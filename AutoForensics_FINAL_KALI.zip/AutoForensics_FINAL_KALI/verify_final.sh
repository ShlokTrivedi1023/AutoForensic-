#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
usage(){
  cat <<'TXT'
Usage:
  ./verify_final.sh --output DIR \
    [--master-evidence CSV --master-manifest CSV --master-timeline CSV --dataset-id TEXT] \
    [--custody-key FILE] [--allow-incomplete]

--allow-incomplete validates technical outputs while preserving a failed strict
release gate when one or more modules remain INCOMPLETE. It does not convert
those modules to PASS_COMPLETE and does not approve the report for final release.
TXT
}
OUTPUT="";ME="";MM="";MT="";DATASET="User-supplied reference dataset";CUSTODY_KEY="";ALLOW_INCOMPLETE=0
while (($#)); do
  case "$1" in
    --output) OUTPUT="$2"; shift 2;;
    --master-evidence) ME="$2"; shift 2;;
    --master-manifest) MM="$2"; shift 2;;
    --master-timeline) MT="$2"; shift 2;;
    --dataset-id) DATASET="$2"; shift 2;;
    --custody-key) CUSTODY_KEY="$2"; shift 2;;
    --allow-incomplete) ALLOW_INCOMPLETE=1; shift;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2;;
  esac
done
[[ -d "$OUTPUT" ]] || { echo "ERROR: output directory not found: $OUTPUT" >&2; usage >&2; exit 2; }
OUTPUT="$(cd "$OUTPUT" && pwd)"

CMD=(python3 tools/final_output_validator.py --output "$OUTPUT" --validation-dir "$OUTPUT/validation")
if [[ -n "$ME$MM$MT" ]]; then
  [[ -f "$ME" && -f "$MM" && -f "$MT" ]] || { echo "ERROR: all three MASTER CSV paths are required together." >&2; exit 2; }
  CMD+=(--master-evidence "$ME" --master-manifest "$MM" --master-timeline "$MT" --dataset-id "$DATASET")
fi
"${CMD[@]}"

# Court-facing completeness gate: every applicable module must carry a
# consistent completion certificate and finish PASS_COMPLETE. Genuinely
# irrelevant or deliberately excluded scopes may be NOT_APPLICABLE/OUT_OF_SCOPE.
# --allow-incomplete never changes the gate result; it only permits the remaining
# technical integrity checks to run and preserves the NOT ACCEPTED result in JSON.
set +e
python3 tools/strict_scope_gate.py "$OUTPUT" --write "$OUTPUT/validation/strict_scope_gate.json"
STRICT_GATE_RC=$?
set -e
if ((STRICT_GATE_RC != 0)); then
  if ((ALLOW_INCOMPLETE)); then
    echo
    echo "STRICT RELEASE GATE: NOT ACCEPTED — incomplete or inconsistent module scope remains."
    echo "Technical verification will continue because --allow-incomplete was supplied."
  else
    exit "$STRICT_GATE_RC"
  fi
fi

REPORT="$(python3 - "$OUTPUT/reports" <<'PY'
from pathlib import Path
import re,sys
root=Path(sys.argv[1])
items=sorted(root.glob('*_report.pdf'))
stable=[p for p in items if not re.search(r'_\d{8}T\d{6}Z_report\.pdf$',p.name)]
print(stable[0] if stable else (items[0] if items else ''))
PY
)"
[[ -f "$REPORT" ]] || { echo "ERROR: final PDF report not found." >&2; exit 3; }
REPORT_JSON="${REPORT%.pdf}.json"
SIG="${REPORT%_report.pdf}_report_signature.json"
PUB="${REPORT%_report.pdf}_report_signing_public.pem"
[[ -f "$REPORT_JSON" ]] || { echo "ERROR: paired report JSON not found: $REPORT_JSON" >&2; exit 3; }
[[ -f "$SIG" && -f "$PUB" ]] || { echo "ERROR: detached signature or public key not found." >&2; exit 3; }

python3 tools/verify_report_signature.py --signature "$SIG" --public-key "$PUB" --base-dir "$OUTPUT/reports"
python3 tools/report_output_audit.py --pdf "$REPORT" --report-json "$REPORT_JSON"
python3 tools/h2_semantic_audit.py --output "$OUTPUT" --write "$OUTPUT/validation/h2_semantic_audit.json"
python3 tests/verify_repaired_run.py --output "$OUTPUT"

COMPLETION="$(find "$OUTPUT" -maxdepth 1 -type f -name '*_completion_manifest.json' -print -quit 2>/dev/null || true)"
if [[ -f "$COMPLETION" ]]; then
  python3 - "$COMPLETION" <<'PY'
import hashlib, json, sys
from pathlib import Path
p=Path(sys.argv[1]); d=json.loads(p.read_text(encoding='utf-8'))
report=Path(d.get('report',{}).get('pdf',''))
expected=str(d.get('report',{}).get('pdf_sha256','')).lower()
if not report.is_file(): raise SystemExit(f"ERROR: completion-manifest report path is missing: {report}")
actual=hashlib.sha256(report.read_bytes()).hexdigest()
if expected and actual != expected: raise SystemExit(f"ERROR: completion-manifest PDF hash mismatch: {actual} != {expected}")
if not bool(d.get('machine_complete')): raise SystemExit('ERROR: completion manifest does not record machine_complete=true')
if not bool(d.get('report',{}).get('signature_verified')): raise SystemExit('ERROR: completion manifest does not record signature verification')
if not bool(d.get('custody',{}).get('chain_integrity_verified')): raise SystemExit('ERROR: completion manifest does not record custody-chain verification')
print(f"Completion manifest verified: {p}")
print(f"Examiner approval status: {d.get('examiner_approval','NOT_ASSERTED')}")
PY
else
  echo "ERROR: completion manifest is missing." >&2; exit 3
fi

if [[ -n "$CUSTODY_KEY" ]]; then
  [[ -f "$CUSTODY_KEY" ]] || { echo "ERROR: custody key not found: $CUSTODY_KEY" >&2; exit 2; }
  LEDGER="$(find "$OUTPUT" -maxdepth 1 -type f -name '*_custody.jsonl' -print -quit)"
  SEAL="$(find "$OUTPUT" -maxdepth 1 -type f -name '*_custody_seal.json' -print -quit)"
  python3 tools/verify_custody.py --ledger "$LEDGER" --seal "$SEAL" --key-file "$CUSTODY_KEY"
else
  echo "Custody HMAC re-verification skipped because --custody-key was not supplied."
  echo "The completion manifest records the in-run chain/HMAC verification result."
fi

echo
if ((STRICT_GATE_RC == 0)); then
  echo "VERIFICATION COMPLETE — STRICT RELEASE GATE PASSED"
else
  echo "TECHNICAL VERIFICATION COMPLETE — STRICT RELEASE NOT ACCEPTED"
fi
echo "Final PDF: $REPORT"
echo "Restricted annex: $OUTPUT/validation/restricted_examiner_annex.json"
echo "Accepted ledger: $OUTPUT/validation/accepted_findings.jsonl"
echo "Candidate ledger: $OUTPUT/validation/candidate_observations.jsonl"
echo "Rejected ledger: $OUTPUT/validation/rejected_observations.jsonl"
echo "Duplicate ledger: $OUTPUT/validation/duplicate_representation_ledger.jsonl"
echo "Derived-fact ledger: $OUTPUT/validation/derived_fact_ledger.jsonl"
echo "Module matrix: $OUTPUT/validation/module_execution_matrix.csv"
echo "Examiner timeline: $(find "$OUTPUT/module_output" -path '*/timeline_builder/examiner_timeline.csv' -print -quit)"
echo "Technical timeline: $(find "$OUTPUT/module_output" -path '*/timeline_builder/technical_event_ledger.csv' -print -quit)"
echo "Custody ledger: $(find "$OUTPUT" -maxdepth 1 -name '*_custody.jsonl' -print -quit)"
echo "Validation results: $OUTPUT/validation"
echo "Logs: $OUTPUT/logs and $OUTPUT/full_execution.log"
