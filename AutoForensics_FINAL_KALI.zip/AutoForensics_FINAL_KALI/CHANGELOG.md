# AutoForensics v2.8.6

## v2.8.6 native-carver performance repair

- Replaced the non-ZIP carver's per-hit maximum-window read with bounded incremental reads that stop at the first deterministically resolved footer/structure.
- Exhaustive signature discovery remains enabled by default; no candidate-count or scan-byte cap was reintroduced.
- ZIP EOCD/central-directory geometry and ZIP payload/CRC validation remain unchanged.
- The change targets repeated EWF logical-media reads and does not contain evidence-specific filenames, offsets, hashes, counts, or expected answers.


- Hardened supported-corpus analysis to be exhaustive by default: zero limits mean unlimited processing and explicit positive resource caps must surface partial/unresolved coverage instead of silent completion.
- Reworked native ZIP carving to validate EOCD/central-directory geometry, decompress/CRC-check complete archives, reject proven corruption, retain inconclusive/encrypted cases as candidates, and account for plausible orphaned local ZIP headers without producing overlapping pseudo-archives.
- Extended evidence accounting so duplicate byte streams retain every source path as provenance aliases instead of disappearing from inventory.
- Removed silent first-N processing limits from filesystem traversal, browser history, email/mbox/PST processing, keyword retention, documents/data rows, OCR candidates, timelines, EVTX parsing, registry traversal/values, recovered-file findings and other supported parsers.
- Retained filesystem directory records in deep filesystem enumeration and kept full raw `fls` output as an artefact.
- Made native filesystem extraction unlimited by default while preserving explicit caveats for overwritten/reallocated data and for any caller-imposed positive extraction budget.
- Made hash-database matching hash every discovered corpus file by default; an explicitly configured size cap is now recorded as unresolved partial coverage.
- Preserved full OCR text, parsed message bodies, source metadata values, decoded document/VBA artefacts and other machine-readable records while leaving bounded report previews as presentation-only summaries.
- Existing E01 evidence is exposed through a read-only libewf stream regardless of whether the image was acquired by AutoForensics or supplied to existing-image mode.
- Added v2.8.6 exhaustive-coverage regression tests and rebaselined the 37-module frozen source lock after the intentional reviewed repairs.
- Production logic remains case-neutral: no validation-image filename, known hash, expected result count, planted artefact offset, MASTER answer or case identifier is used to drive detection.

# AutoForensics v2.8.4

- Repaired the large/multi-table E01 chunk-map defect exposed by the 31.46 GB mostly-empty live USB acquisition. Distinct EWF tables with identical relative offset patterns are now distinguished by table base offset instead of being misclassified as table2 mirrors.
- Live E01 acquisition now requests SHA-256 directly from `ewfacquire` (`-d sha256`) and preserves a libewf acquisition log. The default `stream` hash mode removes the redundant full-device pre/post hashing passes; `AUTOFORENSICS_SOURCE_HASH_MODE=strict` restores separate source pre/post reads when required.
- Acquired E01 verification now uses `ewfverify -d sha256` rather than making the custom EWF reader the acquisition-verification single point of failure.
- Removed a duplicate pre-analysis logical-media hash pass: the verified acquisition hash is reused as the pre-analysis logical-media value.
- Platform-acquired E01 images are analysed through a read-only `ewfmount` logical stream instead of materialising a second full-size RAW image, substantially reducing temporary storage and write time.
- Long `ewfacquire`/`ewfverify` stages now stream progress to the terminal instead of appearing frozen.
- Added regression tests for repeated EWF table patterns and libewf SHA-256 parsing.
- Existing-image deterministic behaviour and the 45-module registry remain unchanged.

# AutoForensics v2.8.3

- Added `--prompt-evidence-source` so a complete case JSON can preload administrative metadata while the examiner still enters the investigator ID/password and explicitly chooses Live device or Existing evidence after authentication.
- The flag refuses combination with `--device` or `--image-path` to prevent ambiguous source selection.
- Added regression tests for the interactive source-selection override.

# AutoForensics v2.8.2

- Fixed the attached-device acquisition CLI/API mismatch: `tools/acquire_devices.py` now passes `hardware_blocker=` to `prepare_write_protection()`.
- Added a regression test that validates keyword compatibility between the CLI call and the core acquisition API.
- No forensic parser, detection rule, evidence result, or module count was changed.

# AutoForensics v2.8.1

- Corrected the Volatility missing-dependency regression test so it is isolated from a genuine system-wide launcher at `/usr/local/bin/vol` or `/opt/volatility3/vol.py`.
- No production forensic parser, module, finding logic, or acquisition behaviour changed.
- Source verification now remains deterministic on fully provisioned Kali installations.

# Changelog

## 2.8.0 — 2026-08-06

- Removed the non-functional `autopsy_analysis` integration from the active registry, execution path, dependency checks, report mapping, validation count and release lock. The platform now contains exactly 45 active modules.
- Reclassified 37 unchanged modules as frozen-verified and eight modules as targeted-repair modules.
- Added dynamic Volatility 3 launcher discovery, exact command/version recording and explicit missing-dependency behaviour for structural memory modules.
- Added deterministic randomised positive, negative and malformed-control tests for memory marker scopes, memory strings, Android/iOS logical records and Volatility adapter behaviour.
- Corrected `mobile_analyzer` so a valid empty supported corpus completes with a verified no-result rather than a partial result.
- Added `core/acquisition.py` and `tools/acquire_devices.py` for safe whole-device discovery, explicit selection, system/output/project-disk exclusion, software/hardware write-protection records, E01/raw imaging, source/acquired-content verification and pre/post-analysis hash comparison.
- Added fail-closed acquisition tests for unverified write protection, post-analysis mutation, segment-manifest mutation and exact raw-byte preservation.
- Added an acquisition integrity table to structured/PDF reporting and extended chain-of-custody events across device selection, protection, imaging and post-analysis verification.
- Preserved historical MASTER module numbering after Autopsy removal; historical module 46 still maps to `mobile_analyzer` while active runtime numbering contains 45 modules.
- Repaired direct execution of `tools/admin.py` and `tools/acquire_devices.py`.
- Forwarded optional-install environment flags through `sudo` and added `gddrescue`/`util-linux` to Kali acquisition dependencies.
- Expanded the automated suite to 91 passing tests and added external denylist anti-hardcoding validation.

## 2.7.4 — 2026-08-06

- Moved generated capability reports out of the extracted source tree into the user state directory so post-install source-hygiene verification is path-neutral.
- Preserved honest incomplete-module reporting during output packaging.

## 2.7.3 — 2026-08-06

- Corrected OCR assurance so accepted OCR requires deterministic independent corroboration and uncorroborated machine transcription remains candidate-only.
- Added dynamic administrative case metadata and clean source-package verification.
