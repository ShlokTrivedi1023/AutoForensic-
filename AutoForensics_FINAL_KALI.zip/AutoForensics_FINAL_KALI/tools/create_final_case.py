#!/usr/bin/env python3
"""Create a generic AutoForensics case without editing JSON or storing secrets."""
from __future__ import annotations
import argparse, getpass, hashlib, json, os, secrets
from datetime import date
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from core.report_signing import generate_signing_key

PERMISSIONS=["conduct_investigation","view_reports","manage_investigators","manage_modules","export_evidence","change_any_password"]

def registry_path()->Path:
    configured=os.environ.get("AUTOFORENSICS_INVESTIGATORS_REGISTRY","").strip()
    if configured:return Path(configured).expanduser().resolve()
    return (Path.home()/".config"/"autoforensics"/"investigators.json").resolve()

def pwhash(password:str)->tuple[str,str]:
    salt=secrets.token_bytes(32)
    digest=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,260_000,dklen=32)
    return digest.hex(),salt.hex()

def infer_domain(path:Path, explicit:str)->tuple[str,str]:
    if explicit!="auto": return explicit, explicit
    if path.is_dir(): return "mobile","mobile"
    ext=path.suffix.lower()
    if ext in {".vmem",".mem",".lime",".dmp"}:return "memory",ext[1:]
    if ext in {".pcap",".pcapng",".cap"}:return "network",ext[1:]
    if ext in {".e01",".ex01",".dd",".img",".raw",".bin"}:return "disk",ext[1:]
    return "disk","auto"

def valid_attachment(path_value:str)->str:
    if not path_value:return ""
    p=Path(path_value).expanduser().resolve()
    if not p.is_file():raise SystemExit(f"Supplementary file not found: {p}")
    return str(p)

def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--evidence",type=Path,required=True)
    ap.add_argument("--case-id",required=True)
    ap.add_argument("--case-file",type=Path,required=True)
    ap.add_argument("--evidence-domain",choices=["auto","disk","memory","network","mobile"],default="auto")
    ap.add_argument("--profile",default="full")
    ap.add_argument("--investigator-id",default=os.environ.get("AUTOFORENSICS_INVESTIGATOR_ID","examiner"))
    ap.add_argument("--investigator-name",default=os.environ.get("AUTOFORENSICS_INVESTIGATOR_NAME","Authorised Examiner"))
    ap.add_argument("--badge",default=os.environ.get("AUTOFORENSICS_BADGE",""))
    ap.add_argument("--institution",default=os.environ.get("AUTOFORENSICS_INSTITUTION",""))
    ap.add_argument("--jurisdiction",default=os.environ.get("AUTOFORENSICS_JURISDICTION","Not specified"))
    ap.add_argument("--authorising-officer","--authorised-by",dest="authorising_officer",default="")
    ap.add_argument("--authorising-title",default="")
    ap.add_argument("--authorising-organisation",default="")
    ap.add_argument("--authorising-email",default="")
    ap.add_argument("--supervising-examiner",default="")
    ap.add_argument("--supervising-title",default="")
    ap.add_argument("--supervising-organisation",default="")
    ap.add_argument("--supervising-email",default="")
    ap.add_argument("--client-representative",default="")
    ap.add_argument("--client-title",default="")
    ap.add_argument("--client-organisation",default="")
    ap.add_argument("--client-email",default="")
    ap.add_argument("--authorisation-letter",default="")
    ap.add_argument("--chain-of-custody",default="")
    ap.add_argument("--evidence-bag-photo",action="append",default=[])
    ap.add_argument("--evidence-bag-photo-dir",action="append",default=[],help="Directory of evidence-bag photographs; repeatable")
    ap.add_argument("--examiner-signature",default="")
    ap.add_argument("--supervisor-signature",default="")
    ap.add_argument("--dummy-attachments",action="store_true")
    ap.add_argument("--enable-openai",action="store_true")
    ap.add_argument("--force",action="store_true")
    args=ap.parse_args()
    evidence=args.evidence.expanduser().resolve()
    if not evidence.exists():raise SystemExit(f"Evidence path not found: {evidence}")
    if not (evidence.is_file() or evidence.is_dir()):raise SystemExit(f"Evidence path is not a file/directory: {evidence}")
    case_file=args.case_file.expanduser().resolve()
    if case_file.exists() and not args.force:raise SystemExit(f"Refusing to overwrite {case_file}; use --force")
    password=os.environ.get("AUTOFORENSICS_INVESTIGATOR_PASSWORD") or getpass.getpass(f"Create/replace password for investigator '{args.investigator_id}': ")
    if len(password)<12:raise SystemExit("Investigator password must be at least 12 characters.")
    reg_path=registry_path(); reg_path.parent.mkdir(parents=True,exist_ok=True)
    template=ROOT/"config"/"investigators.json"
    registry=json.loads(reg_path.read_text() if reg_path.is_file() else (template.read_text() if template.is_file() else '{\"schema_version\":\"1.0\",\"investigators\":{}}'))
    digest,salt=pwhash(password)
    registry.setdefault("investigators",{})[args.investigator_id]={
      "investigator_id":args.investigator_id,"name":args.investigator_name,"badge":args.badge,
      "role":"Forensic Examiner","department":args.institution,"password_hash":digest,"password_salt":salt,
      "account_created":date.today().isoformat(),"last_login":None,"active":True,"must_change_password":False,
      "permissions":PERMISSIONS,"certifications":[],"notes":"Created by create_final_case.py; credentials remain outside the case package."
    }
    reg_path.write_text(json.dumps(registry,indent=2)+"\n"); os.chmod(reg_path,0o600)
    key_dir=Path.home()/".autoforensics"/"keys"; key_dir.mkdir(parents=True,exist_ok=True)
    private=key_dir/"report_private.pem"; public=key_dir/"report_public.pem"
    if not (private.is_file() and public.is_file()): generate_signing_key(private,public)
    os.chmod(private,0o600); os.chmod(public,0o644)
    domain,evidence_type=infer_domain(evidence,args.evidence_domain)
    photo_paths=[valid_attachment(x) for x in args.evidence_bag_photo]
    allowed_photo_suffixes={".jpg",".jpeg",".png",".webp",".tif",".tiff",".bmp",".heic",".heif",".pdf"}
    for directory_value in args.evidence_bag_photo_dir:
      directory=Path(directory_value).expanduser().resolve()
      if not directory.is_dir():raise SystemExit(f"Evidence-bag photo directory not found: {directory}")
      discovered=[str(item.resolve()) for item in sorted(directory.iterdir()) if item.is_file() and item.suffix.lower() in allowed_photo_suffixes]
      if not discovered:raise SystemExit(f"No supported evidence-bag photographs found in: {directory}")
      photo_paths.extend(discovered)
    # Deterministic de-duplication while preserving explicit input order.
    photo_paths=list(dict.fromkeys(photo_paths))
    attachments={
      "authorisation_letter":valid_attachment(args.authorisation_letter),
      "coc_form_image":valid_attachment(args.chain_of_custody),
      "evidence_bag_photos":photo_paths,
      "examiner_signature":valid_attachment(args.examiner_signature),
      "supervisor_signature":valid_attachment(args.supervisor_signature),
    }
    validation_notes={}
    background="Automated forensic examination. Every accepted finding must be derived from the supplied evidence and retain an exact source reference."
    if args.dummy_attachments:
      warning="DUMMY VALIDATION MATERIAL — INGESTION TEST ONLY — NOT VERIFIED"
      validation_notes={"supplementary_document_status":warning,"authorisation_status":warning,"custody_status":warning,"signature_status":warning}
      background += " Supplementary documents are dummy validation material and do not prove authority, custody, identity, ethics approval or legal admissibility."
    ai_policy={"mode":"cloud_opt_in" if args.enable_openai else "local_only","allow_cloud_case_data":bool(args.enable_openai),"consent_reference":f"Authorised optional narrative enhancement for case {args.case_id} on {date.today().isoformat()}" if args.enable_openai else "","permitted_providers":["openai"]}
    case={
      "schema_version":"1.3","case_number":args.case_id,"case_title":"AutoForensics Investigation",
      "jurisdiction":args.jurisdiction,"classification":"FORENSIC EXAMINATION",
      "examiner":{"name":args.investigator_name,"email":"","institution":args.institution,"badge":args.badge,"certifications":[]},
      "authorising_officer":{"name":args.authorising_officer,"title":args.authorising_title,"organisation":args.authorising_organisation,"email":args.authorising_email},
      "supervising_examiner":{"name":args.supervising_examiner,"title":args.supervising_title,"organisation":args.supervising_organisation,"email":args.supervising_email},
      "client_representative":{"name":args.client_representative,"title":args.client_title,"organisation":args.client_organisation,"email":args.client_email},
      "investigation_background":background,"objectives":["Validate evidence integrity","Perform evidence-domain appropriate analysis","Preserve deterministic provenance","Separate accepted, candidate and rejected observations","Generate a signed evidence-grounded report"],
      "investigation_profile":args.profile,
      "evidence_items":[{"exhibit_id":"EX-001","label":"Supplied evidence","path":str(evidence),"description":"Evidence supplied for authorised examination.","serial_number":"","make_model":"","hostname":"","owner":"","os":"","evidence_type":evidence_type,"device_type":domain}],
      "supplementary_files":attachments,"validation_notes":validation_notes,
      "offence_types":[],"report_reference":args.case_id,"report_target_pages":80,
      "ai_policy":ai_policy,"signing":{"require_signature":True,"private_key_path":str(private),"public_key_path":str(public),"signer_role":"Forensic Examiner"}
    }
    case_file.parent.mkdir(parents=True,exist_ok=True); case_file.write_text(json.dumps(case,indent=2)+"\n")
    print(json.dumps({"case_file":str(case_file),"investigator_registry":str(reg_path),"investigator_id":args.investigator_id,"evidence_domain":domain,"evidence_type":evidence_type,"openai_enabled":args.enable_openai,"dummy_attachments":args.dummy_attachments},indent=2))
    return 0
if __name__=="__main__":raise SystemExit(main())
