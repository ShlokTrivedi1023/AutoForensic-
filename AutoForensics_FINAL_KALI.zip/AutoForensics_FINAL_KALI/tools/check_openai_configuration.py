#!/usr/bin/env python3
"""Fail-fast OpenAI configuration check without printing or storing the API key."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.ai_policy import AIPolicyError, enforce_ai_policy  # noqa: E402
from core.case_config import load_case_config  # noqa: E402
from core.llm_provider import LLMUnavailable, synthesize  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate OpenAI case policy and optional connectivity.")
    parser.add_argument("--case-file", required=True)
    parser.add_argument("--live", action="store_true", help="Make one minimal live OpenAI request.")
    args = parser.parse_args()

    os.environ["LLM_PROVIDER"] = "openai"
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        print("FAIL: OPENAI_API_KEY is not set.", file=sys.stderr)
        return 2

    try:
        case = load_case_config(Path(args.case_file))
        record = enforce_ai_policy(case, require_llm=True)
    except (OSError, ValueError, AIPolicyError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2

    print(json.dumps({
        "provider": record["provider"],
        "policy_mode": record["policy_mode"],
        "consent_reference": record["consent_reference"],
        "raw_evidence_transmitted": record["raw_evidence_transmitted"],
        "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        "api_key_present": True,
    }, indent=2))

    if args.live:
        try:
            text = synthesize(
                'Return only this JSON object: {"status":"ok"}',
                purpose="configuration_check",
                max_tokens=40,
                temperature=0.0,
            )
        except LLMUnavailable as exc:
            print(f"FAIL: live OpenAI check failed: {exc}", file=sys.stderr)
            return 3
        if "ok" not in text.lower():
            print("FAIL: OpenAI responded, but the expected check token was absent.", file=sys.stderr)
            return 3
        print("OPENAI LIVE CHECK PASSED")
    else:
        print("OPENAI CONFIGURATION CHECK PASSED (live request not performed)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
