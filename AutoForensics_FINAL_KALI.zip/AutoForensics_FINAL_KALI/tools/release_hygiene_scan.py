#!/usr/bin/env python3
"""Case-neutral source-package hygiene and secret scan."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {".py", ".sh", ".md", ".txt", ".json", ".jsonl", ".yaml", ".yml", ".j2", ".csv"}
BINARY_EVIDENCE_SUFFIXES = {".e01", ".ex01", ".dd", ".img", ".raw", ".vmem", ".mem", ".dmp", ".lime", ".pcap", ".pcapng", ".cap"}
SECRET_PATTERNS = {
    "private key material": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |)PRIVATE KEY-----"),
    "OpenAI-style secret": re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "AWS access key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "GitHub token": re.compile(r"\bgh[opusr]_[A-Za-z0-9]{20,}\b"),
}
FORBIDDEN_DIRS = {".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "output", "outputs"}
FORBIDDEN_FILE_PATTERNS = (
    re.compile(r"(?i)(?:^|[_-])private(?:[_-].*)?\.pem$"),
    re.compile(r"(?i)^id_(?:rsa|dsa|ecdsa|ed25519)$"),
)
GUARD_FILES = {
    "tests/final_acceptance.py",
    "tests/test_strict_scope_completion.py",
    "tools/anti_hardcoding_scan.py",
    "tools/release_selfcheck.py",
    "tools/release_hygiene_scan.py",
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--denylist", type=Path, help="External newline-delimited exact literals forbidden from the package")
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    denylist = []
    if args.denylist:
        denylist = [line.strip() for line in args.denylist.read_text(encoding="utf-8").splitlines()
                    if line.strip() and not line.lstrip().startswith("#")]
    violations: list[dict[str, str]] = []
    scanned = 0
    for path in sorted(ROOT.rglob("*")):
        rel_path = path.relative_to(ROOT)
        rel = rel_path.as_posix()
        if any(part in FORBIDDEN_DIRS for part in rel_path.parts):
            if path.is_dir():
                violations.append({"path": rel, "rule": "generated/cache directory", "detail": path.name})
            continue
        if not path.is_file():
            continue
        scanned += 1
        if path.stat().st_size == 0:
            violations.append({"path": rel, "rule": "zero-byte file", "detail": "empty file"})
        if path.suffix.lower() in BINARY_EVIDENCE_SUFFIXES:
            violations.append({"path": rel, "rule": "evidence-like binary in source package", "detail": path.suffix})
        if any(pattern.search(path.name) for pattern in FORBIDDEN_FILE_PATTERNS):
            violations.append({"path": rel, "rule": "private-key filename", "detail": path.name})
        if path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for name, pattern in SECRET_PATTERNS.items():
            for match in pattern.finditer(text):
                violations.append({"path": rel, "rule": name, "detail": match.group(0)[:80]})
        for value in denylist:
            if len(value) >= 6 and value in text:
                violations.append({"path": rel, "rule": "external denylist literal", "detail": "forbidden exact literal present"})
        if rel not in GUARD_FILES:
            for match in re.finditer(r"(?i)/home/[^/$\s]+/(?:Desktop/)?AutoForensics[^\s\"']*", text):
                violations.append({"path": rel, "rule": "user-specific installation path", "detail": match.group(0)[:120]})
    result = {
        "schema": "autoforensics-release-hygiene-v1",
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "scanned_files": scanned,
        "external_denylist_values": len(denylist),
        "violations": violations,
        "passed": not violations,
    }
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for item in violations:
        print(f"[FAIL] {item['path']}: {item['rule']}: {item['detail']}")
    print(f"RELEASE HYGIENE SCAN: {'PASSED' if not violations else 'FAILED'} ({scanned} files, {len(violations)} violation(s))")
    return 0 if not violations else 1


if __name__ == "__main__":
    raise SystemExit(main())
