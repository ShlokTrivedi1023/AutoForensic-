#!/usr/bin/env python3
"""Safe attached-device discovery and forensic acquisition.

The command never auto-selects a disk.  It excludes the system, output and
project disks, requires an exact confirmation token, verifies hardware or
software write protection, creates E01/raw evidence, and records the five
separate hash stages used by AutoForensics.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.acquisition import (
    AcquisitionError,
    acquire_device,
    discover_devices,
    prepare_write_protection,
    verify_post_analysis,
)


def _device_table(devices) -> None:
    if not devices:
        print("No eligible attached whole-disk devices were found.")
        return
    print("PATH             RO RM  SIZE(bytes)  MODEL / SERIAL                    FLAGS")
    print("-" * 96)
    for d in devices:
        flags = []
        if d.is_system_disk: flags.append("SYSTEM")
        if d.is_output_disk: flags.append("OUTPUT")
        if d.is_project_disk: flags.append("PROJECT")
        if d.mountpoints: flags.append("MOUNTED")
        print(f"{d.path:<16} {int(d.read_only):>2} {int(d.removable):>2} {d.size_bytes:>12}  "
              f"{(d.model + ' / ' + d.serial)[:34]:<34} {' '.join(flags) or 'ELIGIBLE'}")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--list", action="store_true", help="List devices only; performs no acquisition")
    p.add_argument("--device", help="Exact whole-disk device path, for example /dev/sdb")
    p.add_argument("--output-dir", type=Path)
    p.add_argument("--case-id")
    p.add_argument("--evidence-id", default="EX-001")
    p.add_argument("--investigator", default=os.environ.get("USER", "Authorised Examiner"))
    p.add_argument("--format", choices=("e01", "raw", "dd"), default="e01")
    p.add_argument("--write-protection", choices=("software", "hardware"), default="software")
    p.add_argument("--blocker-manufacturer", default="")
    p.add_argument("--blocker-model", default="")
    p.add_argument("--blocker-serial", default="")
    p.add_argument("--blocker-firmware", default="")
    p.add_argument("--blocker-connection", default="")
    p.add_argument("--confirm", help="Must equal ACQUIRE-<device-basename>-<case-id>")
    p.add_argument("--verify-post-analysis", type=Path,
                   help="Verify a prior acquisition manifest after analysis and exit")
    args = p.parse_args()

    try:
        if args.verify_post_analysis:
            data = json.loads(args.verify_post_analysis.read_text(encoding="utf-8"))
            from core.acquisition import acquisition_record_from_dict
            record = acquisition_record_from_dict(data)
            updated = verify_post_analysis(record)
            args.verify_post_analysis.write_text(json.dumps(asdict(updated), indent=2) + "\n", encoding="utf-8")
            print(json.dumps(asdict(updated), indent=2))
            print("POST-ANALYSIS IMAGE INTEGRITY VERIFIED")
            return 0

        output = args.output_dir.resolve() if args.output_dir else (Path.cwd() / "acquisition_output").resolve()
        devices = discover_devices(output_dir=output, project_root=ROOT)
        _device_table(devices)
        if args.list:
            return 0
        if not all((args.device, args.output_dir, args.case_id)):
            p.error("--device, --output-dir and --case-id are required for acquisition")
        selected = next((d for d in devices if d.path == args.device), None)
        if selected is None:
            raise AcquisitionError(
                "Selected path was not returned by safe whole-disk discovery. It may be a partition, "
                "system/output/project disk, or no longer connected."
            )
        expected = f"ACQUIRE-{Path(selected.path).name}-{args.case_id}"
        if args.confirm != expected:
            raise AcquisitionError(f"Explicit confirmation required: --confirm {expected}")

        details = {
            "manufacturer": args.blocker_manufacturer,
            "model": args.blocker_model,
            "serial_number": args.blocker_serial,
            "firmware_version": args.blocker_firmware,
            "connection_type": args.blocker_connection,
            "investigator_confirmation": args.confirm,
        }
        protection = prepare_write_protection(
            selected,
            requested_method=args.write_protection,
            hardware_blocker=details,
        )
        record = acquire_device(
            source=selected,
            output_dir=output,
            case_id=args.case_id,
            evidence_id=args.evidence_id,
            investigator=args.investigator,
            acquisition_format=args.format,
            write_protection=protection,
            description=f"Physical sector-by-sector acquisition of {selected.path}",
            notes=("Hardware blocker recorded" if args.write_protection == "hardware"
                   else "Kali software-enforced read-only fallback; not equivalent to a hardware blocker"),
        )
        manifest = output / f"{args.case_id}_{args.evidence_id}_acquisition_manifest.json"
        manifest.write_text(json.dumps(asdict(record), indent=2) + "\n", encoding="utf-8")
        print(json.dumps(asdict(record), indent=2))
        print(f"ACQUISITION VERIFIED — manifest: {manifest}")
        return 0
    except (AcquisitionError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ACQUISITION REFUSED/FAILED: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
