#!/usr/bin/env python3
"""Create a truthful manual-examination timing record for H1 evaluation."""
from __future__ import annotations
import argparse,hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path

def now():return datetime.now(timezone.utc).isoformat()
def main()->int:
    p=argparse.ArgumentParser();p.add_argument('--case-id',required=True);p.add_argument('--examiner',required=True);p.add_argument('--scope',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    print('Press ENTER immediately before beginning the manual examination.');input();started=now();mono=time.monotonic();print('Timer started:',started);print('Press ENTER after analysis and report completion.');input();ended=now();seconds=time.monotonic()-mono
    record={'schema':'autoforensics-manual-timing-v1','case_id':a.case_id,'examiner':a.examiner,'scope':a.scope,'started_at':started,'completed_at':ended,'manual_seconds':round(seconds,3),'statement':'Timing was initiated and stopped interactively by the named examiner; AutoForensics did not infer the manual duration.'}
    payload=json.dumps(record,sort_keys=True,separators=(',',':')).encode();record['record_sha256']=hashlib.sha256(payload).hexdigest();a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
