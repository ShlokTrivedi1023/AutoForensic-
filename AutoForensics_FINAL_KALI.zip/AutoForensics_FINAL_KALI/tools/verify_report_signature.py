#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
import argparse, json
from core.report_signing import verify_report_signature

p=argparse.ArgumentParser(description="Verify an AutoForensics detached Ed25519 report signature.")
p.add_argument("--signature", required=True)
p.add_argument("--public-key", required=True)
p.add_argument("--base-dir")
a=p.parse_args()
try:
    result=verify_report_signature(a.signature,a.public_key,base_dir=a.base_dir)
except Exception as exc:
    print(f"REPORT SIGNATURE VERIFICATION FAILED: {exc}")
    raise SystemExit(1)
print("REPORT SIGNATURE VERIFICATION PASSED")
print(json.dumps(result,indent=2,sort_keys=True))
