#!/usr/bin/env python3
"""Re-certify a retained pipeline manifest with the current assurance engine.

This tool never changes findings or injects expected answers.  It reconstructs
ModuleResult/Finding objects from a prior manifest, uses each certificate's
recorded original execution status, and applies the current case-neutral scope
contracts.  Specialist-tool limitations therefore remain visible.
"""
from __future__ import annotations
import argparse
import copy
import json
from collections import Counter
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.fact_classification import annotate_findings
from core.module_completion import certify_module_result
from modules._base import Finding, ModuleResult, ModuleStatus, Severity


def _finding(record: dict) -> Finding:
    severity_name = str(record.get("severity") or "INFO").rsplit(".", 1)[-1]
    try:
        severity = Severity(severity_name)
    except ValueError:
        severity = Severity.INFO
    return Finding(
        finding_id=str(record.get("finding_id") or ""),
        finding_type=str(record.get("finding_type") or ""),
        severity=severity,
        description=str(record.get("description") or ""),
        evidence_path=str(record.get("evidence_path") or ""),
        artifact_path=record.get("artifact_path"),
        metadata=copy.deepcopy(record.get("metadata") or {}),
        timestamp=str(record.get("timestamp") or ""),
        evidence_reference=copy.deepcopy(record.get("evidence_reference") or {}),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("pipeline_manifest", type=Path)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    source = json.loads(args.pipeline_manifest.read_text(encoding="utf-8"))
    if not isinstance(source, list):
        raise SystemExit("Pipeline manifest must be a JSON list")

    output = []
    for record in source:
        name = str(record.get("module_name") or record.get("module") or "")
        stats = copy.deepcopy(record.get("statistics") or {})
        old_certificate = stats.pop("completion_certificate", {}) or {}
        stats.pop("coverage", None)
        original_status = str(old_certificate.get("original_status") or record.get("status") or "COMPLETED")
        try:
            status = ModuleStatus(original_status)
        except ValueError:
            status = ModuleStatus.COMPLETED
        result = ModuleResult(
            module_name=name,
            case_id="REPLAY",
            status=status,
            findings=[_finding(item) for item in record.get("findings") or []],
            statistics=stats,
            errors=copy.deepcopy(record.get("errors") or []),
            summary=str(record.get("summary") or ""),
        )
        result.findings = annotate_findings(name, result.findings)
        result = certify_module_result(
            result,
            module_name=name,
            config={"analysis_path": "/retained/evidence", "_working_set": {"evidence_inventory": {}}},
        )
        certificate = result.statistics.get("completion_certificate") or {}
        output.append({
            "module": name,
            "original_execution_status": original_status,
            "replayed_final_status": result.status.value,
            "reasons": certificate.get("reasons") or [],
            "certificate_sha256": certificate.get("certificate_sha256"),
        })

    counts = Counter(item["replayed_final_status"] for item in output)
    summary = {"counts": dict(sorted(counts.items())), "modules": output}
    print(json.dumps(summary, indent=2))
    if args.json_output:
        args.json_output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
