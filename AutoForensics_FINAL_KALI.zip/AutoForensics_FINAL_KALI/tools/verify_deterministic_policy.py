#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
CANDIDATE_BASES={'candidate','heuristic','probabilistic','statistical','model'}
def main():
 p=argparse.ArgumentParser(); p.add_argument('pipeline_manifest',type=Path); a=p.parse_args()
 data=json.loads(a.pipeline_manifest.read_text(encoding='utf-8')); violations=[]
 for module in data:
  for finding in module.get('findings') or []:
   md=finding.get('metadata') or {}; basis=str(md.get('finding_basis') or '').casefold(); fc=str(md.get('fact_class') or '').upper()
   accepted=bool(md.get('counts_toward_unique_evidence',True)) and fc not in {'CANDIDATE_ONLY','REJECTED'}
   if accepted and (basis in CANDIDATE_BASES or md.get('deterministic_validation') is False):
    violations.append((module.get('module_name'),finding.get('finding_id'),basis))
 for v in violations: print('[FAIL]',*v)
 print(f'DETERMINISTIC POLICY: {len(violations)} violation(s)')
 return 1 if violations else 0
if __name__=='__main__': raise SystemExit(main())
