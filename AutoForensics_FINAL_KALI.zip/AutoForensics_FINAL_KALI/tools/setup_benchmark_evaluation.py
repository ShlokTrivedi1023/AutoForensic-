#!/usr/bin/env python3
"""Create a benchmark manifest from real case output, ground truth and timing.

This helper removes manual JSON editing but never invents answer keys or manual
examiner timings. The supplied ground-truth file and manual duration remain the
researcher's evidence.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--case-dir", type=Path, required=True)
    parser.add_argument("--ground-truth", type=Path, required=True)
    parser.add_argument("--manual-seconds", type=float, required=True)
    parser.add_argument("--automated-seconds", type=float)
    parser.add_argument("--dataset", default="NIST CFReDS")
    parser.add_argument("--output", type=Path, default=Path("benchmark_manifest.json"))
    args = parser.parse_args()

    case_dir = args.case_dir.expanduser().resolve()
    ground_truth = args.ground_truth.expanduser().resolve()
    if not case_dir.is_dir():
        raise SystemExit(f"Case output directory not found: {case_dir}")
    if not ground_truth.is_file():
        raise SystemExit(f"Ground-truth file not found: {ground_truth}")
    if args.manual_seconds <= 0:
        raise SystemExit("--manual-seconds must be greater than zero and based on a real measured examination.")

    try:
        gt = json.loads(ground_truth.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Ground-truth JSON is invalid: {exc}") from exc
    if str(gt.get("case_id") or "") not in {"", args.case_id}:
        raise SystemExit(
            f"Ground-truth case_id {gt.get('case_id')!r} does not match {args.case_id!r}."
        )
    artifacts = gt.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise SystemExit("Ground-truth JSON must contain a non-empty artifacts list.")

    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": "1.0",
        "dataset": args.dataset,
        "cases": [{
            "case_id": args.case_id,
            "case_output_dir": str(case_dir),
            "ground_truth": str(ground_truth),
            "manual_seconds": args.manual_seconds,
            "automated_seconds": args.automated_seconds,
        }],
        "statement": (
            "The ground truth and manual timing were supplied by the researcher. "
            "AutoForensics did not infer or generate them."
        ),
    }
    output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("BENCHMARK MANIFEST CREATED")
    print(f"Manifest: {output}")
    print(f"Case output: {case_dir}")
    print(f"Ground truth: {ground_truth}")
    print(f"Manual seconds: {args.manual_seconds}")
    print("Run:")
    print(
        f"  python3 tools/evaluate_benchmark.py --manifest {output} "
        "--output-dir benchmark_results --require-h1-percent 50 --require-h2"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
