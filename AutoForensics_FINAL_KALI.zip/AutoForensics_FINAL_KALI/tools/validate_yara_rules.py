#!/usr/bin/env python3
from __future__ import annotations
import argparse,re,shutil,subprocess,sys,tempfile
from pathlib import Path

def main()->int:
    p=argparse.ArgumentParser();p.add_argument('--rules',type=Path,default=Path('config/yara/default_rules.yar'));a=p.parse_args();rules=a.rules.resolve();text=rules.read_text(encoding='utf-8',errors='replace')
    failures=[]
    if re.search(r'(?m)^\s*\$\w+\s*=.*\bat\s+\d+\s*$',text):failures.append('location operator used in strings declaration; use it in condition')
    ids=re.findall(r'(?m)^\s*(?:private\s+|global\s+)?rule\s+([A-Za-z_][A-Za-z0-9_]*)\b',text)
    if not ids:failures.append('no rule identifiers found')
    if shutil.which('yara'):
        with tempfile.NamedTemporaryFile() as target:
            cp=subprocess.run(['yara','-w',str(rules),target.name],capture_output=True,text=True,timeout=30,check=False)
        if cp.returncode not in (0,1):failures.append((cp.stderr or cp.stdout).strip())
    else:
        try:
            import yara
            yara.compile(filepath=str(rules))
        except ImportError:pass
        except Exception as exc:failures.append(str(exc))
    if failures:
        for x in failures:print('[FAIL]',x)
        return 1
    print(f'[PASS] YARA rule set validated: {len(ids)} rule(s)')
    return 0
if __name__=='__main__':raise SystemExit(main())
