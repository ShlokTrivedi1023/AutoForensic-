#!/usr/bin/env python
"""
tools/analyze_image.py — Pure-Python forensic disk image analyzer for AutoForensics.

Performs a real forensic examination of a raw DD/E01/IMG disk image using
only the Python standard library plus optional hashlib.  No external forensic
tools are required.

Analysis steps
--------------
1.  Hash the disk image (MD5 + SHA-256).
2.  Parse the MBR partition table (CHS geometry, partition type/offset/size).
3.  For each partition, attempt NTFS VBR detection and NTFS MFT parsing.
4.  Extract file metadata (path, size, created, modified, accessed, SHA-256)
    from the MFT for all resident-data and $FILE_NAME attributes.
5.  Run pure-Python string extraction against the image, matching IOC regexes
    (IPs, URLs, email, registry paths, crypto addresses).
6.  Identify suspicious patterns: executable content in image, deleted MFT
    entries, oversized files, unusual timestamps.
7.  Write output to <output_dir>/disk_analysis.json.
8.  Optionally write <output_dir>/evidence_info.json.

Usage
-----
    python tools/analyze_image.py \\
        --image "/path/to/evidence.raw" \\
        --case-id E02 \\
        --output "/full/path/to/output/E02"

Output files
------------
    <output_dir>/disk_analysis.json    — full structured analysis result
    <output_dir>/evidence_info.json    — evidence acquisition record for the report
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import logging
import os
import re
import struct
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S%z",
)
logger = logging.getLogger("analyze_image")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SECTOR_SIZE   = 512
_MBR_SIZE      = 512
_GPT_HEADER_LBA = 1
_NTFS_MAGIC    = b"NTFS    "          # 8 bytes at VBR offset 3
_MFT_SIGNATURE = b"FILE"
_MFT_ENTRY_SZ  = 1024                 # default MFT record size
_MAX_FILES     = 0                    # 0 = exhaustive; positive values are explicit caller safety caps
_STRING_MIN    = 6                    # minimum printable string length
_STRING_CHUNK  = 4 * 1024 * 1024      # 4 MiB chunks for string extraction
_HASH_CHUNK    = 8 * 1024 * 1024      # 8 MiB chunks for image hashing

# Windows FILETIME epoch: 1601-01-01 00:00:00 UTC
_FILETIME_EPOCH = datetime(1601, 1, 1, tzinfo=timezone.utc)
_100NS_PER_SEC  = 10_000_000


def _filetime_to_dt(ft: int) -> Optional[str]:
    """Convert a Windows FILETIME (100-nanosecond intervals since 1601-01-01) to ISO 8601."""
    if ft == 0 or ft == 0xFFFFFFFFFFFFFFFF:
        return None
    try:
        seconds = ft / _100NS_PER_SEC
        dt = _FILETIME_EPOCH + timedelta(seconds=seconds)
        if dt.year < 1970 or dt.year > 2100:
            return None
        return dt.isoformat()
    except (OverflowError, OSError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Image hashing
# ---------------------------------------------------------------------------

def hash_image(image_path: str) -> dict[str, Any]:
    """Compute MD5 and SHA-256 of the disk image. Returns a dict with hash values."""
    logger.info("Hashing image: %s", image_path)
    md5  = hashlib.md5()
    sha  = hashlib.sha256()
    size = 0
    with open(image_path, "rb") as f:
        while chunk := f.read(_HASH_CHUNK):
            md5.update(chunk)
            sha.update(chunk)
            size += len(chunk)
            if size % (128 * 1024 * 1024) == 0:
                logger.info("  Hashed %.0f MB…", size / 1024 / 1024)
    result = {
        "image_path":       image_path,
        "image_size_bytes": size,
        "image_md5":        md5.hexdigest(),
        "image_sha256":     sha.hexdigest(),
    }
    logger.info("Image SHA-256: %s", result["image_sha256"])
    logger.info("Image size:    %.1f MB", size / 1024 / 1024)
    return result


# ---------------------------------------------------------------------------
# MBR / partition table
# ---------------------------------------------------------------------------

def parse_mbr(image_path: str) -> dict[str, Any]:
    """
    Read and parse the MBR partition table.

    Returns a dict with 'mbr_signature', 'disk_id', and 'partitions' list.
    Each partition dict has: index, type_id, type_name, bootable,
    lba_start, lba_size, byte_offset, byte_size.
    """
    _PARTITION_TYPES = {
        0x00: "Empty",
        0x01: "FAT12",
        0x04: "FAT16 <32MB",
        0x05: "Extended CHS",
        0x06: "FAT16",
        0x07: "NTFS / HPFS",
        0x0B: "FAT32 CHS",
        0x0C: "FAT32 LBA",
        0x0E: "FAT16 LBA",
        0x0F: "Extended LBA",
        0x11: "Hidden FAT12",
        0x14: "Hidden FAT16 <32MB",
        0x16: "Hidden FAT16",
        0x17: "Hidden NTFS",
        0x1B: "Hidden FAT32 CHS",
        0x1C: "Hidden FAT32 LBA",
        0x27: "Windows RE",
        0x42: "Windows LDM",
        0x82: "Linux Swap",
        0x83: "Linux",
        0x85: "Linux Extended",
        0x8E: "Linux LVM",
        0xA5: "FreeBSD",
        0xA8: "macOS HFS",
        0xAB: "macOS Boot",
        0xAF: "macOS HFS+",
        0xEE: "GPT protective MBR",
        0xEF: "EFI System",
        0xFB: "VMware VMFS",
        0xFE: "GPT",
        0xFF: "XENIX BBT",
    }

    with open(image_path, "rb") as f:
        mbr = f.read(512)

    if len(mbr) < 512:
        return {"error": "Image too small for MBR"}

    sig = struct.unpack_from("<H", mbr, 510)[0]
    disk_id = mbr[440:444].hex()

    partitions = []
    for i in range(4):
        off = 446 + i * 16
        entry = mbr[off:off + 16]
        bootable  = entry[0] == 0x80
        type_id   = entry[4]
        lba_start = struct.unpack_from("<I", entry, 8)[0]
        lba_size  = struct.unpack_from("<I", entry, 12)[0]
        if type_id == 0 and lba_start == 0:
            continue
        partitions.append({
            "index":       i,
            "type_id":     f"0x{type_id:02X}",
            "type_name":   _PARTITION_TYPES.get(type_id, f"Unknown (0x{type_id:02X})"),
            "bootable":    bootable,
            "lba_start":   lba_start,
            "lba_size":    lba_size,
            "byte_offset": lba_start * _SECTOR_SIZE,
            "byte_size":   lba_size * _SECTOR_SIZE,
        })

    result = {
        "mbr_signature": f"0x{sig:04X}",
        "mbr_valid":     sig == 0xAA55,
        "disk_id":       disk_id,
        "partitions":    partitions,
    }
    logger.info("MBR: signature=%s valid=%s  %d partition(s)",
                result["mbr_signature"], result["mbr_valid"], len(partitions))
    for p in partitions:
        logger.info("  Partition %d: type=%s  lba_start=%d  size=%.1f MB%s",
                    p["index"], p["type_name"], p["lba_start"],
                    p["byte_size"] / 1024 / 1024,
                    "  [bootable]" if p["bootable"] else "")
    return result


# ---------------------------------------------------------------------------
# FAT filesystem detection and parsing
# ---------------------------------------------------------------------------

_FAT_MEDIA_FIXED = 0xF8


def _fat_date(date_val: int) -> Optional[str]:
    if date_val == 0:
        return None
    day   = date_val & 0x1F
    month = (date_val >> 5) & 0x0F
    year  = ((date_val >> 9) & 0x7F) + 1980
    try:
        return f"{year:04d}-{month:02d}-{day:02d}"
    except Exception:
        return None


def _fat_datetime(time_val: int, date_val: int) -> Optional[str]:
    if date_val == 0:
        return None
    sec    = (time_val & 0x1F) * 2
    minute = (time_val >> 5) & 0x3F
    hour   = (time_val >> 11) & 0x1F
    day    = date_val & 0x1F
    month  = (date_val >> 5) & 0x0F
    year   = ((date_val >> 9) & 0x7F) + 1980
    try:
        return f"{year:04d}-{month:02d}-{day:02d}T{hour:02d}:{minute:02d}:{sec:02d}"
    except Exception:
        return None


def detect_fat(vbr: bytes) -> Optional[dict[str, Any]]:
    """
    Detect a FAT12/16/32 filesystem from a VBR (Volume Boot Record).
    Returns a dict of BPB parameters, or None if not FAT.
    """
    if len(vbr) < 62:
        return None
    oem_id = vbr[3:11]
    if not (oem_id.startswith(b"MSDOS") or oem_id.startswith(b"MSWIN") or
            oem_id.startswith(b"mkdosfs") or oem_id.startswith(b"FAT")):
        return None

    try:
        bps = struct.unpack_from("<H", vbr, 11)[0]   # bytes per sector
        spc = vbr[13]                                  # sectors per cluster
        res = struct.unpack_from("<H", vbr, 14)[0]    # reserved sectors
        nf  = vbr[16]                                   # number of FATs
        rde = struct.unpack_from("<H", vbr, 17)[0]    # root dir entries (FAT12/16)
        ts16 = struct.unpack_from("<H", vbr, 19)[0]   # total sectors 16
        fat16sz = struct.unpack_from("<H", vbr, 22)[0]# FAT size 16
        ts32 = struct.unpack_from("<I", vbr, 32)[0]   # total sectors 32
        fat32sz = struct.unpack_from("<I", vbr, 36)[0]# FAT size 32

        if bps == 0 or spc == 0 or nf == 0:
            return None

        total_sectors = ts16 if ts16 != 0 else ts32
        fat_size      = fat16sz if fat16sz != 0 else fat32sz
        if total_sectors == 0 or fat_size == 0:
            return None

        rds  = (rde * 32 + bps - 1) // bps           # root dir sectors
        dss  = res + nf * fat_size + rds              # data start sector
        data_sectors  = total_sectors - dss
        total_clusters = data_sectors // spc

        if total_clusters < 4085:
            fat_type = "FAT12"
        elif total_clusters < 65525:
            fat_type = "FAT16"
        else:
            fat_type = "FAT32"

        # Volume label
        if fat_type in ("FAT12", "FAT16"):
            vol_label = vbr[43:51].decode("ascii", errors="replace").strip()
            vol_id    = struct.unpack_from("<I", vbr, 39)[0]
        else:
            vol_label = vbr[71:82].decode("ascii", errors="replace").strip()
            vol_id    = struct.unpack_from("<I", vbr, 67)[0]

        return {
            "fat_type":           fat_type,
            "bytes_per_sector":   bps,
            "sectors_per_cluster": spc,
            "reserved_sectors":   res,
            "num_fats":           nf,
            "root_dir_entries":   rde,
            "fat_size_sectors":   fat_size,
            "total_sectors":      total_sectors,
            "root_dir_sectors":   rds,
            "data_start_sector":  dss,
            "total_clusters":     total_clusters,
            "volume_label":       vol_label,
            "volume_id":          f"{vol_id:08X}",
            "cluster_size":       bps * spc,
            "root_dir_offset":    (res + nf * fat_size) * bps,
            "fat_offset":         res * bps,
        }
    except struct.error:
        return None


def _cluster_to_offset(cluster: int, bpb: dict, part_offset: int = 0) -> int:
    """Convert a cluster number to a byte offset within the image."""
    return part_offset + (bpb["data_start_sector"] + (cluster - 2) * bpb["sectors_per_cluster"]) * bpb["bytes_per_sector"]


def parse_fat_volume(
    image_path: str, bpb: dict, part_offset: int = 0,
    max_files: int = _MAX_FILES,
) -> list[dict[str, Any]]:
    """Parse a FAT12/16/32 volume using the canonical exhaustive FAT walker.

    ``max_files <= 0`` means unlimited. A positive value is an explicit
    caller-requested safety cap; it is not used by the default investigation.
    Directory traversal is cycle-safe and follows complete FAT cluster chains.
    """
    from core.native_filesystem import FatVolume

    volume = FatVolume(Path(image_path).resolve(), part_offset)
    native_entries = volume.list_files(max_entries=max_files)
    entries: list[dict[str, Any]] = []
    for item in native_entries:
        # Preserve directories as addressable filesystem objects rather than
        # silently dropping them. Consumers that only need files can filter on
        # ``is_directory`` explicitly.
        entries.append({
            "path": item.path,
            "name": item.name,
            "extension": Path(item.name).suffix.lstrip(".").lower(),
            "size_bytes": item.size_bytes,
            "cluster": item.first_cluster,
            "created": item.created,
            "modified": item.modified,
            "accessed": item.accessed,
            "is_system": bool(item.attributes & 0x04),
            "is_hidden": bool(item.attributes & 0x02),
            "is_directory": item.is_directory,
            "deleted": item.deleted,
            "cluster_chain": list(item.cluster_chain),
            "caveats": list(item.caveats),
            "sha256": item.sha256,
        })

    logger.info("FAT filesystem listing: %d object(s) found", len(entries))
    return entries

def _entry_cluster_chain(entry: dict[str, Any], bpb: dict, image_path: str, part_offset: int) -> list[int]:
    """Return the evidence-derived FAT cluster chain for a parsed entry."""
    chain = [int(v) for v in (entry.get("cluster_chain") or []) if int(v) >= 2]
    if chain:
        return chain
    # Backward-compatible fallback for callers that pass an older entry shape.
    try:
        from core.native_filesystem import FatVolume
        volume = FatVolume(Path(image_path).resolve(), part_offset)
        chain, caveats = volume.chain(int(entry.get("cluster") or 0))
        if caveats:
            entry.setdefault("caveats", []).extend(caveats)
        return chain
    except Exception as exc:
        entry.setdefault("caveats", []).append(f"FAT chain resolution failed: {exc}")
        return []


def read_fat_file_bytes(
    image_path: str, bpb: dict, entry: dict, part_offset: int = 0,
    max_bytes: int = 0,
) -> bytes:
    """Read FAT file content; ``max_bytes <= 0`` means the complete file."""
    size = int(entry.get("size_bytes") or 0)
    if size <= 0:
        return b""
    remaining = min(size, max_bytes) if max_bytes > 0 else size
    chain = _entry_cluster_chain(entry, bpb, image_path, part_offset)
    if not chain:
        return b""
    data_parts: list[bytes] = []
    try:
        with open(image_path, "rb") as f:
            for cluster in chain:
                if remaining <= 0:
                    break
                off = _cluster_to_offset(cluster, bpb, part_offset)
                read_size = min(int(bpb["cluster_size"]), remaining)
                f.seek(off)
                chunk = f.read(read_size)
                if not chunk:
                    entry.setdefault("caveats", []).append(
                        f"Unexpected EOF while reading FAT cluster {cluster}"
                    )
                    break
                data_parts.append(chunk)
                remaining -= len(chunk)
    except OSError as exc:
        entry.setdefault("caveats", []).append(f"FAT content read failed: {exc}")
        return b""
    if remaining > 0 and max_bytes <= 0:
        entry.setdefault("caveats", []).append(
            f"FAT content incomplete: {remaining} byte(s) could not be read"
        )
    return b"".join(data_parts)


def hash_fat_file(
    image_path: str, bpb: dict, entry: dict, part_offset: int = 0,
) -> str:
    """Compute SHA-256 of the complete recoverable FAT file content."""
    content = read_fat_file_bytes(image_path, bpb, entry, part_offset, max_bytes=0)
    expected = int(entry.get("size_bytes") or 0)
    if expected > 0 and len(content) != expected:
        return "INCOMPLETE"
    return hashlib.sha256(content).hexdigest()


def save_fat_files(
    image_path: str, bpb: dict, entries: list[dict], output_dir: Path, part_offset: int = 0,
) -> list[dict]:
    """Extract every recoverable FAT file; directory objects remain in the listing."""
    extract_dir = output_dir / "extracted_files"
    extract_dir.mkdir(parents=True, exist_ok=True)

    for index, entry in enumerate(entries):
        if entry.get("is_directory"):
            entry["content_status"] = "directory"
            continue
        expected = int(entry.get("size_bytes") or 0)
        content = read_fat_file_bytes(image_path, bpb, entry, part_offset, max_bytes=0)
        if expected > 0 and len(content) != expected:
            entry["content_status"] = "incomplete"
            entry["sha256"] = hashlib.sha256(content).hexdigest() if content else ""
            continue
        entry["sha256"] = hashlib.sha256(content).hexdigest()
        entry["content_status"] = "complete"
        if expected <= 0:
            continue

        # Preserve the relative evidence path to avoid same-name collisions.
        rel = str(entry.get("path") or entry.get("name") or f"file_{index}").lstrip("/")
        safe_parts = []
        for component in Path(rel).parts:
            cleaned = "".join(c if c not in '<>:"|?*\\\x00' else "_" for c in component).strip()
            safe_parts.append(cleaned or "unnamed")
        out_path = extract_dir.joinpath(*safe_parts)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            out_path.write_bytes(content)
            entry["extracted_path"] = str(out_path)
        except OSError as exc:
            entry["content_status"] = "write_error"
            entry.setdefault("caveats", []).append(f"Could not save extracted file: {exc}")

        logger.info(
            "  %s  %d bytes  SHA-256: %s…",
            str(entry.get("path") or ""), expected, str(entry.get("sha256") or "")[:16],
        )

    return entries


# ---------------------------------------------------------------------------
# NTFS detection and basic VBR parsing
# ---------------------------------------------------------------------------

def find_ntfs_partitions(image_path: str, mbr: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Find NTFS partitions by checking the VBR NTFS magic at the partition offset.

    Returns a list of dicts with 'partition_index', 'byte_offset',
    'ntfs_vbr' (parsed fields from the VBR), and 'mft_offset'.
    """
    ntfs_volumes = []
    image_size = os.path.getsize(image_path)

    # If no partition table or image is small, try offset 0
    check_offsets = [(0, 0)]
    for p in mbr.get("partitions", []):
        check_offsets.append((p["index"], p["byte_offset"]))

    with open(image_path, "rb") as f:
        for part_idx, offset in check_offsets:
            if offset >= image_size:
                continue
            f.seek(offset)
            vbr = f.read(512)
            if len(vbr) < 84:
                continue
            if vbr[3:11] != _NTFS_MAGIC:
                continue

            # Parse NTFS BPB (BIOS Parameter Block)
            try:
                bytes_per_sector    = struct.unpack_from("<H", vbr, 11)[0]
                sectors_per_cluster = vbr[13]
                sectors_per_track   = struct.unpack_from("<H", vbr, 24)[0]
                number_of_heads     = struct.unpack_from("<H", vbr, 26)[0]
                total_sectors       = struct.unpack_from("<Q", vbr, 40)[0]
                mft_lcn             = struct.unpack_from("<Q", vbr, 48)[0]  # MFT logical cluster number
                mft_mirr_lcn        = struct.unpack_from("<Q", vbr, 56)[0]
                clusters_per_mft    = struct.unpack_from("<i", vbr, 64)[0]
                volume_serial       = struct.unpack_from("<Q", vbr, 72)[0]

                if bytes_per_sector == 0 or sectors_per_cluster == 0:
                    continue

                cluster_size = bytes_per_sector * sectors_per_cluster
                mft_offset   = offset + mft_lcn * cluster_size

                # Validate: MFT offset must be within image
                if mft_offset >= image_size:
                    continue

                ntfs_info = {
                    "partition_index":    part_idx,
                    "partition_offset":   offset,
                    "bytes_per_sector":   bytes_per_sector,
                    "sectors_per_cluster": sectors_per_cluster,
                    "cluster_size":       cluster_size,
                    "total_sectors":      total_sectors,
                    "volume_size_bytes":  total_sectors * bytes_per_sector,
                    "mft_lcn":            mft_lcn,
                    "mft_offset":         mft_offset,
                    "volume_serial":      f"{volume_serial:016X}",
                }
                ntfs_volumes.append(ntfs_info)
                logger.info(
                    "NTFS detected at offset %d (partition %d): "
                    "cluster=%d bytes  MFT LCN=%d  MFT byte offset=%d",
                    offset, part_idx, cluster_size, mft_lcn, mft_offset,
                )
            except (struct.error, ZeroDivisionError) as exc:
                logger.debug("VBR parse error at offset %d: %s", offset, exc)

    return ntfs_volumes


# ---------------------------------------------------------------------------
# NTFS MFT parsing
# ---------------------------------------------------------------------------

_ATTR_TYPE_STANDARD_INFO  = 0x10
_ATTR_TYPE_FILE_NAME      = 0x30
_ATTR_TYPE_DATA           = 0x80
_NAMESPACE_WIN32          = 1
_NAMESPACE_DOS_WIN32      = 3


def _parse_attribute(data: bytes, offset: int) -> Optional[dict[str, Any]]:
    """Parse one NTFS attribute starting at offset. Returns None on error."""
    if offset + 16 > len(data):
        return None
    try:
        attr_type   = struct.unpack_from("<I", data, offset)[0]
        attr_len    = struct.unpack_from("<I", data, offset + 4)[0]
        non_resident = data[offset + 8]
        name_len    = data[offset + 9]
        content_off = struct.unpack_from("<H", data, offset + 20)[0]

        if attr_type == 0xFFFFFFFF or attr_len == 0 or attr_len > 65536:
            return None

        content = data[offset + content_off: offset + attr_len] if not non_resident else b""
        return {
            "attr_type":    attr_type,
            "attr_len":     attr_len,
            "non_resident": bool(non_resident),
            "name_len":     name_len,
            "content":      content,
        }
    except struct.error:
        return None


def _parse_standard_info(content: bytes) -> dict[str, Any]:
    """Parse $STANDARD_INFORMATION attribute content."""
    if len(content) < 48:
        return {}
    try:
        created  = struct.unpack_from("<Q", content, 0)[0]
        modified = struct.unpack_from("<Q", content, 8)[0]
        mft_mod  = struct.unpack_from("<Q", content, 16)[0]
        accessed = struct.unpack_from("<Q", content, 24)[0]
        flags    = struct.unpack_from("<I", content, 32)[0]
        return {
            "created":  _filetime_to_dt(created),
            "modified": _filetime_to_dt(modified),
            "mft_mod":  _filetime_to_dt(mft_mod),
            "accessed": _filetime_to_dt(accessed),
            "flags":    flags,
        }
    except struct.error:
        return {}


def _parse_file_name(content: bytes) -> dict[str, Any]:
    """Parse $FILE_NAME attribute content."""
    if len(content) < 66:
        return {}
    try:
        parent_ref  = struct.unpack_from("<Q", content, 0)[0] & 0xFFFFFFFFFFFF
        created     = struct.unpack_from("<Q", content, 8)[0]
        modified    = struct.unpack_from("<Q", content, 16)[0]
        mft_mod     = struct.unpack_from("<Q", content, 24)[0]
        accessed    = struct.unpack_from("<Q", content, 32)[0]
        alloc_size  = struct.unpack_from("<Q", content, 40)[0]
        real_size   = struct.unpack_from("<Q", content, 48)[0]
        flags       = struct.unpack_from("<I", content, 56)[0]
        namespace   = content[65]
        name_len    = content[64]
        name_bytes  = content[66: 66 + name_len * 2]
        try:
            name = name_bytes.decode("utf-16-le", errors="replace")
        except Exception:
            name = ""
        return {
            "parent_ref": parent_ref,
            "created":    _filetime_to_dt(created),
            "modified":   _filetime_to_dt(modified),
            "accessed":   _filetime_to_dt(accessed),
            "alloc_size": alloc_size,
            "real_size":  real_size,
            "flags":      flags,
            "namespace":  namespace,
            "name":       name,
        }
    except struct.error:
        return {}


def _parse_mft_entry(raw: bytes, entry_no: int) -> Optional[dict[str, Any]]:
    """
    Parse one 1024-byte MFT entry. Returns a dict or None if invalid.
    """
    if len(raw) < _MFT_ENTRY_SZ:
        return None
    if raw[:4] != _MFT_SIGNATURE:
        return None
    try:
        seq_number    = struct.unpack_from("<H", raw, 16)[0]
        link_count    = struct.unpack_from("<H", raw, 18)[0]
        first_attr_off = struct.unpack_from("<H", raw, 20)[0]
        flags         = struct.unpack_from("<H", raw, 22)[0]
        is_directory  = bool(flags & 0x02)
        is_deleted    = not bool(flags & 0x01)
        used_size     = struct.unpack_from("<I", raw, 24)[0]
    except struct.error:
        return None

    # Apply NTFS fixup array
    try:
        fixup_off   = struct.unpack_from("<H", raw, 4)[0]
        fixup_count = struct.unpack_from("<H", raw, 6)[0]
        if fixup_off + fixup_count * 2 < len(raw):
            fixup_val = raw[fixup_off: fixup_off + 2]
            data = bytearray(raw)
            for i in range(1, fixup_count):
                sector_end = i * 512 - 2
                if sector_end + 2 <= len(data):
                    data[sector_end: sector_end + 2] = raw[fixup_off + i * 2: fixup_off + i * 2 + 2]
            raw = bytes(data)
    except (struct.error, ValueError):
        pass

    # Walk attributes
    std_info: dict[str, Any] = {}
    file_name: dict[str, Any] = {}
    has_data = False

    offset = first_attr_off
    while offset < min(used_size, _MFT_ENTRY_SZ - 8):
        attr = _parse_attribute(raw, offset)
        if attr is None:
            break
        if attr["attr_type"] == 0xFFFFFFFF:
            break

        atype = attr["attr_type"]
        if atype == _ATTR_TYPE_STANDARD_INFO and not attr["non_resident"]:
            std_info = _parse_standard_info(attr["content"])
        elif atype == _ATTR_TYPE_FILE_NAME and not attr["non_resident"]:
            fn = _parse_file_name(attr["content"])
            # Prefer Win32 or DOS+Win32 namespace names
            if fn and fn.get("name"):
                if not file_name or fn.get("namespace") in (_NAMESPACE_WIN32, _NAMESPACE_DOS_WIN32):
                    file_name = fn
        elif atype == _ATTR_TYPE_DATA:
            has_data = True

        offset += attr["attr_len"]

    if not file_name.get("name"):
        return None

    return {
        "entry_no":    entry_no,
        "is_directory": is_directory,
        "is_deleted":  is_deleted,
        "name":        file_name.get("name", ""),
        "parent_ref":  file_name.get("parent_ref", 0),
        "size_bytes":  file_name.get("real_size", 0),
        "created":     std_info.get("created") or file_name.get("created"),
        "modified":    std_info.get("modified") or file_name.get("modified"),
        "accessed":    std_info.get("accessed") or file_name.get("accessed"),
        "flags":       file_name.get("flags", 0),
        "has_data":    has_data,
        "seq_number":  seq_number,
        "link_count":  link_count,
    }


def parse_mft(image_path: str, ntfs_info: dict[str, Any],
              max_entries: int = _MAX_FILES) -> list[dict[str, Any]]:
    """
    Read and parse MFT entries from the NTFS volume, up to max_entries.

    Returns a list of file-entry dicts with path, size, timestamps, etc.
    """
    mft_offset = ntfs_info["mft_offset"]
    cluster_size = ntfs_info["cluster_size"]
    part_offset  = ntfs_info["partition_offset"]
    image_size   = os.path.getsize(image_path)

    entries: dict[int, dict[str, Any]] = {}
    entry_no = 0

    logger.info("Parsing MFT (start offset=0x%X, cluster_size=%d)…",
                mft_offset, cluster_size)

    with open(image_path, "rb") as f:
        while max_entries <= 0 or entry_no < max_entries * 2:   # zero means exhaustive until MFT boundary
            offset = mft_offset + entry_no * _MFT_ENTRY_SZ
            if offset + _MFT_ENTRY_SZ > image_size:
                break
            f.seek(offset)
            raw = f.read(_MFT_ENTRY_SZ)
            if not raw or len(raw) < _MFT_ENTRY_SZ:
                break
            # Stop if we've gone past the MFT into unrelated data
            if entry_no > 0 and raw[:4] != _MFT_SIGNATURE:
                logger.debug("MFT signature missing at entry %d — stopping MFT walk", entry_no)
                break

            parsed = _parse_mft_entry(raw, entry_no)
            if parsed:
                entries[entry_no] = parsed

            entry_no += 1

    logger.info("Parsed %d valid MFT entries", len(entries))

    # Build path lookup (best-effort; no recursive parent resolution)
    # For simplicity, we just use the file name without full path reconstruction
    result = []
    for eno, entry in sorted(entries.items()):
        # Directories are addressable filesystem objects and remain in the
        # exhaustive listing even when they have no ordinary DATA attribute.
        name = entry.get("name", "")
        if not name or name in (".", ".."):
            continue
        # Determine extension
        ext = Path(name).suffix.lstrip(".").lower() if "." in name else ""
        result.append({
            "entry_no":  eno,
            "path":      name,     # simplified: just filename without full path
            "extension": ext,
            "size_bytes": entry.get("size_bytes", 0),
            "created":   entry.get("created"),
            "modified":  entry.get("modified"),
            "accessed":  entry.get("accessed"),
            "deleted":   entry.get("is_deleted", False),
            "is_directory": bool(entry.get("is_directory", False)),
            "flags":     entry.get("flags", 0),
            "sha256":    "",       # not computed for all files (performance)
        })
        if max_entries > 0 and len(result) >= max_entries:
            break

    logger.info("MFT filesystem listing: %d file/directory entries", len(result))
    return result


# ---------------------------------------------------------------------------
# String / IOC extraction
# ---------------------------------------------------------------------------

_RE_IPV4    = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b")
_RE_URL     = re.compile(r"https?://[^\s<>\"{}|\\^`\[\]]{4,255}|ftp://[^\s<>\"{}|\\^`\[\]]{4,255}")
_RE_EMAIL   = re.compile(r"\b[a-zA-Z0-9._%+\-]{1,64}@[a-zA-Z0-9.\-]{1,253}\.[a-zA-Z]{2,}\b")
_RE_REGKEY  = re.compile(
    r"(?:HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|"
    r"HKEY_USERS|HKEY_CURRENT_CONFIG|HKLM|HKCU)\\[^\r\n\t\"]{1,300}",
    re.IGNORECASE,
)
_RE_BITCOIN = re.compile(r"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b")
_RE_ETH     = re.compile(r"\b0x[a-fA-F0-9]{40}\b")

_PRIVATE_PREFIXES = ("10.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
                     "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.",
                     "172.27.", "172.28.", "172.29.", "172.30.", "172.31.", "192.168.",
                     "127.", "169.254.", "0.", "255.")


def extract_strings_ioc(image_path: str, max_mb: int = 0) -> dict[str, list[str]]:
    """Extract literal IOC-shaped values from the complete image by default.

    ``max_mb <= 0`` means exhaustive byte coverage. A positive value is an
    explicit caller safety cap. Printable runs that cross chunk boundaries are
    carried into the next chunk so boundary placement cannot silently hide a
    match.
    """
    if max_mb > 0:
        logger.info("Extracting strings from configured first %d MB of image…", max_mb)
    else:
        logger.info("Extracting strings across the complete image…")
    results: dict[str, set[str]] = {
        "ipv4": set(), "url": set(), "email": set(),
        "registry_key": set(), "bitcoin": set(), "ethereum": set(),
    }
    image_size = os.path.getsize(image_path)
    max_bytes = min(image_size, max_mb * 1024 * 1024) if max_mb > 0 else image_size
    processed = 0
    carry = b""

    def consume(printable_bytes: bytes) -> None:
        text = printable_bytes.decode("ascii", errors="ignore")
        for m in _RE_IPV4.finditer(text):
            ip = m.group()
            if not any(ip.startswith(p) for p in _PRIVATE_PREFIXES):
                results["ipv4"].add(ip)
        for m in _RE_URL.finditer(text):
            results["url"].add(m.group())
        for m in _RE_EMAIL.finditer(text):
            em = m.group()
            if "." in em.split("@")[-1]:
                results["email"].add(em)
        for m in _RE_REGKEY.finditer(text):
            results["registry_key"].add(m.group())
        for m in _RE_BITCOIN.finditer(text):
            results["bitcoin"].add(m.group())
        for m in _RE_ETH.finditer(text):
            results["ethereum"].add(m.group())

    with open(image_path, "rb") as f:
        while processed < max_bytes:
            chunk = f.read(min(_STRING_CHUNK, max_bytes - processed))
            if not chunk:
                break
            processed += len(chunk)
            data = carry + chunk
            # Retain only a trailing printable run for the next chunk. Everything
            # before it is complete and can be searched exactly once now.
            match = re.search(rb"[ -~]+$", data)
            if match and match.start() > 0:
                complete = data[:match.start()]
                carry = data[match.start():]
            elif match and match.start() == 0:
                complete = b""
                carry = data
            else:
                complete = data
                carry = b""
            for literal in re.findall(rb"[ -~]{%d,}" % _STRING_MIN, complete):
                consume(literal)
        if carry and len(carry) >= _STRING_MIN:
            consume(carry)

    return {key: sorted(values) for key, values in results.items()}


def generate_findings(
    file_listing: list[dict[str, Any]],
    ioc: dict[str, list[str]],
    ntfs_info: Optional[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Generate structured findings from file listing and IOC results."""
    findings = []
    now = datetime.now(timezone.utc).isoformat()

    # Finding: executable files in the image
    executables = [f for f in file_listing if f.get("extension", "") in
                   ("exe", "dll", "sys", "drv", "bat", "cmd", "ps1", "vbs", "js")]
    if executables:
        findings.append({
            "type":        "EXECUTABLE_FILES_FOUND",
            "severity":    "high",
            "category":    "Malware / Suspicious Files",
            "description": (
                f"The disk image contains {len(executables)} executable file(s) "
                f"in the MFT file system. These include: "
                f"{', '.join(e['path'] for e in executables[:10])}."
                + (f" (and {len(executables)-10} more)" if len(executables) > 10 else "")
            ),
            "location":    "NTFS MFT",
            "raw_data":    json.dumps([e["path"] for e in executables[:20]]),
            "recommendation": (
                "Analyse each executable file to determine whether it represents "
                "malware, a legitimate system utility, or a tool relevant to "
                "the investigation."
            ),
            "timestamp":   now,
        })

    # Finding: deleted files
    deleted = [f for f in file_listing if f.get("deleted")]
    if deleted:
        findings.append({
            "type":        "DELETED_FILES_FOUND",
            "severity":    "medium",
            "category":    "Deleted File Recovery",
            "description": (
                f"The NTFS MFT contains {len(deleted)} deleted file record(s) "
                f"whose MFT entries are still present. Sample filenames: "
                f"{', '.join(d['path'] for d in deleted[:10])}."
            ),
            "location":    "NTFS MFT — deleted entries",
            "raw_data":    json.dumps([d["path"] for d in deleted[:20]]),
            "recommendation": (
                "Attempt to recover the data content of deleted files using "
                "file carving or inode-level extraction tools."
            ),
            "timestamp":   now,
        })

    # Finding: suspicious URLs
    suspicious_urls = [u for u in ioc.get("url", []) if any(
        kw in u.lower() for kw in ("pastebin", "raw.github", "transfer.sh", "ngrok",
                                   "bit.ly", "tinyurl", "onion", "tor2web", "darknet")
    )]
    if suspicious_urls:
        findings.append({
            "type":        "SUSPICIOUS_URLS_FOUND",
            "severity":    "high",
            "category":    "IOC / String Match",
            "description": (
                f"String extraction identified {len(suspicious_urls)} potentially "
                f"suspicious URL(s) embedded in the disk image: "
                f"{', '.join(suspicious_urls[:5])}."
            ),
            "location":    "Disk image — string extraction",
            "raw_data":    json.dumps(suspicious_urls[:10]),
            "recommendation": (
                "Investigate each suspicious URL to determine whether it is "
                "associated with malware command-and-control, data exfiltration, "
                "or other malicious activity."
            ),
            "timestamp":   now,
        })

    # Finding: external IP addresses
    ext_ips = ioc.get("ipv4", [])
    if ext_ips:
        findings.append({
            "type":        "EXTERNAL_IP_ADDRESSES_FOUND",
            "severity":    "medium",
            "category":    "IOC / String Match",
            "description": (
                f"String extraction identified {len(ext_ips)} unique external "
                f"IPv4 address(es) embedded in the disk image. "
                f"Sample: {', '.join(ext_ips[:8])}."
            ),
            "location":    "Disk image — string extraction",
            "raw_data":    json.dumps(ext_ips[:20]),
            "recommendation": (
                "Cross-reference each IP address against threat intelligence "
                "databases to identify known malicious infrastructure."
            ),
            "timestamp":   now,
        })

    # Finding: email addresses
    emails = ioc.get("email", [])
    if emails:
        findings.append({
            "type":        "EMAIL_ADDRESSES_FOUND",
            "severity":    "low",
            "category":    "IOC / String Match",
            "description": (
                f"String extraction identified {len(emails)} email address(es) "
                f"embedded in the disk image. "
                f"Sample: {', '.join(emails[:5])}."
            ),
            "location":    "Disk image — string extraction",
            "raw_data":    json.dumps(emails[:20]),
            "recommendation": (
                "Review identified email addresses to determine their relevance "
                "to the investigation; cross-reference with known suspect accounts."
            ),
            "timestamp":   now,
        })

    # Finding: registry key paths
    reg_keys = ioc.get("registry_key", [])
    if reg_keys:
        findings.append({
            "type":        "REGISTRY_KEY_PATHS_FOUND",
            "severity":    "low",
            "category":    "IOC / String Match",
            "description": (
                f"String extraction identified {len(reg_keys)} Windows Registry "
                f"key path(s) embedded in the disk image. "
                f"Sample: {', '.join(reg_keys[:3])}."
            ),
            "location":    "Disk image — string extraction",
            "raw_data":    json.dumps(reg_keys[:20]),
            "recommendation": (
                "Review registry key paths for persistence mechanisms, "
                "autorun entries, or references to malware-associated keys."
            ),
            "timestamp":   now,
        })

    # Finding: NTFS volume info
    if ntfs_info:
        vol_size_mb = ntfs_info.get("volume_size_bytes", 0) / 1024 / 1024
        findings.append({
            "type":        "NTFS_VOLUME_IDENTIFIED",
            "severity":    "low",
            "category":    "Disk Analysis",
            "description": (
                f"An NTFS volume was identified at partition offset "
                f"{ntfs_info.get('partition_offset', 0)} bytes. "
                f"Volume size: {vol_size_mb:.1f} MB, "
                f"cluster size: {ntfs_info.get('cluster_size', 0)} bytes, "
                f"serial number: {ntfs_info.get('volume_serial', 'N/A')}."
            ),
            "location":    f"NTFS VBR at offset {ntfs_info.get('partition_offset', 0)}",
            "raw_data":    json.dumps({
                k: v for k, v in ntfs_info.items()
                if k not in ("mft_offset",)
            }),
            "recommendation": "Verify volume integrity and check for anti-forensic indicators.",
            "timestamp":   now,
        })

    return findings


# ---------------------------------------------------------------------------
# Main analysis function
# ---------------------------------------------------------------------------

def _detect_filesystem(image_path: str) -> tuple[Optional[dict], int]:
    """
    Auto-detect the filesystem type at offset 0 (direct filesystem image).
    Returns (bpb_dict, part_offset) or (None, 0) if unrecognised.
    """
    with open(image_path, "rb") as f:
        vbr = f.read(512)

    # Try FAT at offset 0
    bpb = detect_fat(vbr)
    if bpb:
        logger.info("Detected %s filesystem at image offset 0", bpb["fat_type"])
        return bpb, 0

    # Try NTFS at offset 0
    if vbr[3:11] == _NTFS_MAGIC:
        logger.info("Detected NTFS filesystem at image offset 0 (no partition table)")
        return None, 0   # handled by find_ntfs_partitions

    # Try after reading as a partitioned disk
    mbr = parse_mbr(image_path)
    for part in mbr.get("partitions", []):
        off = part["byte_offset"]
        if off == 0:
            continue
        try:
            with open(image_path, "rb") as f:
                f.seek(off)
                vbr2 = f.read(512)
            bpb2 = detect_fat(vbr2)
            if bpb2:
                logger.info("Detected %s in partition %d at offset %d",
                            bpb2["fat_type"], part["index"], off)
                return bpb2, off
        except OSError:
            continue

    return None, 0


def analyze(image_path: str, case_id: str, output_dir: str) -> None:
    """
    Run the full disk image analysis and write output JSON files.

    Parameters
    ----------
    image_path  : Absolute path to the raw disk image.
    case_id     : Case identifier (used in output metadata).
    output_dir  : Directory where disk_analysis.json and evidence_info.json
                  are written.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    now_iso = datetime.now(timezone.utc).isoformat()

    # 1. Hash image
    hash_info = hash_image(image_path)

    # 2. Detect filesystem type
    bpb, part_offset = _detect_filesystem(image_path)

    file_listing:     list[dict[str, Any]] = []
    fs_info_report:   dict[str, Any] = {}
    ntfs_volumes:     list[dict[str, Any]] = []

    if bpb:
        # FAT filesystem — parse directory tree
        fs_info_report = {
            "Filesystem type":    bpb["fat_type"],
            "Volume label":       bpb.get("volume_label", ""),
            "Volume serial ID":   bpb.get("volume_id", ""),
            "Bytes per sector":   str(bpb["bytes_per_sector"]),
            "Cluster size":       f"{bpb['cluster_size']} bytes",
            "Total sectors":      str(bpb["total_sectors"]),
            "Volume size":        f"{bpb['total_sectors'] * bpb['bytes_per_sector'] / 1024 / 1024:.1f} MB",
            "Total clusters":     str(bpb["total_clusters"]),
            "Image offset":       str(part_offset),
        }
        try:
            file_listing = parse_fat_volume(image_path, bpb, part_offset)
            logger.info("Hashing extracted files…")
            file_listing = save_fat_files(image_path, bpb, file_listing, out, part_offset)
        except Exception as exc:
            logger.warning("FAT parsing failed: %s", exc)
    else:
        # Try NTFS
        try:
            mbr = parse_mbr(image_path)
            ntfs_volumes = find_ntfs_partitions(image_path, mbr)
            if ntfs_volumes:
                primary = ntfs_volumes[0]
                fs_info_report = {
                    "Filesystem type":    "NTFS",
                    "Volume at offset":   str(primary["partition_offset"]),
                    "Cluster size":       f"{primary['cluster_size']} bytes",
                    "Volume size":        f"{primary['volume_size_bytes']/1024/1024:.1f} MB",
                    "Volume serial":      primary["volume_serial"],
                    "MFT offset":         str(primary["mft_offset"]),
                }
                file_listing = parse_mft(image_path, primary)
        except Exception as exc:
            logger.warning("NTFS/MBR parsing failed: %s", exc)

    # 3. Extract strings / IOCs
    ioc = extract_strings_ioc(image_path, max_mb=0)
    logger.info("IOC summary: %s", {k: len(v) for k, v in ioc.items()})

    # 4. Generate findings
    findings = generate_findings(
        file_listing, ioc, ntfs_volumes[0] if ntfs_volumes else None
    )
    # Add FAT-specific findings
    if bpb:
        findings.append({
            "type":        "FAT_FILESYSTEM_IDENTIFIED",
            "severity":    "low",
            "category":    "Disk Analysis",
            "description": (
                f"A {bpb['fat_type']} filesystem was identified at image offset {part_offset}. "
                f"Volume label: '{bpb.get('volume_label', 'NO NAME')}', "
                f"serial: {bpb.get('volume_id', 'N/A')}, "
                f"cluster size: {bpb['cluster_size']} bytes, "
                f"total clusters: {bpb['total_clusters']}."
            ),
            "location":    f"FAT VBR at image offset {part_offset}",
            "raw_data":    json.dumps({k: v for k, v in bpb.items()
                                      if k not in ("root_dir_offset", "fat_offset")}),
            "recommendation": "Verify volume integrity and check for anti-forensic indicators.",
            "timestamp":   now_iso,
        })

        # Finding: JPEG images
        images = [f for f in file_listing if f.get("extension", "").lower() in ("jpg", "jpeg", "png", "gif", "bmp")]
        if images:
            findings.append({
                "type":        "IMAGE_FILES_FOUND",
                "severity":    "medium",
                "category":    "Media / Document Analysis",
                "description": (
                    f"The FAT volume contains {len(images)} image file(s): "
                    f"{', '.join(e['path'] for e in images[:5])}. "
                    f"Image files may contain EXIF metadata including GPS coordinates, "
                    f"device information, and original capture timestamps. "
                    f"Total size: {sum(e.get('size_bytes',0) for e in images):,} bytes."
                ),
                "location":    f"{bpb['fat_type']} volume root directory",
                "raw_data":    json.dumps([
                    {"path": e["path"], "size": e["size_bytes"],
                     "modified": e.get("modified", ""), "sha256": e.get("sha256", "")}
                    for e in images
                ]),
                "recommendation": (
                    "Examine EXIF metadata of all image files for GPS location data, "
                    "device serial numbers, and capture timestamps that may corroborate "
                    "or contradict the suspect's account of events."
                ),
                "timestamp":   now_iso,
            })

        # Finding: suspicious or unusual files
        unusual = [f for f in file_listing
                   if f.get("extension", "") not in ("jpg","jpeg","png","gif","bmp","txt","doc",
                                                      "docx","pdf","xls","xlsx","zip","mp3","mp4")
                   and f.get("size_bytes", 0) > 0]
        if unusual:
            findings.append({
                "type":        "UNUSUAL_FILE_TYPES_FOUND",
                "severity":    "high",
                "category":    "Suspicious Files",
                "description": (
                    f"The FAT volume contains {len(unusual)} file(s) with unusual "
                    f"or unknown extensions: "
                    f"{', '.join(e['path'] for e in unusual[:5])}. "
                    f"These files may represent disguised malware, encrypted data, "
                    f"or proprietary file formats."
                ),
                "location":    f"{bpb['fat_type']} volume",
                "raw_data":    json.dumps([
                    {"path": e["path"], "size": e["size_bytes"],
                     "sha256": e.get("sha256", "")}
                    for e in unusual[:10]
                ]),
                "recommendation": (
                    "Determine the true file type of each unusual file using "
                    "magic-byte analysis (e.g., file(1) or TrID) and examine "
                    "content for forensic significance."
                ),
                "timestamp":   now_iso,
            })

    # 5. Build output document
    output = {
        "module":            "Disk Image Analysis",
        "case_id":           case_id,
        "generated_at":      now_iso,
        "image_path":        image_path,
        "image_size_bytes":  hash_info["image_size_bytes"],
        "image_md5":         hash_info["image_md5"],
        "image_sha256":      hash_info["image_sha256"],
        "filesystem_type":   bpb["fat_type"] if bpb else ("NTFS" if ntfs_volumes else "Unknown"),
        "partition_table":   [],   # no MBR partition table in a direct filesystem image
        "ntfs_info":         fs_info_report,   # reuse ntfs_info field for display
        "ntfs_volumes_found": len(ntfs_volumes),
        "file_listing":      file_listing,
        "strings_ioc":       ioc,
        "findings":          findings,
        "summary": (
            f"Analyzed {hash_info['image_size_bytes']/1024/1024:.1f} MB disk image; "
            f"filesystem: {bpb['fat_type'] if bpb else 'NTFS' if ntfs_volumes else 'Unknown'}; "
            f"{len(file_listing)} files; "
            f"{len(findings)} finding(s)."
        ),
    }

    out_path = out / "disk_analysis.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=True, default=str)
    logger.info("Wrote disk_analysis.json: %s", out_path)

    # 6. Write evidence_info.json
    from datetime import date
    evidence = {
        "exhibit_number":     "EX-001",
        "description":        f"Raw disk image: {Path(image_path).name} "
                              f"({bpb['fat_type'] if bpb else 'NTFS'} filesystem, "
                              f"{hash_info['image_size_bytes']/1024/1024:.1f} MB)",
        "acquisition_date":   date.today().isoformat(),
        "acquisition_method": "Pre-existing/read-only logical media supplied for analysis; acquisition provenance maintained by the parent case",
        "tool_used":          "AutoForensics Disk Analyzer",
        "tool_version":       "1.0",
        "md5_hash":           hash_info["image_md5"],
        "sha256_hash":        hash_info["image_sha256"],
        "source_size_bytes":  hash_info["image_size_bytes"],
        "image_size_bytes":   hash_info["image_size_bytes"],
        "acquired_by":        "AutoForensics",
        "analysis_stream_hashed": True,
        "verified":           False,
        "notes":              (
            f"Image analyzed on {now_iso}. "
            f"Filesystem: {bpb['fat_type'] if bpb else 'NTFS'}. "
            f"Volume label: '{bpb.get('volume_label', 'N/A') if bpb else 'N/A'}'. "
            f"{len(file_listing)} files recovered from directory structure. "
            f"Files extracted to {out / 'extracted_files'}."
        ),
    }
    ev_path = out / "evidence_info.json"
    with open(ev_path, "w", encoding="utf-8") as f:
        json.dump(evidence, f, indent=2)
    logger.info("Wrote evidence_info.json: %s", ev_path)

    logger.info("Analysis complete. Summary: %s", output["summary"])
    print(f"\nAnalysis complete.")
    print(f"  Image:      {image_path}")
    print(f"  SHA-256:    {hash_info['image_sha256']}")
    print(f"  MD5:        {hash_info['image_md5']}")
    print(f"  Size:       {hash_info['image_size_bytes']/1024/1024:.1f} MB")
    print(f"  Filesystem: {bpb['fat_type'] if bpb else 'NTFS' if ntfs_volumes else 'Unknown'}")
    print(f"  Files:      {len(file_listing)}")
    print(f"  Findings:   {len(findings)}")
    for fi in file_listing:
        print(f"    {fi['size_bytes']:>10,} bytes  {fi.get('modified','')[:19]}  {fi['path'].encode('ascii','replace').decode()}")
    print(f"  Output:     {out_path}")
    print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="AutoForensics pure-Python disk image analyzer",
    )
    p.add_argument(
        "--image", "-i", required=True,
        help="Path to the raw disk image (.dd, .img, .raw)",
    )
    p.add_argument(
        "--case-id", "-c", default="CASE",
        help="Case identifier (default: CASE)",
    )
    p.add_argument(
        "--output", "-o", required=True,
        help="Output directory for disk_analysis.json and evidence_info.json",
    )
    return p


if __name__ == "__main__":
    args = _build_parser().parse_args()
    try:
        analyze(
            image_path=args.image,
            case_id=args.case_id,
            output_dir=args.output,
        )
    except KeyboardInterrupt:
        logger.info("Interrupted.")
        sys.exit(1)
    except Exception as exc:
        logger.error("Analysis failed: %s", exc, exc_info=True)
        sys.exit(1)
