#!/usr/bin/env python3
"""Fail-closed capability gate for proposal-defined forensic domains.

The gate reports IMPLEMENTED only when the registered module imports and its
required runtime dependency is available. It does not turn missing tooling into
a clean forensic result.
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

CAPABILITIES: dict[str, dict[str, Any]] = {
    "disk": {
        "modules": ["evidence_validator","ewf_metadata","filesystem_analyzer","deleted_file_recovery","native_signature_carver","file_signature_analyzer"],
        "commands": ["fls", "mmls", "icat"], "python": ["reportlab","pypdf"],
    },
    "memory": {
        "modules": ["memory_process_list","memory_network_connections","memory_artifact_extractor","memory_malware_scanner","memory_string_analyzer","rootkit_detector"],
        "commands": [], "python": [], "special": "volatility",
    },
    "network": {
        "modules": ["pcap_analyzer","network_protocol_decoder","dns_analyzer","http_reconstructor"],
        "commands": ["tshark"], "python": ["scapy"],
    },
    "malware": {
        "modules": ["yara_scanner","clamav_scanner","native_malware_scanner","suspicious_file_detector"],
        "commands": ["yara","clamscan"], "python": ["yara"],
    },
    "carving": {
        "modules": ["native_signature_carver","foremost_carver","scalpel_carver"],
        "commands": ["foremost","scalpel"], "python": [],
    },
    "metadata_document": {
        "modules": ["exiftool_metadata","ocr_text_extractor","document_analyzer","geolocation_extractor"],
        "commands": ["exiftool","tesseract","pdftotext"], "python": ["PIL"],
        "optional_python": ["oletools"],
    },
    "password": {
        "modules": ["hashcat_recovery","john_recovery"],
        "commands": ["hashcat","john"], "python": [],
    },
    "steganography": {
        "modules": ["steganography_detector"],
        "commands": ["steghide"], "optional_commands": ["stegseek", "zsteg", "outguess"],
        "python": ["PIL"],
    },
    "mobile": {
        "modules": ["mobile_analyzer"],
        "commands": [], "python": [], "special": "leapp",
    },
    "report_signing": {
        "modules": [], "commands": [], "python": ["cryptography"],
    },
}

PROFILES={
    "disk":["disk","malware","carving","metadata_document","password","steganography","report_signing"],
    "memory":["memory","malware","report_signing"],
    "network":["network","malware","report_signing"],
    "mobile":["mobile","metadata_document","malware","report_signing"],
    "full":list(CAPABILITIES),
}
_ALLOW_SYNTHETIC_CLAMAV_DB = False



def _volatility_path() -> str:
    configured=os.environ.get("VOLATILITY3_PATH","").strip()
    candidates=[
        configured,
        shutil.which("vol") or "",
        shutil.which("vol.py") or "",
        "/opt/volatility3/vol.py",
        "/usr/local/bin/vol",
        "/usr/local/bin/vol.py",
    ]
    path=next((str(Path(x).expanduser()) for x in candidates if x and Path(x).is_file()),"")
    if path:
        return path
    try:
        importlib.import_module("volatility3.cli")
        return f"{sys.executable} -m volatility3.cli"
    except Exception:
        return ""


def _leapp_paths() -> dict[str,str]:
    def find(env:str,names:list[str],paths:list[str])->str:
        c=os.environ.get(env,"").strip()
        values=[c,*[shutil.which(n) or "" for n in names],*paths]
        return next((str(Path(x).expanduser()) for x in values if x and Path(x).is_file()),"")
    return {
        "aleapp":find("ALEAPP_PATH",["aleapp"],["/opt/ALEAPP/aleapp.py","/opt/aleapp/aleapp.py"]),
        "ileapp":find("ILEAPP_PATH",["ileapp"],["/opt/iLEAPP/ileapp.py","/opt/ileapp/ileapp.py"]),
    }


def inspect_capability(name:str)->dict[str,Any]:
    spec=CAPABILITIES[name]; failures=[]; details=[]
    for mod in spec.get("modules",[]):
        try: importlib.import_module(f"modules.{mod}"); details.append(f"module:{mod}=OK")
        except Exception as exc: failures.append(f"module {mod}: {exc}")
    for cmd in spec.get("commands",[]):
        path=shutil.which(cmd)
        if path: details.append(f"command:{cmd}={path}")
        else: failures.append(f"command missing: {cmd}")
    for cmd in spec.get("optional_commands",[]):
        path=shutil.which(cmd)
        if path: details.append(f"optional_command:{cmd}={path}")
        else: details.append(f"optional_command:{cmd}=UNAVAILABLE")
    if name == "malware" and shutil.which("clamscan"):
        configured_db = os.environ.get("CLAMAV_DB_PATH", "").strip()
        official = Path(configured_db).expanduser() if configured_db else Path("/var/lib/clamav")
        db_suffixes = {".cvd", ".cld", ".cud", ".hdb", ".hsb", ".mdb", ".msb", ".ndb", ".ldb", ".cbc", ".cdb"}
        official_files = [p for p in official.glob("*") if p.is_file() and p.suffix.lower() in db_suffixes and p.stat().st_size > 0] if official.is_dir() else []
        if official_files:
            details.append(f"clamav_database={official} ({len(official_files)} official/configured file(s))")
        else:
            bundled = ROOT / "config" / "clamav" / "synthetic_validation.ndb"
            if _ALLOW_SYNTHETIC_CLAMAV_DB and bundled.is_file() and bundled.stat().st_size > 0:
                details.append(f"clamav_database={bundled} (EICAR-only synthetic validation scope)")
            else:
                failures.append(f"Official/configured ClamAV signature database missing or empty: {official}")
    for pkg in spec.get("python",[]):
        try: importlib.import_module(pkg); details.append(f"python:{pkg}=OK")
        except Exception as exc: failures.append(f"python package {pkg}: {exc}")
    for pkg in spec.get("optional_python",[]):
        try: importlib.import_module(pkg); details.append(f"optional_python:{pkg}=OK")
        except Exception: details.append(f"optional_python:{pkg}=UNAVAILABLE")
    if spec.get("special")=="volatility":
        path=_volatility_path()
        if path: details.append(f"volatility={path}")
        else: failures.append("Volatility 3 entry point not found")
    if spec.get("special")=="leapp":
        paths=_leapp_paths()
        for key,path in paths.items():
            if path: details.append(f"{key}={path}")
            else: failures.append(f"{key} entry point not found")
    return {"capability":name,"ready":not failures,"details":details,"failures":failures}


def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile',choices=sorted(PROFILES),default='full')
    p.add_argument('--json-output',type=Path)
    p.add_argument('--strict',action='store_true',help='Return non-zero if any requested capability is unavailable.')
    p.add_argument('--allow-synthetic-clamav-db', action='store_true',
                   help='Permit the bundled EICAR-only ClamAV signature for controlled synthetic validation.')
    a=p.parse_args()
    global _ALLOW_SYNTHETIC_CLAMAV_DB
    _ALLOW_SYNTHETIC_CLAMAV_DB = bool(a.allow_synthetic_clamav_db)
    results=[inspect_capability(x) for x in PROFILES[a.profile]]
    report={"profile":a.profile,"ready":all(x['ready'] for x in results),"capabilities":results}
    if a.json_output:
        a.json_output.parent.mkdir(parents=True,exist_ok=True)
        a.json_output.write_text(json.dumps(report,indent=2)+"\n",encoding='utf-8')
    for r in results:
        print(f"[{'PASS' if r['ready'] else 'FAIL'}] {r['capability']}")
        for f in r['failures']: print(f"       {f}")
    print("CAPABILITY GATE PASSED" if report['ready'] else "CAPABILITY GATE FAILED")
    return 1 if a.strict and not report['ready'] else 0

if __name__=='__main__': raise SystemExit(main())
