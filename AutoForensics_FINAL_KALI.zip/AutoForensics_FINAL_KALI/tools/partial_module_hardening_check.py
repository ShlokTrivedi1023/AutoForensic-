#!/usr/bin/env python3
"""Deterministic checks for modules previously downgraded by optional-tool failures."""
from __future__ import annotations

import json
import logging
import tempfile
import zipfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from modules._base import ModuleStatus
import modules.document_analyzer as document
import modules.timeline_builder as timeline
import modules.image_content_analyzer as image_content
import modules.ocr_text_extractor as ocr
import modules.geolocation_extractor as geolocation
import modules.clamav_scanner as clamav

LOGGER = logging.getLogger("partial-hardening-check")
LOGGER.addHandler(logging.NullHandler())


def _fixture(root: Path) -> tuple[Path, Path, dict]:
    root.mkdir(parents=True, exist_ok=True)
    evidence = root / "fixture.E01"
    evidence.write_bytes(b"synthetic fixture container placeholder")
    extracted = root / "native" / "extracted"
    extracted.mkdir(parents=True)
    (extracted / "note.txt").write_text("fixture", encoding="utf-8")
    manifest = extracted.parent / "native_filesystem_manifest.json"
    manifest.write_text(json.dumps({
        "files": [
            {
                "path": "/note.txt", "name": "note.txt", "is_directory": False,
                "deleted": False, "size_bytes": 7, "first_cluster": 2,
                "created": "2026-01-01T10:00:00+00:00",
                "modified": "2026-01-01T10:01:00+00:00",
                "accessed": "2026-01-01T10:02:00+00:00",
            },
            {
                "path": "/deleted.txt", "name": "deleted.txt", "is_directory": False,
                "deleted": True, "size_bytes": 4, "first_cluster": 3,
                "created": "2026-01-01T09:00:00+00:00",
                "modified": "2026-01-01T09:05:00+00:00",
                "accessed": "2026-01-01T09:06:00+00:00",
                "recovery_status": "recoverable", "sha256": "00" * 32,
            },
        ]
    }), encoding="utf-8")
    config = {
        "partition_offset": 1,
        "analysis_path": str(evidence),
        "_working_set": {"extracted_files_dir": str(extracted)},
    }
    return evidence, extracted, config


def check_timeline(root: Path) -> None:
    evidence, _, config = _fixture(root / "timeline")
    original = timeline._run_subprocess
    timeline._run_subprocess = lambda *a, **k: (_ for _ in ()).throw(FileNotFoundError("fixture"))
    try:
        result = timeline.run(evidence, "CASE-TIMELINE", root / "timeline-out", config, LOGGER)
    finally:
        timeline._run_subprocess = original
    assert result.status == ModuleStatus.COMPLETED, result.errors
    assert result.statistics["authoritative_source"] == "native_filesystem_manifest"
    assert result.statistics["total_events"] >= 6


def check_document_native(root: Path) -> None:
    evidence, extracted, config = _fixture(root / "document")
    docx = extracted / "active.docm"
    with zipfile.ZipFile(docx, "w") as zf:
        zf.writestr("word/vbaProject.bin", b"VBA")
        zf.writestr("word/embeddings/oleObject1.bin", b"OLE")
        zf.writestr(
            "word/_rels/document.xml.rels",
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="x" Target="https://example.invalid/a" TargetMode="External"/>'
            '</Relationships>',
        )
    (extracted / "active.pdf").write_bytes(b"%PDF-1.4\n1 0 obj<</OpenAction 2 0 R /JavaScript 3 0 R>>endobj\n%%EOF")
    result = document.run(evidence, "CASE-DOCUMENT", root / "document-out", config, LOGGER)
    assert result.status == ModuleStatus.COMPLETED, result.errors
    kinds = {f.finding_type for f in result.findings}
    assert "MACRO_DETECTED" in kinds
    assert "EMBEDDED_OLE_OBJECT" in kinds
    assert "EXTERNAL_DOCUMENT_RELATIONSHIP" in kinds
    assert "SUSPICIOUS_PDF_ELEMENT" in kinds



def check_image_native_corpus(root: Path) -> None:
    evidence, extracted, config = _fixture(root / "image")
    picture = extracted / "picture.png"
    picture.write_bytes(b"P" * 256)
    original_fls = image_content._run_fls
    original_analyse = image_content._analyse_one_image
    def fake_fls(path, logger, errors, offset=0):
        errors.append("fls fixture unavailable")
        return []
    image_content._run_fls = fake_fls
    image_content._analyse_one_image = lambda path, label, logger: {
        "path": label, "local": str(path), "size": path.stat().st_size,
        "mime": "image/png", "ext": "png", "ocr_text": "",
        "doc_type": None, "gps": None, "exif": {}, "_b64_preview": "",
    }
    try:
        result = image_content.run(evidence, "CASE-IMAGE", root / "image-out", config, LOGGER)
    finally:
        image_content._run_fls = original_fls
        image_content._analyse_one_image = original_analyse
    assert result.status == ModuleStatus.COMPLETED, result.errors
    assert result.statistics["analyzed"] == 1
    assert not result.errors


def check_ocr_blank_is_complete(root: Path) -> None:
    evidence, extracted, config = _fixture(root / "ocr")
    try:
        from PIL import Image
        Image.new("RGB", (64, 64), "white").save(extracted / "blank.png")
    except ImportError:
        # Minimal valid 1x1 PNG fallback.
        import base64
        (extracted / "blank.png").write_bytes(base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZVfoAAAAASUVORK5CYII="
        ))
    original = ocr._ocr_image
    ocr._ocr_image = lambda img, logger, psm=3: ""
    try:
        result = ocr.run(evidence, "CASE-OCR", root / "ocr-out", config, LOGGER)
    finally:
        ocr._ocr_image = original
    assert result.status == ModuleStatus.COMPLETED, result.errors
    assert result.statistics["images_processed"] == 1
    assert result.statistics["images_no_text"] == 1
    assert result.statistics["images_failed"] == 0


def check_geolocation_outputs(root: Path) -> None:
    evidence, _, config = _fixture(root / "geo")
    parent = root / "geo-modules"
    meta_dir = parent / "metadata"
    out = parent / "geolocation"
    meta_dir.mkdir(parents=True)
    image_path = parent / "image & one.jpg"
    image_path.write_bytes(b"\xff\xd8\xff\xd9")
    (meta_dir / "metadata_report.json").write_text(json.dumps({
        "files": [{
            "SourceFile": str(image_path),
            "GPSLatitude": "51.5000", "GPSLongitude": "-0.1000",
            "GPSDateTime": "2026-01-01T00:00:00Z",
        }]
    }), encoding="utf-8")
    result = geolocation.run(evidence, "CASE-GEO", out, config, LOGGER)
    assert result.status == ModuleStatus.COMPLETED, result.errors
    assert len(result.artifact_paths) == 3
    assert "&amp;" in (out / "gps_locations.kml").read_text(encoding="utf-8")


def check_clamav_summary_parser(root: Path) -> None:
    parsed = clamav._parse_clamscan_summary(
        "Known viruses: 8,765,432\nScanned directories: 4\nScanned files: 27\n"
        "Infected files: 1\nData scanned: 12.45 MB\n"
    )
    assert parsed["known_viruses"] == 8765432
    assert parsed["scanned_files"] == 27
    assert parsed["infected_files"] == 1

def main() -> int:
    with tempfile.TemporaryDirectory(prefix="af_partial_check_") as tmp:
        root = Path(tmp)
        checks = [check_timeline, check_document_native,
                  check_image_native_corpus, check_ocr_blank_is_complete,
                  check_geolocation_outputs, check_clamav_summary_parser]
        for check in checks:
            check(root)
            print(f"[PASS] {check.__name__}")
    print("PARTIAL-MODULE HARDENING CHECK PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
