#!/usr/bin/env python3
"""Production release gate for AutoForensics.

The gate validates code/configuration and the report-assurance controls. It is
case-neutral and does not contain expected answers for any evidence fixture.
"""
from __future__ import annotations

import compileall
import importlib
import json
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def check(condition: bool, label: str) -> None:
    if not condition:
        raise AssertionError(label)
    print(f"[PASS] {label}")


def _valid_narrative(material: list[dict]) -> dict:
    fid = material[0]["id"]
    title = material[0]["title"]
    fw = {
        "WHO": {"answer": "No actor or ownership is established by the supplied technical artefacts.", "evidence_basis": [fid]},
        "WHAT": {"answer": "The examination identified one grouped filename and content-signature anomaly for review.", "evidence_basis": [fid]},
        "WHEN": {"answer": "No validated activity timestamp is supplied for this grouped material finding.", "evidence_basis": [fid]},
        "WHERE": {"answer": "The observation is located within the supplied evidence and its extracted filesystem content.", "evidence_basis": [fid]},
        "WHY": {"answer": "The evidence does not establish motive, purpose, concealment, or user intent.", "evidence_basis": [fid]},
        "HOW": {"answer": "The mismatch was identified by comparing the filename extension with verified file content.", "evidence_basis": [fid]},
    }
    conclusions = [
        {"text": "The examination identified a grouped file-signature anomaly within the supplied evidence. The observation is reported once even though more than one module may have detected the same underlying content, preventing duplicate detections from being presented as separate events.", "evidence_basis": [fid]},
        {"text": "The technical result establishes that the filename extension and the verified content type differ. It does not establish that the file was executed, that malware was present, or that a user selected the name for a particular purpose.", "evidence_basis": [fid]},
        {"text": "No actor, ownership, motive, or activity time can be attributed from this material finding alone. Any broader interpretation requires independent artefacts that identify a user, reliable chronology, and corroborating context from the examined evidence.", "evidence_basis": [fid]},
        {"text": "The report should therefore preserve the underlying file, its calculated hash, and the byte-level signature result. Examiner review must confirm the file structure and determine whether the object is functional content, a decoy, or a container with a misleading name.", "evidence_basis": [fid]},
    ]
    significance = {
        title: {
            "significance": "The mismatch is a useful triage result because it shows that the filename does not accurately describe the verified content type.",
            "evidential_limit": "The mismatch alone does not establish execution, malware, concealment, authorship, ownership, or user intent in the examined matter.",
            "evidence_basis": [fid],
        }
    }
    recommendations = [
        {"priority": "HIGH", "action": "Preserve the underlying object and record a fresh cryptographic hash before any further content examination.", "rationale": "A preserved and hashed copy provides a stable basis for repeatable byte-level validation and later examiner review.", "evidence_basis": [fid]},
        {"priority": "HIGH", "action": "Validate the complete file header, internal structure, and end markers using an independent parser or hex review.", "rationale": "A magic-byte match alone may be insufficient when a file is truncated, embedded, malformed, or deliberately constructed as a decoy.", "evidence_basis": [fid]},
        {"priority": "MEDIUM", "action": "Record whether the object is functional content, a text decoy, or a container carrying another file type.", "rationale": "This classification explains the practical meaning of the mismatch without inferring execution, ownership, or the reason for the filename.", "evidence_basis": [fid]},
        {"priority": "MEDIUM", "action": "Correlate the file only with independently verified timestamps and artefacts before adding it to an activity narrative.", "rationale": "Filename and content-type evidence does not supply reliable attribution or chronology by itself, so contextual correlation is required.", "evidence_basis": [fid]},
    ]
    return {
        "five_w_one_h": fw,
        "per_finding_significance": significance,
        "conclusions": conclusions,
        "recommendations": recommendations,
    }


def main() -> int:
    check(compileall.compile_dir(ROOT, quiet=1), "all Python files compile")

    import yaml
    registry = yaml.safe_load((ROOT / "config" / "modules.yaml").read_text())
    definitions = registry.get("modules") or {}
    profiles = registry.get("profiles") or {}
    check(bool(definitions), "module registry is non-empty")
    for name in definitions:
        check((ROOT / "modules" / f"{name}.py").is_file(), f"module file exists: {name}")
        importlib.import_module(f"modules.{name}")
    print(f"[PASS] imported {len(definitions)} registered modules")
    for profile_name, profile in profiles.items():
        missing = [m for m in (profile.get("modules") or []) if m not in definitions]
        check(not missing, f"profile references valid modules: {profile_name}")

    from core.module_completion import load_scope_contracts
    contracts = load_scope_contracts()
    check(set(contracts) == set(definitions), "all 45 registered modules have strict scope contracts")
    groups = {name: str(contract.get("baseline_group")) for name, contract in contracts.items()}
    check(sum(v == "FROZEN_VERIFIED" for v in groups.values()) == 37, "strict contract frozen group has 37 modules")
    check(sum(v == "TARGETED_REPAIR" for v in groups.values()) == 8, "strict contract targeted-repair group has 8 modules")
    check(sum(v == "SPECIALIST_INCOMPLETE" for v in groups.values()) == 0, "strict contract specialist-incomplete group has 0 modules")
    lock = json.loads((ROOT / "config" / "frozen_module_lock.json").read_text(encoding="utf-8"))
    check(len(lock.get("modules") or {}) == 37, "frozen-module lock protects 37 modules")
    verify_script = (ROOT / "verify_final.sh").read_text(encoding="utf-8")
    check("tools/strict_scope_gate.py" in verify_script, "final verification invokes the strict 45-module gate")

    help_run = subprocess.run(
        [sys.executable, str(ROOT / "run.py"), "--help"], cwd=ROOT,
        capture_output=True, text=True, timeout=30,
    )
    check(help_run.returncode == 0, "run.py --help succeeds")
    for flag in ("--case-file", "--report-only", "--require-llm", "--skip-check"):
        check(flag in help_run.stdout, f"CLI exposes {flag}")

    from core.main import _json_default, _setup_platform_logger

    class Example(Enum):
        VALUE = "value"

    encoded = json.dumps({
        "set": {"b", "a"}, "path": Path("/tmp/example"),
        "time": datetime(2026, 1, 1, tzinfo=timezone.utc),
        "enum": Example.VALUE, "bytes": b"\x00\xff",
    }, default=_json_default, sort_keys=True)
    decoded = json.loads(encoded)
    check(decoded["set"] == ["a", "b"], "set values serialise deterministically")
    check(decoded["bytes"]["value"] == "00ff", "byte values serialise explicitly")

    with tempfile.TemporaryDirectory() as td:
        logger = _setup_platform_logger(Path(td), "SELF-CHECK")
        check(logger.propagate is False, "platform logger propagation is disabled")
        check(len(logger.handlers) == 2, "platform logger has one console and one file handler")
        for handler in list(logger.handlers):
            handler.close()
        logger.handlers.clear()

    from core import report_ai
    from core.llm_provider import LLMUnavailable

    grouped = report_ai._build_material_findings([
        {"ref": "EX-001", "module": "file_signature_analyzer", "severity": "Medium",
         "title": "Extension mismatch", "detail": "The extension differs from the verified content signature.",
         "path": "evidence/file.bin", "category": "File Signature Anomaly"},
        {"ref": "EX-001", "module": "filesystem_deep_analyzer", "severity": "Medium",
         "title": "Extension mismatch", "detail": "The extension differs from the verified content signature.",
         "path": "evidence/file.bin", "category": "File Signature Anomaly"},
        {"ref": "EX-001", "module": "anti_forensic_detector", "severity": "High",
         "title": "Anti-Forensic Acts Table", "detail": "Aggregate presentation row.",
         "path": "", "category": "Anti-Forensics"},
    ])
    check(len(grouped) == 1, "duplicate detections are grouped and aggregate rows are excluded")
    check(grouped[0]["title"] == "File-type and filename anomalies", "material theme uses neutral language")

    payload = {
        "case_context": {"case_number": "CASE-REFERENCE", "case_title": "Generic examination", "synthetic_validation": False},
        "material_findings": grouped, "claim_ledger": [], "module_outcomes": [],
        "coverage": [], "timestamps": [], "cross_links": [],
    }
    valid = _valid_narrative(grouped)
    unsafe = json.loads(json.dumps(valid))
    unsafe["conclusions"][0]["text"] = (
        "This conclusion guarantees the reliability of the evidence and proves intent beyond any uncertainty. "
        "The wording is intentionally unsafe and should be rejected by the reporting controls before it reaches a report. "
        "Additional filler words keep this paragraph structurally long enough to test semantic rejection rather than minimum length."
    )

    calls: list[str] = []
    original = report_ai.llm_provider.synthesize
    try:
        responses = [json.dumps(unsafe), json.dumps(valid)]
        def fake_synth(prompt: str, **kwargs):
            calls.append(kwargs.get("purpose", ""))
            return responses.pop(0)
        report_ai.llm_provider.synthesize = fake_synth
        narrative = report_ai.synthesize_report_narrative(payload, strict=True, api_log=[])
        check(narrative.get("llm_used") is True, "grounded structured LLM narrative is accepted")
        check(len(calls) == 2, "unsafe first draft is rejected and corrected once")
        check(set(narrative["five_w_one_h"]) == {"WHO", "WHAT", "WHEN", "WHERE", "WHY", "HOW"}, "5W1H has six explicit evidence-based answers")
        check(set(narrative["per_finding_significance"]) == {grouped[0]["title"]}, "significance covers every material finding exactly once")
    finally:
        report_ai.llm_provider.synthesize = original

    check(
        report_ai._unsafe_absolute_claim("The evidence does not prove intent or ownership.") == "",
        "negated evidential limitations are not rejected as absolute claims",
    )
    check(
        bool(report_ai._unsafe_absolute_claim("The hash guarantees the evidence is authentic.")),
        "positive absolute evidential claims remain blocked",
    )

    brief = {"conclusions": valid["conclusions"]}
    try:
        report_ai.llm_provider.synthesize = lambda *a, **k: json.dumps(brief)
        repaired = report_ai.synthesize_report_narrative(payload, strict=True, api_log=[])
        check(repaired.get("structured_fields_evidence_locked") is True, "structured executive fields are generated from evidence-derived controls")
        repaired_entry = repaired["per_finding_significance"][grouped[0]["title"]]
        check(len(repaired_entry["significance"].split()) >= 12 and len(repaired_entry["evidential_limit"].split()) >= 10, "evidence-locked significance satisfies quality thresholds")
    finally:
        report_ai.llm_provider.synthesize = original

    from core import llm_provider
    check(llm_provider.DEFAULT_OPENAI_MAX_TOKENS >= 12000, "OpenAI executive synthesis has sufficient default output budget")

    try:
        report_ai.llm_provider.synthesize = lambda *a, **k: json.dumps(unsafe)
        rejected = report_ai.synthesize_report_narrative(payload, strict=True, api_log=[])
        check(rejected.get("llm_rejected") is True and rejected.get("llm_used") is False, "unsafe model prose is discarded and replaced by evidence-locked fallback")
        check("guarantees" not in " ".join(x.get("text", "") for x in rejected.get("conclusions") or []).lower(), "unsafe model wording cannot enter the report")
    finally:
        report_ai.llm_provider.synthesize = original

    try:
        def unavailable(*a, **k):
            raise LLMUnavailable("provider unavailable")
        report_ai.llm_provider.synthesize = unavailable
        try:
            report_ai.synthesize_report_narrative(payload, strict=True, api_log=[])
        except LLMUnavailable:
            unavailable_failed = True
        else:
            unavailable_failed = False
        check(unavailable_failed, "strict mode still fails when the configured provider returns no response")
    finally:
        report_ai.llm_provider.synthesize = original

    masked = report_ai._mask_executive_text("password: ExampleSecret 4111111111111111")
    check("ExampleSecret" not in masked and masked.endswith("1111"), "executive secret and PAN-shaped values are masked")

    from core.report_generator import _rg_parse_datetime
    check(_rg_parse_datetime("Xxx Xxx 00 0000 00:") is None, "malformed timeline placeholders are excluded")

    from modules.email_communications_analyzer import _parse_aim_log
    with tempfile.TemporaryDirectory() as td:
        log = Path(td) / "chat.txt"
        log.write_text("[2008-02-13 04:47:14] alpha_user: hello\n[2008-02-13 04:48:00] beta.user: reply\n")
        parsed = _parse_aim_log(log, None)
        check(parsed["participants"] == ["alpha_user", "beta.user"], "bracketed AIM screen-name strings are parsed")

    from core.report_loader import _load_recovery_manifest
    import logging
    with tempfile.TemporaryDirectory() as td:
        recovered = Path(td) / "deleted.txt"
        recovered.write_text("sample")
        manifest = Path(td) / "recovery_manifest.json"
        manifest.write_text(json.dumps({
            "generated_at": "2026-01-01T00:00:00+00:00",
            "execution_outcome": "ran_found_x",
            "recovery_source": "native_filesystem_parser",
            "deleted_records": [{
                "path": "/deleted.txt", "deleted": True, "size_bytes": 6,
                "recovery_status": "recovered", "extracted_path": str(recovered),
                "sha256": "00" * 32,
            }],
            "recovered_files": [str(recovered)],
        }))
        result = _load_recovery_manifest(manifest, logging.getLogger("selfcheck"))
        check(result is not None and result.status == "success" and len(result.findings) == 1, "native recovery manifest loads without contradictory status")
        check(not result.error_message, "successful deleted-file recovery has no false error message")

    extra_case_configs = [p for p in (ROOT / "config").glob("case_*.json") if p.name != "case_template.json"]
    check(not extra_case_configs, "no case-specific configuration is bundled")
    req = (ROOT / "requirements.txt").read_text(encoding="utf-8").lower()
    check(not re.search(r"(?mi)^\s*openai\s*[<=>]", req), "no OpenAI SDK package is required; REST access uses the existing HTTP client")

    source_paths = [
        p for base in (ROOT / "core", ROOT / "modules", ROOT / "config", ROOT / "tools")
        for p in base.rglob("*")
        if p.is_file() and p.suffix in {".py", ".json", ".yaml", ".yml", ".txt"}
        and p.resolve() != Path(__file__).resolve()
    ]
    runtime_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in source_paths)
    forbidden = [
        r"TESTCASE-\d{4}-\d{4}",
        r"/home/kali/AutoForensics",
        r"C:\\Users\\",
    ]
    for pattern in forbidden:
        check(not re.search(pattern, runtime_text, re.I), f"no production hard-coding matching {pattern}")

    unsafe_runtime_phrases = [
        "This seal certifies that the forensic report content was complete",
        "Forensic pipeline launched; write-blocker connected; imaging commenced",
        "forensic tool used in this examination (version detected at runtime)",
        "Indicates deliberate file deletion by the user",
        "Prefetch proves a program was executed",
        "attributes the file to a device and a point in time",
    ]
    for phrase in unsafe_runtime_phrases:
        check(phrase not in runtime_text, f"unsafe report phrase removed: {phrase[:55]}")

    print("\nRELEASE SELF-CHECK PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\n[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
