#!/usr/bin/env python3
"""Generate deterministic SHA-256 records for the clean source tree."""
from __future__ import annotations
import hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"release"/"SOURCE_SHA256SUMS.txt"
EXCLUDED_PARTS={"__pycache__",".pytest_cache",".venv","venv"}
EXCLUDED={OUT.resolve()}
rows=[]
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or any(part in EXCLUDED_PARTS for part in path.relative_to(ROOT).parts):
        continue
    if path.resolve() in EXCLUDED or path.suffix == ".pyc":
        continue
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    rows.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text("\n".join(rows)+"\n",encoding="utf-8")
print(f"SOURCE SHA-256 MANIFEST: {len(rows)} files -> {OUT}")
