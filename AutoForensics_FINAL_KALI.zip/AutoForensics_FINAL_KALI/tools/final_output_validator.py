#!/usr/bin/env python3
"""Create final machine-readable ledgers and verify canonical output assurance.

The validator is post-run only. It never supplies expected values to the
investigation engine. It separates primary/decoded evidence from derived,
aggregate, alternative and duplicate representations so report totals cannot be
inflated by cross-module summaries.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
UNIQUE_CLASSES = {"PRIMARY_EVIDENCE", "VERIFIED_DECODED_EVIDENCE"}
DERIVED_CLASSES = {"DERIVED_FACT", "AGGREGATE_SUMMARY"}


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic(path: Path, text: str, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)
    if mode is not None:
        os.chmod(path, mode)


def jsonl(path: Path, records: Iterable[dict[str, Any]], mode: int | None = None) -> None:
    atomic(path, "".join(json.dumps(record, ensure_ascii=False, sort_keys=True, default=str) + "\n" for record in records), mode)


def results(root: Path) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in sorted(root.glob("module_output/**/module_result.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        name = str(data.get("module_name") or path.parent.name)
        if name in seen:
            continue
        seen.add(name)
        output.append({"module": name, "path": path, "data": data})
    return output


def candidate_files(root: Path) -> list[Path]:
    return sorted(root.glob("module_output/**/candidate_observations.json"))


def provenance_ok(finding: dict[str, Any]) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    reference = finding.get("evidence_reference") or {}
    metadata = finding.get("metadata") or {}
    if not reference:
        reasons.append("missing evidence_reference")
    if not (reference.get("source_evidence_sha256") or reference.get("source_container_sha256")):
        reasons.append("missing source evidence hash")
    if not (reference.get("artefact_location") or reference.get("locators") or finding.get("evidence_path")):
        reasons.append("missing artefact locator")
    if metadata.get("candidate_only") or str(metadata.get("finding_basis", "")).casefold() in {"heuristic", "probabilistic", "candidate", "statistical", "model"}:
        reasons.append("candidate/heuristic in accepted ledger")
    if metadata.get("deterministic_validation") is False:
        reasons.append("deterministic validation false")
    if not metadata.get("fact_class"):
        reasons.append("missing fact_class")
    if not metadata.get("evidence_object_id"):
        reasons.append("missing evidence_object_id")
    return not reasons, reasons


def _load_candidates(root: Path) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for path in candidate_files(root):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        values = data if isinstance(data, list) else data.get("candidates") or data.get("observations") or data.get("findings") or []
        module = path.parent.name
        for value in values:
            candidates.append({"module": module, "source": str(path.relative_to(root)), "observation": value})
    return candidates


def _statistics_consistency(module: str, data: dict[str, Any]) -> list[str]:
    problems: list[str] = []
    statistics = data.get("statistics") or {}
    findings = data.get("findings") or []
    summary = str(data.get("summary") or "")
    canonical = statistics.get("canonical_result") or {}
    accepted_declared = canonical.get("accepted_records", canonical.get("accepted_findings"))
    if accepted_declared is not None and int(accepted_declared) != len(findings):
        problems.append(f"{module}: canonical accepted count {accepted_declared} != findings {len(findings)}")
    examined = statistics.get("objects_examined", statistics.get("files_processed", statistics.get("documents_discovered")))
    if examined is not None and int(examined or 0) > 0 and re.search(r"\b0\s+(?:artefacts?|artifacts?|objects?|files?)\s+examined\b", summary, re.I):
        problems.append(f"{module}: narrative claims zero examined while structured count is {examined}")
    return problems


def _restricted_records(accepted: list[dict[str, Any]], candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    sensitive_keys = {"plaintext", "password", "decrypted_content", "machine_transcription_requires_visual_confirmation", "recognized_text", "recognised_text", "ocr_text"}
    for item in accepted:
        metadata = item.get("metadata") or {}
        for key in sensitive_keys:
            if metadata.get(key) not in (None, ""):
                records.append({
                    "status": "ACCEPTED_DETERMINISTIC",
                    "module": item.get("module"), "finding_id": item.get("finding_id"),
                    "field": key, "value": metadata.get(key),
                    "source": item.get("evidence_reference"),
                })
    for item in candidates:
        observation = item.get("observation") or {}
        metadata = observation.get("metadata") or observation
        text = json.dumps(observation, ensure_ascii=False, default=str)
        is_ocr = "ocr" in text.casefold() or "transcription" in text.casefold()
        is_credential = any(token in text.casefold() for token in ("password", "username", "credential"))
        if is_ocr and is_credential:
            records.append({
                "status": "MACHINE_TRANSCRIPTION_REQUIRES_VISUAL_CONFIRMATION",
                "module": item.get("module"),
                "finding_id": observation.get("finding_id"),
                "value": metadata.get("recognized_text") or metadata.get("recognised_text") or metadata.get("ocr_text") or observation.get("description") or observation,
                "source": observation.get("evidence_reference") or metadata.get("source_image") or item.get("source"),
                "warning": "Machine transcription — requires visual examiner confirmation before promotion.",
            })
    return records


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--validation-dir", type=Path)
    parser.add_argument("--master-evidence", type=Path)
    parser.add_argument("--master-manifest", type=Path)
    parser.add_argument("--master-timeline", type=Path)
    parser.add_argument("--dataset-id", default="Exact user-supplied reference image")
    args = parser.parse_args()

    root = args.output.expanduser().resolve()
    validation = (args.validation_dir or root / "validation").resolve()
    validation.mkdir(parents=True, exist_ok=True)

    module_results = results(root)
    accepted: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    matrix: list[dict[str, Any]] = []
    consistency_problems: list[str] = []

    for entry in module_results:
        data = entry["data"]
        module = entry["module"]
        findings = data.get("findings") or []
        for finding in findings:
            ok, reasons = provenance_ok(finding)
            record = {"module": module, **finding}
            if ok:
                accepted.append(record)
            else:
                rejected.append({"module": module, "reason": " ; ".join(reasons), "finding": finding})
                failures.append({"module": module, "finding_id": finding.get("finding_id"), "reasons": reasons})
        statistics = data.get("statistics") or {}
        canonical = statistics.get("canonical_result") or {}
        classes = Counter(str((finding.get("metadata") or {}).get("fact_class") or "UNCLASSIFIED") for finding in findings)
        consistency_problems.extend(_statistics_consistency(module, data))
        matrix.append({
            "module": module,
            "status": data.get("status"),
            "execution_outcome": data.get("execution_outcome") or statistics.get("execution_outcome"),
            "accepted_records": len(findings),
            "unique_evidence_objects": int(canonical.get("unique_evidence_objects") or sum(classes[name] for name in UNIQUE_CLASSES)),
            "primary_evidence": classes["PRIMARY_EVIDENCE"],
            "verified_decoded": classes["VERIFIED_DECODED_EVIDENCE"],
            "derived_facts": classes["DERIVED_FACT"],
            "aggregate_summaries": classes["AGGREGATE_SUMMARY"],
            "alternative_representations": classes["ALTERNATIVE_REPRESENTATION"],
            "candidate_observations": int(canonical.get("candidate_observations") or 0),
            "assurance_rejected": int(canonical.get("assurance_rejected") or 0),
            "errors": len(data.get("errors") or []),
            "class_results": len(data.get("class_results") or []),
            "summary": data.get("summary", ""),
        })

    candidates = _load_candidates(root)
    for entry in module_results:
        assurance_rejected = (((entry["data"].get("statistics") or {}).get("finding_assurance") or {}).get("rejected_findings") or [])
        for finding in assurance_rejected:
            rejected.append({"module": entry["module"], "reason": "assurance rejection", "finding": finding})

    by_class: dict[str, list[dict[str, Any]]] = defaultdict(list)
    duplicate_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in accepted:
        metadata = record.get("metadata") or {}
        fact_class = str(metadata.get("fact_class") or "UNCLASSIFIED")
        by_class[fact_class].append(record)
        duplicate_identity = str(metadata.get("duplicate_identity") or metadata.get("duplicate_group_id") or "")
        if duplicate_identity:
            duplicate_groups[duplicate_identity].append(record)

    duplicate_records: list[dict[str, Any]] = []
    duplicate_ids: set[str] = set()
    for group_id, records_in_group in duplicate_groups.items():
        if len(records_in_group) <= 1:
            continue
        # Same representation class/type may be a copied wrapper. Distinct facts
        # about the same object are retained by their different finding types.
        by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for record in records_in_group:
            by_type[str(record.get("finding_type") or "")].append(record)
        for finding_type, same_type in by_type.items():
            if len(same_type) <= 1:
                continue
            primary = same_type[0]
            for duplicate in same_type[1:]:
                duplicate_ids.add(str(duplicate.get("finding_id") or ""))
                duplicate_records.append({
                    "duplicate_group_id": group_id,
                    "finding_type": finding_type,
                    "primary_finding_id": primary.get("finding_id"),
                    "duplicate_finding_id": duplicate.get("finding_id"),
                    "primary_module": primary.get("module"),
                    "duplicate_module": duplicate.get("module"),
                    "reason": "same canonical source/locator/value and finding type",
                })

    primary_ledger = [record for record in accepted if str((record.get("metadata") or {}).get("fact_class")) in UNIQUE_CLASSES and str(record.get("finding_id") or "") not in duplicate_ids]
    derived_ledger = [record for record in accepted if str((record.get("metadata") or {}).get("fact_class")) in DERIVED_CLASSES]
    alternative_ledger = [record for record in accepted if str((record.get("metadata") or {}).get("fact_class")) == "ALTERNATIVE_REPRESENTATION"]

    jsonl(validation / "accepted_findings.jsonl", accepted)
    jsonl(validation / "primary_evidence_ledger.jsonl", primary_ledger)
    jsonl(validation / "derived_fact_ledger.jsonl", derived_ledger)
    jsonl(validation / "alternative_representation_ledger.jsonl", alternative_ledger)
    jsonl(validation / "duplicate_representation_ledger.jsonl", duplicate_records)
    jsonl(validation / "candidate_observations.jsonl", candidates)
    jsonl(validation / "rejected_observations.jsonl", rejected)

    if matrix:
        with (validation / "module_execution_matrix.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(matrix[0]))
            writer.writeheader()
            writer.writerows(matrix)

    dependencies: dict[str, Any] = {"python": sys.version, "module_results": len(module_results), "external_tools": {}}
    from shutil import which
    for tool in ("ewfmount", "fls", "mmls", "istat", "tsk_recover", "tshark", "vol", "volatility3", "yara", "clamscan", "foremost", "scalpel", "bulk_extractor", "exiftool", "tesseract", "john", "hashcat"):
        path = which(tool)
        dependencies["external_tools"][tool] = {"available": bool(path), "path": path or ""}
    atomic(validation / "dependency_results.json", json.dumps(dependencies, indent=2))

    hashes: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and validation not in path.parents and path.stat().st_size <= 1024 * 1024 * 1024:
            try:
                hashes.append({"path": str(path.relative_to(root)), "size": path.stat().st_size, "sha256": hash_file(path)})
            except OSError:
                pass
    atomic(validation / "evidence_and_output_hashes.json", json.dumps(hashes, indent=2))

    provenance = {
        "accepted_record_count": len(accepted),
        "unique_primary_or_decoded_count": len(primary_ledger),
        "derived_record_count": len(derived_ledger),
        "alternative_representation_count": len(alternative_ledger),
        "duplicate_representation_count": len(duplicate_records),
        "candidate_count": len(candidates),
        "rejected_count": len(rejected),
        "accepted_provenance_failures": failures,
        "statistics_consistency_problems": consistency_problems,
        "passed": not failures and not consistency_problems,
    }
    atomic(validation / "provenance_validation.json", json.dumps(provenance, indent=2))
    atomic(validation / "report_statistics_consistency.json", json.dumps({"passed": not consistency_problems, "problems": consistency_problems}, indent=2))

    heuristic_candidates = []
    for candidate in candidates:
        text = json.dumps(candidate, ensure_ascii=False, default=str).casefold()
        if any(token in text for token in ("heuristic", "entropy", "threshold", "candidate", "probabilistic", "score", "ocr", "foremost", "scalpel", "classification")):
            heuristic_candidates.append(candidate)
    atomic(validation / "heuristic_controls.json", json.dumps({
        "candidate_only_observations": len(heuristic_candidates),
        "policy": "Heuristic/probabilistic observations are excluded from accepted unique evidence until deterministic corroboration succeeds.",
        "samples": heuristic_candidates[:100],
    }, indent=2, ensure_ascii=False))

    restricted = _restricted_records(accepted, candidates)
    atomic(validation / "restricted_examiner_annex.json", json.dumps({
        "classification": "RESTRICTED EXAMINER MATERIAL",
        "warning": "Machine transcriptions require visual confirmation before promotion.",
        "records": restricted,
    }, indent=2, ensure_ascii=False), 0o600)

    limitations = """# Remaining genuine limitations\n\n- Genuine Volatility 3 validation requires a supported RAM image; disk-contained marker strings do not prove memory structures.\n- Physical/logical mobile-device acquisition and full ALEAPP/iLEAPP validation require suitable authorised device-extraction corpora.\n- Software supports traceability and examiner review; legal admissibility remains jurisdictional and human-controlled.\n"""
    atomic(validation / "remaining_limitations.md", limitations)

    compliance = [
        ("Failure isolation", "MET", "Runtime has isolated result storage, timeout and controlled failure states; see retained regression results."),
        ("MASTER comparison for supplied image", "VERIFY LATER", "Run verify_final.sh with independently supplied MASTER files; the investigation engine never reads them."),
        ("Volatility 3 for disk evidence", "NOT APPLICABLE", "A disk image is not a genuine RAM image."),
        ("Genuine Volatility validation", "VERIFY LATER", "A supported RAM corpus is required."),
        ("Mobile artefact parsing for supplied corpus", "EVIDENCE PROVIDED — VALIDATE AGAINST MASTER", "Native embedded Android/iOS-style records are reported; this does not prove device acquisition or full LEAPP support."),
        ("Automatic legal admissibility", "NOT APPLICABLE", "Admissibility depends on examiner review, authorisation, procedure and jurisdiction."),
    ]

    if args.master_evidence and args.master_manifest and args.master_timeline:
        native = next(iter(root.glob("native_filesystem/**/native_filesystem_manifest.json")), None)
        timeline = next(iter(root.glob("module_output/**/timeline_builder/examiner_timeline.csv")), None) or next(iter(root.glob("module_output/**/timeline_builder/semantic_timeline.csv")), None)
        if not native or not timeline:
            raise SystemExit("MASTER comparison requested but native manifest or examiner timeline was not found")
        command = [
            sys.executable, str(ROOT / "tools" / "evaluate_master_reference.py"),
            "--run-output", str(root), "--master-evidence", str(args.master_evidence.resolve()),
            "--master-manifest", str(args.master_manifest.resolve()), "--master-timeline", str(args.master_timeline.resolve()),
            "--native-manifest", str(native), "--semantic-timeline", str(timeline),
            "--dataset-id", args.dataset_id, "--output-dir", str(validation / "master_comparison"),
        ]
        completed = subprocess.run(command, cwd=ROOT)
        if completed.returncode:
            return completed.returncode
        evaluation = json.loads((validation / "master_comparison" / "master_reference_evaluation.json").read_text(encoding="utf-8"))
        master_met = bool(evaluation.get("overall", {}).get("fn") == 0 and evaluation.get("overall", {}).get("fp") == 0 and evaluation.get("filesystem", {}).get("passed"))
        for index, row in enumerate(compliance):
            if row[0] == "MASTER comparison for supplied image":
                compliance[index] = (row[0], "MET" if master_met else "NOT MET", f"TP={evaluation['overall']['tp']}, FP={evaluation['overall']['fp']}, FN={evaluation['overall']['fn']}; filesystem_exact={evaluation['filesystem']['passed']}.")

    with (validation / "compliance_matrix.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["requirement", "status", "explanation"])
        writer.writerows(compliance)
    atomic(validation / "compliance_matrix.json", json.dumps([{"requirement": name, "status": status, "explanation": explanation} for name, status, explanation in compliance], indent=2))

    summary = {
        "module_results": len(module_results),
        "accepted_records": len(accepted),
        "unique_primary_or_decoded": len(primary_ledger),
        "derived_records": len(derived_ledger),
        "alternative_representations": len(alternative_ledger),
        "duplicate_representations": len(duplicate_records),
        "candidate_observations": len(candidates),
        "rejected_observations": len(rejected),
        "provenance_passed": not failures,
        "statistics_consistency_passed": not consistency_problems,
        "validation_dir": str(validation),
    }
    atomic(validation / "final_validation_summary.json", json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    return 0 if not failures and not consistency_problems and len(module_results) == 45 else 2


if __name__ == "__main__":
    raise SystemExit(main())
