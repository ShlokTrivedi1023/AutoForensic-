#!/usr/bin/env python3
"""Final production regression for hash-scope separation and fail-closed lineage.

The default suite creates all fixtures at runtime and contains no case-specific
names, hashes, paths, or planted evidence values.  An optional --evidence input
can be supplied to exercise the same invariants against a real/raw/EWF exhibit.
"""
from __future__ import annotations

import argparse
import hashlib
import logging
import tempfile
import json
from datetime import date
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

PASS: list[str] = []
FAIL: list[str] = []

def check(condition: bool, label: str, detail: str = "") -> None:
    if condition:
        PASS.append(label); print(f"[PASS] {label}")
    else:
        FAIL.append(f"{label}: {detail}"); print(f"[FAIL] {label}: {detail}")


def _table_blocks(section):
    return [b for b in section.blocks if b.block_type == "table"]


def test_report_scope_model() -> None:
    from core.report_sections import EvidenceAcquisition, build_section_three, integrity_verdict

    logical_md5 = "1" * 32
    logical_sha1 = "2" * 40
    logical_sha256 = "3" * 64
    container_md5 = "4" * 32
    container_sha1 = "5" * 40
    container_sha256 = "6" * 64
    ev = EvidenceAcquisition(
        exhibit_number="EX-GENERIC",
        description="Generic pre-existing EWF exhibit",
        acquisition_date=date.today(),
        acquisition_method="Pre-existing image supplied for read-only analysis",
        tool_used="AutoForensics native evidence parser",
        tool_version="2.0.0",
        md5_hash=logical_md5,
        sha1_hash=logical_sha1,
        sha256_hash=logical_sha256,
        md5_reference=logical_md5,
        sha1_reference=logical_sha1,
        sha256_reference="",
        source_container_path="/evidence/generic.E01",
        source_container_md5=container_md5,
        source_container_sha1=container_sha1,
        source_container_sha256=container_sha256,
        source_container_size_bytes=1234,
        source_container_hash_basis="source-file-bytes",
        logical_media_size_bytes=8192,
        source_size_bytes=1234,
        image_size_bytes=8192,
        acquired_by="Generic Examiner",
    )
    check(integrity_verdict(ev) == "VERIFIED",
          "embedded digest verdict uses logical-media fields")
    section = build_section_three([ev])
    tables = _table_blocks(section)
    headers = [tuple(t.data.get("headers") or []) for t in tables]
    check(any("SOURCE CONTAINER" in h for hs in headers for h in hs),
          "report contains a dedicated physical source-container table", str(headers))
    check(any("LOGICAL SHA-256" in h for hs in headers for h in hs),
          "report contains a dedicated reconstructed logical-media table", str(headers))
    flat = repr([t.data for t in tables])
    check(container_sha256 in flat and logical_sha256 in flat,
          "report retains both physical-container and logical-media SHA-256 values")
    check("reconstructed logical media" in flat,
          "embedded comparison table states its logical-media scope")


def test_source_container_lineage(tmp: Path) -> None:
    from core.deterministic_reconciler import reconcile_module_result
    from core.finding_assurance import assure_module_result
    from core.deterministic_validation import deterministic_metadata
    from modules._base import ModuleResult, ModuleStatus, Severity, make_finding

    evidence = tmp / "generic-container.bin"
    evidence.write_bytes(b"generic physical source bytes")
    out = tmp / "output"; out.mkdir()
    finding = make_finding(
        "SOURCE_CONTAINER_HASH_COMPUTED", Severity.INFO,
        "Source container was hashed byte-for-byte.", str(evidence),
        {
            "source_container_path": str(evidence),
            "source_container_sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
            "size_bytes": evidence.stat().st_size,
            **deterministic_metadata("byte-for-byte source hashing", validators=["hashlib.sha256"]),
        },
    )
    result = reconcile_module_result(
        ModuleResult("evidence_validator", "CASE-GENERIC", ModuleStatus.COMPLETED, findings=[finding]),
        module_name="evidence_validator", evidence_path=evidence,
        config={"_working_set": {"source_container_path": str(evidence), "image_set": [str(evidence)]}},
        output_dir=out,
    )
    accepted, rejected = assure_module_result(
        result, exhibit_id="EX-GENERIC", source_evidence_path=str(evidence),
        source_evidence_sha256=hashlib.sha256(evidence.read_bytes()).hexdigest(),
        logical_media_sha256="a" * 64,
    )
    check(len(accepted) == 1 and not rejected,
          "SOURCE_CONTAINER_* finding passes exact source-container lineage", str(rejected))
    check((accepted[0].metadata or {}).get("provenance_lineage_method") == "supplied_source_container",
          "source-container lineage method is explicit")



def test_timestamp_provenance_isolation(tmp: Path) -> None:
    from modules.timeline_builder import (
        _ingest_canonical_finding_timestamps,
        _ingest_completed_module_table_timestamps,
    )
    from core.report_generator import _rg_collect_case_output_timestamps

    config = {
        "_working_set": {
            "canonical_findings_by_module": {
                "anti_forensic_detector": [{
                    "finding_id": "analysis-record",
                    "finding_type": "ANOMALY_GROUP",
                    "description": "Derived anomaly group",
                    "severity": "INFO",
                    "metadata": {
                        "source_records": [{
                            "timestamp": "2099-01-01T00:00:00Z",
                            "event": "module processing record",
                        }]
                    },
                }],
                "mobile_analyzer": [{
                    "finding_id": "mobile-event",
                    "finding_type": "MOBILE_SMS",
                    "description": "Structured message record",
                    "severity": "INFO",
                    "evidence_path": "/evidence/mobile/ios/sms.db",
                    "metadata": {
                        "device_type": "ios",
                        "mobile_platform": "ios",
                        "source_file": "/evidence/mobile/ios/sms.db",
                        "source_records": [{
                            "ROWID": "1",
                            "_source_database": "/evidence/mobile/ios/sms.db",
                            "_source_table": "message",
                            "date": "2035-02-03T04:05:06Z",
                            "text": "generic test message",
                        }],
                    },
                }],
            }
        }
    }
    events = _ingest_canonical_finding_timestamps(config)
    stamps = {str(item.get("timestamp")) for item in events}
    check("2035-02-03T04:05:06+00:00" in stamps,
          "semantic mobile evidence timestamp enters chronology", str(events))
    check(not any("2099-01-01" in stamp for stamp in stamps),
          "derived anti-forensic processing timestamp is excluded from chronology", str(events))

    anti_dir = tmp / "module_output" / "anti_forensic_detector"
    timeline_dir = tmp / "module_output" / "timeline_builder"
    anti_dir.mkdir(parents=True); timeline_dir.mkdir(parents=True)
    (anti_dir / "analysis.json").write_text(json.dumps({"timestamp": "2099-01-01T00:00:00Z"}))
    (timeline_dir / "semantic_timeline.csv").write_text(
        "timestamp,event,source,severity\n"
        "2035-02-03T04:05:06Z,Mobile message,retained mobile database,INFO\n",
        encoding="utf-8",
    )
    collected = _rg_collect_case_output_timestamps(tmp)
    collected_stamps = {str(item.get("timestamp")) for item in collected}
    check("2035-02-03T04:05:06+00:00" in collected_stamps,
          "report chronology collector retains typed semantic module timestamps", str(collected))
    check(not any("2099-01-01" in stamp for stamp in collected_stamps),
          "report chronology collector rejects untyped derived-module timestamps", str(collected))

    original_db = tmp / "retained-evidence" / "sms.db"
    original_db.parent.mkdir(parents=True, exist_ok=True)
    original_db.write_bytes(b"SQLite format 3\x00generic")
    table_dir = tmp / "module_output" / "mobile_analyzer"
    table_dir.mkdir(parents=True, exist_ok=True)
    table_path = table_dir / "native_sms.csv"
    table_path.write_text(
        "_source_database,date,text\n"
        f"{original_db},807278400000000000,generic message\n",
        encoding="utf-8",
    )
    table_events = _ingest_completed_module_table_timestamps(tmp)
    matching = [event for event in table_events if event.get("event", "").startswith("date:")]
    check(bool(matching) and matching[0].get("source_artifact") == str(original_db),
          "structured module timestamps retain exact original-evidence lineage", str(matching))
    check(bool(matching) and matching[0].get("derived_artifact_path") == str(table_path),
          "structured timestamp records separately retain derived parser-output provenance", str(matching))


def test_optional_evidence(path: Path) -> None:
    from core.native_evidence import is_ewf, parse_ewf
    from modules import evidence_validator

    out = Path(tempfile.mkdtemp(prefix="af_final_hash_"))
    result = evidence_validator.run(path, "CASE-GENERIC", out, {}, logging.getLogger("final.regression"))
    types = {f.finding_type for f in result.findings}
    check("SOURCE_CONTAINER_HASH_COMPUTED" in types,
          "real exhibit produces a physical source-container hash finding")
    check("EVIDENCE_MEDIA_HASH_COMPUTED" in types,
          "real exhibit produces a reconstructed logical-media hash finding")
    stats = result.statistics or {}
    check(bool(stats.get("source_container_sha256")) and bool(stats.get("logical_media_sha256")),
          "real exhibit exposes distinct typed hash fields", str(stats))
    if is_ewf(path):
        info = parse_ewf(path)
        checks = [s.descriptor_checksum_valid for s in info.sections]
        check(bool(checks) and all(v is True for v in checks),
              "all present EWF section-descriptor Adler-32 checksums validate", str(checks))
        matches = stats.get("embedded_hash_matches") or {}
        check(bool(matches) and all(v is True for v in matches.values()),
              "embedded EWF digest references match reconstructed logical media", str(matches))
        check(stats.get("source_container_sha256") != stats.get("logical_media_sha256"),
              "compressed EWF container SHA-256 is not conflated with logical-media SHA-256")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", type=Path, help="Optional real/raw/EWF exhibit for integration checks")
    args = parser.parse_args()
    test_report_scope_model()
    with tempfile.TemporaryDirectory(prefix="af_final_regression_") as td:
        tmp = Path(td)
        test_source_container_lineage(tmp)
        test_timestamp_provenance_isolation(tmp)
    if args.evidence:
        test_optional_evidence(args.evidence.resolve())
    print(f"\nFINAL PRODUCTION REGRESSION: {len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        for item in FAIL: print(f"  - {item}")
        return 1
    print("FINAL PRODUCTION REGRESSION PASSED")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
