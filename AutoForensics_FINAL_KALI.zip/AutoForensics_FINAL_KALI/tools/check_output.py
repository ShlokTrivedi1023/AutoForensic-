import json, sys

with open('output/E02/disk_analysis.json', encoding='utf-8') as f:
    data = json.load(f)
print('JSON valid: True')
print('Files found:', len(data.get('file_listing', [])))
print('Findings:', len(data.get('findings', [])))
print('IOC counts:', {k: len(v) for k,v in data.get('strings_ioc',{}).items()})
for fi in data.get('file_listing', []):
    sha = fi.get('sha256','') or ''
    sha_short = sha[:20] if sha else '(not hashed)'
    print(f'  File: {repr(fi["path"])}  {fi["size_bytes"]} bytes  sha256={sha_short}...')
for f in data.get('findings', []):
    print(f'  Finding: [{f["severity"]}] {f["type"]}')
print()
print('Filesystem type:', data.get('filesystem_type'))
print('Image SHA-256:', data.get('image_sha256', '')[:32] + '...')
print('Summary:', data.get('summary'))
