#!/usr/bin/env python3
"""Prove crashes, SystemExit and timeout are isolated and later results survive."""
from __future__ import annotations
import json,tempfile,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from core.module_isolation import ModuleTimeoutError,atomic_write_json,module_timeout

def execute(name,fn,out:Path,timeout:float=1.0):
 out.mkdir(parents=True,exist_ok=True)
 try:
  with module_timeout(timeout,name): value=fn()
  rec={'module_name':name,'status':'COMPLETED','execution_outcome':'ran_found_x' if value else 'ran_found_nothing','finding_count':len(value or []),'findings':value or [],'errors':[]}
 except KeyboardInterrupt: raise
 except BaseException as exc:
  reason='TIMEOUT' if isinstance(exc,ModuleTimeoutError) else 'PARTIAL_FAILURE'
  rec={'module_name':name,'status':'FAILED_ISOLATED','execution_outcome':'did_not_run','finding_count':0,'findings':[],'errors':[f'{type(exc).__name__}: {exc}'],'class_results':[{'verdict':'INDETERMINATE','skip_reason':reason,'count':0}]}
 atomic_write_json(out/'module_result.json',rec);return rec

def main():
 with tempfile.TemporaryDirectory(prefix='af_failure_isolation_') as td:
  root=Path(td)
  crash=execute('crash',lambda:(_ for _ in ()).throw(RuntimeError('controlled')),root/'01')
  sexit=execute('system_exit',lambda:(_ for _ in ()).throw(SystemExit(7)),root/'02')
  timed=execute('timeout',lambda:(time.sleep(2),[])[1],root/'03',0.05)
  later=execute('following',lambda:[{'finding_id':'NEXT','evidence_reference':{'source_evidence_sha256':'0'*64,'artefact_location':'test'}}],root/'04')
  checks=[
   (all(x['status']=='FAILED_ISOLATED' for x in [crash,sexit,timed]),'crash/SystemExit/timeout become FAILED_ISOLATED'),
   (timed['class_results'][0]['skip_reason']=='TIMEOUT','timeout reason retained'),
   (all(x['execution_outcome']=='did_not_run' for x in [crash,sexit,timed]),'failed modules are not presented as completed'),
   (later['status']=='COMPLETED' and later['finding_count']==1,'later module executes and preserves findings'),
   (all((root/f'{i:02d}'/'module_result.json').is_file() for i in range(1,5)),'atomic independent result records exist'),
  ]
  for ok,label in checks:print(f"[{'PASS' if ok else 'FAIL'}] {label}")
  if not all(ok for ok,_ in checks):return 1
 print('FAILURE ISOLATION REGRESSION PASSED');return 0
if __name__=='__main__':raise SystemExit(main())
