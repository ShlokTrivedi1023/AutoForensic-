#!/usr/bin/env python3
"""Create a restricted examiner annex from retained structured outputs."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

SENSITIVE=("password","api key","username","credential","plaintext","decrypted","ocr")
def rows_from(root:Path):
    rows=[]
    for path in root.rglob('*.json*'):
        if path.name.endswith('.jsonl'):
            lines=path.read_text(errors='replace').splitlines()
            objs=[]
            for line in lines:
                try: objs.append(json.loads(line))
                except: pass
        else:
            try:
                obj=json.loads(path.read_text(errors='replace')); objs=obj if isinstance(obj,list) else [obj]
            except: continue
        for obj in objs:
            text=json.dumps(obj,ensure_ascii=False)
            if any(k in text.casefold() for k in SENSITIVE):
                rows.append((str(path.relative_to(root)), text[:2000]))
    return rows
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args();root=Path(a.output).resolve(); out=root/'validation';out.mkdir(exist_ok=True)
    rows=rows_from(root); payload={'classification':'RESTRICTED EXAMINER ANNEX','warning':'Machine transcription requires visual confirmation. Password/plaintext results require deterministic hash, CRC, or decryption verification.','records':[{'source':s,'structured_record':v} for s,v in rows]}
    (out/'restricted_examiner_annex.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    styles=getSampleStyleSheet(); story=[Paragraph('Restricted Examiner Annex',styles['Title']),Paragraph(payload['warning'],styles['BodyText']),Spacer(1,12)]
    data=[['Source','Structured record']] + [[s,v] for s,v in rows[:250]]
    table=Table(data,colWidths=[150,390],repeatRows=1);table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTSIZE',(0,0),(-1,-1),6),('BACKGROUND',(0,0),(-1,0),colors.lightgrey)]));story.append(table)
    SimpleDocTemplate(str(out/'restricted_examiner_annex.pdf'),pagesize=A4,rightMargin=24,leftMargin=24,topMargin=24,bottomMargin=24).build(story)
    print(out/'restricted_examiner_annex.pdf')
if __name__=='__main__': main()
