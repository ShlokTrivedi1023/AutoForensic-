#!/usr/bin/env python3
"""Compare a completed run with an independently supplied reference corpus.

This validator is intentionally data-driven: no case identifiers, expected
filenames, hashes, paths, counts or timestamps are embedded in the code. It
compares a reference logical-file CSV against AutoForensics' native filesystem
manifest and, optionally, checks that every reference timeline timestamp is
represented in the generated semantic timeline.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _normalise_timestamp(value: str) -> str:
    text = str(value or "").strip()
    match = re.match(
        r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?)(?:Z|[+-]\d{2}:\d{2})?",
        text,
    )
    if match:
        result = match.group(1)
        if "." in result:
            result = result.rstrip("0").rstrip(".")
        return result
    match = re.match(r"^(\d{4}-\d{2}-\d{2})(?:\b|\s)", text)
    return match.group(1) if match else text


def compare_files(reference_csv: Path, native_manifest: Path) -> dict[str, Any]:
    reference = _read_csv(reference_csv)
    native = json.loads(native_manifest.read_text(encoding="utf-8"))
    native_files = [item for item in native.get("files", []) if not item.get("is_directory")]
    ref_by_path = {row["logical_path"]: row for row in reference}
    native_by_path = {str(row.get("path") or ""): row for row in native_files}
    missing = sorted(set(ref_by_path) - set(native_by_path))
    unexpected = sorted(set(native_by_path) - set(ref_by_path))
    mismatches: list[dict[str, Any]] = []
    for logical_path in sorted(set(ref_by_path) & set(native_by_path)):
        expected = ref_by_path[logical_path]
        actual = native_by_path[logical_path]
        comparisons = {
            "size_bytes": (int(expected["size_bytes"]), int(actual.get("size_bytes") or 0)),
            "first_cluster": (int(expected["first_cluster"]), int(actual.get("first_cluster") or 0)),
            "cluster_count": (int(expected["cluster_count"]), len(actual.get("cluster_chain") or [])),
            "sha256": (expected["sha256"].casefold(), str(actual.get("sha256") or "").casefold()),
            "created": (expected["fat_created"], str(actual.get("created") or "")),
            "accessed": (expected["fat_accessed"], str(actual.get("accessed") or "")),
            "modified": (expected["fat_modified"], str(actual.get("modified") or "")),
        }
        for field, (wanted, observed) in comparisons.items():
            if wanted != observed:
                mismatches.append({
                    "logical_path": logical_path,
                    "field": field,
                    "expected": wanted,
                    "actual": observed,
                })
    return {
        "reference_file_count": len(reference),
        "native_file_count": len(native_files),
        "missing_paths": missing,
        "unexpected_paths": unexpected,
        "field_mismatches": mismatches,
        "passed": not missing and not unexpected and not mismatches,
    }


def compare_timeline(reference_csv: Path, semantic_csv: Path) -> dict[str, Any]:
    reference = _read_csv(reference_csv)
    semantic = _read_csv(semantic_csv)
    reference_times = [_normalise_timestamp(row.get("timestamp", "")) for row in reference]
    semantic_times = [_normalise_timestamp(row.get("timestamp", "")) for row in semantic]
    semantic_counts = Counter(semantic_times)
    missing: list[dict[str, str]] = []
    for row, timestamp in zip(reference, reference_times):
        if semantic_counts[timestamp] < 1:
            missing.append({"timestamp": timestamp, "event": row.get("event", "")})
    return {
        "reference_event_count": len(reference),
        "reference_unique_timestamp_count": len(set(reference_times)),
        "semantic_event_count": len(semantic),
        "missing_reference_timestamps": missing,
        "passed": not missing,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-manifest", type=Path, required=True)
    parser.add_argument("--native-manifest", type=Path, required=True)
    parser.add_argument("--reference-timeline", type=Path)
    parser.add_argument("--semantic-timeline", type=Path)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()

    result: dict[str, Any] = {
        "filesystem": compare_files(args.reference_manifest, args.native_manifest),
    }
    if bool(args.reference_timeline) != bool(args.semantic_timeline):
        parser.error("--reference-timeline and --semantic-timeline must be supplied together")
    if args.reference_timeline and args.semantic_timeline:
        result["timeline"] = compare_timeline(args.reference_timeline, args.semantic_timeline)
    result["passed"] = all(section.get("passed", False) for section in result.values() if isinstance(section, dict))

    rendered = json.dumps(result, indent=2, ensure_ascii=False)
    print(rendered)
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(rendered + "\n", encoding="utf-8")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
