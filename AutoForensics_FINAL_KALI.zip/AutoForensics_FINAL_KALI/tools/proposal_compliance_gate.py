#!/usr/bin/env python3
"""Fail-closed gate for the deliverables and research claims in the proposal.

This command does not manufacture an H1/H2 result.  It verifies a completed
case, its signed report, its independently verifiable custody seal, per-finding
traceability, the requested runtime capabilities, and a separately supplied
benchmark evaluation.  Any missing artefact is reported as NOT MET.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.finding_assurance import validate_evidence_reference
from core.report_signing import verify_report_signature


def _first(base: Path, pattern: str) -> Path | None:
    return next((p for p in sorted(base.glob(pattern)) if p.is_file()), None)


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _final_report_json(reports: Path) -> Path | None:
    """Select the rendered report JSON, not the earlier pipeline snapshot."""
    for path in sorted(reports.glob("*_report.json")):
        try:
            data = _load_json(path)
        except Exception:
            continue
        if isinstance(data.get("sections"), list) and data.get("sections"):
            return path
    return None


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _check(condition: bool, label: str, detail: str, rows: list[dict[str, Any]]) -> None:
    rows.append({"requirement": label, "met": bool(condition), "detail": detail})
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--case-dir", type=Path, required=True)
    p.add_argument("--public-key", type=Path, required=True)
    p.add_argument("--custody-key", type=Path, required=True)
    p.add_argument("--capability-report", type=Path, required=True)
    p.add_argument("--benchmark-report", type=Path, required=True)
    p.add_argument("--require-h1-percent", type=float, default=50.0)
    p.add_argument("--output", type=Path)
    args = p.parse_args()

    case_dir = args.case_dir.resolve()
    reports = case_dir / "reports"
    rows: list[dict[str, Any]] = []

    findings_path = _first(case_dir, "*_findings.jsonl")
    custody_path = _first(case_dir, "*_custody.jsonl")
    seal_path = _first(case_dir, "*_custody_seal.json")
    pdf = _first(reports, "*_report.pdf")
    report_json = _final_report_json(reports)
    signature = _first(reports, "*_report_signature.json")
    ai_policy = _first(reports, "*_ai_policy.json")
    completion = _first(case_dir, "*_completion_manifest.json")

    required = {
        "canonical findings JSONL": findings_path,
        "custody JSONL": custody_path,
        "custody seal": seal_path,
        "PDF report": pdf,
        "report JSON": report_json,
        "detached report signature": signature,
        "AI policy record": ai_policy,
        "machine completion manifest": completion,
    }
    for label, path in required.items():
        _check(path is not None, label, str(path) if path else "missing", rows)


    if completion:
        receipt = _load_json(completion)
        _check(
            bool(receipt.get("machine_complete")),
            "machine-complete cryptographic receipt",
            f"signature_verified={bool((receipt.get('report') or {}).get('signature_verified'))}; "
            f"custody_hmac_verified={bool((receipt.get('custody') or {}).get('hmac_verified'))}",
            rows,
        )

    pipeline_files = sorted(case_dir.glob("pipeline_manifest_ev*.json"))
    module_json_problems: list[str] = []
    module_entries = 0
    for pipeline_path in pipeline_files:
        try:
            entries = _load_json(pipeline_path)
        except Exception as exc:
            module_json_problems.append(f"{pipeline_path.name}: {exc}")
            continue
        for entry in entries if isinstance(entries, list) else []:
            module_entries += 1
            out_dir = Path(str(entry.get("output_dir") or ""))
            if not out_dir.is_dir() or not (out_dir / "module_result.json").is_file():
                module_json_problems.append(str(entry.get("module_name") or "unknown"))
    _check(
        bool(module_entries) and not module_json_problems,
        "per-module JSON deliverables",
        f"{module_entries} module result JSON file(s) verified" if module_entries and not module_json_problems
        else ("missing standardized result for: " + ", ".join(module_json_problems[:12])),
        rows,
    )

    if pdf and report_json:
        audit = subprocess.run(
            [
                sys.executable,
                str(ROOT / "tools" / "report_output_audit.py"),
                "--pdf",
                str(pdf),
                "--report-json",
                str(report_json),
                "--require-llm-record",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        _check(audit.returncode == 0, "post-generation report audit", audit.stdout.strip(), rows)

    if signature and args.public_key.is_file():
        try:
            verified = verify_report_signature(
                signature.resolve(), args.public_key.resolve(), base_dir=reports
            )
            _check(bool(verified.get("valid")), "Ed25519 report signature", "signature and file hashes verified", rows)
        except Exception as exc:
            _check(False, "Ed25519 report signature", str(exc), rows)
    else:
        _check(False, "Ed25519 report signature", "signature or public key missing", rows)

    if custody_path and seal_path and args.custody_key.is_file():
        check = subprocess.run(
            [
                sys.executable,
                str(ROOT / "tools" / "verify_custody.py"),
                "--ledger",
                str(custody_path),
                "--seal",
                str(seal_path),
                "--key-file",
                str(args.custody_key.resolve()),
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        _check(check.returncode == 0, "custody chain and HMAC seal", check.stdout.strip(), rows)
    else:
        _check(False, "custody chain and HMAC seal", "ledger, seal, or independent key missing", rows)

    if findings_path and custody_path:
        findings = _load_jsonl(findings_path)
        events = _load_jsonl(custody_path)
        custody_ids = {
            str((entry.get("metadata") or {}).get("finding_id") or "")
            for entry in events
            if entry.get("event_type") == "FINDING_RECORDED"
        }
        problems = []
        for finding in findings:
            fid = str(finding.get("finding_id") or finding.get("id") or "")
            valid, reason = validate_evidence_reference(finding.get("evidence_reference") or {})
            if not valid:
                problems.append(f"{fid}: {reason}")
            if fid not in custody_ids:
                problems.append(f"{fid}: no FINDING_RECORDED custody event")
        _check(
            not problems,
            "H2 per-finding evidence and custody binding",
            f"{len(findings)} finding(s) verified" if not problems else "; ".join(problems[:10]),
            rows,
        )

    if ai_policy:
        policy = _load_json(ai_policy)
        mode = str(policy.get("mode") or policy.get("policy_mode") or "")
        provider = str(policy.get("provider") or policy.get("selected_provider") or "")
        allowed = bool(policy.get("allowed", policy.get("policy_allowed", False))) or str(policy.get("decision", "")).upper() == "ALLOWED"
        cloud_consent = bool(policy.get("allow_cloud_case_data", policy.get("cloud_case_data_allowed", False))) and bool(policy.get("consent_reference"))
        privacy_ok = allowed and (
            mode == "local_only" and provider in {"openai", "deterministic", "none", ""}
            or mode == "cloud_opt_in" and cloud_consent
        )
        _check(
            privacy_ok,
            "AI privacy policy",
            f"mode={mode or 'unknown'} provider={provider or 'not recorded'} allowed={allowed}",
            rows,
        )

    if args.capability_report.is_file():
        capabilities = _load_json(args.capability_report)
        _check(
            bool(capabilities.get("ready")),
            "proposal runtime capability gate",
            f"profile={capabilities.get('profile')} ready={capabilities.get('ready')}",
            rows,
        )
    else:
        _check(False, "proposal runtime capability gate", "capability report missing", rows)

    if args.benchmark_report.is_file():
        benchmark = _load_json(args.benchmark_report)
        agg = benchmark.get("aggregate") or {}
        h2 = bool(agg.get("h2_traceability_pass"))
        minimum = agg.get("minimum_time_reduction_percent")
        metrics_present = all(k in agg for k in ("precision", "recall", "f1", "false_positive_rate"))
        h1 = minimum is not None and float(minimum) >= args.require_h1_percent
        _check(metrics_present, "ground-truth accuracy metrics", json.dumps({k: agg.get(k) for k in ("precision", "recall", "f1", "false_positive_rate")}), rows)
        _check(h2, "benchmark H2 gate", f"h2_traceability_pass={h2}", rows)
        _check(
            h1,
            "H1 efficiency threshold",
            f"minimum_time_reduction_percent={minimum}; required={args.require_h1_percent}",
            rows,
        )
    else:
        _check(False, "ground-truth accuracy metrics", "benchmark report missing", rows)
        _check(False, "benchmark H2 gate", "benchmark report missing", rows)
        _check(False, "H1 efficiency threshold", "manual-versus-automated benchmark not supplied", rows)

    report = {
        "schema": "autoforensics-proposal-compliance-v1",
        "case_dir": str(case_dir),
        "requirements": rows,
        "met": all(r["met"] for r in rows),
        "passed": sum(1 for r in rows if r["met"]),
        "failed": sum(1 for r in rows if not r["met"]),
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"PROPOSAL COMPLIANCE: {report['passed']} passed, {report['failed']} failed")
    print("PROPOSAL COMPLIANCE GATE PASSED" if report["met"] else "PROPOSAL COMPLIANCE GATE FAILED")
    return 0 if report["met"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
