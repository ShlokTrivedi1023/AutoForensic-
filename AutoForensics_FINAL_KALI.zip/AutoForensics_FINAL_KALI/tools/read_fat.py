#!/usr/bin/env python3
"""List files in a user-supplied FAT volume using AutoForensics' native parser."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.native_filesystem import FatVolume, best_filesystem  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True, type=Path, help="Path to a raw disk image")
    parser.add_argument("--max-entries", type=int, default=10000)
    parser.add_argument("--include-deleted", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    image = args.image.expanduser().resolve()
    if not image.is_file():
        raise SystemExit(f"Image not found: {image}")
    candidate = best_filesystem(image)
    if candidate is None or not candidate.fs_type.startswith("FAT"):
        raise SystemExit("No FAT12/16/32 volume was recognised")
    volume = FatVolume(image, candidate.offset_bytes)
    entries = volume.list_files(max_entries=args.max_entries)
    shown = 0
    for entry in entries:
        if entry.is_directory:
            continue
        if entry.deleted and not args.include_deleted:
            continue
        state = "DELETED" if entry.deleted else "ACTIVE"
        print(f"{state:7} {entry.size_bytes:10d} {entry.path}")
        shown += 1
    print(f"\nListed {shown} file record(s) from {candidate.fs_type} at sector {candidate.offset_sectors}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
