#!/usr/bin/env python3
"""Validate the final 45-module completion matrix for one AutoForensics run.

The gate is case-neutral.  It reads module contracts and module_result.json
files only; it never reads a MASTER answer key and contains no expected paths,
hashes, timestamps, findings or fixture values.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any
import sys

# Running ``python3 tools/strict_scope_gate.py`` sets sys.path[0] to the
# tools directory rather than the project root.  Add the root explicitly so
# the gate works from the shipped shell wrapper and from any caller location.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.module_completion import load_scope_contracts

_ACCEPTABLE = {"PASS_COMPLETE", "NOT_APPLICABLE", "OUT_OF_SCOPE"}


def _normalise(value: Any) -> str:
    text = str(getattr(value, "value", value) or "").strip().upper()
    return text.split(".", 1)[-1] if text.startswith("MODULESTATUS.") else text


def _load_results(root: Path) -> dict[str, dict[str, Any]]:
    results: dict[str, dict[str, Any]] = {}
    for path in sorted(root.rglob("module_result.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            continue
        name = str(data.get("module_name") or data.get("module") or path.parent.name)
        # Prefer the latest result when an output tree contains reruns.
        results[name] = {**data, "_path": str(path)}
    return results


def evaluate(root: Path) -> dict[str, Any]:
    contracts = load_scope_contracts()
    results = _load_results(root)
    rows: list[dict[str, Any]] = []
    failures: list[str] = []
    for name, contract in contracts.items():
        result = results.get(name)
        if result is None:
            rows.append({
                "module": name, "group": contract.get("baseline_group"),
                "status": "MISSING", "certificate": False,
                "reason": "No module_result.json was found.",
            })
            failures.append(f"{name}: MISSING")
            continue
        status = _normalise(result.get("status"))
        stats = result.get("statistics") or {}
        certificate = stats.get("completion_certificate") if isinstance(stats, dict) else None
        certificate_status = _normalise((certificate or {}).get("final_status")) if isinstance(certificate, dict) else ""
        certificate_hash_ok = False
        if isinstance(certificate, dict) and certificate.get("certificate_sha256"):
            unsigned = dict(certificate)
            expected_hash = str(unsigned.pop("certificate_sha256"))
            canonical = json.dumps(
                unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=True
            ).encode("utf-8")
            certificate_hash_ok = hashlib.sha256(canonical).hexdigest() == expected_hash
        certificate_ok = bool(
            isinstance(certificate, dict)
            and certificate_status == status
            and certificate_hash_ok
            and certificate.get("module") == name
            and certificate.get("baseline_group") == contract.get("baseline_group")
            and certificate.get("declared_input_domain") == contract.get("input_domain")
        )
        reason = "; ".join(str(x) for x in ((certificate or {}).get("reasons") or [])[:4])
        row = {
            "module": name,
            "group": contract.get("baseline_group"),
            "status": status,
            "certificate": certificate_ok,
            "accepted_findings": int((certificate or {}).get("accepted_findings") or 0),
            "reason": reason,
            "result_path": result.get("_path"),
        }
        rows.append(row)
        if status not in _ACCEPTABLE:
            failures.append(f"{name}: {status or 'UNKNOWN'}")
        elif not certificate_ok:
            failures.append(f"{name}: missing or inconsistent completion certificate")

    counts: dict[str, int] = {}
    for row in rows:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {
        "schema": "autoforensics-strict-scope-gate-v1",
        "output_root": str(root.resolve()),
        "module_count_expected": len(contracts),
        "module_count_found": len(results),
        "acceptable_statuses": sorted(_ACCEPTABLE),
        "counts": counts,
        "passed": not failures,
        "failures": failures,
        "modules": rows,
        "claim": (
            "Every applicable module certified complete within its declared scope."
            if not failures else
            "The run cannot claim full module completeness; see failures."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_root", type=Path, help="AutoForensics case output directory")
    parser.add_argument("--write", type=Path, help="Optional JSON output path")
    args = parser.parse_args()
    report = evaluate(args.output_root)
    text = json.dumps(report, indent=2, ensure_ascii=True)
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
