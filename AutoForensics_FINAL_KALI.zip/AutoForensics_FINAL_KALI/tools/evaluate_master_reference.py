#!/usr/bin/env python3
"""Data-driven comparison of an AutoForensics run against supplied MASTER CSVs.

The production engine contains no expected values. This external validator reads
an independently supplied master evidence table, file manifest and timeline,
then compares them with canonical module results from a completed run.
"""
from __future__ import annotations
import argparse, csv, json, re
from collections import defaultdict, Counter
from pathlib import Path
from typing import Any

# The supplied MASTER CSVs use the historical v2.7.x 46-module numbering.
# Autopsy occupied historical slot 6 and was removed in v2.8.0.  Keep the
# historical mapping stable so that later module numbers (especially mobile=46)
# are not shifted or misattributed.  Production execution/reporting uses only
# MODULE_ORDER, which contains the 45 active modules.
HISTORICAL_MODULE_ORDER = [
'evidence_validator','ewf_metadata','image_mounter','filesystem_analyzer','timeline_builder','autopsy_analysis',
'deleted_file_recovery','native_signature_carver','file_signature_analyzer','artifact_extractor','keyword_search',
'hash_database_match','string_extractor','memory_process_list','memory_network_connections','memory_artifact_extractor',
'memory_malware_scanner','memory_string_analyzer','rootkit_detector','pcap_analyzer','network_protocol_decoder',
'dns_analyzer','http_reconstructor','yara_scanner','native_malware_scanner','clamav_scanner','suspicious_file_detector',
'ioc_matcher','foremost_carver','scalpel_carver','bulk_extractor_scan','exiftool_metadata','ocr_text_extractor',
'document_analyzer','geolocation_extractor','hashcat_recovery','john_recovery','steganography_detector',
'windows_registry_analyzer','filesystem_deep_analyzer','email_communications_analyzer','browser_history_analyzer',
'criminal_network_mapper','image_content_analyzer','anti_forensic_detector','mobile_analyzer']
HISTORICAL_NUM_TO_MODULE={i+1:n for i,n in enumerate(HISTORICAL_MODULE_ORDER)}
MODULE_ORDER=[m for m in HISTORICAL_MODULE_ORDER if m != 'autopsy_analysis']

def parse_module_numbers(value:str)->list[int]:
 """Expand values such as '14-19', '7,11,41' and 'All'."""
 text=str(value or '').strip()
 numbers:set[int]=set()
 for start,end in re.findall(r'(?<!\d)(\d{1,2})\s*[-–]\s*(\d{1,2})(?!\d)', text):
  lo,hi=sorted((int(start),int(end)))
  numbers.update(n for n in range(lo,hi+1) if 1<=n<=46)
 text=re.sub(r'(?<!\d)\d{1,2}\s*[-–]\s*\d{1,2}(?!\d)',' ',text)
 numbers.update(int(x) for x in re.findall(r'(?<!\d)(\d{1,2})(?!\d)',text) if 1<=int(x)<=46)
 return sorted(numbers)

def read_csv(p:Path):
 with p.open(encoding='utf-8-sig',newline='') as h:return list(csv.DictReader(h))

def norm(s:Any)->str:
 return re.sub(r'\s+',' ',str(s or '').lower().replace('\\','/')).strip()

def tokens(row:dict[str,str])->set[str]:
 text=' '.join(row.values())
 out=set()
 # hashes, IPs, emails, URLs, paths, identifiers and distinctive words
 for x in re.findall(r'[a-fA-F0-9]{16,64}|\b(?:\d{1,3}\.){3}\d{1,3}\b|[\w.+-]+@[\w.-]+|https?://[^\s;,]+|/[A-Za-z0-9_.()/-]+|\b[A-Za-z][A-Za-z0-9_.-]{7,}\b',text):
  x=norm(x).strip('.,;:)')
  if len(x)>=8: out.add(x)
 # artefact label phrases are secondary tokens
 for x in [row.get('artefact_evidence',''), Path(row.get('source_location','')).name]:
  x=norm(x)
  if len(x)>=5: out.add(x)
 return out

def load_module_results(root:Path)->dict[str,dict]:
 found={}
 for p in root.rglob('module_result.json'):
  # prefer non-explicit duplicate path shortest
  try:d=json.loads(p.read_text(encoding='utf-8'))
  except Exception:continue
  name=str(d.get('module_name') or p.parent.name)
  if name in MODULE_ORDER or p.parent.name in MODULE_ORDER:
   key=p.parent.name if p.parent.name in MODULE_ORDER else name
   if key not in found or len(str(p))<len(found[key]['_path']):
    d['_path']=str(p); found[key]=d
 return found

def flatten_text(v:Any)->str:
 return norm(json.dumps(v,ensure_ascii=False,default=str))

def match_score(tok:set[str], corpus:str)->tuple[int,list[str]]:
 hits=[t for t in tok if t in corpus]
 return len(hits), sorted(hits,key=len,reverse=True)

def norm_ts(s:str)->str:
 m=re.match(r'^(\d{4}-\d{2}-\d{2}t\d{2}:\d{2}:\d{2}(?:\.\d+)?)(?:z|[+-]\d{2}:\d{2})?',norm(s))
 if not m:return norm(s)
 return m.group(1).rstrip('0').rstrip('.')

def main()->int:
 ap=argparse.ArgumentParser()
 ap.add_argument('--run-output',type=Path,required=True)
 ap.add_argument('--master-evidence',type=Path,required=True)
 ap.add_argument('--master-manifest',type=Path,required=True)
 ap.add_argument('--master-timeline',type=Path,required=True)
 ap.add_argument('--native-manifest',type=Path,required=True)
 ap.add_argument('--semantic-timeline',type=Path,required=True)
 ap.add_argument('--dataset-id',default='User-supplied controlled synthetic reference image')
 ap.add_argument('--output-dir',type=Path,required=True)
 args=ap.parse_args(); out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
 modules=load_module_results(args.run_output)
 module_corpus={k:flatten_text(v) for k,v in modules.items()}
 master=read_csv(args.master_evidence)
 rows=[]; item_detected={}; per=defaultdict(lambda:{'expected':0,'detected':0,'missed':0,'unsupported':0,'duplicates':0,'not_applicable':0})
 item_matches=defaultdict(list)
 for row in master:
  item=row['item_id']; tok=tokens(row); nums=parse_module_numbers(row.get('modules',''))
  expected_mods=[HISTORICAL_NUM_TO_MODULE[n] for n in nums if HISTORICAL_NUM_TO_MODULE.get(n) in MODULE_ORDER]
  if not expected_mods and norm(row.get('modules','')) in {'all',''}:
   expected_mods=list(MODULE_ORDER)
  detected_mods=[]; matched_tokens=[]
  applicable_expected=[]
  not_applicable_expected=[]
  for mod in expected_mods:
   status=str((modules.get(mod) or {}).get('status') or '').strip().upper()
   if status in {'NOT_APPLICABLE','VERIFY_LATER'}:
    not_applicable_expected.append(mod)
    per[mod]['not_applicable']+=1
    continue
   applicable_expected.append(mod)
   per[mod]['expected']+=1
   score,hits=match_score(tok,module_corpus.get(mod,''))
   strong=any(len(h)>=16 or '/' in h or '@' in h or re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}',h) for h in hits)
   if score>=2 or strong:
    detected_mods.append(mod); matched_tokens.extend(hits[:5]); per[mod]['detected']+=1
   else: per[mod]['missed']+=1
  # A MASTER item may be jointly established by several modules. If no
  # individual module contains enough context, test the combined expected
  # module corpus before declaring a miss.
  if not detected_mods and applicable_expected:
   combined=' '.join(module_corpus.get(m,'') for m in applicable_expected)
   score,hits=match_score(tok,combined)
   strong=any(len(h)>=16 or '/' in h or '@' in h or re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}',h) for h in hits)
   if score>=2 or strong:
    detected_mods=['JOINT:'+','.join(expected_mods)]
    matched_tokens.extend(hits[:8])
  detected=bool(detected_mods)
  item_detected[item]=detected
  rows.append({'item_id':item,'artefact':row.get('artefact_evidence'),'expected_modules':expected_mods,'applicable_expected_modules':applicable_expected,'not_applicable_expected_modules':not_applicable_expected,'detected_modules':detected_mods,'status':'DETECTED' if detected else 'MISSED','matched_tokens':sorted(set(matched_tokens))})

 # Map accepted findings to master items to identify unsupported and duplicates.
 findings=[]
 for mod,d in modules.items():
  for f in d.get('findings') or []:
   findings.append((mod,f))
 for mod,f in findings:
  corpus=flatten_text(f); candidates=[]
  for row in master:
   sc,h=match_score(tokens(row),corpus)
   if sc:candidates.append((sc,row['item_id'],h))
  if candidates:
   candidates.sort(reverse=True); _,item,hits=candidates[0]; item_matches[item].append(str(f.get('finding_id') or ''))
  else:
   per[mod]['unsupported']+=1
 # duplicates are extra accepted claims mapping to the same master item; listed separately, not automatically FP.
 for item,ids in item_matches.items():
  if len(ids)>1:
   # allocate to modules owning those ids
   idset=set(ids)
   for mod,f in findings:
    if str(f.get('finding_id') or '') in idset: per[mod]['duplicates']+=1

 tp=sum(item_detected.values()); fn=len(master)-tp
 unsupported=sum(v['unsupported'] for v in per.values())
 # Item-level precision: one consolidated reported claim per detected master item + unsupported claims.
 fp=unsupported
 precision=tp/(tp+fp) if tp+fp else 0.0; recall=tp/(tp+fn) if tp+fn else 0.0
 f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
 fpr=fp/(tp+fp) if tp+fp else 0.0

 # exact file manifest
 refs=read_csv(args.master_manifest); native=json.loads(args.native_manifest.read_text())
 nfiles={str(x.get('path')):x for x in native.get('files',[]) if not x.get('is_directory')}
 file_mismatch=[]
 for r in refs:
  a=nfiles.get(r['logical_path'])
  if not a:file_mismatch.append({'path':r['logical_path'],'issue':'missing'});continue
  checks={'size_bytes':(int(r['size_bytes']),int(a.get('size_bytes') or 0)),'first_cluster':(int(r['first_cluster']),int(a.get('first_cluster') or 0)),'cluster_count':(int(r['cluster_count']),len(a.get('cluster_chain') or [])),'sha256':(r['sha256'].lower(),str(a.get('sha256') or '').lower())}
  for k,(x,y) in checks.items():
   if x!=y:file_mismatch.append({'path':r['logical_path'],'issue':k,'expected':x,'actual':y})

 # event-level timeline, matching timestamp + key event terms (not timestamp alone)
 rt=read_csv(args.master_timeline); st=read_csv(args.semantic_timeline)
 timeline=[]
 for r in rt:
  ts=norm_ts(r['timestamp']); ev=norm(r['event']); words={w for w in re.findall(r'[a-z0-9]+',ev) if len(w)>2}
  matches=[]
  for s in st:
   if norm_ts(s.get('timestamp',''))!=ts:continue
   scorpus=norm(' '.join(s.values())); score=sum(1 for w in words if w in scorpus)
   if not words or score>=max(1,min(2,len(words))):matches.append(s)
  same_time=[s for s in st if norm_ts(s.get('timestamp',''))==ts]
  timeline.append({'timestamp':r['timestamp'],'event':r['event'],
                   'status':'DETECTED' if same_time else 'MISSED',
                   'semantic_label_match':'YES' if matches else 'NO'})

 matrix=[]
 for i,mod in enumerate(MODULE_ORDER,1):
  d=modules.get(mod); counts=per[mod]
  status=(d or {}).get('status','NOT_RUN'); outcome=(d or {}).get('execution_outcome') or ((d or {}).get('statistics') or {}).get('execution_outcome','')
  p=counts['detected']/(counts['detected']+counts['unsupported']) if counts['detected']+counts['unsupported'] else (1.0 if counts['expected']==0 and d else 0.0)
  r=counts['detected']/counts['expected'] if counts['expected'] else None
  mf=2*p*r/(p+r) if r is not None and p+r else None
  matrix.append({'module_number':i,'module':mod,'execution_status':status,'execution_outcome':outcome,'expected_items':counts['expected'],'not_applicable_reference_items':counts.get('not_applicable',0),'detected_items':counts['detected'],'missed_items':counts['missed'],'unsupported_findings':counts['unsupported'],'duplicate_mappings':counts['duplicates'],'precision':round(p,6),'recall':None if r is None else round(r,6),'f1':None if mf is None else round(mf,6)})

 report={'schema_version':'2.1','dataset_boundary':args.dataset_id,'metrics_definition':{'tp':'unique MASTER evidence items detected','fn':'unique MASTER evidence items not detected','fp':'accepted tool findings that could not be mapped to any supplied MASTER evidence item','duplicates':'additional accepted findings mapped to an already detected MASTER item; reported separately','precision':'TP/(TP+FP)','recall':'TP/(TP+FN)','f1':'2*precision*recall/(precision+recall)','false_positive_rate':'FP/(TP+FP)'},'overall':{'master_items':len(master),'tp':tp,'fp':fp,'fn':fn,'precision':round(precision,6),'recall':round(recall,6),'f1':round(f1,6),'false_positive_rate':round(fpr,6),'accepted_findings':len(findings)},'filesystem':{'master_files':len(refs),'native_files':len(nfiles),'mismatches':file_mismatch,'passed':not file_mismatch and len(refs)==len(nfiles)},'timeline':{'master_events':len(rt),'detected':sum(x['status']=='DETECTED' for x in timeline),'missed':[x for x in timeline if x['status']=='MISSED']},'evidence_items':rows,'module_matrix':matrix,'scope_statement':'Results apply only to the exact supplied image and MASTER reference. They do not establish performance across other NIST CFReDS images, mobile acquisitions, memory captures or live disks.'}
 (out/'master_reference_evaluation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 with (out/'module_accuracy_matrix.csv').open('w',newline='',encoding='utf-8') as h:
  fields=list(matrix[0]); w=csv.DictWriter(h,fieldnames=fields);w.writeheader();w.writerows(matrix)
 with (out/'evidence_item_comparison.csv').open('w',newline='',encoding='utf-8') as h:
  fields=['item_id','artefact','expected_modules','applicable_expected_modules','not_applicable_expected_modules','detected_modules','status','matched_tokens'];w=csv.DictWriter(h,fieldnames=fields);w.writeheader();
  for x in rows:w.writerow({**x,'expected_modules':';'.join(x['expected_modules']),'applicable_expected_modules':';'.join(x['applicable_expected_modules']),'not_applicable_expected_modules':';'.join(x['not_applicable_expected_modules']),'detected_modules':';'.join(x['detected_modules']),'matched_tokens':';'.join(x['matched_tokens'])})
 with (out/'timeline_comparison.csv').open('w',newline='',encoding='utf-8') as h:
  w=csv.DictWriter(h,fieldnames=['timestamp','event','status','semantic_label_match']);w.writeheader();w.writerows(timeline)
 md=['# MASTER Reference Evaluation','',f"Dataset boundary: {args.dataset_id}",'',f"TP: {tp}",f"FP: {fp}",f"FN: {fn}",f"Precision: {precision:.4f}",f"Recall: {recall:.4f}",f"F1: {f1:.4f}",f"False-positive rate: {fpr:.4f}",'',f"Filesystem exact: {'PASS' if report['filesystem']['passed'] else 'FAIL'}",f"Timeline events: {report['timeline']['detected']}/{len(rt)}",'',report['scope_statement']]
 (out/'master_reference_evaluation.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
 print(json.dumps(report['overall'],indent=2));print(f"Filesystem: {report['filesystem']['passed']}; Timeline {report['timeline']['detected']}/{len(rt)}")
 return 0
if __name__=='__main__':raise SystemExit(main())
