#!/usr/bin/env python3
"""Inspect a FAT boot sector from a user-supplied raw image.

This is a diagnostic utility only. It never supplies a default evidence path.
"""
from __future__ import annotations

import argparse
import struct
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True, type=Path, help="Path to a raw disk image")
    parser.add_argument("--offset-sectors", type=int, default=0, help="Boot-sector offset (default: 0)")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    image = args.image.expanduser().resolve()
    if not image.is_file():
        raise SystemExit(f"Image not found: {image}")
    offset = args.offset_sectors * 512
    with image.open("rb") as fh:
        fh.seek(offset)
        vbr = fh.read(512)
    if len(vbr) != 512:
        raise SystemExit("Unable to read a complete 512-byte boot sector")

    bps = struct.unpack_from("<H", vbr, 11)[0]
    spc = vbr[13]
    reserved = struct.unpack_from("<H", vbr, 14)[0]
    fats = vbr[16]
    root_entries = struct.unpack_from("<H", vbr, 17)[0]
    total16 = struct.unpack_from("<H", vbr, 19)[0]
    media = vbr[21]
    fat16 = struct.unpack_from("<H", vbr, 22)[0]
    total32 = struct.unpack_from("<I", vbr, 32)[0]
    fat32 = struct.unpack_from("<I", vbr, 36)[0]

    if bps not in {512, 1024, 2048, 4096} or spc == 0:
        raise SystemExit("Boot sector does not contain a plausible FAT BPB")
    total = total16 or total32
    fat_size = fat16 or fat32
    root_dir_sectors = (root_entries * 32 + bps - 1) // bps
    data_start = reserved + fats * fat_size + root_dir_sectors
    clusters = (total - data_start) // spc if total > data_start else 0
    fat_type = "FAT12" if clusters < 4085 else "FAT16" if clusters < 65525 else "FAT32"

    if fat_type == "FAT32":
        label = vbr[71:82].decode("ascii", errors="replace").strip()
        fs_text = vbr[82:90].decode("ascii", errors="replace").strip()
        volume_id = struct.unpack_from("<I", vbr, 67)[0]
    else:
        label = vbr[43:54].decode("ascii", errors="replace").strip()
        fs_text = vbr[54:62].decode("ascii", errors="replace").strip()
        volume_id = struct.unpack_from("<I", vbr, 39)[0]

    fields = {
        "Image": image,
        "Boot-sector offset": offset,
        "Bytes per sector": bps,
        "Sectors per cluster": spc,
        "Reserved sectors": reserved,
        "Number of FATs": fats,
        "Root entries": root_entries,
        "Media descriptor": f"0x{media:02X}",
        "Total sectors": total,
        "FAT size (sectors)": fat_size,
        "Total clusters": clusters,
        "Detected FAT type": fat_type,
        "Volume label": label or "(blank)",
        "Filesystem text": fs_text or "(blank)",
        "Volume serial ID": f"{volume_id:08X}",
    }
    for key, value in fields.items():
        print(f"{key:24}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
