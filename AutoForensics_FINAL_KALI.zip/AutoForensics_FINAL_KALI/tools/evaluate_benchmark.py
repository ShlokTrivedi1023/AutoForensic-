#!/usr/bin/env python3
"""Evaluate AutoForensics outputs against a ground-truth benchmark.

The evaluator is dataset-neutral: NIST CFReDS answer keys or synthetic fixture
keys are converted to the documented JSON schema. It calculates precision,
recall, F1, false-positive rate, per-module metrics, H1 time reduction and H2
traceability/custody compliance without embedding any case-specific answers in
the production engine.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.finding_assurance import validate_evidence_reference


def _norm(value: Any) -> Any:
    if isinstance(value, str):
        return re.sub(r"\s+", " ", value.strip().lower().replace("\\", "/"))
    if isinstance(value, dict):
        return {str(k).lower(): _norm(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_norm(v) for v in value]
    return value


def _walk(value: Any, prefix: str = "") -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            dotted = f"{prefix}.{key}" if prefix else str(key)
            yield from _walk(child, dotted)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk(child, f"{prefix}[{index}]")
    else:
        yield prefix.lower(), _norm(value)


def _value_index(finding: dict[str, Any]) -> dict[str, list[Any]]:
    index: dict[str, list[Any]] = defaultdict(list)
    for dotted, value in _walk(finding):
        leaf = re.sub(r"\[\d+\]$", "", dotted.rsplit(".", 1)[-1])
        index[dotted].append(value)
        index[leaf].append(value)
    return index


def _match_finding(finding: dict[str, Any], expected: dict[str, Any]) -> bool:
    index = _value_index(finding)
    for key, required in expected.items():
        normalized = _norm(required)
        key_l = str(key).lower()
        values = index.get(key_l, [])
        if not values:
            values = [value for dotted, candidates in index.items() if dotted.endswith("." + key_l) for value in candidates]
        if normalized not in values:
            # For path-like strings, allow the expected internal path to be a
            # suffix of an absolute retained path.
            if isinstance(normalized, str) and any(
                isinstance(v, str) and (v.endswith(normalized) or normalized in v)
                for v in values
            ):
                continue
            return False
    return True


def _load_findings(case_dir: Path, case_id: str = "") -> list[dict[str, Any]]:
    candidates = []
    if case_id:
        candidates.append(case_dir / f"{case_id}_findings.jsonl")
    candidates.extend(case_dir.glob("*_findings.jsonl"))
    path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        raise FileNotFoundError(f"No canonical findings JSONL found in {case_dir}")
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            records.append(json.loads(line))
    return records


def _load_custody(case_dir: Path, case_id: str = "") -> list[dict[str, Any]]:
    candidates = []
    if case_id:
        candidates.append(case_dir / f"{case_id}_custody.jsonl")
    candidates.extend(case_dir.glob("*_custody.jsonl"))
    path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _derive_automated_seconds(case_dir: Path, case_id: str = "") -> float | None:
    entries = _load_custody(case_dir, case_id)
    timestamps = []
    for entry in entries:
        try:
            timestamps.append(datetime.fromisoformat(str(entry.get("timestamp"))))
        except Exception:
            pass
    if len(timestamps) >= 2:
        return max(0.0, (max(timestamps) - min(timestamps)).total_seconds())
    return None


def _safe_div(num: float, den: float) -> float:
    return num / den if den else 0.0


def evaluate_case(case_spec: dict[str, Any], base_dir: Path) -> dict[str, Any]:
    case_id = str(case_spec.get("case_id") or "")
    case_dir = (base_dir / str(case_spec["case_output_dir"])).resolve()
    gt_path = (base_dir / str(case_spec["ground_truth"])).resolve()
    ground_truth = json.loads(gt_path.read_text(encoding="utf-8"))
    expected_items = [item for item in ground_truth.get("artifacts", []) if item.get("scored", True)]
    not_tested_types = {_norm(x) for x in ground_truth.get("not_tested_finding_types", [])}
    findings = _load_findings(case_dir, case_id)
    custody = _load_custody(case_dir, case_id)

    matched_finding_ids: set[str] = set()
    expected_results = []
    per_module = defaultdict(lambda: {"tp": 0, "fp": 0, "fn": 0})
    for expected in expected_items:
        finding_type = _norm(expected.get("finding_type", ""))
        match_fields = expected.get("match") or {}
        candidates = [
            finding for finding in findings
            if not finding_type or _norm(finding.get("finding_type", "")) == finding_type
        ]
        match = next((finding for finding in candidates if _match_finding(finding, match_fields)), None)
        if match:
            fid = str(match.get("finding_id") or "")
            matched_finding_ids.add(fid)
            module = str(match.get("module_name") or expected.get("module") or "unknown")
            per_module[module]["tp"] += 1
            expected_results.append({"artifact_id": expected.get("artifact_id"), "status": "TP", "finding_id": fid})
        else:
            module = str(expected.get("module") or "unknown")
            per_module[module]["fn"] += 1
            expected_results.append({"artifact_id": expected.get("artifact_id"), "status": "FN", "finding_id": ""})

    false_positives = []
    for finding in findings:
        fid = str(finding.get("finding_id") or "")
        ftype = _norm(finding.get("finding_type", ""))
        if fid in matched_finding_ids or ftype in not_tested_types:
            continue
        false_positives.append({
            "finding_id": fid,
            "finding_type": finding.get("finding_type"),
            "module": finding.get("module_name"),
        })
        per_module[str(finding.get("module_name") or "unknown")]["fp"] += 1

    tp = sum(1 for item in expected_results if item["status"] == "TP")
    fn = sum(1 for item in expected_results if item["status"] == "FN")
    fp = len(false_positives)
    precision = _safe_div(tp, tp + fp)
    recall = _safe_div(tp, tp + fn)
    f1 = _safe_div(2 * precision * recall, precision + recall)
    false_positive_rate = _safe_div(fp, tp + fp)

    custody_finding_ids = {
        str((entry.get("metadata") or {}).get("finding_id") or "")
        for entry in custody if entry.get("event_type") == "FINDING_RECORDED"
    }
    h2_failures = []
    for finding in findings:
        fid = str(finding.get("finding_id") or "")
        ok, reason = validate_evidence_reference(finding.get("evidence_reference") or {})
        if not ok:
            h2_failures.append({"finding_id": fid, "reason": reason})
        if fid not in custody_finding_ids:
            h2_failures.append({"finding_id": fid, "reason": "no matching FINDING_RECORDED custody event"})

    automated_seconds = case_spec.get("automated_seconds")
    if automated_seconds is None:
        automated_seconds = _derive_automated_seconds(case_dir, case_id)
    manual_seconds = case_spec.get("manual_seconds")
    reduction_percent = None
    if automated_seconds is not None and manual_seconds not in (None, 0):
        reduction_percent = (float(manual_seconds) - float(automated_seconds)) / float(manual_seconds) * 100.0

    module_metrics = {}
    for module, counts in sorted(per_module.items()):
        m_tp, m_fp, m_fn = counts["tp"], counts["fp"], counts["fn"]
        m_precision = _safe_div(m_tp, m_tp + m_fp)
        m_recall = _safe_div(m_tp, m_tp + m_fn)
        module_metrics[module] = {
            **counts,
            "precision": round(m_precision, 6),
            "recall": round(m_recall, 6),
            "f1": round(_safe_div(2 * m_precision * m_recall, m_precision + m_recall), 6),
        }

    return {
        "case_id": case_id,
        "case_output_dir": str(case_dir),
        "ground_truth": str(gt_path),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "f1": round(f1, 6),
        "false_positive_rate": round(false_positive_rate, 6),
        "expected_results": expected_results,
        "false_positives": false_positives,
        "h2_traceability_pass": not h2_failures,
        "h2_failures": h2_failures,
        "automated_seconds": automated_seconds,
        "manual_seconds": manual_seconds,
        "time_reduction_percent": round(reduction_percent, 3) if reduction_percent is not None else None,
        "module_metrics": module_metrics,
    }


def _aggregate(cases: list[dict[str, Any]]) -> dict[str, Any]:
    tp = sum(c["tp"] for c in cases)
    fp = sum(c["fp"] for c in cases)
    fn = sum(c["fn"] for c in cases)
    precision = _safe_div(tp, tp + fp)
    recall = _safe_div(tp, tp + fn)
    reductions = [c["time_reduction_percent"] for c in cases if c["time_reduction_percent"] is not None]
    return {
        "cases": len(cases),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "f1": round(_safe_div(2 * precision * recall, precision + recall), 6),
        "false_positive_rate": round(_safe_div(fp, tp + fp), 6),
        "h2_traceability_pass": all(c["h2_traceability_pass"] for c in cases),
        "mean_time_reduction_percent": round(sum(reductions) / len(reductions), 3) if reductions else None,
        "minimum_time_reduction_percent": min(reductions) if reductions else None,
    }


def _write_outputs(output_dir: Path, report: dict[str, Any]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "benchmark_evaluation.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8"
    )
    with (output_dir / "benchmark_cases.csv").open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "case_id", "tp", "fp", "fn", "precision", "recall", "f1",
            "false_positive_rate", "h2_traceability_pass", "automated_seconds",
            "manual_seconds", "time_reduction_percent",
        ])
        writer.writeheader()
        for case in report["case_results"]:
            writer.writerow({key: case.get(key) for key in writer.fieldnames})
    aggregate = report["aggregate"]
    lines = [
        "# AutoForensics Benchmark Evaluation",
        "",
        f"Cases evaluated: {aggregate['cases']}",
        f"True positives: {aggregate['tp']}",
        f"False positives: {aggregate['fp']}",
        f"False negatives: {aggregate['fn']}",
        f"Precision: {aggregate['precision']:.4f}",
        f"Recall: {aggregate['recall']:.4f}",
        f"F1: {aggregate['f1']:.4f}",
        f"False-positive rate: {aggregate['false_positive_rate']:.4f}",
        f"H2 traceability: {'PASS' if aggregate['h2_traceability_pass'] else 'FAIL'}",
        f"Mean time reduction: {aggregate['mean_time_reduction_percent'] if aggregate['mean_time_reduction_percent'] is not None else 'NOT MEASURED'}",
        "",
        "A metric is reported only from the supplied case outputs and ground-truth keys; missing manual timing is not inferred.",
    ]
    (output_dir / "benchmark_evaluation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--require-h1-percent", type=float, default=None)
    parser.add_argument("--require-h2", action="store_true")
    args = parser.parse_args()

    manifest_path = args.manifest.resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    case_specs = manifest.get("cases") or []
    if not case_specs:
        raise SystemExit("Benchmark manifest contains no cases")
    case_results = [evaluate_case(spec, manifest_path.parent) for spec in case_specs]
    report = {
        "schema_version": "1.0",
        "generated_at": datetime.now().astimezone().isoformat(),
        "manifest": str(manifest_path),
        "case_results": case_results,
        "aggregate": _aggregate(case_results),
    }
    _write_outputs(args.output_dir.resolve(), report)
    aggregate = report["aggregate"]
    failures = []
    if args.require_h2 and not aggregate["h2_traceability_pass"]:
        failures.append("H2 traceability gate failed")
    if args.require_h1_percent is not None:
        minimum = aggregate["minimum_time_reduction_percent"]
        if minimum is None:
            failures.append("H1 timing was not measured for every required case")
        elif minimum < args.require_h1_percent:
            failures.append(
                f"H1 minimum time reduction {minimum:.3f}% is below {args.require_h1_percent:.3f}%"
            )
    print(json.dumps(aggregate, indent=2))
    if failures:
        for failure in failures:
            print(f"[FAIL] {failure}", file=sys.stderr)
        return 1
    print("BENCHMARK EVALUATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
