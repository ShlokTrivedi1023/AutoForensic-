"""
tools/__init__.py — AutoForensics tools package.

The tools package contains administrative and utility command-line interfaces
for managing the AutoForensics platform:

  admin.py  — case management, investigator administration, audit commands
"""

from __future__ import annotations

__all__ = ["admin"]
