#!/usr/bin/env python3
from __future__ import annotations
import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from tools.capability_gate import _volatility_path

def main()->int:
    path=_volatility_path()
    if not path:
        print('[FAIL] Volatility 3 entry point not found');return 1
    cmd=path.split() if ' -m ' in path else ([sys.executable,path] if path.endswith('.py') else [path])
    cp=subprocess.run(cmd+['--help'],capture_output=True,text=True,timeout=60,check=False)
    text=(cp.stdout+cp.stderr).lower()
    ok=cp.returncode==0 and ('volatility' in text or 'framework' in text or 'plugin' in text)
    print(f"[{'PASS' if ok else 'FAIL'}] Volatility 3 runtime: {path}")
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
