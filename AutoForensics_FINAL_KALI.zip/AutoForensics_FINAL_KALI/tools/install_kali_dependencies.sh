#!/usr/bin/env bash
# Deterministic core installer for Kali/Debian.
# Optional internet-fetched enrichments are disabled by default so transient
# PyPI/RubyGems/Git/ClamAV TLS failures do not repeatedly interrupt an E01 run.
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run with sudo: sudo bash tools/install_kali_dependencies.sh" >&2
  exit 2
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export DEBIAN_FRONTEND=noninteractive
INSTALL_OPTIONAL="${AUTOFORENSICS_INSTALL_OPTIONAL:-0}"
UPDATE_CLAMAV="${AUTOFORENSICS_UPDATE_CLAMAV:-0}"

apt-get update
core_packages=(
  git python3 python3-pip python3-dev build-essential ca-certificates
  sleuthkit tshark wireshark-common hashcat john yara clamav
  bulk-extractor foremost scalpel libimage-exiftool-perl
  tesseract-ocr steghide binutils unzip p7zip-full
  poppler-utils dosfstools mtools util-linux gddrescue
)
# EWF tool package names vary by Debian/Kali release. Native E01 parsing is the
# primary path, so install whichever external verification package exists.
for candidate in ewf-tools libewf-tools; do
  if apt-cache show "$candidate" >/dev/null 2>&1; then
    core_packages+=("$candidate")
    break
  fi
done

available=()
missing_repo=()
for package in "${core_packages[@]}"; do
  if apt-cache show "$package" >/dev/null 2>&1; then
    available+=("$package")
  else
    missing_repo+=("$package")
  fi
done
if ((${#available[@]})); then
  apt-get install -y "${available[@]}"
fi
if ((${#missing_repo[@]})); then
  echo "[WARN] Core package names absent from this mirror: ${missing_repo[*]}"
fi

# Avoid unnecessary network traffic when every core import is already present.
if python3 - <<'PYCORE'
import importlib
for name in (
    "dateutil", "yaml", "magic", "yara", "reportlab", "pypdf",
    "PIL", "cryptography", "defusedxml", "jinja2",
):
    importlib.import_module(name)
print("[PASS] Core Python imports already available")
PYCORE
then
  :
else
  echo "[INFO] Installing missing core Python requirements"
  if ! python3 -m pip install --break-system-packages --retries 1 --timeout 45 \
      -r "$ROOT_DIR/requirements.txt"; then
    echo "[WARN] Core Python download failed. The capability gate below will identify any genuinely missing mandatory import."
  fi
fi

if [[ "$INSTALL_OPTIONAL" == "1" ]]; then
  echo "[INFO] Optional enrichment installation enabled"
  optional_apt=(python3-oletools outguess stegseek ruby-full ruby-dev cmake libmhash-dev libjpeg-dev libssl-dev wordlists)
  for package in "${optional_apt[@]}"; do
    if apt-cache show "$package" >/dev/null 2>&1; then
      apt-get install -y "$package" || echo "[WARN] Optional apt package failed: $package"
    fi
  done

  python3 -m pip install --break-system-packages --retries 1 --timeout 45 \
      -r "$ROOT_DIR/requirements-optional.txt" || \
      echo "[WARN] Optional Python enrichments unavailable; native document analysis remains enabled."

  if ! command -v zsteg >/dev/null 2>&1 && command -v gem >/dev/null 2>&1; then
    gem install --no-document zsteg || echo "[WARN] Optional zsteg unavailable"
  fi

  install_repo() {
    local url="$1" target="$2"
    if [[ -d "$target/.git" ]]; then
      git -C "$target" pull --ff-only || echo "[WARN] Could not update $target"
    elif [[ ! -e "$target" ]]; then
      git clone --depth 1 "$url" "$target" || echo "[WARN] Could not clone $url"
    fi
  }

  if ! python3 -c 'import volatility3.cli' >/dev/null 2>&1 && [[ ! -f /opt/volatility3/vol.py ]]; then
    install_repo https://github.com/volatilityfoundation/volatility3.git /opt/volatility3
  fi
  install_repo https://github.com/abrignoni/ALEAPP.git /opt/ALEAPP
  install_repo https://github.com/abrignoni/iLEAPP.git /opt/iLEAPP

  for requirements in /opt/volatility3/requirements.txt /opt/ALEAPP/requirements.txt /opt/iLEAPP/requirements.txt; do
    if [[ -f "$requirements" ]]; then
      python3 -m pip install --break-system-packages --retries 1 --timeout 45 -r "$requirements" || \
        echo "[WARN] Optional requirements unavailable: $requirements"
    fi
  done
else
  echo "[INFO] Optional Volatility/ALEAPP/iLEAPP/oletools/zsteg installation skipped."
  echo "       Enable once with: sudo AUTOFORENSICS_INSTALL_OPTIONAL=1 bash tools/install_kali_dependencies.sh"
fi

# Create wrappers only when the corresponding tool exists.
if python3 -c 'import volatility3.cli' >/dev/null 2>&1 || [[ -f /opt/volatility3/vol.py ]]; then
  cat > /usr/local/bin/vol <<'EOF'
#!/usr/bin/env bash
set -e
if python3 -c 'import volatility3.cli' >/dev/null 2>&1; then
  exec python3 -m volatility3.cli "$@"
elif [[ -f /opt/volatility3/vol.py ]]; then
  exec python3 /opt/volatility3/vol.py "$@"
fi
exit 127
EOF
  chmod 0755 /usr/local/bin/vol
fi
if [[ -f /opt/ALEAPP/aleapp.py ]]; then
  printf '%s\n' '#!/usr/bin/env bash' 'exec python3 /opt/ALEAPP/aleapp.py "$@"' > /usr/local/bin/aleapp
  chmod 0755 /usr/local/bin/aleapp
fi
if [[ -f /opt/iLEAPP/ileapp.py ]]; then
  printf '%s\n' '#!/usr/bin/env bash' 'exec python3 /opt/iLEAPP/ileapp.py "$@"' > /usr/local/bin/ileapp
  chmod 0755 /usr/local/bin/ileapp
fi

if [[ "$UPDATE_CLAMAV" == "1" ]]; then
  systemctl stop clamav-freshclam.service >/dev/null 2>&1 || true
  freshclam || echo "[WARN] ClamAV database update failed; exact evidence-contained NDB signatures and native scanners remain available."
  systemctl enable --now clamav-freshclam.service >/dev/null 2>&1 || true
else
  echo "[INFO] ClamAV network update skipped. Enable once with AUTOFORENSICS_UPDATE_CLAMAV=1."
fi

TARGET_USER="${SUDO_USER:-root}"
TARGET_GROUP="$(id -gn "$TARGET_USER")"
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
REG_DIR="$TARGET_HOME/.config/autoforensics"
install -d -m 0700 -o "$TARGET_USER" -g "$TARGET_GROUP" "$REG_DIR"
if [[ ! -f "$REG_DIR/investigators.json" ]]; then
  install -m 0600 -o "$TARGET_USER" -g "$TARGET_GROUP" \
    "$ROOT_DIR/config/investigators.json" "$REG_DIR/investigators.json"
fi

# Capability reports are installation-state artefacts, not source files. Keep
# them outside the extracted release so source-hygiene verification remains
# reproducible after installation on any user account or path.
CAPABILITY_REPORT_DIR="${AUTOFORENSICS_CAPABILITY_REPORT_DIR:-$TARGET_HOME/.local/state/autoforensics}"
install -d -m 0700 -o "$TARGET_USER" -g "$TARGET_GROUP" "$CAPABILITY_REPORT_DIR"
rm -f "$ROOT_DIR/disk_capability_report.json" "$ROOT_DIR/proposal_capability_report.json"

cd "$ROOT_DIR"
python3 tools/capability_gate.py --profile disk --strict \
  --allow-synthetic-clamav-db --json-output "$CAPABILITY_REPORT_DIR/disk_capability_report.json"
python3 tools/capability_gate.py --profile full \
  --allow-synthetic-clamav-db --json-output "$CAPABILITY_REPORT_DIR/proposal_capability_report.json" || true
chown "$TARGET_USER:$TARGET_GROUP" \
  "$CAPABILITY_REPORT_DIR/disk_capability_report.json" \
  "$CAPABILITY_REPORT_DIR/proposal_capability_report.json" 2>/dev/null || true
python3 tools/validate_yara_rules.py

echo "SETUP COMPLETE"
