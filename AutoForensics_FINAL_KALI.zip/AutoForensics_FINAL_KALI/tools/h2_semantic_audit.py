#!/usr/bin/env python3
"""Case-neutral H2 semantic audit for an AutoForensics output directory.

The gate compares the retained candidate ledger, canonical count schema,
completion certificates, provenance, specialist-carver invariants and the stable
report.  It never reads a MASTER/answer key and cannot create or promote
findings.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import traceback
from pathlib import Path
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.count_schema import (
    CANONICAL_COUNT_FIELDS,
    CANONICAL_COUNT_SCHEMA,
    CountSchemaError,
    build_canonical_counts,
    counts_from_certificate,
    validate_canonical_counts,
)
from core.evidence_ledger import load_candidate_records
from core.module_completion import load_scope_contracts

HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")
CURRENT_CERTIFICATE_SCHEMA = "autoforensics-module-completion-v4"


def _json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8", errors="strict"))


def _records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    data = _json(path)
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("candidates", "observations", "records", "items"):
            value = data.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    raise ValueError(f"{path}: candidate ledger has no supported record list")


def _report_json(output: Path) -> Path | None:
    stable = sorted((output / "reports").glob("*_report.json"))
    non_timestamped = [
        p for p in stable
        if not re.search(r"_\d{8}T\d{6}Z_report\.json$", p.name)
    ]
    return (non_timestamped or stable or [None])[0]


def _resolve_retained_path(output: Path, value: Any) -> Path | None:
    text = str(value or "").strip()
    if not text:
        return None
    direct = Path(text)
    if direct.is_file():
        return direct
    # Verification bundles retain the output tree but not the original Kali root.
    # Map only the exact case-output suffix; never basename-search or fuzzy-match.
    normalised = text.replace("\\", "/")
    match = re.search(r"/(?:[^/]+_OUTPUT)/(.*)$", normalised)
    if match:
        relative = match.group(1)
        mapped = (output / relative).resolve()
        try:
            mapped.relative_to(output.resolve())
        except ValueError:
            return None
        if mapped.is_file():
            return mapped
    return None


def _certificate_counts(
    certificate: Mapping[str, Any], derived: Mapping[str, int], *, strict_schema: bool,
) -> tuple[dict[str, int], list[str], list[str]]:
    failures: list[str] = []
    warnings: list[str] = []
    schema = str(certificate.get("schema") or "")
    if schema == CURRENT_CERTIFICATE_SCHEMA:
        try:
            return counts_from_certificate(certificate), failures, warnings
        except CountSchemaError as exc:
            failures.append(f"invalid canonical certificate count schema: {exc}")
            return dict(derived), failures, warnings

    message = (
        f"legacy completion certificate schema {schema or '<missing>'}; "
        f"current schema is {CURRENT_CERTIFICATE_SCHEMA}"
    )
    if strict_schema:
        failures.append(message)
    else:
        warnings.append(message)

    # Legacy diagnostic mode compares every count that actually existed in v3.
    result = dict(derived)
    units = certificate.get("count_units") if isinstance(certificate.get("count_units"), dict) else {}
    for field in (
        "accepted_findings", "candidate_observations", "rejected_observations",
        "unresolved_observations", "aliases",
    ):
        value = certificate.get(field)
        if value in (None, "") and isinstance(units.get(field), dict):
            value = units[field].get("count")
        if value not in (None, ""):
            try:
                result[field] = max(0, int(value))
            except (TypeError, ValueError):
                failures.append(f"legacy certificate field {field} is not an integer: {value!r}")
    return result, failures, warnings


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()




def _hash_interval(path: Path, start: int, length: int) -> str:
    digest = hashlib.sha256()
    remaining = length
    with path.open("rb") as handle:
        handle.seek(start)
        while remaining:
            chunk = handle.read(min(1024 * 1024, remaining))
            if not chunk:
                raise EOFError("interval extends beyond retained source")
            digest.update(chunk)
            remaining -= len(chunk)
    return digest.hexdigest()


def _verify_finding_hash(output: Path, finding: Mapping[str, Any]) -> tuple[bool | None, str]:
    """Verify a finding hash only against its declared byte scope.

    ``sha256`` is frequently the hash of a sub-record, file slack, carved output
    or decoded object rather than the entire provenance source.  Comparing it to
    the full source file creates false failures.  Current results should emit
    ``hash_path``/``hash_scope`` or an exact interval; legacy ambiguous records
    are reported as unverifiable rather than guessed.
    """
    metadata = finding.get("metadata") if isinstance(finding.get("metadata"), dict) else {}
    source_value = metadata.get("provenance_source_path") or metadata.get("source_path") or metadata.get("file_path")
    digest_key = next((key for key in ("source_hash", "file_sha256", "interval_sha256", "sha256")
                       if HEX64.fullmatch(str(metadata.get(key) or ""))), "")
    digest = str(metadata.get(digest_key) or "").lower()
    if not HEX64.fullmatch(digest):
        return None, "no SHA-256 declared"

    # Explicit full-file or retained-output hash path wins.
    hash_value = metadata.get("hash_path") or metadata.get("carved_path") or metadata.get("output_path")
    if hash_value:
        retained = _resolve_retained_path(output, hash_value)
        if retained is None:
            return False, f"declared hash path is not retained: {hash_value}"
        return _hash_file(retained) == digest, str(hash_value)

    source = _resolve_retained_path(output, source_value)
    if source is None:
        return None, "provenance source not retained in verification bundle"
    scope = str(metadata.get("hash_scope") or "").casefold()
    # file_sha256/source_hash conventionally identify the complete retained file.
    if digest_key in {"file_sha256", "source_hash"} or scope in {"full_file", "full_source", "provenance_source"}:
        return _hash_file(source) == digest, str(source_value)

    start_value = next((metadata.get(key) for key in (
        "source_start", "source_offset", "raw_offset", "offset_bytes", "byte_offset"
    ) if metadata.get(key) not in (None, "")), None)
    length_value = next((metadata.get(key) for key in (
        "source_length", "byte_length", "structured_length"
    ) if metadata.get(key) not in (None, "")), None)
    if digest_key == "interval_sha256" or scope in {"interval", "byte_interval", "source_interval"}:
        if start_value is None or length_value is None:
            return False, "interval hash declared without start/length"
        try:
            actual = _hash_interval(source, int(start_value), int(length_value))
        except Exception as exc:
            return False, f"declared source interval could not be verified: {exc}"
        return actual == digest, f"{source_value}#bytes={start_value}+{length_value}"
    return None, "hash scope is ambiguous; full-source comparison intentionally skipped"


def _carver_invariants(
    module: str,
    module_dir: Path,
    output: Path,
    records: list[dict[str, Any]],
    failures: list[str],
) -> None:
    """Validate every retained specialist-carver candidate and summary.

    Current v2 reconciliation manifests are authoritative because they retain
    accepted, rejected *and* unresolved outputs.  Legacy bundles are checked
    against their candidate ledger without pretending the older manifest had
    fields it did not emit.
    """
    if module not in {"foremost_carver", "scalpel_carver"}:
        return
    manifest_path = module_dir / ("foremost_manifest.json" if module == "foremost_carver" else "scalpel_manifest.json")
    manifest: Mapping[str, Any] = {}
    if manifest_path.is_file():
        loaded = _json(manifest_path)
        if isinstance(loaded, Mapping):
            manifest = loaded
    current = str(manifest.get("schema") or "") == "autoforensics-carver-reconciliation-v2"

    if current:
        files = manifest.get("files") if isinstance(manifest.get("files"), list) else []
        reconciliation = manifest.get("reconciliation") if isinstance(manifest.get("reconciliation"), Mapping) else {}
        states = {"ACCEPTED": 0, "REJECTED": 0, "UNRESOLVED": 0}
        source = _resolve_retained_path(output, manifest.get("analysis_source"))
        source_size = source.stat().st_size if source is not None else None
        externally_anchored = False
        if source is None:
            # Verification bundles intentionally omit the original evidence image.
            # That is acceptable only when the manifest carries both the logical
            # media digest and the original source-container digest, plus an explicit
            # policy saying external evidence is required for interval replay.
            analysis_digest = str(
                manifest.get("analysis_source_sha256") or manifest.get("logical_media_sha256") or ""
            ).lower()
            container_digest = str(manifest.get("source_container_sha256") or "").lower()
            container_path = str(manifest.get("source_container_path") or "").strip()
            retention_policy = str(manifest.get("source_retention_policy") or "").strip().upper()
            try:
                declared_source_size = int(manifest.get("source_image_bytes"))
            except (TypeError, ValueError):
                declared_source_size = 0
            if (
                HEX64.fullmatch(analysis_digest)
                and HEX64.fullmatch(container_digest)
                and container_path
                and declared_source_size > 0
                and retention_policy == "EXTERNAL_EVIDENCE_REQUIRED_FOR_INTERVAL_REPLAY"
            ):
                externally_anchored = True
                source_size = declared_source_size
            else:
                failures.append(
                    f"{module}: reconciliation source is not retained and no complete external-evidence cryptographic anchor is declared"
                )
        seen_rows: set[tuple[Any, ...]] = set()
        for index, item in enumerate(files):
            if not isinstance(item, Mapping):
                failures.append(f"{module}: manifest file row {index} is not an object")
                continue
            state = str(item.get("final_state") or "").upper()
            if state not in states:
                failures.append(f"{module}: manifest row {index} has invalid final_state {state!r}")
                continue
            states[state] += 1
            key = (item.get("output_name"), item.get("source_start"), item.get("output_sha256"))
            if key in seen_rows:
                failures.append(f"{module}: duplicate reconciliation row {key}")
            seen_rows.add(key)
            output_path = _resolve_retained_path(output, item.get("output_path"))
            digest = str(item.get("output_sha256") or "").lower()
            if output_path is None:
                if state != "UNRESOLVED" or str(item.get("resolution_reason") or "") != "retained carver output is missing":
                    failures.append(f"{module}: row {index} retained output is missing without an exact unresolved reason")
            else:
                if not HEX64.fullmatch(digest):
                    failures.append(f"{module}: row {index} has no valid output SHA-256")
                elif _hash_file(output_path) != digest:
                    failures.append(f"{module}: row {index} output SHA-256 mismatch")

            start_value, length_value, end_value = item.get("source_start"), item.get("source_length"), item.get("source_end")
            if state != "UNRESOLVED" or start_value not in (None, ""):
                try:
                    start, length, end = int(start_value), int(length_value), int(end_value)
                except (TypeError, ValueError):
                    failures.append(f"{module}: row {index} lacks a valid source interval")
                else:
                    if start < 0 or length <= 0 or end != start + length:
                        failures.append(f"{module}: row {index} has inconsistent source interval")
                    if source_size is not None and end > source_size and state != "REJECTED":
                        failures.append(f"{module}: row {index} outside source is not rejected")
                    interval_digest = str(item.get("source_interval_sha256") or "").lower()
                    if not HEX64.fullmatch(interval_digest):
                        failures.append(f"{module}: row {index} has no valid interval SHA-256")
                    elif source is not None and 0 <= start < end <= source.stat().st_size:
                        if _hash_interval(source, start, length) != interval_digest:
                            failures.append(f"{module}: row {index} interval SHA-256 mismatch")
                    elif externally_anchored:
                        # Without the external evidence bytes we cannot replay the
                        # interval inside this verification subset.  We can still
                        # prove the retained carved output hash equals the declared
                        # source-interval hash and bind that interval to the separately
                        # hashed logical/source container for independent re-examination.
                        if state == "ACCEPTED" and digest and digest != interval_digest:
                            failures.append(f"{module}: row {index} retained output/source interval hashes disagree under external-evidence anchor")
                    if digest and interval_digest and digest != interval_digest and state == "ACCEPTED":
                        failures.append(f"{module}: row {index} output/source interval hashes disagree")

            structural = item.get("structural_validation") if isinstance(item.get("structural_validation"), Mapping) else {}
            if state == "ACCEPTED":
                if structural.get("valid") is not True:
                    failures.append(f"{module}: accepted row {index} lacks successful structural validation")
                try:
                    if int(item.get("structured_length")) != int(item.get("candidate_size_bytes")):
                        failures.append(f"{module}: accepted row {index} does not end at the validated object boundary")
                except (TypeError, ValueError):
                    failures.append(f"{module}: accepted row {index} lacks deterministic boundary lengths")
            if module == "scalpel_carver":
                if not isinstance(item.get("unique_to_scalpel"), bool):
                    failures.append(f"{module}: row {index} unique_to_scalpel is not Boolean")
                if not isinstance(item.get("matched_foremost_hashes"), list):
                    failures.append(f"{module}: row {index} matched_foremost_hashes is not a list")

        declared = reconciliation.get("state_counts") if isinstance(reconciliation.get("state_counts"), Mapping) else {}
        for state, count in states.items():
            try:
                if int(declared.get(state)) != count:
                    failures.append(f"{module}: reconciliation {state} count {declared.get(state)!r} != manifest rows {count}")
            except (TypeError, ValueError):
                failures.append(f"{module}: reconciliation {state} count is absent or invalid")
        if bool(reconciliation.get("all_candidates_resolved")) != (states["UNRESOLVED"] == 0):
            failures.append(f"{module}: all_candidates_resolved disagrees with unresolved row count")
        try:
            total = sum(int(item.get("candidate_size_bytes") or 0) for item in files if isinstance(item, Mapping))
            if int(reconciliation.get("total_candidate_output_bytes")) != total:
                failures.append(f"{module}: total candidate output bytes do not reconcile")
        except (TypeError, ValueError):
            failures.append(f"{module}: total candidate output byte metric is invalid")
        return

    # Legacy diagnostic path.  It cannot prove current v2 reconciliation but it
    # still catches malformed intervals, hashes and Scalpel type errors.
    seen_ids: set[str] = set()
    for index, record in enumerate(records):
        metadata = record.get("metadata") if isinstance(record.get("metadata"), dict) else {}
        candidate_id = str(record.get("candidate_id") or "")
        if not candidate_id:
            failures.append(f"{module}: candidate {index} has no candidate_id")
        elif candidate_id in seen_ids:
            failures.append(f"{module}: duplicate candidate_id {candidate_id}")
        else:
            seen_ids.add(candidate_id)
        start_value = next((metadata.get(key) for key in (
            "source_start", "source_offset", "offset", "offset_bytes", "raw_offset",
        ) if metadata.get(key) not in (None, "")), None)
        length_value = next((metadata.get(key) for key in (
            "source_length", "structured_length", "size_bytes", "length",
        ) if metadata.get(key) not in (None, "")), None)
        end_value = metadata.get("source_end")
        try:
            start, length = int(start_value), int(length_value)
        except (TypeError, ValueError):
            failures.append(f"{module}: candidate {candidate_id or index} lacks a valid source start/length")
            continue
        if start < 0 or length <= 0:
            failures.append(f"{module}: candidate {candidate_id or index} has invalid interval {start}+{length}")
        if end_value not in (None, ""):
            try:
                if int(end_value) != start + length:
                    failures.append(f"{module}: candidate {candidate_id or index} source_end disagrees with start+length")
            except (TypeError, ValueError):
                failures.append(f"{module}: candidate {candidate_id or index} source_end is not an integer")
        carved = _resolve_retained_path(output, metadata.get("carved_path") or record.get("artifact_path"))
        expected = str(metadata.get("sha256") or metadata.get("file_sha256") or "").lower()
        if carved is None:
            failures.append(f"{module}: candidate {candidate_id or index} carved output is not retained")
        elif not HEX64.fullmatch(expected):
            failures.append(f"{module}: candidate {candidate_id or index} has no valid output SHA-256")
        elif _hash_file(carved) != expected:
            failures.append(f"{module}: candidate {candidate_id or index} output SHA-256 mismatch")
        if module == "scalpel_carver":
            if not isinstance(metadata.get("unique_to_scalpel"), bool):
                failures.append(f"{module}: candidate {candidate_id or index} unique_to_scalpel is not Boolean")
            if not isinstance(metadata.get("matched_foremost_hashes"), list):
                failures.append(f"{module}: candidate {candidate_id or index} matched_foremost_hashes is not a list")


def _report_checks(output: Path, failures: list[str], warnings: list[str]) -> dict[str, Any]:
    path = _report_json(output)
    result: dict[str, Any] = {"path": str(path) if path else None, "checked": False}
    if path is None:
        warnings.append("stable report JSON not found; report semantic checks skipped")
        return result
    report = _json(path)
    result["checked"] = True
    meta = report.get("report_metadata") if isinstance(report, dict) else {}
    meta = meta if isinstance(meta, dict) else {}
    for call in meta.get("api_calls") or []:
        if not isinstance(call, dict):
            continue
        if call.get("success") and all(
            call.get(key) in (0, 0.0, "0", "0.0", None, "")
            for key in ("input_tokens", "output_tokens", "duration_ms")
        ):
            failures.append("report: successful AI call has misleading all-zero telemetry")
    full = json.dumps(report, ensure_ascii=False).casefold()
    if "administrative appendices incomplete" not in full and any(
        text in full for text in (
            "authorisation letter — not provided", "examiner signature — not provided",
            "evidence bag photos — not provided",
        )
    ):
        failures.append("report: missing administrative files are not clearly labelled as an unsigned draft")
    if "potential steganography indicator" in full and "steganographic_payload_decoded" in full:
        failures.append("report: decoded payload and unresolved steganography indicator contradict each other")
    result["sha256"] = _hash_file(path)
    return result


def audit_output(output: Path, *, strict_schema: bool) -> dict[str, Any]:
    failures: list[str] = []
    warnings: list[str] = []
    rows: list[dict[str, Any]] = []
    contracts = load_scope_contracts()
    module_paths = sorted(output.glob("module_output/*/*/module_result.json"))
    if not module_paths:
        failures.append("no module_result.json files found")

    legacy_schemas: set[str] = set()
    for module_result_path in module_paths:
        try:
            data = _json(module_result_path)
        except Exception as exc:
            failures.append(f"{module_result_path}: unreadable module result: {exc}")
            continue
        if not isinstance(data, dict):
            failures.append(f"{module_result_path}: module result is not a JSON object")
            continue
        module = str(data.get("module_name") or data.get("module") or module_result_path.parent.name)
        candidate_path = module_result_path.parent / "candidate_observations.json"
        ledger, state_counts, ledger_error = load_candidate_records(
            module, candidate_path if candidate_path.is_file() else None
        )
        if ledger_error:
            failures.append(f"{module}: candidate ledger could not be normalised: {ledger_error}")

        stats = data.get("statistics") if isinstance(data.get("statistics"), dict) else {}
        derived = build_canonical_counts(
            accepted_findings=data.get("findings") or [],
            candidate_records=ledger,
            statistics=stats,
            limitations=stats.get("limitations") or stats.get("known_limitations"),
        )
        validation = validate_canonical_counts(derived)
        if not validation.valid:
            failures.extend(f"{module}: {error}" for error in validation.errors)

        if derived["candidate_observations"] != state_counts.get("CANDIDATE", 0):
            failures.append(f"{module}: canonical candidate count disagrees with ledger state count")
        if derived["rejected_observations"] != state_counts.get("REJECTED", 0):
            failures.append(f"{module}: canonical rejected count disagrees with ledger state count")
        if derived["unresolved_observations"] != state_counts.get("UNRESOLVED", 0):
            failures.append(f"{module}: canonical unresolved count disagrees with ledger state count")

        certificate = ((stats.get("completion_certificate") or {}) if isinstance(stats, dict) else {})
        schema = str(certificate.get("schema") or "")
        if schema != CURRENT_CERTIFICATE_SCHEMA:
            legacy_schemas.add(schema or "<missing>")
        cert_counts, cert_failures, cert_warnings = _certificate_counts(
            certificate, derived, strict_schema=strict_schema,
        )
        failures.extend(f"{module}: {item}" for item in cert_failures)
        # Avoid 46 repeated legacy warnings while preserving per-module diagnostics in rows.
        warnings.extend(f"{module}: {item}" for item in cert_warnings if strict_schema)

        fields_to_compare = CANONICAL_COUNT_FIELDS if schema == CURRENT_CERTIFICATE_SCHEMA else (
            "accepted_findings", "candidate_observations", "rejected_observations",
            "unresolved_observations",
        )
        for field in fields_to_compare:
            if int(cert_counts[field]) != int(derived[field]):
                failures.append(
                    f"{module}: certificate {field} {cert_counts[field]} != ledger/result {derived[field]}"
                )

        emitted_counts = stats.get("canonical_counts") if isinstance(stats.get("canonical_counts"), dict) else None
        if emitted_counts is not None:
            emitted_validation = validate_canonical_counts(emitted_counts)
            if not emitted_validation.valid:
                failures.extend(f"{module}: statistics canonical_counts: {error}" for error in emitted_validation.errors)
            else:
                for field in CANONICAL_COUNT_FIELDS:
                    if int(emitted_counts[field]) != int(derived[field]):
                        failures.append(
                            f"{module}: statistics canonical_counts.{field} {emitted_counts[field]} "
                            f"!= ledger/result {derived[field]}"
                        )
        elif strict_schema:
            failures.append(f"{module}: statistics canonical_counts block is missing")

        assurance = str(certificate.get("evidence_assurance") or "")
        release = str(certificate.get("release_status") or certificate.get("final_status") or "")
        if (
            derived["candidate_observations"] or derived["unresolved_observations"]
        ) and assurance == "SCOPED_ABSENCE":
            failures.append(f"{module}: SCOPED_ABSENCE conflicts with retained candidate evidence")
        if (
            contracts.get(module, {}).get("block_unresolved_candidates", True)
            and derived["unresolved_observations"]
            and release == "PASS_COMPLETE"
        ):
            failures.append(f"{module}: unresolved observations incorrectly pass strict completion")

        for finding in data.get("findings") or []:
            if not isinstance(finding, dict):
                continue
            metadata = finding.get("metadata") if isinstance(finding.get("metadata"), dict) else {}
            verified, detail = _verify_finding_hash(output, finding)
            if verified is False:
                failures.append(f"{module}: finding hash verification failed for {detail}")
            if module == "artifact_extractor":
                parse_status = str(metadata.get("parse_status") or "").casefold()
                description = str(finding.get("description") or "").casefold()
                if parse_status in {"too_short", "invalid", "malformed"} and (
                    "valid shell link" in description or "parsed lnk artefact" in description
                ):
                    failures.append("artifact_extractor: incomplete LNK-like marker is overstated as a valid Shell Link")

        _carver_invariants(module, module_result_path.parent, output, ledger, failures)
        rows.append({
            "module": module,
            "module_result": str(module_result_path.relative_to(output)),
            "certificate_schema": schema,
            "canonical_count_schema": CANONICAL_COUNT_SCHEMA,
            "canonical_counts": derived,
            "certificate_counts": cert_counts,
            "state_counts": state_counts,
            "assurance": assurance,
            "release_status": release,
        })

    if legacy_schemas and not strict_schema:
        warnings.append(
            "legacy completion certificate schema(s) present: "
            + ", ".join(sorted(legacy_schemas))
            + f"; a fresh run must emit {CURRENT_CERTIFICATE_SCHEMA} before strict release"
        )

    report_result = _report_checks(output, failures, warnings)
    return {
        "schema": "autoforensics-h2-semantic-audit-v2",
        "canonical_count_schema": CANONICAL_COUNT_SCHEMA,
        "strict_schema": strict_schema,
        "passed": not failures,
        "audit_completed": True,
        "failures": failures,
        "warnings": warnings,
        "module_count": len(rows),
        "modules": rows,
        "report": report_result,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--write", type=Path)
    parser.add_argument(
        "--strict-schema", action="store_true",
        help=f"Require {CURRENT_CERTIFICATE_SCHEMA} and statistics canonical_counts for every module",
    )
    args = parser.parse_args()
    output = args.output.resolve()
    result: dict[str, Any]
    try:
        result = audit_output(output, strict_schema=args.strict_schema)
    except Exception as exc:  # final fail-closed envelope: always retain diagnostics
        result = {
            "schema": "autoforensics-h2-semantic-audit-v2",
            "canonical_count_schema": CANONICAL_COUNT_SCHEMA,
            "strict_schema": bool(args.strict_schema),
            "passed": False,
            "audit_completed": False,
            "failures": [f"audit execution error: {type(exc).__name__}: {exc}"],
            "warnings": [],
            "module_count": 0,
            "modules": [],
            "traceback": traceback.format_exc(),
        }
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(json.dumps(result, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    for item in result.get("failures") or []:
        print("[FAIL]", item)
    for item in result.get("warnings") or []:
        print("[WARN]", item)
    print(
        f"H2 SEMANTIC AUDIT: {'PASSED' if result.get('passed') else 'FAILED'} "
        f"({len(result.get('failures') or [])} failure(s), {len(result.get('warnings') or [])} warning(s))"
    )
    if not result.get("audit_completed"):
        return 2
    return 0 if result.get("passed") else 1


if __name__ == "__main__":
    raise SystemExit(main())
