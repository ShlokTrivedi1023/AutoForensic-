#!/usr/bin/env python3
"""Independent verifier for an AutoForensics custody ledger and HMAC seal."""
from __future__ import annotations
import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
import argparse
from core.custody_log import CustodyLogger


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", required=True, type=Path)
    parser.add_argument("--seal", required=True, type=Path)
    parser.add_argument("--key-file", required=True, type=Path)
    args = parser.parse_args()
    ok, message = CustodyLogger.verify_seal_files(args.ledger, args.seal, args.key_file)
    print(("CUSTODY VERIFICATION PASSED: " if ok else "CUSTODY VERIFICATION FAILED: ") + message)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
