#!/usr/bin/env python3
"""Run a prepared case with zsh-safe secret prompts.

The wrapper captures the investigator password itself and passes it through the
process environment to a deliberately non-interactive child.  This remains
reliable when the command is pasted through a here-document or another wrapper
whose standard input is not a TTY.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]




def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _iter_path_records(value, prefix: str = ""):
    """Yield ``(key_path, path_value)`` pairs from structured module data."""
    if isinstance(value, dict):
        for key, child in value.items():
            key_l = str(key).casefold()
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(child, str) and any(
                token in key_l for token in (
                    "path", "file", "artifact", "report", "manifest", "output",
                    "transcript", "database", "source",
                )
            ):
                yield child_prefix, child
            yield from _iter_path_records(child, child_prefix)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _iter_path_records(child, f"{prefix}[{index}]")


def _collect_verification_artifacts(output: Path) -> tuple[list[Path], dict]:
    """Collect retained output artefacts and state hand-off scope honestly.

    The verification archive authenticates the sealed report, ledgers and
    retained derivatives.  It is not a replacement for the original evidence.
    Accepted findings must not reference a missing *internal* support file.  An
    original-evidence path outside the sealed output is retained as a hash/
    locator reference and makes the archive a verification subset rather than a
    self-contained reproduction corpus.
    """
    output.mkdir(parents=True, exist_ok=True)
    include: dict[str, Path] = {}
    unavailable_index: dict[tuple[str, str, str], dict] = {}
    output_resolved = output.resolve()
    max_file = int(os.environ.get("AUTOFORENSICS_BUNDLE_MAX_FILE_BYTES", str(512 * 1024 * 1024)))
    max_total = int(os.environ.get("AUTOFORENSICS_BUNDLE_MAX_TOTAL_BYTES", str(4 * 1024 * 1024 * 1024)))
    total = 0

    required_internal_missing: list[dict] = []
    external_source_references: list[dict] = []

    def record_unavailable(
        path_value: str,
        source: str,
        reason: str,
        category: str,
        *,
        required_for_accepted_finding: bool = False,
        size_bytes: int | None = None,
    ) -> None:
        record = {
            "path": path_value,
            "source": source,
            "reason": reason,
            "category": category,
            "required_for_accepted_finding": bool(required_for_accepted_finding),
        }
        if size_bytes is not None:
            record["size_bytes"] = int(size_bytes)
        key = (str(path_value), str(source), str(category))
        unavailable_index.setdefault(key, record)
        if category == "external_source_reference":
            external_source_references.append(record)
        if required_for_accepted_finding and category in {
            "missing_internal_support", "excluded_internal_support",
        }:
            required_internal_missing.append(record)

    def add(path_value: str, source: str, *, required_internal: bool = False) -> None:
        nonlocal total
        if not str(path_value or "").strip():
            return
        # Ignore logical evidence labels and URI-like locators. They are not
        # local files and must not be represented as missing bundle members.
        value = str(path_value).strip().split("#L", 1)[0]
        if "://" in value or value.startswith(("urn:", "memory:", "packet:")):
            return
        try:
            path = Path(value).expanduser().resolve()
        except (OSError, RuntimeError):
            record_unavailable(value, source, "invalid local path", "invalid_reference", required_for_accepted_finding=required_internal)
            return

        # A non-existent absolute path below the output is missing retained
        # support. A relative/logical path outside it is merely an evidence
        # locator and is not treated as an archive defect.
        try:
            is_internal = path == output_resolved or path.is_relative_to(output_resolved)
        except AttributeError:
            try:
                path.relative_to(output_resolved)
                is_internal = True
            except ValueError:
                is_internal = False

        if not path.exists():
            category = "missing_internal_support" if is_internal else "external_source_reference"
            reason = "referenced internal support was not retained" if is_internal else "original/external evidence represented by hash and locator only"
            record_unavailable(str(path), source, reason, category, required_for_accepted_finding=(required_internal and is_internal))
            return

        candidates = [path]
        if path.is_dir():
            candidates = [item for item in path.rglob("*") if item.is_file()]
        for item in candidates:
            try:
                item.relative_to(output_resolved)
                item_internal = True
            except ValueError:
                item_internal = False
            if not item_internal:
                record_unavailable(
                    str(item), source,
                    "original/external evidence represented by hash and exact locator only",
                    "external_source_reference",
                    required_for_accepted_finding=False,
                    size_bytes=(item.stat().st_size if item.is_file() else None),
                )
                continue
            if not item.is_file():
                record_unavailable(
                    str(item), source, "referenced internal support is not a regular file",
                    "missing_internal_support", required_for_accepted_finding=required_internal,
                )
                continue
            size = item.stat().st_size
            if size > max_file or total + size > max_total:
                record_unavailable(
                    str(item), source, "bundle size policy",
                    "excluded_internal_support", required_for_accepted_finding=required_internal,
                    size_bytes=size,
                )
                continue
            key = str(item)
            if key not in include:
                include[key] = item
                total += size

    for result_path in output.glob("module_output/**/module_result.json"):
        add(str(result_path), "module_result", required_internal=True)
        try:
            data = json.loads(result_path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue

        # A reconciled module_result contains canonical findings only. Their
        # retained artifact/report/transcript support is mandatory when it lives
        # inside the sealed output. Original evidence_path/source_path values are
        # expected to remain external and are represented by hashes/locators.
        for index, finding in enumerate(data.get("findings") or []):
            finding_source = f"{result_path.relative_to(output)}:findings[{index}]"
            artifact_value = finding.get("artifact_path")
            if artifact_value:
                add(str(artifact_value), f"{finding_source}.artifact_path", required_internal=True)
            metadata = finding.get("metadata") or {}
            for key_path, value in _iter_path_records(metadata, "metadata"):
                key_l = key_path.casefold()
                mandatory = any(token in key_l for token in (
                    "report_file", "manifest", "artifact", "derived_artifact",
                    "transcript", "validation_report", "parser_output",
                ))
                add(value, f"{finding_source}.{key_path}", required_internal=mandatory)
            if finding.get("evidence_path"):
                add(str(finding["evidence_path"]), f"{finding_source}.evidence_path", required_internal=False)

        for index, value in enumerate(data.get("artifact_paths") or []):
            add(str(value), f"{result_path.relative_to(output)}:artifact_paths[{index}]", required_internal=True)

        # Other structured path references remain useful provenance, but are not
        # automatically mandatory unless they were attached to an accepted
        # finding or declared as a module artifact path above.
        for key_path, value in _iter_path_records(data):
            add(value, f"{result_path.relative_to(output)}:{key_path}", required_internal=False)

    # Include module manifests, candidate files and exact support reports even
    # when an older module omitted them from artifact_paths.
    for pattern in (
        "module_output/**/*.json", "module_output/**/*.jsonl",
        "module_output/**/*.csv", "module_output/**/*.tsv",
        "module_output/**/*.txt", "module_output/**/*.kml",
        "module_output/**/*.geojson",
    ):
        for path in output.glob(pattern):
            if path.is_file():
                add(str(path), "module support file", required_internal=False)

    unavailable = list(unavailable_index.values())
    reason_counts: dict[str, int] = {}
    for record in unavailable:
        reason_counts[record["category"]] = reason_counts.get(record["category"], 0) + 1

    accepted_support_complete = not required_internal_missing
    if not accepted_support_complete:
        reproducibility_status = "PARTIAL_REPRODUCIBILITY"
    elif external_source_references:
        reproducibility_status = "VERIFICATION_SUBSET"
    else:
        reproducibility_status = "SELF_CONTAINED_OUTPUT_VERIFICATION"

    manifest = {
        "schema_version": 2,
        "bundle_scope": (
            "Sealed reports, public verification material, custody records, module results, "
            "candidate observations and retained supporting derivatives. Original evidence "
            "and private signing/HMAC keys are deliberately excluded."
        ),
        "policy": (
            "Every retained internal support file attached to a canonical finding must be bundled. "
            "Original/external evidence remains represented by cryptographic hashes and exact locators."
        ),
        "reproducibility_status": reproducibility_status,
        "accepted_finding_support_complete": accepted_support_complete,
        "source_evidence_included": False,
        "included_file_count": len(include),
        "included_total_bytes": total,
        "limits": {"max_file_bytes": max_file, "max_total_bytes": max_total},
        "not_bundled_counts": reason_counts,
        "required_internal_support_missing": required_internal_missing,
        "files": [
            {"path": str(path.relative_to(output_resolved)), "size_bytes": path.stat().st_size, "sha256": _sha256(path)}
            for path in sorted(include.values())
        ],
        "not_bundled": unavailable,
    }
    manifest_path = output / "verification_artifact_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8")
    include[str(manifest_path)] = manifest_path
    return sorted(include.values()), manifest


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--case-file", type=Path, default=ROOT / "case.json")
    p.add_argument("--investigator-id", default="examiner")
    p.add_argument("--provider", choices=["openai", "none"], default="none")
    p.add_argument("--model", default="gpt-4o-mini")
    p.add_argument("--output-dir", type=Path)
    p.add_argument("--no-require-llm", action="store_true")
    args = p.parse_args()

    case_file = args.case_file.expanduser().resolve()
    if not case_file.is_file():
        raise SystemExit(f"Case file not found: {case_file}")

    env = os.environ.copy()
    env["LLM_PROVIDER"] = args.provider
    if args.provider == "openai":
        env["OPENAI_MODEL"] = args.model
        key = env.get("OPENAI_API_KEY", "") or getpass.getpass("OpenAI API key: ")
        if not key:
            raise SystemExit("No OpenAI API key was supplied.")
        env["OPENAI_API_KEY"] = key
        check = subprocess.run(
            [sys.executable, str(ROOT / "tools" / "check_openai_configuration.py"),
             "--case-file", str(case_file), "--live"],
            cwd=ROOT, env=env,
        )
        if check.returncode != 0:
            return check.returncode
    else:
        env["LLM_PROVIDER"] = "none"
        env.pop("OPENAI_API_KEY", None)

    case_id = "CASE"
    try:
        case_id = str(json.loads(case_file.read_text(encoding="utf-8")).get("case_number") or case_id)
    except Exception:
        pass
    output = args.output_dir
    if output is None:
        output = ROOT / f"output_{case_id}_RERUN_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    output = output.expanduser().resolve()

    investigator_password = env.get("AUTOFORENSICS_PASSWORD", "")
    if not investigator_password:
        investigator_password = getpass.getpass(
            f"AutoForensics password for investigator '{args.investigator_id}': "
        )
    if not investigator_password:
        raise SystemExit("No AutoForensics investigator password was supplied.")
    env["AUTOFORENSICS_PASSWORD"] = investigator_password
    env["AUTOFORENSICS_INVESTIGATOR_ID"] = args.investigator_id

    command = [
        sys.executable, str(ROOT / "run.py"),
        "--case-file", str(case_file),
        "--investigator-id", args.investigator_id,
        "--output-dir", str(output),
        "--non-interactive",
        "--skip-check",
    ]
    if args.provider == "openai" and not args.no_require_llm:
        command.append("--require-llm")

    print("Starting complete investigation.")
    print("Investigator authentication was captured securely by the ready-case wrapper.")
    print(f"Output directory: {output}")
    try:
        completed = subprocess.run(command, cwd=ROOT, env=env)
    finally:
        env.pop("AUTOFORENSICS_PASSWORD", None)
        investigator_password = ""
    if completed.returncode != 0:
        return completed.returncode

    # For the controlled development fixture, run a strict post-generation gate
    # before packaging. This prevents a structurally valid report with known
    # precision/verdict inconsistencies from being presented as a successful
    # synthetic validation result.
    synthetic_metrics = output / "synthetic_validation_metrics.json"
    fixture_profile = ROOT / "validation" / "fixtures" / f"{case_id}_ground_truth.json"
    if fixture_profile.is_file():
        validation = subprocess.run(
            [sys.executable, str(ROOT / "tools" / "validate_synthetic_testcase.py"),
             "--output-dir", str(output),
             "--ground-truth", str(fixture_profile)],
            cwd=ROOT, env=env,
        )
        if validation.returncode != 0:
            print("\nSynthetic ground-truth validation failed; verification bundle was not approved.")
            return validation.returncode

    # Produce a compact verification bundle without private signing or HMAC
    # keys. This makes the PDF/JSON, per-module JSON, custody ledger/seal,
    # completion receipt and public verification key easy to submit together.
    bundle = output.parent / f"{output.name}_VERIFICATION_BUNDLE.zip"
    supporting, artifact_manifest = _collect_verification_artifacts(output)
    if not artifact_manifest.get("accepted_finding_support_complete", False):
        print("\nVerification bundle was not approved: one or more canonical findings reference missing internal support files.")
        print("See verification_artifact_manifest.json for required_internal_support_missing.")
        return 2
    include: list[Path] = list(supporting)
    patterns = [
        "reports/*_report.pdf",
        "reports/*_report.json",
        "reports/*_report_manifest.json",
        "reports/*_report_signature.json",
        "reports/*_report_signing_public.pem",
        "reports/*_ai_policy.json",
        "*_custody.jsonl",
        "*_custody_seal.json",
        "*_completion_manifest.json",
        "*_findings.jsonl",
        "pipeline_manifest_ev*.json",
        "module_output/**/module_result.json",
        "proposal_capability_report.json",
        "synthetic_validation_metrics.json",
        "synthetic_ground_truth_used.json",
    ]
    for pattern in patterns:
        include.extend(path for path in output.glob(pattern) if path.is_file())
    seen: set[str] = set()
    with zipfile.ZipFile(
        bundle,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        allowZip64=True,
        strict_timestamps=False,
    ) as archive:
        for path in sorted(include):
            resolved = str(path.resolve())
            if resolved in seen:
                continue
            seen.add(resolved)
            archive.write(path, path.relative_to(output))

    # Fail closed if the generated hand-off archive is corrupt.  ZIP metadata
    # timestamps are normalised only in the archive header; original retained
    # artefact timestamps and hashes remain unchanged in the sealed output.
    with zipfile.ZipFile(bundle, "r") as verification_archive:
        bad_member = verification_archive.testzip()
    if bad_member:
        print(f"Verification bundle integrity check failed at: {bad_member}")
        return 2

    print("\nInvestigation and cryptographic verification completed.")
    print(f"Verification bundle: {bundle}")
    print("Private report-signing and custody-HMAC keys were not included.")
    print(f"Bundle scope status: {artifact_manifest.get('reproducibility_status', 'UNKNOWN')}")
    print(f"Accepted-finding internal support complete: {artifact_manifest.get('accepted_finding_support_complete', False)}")
    print(f"Supporting artefacts bundled: {artifact_manifest['included_file_count']} file(s), {artifact_manifest['included_total_bytes']} bytes.")
    if artifact_manifest.get("not_bundled"):
        counts = artifact_manifest.get("not_bundled_counts") or {}
        print(
            f"References not bundled: {len(artifact_manifest['not_bundled'])} "
            f"({', '.join(f'{key}={value}' for key, value in sorted(counts.items()))}); "
            "see verification_artifact_manifest.json."
        )
    print("This archive verifies the sealed outputs; original evidence is required for independent re-examination.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
