#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
import argparse
from core.report_signing import generate_signing_key

p=argparse.ArgumentParser(description="Generate an Ed25519 examiner signing key pair.")
p.add_argument("--private-key", required=True)
p.add_argument("--public-key", required=True)
p.add_argument("--force", action="store_true")
a=p.parse_args()
priv,pub=generate_signing_key(a.private_key,a.public_key,force=a.force)
print(f"Private key (keep secret): {priv}")
print(f"Public key: {pub}")
