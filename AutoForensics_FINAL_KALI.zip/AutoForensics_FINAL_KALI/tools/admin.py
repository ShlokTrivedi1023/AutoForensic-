#!/usr/bin/env python3
"""
tools/admin.py — Platform Administration CLI for Auto Forensics

Manages the investigators registry, verifies chain-of-custody ledger integrity,
and displays the authentication audit log.

Commands
--------
  set-admin-password      Bootstrap or reset the admin account password
  add-investigator        Register a new investigator account
  remove-investigator     Permanently delete an investigator record
  list-investigators      Display all registered investigators
  reset-password          Reset any investigator's password
  deactivate-investigator Suspend an account without deleting it
  activate-investigator   Reactivate a suspended account
  verify-chain            Re-verify a chain-of-custody .jsonl ledger hash-chain
  show-audit-log          Display the authentication attempt audit log

Security model
--------------
  - Every write operation (add, remove, reset, deactivate, activate) requires
    authentication as an account holding the 'manage_investigators' permission.
    The only exception is set-admin-password when the admin password field is
    still a PLACEHOLDER value (first-run bootstrap).
  - Passwords are hashed with PBKDF2-HMAC-SHA256 at 260,000 iterations, matching
    the algorithm in core/main.py exactly. Salts are 32 cryptographically-random
    bytes, unique per account.
  - All password comparisons use hmac.compare_digest() for constant-time equality.
  - Registry writes are atomic: written to a tempfile, then renamed into place.
    This prevents a partial write from corrupting the registry if the process
    is interrupted.
  - The registry file is set to 0o600 (owner read/write only) after every write.
  - All user-supplied strings are sanitised and pattern-checked before use.
  - No subprocess calls use shell=True (no subprocess calls at all in this file).
  - All file paths are canonicalised with Path.resolve() before any I/O.

Target platform: Kali Linux, Python 3.11+
"""

import argparse
import getpass
import hashlib
import hmac
import json
import logging
import logging.handlers
import os
import platform as _platform_check
import re
import shutil
import sys
import tempfile
from contextlib import contextmanager
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Generator, Optional

# ---------------------------------------------------------------------------
# Platform constants
# ---------------------------------------------------------------------------

# Resolve and publish the project root before importing project modules.
# Direct execution (``python3 tools/admin.py``) otherwise places only the tools
# directory on sys.path and fails to import ``core``.
_PROJECT_ROOT = Path(__file__).parent.parent.resolve()
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from core.version import VERSION

def _registry_path() -> Path:
    """Return a writable per-user registry unless explicitly overridden.

    A system-wide /etc registry caused first-run permission and stale-role
    failures on Kali.  Operators that intentionally manage a shared registry
    can still set AUTOFORENSICS_INVESTIGATORS_REGISTRY to an absolute path.
    """
    configured = os.environ.get("AUTOFORENSICS_INVESTIGATORS_REGISTRY", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    if _platform_check.system() == "Windows":
        base = Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming"))
        return (base / "AutoForensics" / "investigators.json").resolve()
    return (Path.home() / ".config" / "autoforensics" / "investigators.json").resolve()

INVESTIGATORS_REGISTRY_PATH = _registry_path()
DEFAULT_OUTPUT_DIR           = Path(os.environ.get("AUTOFORENSICS_STATE_DIR") or (Path.home() / ".local" / "state" / "autoforensics")).expanduser().resolve()

# PBKDF2 parameters — must match core/main.py exactly so hashes are portable
_PBKDF2_HASH_NAME  = "sha256"
_PBKDF2_ITERATIONS = 260_000
_PBKDF2_SALT_BYTES = 32      # 256-bit random salt per account
_PBKDF2_DK_LEN     = 32      # 256-bit derived key

# Sentinel prefix used to detect un-initialised password fields in the registry.
# Any password_hash or password_salt starting with this string is a placeholder.
_PLACEHOLDER_PREFIX = "PLACEHOLDER"

# Narrow input allowlists — prevent injection via any field that ends up in
# the registry, a log file, or a subprocess argument.
_INVESTIGATOR_ID_RE  = re.compile(r"^[A-Za-z0-9_]{1,32}$")
_BADGE_RE            = re.compile(r"^[A-Za-z0-9\-_/]{1,32}$")
_NAME_MAX_LEN        = 120
_DEPT_MAX_LEN        = 120
_NOTES_MAX_LEN       = 500

_ALLOWED_ROLES = {
    "Platform Administrator",
    "Senior Forensic Examiner",
    "Forensic Examiner",
    "Junior Forensic Examiner",
    "Forensic Analyst",
    "Law Enforcement Officer",
    "Supervisor",
}

_ALL_PERMISSIONS = {
    "conduct_investigation",
    "view_reports",
    "manage_investigators",
    "manage_modules",
    "export_evidence",
    "change_any_password",
}

# Password strength requirements
_PASSWORD_MIN_LEN  = 12
_PASSWORD_MAX_LEN  = 128


def _ensure_investigators_registry() -> None:
    """Create the resolved per-user/explicit investigator registry when missing."""
    if INVESTIGATORS_REGISTRY_PATH.exists():
        return
    project_template = _PROJECT_ROOT / "config" / "investigators.json"
    legacy_system = Path("/etc/autoforensics/investigators.json")
    try:
        INVESTIGATORS_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        migration_source = (
            legacy_system if legacy_system.is_file() and os.access(legacy_system, os.R_OK)
            else project_template
        )
        if migration_source.exists():
            shutil.copy2(migration_source, INVESTIGATORS_REGISTRY_PATH)
        else:
            INVESTIGATORS_REGISTRY_PATH.write_text(
                '{"_password_hashing":{"algorithm":"pbkdf2_hmac_sha256",'
                '"iterations":260000,"salt_bytes":32,"dk_len":32},'
                '"investigators":{"admin":{"investigator_id":"admin",'
                '"name":"Platform Administrator","badge":"ADMIN-001",'
                '"role":"Platform Administrator",'
                '"department":"IT / Forensics Platform Operations",'
                '"password_hash":"PLACEHOLDER_RUN_tools/admin.py_set-admin-password_TO_REPLACE_THIS",'
                '"password_salt":"PLACEHOLDER_RUN_tools/admin.py_set-admin-password_TO_REPLACE_THIS",'
                '"account_created":"YYYY-MM-DD","last_login":null,"active":true,'
                '"must_change_password":true,'
                '"permissions":["conduct_investigation","view_reports",'
                '"manage_investigators","manage_modules","export_evidence",'
                '"change_any_password"],'
                '"certifications":[],'
                '"notes":"Default bootstrap administrator. Disable after creating named administrator accounts."}}}',
                encoding="utf-8",
            )
        try:
            os.chmod(INVESTIGATORS_REGISTRY_PATH, 0o600)
        except OSError:
            pass  # Windows or permission denied — non-fatal
    except OSError:
        pass  # Will fail gracefully at login if still missing


# ---------------------------------------------------------------------------
# ANSI colour helpers
# Colours are only emitted when stdout is a real TTY and NO_COLOR is not set.
# This follows the https://no-color.org/ convention so scripts can suppress
# colour output cleanly.
# ---------------------------------------------------------------------------

def _supports_colour() -> bool:
    """Return True if the terminal supports ANSI colour escape sequences."""
    # Explicit opt-out via environment variable (no-color.org convention)
    if os.environ.get("NO_COLOR"):
        return False
    # Only emit colours when writing to an interactive terminal
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


_USE_COLOUR = _supports_colour()

# ANSI escape sequences — only used when _USE_COLOUR is True
_C_GREEN  = "\033[92m"   if _USE_COLOUR else ""
_C_RED    = "\033[91m"   if _USE_COLOUR else ""
_C_YELLOW = "\033[93m"   if _USE_COLOUR else ""
_C_CYAN   = "\033[96m"   if _USE_COLOUR else ""
_C_BOLD   = "\033[1m"    if _USE_COLOUR else ""
_C_DIM    = "\033[2m"    if _USE_COLOUR else ""
_C_RESET  = "\033[0m"    if _USE_COLOUR else ""


def _ok(msg: str)   -> str: return f"{_C_GREEN}{_C_BOLD}[OK]{_C_RESET}  {msg}"
def _err(msg: str)  -> str: return f"{_C_RED}{_C_BOLD}[FAIL]{_C_RESET} {msg}"
def _warn(msg: str) -> str: return f"{_C_YELLOW}{_C_BOLD}[WARN]{_C_RESET} {msg}"
def _info(msg: str) -> str: return f"{_C_CYAN}[INFO]{_C_RESET} {msg}"
def _hdr(msg: str)  -> str: return f"\n{_C_BOLD}{_C_CYAN}{msg}{_C_RESET}\n{'─' * len(msg)}"
def _dim(msg: str)  -> str: return f"{_C_DIM}{msg}{_C_RESET}"


# ---------------------------------------------------------------------------
# Logging
# Operational log for the admin tool itself. Separate from the CoC log and
# the auth audit log. Useful for debugging and incident response.
# ---------------------------------------------------------------------------

def _setup_logging() -> logging.Logger:
    """
    Configure a rotating file logger for the admin tool.

    Writes to the per-user AutoForensics state directory (DEBUG+) and to the console (WARNING+).
    The console handler is WARNING-only so routine informational messages do
    not clutter the terminal output — those are printed directly via print().
    """
    log_dir = DEFAULT_OUTPUT_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        fmt     = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt = "%Y-%m-%dT%H:%M:%S%z",
    )

    logger = logging.getLogger("autoforensics.admin")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    # Rotating file handler — keeps the last 5 × 10 MB = 50 MB of admin activity
    log_file = DEFAULT_OUTPUT_DIR / "logs" / "admin_tool.log"
    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)

    # Console handler — only warnings and errors (don't pollute print() output)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.WARNING)
    console_handler.setFormatter(fmt)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


_log = _setup_logging()


# ---------------------------------------------------------------------------
# Input validation and sanitisation
# Every user-supplied value passes through these functions before it is stored,
# logged, or compared. This is the primary defence against injection via crafted
# field values.
# ---------------------------------------------------------------------------

def _sanitize(value: str, label: str, max_len: int = 256) -> str:
    """
    Strip whitespace and enforce a maximum length on any string input.

    This is the base sanitiser — every other validator calls this first.
    Raises ValueError with a clear message so the caller can surface it
    directly to the operator without leaking internal details.
    """
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a string, got {type(value).__name__}")
    value = value.strip()
    if not value:
        raise ValueError(f"{label} cannot be empty")
    if len(value) > max_len:
        raise ValueError(
            f"{label} is too long ({len(value)} chars). Maximum is {max_len}."
        )
    return value


def _validate_investigator_id(raw: str) -> str:
    """
    Validate an investigator ID: alphanumeric + underscores, 1–32 characters.

    The narrow allowlist (no spaces, hyphens, slashes, or special characters)
    ensures the ID is safe as:
      - A JSON object key (no injection via control characters)
      - A filename component (no path traversal)
      - A log field value (no newline injection)
    """
    cleaned = _sanitize(raw, "Investigator ID", max_len=32)
    if not _INVESTIGATOR_ID_RE.match(cleaned):
        raise ValueError(
            f"Investigator ID '{cleaned}' is invalid. "
            "Use only letters, digits, and underscores (max 32 characters)."
        )
    return cleaned


def _validate_name(raw: str) -> str:
    """
    Validate a full legal name: printable characters only, max 120 chars.

    Names appear in CoC log entries and court reports. We allow the full
    printable ASCII set (plus common Unicode letters via the strip check)
    but explicitly reject control characters that could break JSON or log
    file parsers.
    """
    cleaned = _sanitize(raw, "Name", max_len=_NAME_MAX_LEN)
    # Reject any ASCII control character (0x00–0x1F, 0x7F)
    if re.search(r"[\x00-\x1f\x7f]", cleaned):
        raise ValueError("Name contains invalid control characters.")
    return cleaned


def _validate_badge(raw: str) -> str:
    """
    Validate a badge or employee number: alphanumeric + hyphens/underscores/slashes.

    Badge numbers appear in CoC logs and court reports. The allowlist prevents
    any character that could be misinterpreted as a field separator or command.
    """
    cleaned = _sanitize(raw, "Badge number", max_len=32)
    if not _BADGE_RE.match(cleaned):
        raise ValueError(
            f"Badge number '{cleaned}' is invalid. "
            "Use only letters, digits, hyphens, underscores, and forward-slashes."
        )
    return cleaned


def _validate_role(raw: str) -> str:
    """
    Validate a role against the closed enumeration of allowed roles.

    Roles are a closed set — accepting arbitrary strings would allow an
    operator to write misleading role names into court-admissible CoC records.
    """
    cleaned = _sanitize(raw, "Role", max_len=64)
    if cleaned not in _ALLOWED_ROLES:
        raise ValueError(
            f"Role '{cleaned}' is not in the allowed list.\n"
            f"Allowed roles: {', '.join(sorted(_ALLOWED_ROLES))}"
        )
    return cleaned


def _validate_department(raw: str) -> str:
    """
    Validate a department name: printable characters only, max 120 chars.

    Same control-character rejection as _validate_name — department names
    appear in CoC logs and cannot contain line-break injection characters.
    """
    cleaned = _sanitize(raw, "Department", max_len=_DEPT_MAX_LEN)
    if re.search(r"[\x00-\x1f\x7f]", cleaned):
        raise ValueError("Department name contains invalid control characters.")
    return cleaned


def _validate_password_strength(password: str) -> None:
    """
    Enforce minimum password complexity requirements.

    Requirements (all must be satisfied):
      - At least 12 characters (configurable via _PASSWORD_MIN_LEN)
      - At least one uppercase letter
      - At least one lowercase letter
      - At least one digit
      - At least one special character

    These requirements are not a security mechanism on their own — they
    exist to prevent investigators from setting trivially guessable passwords
    that would undermine the chain of custody authentication guarantee.
    A court challenge that the authentication was trivially bypassable must
    not succeed.
    """
    if len(password) < _PASSWORD_MIN_LEN:
        raise ValueError(
            f"Password must be at least {_PASSWORD_MIN_LEN} characters long."
        )
    if len(password) > _PASSWORD_MAX_LEN:
        raise ValueError(
            f"Password must not exceed {_PASSWORD_MAX_LEN} characters."
        )
    if not re.search(r"[A-Z]", password):
        raise ValueError("Password must contain at least one uppercase letter.")
    if not re.search(r"[a-z]", password):
        raise ValueError("Password must contain at least one lowercase letter.")
    if not re.search(r"\d", password):
        raise ValueError("Password must contain at least one digit.")
    if not re.search(r"[^A-Za-z0-9]", password):
        raise ValueError(
            "Password must contain at least one special character "
            "(e.g. ! @ # $ % ^ & * _ - + = ?)."
        )


# ---------------------------------------------------------------------------
# Password hashing
# Must be byte-for-byte identical to the implementation in core/main.py.
# Any divergence would make it impossible to authenticate with passwords
# set via this admin tool.
# ---------------------------------------------------------------------------

def _generate_salt() -> bytes:
    """
    Generate a cryptographically random 32-byte salt.

    os.urandom() reads from the OS CSPRNG (/dev/urandom on Linux), which is
    suitable for cryptographic key material. A fresh salt is generated for
    every account to ensure that two accounts with the same password still
    produce different stored hashes — this prevents rainbow-table attacks
    even if one account's salt is compromised.
    """
    return os.urandom(_PBKDF2_SALT_BYTES)


def _hash_password(password: str, salt: bytes) -> str:
    """
    Derive a stored password hash using PBKDF2-HMAC-SHA256.

    Parameters
    ----------
    password    Plaintext password string. Encoded to UTF-8 before hashing
                so Unicode passwords are handled consistently across platforms.
    salt        Random 32-byte salt, unique per account.

    Returns
    -------
    Lowercase hex string of the 32-byte derived key (64 hex characters).

    This function is intentionally identical to the one in core/main.py.
    260,000 iterations meets NIST SP 800-132 (2023) minimum recommendations
    for PBKDF2-SHA256. Using the stdlib implementation avoids a bcrypt/argon2
    C-extension dependency that may not be available on all Kali configurations.
    """
    dk = hashlib.pbkdf2_hmac(
        hash_name  = _PBKDF2_HASH_NAME,
        password   = password.encode("utf-8"),
        salt       = salt,
        iterations = _PBKDF2_ITERATIONS,
        dklen      = _PBKDF2_DK_LEN,
    )
    return dk.hex()


def _verify_password(password: str, stored_hash: str, stored_salt_hex: str) -> bool:
    """
    Verify a plaintext password against a stored PBKDF2 hash.

    Uses hmac.compare_digest() for constant-time equality comparison.
    This prevents timing-oracle attacks where an attacker measures response
    latency to determine how many bytes of the hash matched before the
    comparison short-circuited.

    Returns True if the password matches, False otherwise.
    """
    try:
        salt = bytes.fromhex(stored_salt_hex)
    except ValueError:
        # Stored salt is not valid hex — treat as auth failure, not a crash
        _log.error("Stored salt is not valid hex — possible registry corruption")
        return False

    candidate = _hash_password(password, salt)
    # compare_digest works on equal-length strings of equal type
    return hmac.compare_digest(candidate, stored_hash)


# ---------------------------------------------------------------------------
# Investigators registry I/O
# The registry is a JSON file. Writes are atomic (tempfile → rename) so a
# crash mid-write cannot corrupt the registry. The file is set 0o600 after
# every write.
# ---------------------------------------------------------------------------

def _load_registry() -> dict[str, Any]:
    """
    Load the investigators registry from disk.

    Raises RuntimeError on any I/O or parse failure — these are platform
    configuration errors that the operator must fix, not conditions that
    should be silently ignored.
    """
    path = INVESTIGATORS_REGISTRY_PATH.resolve()

    if not path.exists():
        raise RuntimeError(
            f"Investigators registry not found at {path}.\n"
            "Run: python3 tools/admin.py set-admin-password  (first-run setup)"
        )

    # Warn if the registry is world-readable — it contains derived password material
    stat = path.stat()
    if stat.st_mode & 0o077:
        print(_warn(
            f"Registry permissions are {oct(stat.st_mode & 0o777)} — "
            f"should be 0o600. Fix with: chmod 600 {path}"
        ))

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Registry file is not valid JSON: {exc}\n"
            f"File: {path}"
        ) from exc
    except OSError as exc:
        raise RuntimeError(f"Cannot read registry: {exc}") from exc

    if "investigators" not in data or not isinstance(data["investigators"], dict):
        raise RuntimeError(
            "Registry file is missing the 'investigators' key or it is not a dict.\n"
            "The file may be corrupt. Restore from backup."
        )

    return data


def _save_registry(data: dict[str, Any]) -> None:
    """
    Atomically write the registry to disk.

    Write strategy:
      1. Serialise to JSON in memory.
      2. Write to a named temporary file in the same directory as the registry
         (same filesystem, so rename is atomic).
      3. Set permissions on the temp file to 0o600 before the rename, so
         there is never a window where the registry is world-readable.
      4. Rename temp → registry path (atomic on POSIX).

    If any step fails, the temporary file is cleaned up and the original
    registry is untouched.
    """
    path = INVESTIGATORS_REGISTRY_PATH.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)

    serialised = json.dumps(data, indent=2, ensure_ascii=True, sort_keys=False)

    # Write to a temp file in the same directory to ensure the rename is atomic
    # (rename across filesystems is not atomic on Linux).
    tmp_fd, tmp_path_str = tempfile.mkstemp(
        dir    = str(path.parent),
        prefix = ".investigators_tmp_",
        suffix = ".json",
    )
    tmp_path = Path(tmp_path_str)

    try:
        # Set permissions before writing content — prevents any window where
        # a partially-written file with permissive permissions is visible
        os.fchmod(tmp_fd, 0o600)
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(serialised)
        # Atomic rename — replaces the target file in one syscall
        tmp_path.rename(path)
    except Exception:
        # Clean up the temp file if anything went wrong
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise

    _log.info("Registry saved to %s", path)


@contextmanager
def _registry_lock() -> Generator[None, None, None]:
    """
    Context manager that holds an exclusive advisory lock on the registry file.

    Uses fcntl.LOCK_EX (exclusive lock) to prevent concurrent admin tool
    invocations from simultaneously modifying the registry and producing a
    corrupted JSON file or a lost-update. The lock is released automatically
    when the context exits, even if an exception is raised.

    Note: This is an advisory lock — it only prevents concurrent access by
    processes that also acquire this lock. It does not prevent a process
    that bypasses the admin tool from writing directly to the file.
    """
    lock_path = INVESTIGATORS_REGISTRY_PATH.parent / ".investigators.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import fcntl  # Linux/macOS only — target platform is Kali Linux
    except ImportError:
        # Not available on Windows; fall through without locking (dev environment)
        _log.warning("fcntl not available — registry locking disabled")
        yield
        return

    with open(lock_path, "w", encoding="ascii") as lock_fh:
        try:
            fcntl.flock(lock_fh, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(lock_fh, fcntl.LOCK_UN)


# ---------------------------------------------------------------------------
# Administrator authentication
# Every write operation requires the caller to authenticate as an account
# that holds the 'manage_investigators' permission.
# ---------------------------------------------------------------------------

def _authenticate_admin(
    registry: dict[str, Any],
    prompt_prefix: str = "",
) -> dict[str, Any]:
    """
    Authenticate the operator as an administrator.

    Prompts for an investigator_id and password and verifies against the
    registry. Only accounts with 'manage_investigators' in their permissions
    list are accepted. Three consecutive failures abort the program to
    prevent brute-force attempts via the admin tool.

    Parameters
    ----------
    registry        The loaded registry dict (investigators key must be present).
    prompt_prefix   Optional label shown above the auth prompts (e.g. "Admin").

    Returns
    -------
    The authenticated investigator profile dict on success.

    Raises
    ------
    SystemExit  After three consecutive failures.
    """
    investigators = registry.get("investigators", {})
    max_attempts = 3

    if prompt_prefix:
        print(f"\n{_C_BOLD}Administrator authentication required: {prompt_prefix}{_C_RESET}")
    else:
        print(f"\n{_C_BOLD}Administrator authentication required{_C_RESET}")

    for attempt in range(1, max_attempts + 1):
        admin_id = input("Admin investigator ID: ").strip()
        # getpass hides password input — never use input() for passwords
        password  = getpass.getpass("Admin password: ")

        profile = investigators.get(admin_id)

        if profile is None:
            print(_err(f"Authentication failed ({attempt}/{max_attempts})"))
            _log.warning("Admin auth failed: unknown investigator_id=%s", admin_id)
            continue

        if not profile.get("active", True):
            print(_err(f"Account '{admin_id}' is deactivated."))
            _log.warning("Admin auth failed: account inactive investigator_id=%s", admin_id)
            continue

        # Verify the account has admin permission before checking the password.
        # Checking permissions first avoids leaking whether the password was
        # correct for a non-admin account (timing-insensitive but semantically clean).
        if "manage_investigators" not in profile.get("permissions", []):
            print(_err(f"Account '{admin_id}' does not have administrator permissions."))
            _log.warning(
                "Admin auth failed: insufficient permissions investigator_id=%s", admin_id
            )
            continue

        stored_hash = profile.get("password_hash", "")
        stored_salt = profile.get("password_salt", "")

        # Reject accounts whose password is still a placeholder —
        # a placeholder hash is not a real derived key and will never match
        if stored_hash.startswith(_PLACEHOLDER_PREFIX) or stored_salt.startswith(_PLACEHOLDER_PREFIX):
            print(_warn(
                f"Account '{admin_id}' has a placeholder password. "
                "Run set-admin-password first."
            ))
            _log.warning(
                "Admin auth failed: placeholder password investigator_id=%s", admin_id
            )
            continue

        if _verify_password(password, stored_hash, stored_salt):
            print(_ok(f"Authenticated as: {profile.get('name', admin_id)} ({profile.get('badge', 'N/A')})"))
            _log.info("Admin authenticated: investigator_id=%s", admin_id)
            return profile

        print(_err(f"Authentication failed ({attempt}/{max_attempts})"))
        _log.warning("Admin auth failed: wrong password investigator_id=%s", admin_id)

    # Three failures — abort entirely to prevent further brute-force attempts
    print(_err("Too many failed attempts. Aborting."))
    _log.error("Admin auth: too many failed attempts — aborting")
    sys.exit(1)


def _is_placeholder(profile: dict[str, Any]) -> bool:
    """Return True if the account's password fields are still placeholder values."""
    h = profile.get("password_hash", _PLACEHOLDER_PREFIX)
    s = profile.get("password_salt", _PLACEHOLDER_PREFIX)
    return h.startswith(_PLACEHOLDER_PREFIX) or s.startswith(_PLACEHOLDER_PREFIX)


# ---------------------------------------------------------------------------
# Shared prompt helper
# ---------------------------------------------------------------------------

def _prompt_new_password(label: str = "New password") -> str:
    """
    Interactively prompt for a new password with confirmation.

    Reads the password twice and compares — the operator must type the same
    password twice to prevent typos in a non-echoed field. Validates strength
    requirements before returning.

    Returns the validated plaintext password string.
    """
    for _ in range(3):
        pw1 = getpass.getpass(f"{label}: ")
        pw2 = getpass.getpass(f"Confirm {label.lower()}: ")

        # compare_digest prevents a timing oracle on the confirmation comparison —
        # even though this is not a security comparison, using it consistently
        # avoids any theoretical information leakage and demonstrates the pattern.
        if not hmac.compare_digest(pw1, pw2):
            print(_err("Passwords do not match. Try again."))
            continue

        try:
            _validate_password_strength(pw1)
            return pw1
        except ValueError as exc:
            print(_err(str(exc)))

    print(_err("Failed to set a valid password after 3 attempts."))
    sys.exit(1)


# ---------------------------------------------------------------------------
# Command: set-admin-password
# ---------------------------------------------------------------------------

def cmd_set_admin_password(args: argparse.Namespace) -> None:
    """
    Set or reset the admin account password.

    First-run behaviour (admin password is PLACEHOLDER)
    ----------------------------------------------------
    No current password is required. The operator sets a new password, which
    replaces the placeholder. This is the bootstrap entry point for a fresh
    deployment.

    Subsequent runs (admin password is a real hash)
    -----------------------------------------------
    The current admin password must be provided and verified before a new
    password can be set. This prevents an attacker with write access to the
    registry file from resetting the admin password without knowing the current one.

    The must_change_password flag is cleared after a successful password set,
    indicating the account has been properly initialised.
    """
    print(_hdr("Set Admin Password"))

    registry = _load_registry()
    investigators = registry["investigators"]

    admin_profile = investigators.get("admin")
    if admin_profile is None:
        print(_err(
            "No 'admin' account found in registry. "
            f"Ensure {str(INVESTIGATORS_REGISTRY_PATH)} contains an 'admin' entry."
        ))
        sys.exit(1)

    first_run = _is_placeholder(admin_profile)

    if first_run:
        print(_info("Admin password is unset (first-run). No current password required."))
        print(_warn("IMPORTANT: This is the bootstrap setup step. Secure this password."))
    else:
        # Require current admin password before allowing a change.
        # This prevents a physical-access attacker from resetting the password
        # just by running this command.
        print(_info("Current admin password is required to set a new one."))
        current_pw = getpass.getpass("Current admin password: ")

        if not _verify_password(
            current_pw,
            admin_profile["password_hash"],
            admin_profile["password_salt"],
        ):
            print(_err("Current password is incorrect. Aborting."))
            _log.warning("set-admin-password: current password verification failed")
            sys.exit(1)

        print(_ok("Current password verified."))

    # Prompt for the new password with strength validation
    new_password = _prompt_new_password("New admin password")

    salt            = _generate_salt()
    password_hash   = _hash_password(new_password, salt)

    with _registry_lock():
        # Re-load inside the lock to pick up any changes since we first loaded
        registry = _load_registry()
        registry["investigators"]["admin"]["password_hash"]      = password_hash
        registry["investigators"]["admin"]["password_salt"]      = salt.hex()
        registry["investigators"]["admin"]["must_change_password"] = False
        registry["investigators"]["admin"]["active"] = True
        registry["investigators"]["admin"]["role"] = "Platform Administrator"
        registry["investigators"]["admin"]["permissions"] = sorted(_ALL_PERMISSIONS)
        registry["investigators"]["admin"]["account_created"] = (
            registry["investigators"]["admin"].get("account_created")
            or date.today().isoformat()
        )
        # Remove the _password_instructions comment if present (it's a first-run guide)
        registry["investigators"]["admin"].pop("_password_instructions", None)

        _save_registry(registry)

    print(_ok("Admin password set successfully."))
    if first_run:
        print(_info(
            "First-run setup complete. You can now authenticate as 'admin'.\n"
            "Next step: use add-investigator to create named investigator accounts."
        ))

    _log.info("Admin password set (first_run=%s)", first_run)


# ---------------------------------------------------------------------------
# Command: add-investigator
# ---------------------------------------------------------------------------

def cmd_add_investigator(args: argparse.Namespace) -> None:
    """
    Register a new investigator account in the registry.

    Prompts interactively for all required fields when not supplied via CLI.
    Validates every field before writing. Sets must_change_password=True so
    the new investigator is forced to change their initial password on first
    login (enforced by core/main.py).

    Requires administrator authentication before any changes are made.
    """
    print(_hdr("Add Investigator"))

    registry = _load_registry()
    _authenticate_admin(registry, "add-investigator")

    # ── Collect and validate all fields ──────────────────────────────────

    # Investigator ID
    raw_id = getattr(args, "id", None) or input("Investigator ID (login username): ").strip()
    try:
        inv_id = _validate_investigator_id(raw_id)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    # Duplicate check — IDs must be unique
    if inv_id in registry["investigators"]:
        print(_err(f"Investigator ID '{inv_id}' already exists. Use reset-password to change password."))
        sys.exit(1)

    # Full legal name
    raw_name = getattr(args, "name", None) or input("Full legal name: ").strip()
    try:
        name = _validate_name(raw_name)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    # Badge number
    raw_badge = getattr(args, "badge", None) or input("Badge / employee number: ").strip()
    try:
        badge = _validate_badge(raw_badge)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    # Role — show allowed options
    raw_role = getattr(args, "role", None)
    if not raw_role:
        print("Allowed roles:")
        for i, r in enumerate(sorted(_ALLOWED_ROLES), 1):
            print(f"  [{i}] {r}")
        raw_role = input("Role: ").strip()
    try:
        role = _validate_role(raw_role)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    # Department
    raw_dept = getattr(args, "department", None) or input("Department: ").strip()
    try:
        department = _validate_department(raw_dept)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    # Permissions — default to conduct_investigation + view_reports for regular investigators
    # Administrators must be explicitly granted manage_* permissions
    if role == "Platform Administrator":
        default_perms = list(_ALL_PERMISSIONS)
    else:
        default_perms = ["conduct_investigation", "view_reports"]
    print(_info(f"Default permissions for this role: {', '.join(default_perms)}"))
    custom = input("Add additional permissions? (y/N): ").strip().lower()
    perms = list(default_perms)
    if custom == "y":
        print(f"Available permissions: {', '.join(sorted(_ALL_PERMISSIONS))}")
        extras_raw = input("Enter permissions to add (comma-separated): ").strip()
        for p in extras_raw.split(","):
            p = p.strip()
            if p and p in _ALL_PERMISSIONS and p not in perms:
                perms.append(p)
            elif p and p not in _ALL_PERMISSIONS:
                print(_warn(f"Unknown permission '{p}' — ignored"))

    # Initial password
    print(_info(
        f"Setting initial password for {inv_id}. "
        "They will be required to change it on first login."
    ))
    initial_password = _prompt_new_password("Initial password")

    salt          = _generate_salt()
    password_hash = _hash_password(initial_password, salt)

    # Build the new investigator record
    new_profile: dict[str, Any] = {
        "investigator_id":    inv_id,
        "name":               name,
        "badge":              badge,
        "role":               role,
        "department":         department,
        "password_hash":      password_hash,
        "password_salt":      salt.hex(),
        "account_created":    date.today().isoformat(),
        "last_login":         None,
        "active":             True,
        # Force password change on first login — the initial password was set
        # by an admin, not chosen by the investigator themselves
        "must_change_password": True,
        "permissions":        perms,
        "certifications":     [],
        "notes":              "",
    }

    # Print summary before writing
    print(f"""
{_C_BOLD}New investigator account summary:{_C_RESET}
  ID:          {inv_id}
  Name:        {name}
  Badge:       {badge}
  Role:        {role}
  Department:  {department}
  Permissions: {', '.join(perms)}
  Active:      True
  Must change password: True
""")
    confirm = input("Create this account? (YES/no): ").strip()
    if confirm != "YES":
        print(_warn("Account creation cancelled."))
        sys.exit(0)

    with _registry_lock():
        registry = _load_registry()
        if inv_id in registry["investigators"]:
            print(_err(f"Investigator ID '{inv_id}' was added by another process. Aborting."))
            sys.exit(1)
        registry["investigators"][inv_id] = new_profile
        _save_registry(registry)

    print(_ok(f"Investigator '{inv_id}' ({name}) created successfully."))
    _log.info("Investigator added: id=%s name=%s badge=%s role=%s", inv_id, name, badge, role)


# ---------------------------------------------------------------------------
# Command: remove-investigator
# ---------------------------------------------------------------------------

def cmd_remove_investigator(args: argparse.Namespace) -> None:
    """
    Permanently delete an investigator account from the registry.

    WARNING: Deletion is permanent and irreversible. Because every chain of
    custody log entry references the investigator's ID, removing an account
    will leave orphaned ID references in all historical CoC logs. This does
    NOT corrupt the hash chain, but it means the name/badge corresponding to
    that ID can no longer be resolved from the registry.

    The operator must type the investigator's ID as a confirmation to proceed.
    Administrators (accounts with manage_investigators permission) cannot be
    removed if they are the only active administrator — this prevents accidental
    lockout.

    Use deactivate-investigator instead to suspend an account while preserving
    the historical record.

    Requires administrator authentication.
    """
    print(_hdr("Remove Investigator"))

    registry = _load_registry()
    _authenticate_admin(registry, "remove-investigator")

    raw_id = getattr(args, "id", None) or input("Investigator ID to remove: ").strip()
    try:
        inv_id = _validate_investigator_id(raw_id)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    investigators = registry["investigators"]

    if inv_id not in investigators:
        print(_err(f"Investigator ID '{inv_id}' not found in registry."))
        sys.exit(1)

    profile = investigators[inv_id]

    # Prevent removing the last active administrator
    if "manage_investigators" in profile.get("permissions", []) and profile.get("active", True):
        active_admins = [
            iid for iid, p in investigators.items()
            if "manage_investigators" in p.get("permissions", [])
            and p.get("active", True)
            and iid != inv_id
        ]
        if not active_admins:
            print(_err(
                "Cannot remove the only active administrator account. "
                "Grant 'manage_investigators' permission to another account first."
            ))
            sys.exit(1)

    # Display details of the account being removed
    print(f"""
{_C_RED}{_C_BOLD}WARNING: THIS ACTION IS PERMANENT AND IRREVERSIBLE{_C_RESET}

Account to be deleted:
  ID:         {profile.get('investigator_id', inv_id)}
  Name:       {profile.get('name', 'Unknown')}
  Badge:      {profile.get('badge', 'N/A')}
  Role:       {profile.get('role', 'Unknown')}
  Active:     {profile.get('active', True)}

Deleting this account will leave orphaned investigator ID references in
all historical chain-of-custody logs. Consider using deactivate-investigator
to suspend the account instead.
""")

    # Require the operator to type the ID — prevents accidental deletion on a
    # tab-complete or copy-paste error
    typed_id = input(
        f"Type the investigator ID '{inv_id}' exactly to confirm permanent deletion: "
    ).strip()

    if not hmac.compare_digest(typed_id, inv_id):
        print(_warn("ID did not match. Deletion cancelled."))
        sys.exit(0)

    with _registry_lock():
        registry = _load_registry()
        if inv_id not in registry["investigators"]:
            print(_err(f"Account '{inv_id}' no longer exists (removed by another process)."))
            sys.exit(1)
        del registry["investigators"][inv_id]
        _save_registry(registry)

    print(_ok(f"Investigator '{inv_id}' permanently removed from registry."))
    _log.warning("Investigator REMOVED: id=%s name=%s", inv_id, profile.get("name"))


# ---------------------------------------------------------------------------
# Command: list-investigators
# ---------------------------------------------------------------------------

def cmd_list_investigators(args: argparse.Namespace) -> None:
    """
    Display all registered investigator accounts in a formatted table.

    Shows account status (active/inactive), role, badge, and whether the
    account must change its password. Inactive accounts are displayed in
    dim/yellow text so they stand out visually.

    Requires administrator authentication — the registry contains role and
    permission information that should not be freely readable on shared systems.
    """
    print(_hdr("Registered Investigators"))

    registry = _load_registry()
    _authenticate_admin(registry, "list-investigators")

    investigators = registry["investigators"]

    if not investigators:
        print(_info("No investigators registered."))
        return

    # Column widths (minimum values — expand for long content)
    col_id   = max(18, max(len(k) for k in investigators))
    col_name = max(28, max(len(v.get("name", "")) for v in investigators.values()))
    col_badge = 14
    col_role  = 28
    col_dept  = 24
    col_active = 8

    header = (
        f"{'ID':<{col_id}}  "
        f"{'Name':<{col_name}}  "
        f"{'Badge':<{col_badge}}  "
        f"{'Role':<{col_role}}  "
        f"{'Active':<{col_active}}  "
        f"{'Pw Change'}"
    )
    sep = "─" * len(header)

    print(f"{_C_BOLD}{_C_CYAN}{header}{_C_RESET}")
    print(sep)

    for inv_id, profile in sorted(investigators.items()):
        is_active    = profile.get("active", True)
        must_change  = profile.get("must_change_password", False)
        is_placeholder_pw = _is_placeholder(profile)

        name    = profile.get("name", "(no name)")
        badge   = profile.get("badge", "N/A")
        role    = profile.get("role", "Unknown")
        dept    = profile.get("department", "N/A")
        active_s = "Yes" if is_active else "No"
        change_s = "REQUIRED" if (must_change or is_placeholder_pw) else "No"

        row = (
            f"{inv_id:<{col_id}}  "
            f"{name:<{col_name}}  "
            f"{badge:<{col_badge}}  "
            f"{role:<{col_role}}  "
            f"{active_s:<{col_active}}  "
            f"{change_s}"
        )

        if not is_active:
            # Dim + yellow for inactive accounts — visually distinguishable
            print(f"{_C_YELLOW}{_C_DIM}{row}{_C_RESET}")
        elif must_change or is_placeholder_pw:
            # Yellow for accounts requiring a password change
            print(f"{_C_YELLOW}{row}{_C_RESET}")
        elif "manage_investigators" in profile.get("permissions", []):
            # Cyan + bold for administrator accounts
            print(f"{_C_CYAN}{_C_BOLD}{row}{_C_RESET}")
        else:
            print(row)

    print(sep)
    active_count   = sum(1 for p in investigators.values() if p.get("active", True))
    inactive_count = len(investigators) - active_count
    print(f"{_C_DIM}Total: {len(investigators)}  Active: {active_count}  Inactive: {inactive_count}{_C_RESET}\n")

    _log.info("list-investigators: %d accounts listed", len(investigators))


# ---------------------------------------------------------------------------
# Command: reset-password
# ---------------------------------------------------------------------------

def cmd_reset_password(args: argparse.Namespace) -> None:
    """
    Reset an investigator's password.

    The account being reset does not need to provide its current password —
    that is the administrator's privilege. The account's must_change_password
    flag is set to True so the investigator is forced to choose a new personal
    password on their next login (enforced by core/main.py).

    This is the correct procedure when an investigator forgets their password
    or when an account needs to be handed to a new person.

    Requires administrator authentication.
    """
    print(_hdr("Reset Password"))

    registry = _load_registry()
    _authenticate_admin(registry, "reset-password")

    raw_id = getattr(args, "id", None) or input("Investigator ID to reset: ").strip()
    try:
        inv_id = _validate_investigator_id(raw_id)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    if inv_id not in registry["investigators"]:
        print(_err(f"Investigator ID '{inv_id}' not found."))
        sys.exit(1)

    profile = registry["investigators"][inv_id]
    print(_info(
        f"Resetting password for: {profile.get('name', inv_id)} "
        f"({profile.get('badge', 'N/A')})"
    ))

    new_password = _prompt_new_password("New password")

    salt          = _generate_salt()
    password_hash = _hash_password(new_password, salt)

    with _registry_lock():
        registry = _load_registry()
        if inv_id not in registry["investigators"]:
            print(_err(f"Account '{inv_id}' no longer exists."))
            sys.exit(1)
        registry["investigators"][inv_id]["password_hash"]       = password_hash
        registry["investigators"][inv_id]["password_salt"]       = salt.hex()
        # Force the investigator to choose their own password on next login.
        # The admin-set password is a temporary credential, not a permanent one.
        registry["investigators"][inv_id]["must_change_password"] = True
        _save_registry(registry)

    print(_ok(f"Password reset for '{inv_id}'. Investigator must change it on next login."))
    _log.info("Password reset: id=%s by admin", inv_id)


# ---------------------------------------------------------------------------
# Command: deactivate-investigator
# ---------------------------------------------------------------------------

def cmd_deactivate_investigator(args: argparse.Namespace) -> None:
    """
    Suspend an investigator account by setting active=False.

    The account is preserved in the registry so that historical chain-of-custody
    log entries can still be resolved to a name and badge. The investigator
    can no longer authenticate while inactive.

    Cannot deactivate the last active administrator to prevent platform lockout.

    Requires administrator authentication.
    """
    print(_hdr("Deactivate Investigator"))

    registry = _load_registry()
    _authenticate_admin(registry, "deactivate-investigator")

    raw_id = getattr(args, "id", None) or input("Investigator ID to deactivate: ").strip()
    try:
        inv_id = _validate_investigator_id(raw_id)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    investigators = registry["investigators"]

    if inv_id not in investigators:
        print(_err(f"Investigator ID '{inv_id}' not found."))
        sys.exit(1)

    profile = investigators[inv_id]

    if not profile.get("active", True):
        print(_warn(f"Account '{inv_id}' is already inactive."))
        sys.exit(0)

    # Prevent deactivating the last active admin
    if "manage_investigators" in profile.get("permissions", []):
        active_admins = [
            iid for iid, p in investigators.items()
            if "manage_investigators" in p.get("permissions", [])
            and p.get("active", True)
            and iid != inv_id
        ]
        if not active_admins:
            print(_err(
                "Cannot deactivate the only active administrator account. "
                "Activate or create another administrator account first."
            ))
            sys.exit(1)

    print(_info(
        f"Deactivating: {profile.get('name', inv_id)} ({profile.get('badge', 'N/A')})"
    ))
    confirm = input(f"Deactivate account '{inv_id}'? (YES/no): ").strip()
    if confirm != "YES":
        print(_warn("Deactivation cancelled."))
        sys.exit(0)

    with _registry_lock():
        registry = _load_registry()
        registry["investigators"][inv_id]["active"] = False
        _save_registry(registry)

    print(_ok(f"Account '{inv_id}' deactivated. Historical CoC records are preserved."))
    _log.info("Account deactivated: id=%s", inv_id)


# ---------------------------------------------------------------------------
# Command: activate-investigator
# ---------------------------------------------------------------------------

def cmd_activate_investigator(args: argparse.Namespace) -> None:
    """
    Reactivate a previously deactivated investigator account.

    Sets active=True. The account's password remains as it was when the
    account was deactivated. If there is concern the password was compromised
    during the suspension, use reset-password as well.

    Requires administrator authentication.
    """
    print(_hdr("Activate Investigator"))

    registry = _load_registry()
    _authenticate_admin(registry, "activate-investigator")

    raw_id = getattr(args, "id", None) or input("Investigator ID to activate: ").strip()
    try:
        inv_id = _validate_investigator_id(raw_id)
    except ValueError as exc:
        print(_err(str(exc)))
        sys.exit(1)

    if inv_id not in registry["investigators"]:
        print(_err(f"Investigator ID '{inv_id}' not found."))
        sys.exit(1)

    profile = registry["investigators"][inv_id]

    if profile.get("active", True):
        print(_warn(f"Account '{inv_id}' is already active."))
        sys.exit(0)

    print(_info(
        f"Activating: {profile.get('name', inv_id)} ({profile.get('badge', 'N/A')})"
    ))

    with _registry_lock():
        registry = _load_registry()
        registry["investigators"][inv_id]["active"] = True
        _save_registry(registry)

    print(_ok(f"Account '{inv_id}' is now active."))
    _log.info("Account activated: id=%s", inv_id)


# ---------------------------------------------------------------------------
# Command: verify-chain
# ---------------------------------------------------------------------------

def cmd_verify_chain(args: argparse.Namespace) -> None:
    """
    Re-verify the hash chain integrity of a chain-of-custody .jsonl ledger.

    Algorithm
    ---------
    For each line (entry) in the .jsonl file:
      1. Parse the line as JSON.
      2. Extract and remove the 'self_hash' field from the parsed dict.
      3. Re-serialise the remaining fields with json.dumps(sort_keys=True,
         ensure_ascii=True) — the same serialisation used when the entry was
         written by CustodyLogger.
      4. Compute SHA-256 of the serialised bytes.
      5. Compare the computed hash to the extracted self_hash.
         → If they differ, the entry's content has been altered since it was
           written. FAIL.
      6. Verify that the entry's previous_hash field equals the self_hash of
         the previous entry (or "GENESIS" for entry 0).
         → If they differ, an entry has been inserted, deleted, or reordered.
           FAIL.

    Each entry result is printed in real time. A final PASS/FAIL verdict is
    printed at the end with totals.

    Seal verification (optional)
    ----------------------------
    If a seal .json file is found alongside the .jsonl file (same stem +
    '_seal.json'), it is read and the totals and final hash are checked for
    consistency with the ledger. HMAC verification of the seal requires the
    original HMAC key (not stored in the seal file — it must be provided
    separately). If --hmac-key is not given, HMAC verification is skipped.

    Parameters (from argparse)
    --------------------------
    args.ledger_path    Path to the .jsonl ledger file. Required.
    args.hmac_key_hex   Optional 64-char hex HMAC key for seal HMAC verification.
    args.verbose        If True, print a line for every passing entry, not just
                        failures.
    """
    print(_hdr("Verify Chain of Custody Ledger"))

    # ── Validate and resolve the ledger path ─────────────────────────────
    raw_path = getattr(args, "ledger_path", None)
    if not raw_path:
        raw_path = input("Path to .jsonl custody ledger: ").strip()

    # Path.resolve() canonicalises the path, preventing traversal via ../
    try:
        ledger_path = Path(raw_path).resolve()
    except (OSError, ValueError) as exc:
        print(_err(f"Invalid path: {exc}"))
        sys.exit(1)

    if not ledger_path.exists():
        print(_err(f"File not found: {ledger_path}"))
        sys.exit(1)

    if not ledger_path.is_file():
        print(_err(f"Not a regular file: {ledger_path}"))
        sys.exit(1)

    print(_info(f"Ledger: {ledger_path}"))
    print(_info(f"Size:   {ledger_path.stat().st_size:,} bytes\n"))

    verbose = getattr(args, "verbose", False)

    # ── Read all lines ───────────────────────────────────────────────────
    try:
        with open(ledger_path, "r", encoding="utf-8") as f:
            raw_lines = [line.strip() for line in f if line.strip()]
    except OSError as exc:
        print(_err(f"Cannot read ledger: {exc}"))
        sys.exit(1)

    total_entries    = len(raw_lines)
    passed_entries   = 0
    failed_entries   = 0
    expected_prev    = "GENESIS"
    last_self_hash   = "GENESIS"
    any_failure      = False

    if total_entries == 0:
        print(_warn("Ledger file is empty — nothing to verify."))
        sys.exit(0)

    print(f"{'Entry':>6}  {'Event Type':<28}  {'Self Hash (first 16)':<18}  {'Status'}")
    print("─" * 78)

    for index, raw_line in enumerate(raw_lines):

        # ── Parse JSON ───────────────────────────────────────────────────
        try:
            data: dict = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            print(f"{index:>6}  {'(MALFORMED JSON)':<28}  {'':18}  "
                  f"{_C_RED}{_C_BOLD}FAIL — malformed JSON: {exc}{_C_RESET}")
            failed_entries += 1
            any_failure = True
            # Cannot continue the chain from a broken entry — stop here
            print(_err(f"\nChain verification aborted at entry {index}: unparseable JSON."))
            break

        event_type = data.get("event_type", "UNKNOWN")

        # ── Extract stored self_hash ─────────────────────────────────────
        stored_self_hash: Optional[str] = data.pop("self_hash", None)
        if stored_self_hash is None:
            print(f"{index:>6}  {event_type:<28}  {'':18}  "
                  f"{_C_RED}{_C_BOLD}FAIL — missing self_hash field{_C_RESET}")
            failed_entries += 1
            any_failure = True
            continue

        # ── Recompute self_hash ──────────────────────────────────────────
        # sort_keys=True and ensure_ascii=True match the serialisation in
        # CustodyEntry._compute_self_hash() exactly.
        serialised  = json.dumps(data, sort_keys=True, ensure_ascii=True)
        recomputed  = hashlib.sha256(serialised.encode("utf-8")).hexdigest()

        content_ok  = hmac.compare_digest(recomputed, stored_self_hash)

        # ── Verify previous_hash chain link ──────────────────────────────
        stored_prev = data.get("previous_hash", "")
        chain_ok    = hmac.compare_digest(stored_prev, expected_prev)

        # ── Determine entry verdict ──────────────────────────────────────
        entry_ok    = content_ok and chain_ok
        hash_short  = stored_self_hash[:16]

        if entry_ok:
            passed_entries += 1
            last_self_hash = stored_self_hash
            if verbose:
                print(f"{index:>6}  {event_type:<28}  {hash_short:<18}  "
                      f"{_C_GREEN}PASS{_C_RESET}")
        else:
            failed_entries += 1
            any_failure = True
            reasons = []
            if not content_ok:
                reasons.append(
                    f"content altered (stored={stored_self_hash[:12]}… "
                    f"computed={recomputed[:12]}…)"
                )
            if not chain_ok:
                reasons.append(
                    f"chain broken (expected prev={expected_prev[:12]}… "
                    f"got {stored_prev[:12]}…)"
                )
            print(f"{index:>6}  {event_type:<28}  {hash_short:<18}  "
                  f"{_C_RED}{_C_BOLD}FAIL — {'; '.join(reasons)}{_C_RESET}")

        # Advance expected_prev regardless of failure so we can detect the
        # full extent of the chain break rather than stopping at the first bad entry
        expected_prev = stored_self_hash

    # ── Print summary ─────────────────────────────────────────────────────
    print("─" * 78)
    print(f"Total entries:  {total_entries}")
    print(f"Passed:         {_C_GREEN}{passed_entries}{_C_RESET}")
    if failed_entries:
        print(f"Failed:         {_C_RED}{_C_BOLD}{failed_entries}{_C_RESET}")
    else:
        print(f"Failed:         {failed_entries}")

    # ── Optional seal file verification ──────────────────────────────────
    # Look for a seal file alongside the ledger (same stem + _seal suffix)
    stem_without_suffix = re.sub(r"_custody$", "", ledger_path.stem)
    seal_path = ledger_path.parent / f"{stem_without_suffix}_custody_seal.json"

    if seal_path.exists():
        print(f"\n{_C_BOLD}Seal file found: {seal_path.name}{_C_RESET}")
        _verify_seal_file(
            seal_path       = seal_path,
            total_entries   = passed_entries + failed_entries,
            final_chain_hash = last_self_hash,
            hmac_key_hex    = getattr(args, "hmac_key_hex", None),
        )
    else:
        print(_info(f"\nNo seal file found (expected: {seal_path.name})"))

    # ── Overall verdict ───────────────────────────────────────────────────
    print("\n" + "═" * 78)
    if not any_failure:
        print(f"{_C_GREEN}{_C_BOLD}OVERALL RESULT: CHAIN INTEGRITY VERIFIED — all {total_entries} entries passed{_C_RESET}")
    else:
        print(f"{_C_RED}{_C_BOLD}OVERALL RESULT: CHAIN INTEGRITY COMPROMISED — {failed_entries} of {total_entries} entries FAILED{_C_RESET}")
        print(f"{_C_RED}This ledger may have been tampered with. Do not rely on it for court submission without expert review.{_C_RESET}")
    print("═" * 78 + "\n")

    _log.info(
        "verify-chain: ledger=%s total=%d passed=%d failed=%d",
        ledger_path, total_entries, passed_entries, failed_entries,
    )

    # Exit with non-zero status on failure so scripts can detect a broken chain
    if any_failure:
        sys.exit(2)


def _verify_seal_file(
    seal_path:        Path,
    total_entries:    int,
    final_chain_hash: str,
    hmac_key_hex:     Optional[str],
) -> None:
    """
    Verify the seal document against the verified ledger state.

    Checks:
      1. total_entries in seal matches the count we just verified
      2. final_chain_hash in seal matches the last entry's self_hash
      3. If hmac_key_hex is provided, recompute and verify the seal HMAC
    """
    try:
        with open(seal_path, "r", encoding="utf-8") as f:
            seal: dict = json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        print(_err(f"Cannot read seal file: {exc}"))
        return

    # Check entry count consistency
    sealed_total = seal.get("total_entries")
    if sealed_total != total_entries:
        print(_err(
            f"Seal total_entries mismatch: seal says {sealed_total}, "
            f"ledger has {total_entries} entries"
        ))
    else:
        print(_ok(f"Seal entry count matches: {sealed_total}"))

    # Check final chain hash consistency
    sealed_final = seal.get("final_chain_hash", "")
    if not hmac.compare_digest(sealed_final, final_chain_hash):
        print(_err(
            f"Seal final_chain_hash mismatch: "
            f"seal={sealed_final[:16]}… ledger={final_chain_hash[:16]}…"
        ))
    else:
        print(_ok(f"Seal final chain hash matches: {sealed_final[:24]}…"))

    # Check chain integrity flag recorded in seal
    if not seal.get("chain_integrity_verified", False):
        print(_warn("Seal records that chain integrity was NOT verified at case close."))
    else:
        print(_ok("Seal records chain_integrity_verified: True at case close"))

    # HMAC verification — optional, requires the original HMAC key
    if hmac_key_hex:
        try:
            hmac_key = bytes.fromhex(hmac_key_hex)
        except ValueError:
            print(_err("--hmac-key is not valid hex — HMAC verification skipped"))
            return

        # Reconstruct the seal content dict (without the seal_hmac and
        # hmac_key_sha256 fields — those were not part of the HMAC input)
        seal_content = {
            k: v for k, v in seal.items()
            if k not in ("seal_hmac", "hmac_key_sha256")
        }
        seal_bytes = json.dumps(seal_content, sort_keys=True, ensure_ascii=True).encode("utf-8")
        expected_hmac = hmac.new(hmac_key, seal_bytes, hashlib.sha256).hexdigest()
        stored_hmac   = seal.get("seal_hmac", "")

        if hmac.compare_digest(expected_hmac, stored_hmac):
            print(_ok("Seal HMAC verified — seal document has not been tampered with"))
        else:
            print(_err("Seal HMAC MISMATCH — seal document may have been tampered with"))
    else:
        print(_info("HMAC key not provided — seal HMAC verification skipped"))
        print(_dim("  To verify: python3 tools/admin.py verify-chain <path> --hmac-key <key>"))


# ---------------------------------------------------------------------------
# Command: show-audit-log
# ---------------------------------------------------------------------------

def cmd_show_audit_log(args: argparse.Namespace) -> None:
    """
    Display the authentication audit log in human-readable format.

    Reads output/auth_audit.jsonl (or a path specified by --audit-path) and
    displays each entry with timestamp, result, investigator ID, and reason.

    Filters:
      --last N          Show only the most recent N entries
      --investigator-id Show only entries for a specific investigator ID
      --failures-only   Show only failed authentication attempts

    Successful logins are shown in green; failures in red.

    Requires administrator authentication — the audit log may reveal
    investigator IDs and authentication patterns that should be restricted.
    """
    print(_hdr("Authentication Audit Log"))

    registry = _load_registry()
    _authenticate_admin(registry, "show-audit-log")

    # Determine audit log path
    raw_path = getattr(args, "audit_path", None)
    if raw_path:
        try:
            audit_path = Path(raw_path).resolve()
        except (OSError, ValueError) as exc:
            print(_err(f"Invalid audit log path: {exc}"))
            sys.exit(1)
    else:
        audit_path = DEFAULT_OUTPUT_DIR / "auth_audit.jsonl"

    if not audit_path.exists():
        print(_info(f"Audit log not found at {audit_path}."))
        print(_info("No authentication attempts have been recorded yet, or the path is incorrect."))
        return

    print(_info(f"Audit file: {audit_path}"))

    # Read and parse all entries
    entries: list[dict] = []
    parse_errors = 0

    try:
        with open(audit_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    entries.append(entry)
                except json.JSONDecodeError:
                    parse_errors += 1
                    _log.warning("Audit log line %d is malformed JSON", line_num)
    except OSError as exc:
        print(_err(f"Cannot read audit log: {exc}"))
        sys.exit(1)

    if parse_errors:
        print(_warn(f"{parse_errors} malformed line(s) skipped in audit log."))

    # ── Apply filters ────────────────────────────────────────────────────
    filter_id      = getattr(args, "investigator_id_filter", None)
    failures_only  = getattr(args, "failures_only", False)
    last_n         = getattr(args, "last", None)

    if filter_id:
        try:
            filter_id = _validate_investigator_id(filter_id)
        except ValueError:
            print(_err(f"Invalid investigator ID filter: '{filter_id}'"))
            sys.exit(1)
        entries = [e for e in entries if e.get("investigator_id") == filter_id]

    if failures_only:
        entries = [e for e in entries if e.get("event", "").upper() != "AUTH_SUCCESS"]

    if last_n is not None:
        if not isinstance(last_n, int) or last_n <= 0:
            print(_err("--last must be a positive integer."))
            sys.exit(1)
        entries = entries[-last_n:]

    if not entries:
        print(_info("No entries match the specified filters."))
        return

    print(_info(f"Displaying {len(entries)} entry/entries:\n"))

    # ── Column header ────────────────────────────────────────────────────
    hdr = f"{'Timestamp':<36}  {'Event':<15}  {'Investigator ID':<22}  {'Detail'}"
    print(f"{_C_BOLD}{_C_CYAN}{hdr}{_C_RESET}")
    print("─" * 100)

    success_count = 0
    failure_count = 0

    for entry in entries:
        timestamp    = entry.get("timestamp", "UNKNOWN")
        event        = entry.get("event", "UNKNOWN").upper()
        inv_id       = entry.get("investigator_id", "UNKNOWN")
        reason       = entry.get("reason", "")

        is_success = (event == "AUTH_SUCCESS")

        if is_success:
            success_count += 1
            status_str = f"{_C_GREEN}{_C_BOLD}SUCCESS{_C_RESET}"
        else:
            failure_count += 1
            status_str = f"{_C_RED}{_C_BOLD}FAILURE{_C_RESET}"

        # Truncate reason to keep the table readable — full detail in the raw file
        reason_display = reason[:60] + "…" if len(reason) > 60 else reason

        # inv_id comes from user input that was stored in the log — sanitise for display
        # by replacing any non-printable characters before printing to terminal
        safe_inv_id = re.sub(r"[^\x20-\x7e]", "?", str(inv_id))

        print(
            f"{timestamp:<36}  "
            f"{status_str:<{15 + len(_C_GREEN) + len(_C_BOLD) + len(_C_RESET)}}  "
            f"{safe_inv_id:<22}  "
            f"{reason_display}"
        )

    print("─" * 100)
    print(
        f"{_C_DIM}Total: {len(entries)}  |  "
        f"{_C_GREEN}Success: {success_count}{_C_DIM}  |  "
        f"{_C_RED}Failure: {failure_count}{_C_RESET}"
    )

    _log.info("show-audit-log: displayed %d entries", len(entries))


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    """
    Build the CLI argument parser for all admin commands.

    Each command is a sub-parser under the main parser. Arguments can be
    supplied on the CLI for automation, or left out for interactive prompting.
    """
    parser = argparse.ArgumentParser(
        prog        = "admin.py",
        description = "Auto Forensics — Platform Administration CLI",
        formatter_class = argparse.RawDescriptionHelpFormatter,
        epilog = (
            "Examples:\n"
            "  First-run setup:          python3 tools/admin.py set-admin-password\n"
            "  Add an investigator:      python3 tools/admin.py add-investigator\n"
            "  List all accounts:        python3 tools/admin.py list-investigators\n"
            "  Verify a CoC ledger:      python3 tools/admin.py verify-chain /path/to.jsonl\n"
            "  View audit log (last 50): python3 tools/admin.py show-audit-log --last 50\n"
        ),
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")

    subs = parser.add_subparsers(dest="command", metavar="COMMAND", required=True)

    # ── set-admin-password ───────────────────────────────────────────────
    subs.add_parser(
        "set-admin-password",
        help = "Bootstrap or reset the admin account password",
    )

    # ── add-investigator ─────────────────────────────────────────────────
    p_add = subs.add_parser(
        "add-investigator",
        help = "Register a new investigator account",
    )
    p_add.add_argument("--id",         metavar="ID",         help="Investigator login ID")
    p_add.add_argument("--name",       metavar="NAME",       help="Full legal name")
    p_add.add_argument("--badge",      metavar="BADGE",      help="Badge / employee number")
    p_add.add_argument("--role",       metavar="ROLE",       help="Role (see allowed values)")
    p_add.add_argument("--department", metavar="DEPT",       help="Department or unit")

    # ── remove-investigator ──────────────────────────────────────────────
    p_rm = subs.add_parser(
        "remove-investigator",
        help = "Permanently delete an investigator record (irreversible)",
    )
    p_rm.add_argument("--id", metavar="ID", help="Investigator ID to remove")

    # ── list-investigators ───────────────────────────────────────────────
    subs.add_parser(
        "list-investigators",
        help = "Display all registered investigators",
    )

    # ── reset-password ───────────────────────────────────────────────────
    p_reset = subs.add_parser(
        "reset-password",
        help = "Reset an investigator's password",
    )
    p_reset.add_argument("--id", metavar="ID", help="Investigator ID whose password to reset")

    # ── deactivate-investigator ──────────────────────────────────────────
    p_deact = subs.add_parser(
        "deactivate-investigator",
        help = "Suspend an investigator account (preserves CoC records)",
    )
    p_deact.add_argument("--id", metavar="ID", help="Investigator ID to deactivate")

    # ── activate-investigator ────────────────────────────────────────────
    p_act = subs.add_parser(
        "activate-investigator",
        help = "Reactivate a suspended investigator account",
    )
    p_act.add_argument("--id", metavar="ID", help="Investigator ID to activate")

    # ── verify-chain ─────────────────────────────────────────────────────
    p_vc = subs.add_parser(
        "verify-chain",
        help = "Verify chain-of-custody ledger hash chain integrity",
    )
    p_vc.add_argument(
        "ledger_path",
        nargs   = "?",
        metavar = "LEDGER",
        help    = "Path to the .jsonl custody ledger file",
    )
    p_vc.add_argument(
        "--hmac-key",
        dest    = "hmac_key_hex",
        metavar = "HEX",
        help    = "64-char hex HMAC key for seal HMAC verification (optional)",
    )
    p_vc.add_argument(
        "--verbose", "-v",
        action  = "store_true",
        help    = "Print a result line for every entry, not just failures",
    )

    # ── show-audit-log ───────────────────────────────────────────────────
    p_audit = subs.add_parser(
        "show-audit-log",
        help = "Display the authentication attempt audit log",
    )
    p_audit.add_argument(
        "--audit-path",
        dest    = "audit_path",
        metavar = "PATH",
        help    = f"Path to auth_audit.jsonl (default: {DEFAULT_OUTPUT_DIR / 'auth_audit.jsonl'})",
    )
    p_audit.add_argument(
        "--last",
        type    = int,
        metavar = "N",
        help    = "Show only the most recent N entries",
    )
    p_audit.add_argument(
        "--investigator-id",
        dest    = "investigator_id_filter",
        metavar = "ID",
        help    = "Filter entries to a specific investigator ID",
    )
    p_audit.add_argument(
        "--failures-only",
        dest    = "failures_only",
        action  = "store_true",
        help    = "Show only failed authentication attempts",
    )

    return parser


# ---------------------------------------------------------------------------
# Command dispatch
# ---------------------------------------------------------------------------

_COMMAND_MAP: dict[str, Any] = {
    "set-admin-password":      cmd_set_admin_password,
    "add-investigator":        cmd_add_investigator,
    "remove-investigator":     cmd_remove_investigator,
    "list-investigators":      cmd_list_investigators,
    "reset-password":          cmd_reset_password,
    "deactivate-investigator": cmd_deactivate_investigator,
    "activate-investigator":   cmd_activate_investigator,
    "verify-chain":            cmd_verify_chain,
    "show-audit-log":          cmd_show_audit_log,
}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Parse arguments and dispatch to the appropriate command handler.

    Unhandled exceptions are caught at the top level, logged, and printed
    in a clean format rather than a raw Python traceback — traceback output
    can expose internal paths and logic to an observer watching the terminal.
    """
    _ensure_investigators_registry()
    parser = _build_parser()
    args   = parser.parse_args()

    handler = _COMMAND_MAP.get(args.command)
    if handler is None:
        # argparse's required=True on subparsers should prevent this, but
        # guard against future changes to the dispatch map
        print(_err(f"Unknown command: {args.command}"))
        parser.print_help()
        sys.exit(1)

    try:
        handler(args)
    except RuntimeError as exc:
        print(_err(str(exc)))
        _log.error("RuntimeError in command '%s': %s", args.command, exc)
        sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n{_warn('Interrupted by operator. No changes were made.')}")
        sys.exit(130)  # 130 = 128 + SIGINT (standard shell convention)
    except Exception as exc:
        # Catch-all: print a clean message rather than a raw traceback
        print(_err(f"Unexpected error: {exc}"))
        print(_dim(f"Check {DEFAULT_OUTPUT_DIR / 'logs' / 'admin_tool.log'} for details."))
        _log.exception("Unexpected exception in command '%s'", args.command)
        sys.exit(1)


if __name__ == "__main__":
    main()
