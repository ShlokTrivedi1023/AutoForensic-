#!/usr/bin/env python3
"""Compare two runs after removing volatile UUIDs, clocks and host paths.

The comparator is evidence-name neutral: renaming a byte-identical source image
or changing the case ID must not make deterministic findings appear different.
Exact logical paths below the generated evidence root, source hashes, finding
types, severity and validation methods remain part of the semantic comparison.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

_EVIDENCE_SUFFIXES = {".e01", ".ex01", ".dd", ".img", ".raw", ".bin", ".vmem", ".dmp", ".lime"}


def norm_path(value: str) -> str:
    s = str(value or "").replace("\\", "/")
    marker = "/native_filesystem/"
    if marker in s:
        tail = s.split(marker, 1)[1]
        parts = tail.split("/", 1)
        logical = parts[1] if len(parts) == 2 else ""
        return marker + "<EVIDENCE_ROOT>/" + logical
    for marker in ("/module_output/", "/reports/"):
        if marker in s:
            return marker + s.split(marker, 1)[1]
    suffix = Path(s).suffix.casefold()
    if suffix in _EVIDENCE_SUFFIXES:
        return "<LOGICAL_MEDIA>" if suffix == ".raw" else "<SOURCE_EVIDENCE>"
    return Path(s).name if s.startswith("/") else s


def norm_description(value: Any) -> str:
    text = str(value or "").replace("\\", "/")
    # Remove host/run prefixes before stable analysis roots.
    text = re.sub(r"/[^\s;'\"]+/(?:output|native_filesystem|module_output)/", "/", text)
    # Some module prose starts at the generated evidence-root directory rather
    # than including the native_filesystem marker.
    text = re.sub(
        r"(?P<quote>['\"])/[^'\"]+/(?P<branch>extracted_files|deleted_files)/",
        lambda m: f"{m.group('quote')}/<EVIDENCE_ROOT>/{m.group('branch')}/",
        text,
    )
    # Source-container and reconstructed-media names are operator-controlled.
    text = re.sub(
        r"(?P<quote>['\"])[^'\"]+\.(?:E01|Ex01|dd|img|raw|bin|vmem|dmp|lime)(?P=quote)",
        lambda m: f"{m.group('quote')}<SOURCE_EVIDENCE>{m.group('quote')}",
        text,
        flags=re.IGNORECASE,
    )
    return text


def canonical(root: Path) -> tuple[list[dict[str, Any]], str]:
    rows: list[dict[str, Any]] = []
    for p in root.glob("module_output/**/module_result.json"):
        d = json.loads(p.read_text(encoding="utf-8"))
        module = str(d.get("module_name") or p.parent.name)
        for finding in d.get("findings") or []:
            ref = finding.get("evidence_reference") or {}
            md = finding.get("metadata") or {}
            loc = ref.get("artefact_location") or finding.get("evidence_path") or ""
            hashes = ref.get("artefact_hashes") or {}
            rows.append({
                "module": module,
                "finding_type": finding.get("finding_type"),
                "severity": finding.get("severity"),
                "description": norm_description(finding.get("description")),
                "location": norm_path(loc),
                "hashes": hashes,
                "validation_method": md.get("validation_method"),
                "deterministic_validation": md.get("deterministic_validation"),
            })
    rows.sort(key=lambda x: json.dumps(x, sort_keys=True, default=str))
    blob = json.dumps(rows, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    return rows, hashlib.sha256(blob).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-a", type=Path, required=True)
    parser.add_argument("--run-b", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    rows_a, hash_a = canonical(args.run_a)
    rows_b, hash_b = canonical(args.run_b)
    report = {
        "run_a_count": len(rows_a),
        "run_b_count": len(rows_b),
        "run_a_semantic_sha256": hash_a,
        "run_b_semantic_sha256": hash_b,
        "passed": rows_a == rows_b,
    }
    text = json.dumps(report, indent=2)
    print(text)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
