#!/usr/bin/env python3
"""Fail-closed production-source scan for case-specific or answer-key coupling.

The scanner is generic.  Optional deny-list values are supplied externally at
release time and are never packaged as runtime expectations.
"""
from __future__ import annotations
import argparse
import ast
import json
import re
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
RUNTIME_ROOTS = (ROOT / "core", ROOT / "modules", ROOT / "config", ROOT / "report_templates")
RUNTIME_FILES = (ROOT / "run.py", ROOT / "run_final.sh", ROOT / "install.sh")
TEXT_SUFFIXES = {".py", ".yaml", ".yml", ".json", ".j2", ".txt", ".sh"}
GENERIC_PATTERNS = {
    "machine-specific AutoForensics path": re.compile(r"(?i)/home/[^/]+/AutoForensics(?:[_/\\-]|$)"),
    "hard-coded Windows user path": re.compile(r"(?i)[A-Z]:\\\\Users\\\\[^\\\"']+"),
}
ALLOWED_RELATIVE = {
    "tools/evaluate_master_reference.py", "tools/compare_reference_corpus.py",
    "tools/final_output_validator.py", "config/ground_truth_template.json",
}


def iter_runtime_files() -> Iterable[Path]:
    for root in RUNTIME_ROOTS:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES and "__pycache__" not in path.parts:
                yield path
    for path in RUNTIME_FILES:
        if path.is_file():
            yield path


def literal_import_violations(path: Path, text: str) -> list[str]:
    if path.suffix != ".py":
        return []
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError:
        return []
    out=[]
    sensitive_names={"case_id","case_number","expected_hash","expected_sha256","expected_password","expected_filename","answer_key"}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.split(".")[0] in {"tests", "validation", "reference", "fixtures"}:
            out.append(f"imports non-runtime reference namespace {node.module}")
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in {"tests", "validation", "reference", "fixtures"}:
                    out.append(f"imports non-runtime reference namespace {alias.name}")
        if isinstance(node, ast.Compare) and len(node.ops)==1 and isinstance(node.ops[0], (ast.Eq,ast.NotEq)) and len(node.comparators)==1:
            left_names={n.id.casefold() for n in ast.walk(node.left) if isinstance(n,ast.Name)}
            left_names.update(n.attr.casefold() for n in ast.walk(node.left) if isinstance(n,ast.Attribute))
            comp=node.comparators[0]
            if left_names & sensitive_names and isinstance(comp,ast.Constant) and isinstance(comp.value,str) and len(comp.value)>=8:
                out.append(f"hard-coded comparison for {sorted(left_names & sensitive_names)} against literal {comp.value[:80]!r}")
    return out


def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--denylist", type=Path, help="Optional external newline-delimited literal values to forbid")
    parser.add_argument("--json-output", type=Path)
    args=parser.parse_args()
    deny=[]
    if args.denylist:
        deny=[line.strip() for line in args.denylist.read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#")]
    violations=[]
    scanned=0
    for path in sorted(set(iter_runtime_files())):
        rel=str(path.relative_to(ROOT))
        if rel in ALLOWED_RELATIVE:
            continue
        try:
            text=path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            violations.append({"path":rel,"rule":"unreadable","detail":str(exc)})
            continue
        scanned+=1
        for name,pattern in GENERIC_PATTERNS.items():
            for match in pattern.finditer(text):
                violations.append({"path":rel,"rule":name,"detail":match.group(0)[:240]})
        for value in deny:
            if len(value) >= 6 and value in text:
                violations.append({"path":rel,"rule":"external denylist literal","detail":value[:240]})
        for detail in literal_import_violations(path,text):
            violations.append({"path":rel,"rule":"runtime/reference separation","detail":detail})
    result={"schema":"autoforensics-anti-hardcoding-scan-v1","scanned_files":scanned,"denylist_values":len(deny),"violations":violations,"passed":not violations}
    if args.json_output:
        args.json_output.parent.mkdir(parents=True,exist_ok=True)
        args.json_output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    for item in violations:
        print(f"[FAIL] {item['path']}: {item['rule']}: {item['detail']}")
    print(f"ANTI-HARDCODING SCAN: {'PASSED' if not violations else 'FAILED'} ({scanned} files, {len(violations)} violation(s))")
    return 0 if not violations else 1

if __name__ == "__main__":
    raise SystemExit(main())
