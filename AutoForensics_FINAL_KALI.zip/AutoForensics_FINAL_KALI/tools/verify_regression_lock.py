#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
lock=json.loads((ROOT/'config/frozen_module_lock.json').read_text(encoding='utf-8'))
fail=[]
for name,record in lock['modules'].items():
    path=ROOT/record['path']
    actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else 'MISSING'
    ok=actual==record['sha256']
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {actual}")
    if not ok: fail.append(name)
raise SystemExit(1 if fail else 0)
