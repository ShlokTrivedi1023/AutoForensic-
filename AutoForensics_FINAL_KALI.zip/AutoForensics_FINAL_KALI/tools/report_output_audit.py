#!/usr/bin/env python3
"""Audit a generated AutoForensics report for executive-reporting defects.

This is a case-neutral post-generation gate. It does not decide whether a
forensic proposition is true; it checks the report package for structural,
traceability, contradiction and known overstatement defects before examiner
review. A passing result is not a substitute for examination of the source
artefacts.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover - optional fallback below
    PdfReader = None  # type: ignore

REQUIRED_EXECUTIVE_HEADINGS = (
    "Executive Investigation Conclusion",
    "Key Forensic Questions (5W1H)",
    "Material Findings",
    "Evidential Significance and Limits",
    "Recommendations",
)

# Exact legacy defects and absolute claims that must not survive into a final
# report. Negated/bounded wording is intentionally not listed here.
FORBIDDEN_PHRASES = (
    "Xxx " + "Xxx 00 0000",
    "Participants" + ": .",
    "This seal certifies that the forensic report content " + "was complete",
    "Forensic pipeline launched; write-blocker connected; " + "imaging commenced",
    "guarantees the reliability " + "of the evidence",
    "deliberate attempts to obstruct forensic analysis " + "and destroy evidence",
    "Prefetch proves a program " + "was executed",
    "Indicates deliberate file deletion " + "by the user",
    "attributes the file to a device " + "and a point in time",
    "can reliably process",
    "matches its original state",
    "matched its original state",
    "No file-carving results to chart",
    "OPERATOR ACTION REQUIRED",
)

UUID_RE = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
    re.I,
)
ABS_PATH_RE = re.compile(r"(?:/home/[^\s,;]+|[A-Za-z]:\\Users\\[^\s,;]+)")


def _module_audit_key(name: Any) -> str:
    """Return one stable module id for runtime ids and report display labels.

    Coverage uses professional display labels while execution data uses canonical
    runtime ids.  Report auditing must compare identity, not presentation text.
    """
    raw = " ".join(str(name or "").strip().split())
    if not raw:
        return ""
    try:
        from core.coverage_registry import _MODULE_DEFAULTS
        from core.report_generator import _display_module_name
        for module_id in _MODULE_DEFAULTS:
            if raw == module_id or raw.casefold() == _display_module_name(module_id).casefold():
                return module_id
    except Exception:
        pass
    return re.sub(r"[^a-z0-9]+", "_", raw.casefold()).strip("_")


def _text_values(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from _text_values(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from _text_values(child)


def _section(report: dict, title: str) -> dict | None:
    for section in report.get("sections") or []:
        if str(section.get("section_title") or "").strip().lower() == title.lower():
            return section
    return None


def _section_text(section: dict | None) -> str:
    if not section:
        return ""
    return "\n".join(_text_values(section.get("blocks") or []))


def _tables(section: dict | None) -> list[dict]:
    if not section:
        return []
    return [
        block.get("data") or {}
        for block in section.get("blocks") or []
        if block.get("type") == "table"
    ]


def _extract_pdf_text(path: Path) -> str:
    if PdfReader is not None:
        reader = PdfReader(str(path))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    import subprocess
    completed = subprocess.run(
        ["pdftotext", str(path), "-"], capture_output=True, text=True, timeout=120
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "pdftotext failed")
    return completed.stdout



def _validate_pdf_pagination(path: Path) -> tuple[list[str], list[str]]:
    """Validate generated report footer numbering page-by-page.

    Body text or an attached one-page source may legitimately contain
    ``Page 1 of 1``. Only footer-like lines carrying the AutoForensics report
    identity are treated as pagination metadata.
    """
    failures: list[str] = []
    warnings: list[str] = []
    if PdfReader is None:
        warnings.append("pypdf unavailable; PDF footer pagination was not checked")
        return failures, warnings
    try:
        reader = PdfReader(str(path))
        total = len(reader.pages)
        footer_re = re.compile(r"(?i)\bPage\s+(\d+)\s+of\s+(\d+)\s*$")
        found = 0
        for physical_index, page in enumerate(reader.pages, 1):
            page_text = page.extract_text() or ""
            lines = [line.strip() for line in page_text.splitlines() if line.strip()]
            tail = lines[-18:]
            for tail_index, line in enumerate(tail):
                match = footer_re.search(line)
                if not match:
                    continue
                nearby = " ".join(tail[max(0, tail_index - 3): tail_index + 1]).lower()
                if not any(token in nearby for token in (
                    "digital forensic investigation report", "autoforensics", "confidential",
                    "synthetic / validation",
                )):
                    continue
                found += 1
                shown_page = int(match.group(1))
                shown_total = int(match.group(2))
                if shown_page != physical_index or shown_total != total:
                    failures.append(
                        "PDF footer pagination mismatch on physical page "
                        f"{physical_index}: '{line}' (expected Page {physical_index} of {total})"
                    )
        if found == 0:
            warnings.append("no recognisable AutoForensics page footer was found")
    except Exception as exc:
        failures.append(f"could not validate PDF footer pagination: {exc}")
    return failures, warnings

def _failures_for_json(report: dict, *, require_llm: bool) -> tuple[list[str], list[str]]:
    failures: list[str] = []
    warnings: list[str] = []
    metadata = report.get("report_metadata") or {}
    sections = report.get("sections") or []
    full_text = "\n".join(_text_values(report))

    if not sections:
        failures.append("report JSON contains no sections")

    conclusions = _section(report, "Conclusions")
    recommendations = _section(report, "Recommendations")
    conclusion_text = _section_text(conclusions)
    recommendation_text = _section_text(recommendations)
    executive_text = conclusion_text + "\n" + recommendation_text

    for heading in REQUIRED_EXECUTIVE_HEADINGS:
        if heading.lower() not in full_text.lower():
            failures.append(f"missing required executive heading: {heading}")

    calls = metadata.get("api_calls") or []
    successful_exec_calls = [
        c for c in calls
        if c.get("success") and str(c.get("purpose") or "").startswith("deep_analysis")
    ]
    narrative_assurance = metadata.get("narrative_assurance") or {}
    llm_used = bool(narrative_assurance.get("llm_used")) or bool(successful_exec_calls)
    llm_rejected = bool(narrative_assurance.get("llm_rejected"))
    llm_attempted = bool(narrative_assurance.get("llm_attempted"))
    ai_narrative_expected = require_llm or llm_used or llm_attempted
    if llm_used and "evidence-grounded summary" not in executive_text.lower():
        failures.append("AI-assisted narrative disclosure is missing")
    if llm_used and "model did not analyse the raw evidence" not in executive_text.lower():
        failures.append("report does not disclose that the model did not analyse raw evidence")
    if llm_rejected and "rejected by the evidence/quality controls" not in executive_text.lower():
        failures.append("rejected model output was replaced without an explicit disclosure")
    if require_llm and not llm_attempted and not successful_exec_calls:
        failures.append("strict LLM mode has no recorded provider response or accepted synthesis")
    if require_llm and llm_rejected and not narrative_assurance.get("deterministic_fallback_used"):
        failures.append("rejected LLM output is not explicitly recorded as deterministic fallback")
    if "examiner" not in executive_text.lower() or "verify" not in executive_text.lower():
        failures.append("executive narrative lacks an examiner-verification warning")

    for phrase in FORBIDDEN_PHRASES:
        if phrase.lower() in full_text.lower():
            failures.append(f"forbidden legacy/overstatement phrase found: {phrase}")

    # Conclusion quality: at least four developed paragraphs between the 5.1
    # and 5.2 headings. Provider/disclosure paragraphs are excluded.
    blocks = (conclusions or {}).get("blocks") or []
    in_conclusion = False
    paragraphs: list[str] = []
    for block in blocks:
        if block.get("type") == "heading2":
            heading = str((block.get("data") or {}).get("text") or "")
            if "Executive Investigation Conclusion" in heading:
                in_conclusion = True
                continue
            if in_conclusion:
                break
        if in_conclusion and block.get("type") == "paragraph":
            text = str((block.get("data") or {}).get("text") or "").strip()
            if text.startswith("Provider record:"):
                continue
            if len(text.split()) >= 20:
                paragraphs.append(text)
    if len(paragraphs) < 4:
        failures.append(f"executive conclusion has only {len(paragraphs)} developed paragraph(s); at least 4 required")

    conclusion_tables = _tables(conclusions)
    five_w = next((t for t in conclusion_tables if (t.get("headers") or [])[:1] == ["Question"]), None)
    if not five_w:
        failures.append("5W1H evidence table is missing")
    else:
        rows = five_w.get("rows") or []
        questions = [str(row[0]).upper() for row in rows if row]
        expected = ["WHO", "WHAT", "WHEN", "WHERE", "WHY", "HOW"]
        if questions != expected:
            failures.append(f"5W1H rows are incomplete or out of order: {questions}")
        for row in rows:
            if len(row) < 3 or not str(row[1]).strip() or not str(row[2]).strip():
                failures.append("a 5W1H row lacks an answer or evidence basis")

    material = next((t for t in conclusion_tables if "Material Finding" in (t.get("headers") or [])), None)
    significance = next((t for t in conclusion_tables if "Evidential Significance" in (t.get("headers") or [])), None)
    if not material:
        failures.append("material-findings table is missing")
        material_titles: list[str] = []
    else:
        rows = material.get("rows") or []
        material_titles = [str(row[1]).strip() for row in rows if len(row) > 1]
        if not material_titles:
            failures.append("material-findings table is empty")
        if len(material_titles) != len(set(t.lower() for t in material_titles)):
            failures.append("material-findings table contains duplicate grouped titles")
        for row in rows:
            if len(row) < 6 or not str(row[4]).strip() or not str(row[5]).strip():
                failures.append("a material finding lacks an evidence statement or evidence basis")

    if not significance:
        failures.append("evidential-significance table is missing")
    else:
        rows = significance.get("rows") or []
        sig_titles = [str(row[0]).strip() for row in rows if row]
        if set(t.lower() for t in sig_titles) != set(t.lower() for t in material_titles):
            failures.append("significance rows do not cover material findings exactly once")
        for row in rows:
            if len(row) < 4 or any(not str(cell).strip() for cell in row[:4]):
                failures.append("a significance row lacks significance, limitation, or evidence basis")
        sig_texts = [re.sub(r"\s+", " ", str(row[1]).strip().lower()) for row in rows if len(row) > 1]
        if len(sig_texts) > 1 and len(set(sig_texts)) == 1:
            failures.append("significance rows repeat identical generic wording")

    rec_tables = _tables(recommendations)
    rec_table = next((t for t in rec_tables if "Recommended Action" in (t.get("headers") or [])), None)
    if not rec_table:
        failures.append("prioritised recommendations table is missing")
    else:
        rows = rec_table.get("rows") or []
        if not (4 <= len(rows) <= 12):
            warnings.append(f"recommendation count is {len(rows)}; normally 4-12 actionable items are expected")
        for row in rows:
            if len(row) < 5 or any(not str(cell).strip() for cell in row[1:5]):
                failures.append("a recommendation lacks priority, action, rationale, or evidence basis")
            if len(row) >= 2 and str(row[1]).upper() not in {"URGENT", "HIGH", "MEDIUM", "LOW"}:
                failures.append(f"unsupported recommendation priority: {row[1]}")

    # Executive prose should not expose machine-local paths or opaque finding UUIDs.
    if ABS_PATH_RE.search(executive_text):
        failures.append("executive sections expose an absolute host path")
    if UUID_RE.search(executive_text):
        failures.append("executive sections expose opaque generated UUIDs instead of material references")

    # Release identity and semantic assurance checks.  These checks are generic:
    # they compare the generated package with the installed release and with its
    # own structured statements; no case-specific expected value is used.
    try:
        from core.version import VERSION as RELEASE_VERSION
    except Exception:
        RELEASE_VERSION = ""
    reported_versions = {str(v).strip() for k, v in metadata.items() if "version" in str(k).casefold() and str(v).strip()}
    if RELEASE_VERSION and reported_versions and RELEASE_VERSION not in reported_versions:
        failures.append(
            f"report version metadata {sorted(reported_versions)} does not contain installed release version {RELEASE_VERSION}"
        )

    if re.search(r"(?i)across independent artefacts", full_text):
        failures.append("report calls duplicate/wrapper representations independent artefacts")

    decoded_hidden = any(token in full_text.upper() for token in (
        "STEGANOGRAPHIC_PAYLOAD_DECODED", "VERIFIED RECOVERED BYTES",
        "CONFIRMED HIDDEN OR APPENDED PAYLOAD BYTES",
    ))
    if decoded_hidden and re.search(r"(?i)potential steganography indicator.{0,160}indicator only", full_text):
        failures.append("deterministically decoded hidden/appended bytes are described only as a potential indicator")

    if re.search(r"(?is)encrypted or password-protected content.{0,600}hash(?:es)?\.txt", full_text):
        failures.append("standalone password-hash challenge file is grouped as encrypted/password-protected content")

    for call in metadata.get("api_calls") or []:
        if not call.get("success"):
            continue
        numeric = [call.get("input_tokens"), call.get("output_tokens"), call.get("duration_seconds")]
        if all(value in (0, 0.0, "0", "0.0") for value in numeric):
            failures.append("successful API call records misleading zero token and zero duration telemetry; use actual values or not_recorded")

    # Internal contradictions observed in validation reports.
    if "No deleted files were recovered" in full_text and "Deleted File Recovered" in full_text:
        failures.append("report contradicts itself about deleted-file recovery")
    if re.search(
        r"(?i)\b0\s+(?:artefacts?|artifacts?|objects?|files?)\s+examined;\s*[1-9]\d*\s+relevant",
        full_text,
    ):
        failures.append(
            "module narrative reports zero examined objects despite non-zero relevant findings"
        )

    # Distinct deleted-file records must not be inflated by duplicate module rows.
    deleted_names = {
        re.sub(r"(?i)^(?:deleted_)+", "", name.lower())
        for name in re.findall(
            r"(?i)/([A-Za-z0-9_.-]+\.(?:txt|pdf|jpg|jpeg|png|gif|bmp|zip|docx?|xlsx?))",
            full_text,
        )
        if "carve" in name.lower() or "deleted" in name.lower()
    }
    if deleted_names:
        distinct = len(deleted_names)
        deleted_material = next(
            (row for row in ((material or {}).get("rows") or [])
             if len(row) > 1 and "deleted" in str(row[1]).lower()),
            None,
        )
        if deleted_material:
            # Ignore the first table cell when it is only a row/index number.
            statement = " ".join(str(x) for x in deleted_material[1:])
            numbers = [int(x) for x in re.findall(r"\b\d+\b", statement)]
            if numbers and distinct not in numbers:
                failures.append(
                    f"material deleted-file count does not match distinct technical records ({distinct})"
                )
        for bad in set(re.findall(r"(?i)(?<![-A-Za-z0-9])(\d{1,3})[ \t]+(?:distinct[ \t]+)?deleted (?:files?|filesystem[ \t]+(?:records?|entries)|artefacts?|records?)\b", executive_text)):
            if int(bad) != distinct:
                failures.append(
                    f"executive deleted-file count {bad} does not match {distinct} distinct records"
                )

    # Detailed module prose must preserve the same execution state as the
    # summary table. A skipped/not-applicable capability is not a failed
    # forensic examination and must not be rendered as one.
    analysis = next(
        (sec for sec in sections if str(sec.get("section_title") or "").startswith("Analysis:")),
        None,
    )
    did_not_run_names: list[str] = []
    for table in _tables(analysis):
        headers = table.get("headers") or []
        if headers[:2] != ["Module", "Execution Outcome"]:
            continue
        for row in table.get("rows") or []:
            if len(row) >= 2 and str(row[1]).strip().upper() == "DID NOT RUN":
                did_not_run_names.append(str(row[0]).strip())
    for name in did_not_run_names:
        slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
        if re.search(rf"(?i)\b{re.escape(slug)}\s+v[^\n]{{0,40}}\bFAILED\s+on\b", full_text):
            failures.append(f"did-not-run module is rendered as FAILED in its detailed section: {name}")

    # Candidate OCR containing access/credential labels must not expose exact
    # values in the distributed report. The restricted module output may retain
    # the raw candidate for manual verification.
    if re.search(
        r'(?is)OCR produced.{0,240}(?:password|passwd|pwd|passcode|vpn|wi-?fi|admin|login|credential).{0,240}["“][^"”]{3,}["”]',
        full_text,
    ):
        failures.append("distributed report exposes unverified credential-labelled OCR candidate text")

    # Coverage must totalise every configured module, including zero-finding,
    # partial, failed and not-tested outcomes.
    coverage = _section(report, "Examination Coverage")
    analysis_modules: dict[str, str] = {}
    for table in _tables(analysis):
        headers = table.get("headers") or []
        if headers[:2] == ["Module", "Execution Outcome"]:
            for row in table.get("rows") or []:
                if len(row) >= 2:
                    analysis_modules[_module_audit_key(row[0])] = str(row[1]).strip().upper()
    coverage_modules: dict[str, tuple[str, str]] = {}
    for table in _tables(coverage):
        headers = table.get("headers") or []
        if headers[:3] in (
            ["Module", "Status", "Execution Status"],
            ["Module", "Status", "Execution Outcome"],  # legacy report package
        ):
            for row in table.get("rows") or []:
                if len(row) >= 6:
                    coverage_modules[_module_audit_key(row[0])] = (
                        str(row[2]).strip().upper(), str(row[5]).strip().upper()
                    )
                elif len(row) >= 5:
                    coverage_modules[_module_audit_key(row[0])] = (
                        str(row[2]).strip().upper(), str(row[4]).strip().upper()
                    )
    if analysis_modules and set(analysis_modules) != set(coverage_modules):
        missing = sorted(set(analysis_modules) - set(coverage_modules))
        extra = sorted(set(coverage_modules) - set(analysis_modules))
        failures.append(
            "coverage module set does not match configured module outcomes: "
            f"missing={missing[:12]} extra={extra[:12]}"
        )
    def _compatible_execution(finding_outcome: str, execution_status: str) -> bool:
        """Compare distinct dimensions without treating vocabulary differences as contradictions."""
        finding_outcome = str(finding_outcome or "").strip().upper()
        execution_status = str(execution_status or "").strip().upper()
        if not execution_status or execution_status == finding_outcome:
            return True
        # Finding outcome and procedural completeness are independent dimensions.
        # A module may execute, retain accepted findings, and still be partial
        # because a declared counter, parser, dependency or candidate remains
        # unresolved.  The coverage table carries that limitation explicitly.
        allowed = {
            "RAN FOUND X": {"EXECUTION_COMPLETE", "EXECUTION_PARTIAL"},
            "RAN FOUND NOTHING": {"EXECUTION_COMPLETE", "EXECUTION_PARTIAL"},
            "RAN WITH CAVEAT": {"EXECUTION_COMPLETE", "EXECUTION_PARTIAL"},
            "DID NOT RUN": {"EXECUTION_FAILED", "NOT_APPLICABLE", "OUT_OF_SCOPE"},
            "FAILED": {"EXECUTION_FAILED"},
        }
        return execution_status in allowed.get(finding_outcome, set())

    for name, outcome in analysis_modules.items():
        coverage_status, assurance = coverage_modules.get(name, ("", ""))
        if coverage_status and not _compatible_execution(outcome, coverage_status):
            failures.append(
                f"coverage execution status contradicts finding outcome for {name}: "
                f"{outcome} vs {coverage_status}"
            )
        if outcome == "RAN FOUND NOTHING" and "PRESENT" in assurance:
            failures.append(f"coverage marks PRESENT while analysis says ran found nothing: {name}")

    # Coverage verdicts cannot certify absence when a module did not run or was partial.
    for table in _tables(coverage):
        if "Verdict" not in (table.get("headers") or []):
            continue
        for row in table.get("rows") or []:
            row_text = " ".join(str(x) for x in row).lower()
            if "verified_absent" in row_text or "verified absent" in row_text:
                if any(token in row_text for token in (
                    "memory string", "timeline", "clamav", "registry", "no corpus",
                    "dependency_missing", "partial", "did not run", "skipped",
                )):
                    failures.append(f"unsupported VERIFIED ABSENT coverage verdict: {row[:3]}")

    # Section and appendix numbering must be unambiguous.
    titles = [str(sec.get("section_title") or "") for sec in sections]
    appendix_letters = [m.group(1) for title in titles if (m := re.match(r"(?i)Appendix\s+([A-Z])\b", title))]
    if len(appendix_letters) != len(set(appendix_letters)):
        failures.append("duplicate appendix letters are present")
    numeric = [(sec.get("section_number"), str(sec.get("section_title") or "")) for sec in sections]
    main_numbers = [n for n, title in numeric if isinstance(n, int) and 1 <= n < 90]
    if len(main_numbers) != len(set(main_numbers)):
        failures.append(f"duplicate main section numbers are present: {main_numbers}")
    limitations_section = _section(report, "Scope and Limitations")
    if not limitations_section or limitations_section.get("section_number") != 8:
        failures.append("Section 8 — Scope and Limitations is missing or misnumbered")
    refs = _section(report, "References")
    if refs and refs.get("section_number") != 9:
        failures.append("References section is not numbered as Section 9")

    # Carving presentation must use candidate terminology and must not deny
    # results when a carving module has recorded candidates.
    if "signature carved object" in full_text.lower() or "native signature carving" in full_text.lower():
        if "no signature-carving candidate objects were reported" in full_text.lower():
            failures.append("charts deny carving candidates despite recorded carving output")
    if "file types recovered by carving" in full_text.lower() and "structurally validated carved objects" not in full_text.lower():
        failures.append("carving chart uses 'recovered' without distinguishing structurally validated objects from candidates")

    # Filesystem listing entries include directories, metadata rows and deleted
    # records; they must never be restated as a count of distinct files.
    listing_counts = set(
        re.findall(r"(?i)\b(\d+)\s+filesystem listing entries\b", full_text)
    )
    for count in sorted(listing_counts):
        if re.search(
            rf"(?i)\b{re.escape(count)}\s+(?:distinct\s+)?files\b",
            executive_text,
        ):
            failures.append(
                f"filesystem listing-entry count {count} is presented as distinct files"
            )
    if "2026-07-26" in executive_text and "examination" not in executive_text.lower():
        warnings.append("executive text contains the report date; verify it is not presented as evidence activity")
    if "artefact-content timestamps" in executive_text.lower() and "module-processing" not in executive_text.lower():
        failures.append("WHEN does not distinguish evidence timestamps from processing timestamps")

    # Synthetic cases must not carry unresolved physical-document action pages.
    classification = str(metadata.get("classification") or "").lower()
    if any(x in classification for x in ("synthetic", "validation")):
        if "operator action required" in full_text.lower():
            failures.append("synthetic validation report contains unresolved physical-document action pages")

    # Circular/in-document seal language is prohibited; hashes must be detached.
    if "excluding this seal page" in full_text.lower() or "cryptographic seal page" in full_text.lower():
        failures.append("report contains a non-reproducible embedded seal instruction")

    if require_llm and llm_used and len(successful_exec_calls) != 1:
        failures.append(
            f"accepted LLM prose requires exactly one successful executive synthesis record; found {len(successful_exec_calls)}"
        )
    elif len(successful_exec_calls) > 1:
        warnings.append(f"multiple successful executive synthesis calls recorded: {len(successful_exec_calls)}")

    quality_warnings = metadata.get("quality_warnings") or []
    if quality_warnings:
        warnings.append(f"report metadata contains {len(quality_warnings)} quality warning(s)")

    return failures, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-json", type=Path, help="Generated AutoForensics report JSON")
    parser.add_argument("--pdf", type=Path, help="Optional generated PDF to cross-check; the paired *_report.json is auto-discovered when possible")
    parser.add_argument(
        "--require-llm-record", action="store_true",
        help="Require a recorded provider response; accepted prose needs one successful deep_analysis call",
    )
    args = parser.parse_args()

    if not args.report_json and not args.pdf:
        parser.error("provide --report-json and/or --pdf")

    report_json = args.report_json
    if report_json is None and args.pdf:
        candidates = [
            args.pdf.with_suffix(".json"),
            args.pdf.with_name(args.pdf.stem + ".json"),
        ]
        # Normal generated names are <case>_report.pdf / <case>_report.json.
        if args.pdf.stem.endswith("_report"):
            candidates.insert(0, args.pdf.with_name(args.pdf.stem + ".json"))
        report_json = next((c for c in candidates if c.is_file()), None)

    if report_json is None or not report_json.is_file():
        print("[FAIL] generated report JSON is required for the full assurance audit; pass --report-json", file=sys.stderr)
        return 2
    try:
        report = json.loads(report_json.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[FAIL] cannot read report JSON: {exc}", file=sys.stderr)
        return 2

    failures, warnings = _failures_for_json(report, require_llm=args.require_llm_record)

    if args.pdf:
        if not args.pdf.is_file():
            failures.append(f"PDF not found: {args.pdf}")
        else:
            try:
                pdf_text = _extract_pdf_text(args.pdf)
            except Exception as exc:
                failures.append(f"could not extract PDF text: {exc}")
            else:
                json_text = "\n".join(_text_values(report))
                for heading in REQUIRED_EXECUTIVE_HEADINGS:
                    if heading.lower() not in pdf_text.lower():
                        failures.append(f"PDF is missing rendered heading: {heading}")
                for phrase in FORBIDDEN_PHRASES:
                    if phrase.lower() in pdf_text.lower():
                        failures.append(f"PDF contains forbidden phrase: {phrase}")
                pagination_failures, pagination_warnings = _validate_pdf_pagination(args.pdf)
                failures.extend(pagination_failures)
                warnings.extend(pagination_warnings)
                if "CASE" not in pdf_text.upper() and "REPORT" not in pdf_text.upper():
                    failures.append("PDF text extraction does not resemble the generated report")
                if len(pdf_text) < max(500, int(len(json_text) * 0.05)):
                    warnings.append("PDF extracted text is unexpectedly short relative to report JSON")

        manifest = args.pdf.with_name(args.pdf.stem + "_manifest.json")
        if manifest.is_file():
            try:
                manifest_data = json.loads(manifest.read_text(encoding="utf-8"))
                import hashlib
                pdf_hash = hashlib.sha256(args.pdf.read_bytes()).hexdigest()
                json_hash = hashlib.sha256(report_json.read_bytes()).hexdigest()
                if manifest_data.get("report_pdf_sha256") != pdf_hash:
                    failures.append("detached manifest PDF hash does not match the generated PDF")
                if manifest_data.get("report_json_sha256") != json_hash:
                    failures.append("detached manifest JSON hash does not match the generated JSON")
            except Exception as exc:
                failures.append(f"cannot validate detached report manifest: {exc}")
        else:
            failures.append("detached report-integrity manifest is missing")

    for warning in warnings:
        print(f"[WARN] {warning}")
    if failures:
        for failure in failures:
            print(f"[FAIL] {failure}")
        print(f"\nREPORT OUTPUT AUDIT FAILED ({len(failures)} failure(s), {len(warnings)} warning(s))")
        return 1

    print(f"REPORT OUTPUT AUDIT PASSED ({len(warnings)} warning(s))")
    print("This gate checks structure, traceability and known reporting defects; examiner verification of the evidence remains required.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
