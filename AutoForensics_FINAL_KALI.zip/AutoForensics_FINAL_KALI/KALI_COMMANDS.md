# Kali execution guide — AutoForensics

## 1. Verify, extract and install

```bash
cd "$HOME/Desktop"
sha256sum -c AutoForensics_v2.8.6_KALI.zip.sha256
unzip -t AutoForensics_v2.8.6_KALI.zip
rm -rf AutoForensics_v2.8.6_KALI
unzip -q AutoForensics_v2.8.6_KALI.zip
cd AutoForensics_v2.8.6_KALI
chmod +x install.sh run_final.sh verify_final.sh package_outputs.sh \
  verify_source_release.sh package_source.sh tools/acquire_devices.py
AUTOFORENSICS_INSTALL_OPTIONAL=1 AUTOFORENSICS_UPDATE_CLAMAV=1 bash install.sh
bash verify_source_release.sh
python3 run.py --version
python3 run.py --check
```

## 2. First-run investigator setup

```bash
cd "$HOME/Desktop/AutoForensics_v2.8.6_KALI"
python3 tools/admin.py set-admin-password
python3 tools/admin.py add-investigator
python3 tools/admin.py list-investigators
```

Use the investigator ID created above. Do not store the investigator password or OpenAI key in a script.

## 3. Existing-image investigation

```bash
cd "$HOME/Desktop/AutoForensics_v2.8.6_KALI"
EVIDENCE="$HOME/Desktop/evidence.E01"
CASE_ID="AF-V285-$(date +%Y%m%d-%H%M%S)"
OUTPUT="$HOME/Desktop/${CASE_ID}_OUTPUT"

[[ -f "$EVIDENCE" ]] || { echo "Evidence not found: $EVIDENCE"; exit 1; }
sha256sum "$EVIDENCE"

bash run_final.sh \
  --evidence "$EVIDENCE" \
  --case-id "$CASE_ID" \
  --output "$OUTPUT" \
  --evidence-domain auto \
  --profile full \
  --investigator-id "examiner-id" \
  --investigator-name "Authorised Examiner" \
  --badge "examiner-badge" \
  --institution "Organisation"
```

Add only genuine administrative metadata and files supplied for the case.

## 4. Prepare for an attached evidence SSD

The evidence SSD must be connected as an external whole device. The output remains on a different disk, normally the Kali system disk when it has adequate free space.

Disable desktop automount before connecting the evidence SSD:

```bash
gsettings set org.gnome.desktop.media-handling automount false 2>/dev/null || true
gsettings set org.gnome.desktop.media-handling automount-open false 2>/dev/null || true
```

Connect the SSD, then list devices without acquiring anything:

```bash
cd "$HOME/Desktop/AutoForensics_v2.8.6_KALI"
LIVE_CASE="AF-LIVE-$(date +%Y%m%d-%H%M%S)"
LIVE_OUTPUT="$HOME/Desktop/${LIVE_CASE}_OUTPUT"
mkdir -p "$LIVE_OUTPUT"

findmnt -no SOURCE /
lsblk -d -o NAME,PATH,TYPE,RO,RM,SIZE,VENDOR,MODEL,SERIAL,REV,TRAN
python3 tools/acquire_devices.py --list --output-dir "$LIVE_OUTPUT"
```

Identify the evidence **whole disk**, such as `/dev/sdb`. Never use a partition such as `/dev/sdb1`. Confirm that it is not the device shown by `findmnt -no SOURCE /` and is not the destination disk.

## 5. Integrated software-read-only acquisition and analysis

Set the exact device path only after reviewing the list:

```bash
EVIDENCE_DEVICE="/dev/sdX"   # replace with the exact whole evidence disk
INVESTIGATOR_ID="examiner-id"
REGISTRY="$HOME/.config/autoforensics/investigators.json"

export AUTOFORENSICS_INVESTIGATORS_REGISTRY="$REGISTRY"
export AUTOFORENSICS_WRITE_BLOCK_METHOD="software"
export AUTOFORENSICS_ACQUISITION_FORMAT="e01"
export AUTOFORENSICS_EVIDENCE_ID="SSD-001"

sudo --preserve-env=AUTOFORENSICS_INVESTIGATORS_REGISTRY,AUTOFORENSICS_WRITE_BLOCK_METHOD,AUTOFORENSICS_ACQUISITION_FORMAT,AUTOFORENSICS_EVIDENCE_ID \
  python3 run.py --skip-check \
  --case-id "$LIVE_CASE" \
  --investigator-id "$INVESTIGATOR_ID" \
  --profile full \
  --device "$EVIDENCE_DEVICE" \
  --output-dir "$LIVE_OUTPUT"
```

The platform must stop unless it can:

- unmount all source partitions;
- set the whole source and child partitions read-only;
- verify kernel/sysfs or `blockdev` read-only state;
- verify that no source partition remains mounted;
- exclude system, project and output disks;
- acquire and verify the complete source byte stream;
- match pre-analysis and post-analysis image hashes.

The report must state `SOFTWARE_ENFORCED_READ_ONLY` and that this is not equivalent to a certified hardware blocker.

After the run:

```bash
sudo chown -R "$USER:$USER" "$LIVE_OUTPUT"
find "$LIVE_OUTPUT" -name '*acquisition_manifest.json' -print
jq '.write_protection, .source_pre_vs_acquired, .source_pre_vs_source_post, .pre_vs_post_container_set, .pre_vs_post_logical_media, .status' \
  "$(find "$LIVE_OUTPUT" -name '*acquisition_manifest.json' -print -quit)"
```

## 6. Standalone acquisition only

Use this only when acquisition and analysis are intentionally separated:

```bash
ACQ_DIR="$HOME/Desktop/${LIVE_CASE}_ACQUISITION"
DEVICE_BASENAME="$(basename "$EVIDENCE_DEVICE")"

sudo --preserve-env=PYTHONPATH python3 tools/acquire_devices.py \
  --device "$EVIDENCE_DEVICE" \
  --output-dir "$ACQ_DIR" \
  --case-id "$LIVE_CASE" \
  --evidence-id "SSD-001" \
  --investigator "Shlok Vijay Trivedi" \
  --format e01 \
  --write-protection software \
  --confirm "ACQUIRE-${DEVICE_BASENAME}-${LIVE_CASE}"
```

Then analyse the created E01 with `run_final.sh`. After analysis, verify the acquisition manifest again:

```bash
MANIFEST="$(find "$ACQ_DIR" -name '*acquisition_manifest.json' -print -quit)"
sudo --preserve-env=PYTHONPATH python3 tools/acquire_devices.py --verify-post-analysis "$MANIFEST"
```

## 7. Raw acquisition alternative

```bash
sudo --preserve-env=PYTHONPATH python3 tools/acquire_devices.py \
  --device "$EVIDENCE_DEVICE" \
  --output-dir "$ACQ_DIR" \
  --case-id "$LIVE_CASE" \
  --evidence-id "SSD-001" \
  --investigator "Shlok Vijay Trivedi" \
  --format raw \
  --write-protection software \
  --confirm "ACQUIRE-${DEVICE_BASENAME}-${LIVE_CASE}"
```

GNU `ddrescue` is preferred. The `dd` fallback uses the detected logical sector size and exact sector count; it refuses ambiguous size metadata.

## 8. Verify report, chain and output package

```bash
bash verify_final.sh --output "$LIVE_OUTPUT" --allow-incomplete
bash package_outputs.sh --output "$LIVE_OUTPUT"

REPORT_SIG="$(find "$LIVE_OUTPUT/reports" -name '*_report_signature.json' -print -quit)"
PUBLIC_KEY="$(find "$LIVE_OUTPUT/reports" -name '*_report_signing_public.pem' -print -quit)"
python3 tools/verify_report_signature.py \
  --signature "$REPORT_SIG" \
  --public-key "$PUBLIC_KEY" \
  --base-dir "$LIVE_OUTPUT/reports"

sha256sum "$LIVE_OUTPUT"_VERIFICATION_BUNDLE.zip
unzip -t "$LIVE_OUTPUT"_VERIFICATION_BUNDLE.zip
```

A custody HMAC can be independently rechecked only with the separately retained case custody key. Private report-signing and custody keys must not be placed in reviewer bundles.
