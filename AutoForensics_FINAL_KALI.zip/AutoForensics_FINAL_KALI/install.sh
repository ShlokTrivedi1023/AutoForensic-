#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != "Linux" ]]; then echo "ERROR: AutoForensics targets Kali/Debian Linux." >&2; exit 2; fi
if ! command -v python3 >/dev/null; then echo "ERROR: python3 is required." >&2; exit 2; fi
python3 - <<'PY'
import sys
if sys.version_info < (3,11): raise SystemExit('Python 3.11+ is required')
print('Python:',sys.version.split()[0])
PY
if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  env PYTHONDONTWRITEBYTECODE=1 bash tools/install_kali_dependencies.sh
elif command -v sudo >/dev/null 2>&1; then
  sudo env \
    PYTHONDONTWRITEBYTECODE=1 \
    AUTOFORENSICS_INSTALL_OPTIONAL="${AUTOFORENSICS_INSTALL_OPTIONAL:-0}" \
    AUTOFORENSICS_UPDATE_CLAMAV="${AUTOFORENSICS_UPDATE_CLAMAV:-0}" \
    bash tools/install_kali_dependencies.sh
  sudo chown -R "$(id -u):$(id -g)" "$ROOT"
else
  echo "ERROR: root or sudo is required to install Kali system dependencies." >&2
  exit 2
fi
find "$ROOT" -type d -name __pycache__ -prune -exec rm -rf {} +
python3 -m compileall -q -f core modules tools tests run.py
python3 tools/release_selfcheck.py
printf '\nINSTALLATION CHECK COMPLETE\n'
