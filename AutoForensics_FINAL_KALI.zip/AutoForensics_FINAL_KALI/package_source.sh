#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
VERSION="$(cat VERSION)"
DEFAULT_ARCHIVE="$(cd "$ROOT/.." && pwd)/AutoForensics_v${VERSION}_KALI.zip"
ARCHIVE="${1:-$DEFAULT_ARCHIVE}"

./verify_source_release.sh release/SOURCE_RELEASE_VALIDATION.log
python3 tools/generate_source_hashes.py

python3 - "$ROOT" "$ARCHIVE" <<'PYCODE'
from __future__ import annotations
import hashlib, shutil, sys, tempfile, zipfile
from pathlib import Path
src=Path(sys.argv[1]).resolve(); archive=Path(sys.argv[2]).resolve()
root_name=f"AutoForensics_v{(src/'VERSION').read_text().strip()}_KALI"
excluded_parts={"__pycache__",".pytest_cache",".mypy_cache",".ruff_cache",".venv","venv","output","outputs"}
excluded_names={archive.name,archive.name+'.sha256'}
files=[]
for p in sorted(src.rglob('*')):
    if not p.is_file(): continue
    rel=p.relative_to(src)
    if any(part in excluded_parts for part in rel.parts) or p.suffix=='.pyc' or p.name in excluded_names:
        continue
    files.append(p)
if not files: raise SystemExit('ERROR: source tree is empty')
archive.parent.mkdir(parents=True,exist_ok=True)
tmp=archive.with_suffix(archive.suffix+'.tmp')
for target in (tmp,archive,Path(str(archive)+'.sha256')):
    target.unlink(missing_ok=True)
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
    for p in files:
        info=zipfile.ZipInfo(f"{root_name}/{p.relative_to(src).as_posix()}",date_time=(2026,8,6,12,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=(p.stat().st_mode & 0xFFFF)<<16
        z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(tmp) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f'ERROR: ZIP CRC failure: {bad}')
    names=[i.filename for i in z.infolist() if not i.is_dir()]
    if len(names)!=len(files): raise SystemExit('ERROR: ZIP member count mismatch')
    forbidden=[n for n in names if any(part in excluded_parts for part in Path(n).parts) or n.endswith('.pyc')]
    if forbidden: raise SystemExit(f'ERROR: generated residue packaged: {forbidden[:5]}')
    with tempfile.TemporaryDirectory(prefix='af_source_release_') as td:
        z.extractall(td)
        extracted=Path(td)/root_name
        for p in files:
            q=extracted/p.relative_to(src)
            if not q.is_file(): raise SystemExit(f'ERROR: extracted file missing: {q}')
            if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(q.read_bytes()).digest():
                raise SystemExit(f'ERROR: extracted file hash mismatch: {q}')
shutil.move(tmp,archive)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
Path(str(archive)+'.sha256').write_text(f"{digest}  {archive.name}\n",encoding='utf-8')
print(f"SOURCE ZIP CREATED: {archive}")
print(f"SOURCE ZIP SHA-256: {digest}")
print(f"SOURCE ZIP FILES: {len(files)}")
PYCODE
