#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
mkdir -p release
LOG="${1:-release/SOURCE_RELEASE_VALIDATION.log}"

run_checks() {
  echo "AutoForensics source release verification"
  echo "Version: $(cat VERSION)"
  echo "Python: $(python3 --version 2>&1)"
  echo "UTC start: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo

  find "$ROOT" -type d \( -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache \) -prune -exec rm -rf {} +
  find "$ROOT" -type f -name '*.pyc' -delete

  python3 -m compileall -q -f core modules tools tests run.py
  python3 -m pytest -q
  python3 tools/verify_regression_lock.py

  SCAN_ARGS=()
  if [[ -n "${AUTOFORENSICS_DENYLIST:-}" ]]; then
    [[ -f "$AUTOFORENSICS_DENYLIST" ]] || {
      echo "ERROR: AUTOFORENSICS_DENYLIST does not exist: $AUTOFORENSICS_DENYLIST" >&2
      return 2
    }
    SCAN_ARGS=(--denylist "$AUTOFORENSICS_DENYLIST")
  fi

  python3 tools/anti_hardcoding_scan.py "${SCAN_ARGS[@]}" --json-output release/ANTI_HARDCODING_SCAN.json
  python3 tools/release_selfcheck.py

  find "$ROOT" -type d \( -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache \) -prune -exec rm -rf {} +
  find "$ROOT" -type f -name '*.pyc' -delete
  python3 tools/release_hygiene_scan.py "${SCAN_ARGS[@]}" --json-output release/RELEASE_HYGIENE_SCAN.json
  python3 tools/generate_source_hashes.py

  find "$ROOT" -type d \( -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache \) -prune -exec rm -rf {} +
  find "$ROOT" -type f -name '*.pyc' -delete

  echo
  echo "SOURCE RELEASE VERIFICATION PASSED"
  echo "UTC end: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
}

run_checks 2>&1 | tee "$LOG"
