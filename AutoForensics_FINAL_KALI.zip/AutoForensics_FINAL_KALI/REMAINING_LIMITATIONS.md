# Remaining honest limitations — v2.8.6

1. **Physical acquisition is implemented but not physically executed in this build environment.** It must be validated on the investigator's Kali workstation using controlled media before the release can claim a completed attached-device test.
2. **Software read-only protection is not a hardware blocker.** The software fallback is fail-closed and recorded, but a certified hardware blocker offers stronger isolation for real evidential acquisition.
3. **Real RAM validation remains corpus-dependent.** The Volatility adapter, dependency handling and randomised marker paths are tested. Genuine Windows/Linux RAM structures require compatible acquisitions, symbols and working Volatility plugins.
4. **Mobile analysis is logical, not physical acquisition.** The module parses supported Android/iOS extraction directories, archives, SQLite artefacts and LEAPP outputs. It does not extract a phone through USB or claim commercial-UFDR equivalence.
5. **External-tool modules require Kali dependencies.** Missing YARA, ClamAV, bulk_extractor, ExifTool, Hashcat or other named tools must produce blocked/incomplete/failed states, not a false pass.
6. **The primary E01 is synthetic.** Perfect results on this controlled corpus do not prove universal real-world accuracy.
7. **Legal use remains human-controlled.** Hashing proves integrity of the hashed object, not the truth of every interpretation. Examiner review, authority, laboratory procedure and jurisdictional requirements remain mandatory.
