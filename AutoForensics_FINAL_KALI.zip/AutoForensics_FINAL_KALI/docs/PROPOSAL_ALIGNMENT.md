# Proposal alignment — v2.8.0

Two figures are intentionally separated:

- **Implemented proposal alignment: 91.0%** — code paths, tests and primary-corpus evidence available in this release.
- **Fully validated proposal alignment: 87.0%** — excludes points that still require a genuine attached SSD, real RAM corpus or full Kali dependency run.

## Implemented alignment calculation

| Area | Weight | Score | Basis |
|---|---:|---:|---|
| Functional objectives and module scope | 30 | 25.0 | 45 active modules; Autopsy removed; two intake paths implemented; real RAM/physical-mobile validation incomplete |
| H1 efficiency | 15 | 15.0 | Treated as completed under the established project result |
| H2 reliability | 20 | 19.0 | Primary TP=38, FP=0, FN=0; provenance and semantic audits pass; wider corpora limited |
| Deterministic architecture/reproducibility | 15 | 14.0 | Case-neutral parsing, hard-coding scans, lock and 91 tests |
| Reporting, custody and examiner review | 10 | 9.0 | Signed report, integrity table and extended custody path; physical acquisition report not yet produced |
| Ethics and limitations | 5 | 4.5 | Synthetic, software-blocker and legal limits explicit |
| Packaging/independent usability | 5 | 4.5 | Clean deterministic ZIP/checksum and commands; final Kali physical validation pending |
| **Total** | **100** | **91.0** | |

## Remaining proposal gaps

- genuine attached-device acquisition must be executed and verified on Kali;
- genuine supported RAM and Volatility results require a real memory corpus;
- specialist mobile validation requires suitable authorised logical extraction/LEAPP corpus;
- the source must pass a fresh fully provisioned Kali investigation with all applicable external dependencies.

No score is increased merely by changing wording or counting removed/untested modules.
