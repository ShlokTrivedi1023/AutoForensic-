# Autopsy removal record — v2.8.0

The `autopsy_analysis` integration was removed because no compatible genuine headless ingest was available.

Removed from:
- module source and package export
- authoritative module registry and every profile
- scope contracts and frozen locks
- report module maps and screenshot appendices
- strict completion and output-validation counts
- dependency and release documentation
- Autopsy-specific tests and fallback logic

The final active registry contains exactly 45 modules. No placeholder, simulated result, native fallback, or disabled Autopsy row is counted. Historical context appears only in this removal record and the changelog.
