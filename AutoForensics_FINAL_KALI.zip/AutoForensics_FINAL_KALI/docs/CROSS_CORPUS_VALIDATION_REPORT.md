# Cross-corpus validation report — v2.8.0

## Executed corpora

| Corpus | Purpose | Outcome |
|---|---|---|
| AF-UNIFIED synthetic E01 | Primary full-pipeline reference | 38/38 evidence items, 77/77 files and 27/27 timeline events; system TP=38, FP=0, FN=0 |
| Randomised structured-memory corpora | Different filenames, case IDs, domains, IPs, credentials and markers | Positive records detected with source offsets; random-byte and malformed controls produced no accepted findings |
| Randomised literal-memory-string corpora | ASCII/UTF-16LE extraction | Runtime-generated URL/email detected; random-byte negative produced no findings |
| Randomised Android SQLite corpus | Logical mobile parsing | SMS record detected with structured provenance |
| Randomised iOS SQLite corpus | Logical mobile parsing | iMessage record detected with structured provenance |
| Empty supported mobile directory | Negative control | No fabricated finding; valid no-result behaviour retained |
| Fake dynamically located Volatility executable | Adapter/command validation | Path, command, input and plugin recorded; output parsed by integration path |
| Missing Volatility dependency | Failure control | Explicit `FileNotFoundError`; no false success |
| Controlled raw acquisition file | Acquisition/hash workflow | Source, acquired-content and pre/post hashes matched |
| Mutated acquired image | Integrity negative control | Post-analysis verification failed closed |
| Unverified write-protection record | Safety negative control | Acquisition refused |

## Primary output caveat

The v2.8.0 E01 run in this container loaded all 45 modules and generated a signed 176-page report. The container lacked several Kali binaries, so the strict all-module gate correctly failed with 37 PASS_COMPLETE, 2 NOT_APPLICABLE, 3 INCOMPLETE and 3 FAILED_ISOLATED. This is an environment smoke run, not the final Kali acceptance run. Its report signature, report audit and H2 semantic audit passed.

## Not executed here

- a physical attached SSD;
- a certified hardware write blocker;
- a genuine supported RAM capture with real Volatility structures;
- physical phone acquisition;
- an independent public corpus beyond the supplied reference and isolated randomised fixtures.

Generated fixtures are isolated in tests and do not provide expected values to production code. They support generalisation and failure-behaviour testing but do not prove universal real-world capability.
