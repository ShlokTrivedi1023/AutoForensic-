# Regression report — v2.7.4 to v2.8.0

| Area | v2.7.4 | v2.8.0 result |
|---|---|---|
| Active modules | 46 including incomplete Autopsy | 45; Autopsy removed |
| Frozen verified group | 37 | 37 preserved and lock-verified |
| Targeted modules | Eight honestly limited | Eight targeted implementations/tests added; real-corpus boundaries remain explicit |
| Primary MASTER evidence | 38/38 | 38/38 in container smoke run |
| Primary file manifest | 77/77 | 77/77 exact |
| Primary timeline | 27/27 | 27/27 |
| System FP/FN on primary corpus | 0/0 | 0/0 |
| Accepted findings | 413 in v2.7.4 Kali run | 369 in v2.8.0 container run; difference is environment/tool availability, not a claim of regression-free Kali output |
| Report integrity | Passed | Signed report, output audit and H2 semantic audit passed |
| Acquisition | Existing images only | Attached-device implementation and controlled hash tests added; physical test pending |
| Source hard-coding | None identified | 109 runtime files, zero generic/external-denylist violations |

The 37 frozen modules pass source-lock verification. The v2.8.0 container did not contain all Kali binaries, so a fresh fully provisioned Kali run is required before comparing exact per-module accepted counts with the v2.7.4 Kali baseline.
