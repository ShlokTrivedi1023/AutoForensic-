# Engineering changelog — v2.8.0

| File / component | Root cause | Code-level repair | Validation |
|---|---|---|---|
| `config/modules.yaml`, registry/profile/report/validation mappings | Autopsy could not perform genuine headless ingest but remained counted | Removed registration, invocation, dependency, report and count entries; active count is 45 | Registry self-check, lock verification, 91 tests |
| `core/acquisition.py` | No complete fail-closed attached-device acquisition lifecycle | Added safe discovery, explicit source selection, disk exclusions, verified write protection, E01/raw acquisition, five-stage hashes and post-analysis verification | Positive acquisition, mutation, refusal and manifest-change tests |
| `core/main.py` | Existing image and live attached-device paths did not share a proven lifecycle | Integrated acquisition before normal mounting/analysis and post-analysis verification afterward; custody events include device/protection/hash stages | Import/regression suite and controlled acquisition tests |
| `core/report_sections.py` | Report did not clearly distinguish source, logical-media and compressed-container hashes | Added acquisition integrity fields/table and explicit explanatory limits | Report output audit passed |
| `core/volatility_adapter.py` | Memory modules relied on one fixed `vol.py` path | Added environment/config/PATH/standard-location discovery and command/version records | Fake-launcher and missing-dependency tests |
| Five structural memory modules | Fixed-path dependency and unclear marker-vs-structural scope | Routed structural execution through central adapter; deterministic marker scope remains separately labelled | Randomised marker positive/negative/malformed tests; primary corpus run |
| `memory_string_analyzer` | Wider semantic interpretation risk | Retained exhaustive literal ASCII/UTF-16LE extraction with occurrence provenance and no process/ownership inference | Randomised positive and negative tests |
| `mobile_analyzer` | A supported valid-empty extraction could be labelled partial because findings were empty | Completion now depends on parser manifest/accounting, not non-zero findings | Randomised Android, iOS and negative-control tests |
| `image_mounter` | Module name could imply an OS mount was mandatory | Declared scope is verified read-only evidence access; native stream access is valid and OS mount status is separate | Random path positive and missing-path failure test |
| `tools/evaluate_master_reference.py` | Removing Autopsy shifted historical MASTER numbers and caused `KeyError: 46` | Added immutable historical 46-slot mapping and separate 45-module active order | Historical slots 6/46 regression tests; 38/38 evaluation |
| `tools/acquire_devices.py` | Incorrect imported verifier name prevented direct execution | Corrected import/call and added CLI smoke test | `--help` test passes |
| `tools/admin.py` | Direct execution could not import `core` | Publishes project root to `sys.path` before project imports | Direct `--help` test passes |
| `install.sh`, dependency installer | Optional install flags were lost across `sudo`; raw imaging dependency absent | Explicitly forwards flags; installs `gddrescue` and `util-linux` | Shell syntax and release verification |
