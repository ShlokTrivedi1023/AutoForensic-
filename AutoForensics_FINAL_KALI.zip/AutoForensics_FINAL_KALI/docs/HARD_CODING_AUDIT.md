# Hard-coding and case-independence audit

## Scope

Runtime Python, shell, YAML/JSON configuration and report templates were scanned for machine-specific paths, reference/test imports, literal case/hash comparisons and an external denylist built from the supplied E01 and MASTER values.

External denylist examples included the AF-UNIFIED case/evidence identifiers, evidence SHA-256 values, planted domain/IP/email/password values and distinctive planted filenames.

## Result

- Runtime files scanned: **109**
- Generic anti-hardcoding violations: **0**
- External denylist violations: **0**
- Production imports from tests/fixtures/reference namespaces: **0**
- MASTER data used by investigation runtime: **No**

`tools/evaluate_master_reference.py` and post-run validation tools may read external MASTER files. They are expressly excluded from production detection and cannot create or promote findings.

Remaining textual references to “Autopsy” are limited to:

- historical removal/migration documentation;
- the immutable historical 46-slot MASTER-number map;
- generic forensic-tool-name recognition inside evidence artefacts.

They do not register, invoke, simulate, report or count an Autopsy module.
