# Dependency compatibility matrix

| Capability | Required command/library | Acceptance check | Missing behaviour |
|---|---|---|---|
| E01 acquisition | `ewfacquire` from libewf/ewf-tools | command exists, returns success, image exists, logical-content hash matches source | acquisition fails |
| Raw acquisition | `ddrescue` preferred; GNU `dd` fallback | output exists, exact byte count/hash matches source | acquisition fails/refuses ambiguous metadata |
| Device safety | `lsblk`, `findmnt`, `blockdev`, `umount` | JSON discovery; source/output/system exclusion; read-only and mount verification | acquisition fails |
| Structural memory | Volatility 3 `vol`, `vol.py` or Python module | launcher resolves, version/command captured, plugin returns supported output | blocked/failed, never empty success |
| Android/iOS enrichment | ALEAPP/iLEAPP | executable/script resolves and compatible extraction is supplied | native logical scope remains separate; LEAPP not claimed |
| YARA | `yara` plus valid rules | executable and rule validation | failed/blocked module |
| ClamAV | `clamscan` plus usable database/signature source | executable/database capability probe | failed/blocked module |
| Bulk extraction | `bulk_extractor` | executable capability probe and output | failed/blocked module |
| Metadata | `exiftool` | executable and parse output | named ExifTool scope incomplete |
| Password recovery | `hashcat`, `john` | version/capability probe and supported hash input | named tool scope incomplete/blocked |
| OCR | Tesseract | executable plus retained candidate/corroboration policy | OCR scope blocked; no fabricated transcription |
| PDF/reporting | ReportLab, pypdf, cryptography | import and report/signature verification | report generation fails |

Exact installed versions are recorded at runtime. The release does not claim compatibility merely because a command name exists; the required operation must succeed on the supplied input.
