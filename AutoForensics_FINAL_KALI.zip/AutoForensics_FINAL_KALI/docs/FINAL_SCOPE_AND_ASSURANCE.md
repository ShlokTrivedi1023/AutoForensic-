# Final scope and assurance

The MASTER reference is accepted only as an optional post-investigation validation input. It is never loaded by the investigation pipeline and cannot create, modify or promote findings. Runtime findings originate from evidence parsing and are stored before reference comparison.

A passing MASTER comparison means that the tested output matched the supplied reference at the defined measurement level. It does not prove universal accuracy, laboratory accreditation, court admissibility or performance on an untested dataset.
