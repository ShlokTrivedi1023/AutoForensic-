# AutoForensics v2.8.5 — Exhaustive coverage contract

The production default is **no silent truncation** for supported evidence classes. A discovered supported object must be processed or represented with an explicit non-complete state and reason.

## Contract

- `0` on processing limits means unlimited/exhaustive.
- A positive user/operator resource cap is permitted, but reaching it must prevent an exhaustive COMPLETE claim and must expose discovered/processed/unresolved counts.
- Duplicate byte streams may be analysed once for content efficiency, but every distinct evidentiary source path remains inventoried as provenance/alias information.
- Bounded report previews, screenshots and human-readable examples are presentation controls only; they must not bound primary parsing or machine-readable artefact retention.
- Corrupt, partial, encrypted or unsupported objects are not silently discarded. They are retained as candidate/rejected/unresolved observations when a deterministic classification can be made.
- Absence of recoverability (for example overwritten bytes or encrypted content without credentials) is an evidence limitation, not permission to fabricate a result.

This contract is case-neutral and contains no expected findings for a validation image.
