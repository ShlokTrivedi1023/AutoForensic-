# Attached-device acquisition implementation

## Device discovery and safety

`core.acquisition.discover_devices()` obtains whole-disk metadata from `lsblk -J -b`, including path, vendor, model, serial, firmware, transport, size, sector sizes, partition table, child partitions, mount state and read-only state. It identifies the block-device ancestry of `/`, the project and the output destination. For a new output directory it resolves the nearest existing parent before identifying the destination disk.

The engine never automatically selects the first disk. Partitions are not accepted as acquisition sources. The system, project and output disks are rejected.

## Write protection

Hardware mode requires manufacturer, model, serial, firmware and connection details and still verifies the exposed kernel read-only state.

Software mode:

1. unmounts all source partitions;
2. sets every child and the whole device read-only using `blockdev --setro`;
3. checks sysfs and/or `blockdev --getro`;
4. verifies all child partitions are read-only;
5. verifies that no partition remains mounted;
6. stops when verification fails.

No destructive write attempt is made against evidence. Software protection is recorded as `SOFTWARE_ENFORCED_READ_ONLY` and explicitly described as weaker than a certified hardware blocker.

## Imaging

- E01: `ewfacquire`, segmented at 2,073,741,824 bytes, with case/evidence/examiner metadata.
- Raw: GNU `ddrescue` preferred. The GNU `dd` fallback uses the detected logical sector size and exact sector count and refuses ambiguous device metadata.
- Physical acquisition means a complete whole-device byte stream. Logical file copying is not labelled physical imaging.

## Integrity stages

1. source byte-stream SHA-256 before acquisition;
2. acquired logical-content SHA-256 compared with source;
3. source byte-stream SHA-256 after acquisition compared with source pre-hash;
4. ordered segment/container-set SHA-256 and logical-media SHA-256 before analysis;
5. the same hashes after analysis.

Compressed E01 container hashes and source-content hashes are different objects. The report never expects them to be equal.

## Failure handling

The acquisition fails closed for unverified write protection, source/output conflict, failed commands, missing image, source-size change, acquisition-content mismatch or post-analysis image mutation. Partial logs remain evidence for review but are not labelled successful acquisition.

## Validation state

Controlled regular-file tests prove exact raw-copy hashing, pre/post integrity matching, mutation detection, unverified-protection refusal and segment-manifest change detection. A genuine physical SSD was not available in this execution environment; the Kali physical test remains mandatory.
