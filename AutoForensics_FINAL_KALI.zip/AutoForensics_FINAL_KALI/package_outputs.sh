#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
usage(){ echo "Usage: ./package_outputs.sh --output DIR [--archive PATH]"; }
OUTPUT="";ARCHIVE=""
while (($#)); do case "$1" in --output) OUTPUT="$2";shift 2;; --archive) ARCHIVE="$2";shift 2;; -h|--help) usage;exit 0;; *) echo "Unknown: $1" >&2;exit 2;; esac;done
[[ -d "$OUTPUT" ]] || { echo "ERROR: output missing: $OUTPUT" >&2;exit 2; }
OUTPUT="$(cd "$OUTPUT" && pwd)"
[[ -n "$ARCHIVE" ]] || ARCHIVE="${OUTPUT}_FINAL_VERIFIED.zip"
ARCHIVE="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).expanduser().resolve())' "$ARCHIVE")"

./verify_final.sh --output "$OUTPUT" --allow-incomplete

python3 - "$OUTPUT" <<'PY'
from pathlib import Path
import csv,json,re,sys
from pypdf import PdfReader
root=Path(sys.argv[1])
patterns={
 'final PDF':'reports/*_report.pdf',
 'report JSON':'reports/*_report.json',
 'signature':'reports/*_report_signature.json',
 'public key':'reports/*_report_signing_public.pem',
 'completion manifest':'*_completion_manifest.json',
 'custody ledger':'*_custody.jsonl',
 'custody seal':'*_custody_seal.json',
 'accepted ledger':'validation/accepted_findings.jsonl',
 'candidate ledger':'validation/candidate_observations.jsonl',
 'rejected ledger':'validation/rejected_observations.jsonl',
 'duplicate ledger':'validation/duplicate_representation_ledger.jsonl',
 'derived ledger':'validation/derived_fact_ledger.jsonl',
 'module matrix':'validation/module_execution_matrix.csv',
 'restricted annex':'validation/restricted_examiner_annex.json',
 'examiner timeline':'module_output/*/timeline_builder/examiner_timeline.csv',
 'technical timeline':'module_output/*/timeline_builder/technical_event_ledger.csv',
 'validation summary':'validation/final_validation_summary.json',
 'provenance result':'validation/provenance_validation.json',
}
resolved={}
for label,pat in patterns.items():
    items=sorted(root.glob(pat))
    if label in {'final PDF','report JSON'}:
        items=[p for p in items if not re.search(r'_\d{8}T\d{6}Z_report\.(?:pdf|json)$',p.name)] or items
    if not items: raise SystemExit(f'ERROR: missing required {label}: {pat}')
    p=items[0]; resolved[label]=p
    if label not in {'candidate ledger','rejected ledger','duplicate ledger','derived ledger'} and p.stat().st_size == 0:
        raise SystemExit(f'ERROR: required {label} is empty: {p}')
# Parse every JSON/JSONL/CSV deliverable.
for p in root.rglob('*.json'):
    json.loads(p.read_text(encoding='utf-8'))
for p in root.rglob('*.jsonl'):
    for line_no,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if line.strip(): json.loads(line)
for p in root.rglob('*.csv'):
    with p.open(newline='',encoding='utf-8') as fh:
        list(csv.reader(fh))
reader=PdfReader(str(resolved['final PDF']))
if not reader.pages: raise SystemExit('ERROR: final PDF has no readable pages')
print(f"PACKAGE PRECHECK PASSED: {len(reader.pages)}-page report; {len(resolved)} mandatory deliverables")
PY

mkdir -p "$(dirname "$ARCHIVE")"
tmp="${ARCHIVE}.tmp.$$"; rm -f "$tmp" "$ARCHIVE" "${ARCHIVE}.sha256"
python3 - "$OUTPUT" "$tmp" <<'PY'
from __future__ import annotations
import hashlib,sys,tempfile,zipfile
from pathlib import Path
root=Path(sys.argv[1]); dest=Path(sys.argv[2])
files=sorted(p for p in root.rglob('*') if p.is_file())
if not files: raise SystemExit('ERROR: no files to archive')
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    for p in files: z.write(p,Path(root.name)/p.relative_to(root))
with zipfile.ZipFile(dest) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f'ERROR: ZIP CRC test failed: {bad}')
    members=[i for i in z.infolist() if not i.is_dir()]
    if len(members)!=len(files): raise SystemExit(f'ERROR: member count {len(members)} != {len(files)}')
    with tempfile.TemporaryDirectory(prefix='af_package_verify_') as td:
        z.extractall(td)
        extracted=Path(td)/root.name
        for p in files:
            rel=p.relative_to(root); q=extracted/rel
            if not q.is_file(): raise SystemExit(f'ERROR: extracted member missing: {rel}')
            a=hashlib.sha256(p.read_bytes()).hexdigest(); b=hashlib.sha256(q.read_bytes()).hexdigest()
            if a!=b: raise SystemExit(f'ERROR: extracted hash mismatch: {rel}')
print(f'ARCHIVE REOPEN/EXTRACT/HASH VERIFICATION PASSED: {len(files)} files')
PY
mv "$tmp" "$ARCHIVE"
sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
echo
echo "VERIFIED OUTPUT ZIP: $ARCHIVE"
echo "ZIP SHA-256 RECORD: ${ARCHIVE}.sha256"
