# Synthetic validation ClamAV signature

`synthetic_validation.ndb` contains only the public EICAR antivirus test-file
signature. AutoForensics may use it only when the case classification explicitly
contains `SYNTHETIC` and the official ClamAV database is unavailable.

It is not a replacement for the official ClamAV signature database and cannot
support a general malware-absence verdict.
