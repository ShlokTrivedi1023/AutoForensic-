rule TEST_EICAR_Antivirus_Test_File
{
  meta:
    description = "EICAR antivirus test signature; not live malware"
    severity = "INFO"
  strings:
    $eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
  condition:
    $eicar
}

rule SUSP_Text_Only_MZ_Decoy
{
  meta:
    description = "Printable text beginning with MZ; validate PE structure before treating as executable"
    severity = "MEDIUM"
  strings:
    $mz = "MZ"
  condition:
    $mz at 0 and filesize < 1048576
}
