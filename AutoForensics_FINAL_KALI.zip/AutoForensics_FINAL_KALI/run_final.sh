#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
usage(){ cat <<'EOF'
Usage: ./run_final.sh --evidence PATH --case-id ID --output DIR [options]
Options:
  --evidence-domain auto|disk|memory|network|mobile
  --profile PROFILE
  --investigator-id ID --investigator-name NAME --badge VALUE --institution VALUE
  --jurisdiction TEXT
  --authorising-officer NAME [--authorising-title TEXT --authorising-organisation TEXT]
  --supervising-examiner NAME [--supervising-title TEXT --supervising-organisation TEXT]
  --client-representative NAME [--client-title TEXT --client-organisation TEXT]
  --use-openai                 Optional narrative enhancement; requires OPENAI_API_KEY
  --authorisation-letter PATH --chain-of-custody PATH
  --evidence-bag-photo PATH    Repeatable
  --evidence-bag-photo-dir DIR Add all supported photographs in a directory; repeatable
  --examiner-signature PATH --supervisor-signature PATH
  --dummy-attachments          Visibly labels supplied attachments as unverified test material
EOF
}
EVIDENCE="";CASE_ID="";OUTPUT="";DOMAIN=auto;PROFILE=full;INV_ID=examiner;INV_NAME="Authorised Examiner";BADGE="";INSTITUTION="";USE_OPENAI=0;DUMMY=0
EXTRA=()
while (($#)); do
 case "$1" in
 --evidence) EVIDENCE="$2";shift 2;; --case-id) CASE_ID="$2";shift 2;; --output) OUTPUT="$2";shift 2;;
 --evidence-domain) DOMAIN="$2";shift 2;; --profile) PROFILE="$2";shift 2;; --investigator-id) INV_ID="$2";shift 2;;
 --investigator-name) INV_NAME="$2";shift 2;; --badge) BADGE="$2";shift 2;; --institution) INSTITUTION="$2";shift 2;;
 --use-openai) USE_OPENAI=1;shift;; --dummy-attachments) DUMMY=1;shift;;

 --authorisation-letter|--chain-of-custody|--evidence-bag-photo|--evidence-bag-photo-dir|--examiner-signature|--supervisor-signature|--jurisdiction|--authorising-officer|--authorised-by|--authorising-title|--authorising-organisation|--authorising-email|--supervising-examiner|--supervising-title|--supervising-organisation|--supervising-email|--client-representative|--client-title|--client-organisation|--client-email) EXTRA+=("$1" "$2");shift 2;;
 -h|--help) usage;exit 0;; *) echo "Unknown option: $1" >&2;usage;exit 2;; esac
done
[[ -n "$EVIDENCE" && -n "$CASE_ID" && -n "$OUTPUT" ]] || { usage >&2; exit 2; }
[[ -f "$EVIDENCE" ]] || { echo "ERROR: evidence not found: $EVIDENCE" >&2;exit 2; }
EVIDENCE="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).expanduser().resolve())' "$EVIDENCE")"
OUTPUT="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).expanduser().resolve())' "$OUTPUT")"
if [[ -e "$OUTPUT" && -n "$(find "$OUTPUT" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then echo "ERROR: output must be absent or empty: $OUTPUT" >&2;exit 2;fi
mkdir -p "$OUTPUT"; STATE="$OUTPUT/.autoforensics_state";mkdir -p "$STATE";CASE_FILE="$STATE/case.json";LOG="$OUTPUT/full_execution.log"
if [[ -z "${AUTOFORENSICS_INVESTIGATOR_PASSWORD:-}" ]]; then
 read -rsp "Create/replace AutoForensics investigator password (minimum 12 characters): " AUTOFORENSICS_INVESTIGATOR_PASSWORD;echo
 export AUTOFORENSICS_INVESTIGATOR_PASSWORD
fi
export AUTOFORENSICS_PASSWORD="$AUTOFORENSICS_INVESTIGATOR_PASSWORD"
CREATE=(python3 tools/create_final_case.py --evidence "$EVIDENCE" --case-id "$CASE_ID" --case-file "$CASE_FILE" --evidence-domain "$DOMAIN" --profile "$PROFILE" --investigator-id "$INV_ID" --investigator-name "$INV_NAME" --badge "$BADGE" --institution "$INSTITUTION" --force)
((USE_OPENAI)) && CREATE+=(--enable-openai)
((DUMMY)) && CREATE+=(--dummy-attachments)
CREATE+=("${EXTRA[@]}")
"${CREATE[@]}" | tee "$STATE/case_creation.json"
if ((USE_OPENAI)); then
 [[ -n "${OPENAI_API_KEY:-}" ]] || { echo "ERROR: --use-openai requires OPENAI_API_KEY in the environment." >&2;exit 2; }
 PROVIDER=openai
else PROVIDER=none; fi
set +e
python3 tools/run_ready_case.py --case-file "$CASE_FILE" --investigator-id "$INV_ID" --provider "$PROVIDER" --no-require-llm --output-dir "$OUTPUT" 2>&1 | tee "$LOG"
RC=${PIPESTATUS[0]};set -e
if ((RC!=0)); then echo "ERROR: investigation failed with exit code $RC. See $LOG" >&2;exit "$RC";fi
python3 tools/build_restricted_annex.py --output "$OUTPUT"
# Validate all technical outputs even when an honestly incomplete specialist
# module prevents strict release acceptance. The strict gate result remains
# recorded in validation/strict_scope_gate.json and is never weakened.
./verify_final.sh --output "$OUTPUT" --allow-incomplete

echo
echo "FINAL OUTPUT LOCATIONS"
python3 - "$OUTPUT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
def first(*patterns):
    for pattern in patterns:
        found=sorted(root.glob(pattern))
        if found:
            stable=[p for p in found if not any(part.startswith('.') for part in p.parts)]
            return stable[0] if stable else found[0]
    return None
items=[
 ("Final PDF", first("reports/*_report.pdf")),
 ("Restricted annex JSON", first("validation/restricted_examiner_annex.json")),
 ("Restricted annex PDF", first("validation/restricted_examiner_annex.pdf")),
 ("Accepted ledger", first("validation/accepted_findings.jsonl")),
 ("Candidate ledger", first("validation/candidate_observations.jsonl")),
 ("Rejected ledger", first("validation/rejected_observations.jsonl")),
 ("Duplicate ledger", first("validation/duplicate_representation_ledger.jsonl")),
 ("Derived-fact ledger", first("validation/derived_fact_ledger.jsonl")),
 ("Module matrix", first("validation/module_execution_matrix.csv")),
 ("Examiner timeline", first("module_output/*/timeline_builder/examiner_timeline.csv")),
 ("Technical timeline", first("module_output/*/timeline_builder/technical_event_ledger.csv")),
 ("Custody ledger", first("*_custody.jsonl")),
 ("Validation summary", first("validation/final_validation_summary.json")),
 ("Execution log", first("full_execution.log")),
 ("Completion manifest", first("*_completion_manifest.json")),
]
for label,path in items:
    print(f"{label}: {path if path else 'NOT GENERATED'}")
print(f"Verified output ZIP: run ./package_outputs.sh --output {root}")
PY
