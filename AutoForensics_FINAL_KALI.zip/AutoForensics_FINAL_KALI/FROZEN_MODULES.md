# Frozen and repaired module policy — v2.8.6

AutoForensics contains exactly **45 active modules** in this final source freeze.

- **37 FROZEN_VERIFIED modules** are protected by `config/frozen_module_lock.json`.
- **8 TARGETED_REPAIR modules** are protected by module-specific positive, negative, malformed-input, unsupported-input, dependency-failure and provenance tests.
- The removed Autopsy integration is not registered, invoked, reported or counted.

The eight targeted modules are:

1. `image_mounter`
2. `memory_process_list`
3. `memory_network_connections`
4. `memory_artifact_extractor`
5. `memory_malware_scanner`
6. `memory_string_analyzer`
7. `rootkit_detector`
8. `mobile_analyzer`

## v2.8.6 lock rebaseline

The v2.8.6 exhaustive-coverage repair intentionally modified a subset of modules that were hash-locked in v2.8.0. Their hashes are therefore **rebaselined to the reviewed v2.8.6 source**, rather than being described as unchanged. The lock protects the final v2.8.6 release from accidental source drift after this rebaseline.

A source hash demonstrates source stability only. It does not establish correctness on an arbitrary evidence corpus. Runtime evidence validation, dependency checks, corpus coverage reconciliation and examiner review remain separate requirements.
