from __future__ import annotations

import hashlib
import json
from pathlib import Path

from modules._base import Finding, ModuleResult, ModuleStatus, Severity
from core.deterministic_reconciler import reconcile_module_result
from core.module_completion import certify_module_result
from tools.h2_semantic_audit import _carver_invariants


def _finding(source: Path, *, candidate: bool = False) -> Finding:
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    metadata = {
        "file_sha256": digest,
        "deterministic_validation": True,
        "counts_toward_unique_evidence": not candidate,
    }
    if candidate:
        # This recreates the exact failure mode seen in the controlled run:
        # a candidate state was deterministic, but the evidentiary claim itself
        # was not payload-validated and must not be promoted.
        metadata.update({
            "validation_state": "CANDIDATE",
            "candidate_only": True,
            "fact_class": "CANDIDATE_ONLY",
            "payload_integrity_validated": False,
        })
    return Finding(
        finding_id="f-1",
        finding_type="CARVED_FILE_VALIDATED",
        severity=Severity.INFO,
        description="test carved object",
        evidence_path=str(source),
        artifact_path=str(source),
        metadata=metadata,
        timestamp="2026-08-08T00:00:00+00:00",
    )


def test_explicit_candidate_state_cannot_be_promoted_by_deterministic_flag(tmp_path: Path):
    source = tmp_path / "evidence.bin"
    source.write_bytes(b"candidate-container")
    out = tmp_path / "module"
    out.mkdir()
    result = ModuleResult(
        module_name="native_signature_carver",
        case_id="CASE-1",
        status=ModuleStatus.COMPLETED,
        findings=[_finding(source, candidate=True)],
    )
    reconciled = reconcile_module_result(
        result,
        module_name="native_signature_carver",
        evidence_path=source,
        config={"_working_set": {}},
        output_dir=out,
    )
    assert reconciled.findings == []
    recon = reconciled.statistics["deterministic_reconciliation"]
    assert recon["candidate_observations"] == 1
    ledger = json.loads(Path(recon["candidate_file"]).read_text())
    assert ledger["ledger_counts"]["CANDIDATE"] == 1
    record = ledger["candidates"][0]
    assert record["metadata"]["candidate_only"] is True
    assert record["metadata"]["deterministic_validation"] is False
    assert record["metadata"]["counts_toward_unique_evidence"] is False


def test_native_carver_can_complete_with_fully_accounted_candidate_ledger(tmp_path: Path):
    source = tmp_path / "source.bin"
    source.write_bytes(b"accepted-evidence")
    accepted = _finding(source, candidate=False)

    candidate_records = []
    for i in range(4):
        candidate_records.append({
            "finding_id": f"candidate-{i}",
            "finding_type": "CARVED_FILE_VALIDATED",
            "description": "encrypted payload not validated at carving stage",
            "metadata": {
                "ledger_state": "CANDIDATE",
                "candidate_only": True,
                "fact_class": "CANDIDATE_ONLY",
                "counts_toward_unique_evidence": False,
                "validation_reason": "encrypted payload requires credentials",
            },
        })
    ledger = tmp_path / "candidate_observations.json"
    ledger.write_text(json.dumps({"candidates": candidate_records}), encoding="utf-8")

    result = ModuleResult(
        module_name="native_signature_carver",
        case_id="CASE-1",
        status=ModuleStatus.COMPLETED,
        findings=[accepted],
        statistics={
            "objects_discovered": 26,
            "objects_processed": 26,
            "invalid_accepted_carvings": 0,
            "unresolved_supported_objects": 0,
            "deterministic_reconciliation": {
                "candidate_observations": 4,
                "rejected_observations": 0,
                "unresolved_observations": 0,
                "ledger_counts": {
                    "ACCEPTED": 0,
                    "CANDIDATE": 4,
                    "REJECTED": 0,
                    "UNRESOLVED": 0,
                },
                "candidate_file": str(ledger),
            },
        },
    )
    certified = certify_module_result(
        result,
        module_name="native_signature_carver",
        config={"analysis_path": str(source), "_working_set": {}},
    )
    assert certified.status == ModuleStatus.PASS_COMPLETE
    certificate = certified.statistics["completion_certificate"]
    assert certificate["candidate_observations"] == 4
    assert certificate["unresolved_observations"] == 0
    assert certificate["unsupported_accepted_findings"] == 0
    assert certificate["evidence_assurance"] == "MIXED"
    assert certificate["reasons"] == []


def test_h2_accepts_verification_subset_carver_with_external_crypto_anchor(tmp_path: Path):
    output = tmp_path / "case"
    module_dir = output / "module_output" / "ev00" / "foremost_carver"
    module_dir.mkdir(parents=True)
    carved = module_dir / "carved.bin"
    carved.write_bytes(b"retained-byte-interval")
    digest = hashlib.sha256(carved.read_bytes()).hexdigest()
    missing_logical_stream = output / "ewf_mount" / "case" / "ewf1"

    manifest = {
        "schema": "autoforensics-carver-reconciliation-v2",
        "analysis_source": str(missing_logical_stream),
        "analysis_source_sha256": "a" * 64,
        "logical_media_sha256": "a" * 64,
        "source_container_path": "/external/evidence.E01",
        "source_container_sha256": "b" * 64,
        "source_image_bytes": 67108864,
        "source_retention_policy": "EXTERNAL_EVIDENCE_REQUIRED_FOR_INTERVAL_REPLAY",
        "files": [{
            "output_name": carved.name,
            "output_path": str(carved),
            "output_sha256": digest,
            "final_state": "ACCEPTED",
            "source_start": 1024,
            "source_length": len(carved.read_bytes()),
            "source_end": 1024 + len(carved.read_bytes()),
            "source_interval_sha256": digest,
            "candidate_size_bytes": len(carved.read_bytes()),
            "structured_length": len(carved.read_bytes()),
            "structural_validation": {"valid": True},
        }],
        "reconciliation": {
            "state_counts": {"ACCEPTED": 1, "REJECTED": 0, "UNRESOLVED": 0},
            "all_candidates_resolved": True,
            "total_candidate_output_bytes": len(carved.read_bytes()),
        },
    }
    (module_dir / "foremost_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    failures: list[str] = []
    _carver_invariants("foremost_carver", module_dir, output, [], failures)
    assert failures == []


def test_interactive_wizard_supports_multiple_evidence_and_e01_entrypoint(monkeypatch, capsys):
    from core.case_config import run_wizard

    answers = iter([
        # case identifiers
        "CASE-FINAL-1", "", "", "",
        # examiner (name/badge take authenticated defaults)
        "", "", "Coventry University", "", "",
        # case details
        "", "", "", "",
        # background + optional context + objectives
        "", "", "Europe/London", "", "",
        # evidence count
        "2",
        # Evidence 1: deliberately enter E02 first, then the valid E01 entry point
        "/evidence/case.E02", "/evidence/case.E01", "Disk image", "", "", "auto", "", "", "",
        # Evidence 2
        "/evidence/network.pcap", "Network capture", "", "", "network", "", "", "",
        # people / organisation
        "", "", "", "", "", "", "", "", "",
        # supporting material: four scalar paths, then photo list blank, extra list one+blank
        "", "", "", "", "", "/case/supporting-note.pdf", "",
        # profile and OpenAI
        "1", "n",
    ])
    monkeypatch.setattr("builtins.input", lambda _prompt="": next(answers))
    cfg = run_wizard(examiner_defaults={"name": "Examiner One", "badge": "E-001"})
    assert len(cfg.evidence_items) == 2
    assert cfg.evidence_items[0].path.endswith("case.E01")
    assert cfg.evidence_items[1].path.endswith("network.pcap")
    assert cfg.evidence_items[1].evidence_type == "network"
    assert cfg.supplementary.additional_files == ["/case/supporting-note.pdf"]
    assert cfg.investigation_profile == "full"
    assert cfg.ai_policy.mode == "local_only"
    output = capsys.readouterr().out
    assert "select only the .E01" in output
    assert "version" not in output.casefold()


def test_primary_banner_has_no_visible_platform_version(capsys):
    from core.main import _print_banner
    _print_banner()
    output = capsys.readouterr().out
    assert "AUTOFORENSICS" in output
    assert "Version" not in output
    assert "v2." not in output
