#!/usr/bin/env python3
"""Case-neutral integration checks for a completed AutoForensics output.

The checks validate internal consistency and the repaired assurance semantics.
They intentionally contain no fixture filename, case ID, password, hash, cluster,
packet value, MASTER answer, or expected artefact count.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.ocr_assurance import all_accepted_ocr_findings_are_corroborated


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def one(root: Path, pattern: str) -> Path:
    matches = sorted(root.glob(pattern))
    if len(matches) != 1:
        raise AssertionError(f"expected exactly one {pattern!r}; found {len(matches)}")
    return matches[0]


def check(condition: bool, label: str, failures: list[str]) -> None:
    print(f"[{'PASS' if condition else 'FAIL'}] {label}")
    if not condition:
        failures.append(label)


def module_dir(output: Path, name: str) -> Path:
    dirs = sorted(output.glob(f"module_output/*/{name}"))
    if len(dirs) != 1:
        raise AssertionError(f"module output for {name} not unique: {dirs}")
    return dirs[0]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-completion", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    failures: list[str] = []

    manifest = load_json(one(output, "pipeline_manifest_*.json"))
    if isinstance(manifest, list):
        entries = manifest
    else:
        entries = manifest.get("modules") or manifest.get("module_results") or manifest.get("entries") or []
        if isinstance(entries, dict):
            entries = list(entries.values())
    check(len(entries) == 45, "pipeline manifest totalises 45 configured modules", failures)

    all_module_results = list(output.glob("module_output/*/*/module_result.json"))
    check(len(all_module_results) == 45, "all 45 modules wrote independent result files", failures)
    shared_error = "dictionary update sequence element"
    check(
        not any(shared_error in p.read_text(encoding="utf-8", errors="ignore") for p in all_module_results),
        "legacy evidence-reference conversion error is absent",
        failures,
    )

    dns = load_json(module_dir(output, "dns_analyzer") / "dns_analysis.json")
    records = dns.get("dns_records_sample") or []
    q = [r for r in records if r.get("record_type") == "DNS_QUERY"]
    r = [x for x in records if x.get("record_type") == "DNS_RESPONSE"]
    check(dns.get("total_dns_queries") == len(q), "DNS query count matches query records", failures)
    check(dns.get("total_dns_responses") == len(r), "DNS response count matches response records", failures)
    check(not any(x.get("record_type") == "DNS_QUERY" and x.get("dns.flags.response") == "1" for x in records),
          "DNS responses are never labelled as queries", failures)

    timeline_path = module_dir(output, "timeline_builder") / "examiner_timeline.csv"
    with timeline_path.open(newline="", encoding="utf-8") as fh:
        timeline = list(csv.DictReader(fh))
    keys = [(x.get("timestamp"), x.get("event_type"), x.get("source_artifact"), x.get("source_locator")) for x in timeline]
    check(len(keys) == len(set(keys)), "examiner timeline contains no duplicate semantic event rows", failures)
    check(all(x.get("event_type") and not re.match(r"(?i)^(date|timestamp|frame\.time)\s*:", x.get("event", "")) for x in timeline),
          "examiner timeline uses semantic event names", failures)
    event_types = Counter(x.get("event_type") for x in timeline)
    check(event_types["DNS_QUERY"] == len(q) and event_types["DNS_RESPONSE"] == len(r),
          "examiner timeline preserves DNS request/response semantics", failures)
    for event_type in ("DOWNLOAD_STARTED", "DOWNLOAD_COMPLETED", "DOWNLOAD_LAST_ACCESSED"):
        check(event_types[event_type] >= 0, f"timeline schema supports {event_type}", failures)
    if any(event_types[t] for t in ("DOWNLOAD_STARTED", "DOWNLOAD_COMPLETED", "DOWNLOAD_LAST_ACCESSED")):
        check(all(event_types[t] > 0 for t in ("DOWNLOAD_STARTED", "DOWNLOAD_COMPLETED", "DOWNLOAD_LAST_ACCESSED")),
              "browser download start/completion/last-access are separately represented", failures)

    ocr_result = load_json(module_dir(output, "ocr_text_extractor") / "module_result.json")
    ocr_candidates_data = load_json(module_dir(output, "ocr_text_extractor") / "candidate_observations.json")
    ocr_candidates = (ocr_candidates_data.get("candidates") or []) if isinstance(ocr_candidates_data, dict) else ocr_candidates_data
    ocr_accepted = ocr_result.get("findings") or []
    check(all_accepted_ocr_findings_are_corroborated(ocr_accepted),
          "every accepted OCR finding has deterministic independent corroboration", failures)
    check(bool(ocr_candidates), "OCR machine transcriptions are retained as candidates", failures)
    check(all((x.get("metadata") or {}).get("candidate_only") is True for x in ocr_candidates if isinstance(x, dict)),
          "every retained OCR observation is marked candidate-only", failures)

    recovery = load_json(module_dir(output, "deleted_file_recovery") / "recovery_manifest.json")
    recovered = recovery.get("recovered_evidence_files") or []
    controls = recovery.get("recovery_control_files") or []
    recovered_paths = [str(x.get("path") if isinstance(x, dict) else x) for x in recovered]
    check(len(recovered_paths) == len(set(recovered_paths)), "deleted evidence collection is unique", failures)
    check(not any(p.lower().endswith((".json", ".csv", ".jsonl")) for p in recovered_paths),
          "control records are excluded from recovered evidence files", failures)
    check(not set(recovered_paths) & {str(x.get("path") if isinstance(x, dict) else x) for x in controls},
          "recovered evidence and control-file collections are disjoint", failures)

    document_dir = module_dir(output, "document_analyzer")
    document = load_json(document_dir / "document_analysis.json")
    document_result = load_json(document_dir / "module_result.json")
    doc_text = json.dumps(document, sort_keys=True)
    doc_result_text = json.dumps(document_result, sort_keys=True)
    check("metadata_namespace" in doc_result_text or '"namespace"' in doc_result_text,
          "document metadata findings retain an explicit namespace", failures)
    check("archive" in doc_text.lower() and "archive" in doc_result_text.lower(),
          "document analysis includes canonical archive scope", failures)

    registry = load_json(module_dir(output, "windows_registry_analyzer") / "registry_manifest.json")
    registry_text = json.dumps(registry, sort_keys=True)
    if "TEXT_REGISTRY_EXPORT" in registry_text:
        check("REGISTRY_VALUE_RECORD" in registry_text or "value_name" in registry_text,
              "text registry exports produce deterministic semantic values", failures)

    reports = output / "reports"
    # Prefer the stable final report when timestamped drafts also exist.
    stable = sorted(p for p in reports.glob("*_report.json") if not re.search(r"_\d{8}T\d{6}Z_report\.json$", p.name))
    report_json = stable[0] if len(stable) == 1 else one(reports, "*_report.json")
    report = load_json(report_json)
    report_text = json.dumps(report, ensure_ascii=False)
    check(not re.search(r"(?i)\b0\s+(?:artefacts?|artifacts?|objects?|files?)\s+examined;\s*[1-9]\d*\s+relevant", report_text),
          "report contains no zero-examined/nonzero-findings contradiction", failures)
    check("EVIDENCE-GROUNDED SUMMARY" in report_text.upper(), "report uses evidence-grounded summary heading", failures)
    check("AI-generated summary" not in report_text and "AI-assisted summary" not in report_text,
          "report contains no prohibited AI-facing heading", failures)

    validation = output / "validation"
    if validation.is_dir():
        summary = validation / "final_validation_summary.json"
        if summary.is_file():
            data = load_json(summary)
            check(bool(data.get("provenance_complete", data.get("provenance_passed", True))),
                  "validation records provenance completeness", failures)
            check(bool(data.get("statistics_consistent", True)),
                  "structured statistics are internally consistent", failures)

    if args.require_completion:
        completion = one(output, "*_completion_manifest.json")
        data = load_json(completion)
        check(data.get("machine_complete") is True, "completion manifest records machine completion", failures)
        check((data.get("report") or {}).get("signature_verified") is True,
              "completion manifest records report-signature verification", failures)
        check((data.get("custody") or {}).get("chain_integrity_verified") is True,
              "completion manifest records custody-chain verification", failures)

    print(f"REPAIRED-RUN INTEGRATION CHECK: {len(failures)} failure(s)")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
