from __future__ import annotations

import hashlib
import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from core.administrative_attachments import ingest_administrative_attachments
from core.carving_reconciliation import reconcile_candidates
from core.count_schema import (
    CANONICAL_COUNT_FIELDS,
    CountSchemaError,
    build_canonical_counts,
    counts_from_certificate,
    validate_canonical_counts,
)
from modules.foremost_carver import _parse_audit

ROOT = Path(__file__).resolve().parents[1]


def _zip_bytes() -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("inside.txt", "generic deterministic test")
    return buffer.getvalue()


def test_canonical_count_schema_has_all_required_units_and_fails_closed():
    accepted = [{
        "finding_id": "F-1",
        "evidence_path": "/evidence/a.bin",
        "metadata": {"file_sha256": "a" * 64, "semantic_object_id": "object-1"},
    }]
    candidate = [
        {"ledger_state": "CANDIDATE", "evidence_path": "/evidence/b.bin"},
        {"ledger_state": "REJECTED", "evidence_path": "/evidence/c.bin"},
        {"ledger_state": "UNRESOLVED", "evidence_path": "/evidence/d.bin"},
    ]
    counts = build_canonical_counts(accepted_findings=accepted, candidate_records=candidate)
    assert tuple(counts) == CANONICAL_COUNT_FIELDS
    assert counts["accepted_findings"] == 1
    assert counts["candidate_observations"] == 1
    assert counts["rejected_observations"] == 1
    assert counts["unresolved_observations"] == 1
    assert counts["source_paths"] == 4
    assert validate_canonical_counts(counts).valid
    with pytest.raises(CountSchemaError):
        counts_from_certificate({"canonical_counts": {"accepted_findings": 1}})


def test_h2_audit_always_writes_structured_failure(tmp_path: Path):
    module_dir = tmp_path / "module_output" / "ev00" / "broken"
    module_dir.mkdir(parents=True)
    (module_dir / "module_result.json").write_text("{broken", encoding="utf-8")
    out = tmp_path / "h2.json"
    proc = subprocess.run(
        [sys.executable, str(ROOT / "tools/h2_semantic_audit.py"), "--output", str(tmp_path), "--write", str(out)],
        text=True, capture_output=True, check=False,
    )
    assert proc.returncode == 1
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert payload["schema"] == "autoforensics-h2-semantic-audit-v2"
    assert payload["audit_completed"] is True
    assert payload["passed"] is False
    assert any("unreadable module result" in item for item in payload["failures"])


def test_foremost_rounded_audit_size_is_not_treated_as_exact(tmp_path: Path):
    audit = tmp_path / "audit.txt"
    audit.write_text("0: 00000001.jpg 19 KB 12345 comment\n", encoding="utf-8")
    rows = _parse_audit(audit)
    assert rows == [{
        "file_name": "00000001.jpg",
        "offset": 12345,
        "size_bytes": 19 * 1024,
        "audit_reported_size_bytes": 19 * 1024,
        "audit_size_is_exact": False,
    }]


def test_carver_reconciliation_accepts_exact_object_and_rejects_overcarve(tmp_path: Path):
    payload = _zip_bytes()
    prefix = b"P" * 37
    suffix = b"TRAILING"
    source = tmp_path / "source.bin"
    source.write_bytes(prefix + payload + suffix)
    exact = tmp_path / "exact.zip"
    exact.write_bytes(payload)
    over = tmp_path / "over.zip"
    over.write_bytes(payload + suffix)
    rows, summary = reconcile_candidates(
        tool_name="scalpel",
        source_path=source,
        candidates=[
            {"file_name": exact.name, "file_type": "zip", "source_start": len(prefix), "output_path": str(exact)},
            {"file_name": over.name, "file_type": "zip", "source_start": len(prefix), "output_path": str(over)},
        ],
        peer_hashes={hashlib.sha256(payload).hexdigest()},
    )
    by_name = {row["output_name"]: row for row in rows}
    assert by_name["exact.zip"]["final_state"] == "ACCEPTED"
    assert by_name["over.zip"]["final_state"] == "REJECTED"
    assert "validated object boundary" in by_name["over.zip"]["resolution_reason"]
    assert isinstance(by_name["exact.zip"]["unique_to_scalpel"], bool)
    assert isinstance(by_name["exact.zip"]["matched_foremost_hashes"], list)
    assert summary["state_counts"] == {"ACCEPTED": 1, "REJECTED": 1, "UNRESOLVED": 0}


def test_administrative_attachments_are_hashed_copied_and_repointed(tmp_path: Path):
    sources = tmp_path / "sources"
    sources.mkdir()
    values = {}
    for name in ("authorisation.pdf", "custody.pdf", "examiner.png", "supervisor.png", "bag.jpg"):
        path = sources / name
        path.write_bytes((name + "\n").encode())
        values[name] = path
    supplementary = SimpleNamespace(
        authorisation_letter=str(values["authorisation.pdf"]),
        coc_form_image=str(values["custody.pdf"]),
        examiner_signature=str(values["examiner.png"]),
        supervisor_signature=str(values["supervisor.png"]),
        evidence_bag_photos=[str(values["bag.jpg"])],
    )
    case = SimpleNamespace(supplementary=supplementary)
    result = ingest_administrative_attachments(case, tmp_path / "case")
    assert result["administratively_complete"] is True
    assert not result["missing"] and not result["errors"]
    assert len(result["attachments"]) == 5
    for record in result["attachments"]:
        retained = Path(record["retained_path"])
        assert retained.is_file()
        assert hashlib.sha256(retained.read_bytes()).hexdigest() == record["sha256"]
        assert retained.parent.name == "administrative_attachments"
    assert Path(supplementary.authorisation_letter).parent.name == "administrative_attachments"
    assert Path(supplementary.evidence_bag_photos[0]).parent.name == "administrative_attachments"


def test_release_lock_and_scope_groups_match_controlling_handoff():
    lock = json.loads((ROOT / "config/frozen_module_lock.json").read_text(encoding="utf-8"))
    assert lock["schema"] == "autoforensics-frozen-module-lock-v4"
    assert len(lock["modules"]) == 37
    import yaml
    contracts = yaml.safe_load((ROOT / "config/module_scope_contracts.yaml").read_text(encoding="utf-8"))["modules"]
    groups = [row["baseline_group"] for row in contracts.values()]
    assert groups.count("FROZEN_VERIFIED") == 37
    assert groups.count("TARGETED_REPAIR") == 8
    assert groups.count("SPECIALIST_INCOMPLETE") == 0


def test_clean_package_audit_entrypoints_compile_and_import():
    for rel in (
        "tools/h2_semantic_audit.py", "tools/report_output_audit.py",
        "tools/compare_reference_corpus.py", "tools/evaluate_master_reference.py",
    ):
        proc = subprocess.run([sys.executable, "-m", "py_compile", str(ROOT / rel)], check=False)
        assert proc.returncode == 0
