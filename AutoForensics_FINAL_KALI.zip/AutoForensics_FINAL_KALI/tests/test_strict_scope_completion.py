from __future__ import annotations

from pathlib import Path
import json

from core.memory_marker_modules import run_marker_scope
from core.module_completion import certify_module_result, load_scope_contracts
from modules._base import ModuleResult, ModuleStatus
from modules.exiftool_metadata import _check_timestamp_anomaly, _is_host_extraction_field


def _config(tmp_path: Path) -> dict:
    evidence = tmp_path / "evidence.dd"
    evidence.write_bytes(b"runtime evidence")
    return {
        "analysis_path": str(evidence),
        "_working_set": {
            "evidence_inventory": {"schema": "test", "objects": []},
            "primary_evidence_roots": [],
            "canonical_findings_by_module": {},
        },
    }


def test_all_45_modules_have_case_neutral_scope_contracts():
    contracts = load_scope_contracts()
    assert len(contracts) == 45
    assert {v["baseline_group"] for v in contracts.values()} == {
        "FROZEN_VERIFIED", "TARGETED_REPAIR"
    }
    text = Path("config/module_scope_contracts.yaml").read_text(encoding="utf-8").casefold()
    assert "testcase-" not in text
    assert "/home/kali/" not in text


def test_complete_empty_scope_can_receive_pass_complete(tmp_path):
    result = ModuleResult(
        module_name="evidence_validator", case_id="RUNTIME",
        status=ModuleStatus.COMPLETED,
        statistics={"sources_discovered": 1, "sources_processed": 1},
    )
    certified = certify_module_result(result, module_name="evidence_validator", config=_config(tmp_path))
    assert certified.status == ModuleStatus.PASS_COMPLETE
    assert certified.statistics["completion_certificate"]["case_specific_reference_used"] is False


def test_memory_marker_scope_reports_literal_records_not_kernel_objects(tmp_path):
    marker = tmp_path / "memory.bin"
    marker.write_bytes(
        b"padding\x00PROCESS pid=451 ppid=4 name=runtime.exe state=running\x00"
        b"NETCONN pid=451 TCP 192.0.2.1:4444 198.51.100.2:443 ESTABLISHED\x00"
    )
    process = run_marker_scope(
        module_name="memory_process_list", case_id="RUNTIME", marker_paths=[marker]
    )
    assert process.status == ModuleStatus.COMPLETED
    assert [f.finding_type for f in process.findings] == ["MEMORY_PROCESS_MARKER"]
    assert process.statistics["structural_memory_applicable"] is False
    assert process.class_results[1].skip_reason.value == "NOT_APPLICABLE"


def test_exiftool_host_copy_fields_never_become_source_metadata():
    assert _is_host_extraction_field({"group": "File", "field": "FileModifyDate"})
    assert _is_host_extraction_field({"group": "System", "field": "FilePermissions"})
    assert not _is_host_extraction_field({"group": "EXIF", "field": "DateTimeOriginal"})
    # A host-copy FileModifyDate cannot create an embedded timestamp anomaly.
    record = {"CreateDate": "2025:01:02 00:00:00", "FileModifyDate": "2020:01:01 00:00:00"}
    assert _check_timestamp_anomaly(record) is None


def test_timeline_consumes_tcp_mobile_and_document_semantic_times(tmp_path):
    from modules.timeline_builder import _ingest_canonical_finding_timestamps

    pcap = tmp_path / "traffic.pcap"
    pcap.write_bytes(b"pcap")
    ios_db = tmp_path / "ios_messages.db"
    ios_db.write_bytes(b"db")
    pdf = tmp_path / "report.pdf"
    pdf.write_bytes(b"%PDF")
    config = {
        "_working_set": {
            "canonical_findings_by_module": {
                "network_protocol_decoder": [{
                    "finding_id": "net-1", "finding_type": "NETWORK_PROTOCOL_RECORD",
                    "description": "decoded frames", "severity": "INFO",
                    "metadata": {"pcap_file": str(pcap), "records": [{
                        "timestamp": "2026-01-01T10:00:00+00:00", "semantic_event": "TCP SYN",
                        "frame_number": 1, "capture_offset": 24,
                        "ip_src": "192.0.2.1", "src_port": 50000,
                        "ip_dst": "198.51.100.2", "dst_port": 443,
                    }]},
                }],
                "mobile_analyzer": [{
                    "finding_id": "mob-1", "finding_type": "MOBILE_CHAT",
                    "description": "chat", "severity": "INFO",
                    "metadata": {"device_type": "ios", "source_records": [{
                        "_source_database": str(ios_db), "_source_table": "message",
                        "ROWID": 7, "ZDATE": 800000000, "text": "runtime message",
                    }]},
                }],
                "document_analyzer": [{
                    "finding_id": "doc-1", "finding_type": "METADATA_FIELD",
                    "description": "PDF creation", "severity": "INFO",
                    "metadata": {"file_path": str(pdf), "metadata_field": "CreationDate",
                                 "metadata_value": "D:20260101120000+00'00'"},
                }],
            }
        }
    }
    events = _ingest_canonical_finding_timestamps(config)
    types = [event["event_type"] for event in events]
    assert "TCP_SYN" in types
    assert "IOS_MESSAGE" in types
    assert "FILE_CREATED" in types


def test_mobile_leapp_proof_is_required_only_when_specialist_scope_applies(tmp_path):
    mobile = tmp_path / "mobile_source"
    mobile.mkdir()
    config = _config(tmp_path)
    config["mobile_sources"] = [str(mobile)]
    base_stats = {
        "sources_discovered": 1,
        "sources_processed": 1,
        "supported_objects_discovered": 1,
        "supported_objects_processed": 1,
        "unresolved_supported_objects": 0,
        "specialist_applicable": True,
    }
    missing = ModuleResult(
        module_name="mobile_analyzer",
        case_id="RUNTIME",
        status=ModuleStatus.COMPLETED,
        statistics={**base_stats, "leapp_completed": False},
    )
    certified_missing = certify_module_result(
        missing, module_name="mobile_analyzer", config=config
    )
    assert certified_missing.status == ModuleStatus.INCOMPLETE

    complete = ModuleResult(
        module_name="mobile_analyzer",
        case_id="RUNTIME",
        status=ModuleStatus.COMPLETED,
        statistics={**base_stats, "leapp_completed": True},
    )
    certified_complete = certify_module_result(
        complete, module_name="mobile_analyzer", config=config
    )
    assert certified_complete.status == ModuleStatus.PASS_COMPLETE


def test_report_loader_recognises_strict_pass_complete(tmp_path):
    import json
    import logging
    from core.report_loader import _load_generic_module_result

    result_path = tmp_path / "module_result.json"
    result_path.write_text(json.dumps({
        "module_name": "evidence_validator",
        "status": "PASS_COMPLETE",
        "statistics": {},
        "findings": [],
        "class_results": [],
    }), encoding="utf-8")
    loaded = _load_generic_module_result(result_path, logging.getLogger("test"))
    assert loaded is not None
    assert loaded.status == "success"


def test_candidate_only_observations_do_not_block_module_completion_when_quarantined(tmp_path):
    from core.deterministic_validation import candidate_metadata
    from modules._base import Severity, make_finding

    root = tmp_path / "corpus"
    root.mkdir()
    image = root / "image.png"
    image.write_bytes(b"candidate source")
    config = _config(tmp_path)
    config["_working_set"]["primary_evidence_roots"] = [str(root)]
    finding = make_finding(
        "OCR_ENGINE_TRANSCRIPTION", Severity.INFO,
        "Machine transcription requiring confirmation.",
        str(image),
        candidate_metadata(
            "OCR transcription",
            reason="Probabilistic transcription requires independent confirmation.",
        ),
        artifact_path=str(image),
    )
    result = ModuleResult(
        module_name="ocr_text_extractor", case_id="RUNTIME",
        status=ModuleStatus.COMPLETED,
        findings=[finding],
        statistics={
            "sources_discovered": 1, "sources_processed": 1,
            "supported_objects_discovered": 1, "supported_objects_processed": 1,
            "records_discovered": 1, "records_processed": 1,
            "unresolved_supported_objects": 0, "parser_errors": 0,
        },
    )
    certified = certify_module_result(result, module_name="ocr_text_extractor", config=config)
    assert certified.status == ModuleStatus.PASS_COMPLETE
    assert certified.statistics["completion_certificate"]["unsupported_accepted_findings"] == 0


def test_candidate_cannot_inflate_unique_evidence_even_when_candidates_are_allowed(tmp_path):
    from modules._base import Severity, make_finding

    root = tmp_path / "corpus"
    root.mkdir()
    image = root / "image.png"
    image.write_bytes(b"candidate source")
    config = _config(tmp_path)
    config["_working_set"]["primary_evidence_roots"] = [str(root)]
    finding = make_finding(
        "OCR_ENGINE_TRANSCRIPTION", Severity.INFO, "candidate", str(image),
        {
            "candidate_only": True,
            "fact_class": "CANDIDATE_ONLY",
            "deterministic_validation": False,
            "counts_toward_unique_evidence": True,
        },
        artifact_path=str(image),
    )
    result = ModuleResult(
        module_name="ocr_text_extractor", case_id="RUNTIME",
        status=ModuleStatus.COMPLETED,
        findings=[finding],
        statistics={
            "sources_discovered": 1, "sources_processed": 1,
            "supported_objects_discovered": 1, "supported_objects_processed": 1,
            "records_discovered": 1, "records_processed": 1,
            "unresolved_supported_objects": 0, "parser_errors": 0,
        },
    )
    certified = certify_module_result(result, module_name="ocr_text_extractor", config=config)
    assert certified.status == ModuleStatus.INCOMPLETE


def test_strict_scope_gate_script_imports_core_when_executed_directly(tmp_path):
    import subprocess
    import sys

    script = Path(__file__).resolve().parents[1] / "tools" / "strict_scope_gate.py"
    proc = subprocess.run(
        [sys.executable, str(script), str(tmp_path)],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )
    # The empty output is expected to fail the completeness gate, but the
    # executable must run and emit JSON rather than crashing on ``import core``.
    assert proc.returncode == 2
    assert "ModuleNotFoundError" not in proc.stderr
    payload = json.loads(proc.stdout)
    assert payload["schema"] == "autoforensics-strict-scope-gate-v1"
    assert payload["passed"] is False
