from __future__ import annotations

from types import SimpleNamespace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.canonical_result import finalise_canonical_result
from core.fact_classification import (
    FactClass,
    annotate_finding,
    evidence_object_id,
)


def _finding(*, finding_type="METADATA_FIELD", metadata=None, evidence_path="/evidence/image.dd"):
    return SimpleNamespace(
        finding_type=finding_type,
        metadata=dict(metadata or {}),
        evidence_reference={},
        evidence_path=evidence_path,
    )


def test_metadata_fields_from_same_file_remain_distinct_evidence_objects():
    first = _finding(metadata={
        "file_sha256": "a" * 64,
        "logical_path": "/Documents/report.pdf",
        "field_name": "Author",
        "value": "Analyst One",
        "finding_basis": "deterministic",
        "deterministic_validation": True,
    })
    second = _finding(metadata={
        "file_sha256": "a" * 64,
        "logical_path": "/Documents/report.pdf",
        "field_name": "Title",
        "value": "Case Notes",
        "finding_basis": "deterministic",
        "deterministic_validation": True,
    })
    assert evidence_object_id("document_analyzer", first) != evidence_object_id("document_analyzer", second)


def test_candidate_cannot_count_as_unique_evidence():
    candidate = _finding(
        finding_type="OCR_TRANSCRIPTION",
        metadata={
            "candidate_only": True,
            "finding_basis": "probabilistic",
            "deterministic_validation": False,
            "recognised_text": "uncertain transcription",
        },
    )
    annotated = annotate_finding("ocr_text_extractor", candidate)
    assert annotated.metadata["fact_class"] == FactClass.CANDIDATE_ONLY.value
    assert annotated.metadata["counts_toward_unique_evidence"] is False


def test_derived_relationship_does_not_inflate_unique_evidence():
    derived = _finding(
        finding_type="RELATIONSHIP_RECORD",
        metadata={
            "source_finding_ids": ["f-1", "f-2"],
            "finding_basis": "deterministic",
            "deterministic_validation": True,
        },
    )
    annotated = annotate_finding("criminal_network_mapper", derived)
    assert annotated.metadata["fact_class"] in {
        FactClass.DERIVED_FACT.value,
        FactClass.AGGREGATE_SUMMARY.value,
    }
    assert annotated.metadata["counts_toward_unique_evidence"] is False


def test_canonical_statistics_never_say_zero_examined_with_nonzero_records():
    finding = annotate_finding(
        "document_analyzer",
        _finding(metadata={
            "file_sha256": "b" * 64,
            "logical_path": "/Documents/a.pdf",
            "field_name": "Author",
            "value": "A",
            "finding_basis": "deterministic",
            "deterministic_validation": True,
        }),
    )
    from modules._base import ModuleResult, ModuleStatus
    result = ModuleResult(
        module_name="document_analyzer",
        case_id="TEST-CASE",
        status=ModuleStatus.COMPLETED,
        findings=[finding],
        statistics={"objects_examined": 0},
        errors=[],
    )
    finalise_canonical_result(result)
    stats = result.statistics["module_statistics"]
    assert stats["objects_examined"] >= 1
    assert stats["accepted_records"] == 1


def test_dns_pairing_uses_runtime_values_not_fixture_constants():
    from modules.dns_analyzer import _normalise_dns_records
    records = [
        {
            "dns.flags.response": "0", "dns.qry.name": "mutated.example.invalid",
            "dns.id": "0x7a7a", "ip.src": "192.0.2.44", "ip.dst": "198.51.100.99",
            "dns.a": "", "dns.flags.rcode": "0",
        },
        {
            "dns.flags.response": "1", "dns.qry.name": "mutated.example.invalid",
            "dns.id": "0x7a7a", "ip.src": "198.51.100.99", "ip.dst": "192.0.2.44",
            "dns.a": "203.0.113.199", "dns.resp.ttl": "123", "dns.flags.rcode": "0",
        },
    ]
    counts = _normalise_dns_records(records)
    assert counts == {
        "queries": 1, "responses": 1, "questions": 2, "answers": 1,
        "errors": 0, "unmatched_requests": 0, "unmatched_responses": 0,
    }
    assert records[0]["record_type"] == "DNS_QUERY"
    assert records[1]["record_type"] == "DNS_RESPONSE"
    assert records[1]["answers"] == ["203.0.113.199"]
    assert records[0]["matched_pair"] and records[1]["matched_pair"]


def test_registry_export_parser_reads_arbitrary_runtime_value(tmp_path):
    from modules.windows_registry_analyzer import _parse_reg_export
    reg = tmp_path / "changed.reg"
    reg.write_text(
        'Windows Registry Editor Version 5.00\n\n'
        '[HKEY_CURRENT_USER\\Software\\Example\\Run]\n'
        '"ChangedUpdater"="C:\\\\Program Files\\\\Changed\\\\agent.exe"\n'
        '"Counter"=dword:0000002a\n',
        encoding="utf-8",
    )
    ok, values, error = _parse_reg_export(reg)
    assert ok and not error
    by_name = {item["value_name"]: item for item in values}
    assert by_name["ChangedUpdater"]["value_data"].endswith("Changed\\agent.exe")
    assert by_name["Counter"]["value_type"] == "REG_DWORD"
    assert by_name["Counter"]["value_data"] == 42
