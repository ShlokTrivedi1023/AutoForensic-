from __future__ import annotations
import json
from pathlib import Path
from types import SimpleNamespace

from core.evidence_ledger import LedgerState, normalise_candidate_records
from core.module_completion import certify_module_result, load_scope_contracts
from core.deterministic_memory import canonical_marker_sources
from modules._base import ModuleResult, ModuleStatus
from modules.timeline_builder import _ingest_archive_metadata_timestamps


def _result(module: str, *, ledger: dict[str,int], status=ModuleStatus.COMPLETED):
    return ModuleResult(
        module_name=module, case_id="GENERIC", status=status, findings=[], errors=[],
        statistics={
            "sources_discovered": 1, "sources_processed": 1,
            "supported_objects_discovered": sum(ledger.values()),
            "supported_objects_processed": sum(ledger.values()),
            "records_discovered": sum(ledger.values()),
            "records_processed": sum(ledger.values()),
            "deterministic_reconciliation": {"ledger_counts": ledger},
            "engine_completed": True,
        },
    )


def test_scope_groups_are_controlled():
    contracts=load_scope_contracts()
    groups=[c.get("baseline_group") for c in contracts.values()]
    assert groups.count("FROZEN_VERIFIED") == 37
    assert groups.count("TARGETED_REPAIR") == 8
    assert groups.count("SPECIALIST_INCOMPLETE") == 0


def test_candidate_ledger_is_not_silently_zero():
    result=_result("ocr_text_extractor", ledger={"CANDIDATE": 3, "REJECTED": 1, "UNRESOLVED": 0, "ACCEPTED": 0})
    result=certify_module_result(result,module_name="ocr_text_extractor",config={"analysis_path":"/tmp/evidence","_working_set":{"evidence_inventory":{}}})
    cert=result.statistics["completion_certificate"]
    assert cert["candidate_observations"] == 3
    assert cert["rejected_observations"] == 1
    assert cert["evidence_assurance"] == "INDETERMINATE"
    assert cert["count_units"]["candidate_observations"]["count"] == 3


def test_foremost_unresolved_candidates_block_pass():
    result=_result("foremost_carver", ledger={"CANDIDATE": 0, "REJECTED": 0, "UNRESOLVED": 2, "ACCEPTED": 0})
    result=certify_module_result(result,module_name="foremost_carver",config={"analysis_path":"/tmp/evidence","_working_set":{"evidence_inventory":{}}})
    assert result.status == ModuleStatus.INCOMPLETE
    assert result.statistics["completion_certificate"]["unresolved_observations"] == 2


def test_candidate_states_are_fail_closed():
    rows,counts=normalise_candidate_records("foremost_carver",[{"finding_type":"CARVE","metadata":{"candidate_reason":"pending structural validation"}}])
    assert rows[0]["ledger_state"] == LedgerState.UNRESOLVED.value
    assert counts["UNRESOLVED"] == 1
    rows,counts=normalise_candidate_records("ocr_text_extractor",[{"finding_type":"OCR","metadata":{"candidate_reason":"OCR requires corroboration"}}])
    assert rows[0]["ledger_state"] == LedgerState.CANDIDATE.value


def test_archive_metadata_is_discovered_generically(tmp_path: Path):
    import zipfile
    root=tmp_path/"files"; root.mkdir()
    archive=root/"anything.bin"
    info=zipfile.ZipInfo("member.txt", date_time=(2026,7,28,17,1,42))
    with zipfile.ZipFile(archive,"w") as zf: zf.writestr(info,b"x")
    events=_ingest_archive_metadata_timestamps({"_working_set":{"extracted_files_dir":str(root)}})
    assert any(e["event_type"]=="ARCHIVE_ENTRY_MODIFIED" and e["timestamp"].startswith("2026-07-28T17:01:42") for e in events)
    assert all("anything.bin" not in e["details"] for e in events)  # case-neutral description


def test_memory_ascii_utf16_semantic_dedup(tmp_path: Path):
    marker="PROCESS pid=42 name=sample.exe"
    p=tmp_path/"memory.raw"
    p.write_bytes(marker.encode()+b"\x00"*8+marker.encode("utf-16le"))
    result=canonical_marker_sources([p])
    # API returns canonical records, not one record per encoding occurrence.
    records=result.get("records") if isinstance(result,dict) else result
    if records is None and isinstance(result,dict): records=result.get("markers")
    assert records is not None
    matching=[r for r in records if marker in str(r)]
    assert len(matching) <= 1


def test_lnk_parser_rejects_short_marker_and_accepts_structural_minimum(tmp_path: Path):
    import logging, struct
    from modules.artifact_extractor import _parse_lnk
    short=tmp_path/"short.lnk"; short.write_bytes(b"C:\\target.exe")
    assert _parse_lnk(short,logging.getLogger("test"))["parse_status"] == "too_short"
    valid=bytearray(80)
    struct.pack_into("<I",valid,0,0x4C)
    valid[4:20]=bytes([0x01,0x14,0x02,0x00,0,0,0,0,0xC0,0,0,0,0,0,0,0x46])
    # flags=0 and terminating ExtraData block at offset 76
    structural=tmp_path/"structural.lnk"; structural.write_bytes(valid)
    parsed=_parse_lnk(structural,logging.getLogger("test"))
    assert parsed["parse_status"] == "ok"
    assert parsed["valid_clsid"] is True
    assert parsed["field_boundaries_valid"] is True


def test_file_path_plus_matching_hash_satisfies_h2(tmp_path: Path):
    import hashlib
    from modules._base import Finding, Severity
    p=tmp_path/"evidence.bin"; p.write_bytes(b"evidence")
    f=Finding(finding_id="f",finding_type="EXACT",severity=Severity.INFO,description="exact",timestamp="",evidence_path=str(p),artifact_path=str(p),metadata={"provenance_source_path":str(p),"file_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"deterministic_validation":True})
    r=ModuleResult(module_name="evidence_validator",case_id="X",status=ModuleStatus.COMPLETED,findings=[f],statistics={"sources_discovered":1,"sources_processed":1,"supported_objects_discovered":1,"supported_objects_processed":1,"records_discovered":1,"records_processed":1})
    r=certify_module_result(r,module_name="evidence_validator",config={"analysis_path":str(p),"_working_set":{"evidence_inventory":{}}})
    assert r.statistics["completion_certificate"]["provenance_gaps"] == 0


def test_confirmed_stego_supersedes_same_source_candidate():
    from core.report_ai import _build_material_findings
    rows = [
        {
            "module": "steganography_detector",
            "finding_type": "STEGANOGRAPHIC_PAYLOAD_DECODED",
            "title": "Payload decoded",
            "detail": "Payload was deterministically decoded and retained.",
            "path": "/evidence/picture.bmp",
            "severity": "MEDIUM",
            "metadata": {"file_sha256": "a" * 64},
        },
        {
            "module": "steganography_detector",
            "finding_type": "LSB_ANOMALY",
            "title": "Potential LSB anomaly",
            "detail": "Statistical steganography indicator.",
            "path": "/evidence/picture.bmp",
            "severity": "MEDIUM",
            "metadata": {"candidate_only": True, "file_sha256": "a" * 64},
        },
    ]
    material = _build_material_findings(rows)
    themes = [row["theme"] for row in material]
    assert "steganography_confirmed" in themes
    assert "steganography_candidate" not in themes


def test_missing_administrative_files_emit_unsigned_draft_notice():
    from core.report_appendices import build_appendix_declaration
    section = build_appendix_declaration(case_config=None)
    text = " ".join(
        str(block.data.get("text") or "")
        for block in section.blocks
        if block.block_type == "paragraph"
    )
    assert "Administrative appendices incomplete — unsigned draft." in text
