from pathlib import Path
import tempfile

from core.evidence_ledger import ledger_counts
from modules.foremost_carver import _parse_audit
from modules.scalpel_carver import _parse_audit_txt


def test_public_ledger_counts():
    assert ledger_counts([
        {"ledger_state": "CANDIDATE"},
        {"ledger_state": "REJECTED"},
    ]) == {
        "ACCEPTED": 0,
        "CANDIDATE": 1,
        "REJECTED": 1,
        "UNRESOLVED": 0,
    }


def test_foremost_tabular_offsets():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "audit.txt"
        p.write_text("0:\t00002120.jpg \t      19 KB \t    1085472 \t \n")
        records = _parse_audit(p)
        assert records[0]["offset"] == 1085472
        assert records[0]["file_name"] == "00002120.jpg"


def test_scalpel_intervals_and_boolean_contract():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "audit.txt"
        p.write_text("00000015.bmp       357636        YES        10000000        image.raw\n")
        record = _parse_audit_txt(p)["00000015.bmp"]
        assert record["source_start"] == 357636
        assert record["source_end"] == 10357636
        assert record["chop"] is True
