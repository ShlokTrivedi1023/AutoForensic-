from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.acquisition import (
    AcquisitionError,
    DeviceInfo,
    acquire_device,
    hash_segments,
    prepare_write_protection,
    sha256_stream,
    verify_post_analysis,
)


def _test_device(path: Path) -> DeviceInfo:
    return DeviceInfo(
        path=str(path.resolve()),
        name=path.name,
        kname=path.name,
        device_type="test-file",
        read_only=True,
        size_bytes=path.stat().st_size,
        model="CONTROLLED REGRESSION FILE",
        serial="RANDOMISED-TEST",
        transport="file",
    )


def test_raw_acquisition_records_distinct_hash_stages(tmp_path: Path):
    source = tmp_path / "controlled-source.bin"
    source.write_bytes((b"randomised acquisition corpus\n" * 8192) + bytes(range(256)))
    dev = _test_device(source)
    protection = prepare_write_protection(
        dev, requested_method="software", allow_regular_file_test=True
    )
    record = acquire_device(
        source=dev,
        output_dir=tmp_path / "output",
        case_id="GENERIC-CASE",
        evidence_id="EX-001",
        investigator="Generic Examiner",
        acquisition_format="raw",
        write_protection=protection,
        allow_regular_file_test=True,
    )
    expected, size = sha256_stream(source)
    assert record.acquisition_verified is True
    assert record.source_pre_acquisition_sha256 == expected
    assert record.source_post_acquisition_sha256 == expected
    assert record.acquired_content_sha256 == expected
    assert record.source_pre_vs_acquired == "MATCH"
    assert record.source_pre_vs_source_post == "MATCH"
    assert Path(record.image_path).stat().st_size == size
    assert record.container_set_sha256_pre_analysis
    assert record.logical_media_sha256_pre_analysis == expected
    manifest = json.loads(Path(record.manifest_path).read_text(encoding="utf-8"))
    assert manifest["write_protection"]["effective_method"] == "TEST_FILE_READ_ONLY_OPEN"
    assert manifest["status"] == "ACQUIRED_PENDING_POST_ANALYSIS_VERIFICATION"

    verified = verify_post_analysis(record)
    assert verified.analysis_integrity_verified is True
    assert verified.pre_vs_post_container_set == "MATCH"
    assert verified.pre_vs_post_logical_media == "MATCH"
    assert verified.status == "VERIFIED_COMPLETE"


def test_post_analysis_mutation_is_fail_closed(tmp_path: Path):
    source = tmp_path / "source.bin"
    source.write_bytes(b"A" * 65536)
    dev = _test_device(source)
    protection = prepare_write_protection(dev, allow_regular_file_test=True)
    record = acquire_device(
        source=dev,
        output_dir=tmp_path / "output",
        case_id="MUTATION-CONTROL",
        evidence_id="EX-009",
        investigator="Generic Examiner",
        acquisition_format="raw",
        write_protection=protection,
        allow_regular_file_test=True,
    )
    with Path(record.image_path).open("ab") as fh:
        fh.write(b"unauthorised change")
    with pytest.raises(AcquisitionError, match="Post-analysis integrity verification failed"):
        verify_post_analysis(record)
    assert record.pre_vs_post_container_set == "MISMATCH"
    assert record.pre_vs_post_logical_media == "MISMATCH"


def test_acquisition_refuses_unverified_write_protection(tmp_path: Path):
    source = tmp_path / "source.bin"
    source.write_bytes(b"x")
    dev = _test_device(source)
    protection = prepare_write_protection(dev, allow_regular_file_test=True)
    protection.verified = False
    with pytest.raises(AcquisitionError, match="write protection is not verified"):
        acquire_device(
            source=dev,
            output_dir=tmp_path / "out",
            case_id="REFUSE",
            evidence_id="EX-001",
            investigator="Examiner",
            acquisition_format="raw",
            write_protection=protection,
            allow_regular_file_test=True,
        )


def test_segment_manifest_changes_when_image_changes(tmp_path: Path):
    image = tmp_path / "image.raw"
    image.write_bytes(b"first")
    rows1, digest1 = hash_segments(image)
    image.write_bytes(b"second")
    rows2, digest2 = hash_segments(image)
    assert rows1[0].sha256 != rows2[0].sha256
    assert digest1 != digest2


def test_acquisition_cli_imports_and_displays_help():
    import subprocess
    import sys
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    completed = subprocess.run(
        [sys.executable, str(root / "tools" / "acquire_devices.py"), "--help"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    assert "--verify-post-analysis" in completed.stdout
    assert "--write-protection" in completed.stdout


def test_new_output_directory_uses_existing_parent_for_disk_ancestry(tmp_path):
    from core.acquisition import _existing_path_anchor

    not_created = tmp_path / "future-case" / "nested-output"
    assert not not_created.exists()
    assert _existing_path_anchor(not_created) == tmp_path.resolve()


def test_admin_cli_direct_execution_displays_help():
    import subprocess
    import sys
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    completed = subprocess.run(
        [sys.executable, str(root / "tools" / "admin.py"), "--help"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    assert "set-admin-password" in completed.stdout
    assert "verify-chain" in completed.stdout


def test_acquisition_cli_prepare_write_protection_keywords_match_core_api():
    """Prevent CLI/core keyword drift from reaching live evidence workflows."""
    import ast
    import inspect
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    source_path = root / "tools" / "acquire_devices.py"
    tree = ast.parse(source_path.read_text(encoding="utf-8"), filename=str(source_path))
    calls = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "prepare_write_protection"
    ]
    assert calls, "acquisition CLI no longer calls prepare_write_protection"
    accepted = set(inspect.signature(prepare_write_protection).parameters)
    for call in calls:
        supplied = {kw.arg for kw in call.keywords if kw.arg is not None}
        assert supplied <= accepted, (
            f"CLI passes unsupported keyword(s): {sorted(supplied - accepted)}"
        )
    assert "hardware_blocker" in {kw.arg for kw in calls[0].keywords}
