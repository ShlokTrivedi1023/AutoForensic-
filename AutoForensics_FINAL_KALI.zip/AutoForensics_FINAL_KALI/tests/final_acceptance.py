#!/usr/bin/env python3
from __future__ import annotations
import importlib, os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

def check(ok: bool,label: str,failures: list[str])->None:
    print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    if not ok: failures.append(label)

def main()->int:
    failures=[]
    import yaml
    cfg=yaml.safe_load((ROOT/'config/modules.yaml').read_text(encoding='utf-8'))
    names=[n for n,d in cfg['modules'].items() if d.get('active',True)]
    imported=[]
    for name in names:
        try:
            importlib.import_module(f'modules.{name}'); imported.append(name)
        except Exception as exc:
            print(f'[IMPORT FAIL] {name}: {exc}')
    check(len(names)==45 and len(imported)==45,'all 45 registered modules import',failures)
    cp=subprocess.run([sys.executable,str(ROOT/'tools/failure_isolation_regression.py')],cwd=ROOT)
    check(cp.returncode==0,'failure isolation crash/SystemExit/timeout test',failures)

    production='\n'.join(
        p.read_text(encoding='utf-8',errors='ignore')
        for root in (ROOT/'core',ROOT/'modules') for p in root.rglob('*.py')
    )
    supplied=[x for x in os.environ.get('AUTOFORENSICS_FORBIDDEN_TOKENS','').split('|') if x]
    check(not any(token.lower() in production.lower() for token in supplied),
          'no externally supplied forbidden token occurs in production core/modules',failures)
    check('/home/kali/' not in production and 'C:\\Users\\' not in production,
          'no fixed operator home path occurs in production core/modules',failures)
    check('DUMMY VALIDATION MATERIAL — INGESTION TEST ONLY — NOT VERIFIED' in
          (ROOT/'core/report_appendices.py').read_text(encoding='utf-8'),
          'dummy attachment warning is visible in report code',failures)
    check('RAW CARVING CANDIDATES — NOT VALIDATED RECOVERED FILES' in
          (ROOT/'core/report_generator.py').read_text(encoding='utf-8'),
          'carving candidates are explicitly non-evidential',failures)
    dns=(ROOT/'modules/dns_analyzer.py').read_text(encoding='utf-8')
    check('candidate_metadata' in dns and 'deterministic_metadata' in dns,
          'DNS deterministic/candidate separation exists',failures)
    mobile=(ROOT/'modules/mobile_analyzer.py').read_text(encoding='utf-8')
    check('OUT_OF_SCOPE' in mobile and 'first_class_mobile' in mobile and 'leapp_applicable' in mobile,
          'mobile acquisition/LEAPP scope separated from nested artefact parsing',failures)
    maintext=(ROOT/'core/main.py').read_text(encoding='utf-8')
    check('NOT_APPLICABLE' in maintext and 'genuine_memory' in maintext,
          'Volatility structural modules are gated by genuine memory classification',failures)
    check('Machine transcription — requires visual or independent confirmation' in
          (ROOT/'modules/ocr_text_extractor.py').read_text(encoding='utf-8'),
          'OCR is visibly labelled machine transcription',failures)
    ai='\n'.join((ROOT/x).read_text(encoding='utf-8') for x in
                 ['core/llm_provider.py','core/ai_policy.py','tools/run_ready_case.py'])
    check('ollama' not in ai.lower() and 'gemini' not in ai.lower(),
          'OpenAI is the only optional LLM provider',failures)
    check(all((ROOT/x).is_file() for x in ['run_final.sh','verify_final.sh','install.sh']),
          'single-command Kali scripts included',failures)
    print(f'FINAL ACCEPTANCE: {len(failures)} failure(s)')
    return 1 if failures else 0
if __name__=='__main__': raise SystemExit(main())
