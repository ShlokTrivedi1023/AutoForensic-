from __future__ import annotations

import json
import logging
import os
import sqlite3
import uuid
from pathlib import Path

import pytest

from core.memory_marker_modules import run_marker_scope
from core.volatility_adapter import resolve_volatility_launcher, run_volatility_plugin
from modules._base import ModuleStatus
from modules.image_mounter import run as run_image_mounter
from modules.memory_string_analyzer import run as run_memory_strings
from modules.mobile_analyzer import run as run_mobile

LOG = logging.getLogger("v280-targeted")


def _random_marker_corpus(path: Path) -> dict[str, str]:
    token = uuid.uuid4().hex
    domain = f"{token}.example.invalid"
    ip = f"198.51.100.{int(token[:2], 16) % 200 + 1}"
    lines = [
        f"PROCESS pid=731 ppid=4 name={token[:8]}.exe state=Running",
        f"NETCONN pid=731 TCP 192.0.2.10:49152 {ip}:443 ESTABLISHED",
        f"HIDDEN_PROCESS_CANDIDATE pid=917 name={token[8:16]}.exe list_state=absent scan_state=present",
        f"ROOTKIT_TEST_MARKER={token}",
        f"DNS {domain} A {ip}",
        f"URL https://{domain}/artifact/{token}",
        f"CREDENTIAL username=user-{token[:6]} password=pass-{token[6:18]}",
        f"API_KEY key-{token}",
        f"KEYWORD operation-{token}",
        f"MALWARE_TEST=harmless-{token}",
    ]
    path.write_bytes(("\x00".join(lines) + "\x00").encode("ascii"))
    return {"token": token, "domain": domain, "ip": ip}


@pytest.mark.parametrize(
    "module_name,expected_type",
    [
        ("memory_process_list", "MEMORY_PROCESS_MARKER"),
        ("memory_network_connections", "MEMORY_NETWORK_MARKER"),
        ("memory_artifact_extractor", "MEMORY_CREDENTIAL_MARKER"),
        ("memory_malware_scanner", "MEMORY_MALWARE_TEST_MARKER"),
        ("rootkit_detector", "ROOTKIT_TEST_MARKER"),
    ],
)
def test_randomised_memory_marker_cross_corpus(module_name: str, expected_type: str, tmp_path: Path):
    source = tmp_path / f"{uuid.uuid4().hex}.mem"
    values = _random_marker_corpus(source)
    result = run_marker_scope(module_name=module_name, case_id=f"CASE-{uuid.uuid4().hex}", marker_paths=[source])
    assert result.status == ModuleStatus.COMPLETED
    assert any(f.finding_type == expected_type for f in result.findings)
    assert all(f.evidence_path == str(source) for f in result.findings)
    assert all((f.metadata or {}).get("deterministic_validation") is True for f in result.findings)
    # The source values are runtime-generated and must be parsed, not expected by production code.
    assert values["token"] not in (Path(__file__).parents[1] / "core" / "memory_marker_modules.py").read_text()


def test_memory_marker_negative_and_malformed_controls(tmp_path: Path):
    negative = tmp_path / "negative.mem"
    negative.write_bytes(os.urandom(4096) + b"ordinary printable text without structured grammar")
    result = run_marker_scope(module_name="memory_process_list", case_id="NEG", marker_paths=[negative])
    assert result.status == ModuleStatus.COMPLETED
    assert result.findings == []
    malformed = tmp_path / "malformed.mem"
    malformed.write_bytes(b"PROCESS pid=not-a-number ppid=4 name=x.exe state=Running\x00")
    malformed_result = run_marker_scope(module_name="memory_process_list", case_id="MAL", marker_paths=[malformed])
    assert malformed_result.status == ModuleStatus.COMPLETED
    assert malformed_result.findings == []


def test_memory_string_analyzer_randomised_positive_and_negative(tmp_path: Path):
    token = uuid.uuid4().hex
    source = tmp_path / "random.vmem"
    source.write_bytes(
        b"\x00" * 31
        + f"https://{token}.example.invalid/path\x00user-{token[:8]}@example.invalid\x00".encode()
        + b"\x00" * 17
    )
    result = run_memory_strings(
        source, "STRING-CROSS-CORPUS", tmp_path / "out",
        {"evidence_type": "memory", "memory_path": str(source)}, LOG,
    )
    assert result.status == ModuleStatus.COMPLETED
    assert result.findings
    for finding in result.findings:
        assert (finding.metadata or {}).get("deterministic_validation") is True
        assert (finding.metadata or {}).get("occurrences")
    empty = tmp_path / "empty.vmem"
    empty.write_bytes(os.urandom(2048))
    negative = run_memory_strings(
        empty, "STRING-NEGATIVE", tmp_path / "negative-out",
        {"evidence_type": "memory", "memory_path": str(empty)}, LOG,
    )
    assert negative.status == ModuleStatus.COMPLETED
    assert negative.findings == []


def test_image_mounter_validates_runtime_access_path_not_case_name(tmp_path: Path):
    evidence = tmp_path / f"{uuid.uuid4().hex}.raw"
    evidence.write_bytes(os.urandom(8192))
    result = run_image_mounter(
        evidence, f"CASE-{uuid.uuid4().hex}", tmp_path / "mount-out",
        {"analysis_path": str(evidence), "_working_set": {"evidence_access_method": "native_raw_stream"}}, LOG,
    )
    assert result.status == ModuleStatus.COMPLETED
    assert result.statistics["native_access"] == 1
    assert result.findings[0].evidence_path == str(evidence)
    missing = run_image_mounter(
        evidence, "MISSING", tmp_path / "missing-out",
        {"analysis_path": str(tmp_path / "absent.raw"), "_working_set": {}}, LOG,
    )
    assert missing.status == ModuleStatus.FAILED_ISOLATED
    assert not missing.findings


def _create_android(root: Path, token: str) -> None:
    db = root / "data" / "data" / "com.android.providers.telephony" / "databases" / "mmssms.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.execute("create table sms (_id integer, address text, date integer, type integer, body text, read integer)")
    conn.execute("insert into sms values (1, ?, 1700000000000, 1, ?, 1)", (f"+44{token[:9]}", f"message-{token}"))
    conn.commit(); conn.close()


def _create_ios(root: Path, token: str) -> None:
    db = root / "HomeDomain" / "Library" / "SMS" / "sms.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.execute("create table message (ROWID integer, guid text, text text, date integer, handle_id integer, service text, is_from_me integer)")
    conn.execute("insert into message values (1, ?, ?, 700000000, 1, 'iMessage', 0)", (token, f"ios-{token}"))
    conn.commit(); conn.close()


@pytest.mark.parametrize("platform,builder", [("android", _create_android), ("ios", _create_ios)])
def test_mobile_native_randomised_cross_corpus(platform, builder, tmp_path: Path):
    token = uuid.uuid4().hex
    root = tmp_path / f"{platform}-{token}"
    builder(root, token)
    result = run_mobile(
        root, f"MOBILE-{uuid.uuid4().hex}", tmp_path / f"out-{platform}",
        {"device_type": platform, "evidence_type": "disk", "run_leapp": False,
         "mobile_sources": [str(root)], "mobile_roots": [str(root)], "_working_set": {}}, LOG,
    )
    assert result.status == ModuleStatus.COMPLETED
    assert result.findings
    assert any(f.finding_type == "MOBILE_SMS" for f in result.findings)
    assert result.statistics["parser_errors"] == 0
    assert result.statistics["unresolved_supported_objects"] == 0


def test_mobile_negative_control_returns_no_false_findings(tmp_path: Path):
    root = tmp_path / "data" / "data" / "empty.app"
    root.mkdir(parents=True)
    result = run_mobile(
        tmp_path, "MOBILE-NEGATIVE", tmp_path / "mobile-neg-out",
        {"device_type": "android", "evidence_type": "disk", "run_leapp": False,
         "mobile_sources": [str(tmp_path)], "mobile_roots": [str(tmp_path)], "_working_set": {}}, LOG,
    )
    assert result.status in {ModuleStatus.COMPLETED, ModuleStatus.FAILED_ISOLATED}
    assert result.findings == []


def test_volatility_launcher_is_dynamic_and_records_command(tmp_path: Path, monkeypatch):
    fake = tmp_path / "vol"
    fake.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        "if '--version' in sys.argv: print('Volatility 3 Framework 9.9-test')\n"
        "else: print('PID\\tPPID\\tImageFileName\\n101\\t4\\trandom.exe')\n"
    )
    fake.chmod(0o755)
    memory = tmp_path / "runtime-name.mem"
    memory.write_bytes(os.urandom(4096))
    launcher = resolve_volatility_launcher({"vol_path": str(fake)})
    assert launcher.resolved_path == str(fake)
    execution = run_volatility_plugin(
        evidence_path=memory, plugin="windows.pslist.PsList",
        config={"vol_path": str(fake)}, timeout=10,
    )
    assert execution.returncode == 0
    assert "random.exe" in execution.stdout
    assert str(memory.resolve()) in execution.command
    assert execution.command[-1] == "windows.pslist.PsList"


def test_volatility_missing_dependency_is_explicit(tmp_path: Path, monkeypatch):
    # Isolate the test from a real Volatility installation in standard paths
    # such as /usr/local/bin/vol. The production resolver must continue to
    # discover those locations; this test specifically exercises the genuine
    # no-launcher branch.
    import core.volatility_adapter as volatility_adapter

    real_candidate = volatility_adapter._candidate

    def isolated_candidate(value: str, source: str):
        if source == "standard installation":
            return None
        return real_candidate(value, source)

    monkeypatch.setattr(volatility_adapter, "_candidate", isolated_candidate)
    monkeypatch.setenv("PATH", str(tmp_path))
    monkeypatch.delenv("VOLATILITY3_PATH", raising=False)
    monkeypatch.delenv("AUTOFORENSICS_VOLATILITY_BIN", raising=False)
    with pytest.raises(FileNotFoundError):
        resolve_volatility_launcher({"vol_path": str(tmp_path / "missing-vol")})
