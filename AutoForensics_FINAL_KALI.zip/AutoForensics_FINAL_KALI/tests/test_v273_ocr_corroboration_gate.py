from __future__ import annotations

from copy import deepcopy

from core.ocr_assurance import (
    accepted_ocr_finding_is_corroborated,
    all_accepted_ocr_findings_are_corroborated,
)


def valid_finding() -> dict:
    return {
        "finding_type": "OCR_TRANSCRIPTION_CORROBORATED",
        "metadata": {
            "deterministic_validation": True,
            "image_sha256": "a" * 64,
            "transcript_sha256": "b" * 64,
            "examiner_confirmation_status": "INDEPENDENTLY_CORROBORATED",
            "corroboration": {
                "confirmed": True,
                "matched_fields": [
                    {"label": "FIELD_ONE", "value": "value-one", "matches": [{"sha256": "c" * 64}]},
                    {"label": "FIELD_TWO", "value": "value-two", "matches": [{"sha256": "d" * 64}]},
                ],
                "supporting_sources": [{"sha256": "c" * 64}, {"sha256": "d" * 64}],
            },
        },
    }


def test_corroborated_ocr_finding_is_accepted_by_gate() -> None:
    finding = valid_finding()
    assert accepted_ocr_finding_is_corroborated(finding)
    assert all_accepted_ocr_findings_are_corroborated([finding])


def test_uncorroborated_ocr_finding_fails_closed() -> None:
    finding = valid_finding()
    finding["metadata"]["corroboration"] = {"confirmed": False, "matched_fields": [], "supporting_sources": []}
    assert not accepted_ocr_finding_is_corroborated(finding)


def test_same_source_hash_is_not_independent_corroboration() -> None:
    finding = valid_finding()
    image_hash = finding["metadata"]["image_sha256"]
    for field in finding["metadata"]["corroboration"]["matched_fields"]:
        field["matches"] = [{"sha256": image_hash}]
    finding["metadata"]["corroboration"]["supporting_sources"] = [{"sha256": image_hash}]
    assert not accepted_ocr_finding_is_corroborated(finding)


def test_candidate_or_unknown_ocr_types_cannot_pass_as_accepted() -> None:
    candidate = valid_finding()
    candidate["metadata"]["candidate_only"] = True
    assert not accepted_ocr_finding_is_corroborated(candidate)
    unknown = valid_finding()
    unknown["finding_type"] = "OCR_ENGINE_TRANSCRIPTION"
    assert not accepted_ocr_finding_is_corroborated(unknown)
