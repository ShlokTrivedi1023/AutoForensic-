from __future__ import annotations


def _accepted(start: int, length: int, digest: str) -> dict:
    return {
        "final_state": "ACCEPTED",
        "source_start": start,
        "source_length": length,
        "source_end": start + length,
        "candidate_size_bytes": length,
        "structured_length": length,
        "structural_validation": {"valid": True},
        "source_bytes_match_output": True,
        "output_sha256": digest,
        "source_interval_sha256": digest,
    }


def test_scalpel_completion_counters_are_emitted_from_runtime_records():
    from modules.scalpel_carver import _accepted_completion_counters

    a = _accepted(100, 20, "a" * 64)
    b = _accepted(200, 30, "b" * 64)
    assert _accepted_completion_counters([a, b]) == {
        "invalid_accepted_carvings": 0,
        "overlapping_accepted_carvings": 0,
    }


def test_scalpel_completion_counters_fail_closed_on_invalid_or_overlapping_acceptance():
    from modules.scalpel_carver import _accepted_completion_counters

    a = _accepted(100, 20, "a" * 64)
    b = _accepted(110, 20, "b" * 64)
    bad = _accepted(300, 10, "c" * 64)
    bad["source_bytes_match_output"] = False
    counters = _accepted_completion_counters([a, b, bad])
    assert counters["invalid_accepted_carvings"] == 1
    assert counters["overlapping_accepted_carvings"] == 2


def test_report_audit_allows_findings_with_partial_execution_status():
    from tools.report_output_audit import _failures_for_json

    report = {
        "report_metadata": {},
        "sections": [
            {"section_title": "Analysis: X", "blocks": [{"type": "table", "data": {
                "headers": ["Module", "Execution Outcome", "Status", "Evidence Assurance", "Examined", "Findings / Reason"],
                "rows": [["Scalpel File Carver", "RAN FOUND X", "INCOMPLETE", "MIXED", "71 candidates", "18"]],
            }}]},
            {"section_title": "Examination Coverage", "blocks": [{"type": "table", "data": {
                "headers": ["Module", "Status", "Execution Status", "Canonical Findings", "Candidates", "Assurance", "Reason / Summary"],
                "rows": [["Scalpel File Carver", "INCOMPLETE", "EXECUTION_PARTIAL", "18", "0", "MIXED", "partial scope"]],
            }}]},
        ],
    }
    failures, _ = _failures_for_json(report, require_llm=False)
    assert not any("execution status contradicts" in item for item in failures)
