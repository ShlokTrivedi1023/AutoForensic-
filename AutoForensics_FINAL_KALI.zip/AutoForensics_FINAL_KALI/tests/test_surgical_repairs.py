import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.forensic_identity import deleted_artifact_identity
from modules.timeline_builder import _build_examiner_timeline

def test_deleted_identity_ignores_export_alias():
    a=deleted_artifact_identity(original_path='/x/a.txt',starting_cluster=42,content_hash='ab')
    b=deleted_artifact_identity(original_path='/x/a.txt',starting_cluster=42,content_hash='ab')
    assert a==b

def test_timeline_semantic_dedup():
    e=[{'timestamp':'2026-01-01T00:00:00Z','event':'DNS query example.invalid','source':'dns','source_artifact':'x.pcap'}, {'timestamp':'2026-01-01T00:00:00Z','event':'DNS query example.invalid','source':'network decoder','source_artifact':'x.pcap'}]
    out=_build_examiner_timeline(e)
    assert len(out)==1 and out[0]['event']=='DNS request'

def test_no_generic_timeline_labels():
    assert _build_examiner_timeline([{'timestamp':'2026-01-01T00:00:00Z','event':'timestamp:','source':'x'}])==[]
