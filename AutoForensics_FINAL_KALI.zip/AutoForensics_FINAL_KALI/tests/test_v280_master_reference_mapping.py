from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


def _load_module():
    path = Path(__file__).resolve().parents[1] / "tools" / "evaluate_master_reference.py"
    spec = spec_from_file_location("evaluate_master_reference_v280", path)
    assert spec and spec.loader
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_historical_master_numbering_is_stable_after_autopsy_removal():
    mod = _load_module()
    assert len(mod.HISTORICAL_MODULE_ORDER) == 46
    assert mod.HISTORICAL_NUM_TO_MODULE[6] == "autopsy_analysis"
    assert mod.HISTORICAL_NUM_TO_MODULE[46] == "mobile_analyzer"
    assert "autopsy_analysis" not in mod.MODULE_ORDER
    assert len(mod.MODULE_ORDER) == 45


def test_master_module_46_parses_without_key_error():
    mod = _load_module()
    numbers = mod.parse_module_numbers("41,43,46")
    active = [
        mod.HISTORICAL_NUM_TO_MODULE[number]
        for number in numbers
        if mod.HISTORICAL_NUM_TO_MODULE.get(number) in mod.MODULE_ORDER
    ]
    assert active == [
        "email_communications_analyzer",
        "criminal_network_mapper",
        "mobile_analyzer",
    ]


def test_removed_historical_autopsy_slot_is_not_treated_as_active():
    mod = _load_module()
    numbers = mod.parse_module_numbers("6")
    active = [
        mod.HISTORICAL_NUM_TO_MODULE[number]
        for number in numbers
        if mod.HISTORICAL_NUM_TO_MODULE.get(number) in mod.MODULE_ORDER
    ]
    assert active == []
