from __future__ import annotations

import hashlib
import json
from pathlib import Path

from core.evidence_declaration import discover_evidence_declarations
from core.report_ai import _material_theme, _build_material_findings
from core.version import VERSION

ROOT = Path(__file__).resolve().parents[1]


def test_release_version_is_central_and_consistent():
    assert VERSION == (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    for rel in ("run.py", "core/main.py", "core/report_generator.py", "tools/admin.py"):
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "2.3.0-strict-scope" not in text


def test_exact_39_frozen_modules_are_hash_locked_and_unchanged():
    payload = json.loads((ROOT / "config/frozen_module_lock.json").read_text(encoding="utf-8"))
    lock = payload.get("modules", payload)
    assert len(lock) == 37
    for module_name, record in lock.items():
        expected = record.get("sha256") if isinstance(record, dict) else record
        rel = record.get("path") if isinstance(record, dict) else f"modules/{module_name}.py"
        path = ROOT / rel
        assert path.is_file()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected


def test_evidence_declaration_is_content_driven_not_filename_driven(tmp_path: Path):
    arbitrary = tmp_path / "random-material.bin.txt"
    arbitrary.write_text(
        "Scope notice: this evidence corpus is fabricated validation material for parser testing only.",
        encoding="utf-8",
    )
    config = {"_working_set": {"primary_evidence_roots": [str(tmp_path)]}}
    rows = discover_evidence_declarations(config)
    assert len(rows) == 1
    assert rows[0].path == str(arbitrary)
    assert rows[0].sha256 == hashlib.sha256(arbitrary.read_bytes()).hexdigest()
    assert "fabricated validation material" in rows[0].excerpt


def test_negated_declaration_is_not_promoted(tmp_path: Path):
    p = tmp_path / "ordinary.txt"
    p.write_text("This evidence is not synthetic and is not validation material.", encoding="utf-8")
    config = {"_working_set": {"primary_evidence_roots": [str(tmp_path)]}}
    assert discover_evidence_declarations(config) == []


def test_report_material_classification_uses_finding_types_not_fixture_values():
    hash_fact = {
        "module": "hashcat_recovery", "finding_type": "PASSWORD_RECOVERED",
        "title": "Password recovered", "detail": "Exact hash/plaintext verification",
        "metadata": {"hash_type": "MD5", "recovery_method": "direct_recomputation"},
    }
    archive_fact = {
        "module": "john_recovery", "finding_type": "PASSWORD_RECOVERED",
        "title": "Archive password recovered", "detail": "Encrypted archive decryption verified",
        "metadata": {"decryption_verified": True, "file_path": "/evidence/item.zip"},
    }
    stego_fact = {
        "module": "steganography_detector", "finding_type": "STEGANOGRAPHIC_PAYLOAD_DECODED",
        "title": "Payload decoded", "detail": "Payload was deterministically decoded",
        "metadata": {"decoded_payload_sha256": "a" * 64},
    }
    carve_fact = {
        "module": "native_signature_carver", "finding_type": "CARVED_FILE_VALIDATED",
        "title": "Carved object validated", "detail": "Internal structure and boundary validated",
        "metadata": {"file_sha256": "b" * 64},
    }
    assert _material_theme("hashcat_recovery", hash_fact) == "password_hash"
    assert _material_theme("john_recovery", archive_fact) == "encrypted"
    assert _material_theme("steganography_detector", stego_fact) == "steganography_confirmed"
    assert _material_theme("native_signature_carver", carve_fact) == "carving_validated"
    material = _build_material_findings([hash_fact, archive_fact, stego_fact, carve_fact])
    by_theme = {row["theme"]: row for row in material}
    assert by_theme["password_hash"]["assessment_status"] == "VERIFIED HASH RELATIONSHIP"
    assert by_theme["steganography_confirmed"]["assessment_status"] == "VERIFIED RECOVERED BYTES"
    assert by_theme["carving_validated"]["assessment_status"] == "STRUCTURALLY VALIDATED"


def test_heuristic_security_labels_are_candidate_only_in_repaired_modules():
    checks = {
        "modules/http_reconstructor.py": (
            "SUSPICIOUS_USER_AGENT_CANDIDATE", "HTTP_EXFILTRATION_CANDIDATE",
            "HTTP_EXECUTABLE_CONTENT_CANDIDATE", "candidate_metadata(",
        ),
        "modules/network_protocol_decoder.py": (
            "SMB_ADMIN_SHARE_ABUSE_CANDIDATE", "ICMP_TUNNEL_CANDIDATE",
            "ARP_POISONING_CANDIDATE", "candidate_metadata(",
        ),
        "modules/memory_process_list.py": (
            "ROOTKIT_DKOM_CANDIDATE", "PROCESS_MASQUERADING_CANDIDATE",
            "SUSPICIOUS_PROCESS_PARENT_CANDIDATE", "candidate_metadata(",
        ),
        "modules/rootkit_detector.py": (
            "ROOTKIT_DKOM_CANDIDATE", "SSDT_HOOK_CANDIDATE",
            "IRP_HOOK_CANDIDATE", "candidate_metadata(",
        ),
    }
    for rel, expected in checks.items():
        text = (ROOT / rel).read_text(encoding="utf-8")
        for token in expected:
            assert token in text
        assert "metadata={**candidate_metadata" not in text


def test_completion_schema_declares_execution_assurance_and_units():
    text = (ROOT / "core/module_completion.py").read_text(encoding="utf-8")
    assert "autoforensics-module-completion-v4" in text
    assert '"execution_status"' in text
    assert '"evidence_assurance"' in text
    assert '"count_units"' in text
    assert "return max(values)" not in text


def test_generic_result_loader_preserves_typed_findings_and_examined_units(tmp_path: Path):
    import logging
    from core.report_loader import _load_generic_module_result

    result_path = tmp_path / "module_result.json"
    result_path.write_text(json.dumps({
        "module_name": "example_module",
        "status": "COMPLETED",
        "execution_outcome": "ran_found_x",
        "findings": [{
            "finding_id": "F-1",
            "finding_type": "CARVED_FILE_VALIDATED",
            "severity": "INFO",
            "description": "A generic structurally validated object.",
            "evidence_path": "/evidence/object.bin",
            "metadata": {"deterministic_validation": True, "file_sha256": "c" * 64},
        }],
        "statistics": {
            "module_statistics": {"objects_examined": 7},
            "canonical_result": {"accepted_records": 1},
        },
    }), encoding="utf-8")

    loaded = _load_generic_module_result(result_path, logging.getLogger("test"))
    assert loaded is not None
    assert loaded.artefacts_examined == 7
    assert loaded.findings[0].finding_type == "CARVED_FILE_VALIDATED"
    assert loaded.findings[0].metadata["deterministic_validation"] is True


def test_synthesis_payload_preserves_structural_finding_fields():
    from datetime import datetime, timezone
    from core.report_generator import build_synthesis_payload
    from core.report_sections import FindingItem, FindingSeverity, ModuleResult

    result = ModuleResult(
        module_name="steganography_detector",
        module_version="1.0",
        run_timestamp=datetime.now(timezone.utc),
        status="success",
        findings=[FindingItem(
            finding_id="F-typed",
            title="Payload decoded",
            description="A self-terminating payload was deterministically decoded.",
            severity=FindingSeverity.MEDIUM,
            category="Steganography",
            artefact_location="/evidence/image.bmp",
            finding_type="STEGANOGRAPHIC_PAYLOAD_DECODED",
            metadata={"decoded_payload_sha256": "d" * 64},
        )],
        artefacts_examined=1,
        artefacts_relevant=1,
    )
    payload = build_synthesis_payload({}, [result])
    assert payload["findings"][0]["finding_type"] == "STEGANOGRAPHIC_PAYLOAD_DECODED"
    assert payload["findings"][0]["metadata"]["decoded_payload_sha256"] == "d" * 64
    assert any(row["theme"] == "steganography_confirmed" for row in payload["material_findings"])
