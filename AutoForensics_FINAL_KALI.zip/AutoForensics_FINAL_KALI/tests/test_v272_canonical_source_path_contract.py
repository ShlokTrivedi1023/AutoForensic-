from __future__ import annotations

import json
from pathlib import Path

from core.evidence_ledger import load_candidate_records
from core.module_completion import certify_module_result
from modules._base import Finding, ModuleResult, ModuleStatus, Severity


def _finding(path: str, finding_id: str = "F-1") -> Finding:
    return Finding(
        finding_id=finding_id,
        finding_type="DETERMINISTIC_TEST",
        severity=Severity.INFO,
        description="Synthetic case-neutral deterministic record",
        evidence_path=path,
        artifact_path=None,
        metadata={
            "provenance_source_path": path,
            "file_sha256": "a" * 64,
            "semantic_object_id": finding_id,
        },
        timestamp="2026-01-01T00:00:00+00:00",
    )


def _ledger(path: Path) -> None:
    path.write_text(json.dumps({
        "module": "suspicious_file_detector",
        "ledger_counts": {
            "ACCEPTED": 0, "CANDIDATE": 1, "REJECTED": 1, "UNRESOLVED": 0,
        },
        "candidates": [
            {
                "finding_type": "ENTROPY_CANDIDATE",
                "description": "Candidate retained for review",
                "evidence_path": "/evidence/candidate.bin",
                "ledger_state": "CANDIDATE",
                "metadata": {
                    "ledger_state": "CANDIDATE",
                    "provenance_source_path": "/evidence/candidate.bin",
                },
            },
            {
                "finding_type": "REJECTED_STRUCTURE",
                "description": "Structurally rejected observation",
                "evidence_path": "/evidence/rejected.bin",
                "ledger_state": "REJECTED",
                "metadata": {
                    "ledger_state": "REJECTED",
                    "provenance_source_path": "/evidence/rejected.bin",
                },
            },
        ],
    }), encoding="utf-8")


def test_completion_certificate_uses_the_same_retained_ledger_as_h2(tmp_path: Path):
    ledger = tmp_path / "candidate_observations.json"
    _ledger(ledger)
    result = ModuleResult(
        module_name="suspicious_file_detector",
        case_id="CASE-NEUTRAL",
        status=ModuleStatus.COMPLETED,
        findings=[_finding("/evidence/accepted.bin")],
        statistics={
            "deterministic_reconciliation": {
                "candidate_observations": 1,
                "rejected_observations": 1,
                "unresolved_observations": 0,
                "ledger_counts": {
                    "ACCEPTED": 0, "CANDIDATE": 1, "REJECTED": 1, "UNRESOLVED": 0,
                },
                "candidate_file": str(ledger),
            },
        },
    )
    certified = certify_module_result(
        result,
        module_name="suspicious_file_detector",
        config={
            "analysis_path": str(tmp_path / "evidence.raw"),
            "_working_set": {"evidence_inventory": {}},
        },
    )
    certificate = certified.statistics["completion_certificate"]
    assert certificate["canonical_counts"]["source_paths"] == 3
    assert certified.statistics["canonical_counts"]["source_paths"] == 3
    assert certificate["candidate_ledger"]["loaded_records"] == 2
    assert certificate["candidate_ledger"]["state_counts"] == {
        "ACCEPTED": 0, "CANDIDATE": 1, "REJECTED": 1, "UNRESOLVED": 0,
    }

    records, states, error = load_candidate_records(
        "suspicious_file_detector", ledger
    )
    assert error is None
    assert len(records) == 2
    assert states["CANDIDATE"] == 1
    assert states["REJECTED"] == 1


def test_missing_declared_candidate_ledger_fails_closed(tmp_path: Path):
    missing = tmp_path / "missing.json"
    result = ModuleResult(
        module_name="suspicious_file_detector",
        case_id="CASE-NEUTRAL",
        status=ModuleStatus.COMPLETED,
        findings=[_finding("/evidence/accepted.bin")],
        statistics={
            "deterministic_reconciliation": {
                "candidate_observations": 1,
                "rejected_observations": 0,
                "unresolved_observations": 0,
                "ledger_counts": {
                    "ACCEPTED": 0, "CANDIDATE": 1, "REJECTED": 0, "UNRESOLVED": 0,
                },
                "candidate_file": str(missing),
            },
        },
    )
    certified = certify_module_result(
        result,
        module_name="suspicious_file_detector",
        config={
            "analysis_path": str(tmp_path / "evidence.raw"),
            "_working_set": {"evidence_inventory": {}},
        },
    )
    assert certified.status == ModuleStatus.INCOMPLETE
    reasons = certified.statistics["completion_certificate"]["reasons"]
    assert any("Canonical candidate ledger unavailable" in reason for reason in reasons)
