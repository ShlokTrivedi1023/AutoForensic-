from __future__ import annotations
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from core.fact_classification import duplicate_identity
from core.main import _strict_status_counts
from core.module_completion import _coverage
from modules._base import ModuleResult, ModuleStatus, Severity, make_finding
from modules.timeline_builder import _normalise_timestamp_value, _build_examiner_timeline


def _result(stats):
    return ModuleResult(module_name="generic", case_id="CASE", status=ModuleStatus.COMPLETED, findings=[], statistics=stats)


def test_same_unit_coverage_does_not_compare_roots_to_files(tmp_path):
    result=_result({"files_hashed":77,"raw_observations":1})
    cov=_coverage(result,{"input_domain":"all_files"},{"_working_set":{"primary_evidence_roots":[str(tmp_path)]}})
    assert cov["source_objects_discovered"]==cov["source_objects_processed"]==1
    assert cov["supported_objects_discovered"]==cov["supported_objects_processed"]==77
    assert cov["record_accounting_asserted"] is False


def test_distinct_hash_algorithms_are_not_duplicates():
    common={"file_path":"/evidence/a.bin","byte_offset":0,"deterministic_validation":True}
    a=make_finding("HASH_CONFIRMED",Severity.INFO,"md5","/evidence/a.bin",{**common,"algorithm":"MD5","computed_hash":"aa"})
    b=make_finding("HASH_CONFIRMED",Severity.INFO,"sha1","/evidence/a.bin",{**common,"algorithm":"SHA-1","computed_hash":"bb"})
    assert duplicate_identity("evidence_validator",a)!=duplicate_identity("evidence_validator",b)


def test_numeric_string_epochs_are_normalised():
    assert _normalise_timestamp_value("timestamp","1785240000",Path("android/chat.db")).startswith("2026-07-28T12:00:00")
    assert _normalise_timestamp_value("date","1785240000000",Path("android/mmssms.db")).startswith("2026-07-28T12:00:00")
    assert _normalise_timestamp_value("date","807278400000000000",Path("ios/sms.db")).startswith("2026-08-01T12:00:00")


def test_dns_aliases_consolidate():
    base={"timestamp":"2026-01-01T00:00:00+00:00","semantic_object":"example.invalid","details":"DNS query example.invalid","severity":"INFO","source_artifact":"x.pcap","source_locator":"frame=1"}
    rows=_build_examiner_timeline([
        {**base,"event_type":"DNS_QUERY","responsible_module":"dns_analyzer"},
        {**base,"event_type":"DNS_REQUEST","responsible_module":"network_protocol_decoder"},
    ])
    assert len(rows)==1
    assert rows[0]["event_type"] == "DNS_QUERY"
    assert rows[0]["consolidated_event_count"]==1


def test_strict_status_counts_never_say_zero_after_terminal_results():
    counts=_strict_status_counts([{"status":"PASS_COMPLETE"},{"status":"INCOMPLETE"},{"status":"NOT_APPLICABLE"}])
    assert counts["executed"]==3
    assert counts["completed"]==1
    assert counts["incomplete"]==1
    assert counts["zero_modules_executed"] is False


def test_filesystem_summary_does_not_inflate_deleted_count():
    from core.report_ai import _material_theme
    summary = {"title": "FAT32 structural validation", "category": "filesystem", "detail": "Filesystem parsed; deleted files=4"}
    deleted = {"title": "Deleted file recovered", "category": "deleted record", "detail": "/docs/a.txt"}
    assert _material_theme("filesystem_analyzer", summary) != "deleted"
    assert _material_theme("deleted_file_recovery", deleted) == "deleted"
