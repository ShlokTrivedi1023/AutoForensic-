from argparse import Namespace
from pathlib import Path

import pytest

from core.case_config import CaseConfig, EvidenceItem, ExaminerInfo
from core.main import ForensicOrchestrator, _build_parser


def test_parser_accepts_prompt_evidence_source():
    ns = _build_parser().parse_args(["--prompt-evidence-source"])
    assert ns.prompt_evidence_source is True


def test_prompt_flag_conflicts_with_direct_device(tmp_path: Path):
    orch = ForensicOrchestrator(tmp_path)
    orch._investigator = {"id": "x", "name": "X", "badge": "1", "role": "Examiner"}
    orch._case_config = CaseConfig(
        case_number="C1",
        case_title="Case",
        examiner=ExaminerInfo(name="X"),
        investigation_profile="full",
        evidence_items=[EvidenceItem(label="USB", path="/dev/null")],
    )
    args = Namespace(
        case_id=None, profile=None, device="/dev/null", image_path=None,
        prompt_evidence_source=True, output_dir=str(tmp_path / "out"),
        evidence_type="auto",
    )
    with pytest.raises(ValueError, match="cannot be combined"):
        orch.intake_case(args)


def test_prompt_flag_ignores_case_config_path_and_uses_menu(tmp_path: Path, monkeypatch):
    source = tmp_path / "chosen.E01"
    source.write_bytes(b"evidence")
    stale = tmp_path / "stale.E01"
    stale.write_bytes(b"stale")

    orch = ForensicOrchestrator(tmp_path)
    orch._investigator = {"id": "x", "name": "X", "badge": "1", "role": "Examiner"}
    orch._case_config = CaseConfig(
        case_number="C1",
        case_title="Case",
        examiner=ExaminerInfo(name="X"),
        investigation_profile="full",
        evidence_items=[EvidenceItem(label="Old", path=str(stale))],
    )
    monkeypatch.setattr(orch, "_prompt_evidence_source", lambda: (None, str(source)))
    monkeypatch.setattr(orch, "_require_confirmation", lambda: None)
    monkeypatch.setattr(
        "core.administrative_attachments.ingest_administrative_attachments",
        lambda *a, **k: {"administratively_complete": True, "errors": [], "missing": []},
    )
    args = Namespace(
        case_id=None, profile=None, device=None, image_path=None,
        prompt_evidence_source=True, output_dir=str(tmp_path / "out"),
        evidence_type="auto",
    )
    orch.intake_case(args)
    assert orch._evidence_source == "existing_image"
    assert orch._image_path == source.resolve()
    assert orch._config_evidence_paths == []
