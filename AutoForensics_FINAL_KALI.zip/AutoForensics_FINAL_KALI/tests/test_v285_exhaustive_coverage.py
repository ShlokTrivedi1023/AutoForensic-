from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path


def _zip_bytes(*names: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for index, name in enumerate(names):
            zf.writestr(name, (f"record-{index}-" * 50).encode())
    return buf.getvalue()


def test_zip_complete_members_are_not_recarved_and_partial_header_is_retained(tmp_path: Path):
    from core.native_carving import DEFAULT_SPECS, carve_signatures

    complete = _zip_bytes("one.txt", "two.txt", "three.txt")
    # A plausible standalone local header with no EOCD/central directory.
    name = b"orphan.txt"
    partial = (
        b"PK\x03\x04"
        + (20).to_bytes(2, "little")  # version needed
        + (0).to_bytes(2, "little")   # flags
        + (0).to_bytes(2, "little")   # stored
        + b"\x00" * 16
        + len(name).to_bytes(2, "little")
        + (0).to_bytes(2, "little")
        + name
    )
    source = tmp_path / "media.bin"
    source.write_bytes(b"A" * 4096 + complete + b"B" * 4096 + partial + b"C" * 4096)
    specs = tuple(s for s in DEFAULT_SPECS if s.name == "zip")
    results = carve_signatures(source, tmp_path / "carved", specs=specs, max_candidates=0)

    accepted = [r for r in results if r.validation_state == "ACCEPTED"]
    candidates = [r for r in results if r.validation_state == "CANDIDATE"]
    assert len(accepted) == 1
    assert accepted[0].offset_bytes == 4096
    assert accepted[0].payload_validated is True
    # Three internal local headers belong to the accepted archive and therefore
    # must not become three additional pseudo-ZIPs.
    assert complete.count(b"PK\x03\x04") == 3
    assert len(candidates) == 1
    assert candidates[0].file_type == "zip_partial"
    assert candidates[0].offset_bytes == 4096 + len(complete) + 4096


def test_corrupt_complete_zip_is_rejected_not_accepted(tmp_path: Path):
    from core.native_carving import DEFAULT_SPECS, carve_signatures

    payload = bytearray(_zip_bytes("evidence.txt"))
    name_len = int.from_bytes(payload[26:28], "little")
    extra_len = int.from_bytes(payload[28:30], "little")
    compressed_size = int.from_bytes(payload[18:22], "little")
    payload_start = 30 + name_len + extra_len
    payload[payload_start + max(1, compressed_size // 2)] ^= 0x40

    source = tmp_path / "corrupt.bin"
    source.write_bytes(bytes(payload))
    specs = tuple(s for s in DEFAULT_SPECS if s.name == "zip")
    results = carve_signatures(source, tmp_path / "carved", specs=specs, max_candidates=0)
    assert len(results) == 1
    assert results[0].validation_state == "REJECTED"
    assert results[0].payload_validated is False


def test_zero_document_limit_means_all_unique_documents(tmp_path: Path):
    from modules.document_analyzer import _find_files_from_candidates

    paths = []
    for i in range(5):
        p = tmp_path / f"doc{i}.txt"
        p.write_text(f"unique-{i}", encoding="utf-8")
        paths.append(p)
    found = _find_files_from_candidates(paths, frozenset({".txt"}), 0)
    assert len(found) == 5


def test_evidence_inventory_accounts_for_alias_paths(tmp_path: Path):
    from core.evidence_inventory import build_inventory

    (tmp_path / "a.txt").write_text("same", encoding="utf-8")
    (tmp_path / "b.txt").write_text("same", encoding="utf-8")
    (tmp_path / "c.txt").write_text("different", encoding="utf-8")
    inv = build_inventory([tmp_path])
    assert inv["coverage"]["coverage_complete"] is True
    assert inv["coverage"]["paths_discovered"] == 3
    assert inv["object_count"] == 3
    aliases = inv["alias_groups"]
    assert len(aliases) == 1
    assert len(aliases[0]["aliases"]) == 1


def test_memory_marker_default_scans_beyond_explicit_small_cap(tmp_path: Path):
    from core.deterministic_memory import extract_structured_memory_markers

    source = tmp_path / "memory.raw"
    marker = b"PROCESS pid=42 ppid=1 name=proc.exe state=running"
    source.write_bytes(b"X" * 4096 + b"\x00" + marker + b"\x00")

    limited = extract_structured_memory_markers(source, max_bytes=1024)
    assert limited["coverage_complete"] is False
    assert limited["record_count"] == 0

    complete = extract_structured_memory_markers(source)
    assert complete["coverage_complete"] is True
    assert complete["record_count"] == 1
    assert complete["records"][0]["pid"] == 42


def test_john_zero_hash_cap_means_unlimited(tmp_path: Path):
    from modules.john_recovery import _collect_hashes_from_json

    values = [
        "$1$" + "a" * 40,
        "$6$" + "b" * 32,
        "$2b$12$" + "c" * 53,
    ]
    (tmp_path / "records.json").write_text(json.dumps({"hashes": values}), encoding="utf-8")
    found = _collect_hashes_from_json([tmp_path], 0)
    assert {value for _, value in found} == set(values)


def test_exhaustive_defaults_are_zero():
    import inspect
    import core.evidence_inventory as inventory
    import core.structured_records as records
    from core.native_carving import carve_signatures
    from core.native_filesystem import FatVolume, analyze_and_extract

    assert inventory._MAX_FILES == 0
    assert inventory._MAX_ARCHIVE_NAMES == 0
    assert records._MAX_RECORDS == 0
    assert inspect.signature(carve_signatures).parameters["max_candidates"].default == 0
    assert inspect.signature(analyze_and_extract).parameters["max_files"].default == 0
    assert inspect.signature(analyze_and_extract).parameters["max_extract_bytes"].default == 0
    assert inspect.signature(FatVolume.list_files).parameters["max_entries"].default == 0


def test_filesystem_deep_retains_directory_and_file_records(monkeypatch, tmp_path: Path):
    import logging
    import modules.filesystem_deep_analyzer as fsdeep

    stdout = (
        "d/d 5:\tUsers/\t2026-01-01T00:00:00\t2026-01-01T00:00:00\t"
        "2026-01-01T00:00:00\t2026-01-01T00:00:00\n"
        "r/r 6:\tUsers/photo.jpg\t2026-01-02T00:00:00\t2026-01-02T00:00:00\t"
        "2026-01-02T00:00:00\t2026-01-02T00:00:00\n"
    )

    monkeypatch.setattr(
        fsdeep,
        "_run_subprocess",
        lambda *args, **kwargs: (0, stdout, ""),
    )
    entries, raw = fsdeep._run_fls_full(
        tmp_path / "evidence.img", logging.getLogger("test"), []
    )

    assert raw == stdout
    assert len(entries) == 2
    directory, regular = entries
    assert directory["type"] == "directory"
    assert directory["path"] == "Users"
    assert directory["ext"] == ""
    assert regular["type"] == "file"
    assert regular["path"] == "Users/photo.jpg"
    assert regular["ext"] == "jpg"


def test_browser_index_dat_parser_retains_more_than_200_urls(tmp_path: Path):
    import logging
    from modules.browser_history_analyzer import _parse_index_dat

    path = tmp_path / "index.dat"
    urls = [f"http://example{i:03d}.test/path" for i in range(250)]
    path.write_bytes(b"\x00".join(url.encode("ascii") for url in urls))

    results = _parse_index_dat(path, logging.getLogger("test"))
    assert len(results) == 250
    assert {row["url"] for row in results} == set(urls)


def test_keyword_zero_hit_cap_retains_more_than_100_hits(tmp_path: Path):
    import logging
    from modules.keyword_search import _grep_text_file

    path = tmp_path / "keywords.txt"
    path.write_text("".join(f"needle hit {i}\n" for i in range(250)), encoding="utf-8")

    hits = _grep_text_file(
        path,
        "needle",
        False,
        0,
        0,
        logging.getLogger("test"),
    )
    assert len(hits) == 250
    assert hits[0]["line_number"] == 1
    assert hits[-1]["line_number"] == 250


def test_mbox_parser_processes_more_than_500_messages(tmp_path: Path):
    import logging
    import mailbox
    from email.message import EmailMessage
    from modules.email_communications_analyzer import _parse_mbox

    path = tmp_path / "mailbox.mbox"
    box = mailbox.mbox(str(path), create=True)
    try:
        for i in range(525):
            msg = EmailMessage()
            msg["From"] = f"sender{i}@example.test"
            msg["To"] = "receiver@example.test"
            msg["Subject"] = f"subject-{i}"
            msg.set_content(f"body-{i}")
            box.add(msg)
        box.flush()
    finally:
        box.close()

    parsed = _parse_mbox(path, logging.getLogger("test"))
    assert parsed["message_count"] == 525
    assert len(parsed["messages"]) == 525
    assert parsed["messages"][-1]["subject"] == "subject-524"


def test_native_nonzip_carver_does_not_issue_max_window_read_per_hit(monkeypatch, tmp_path: Path):
    import core.native_carving as carving

    source = tmp_path / "media.bin"
    # 300 small JPEG-shaped objects.  The old implementation requested 64 MiB
    # for every SOI hit; the repaired implementation should request bounded
    # chunks and stop after the nearby EOI.
    obj = b"\xff\xd8\xff" + (b"A" * 1021) + b"\xff\xd9"
    source.write_bytes((b"P" * 128) + ((obj + b"Q" * 64) * 300))

    original_open = carving.open_evidence_stream
    requested: list[int] = []

    class TrackingStream:
        def __init__(self, wrapped):
            self._wrapped = wrapped
            self.media_size = getattr(wrapped, "media_size", source.stat().st_size)
        def __enter__(self):
            self._wrapped.__enter__()
            return self
        def __exit__(self, *args):
            return self._wrapped.__exit__(*args)
        def read(self, size=-1):
            requested.append(int(size))
            return self._wrapped.read(size)
        def seek(self, *args):
            return self._wrapped.seek(*args)

    def tracked_open(path):
        return TrackingStream(original_open(path))

    monkeypatch.setattr(carving, "open_evidence_stream", tracked_open)
    jpeg = tuple(s for s in carving.DEFAULT_SPECS if s.name == "jpeg")
    results = carving.carve_signatures(source, tmp_path / "carved", specs=jpeg, max_candidates=0)

    assert len(results) == 300
    assert all(r.validation_state == "ACCEPTED" for r in results)
    # Crucial regression: never request the 64 MiB JPEG max window per hit.
    assert max(requested) <= 8 * 1024 * 1024


def test_native_nonzip_carver_retains_fragment_candidate_without_huge_copy(tmp_path: Path):
    from core.native_carving import DEFAULT_SPECS, carve_signatures

    source = tmp_path / "fragment.bin"
    source.write_bytes(b"X" * 1024 + b"%PDF-1.7\nfragment-without-eof" + b"Y" * 4096)
    pdf = tuple(s for s in DEFAULT_SPECS if s.name == "pdf")
    results = carve_signatures(source, tmp_path / "carved", specs=pdf, max_candidates=0)

    assert len(results) == 1
    assert results[0].validation_state == "CANDIDATE"
    assert results[0].output_path == ""
    assert results[0].size_bytes == len(b"%PDF-")
