from pathlib import Path
import json


def test_report_audit_execution_vocabulary_is_semantically_compatible():
    from tools.report_output_audit import _failures_for_json
    report = {
        "report_metadata": {},
        "sections": [
            {"section_title": "Analysis: X", "blocks": [{"type": "table", "data": {
                "headers": ["Module", "Execution Outcome", "Status", "Evidence Assurance", "Examined", "Findings / Reason"],
                "rows": [["Evidence Integrity Validator", "RAN FOUND X", "SUCCESS", "PRESENT", "1 object processed", "1"]],
            }}]},
            {"section_title": "Examination Coverage", "blocks": [{"type": "table", "data": {
                "headers": ["Module", "Status", "Execution Status", "Canonical Findings", "Candidates", "Assurance", "Reason / Summary"],
                "rows": [["Evidence Integrity Validator", "PASS_COMPLETE", "EXECUTION_COMPLETE", "1", "0", "PRESENT", "ok"]],
            }}]},
        ],
    }
    failures, _ = _failures_for_json(report, require_llm=False)
    assert not any("execution status contradicts" in item for item in failures)


def test_fls_tab_parser_keeps_filename_separate(monkeypatch, tmp_path):
    from modules import filesystem_deep_analyzer as mod
    sample = "r/r 6061:\tEvidence/holiday.jpg.scr\t2026-07-28 12:00:00 (UTC)\t2026-07-28 12:00:00 (UTC)\t2026-07-28 12:00:00 (UTC)\t2026-07-28 12:00:00 (UTC)\t55\t0\t0\n"
    monkeypatch.setattr(mod, "_run_subprocess", lambda *a, **k: (0, sample, ""))
    rows, _ = mod._run_fls_full(tmp_path/"x.raw", type("L", (), {"debug":lambda *a,**k:None})(), [], 0, "fat")
    assert rows[0]["path"] == "Evidence/holiday.jpg.scr"
    assert mod._detect_extension_mismatches(rows)[0]["name"] == "holiday.jpg.scr"


def test_scalpel_loads_sibling_foremost_hashes(tmp_path):
    from modules.scalpel_carver import _load_foremost_hashes
    scalpel = tmp_path/"scalpel_carver"; scalpel.mkdir()
    foremost = tmp_path/"foremost_carver"; foremost.mkdir()
    (foremost/"foremost_manifest.json").write_text(json.dumps({"files":[{"sha256":"a"*64}]}))
    assert _load_foremost_hashes(scalpel) == {"a"*64}


def test_ai_policy_defaults_to_deterministic_without_key(monkeypatch):
    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    from core.ai_policy import configured_provider
    assert configured_provider() == "deterministic"
