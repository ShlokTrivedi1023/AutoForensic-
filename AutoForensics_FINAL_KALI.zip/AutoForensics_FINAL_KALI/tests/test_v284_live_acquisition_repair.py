from __future__ import annotations

import struct
from pathlib import Path

from core import native_evidence
from core.acquisition import _extract_calculated_digest
from core.native_evidence import EwfSection, _build_chunk_map


def _table_payload(base_offset: int, entries: tuple[int, ...]) -> bytes:
    data = bytearray(24 + len(entries) * 4)
    struct.pack_into('<I', data, 0, len(entries))
    struct.pack_into('<Q', data, 8, base_offset)
    struct.pack_into(f'<{len(entries)}I', data, 24, *entries)
    return bytes(data)


def test_repeated_relative_table_patterns_with_different_bases_are_not_deduplicated(
    tmp_path: Path, monkeypatch
):
    """Regression for the large mostly-empty E01 failure seen in v2.8.3.

    Distinct EWF tables can legitimately have identical relative entry arrays
    when chunks compress to repeated sizes. Their base offsets distinguish the
    tables. Deduplicating only by raw entries silently truncated the chunk map.
    """
    seg = tmp_path / 'large.E01'
    seg.write_bytes(b'\x00' * 5000)

    table1 = EwfSection(
        segment_path=seg, segment_number=1, section_type='table',
        offset=1300, next_offset=1376, size=76, data_offset=1376,
        data_size=32,
    )
    table2 = EwfSection(
        segment_path=seg, segment_number=1, section_type='table',
        offset=2300, next_offset=2376, size=76, data_offset=2376,
        data_size=32,
    )
    payloads = {
        1300: _table_payload(1000, (100, 200)),
        2300: _table_payload(2000, (100, 200)),
    }
    monkeypatch.setattr(
        native_evidence,
        '_read_section_data',
        lambda section: payloads[section.offset],
    )

    chunks = _build_chunk_map(
        [table1, table2], nominal_chunk_size=32768,
        media_size=4 * 32768, warnings=[],
    )
    assert len(chunks) == 4
    assert [(c.start, c.end) for c in chunks] == [
        (1100, 1200), (1200, 1376), (2100, 2200), (2200, 2376)
    ]


def test_libewf_sha256_parser_accepts_current_output_spelling():
    digest = 'a' * 64
    text = f'SHA256 hash calculated over data:\t\t{digest}\n'
    assert _extract_calculated_digest(text, 'sha256') == digest


def test_libewf_sha256_parser_accepts_hyphenated_output_spelling():
    digest = 'B' * 64
    text = f'SHA-256 hash calculated over data: {digest}\n'
    assert _extract_calculated_digest(text, 'sha256') == digest.lower()


def test_e01_stream_hash_mode_uses_acquisition_digest_without_separate_source_posthash(
    tmp_path: Path, monkeypatch
):
    import hashlib
    import os
    from core.acquisition import DeviceInfo, acquire_device, prepare_write_protection

    bindir = tmp_path / 'bin'
    bindir.mkdir()
    ewfacquire = bindir / 'ewfacquire'
    ewfacquire.write_text(
        """#!/usr/bin/env python3
import hashlib, pathlib, shutil, sys
if '--version' in sys.argv or '-V' in sys.argv or '-h' in sys.argv:
    print('ewfacquire fake-1.0'); raise SystemExit(0)
args=sys.argv[1:]
target=pathlib.Path(args[args.index('-t')+1])
log=pathlib.Path(args[args.index('-l')+1])
source=pathlib.Path(args[-1])
data=source.read_bytes(); digest=hashlib.sha256(data).hexdigest()
pathlib.Path(str(target)+'.E01').write_bytes(data)
log.write_text(f'SHA256 hash calculated over data:\\t\\t{digest}\\nWritten: {len(data)} bytes\\n')
"""
    )
    ewfverify = bindir / 'ewfverify'
    ewfverify.write_text(
        """#!/usr/bin/env python3
import hashlib, pathlib, sys
if '--version' in sys.argv or '-V' in sys.argv or '-h' in sys.argv:
    print('ewfverify fake-1.0'); raise SystemExit(0)
args=sys.argv[1:]
log=pathlib.Path(args[args.index('-l')+1])
image=pathlib.Path(args[-1]); data=image.read_bytes(); digest=hashlib.sha256(data).hexdigest()
log.write_text(f'Verify completed\\nRead: 1 KiB ({len(data)} bytes)\\nSHA256 hash calculated over data:\\t\\t{digest}\\newfverify: SUCCESS\\n')
"""
    )
    ewfacquire.chmod(0o755); ewfverify.chmod(0o755)
    monkeypatch.setenv('PATH', str(bindir) + os.pathsep + os.environ.get('PATH', ''))
    monkeypatch.setenv('AUTOFORENSICS_SOURCE_HASH_MODE', 'stream')

    source = tmp_path / 'source.bin'
    source.write_bytes(b'live acquisition regression data' * 100)
    dev = DeviceInfo(
        path=str(source.resolve()), name=source.name, kname=source.name,
        device_type='test-file', read_only=True, size_bytes=source.stat().st_size,
        model='CONTROLLED REGRESSION FILE', serial='RANDOM', transport='file',
    )
    protection = prepare_write_protection(dev, allow_regular_file_test=True)
    record = acquire_device(
        source=dev, output_dir=tmp_path/'out', case_id='GENERIC', evidence_id='EV-1',
        investigator='Examiner', acquisition_format='e01',
        write_protection=protection, allow_regular_file_test=True,
    )
    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    assert record.acquisition_verified is True
    assert record.source_pre_acquisition_sha256 == expected
    assert record.acquired_content_sha256 == expected
    assert record.source_pre_vs_acquired == 'MATCH'
    assert record.source_post_acquisition_sha256 == ''
    assert record.source_pre_vs_source_post == 'NOT_RUN_STREAM_MODE'
    assert 'ewfacquire acquisition-stream' in record.source_pre_hash_basis
    assert Path(record.acquisition_log_path).is_file()
    assert Path(record.verification_log_path).is_file()
