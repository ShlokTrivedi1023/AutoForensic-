from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


def test_create_final_case_preserves_optional_administrative_people(tmp_path: Path) -> None:
    evidence = tmp_path / "sample.img"
    evidence.write_bytes(b"generic-test-evidence")
    case_file = tmp_path / "case.json"
    registry = tmp_path / "investigators.json"
    env = os.environ.copy()
    env.update({
        "HOME": str(tmp_path / "home"),
        "AUTOFORENSICS_INVESTIGATOR_PASSWORD": "CorrectHorseBatteryStaple!",
        "AUTOFORENSICS_INVESTIGATORS_REGISTRY": str(registry),
    })
    command = [
        sys.executable, "tools/create_final_case.py",
        "--evidence", str(evidence),
        "--case-id", "GENERIC-CASE",
        "--case-file", str(case_file),
        "--investigator-id", "examiner-generic",
        "--investigator-name", "Examiner Name",
        "--jurisdiction", "Example jurisdiction",
        "--authorising-officer", "Authorising Person",
        "--authorising-title", "Authorising Role",
        "--authorising-organisation", "Authority Organisation",
        "--supervising-examiner", "Supervisor Name",
        "--supervising-organisation", "Supervising Organisation",
        "--client-representative", "Client Contact",
        "--client-organisation", "Client Organisation",
    ]
    subprocess.run(command, cwd=Path(__file__).resolve().parents[1], env=env, check=True, capture_output=True, text=True)
    case = json.loads(case_file.read_text(encoding="utf-8"))
    assert case["schema_version"] == "1.3"
    assert case["jurisdiction"] == "Example jurisdiction"
    assert case["authorising_officer"]["name"] == "Authorising Person"
    assert case["authorising_officer"]["title"] == "Authorising Role"
    assert case["supervising_examiner"]["name"] == "Supervisor Name"
    assert case["client_representative"]["name"] == "Client Contact"
