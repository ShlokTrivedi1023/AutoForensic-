"""Module-level timeout and atomic result persistence.

The orchestrator runs each module in its own output directory.  On POSIX, a
real-time interval timer interrupts a module that exceeds its declared budget.
Every result is written with fsync + os.replace so an interrupted process cannot
leave a half-written canonical JSON file.
"""
from __future__ import annotations
import json, os, signal, threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

class ModuleTimeoutError(TimeoutError):
    pass

@contextmanager
def module_timeout(seconds: float, module_name: str) -> Iterator[None]:
    seconds=float(seconds or 0)
    if seconds <= 0 or os.name != "posix" or threading.current_thread() is not threading.main_thread():
        yield; return
    previous_handler=signal.getsignal(signal.SIGALRM)
    previous_timer=signal.getitimer(signal.ITIMER_REAL)
    def _handler(signum, frame):
        raise ModuleTimeoutError(f"Module '{module_name}' exceeded timeout of {seconds:.1f} seconds")
    signal.signal(signal.SIGALRM, _handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)
        if previous_timer[0] > 0:
            signal.setitimer(signal.ITIMER_REAL, *previous_timer)

def atomic_write_json(path: Path, payload: Any) -> None:
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+f".tmp.{os.getpid()}")
    data=json.dumps(payload, indent=2, ensure_ascii=True, default=str)+"\n"
    with tmp.open("w", encoding="utf-8") as fh:
        fh.write(data); fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp, path)

def atomic_write_text(path: Path, text: str) -> None:
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+f".tmp.{os.getpid()}")
    with tmp.open("w", encoding="utf-8") as fh:
        fh.write(text); fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp, path)
