"""Forensically safe attached-device discovery, acquisition and integrity verification.

The implementation is deliberately fail-closed:
* a source device is never auto-selected;
* the system/project/output device is rejected;
* mounted source partitions are unmounted before imaging;
* software read-only protection is verified with kernel/ioctl state;
* no destructive write test is performed against evidence;
* source, acquired-content, container-set, pre-analysis and post-analysis hashes
  are recorded as different objects and are never conflated.

A regular file may be used only when ``allow_regular_file_test=True``.  That mode
exists for controlled regression tests and is never described as physical-device
acquisition.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Optional
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile


class AcquisitionError(RuntimeError):
    """Fail-closed acquisition error."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


@dataclass
class CommandRecord:
    command: list[str]
    started_at: str
    completed_at: str
    returncode: int
    stdout: str = ""
    stderr: str = ""


@dataclass
class DeviceInfo:
    path: str
    name: str = ""
    kname: str = ""
    device_type: str = ""
    read_only: bool = False
    removable: bool = False
    size_bytes: int = 0
    vendor: str = ""
    model: str = ""
    serial: str = ""
    firmware_revision: str = ""
    transport: str = ""
    logical_sector_size: int = 0
    physical_sector_size: int = 0
    partition_table: str = ""
    filesystem_type: str = ""
    wwn: str = ""
    parent_name: str = ""
    mountpoints: list[str] = field(default_factory=list)
    partitions: list[dict[str, Any]] = field(default_factory=list)
    is_system_disk: bool = False
    is_output_disk: bool = False
    is_project_disk: bool = False
    discovery_time: str = field(default_factory=utc_now)
    exclusion_reasons: list[str] = field(default_factory=list)

    @property
    def eligible(self) -> bool:
        return (
            self.device_type == "disk"
            and not self.is_system_disk
            and not self.is_output_disk
            and not self.is_project_disk
            and not self.mountpoints
            and not self.exclusion_reasons
        )


@dataclass
class WriteProtectionRecord:
    source_device: str
    requested_method: str
    effective_method: str
    hardware_blocker: dict[str, str]
    unmounted_paths: list[str]
    commands: list[CommandRecord]
    sysfs_read_only: Optional[bool]
    ioctl_read_only: Optional[bool]
    partitions_read_only: bool
    no_mounted_partitions: bool
    verified: bool
    verification_method: str
    limitations: list[str]
    verified_at: str = field(default_factory=utc_now)


@dataclass
class SegmentHash:
    path: str
    order: int
    size_bytes: int
    sha256: str


@dataclass
class AcquisitionRecord:
    schema: str
    case_id: str
    evidence_id: str
    investigator: str
    source: DeviceInfo
    write_protection: WriteProtectionRecord
    acquisition_format: str
    acquisition_tool: str
    acquisition_tool_version: str
    acquisition_command: list[str]
    acquisition_started_at: str
    acquisition_completed_at: str
    image_path: str
    image_segments: list[SegmentHash]
    read_error_log: str
    bad_sector_count: Optional[int]
    source_pre_acquisition_sha256: str
    source_post_acquisition_sha256: str
    acquired_content_sha256: str
    source_pre_vs_acquired: str
    source_pre_vs_source_post: str
    container_set_sha256_pre_analysis: str
    logical_media_sha256_pre_analysis: str
    source_pre_hash_basis: str = "separate pre-acquisition device read"
    source_post_hash_basis: str = "separate post-acquisition device read"
    acquisition_log_path: str = ""
    verification_log_path: str = ""
    container_set_sha256_post_analysis: str = ""
    logical_media_sha256_post_analysis: str = ""
    pre_vs_post_container_set: str = "NOT_RUN"
    pre_vs_post_logical_media: str = "NOT_RUN"
    acquisition_verified: bool = False
    analysis_integrity_verified: bool = False
    status: str = "ACQUIRED_PENDING_POST_ANALYSIS_VERIFICATION"
    limitations: list[str] = field(default_factory=list)
    commands: list[CommandRecord] = field(default_factory=list)
    manifest_path: str = ""


def _clean_output(text: str, limit: int = 12000) -> str:
    text = text or ""
    return text[-limit:]


def run_command(
    command: list[str], *, timeout: Optional[int] = 60, check: bool = False,
    input_text: Optional[str] = None,
) -> tuple[subprocess.CompletedProcess[str], CommandRecord]:
    started = utc_now()
    cp = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
        input=input_text,
    )
    record = CommandRecord(
        command=list(command), started_at=started, completed_at=utc_now(),
        returncode=cp.returncode, stdout=_clean_output(cp.stdout), stderr=_clean_output(cp.stderr),
    )
    if check and cp.returncode != 0:
        raise AcquisitionError(
            f"Command failed ({cp.returncode}): {' '.join(command)}\n"
            f"{_clean_output(cp.stderr or cp.stdout, 2000)}"
        )
    return cp, record


def run_command_live(
    command: list[str], *, timeout: Optional[int] = None, check: bool = False,
) -> tuple[subprocess.CompletedProcess[str], CommandRecord]:
    """Run a long command with terminal output visible to the examiner.

    Acquisition/verification tools already support their own durable ``-l`` log
    files, so suppressing their progress inside ``capture_output=True`` only makes
    a healthy multi-hour acquisition look frozen.  This helper deliberately
    inherits stdout/stderr while still recording command/timing/return-code data.
    """
    started = utc_now()
    cp = subprocess.run(command, timeout=timeout, check=False)
    record = CommandRecord(
        command=list(command), started_at=started, completed_at=utc_now(),
        returncode=cp.returncode, stdout="", stderr="",
    )
    if check and cp.returncode != 0:
        raise AcquisitionError(
            f"Command failed ({cp.returncode}): {' '.join(command)}"
        )
    return cp, record


def _extract_calculated_digest(text: str, algorithm: str = "sha256") -> str:
    """Extract a digest emitted by libewf acquisition/verification tools."""
    algo = algorithm.lower().replace("-", "")
    if algo == "sha256":
        label = r"SHA-?256"
        width = 64
    elif algo == "sha1":
        label = r"SHA-?1"
        width = 40
    elif algo == "md5":
        label = r"MD5"
        width = 32
    else:
        raise ValueError(f"Unsupported digest algorithm: {algorithm}")
    patterns = [
        rf"{label}\s+hash\s+calculated\s+over\s+data\s*:\s*([0-9a-fA-F]{{{width}}})",
        rf"calculated\s+{label}\s*[:=]\s*([0-9a-fA-F]{{{width}}})",
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text or "", flags=re.IGNORECASE)
        if matches:
            return matches[-1].lower()
    return ""


def _read_text_if_exists(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""
    except OSError:
        return ""


def verify_ewf_with_libewf(
    image_path: Path, *, log_path: Optional[Path] = None, live_output: bool = True,
) -> tuple[str, int, CommandRecord, str]:
    """Verify an E01 with libewf and return its logical-media SHA-256.

    This is the authoritative path for platform-created E01 images.  It avoids
    making the custom classic-EWF parser a single point of failure for large or
    multi-table images while preserving a deterministic SHA-256 comparison.
    """
    binary = os.environ.get("AUTOFORENSICS_EWFVERIFY_BIN", "ewfverify")
    if not shutil.which(binary):
        raise AcquisitionError("ewfverify is required to verify E01 acquisition content.")
    image_path = Path(image_path).resolve()
    if log_path is None:
        fd, temp_name = tempfile.mkstemp(prefix="autoforensics-ewfverify-", suffix=".log")
        os.close(fd)
        log_path = Path(temp_name)
        remove_log = True
    else:
        log_path = Path(log_path).resolve()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        remove_log = False
    command = [binary, "-d", "sha256", "-l", str(log_path), str(image_path)]
    try:
        if live_output:
            cp, record = run_command_live(command, timeout=None)
            output = _read_text_if_exists(log_path)
        else:
            cp, record = run_command(command, timeout=None)
            output = "\n".join((cp.stdout or "", cp.stderr or "", _read_text_if_exists(log_path)))
        if cp.returncode != 0:
            raise AcquisitionError(
                f"ewfverify failed ({cp.returncode}). See {log_path}"
            )
        digest = _extract_calculated_digest(output, "sha256")
        if not digest:
            raise AcquisitionError(
                f"ewfverify completed but its calculated SHA-256 could not be parsed from {log_path}"
            )
        # The logical media size is the original source-device size for a full
        # physical acquisition; callers compare this explicitly with source size.
        size = 0
        size_match = re.findall(
            r"\(([0-9]+)\s+bytes\)", output, flags=re.IGNORECASE
        )
        if size_match:
            size = int(size_match[-1])
        return digest, size, record, output
    finally:
        if remove_log:
            try:
                log_path.unlink(missing_ok=True)
            except OSError:
                pass


def _flatten(nodes: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for node in nodes:
        out.append(node)
        out.extend(_flatten(node.get("children") or []))
    return out


def _existing_path_anchor(path: Path) -> Path:
    """Return the nearest existing path used to identify a destination disk.

    Output directories are commonly new case paths.  Resolving ancestry only on
    the not-yet-created leaf would make ``findmnt --target`` fail and could omit
    the destination disk from the exclusion set.
    """
    candidate = Path(path).expanduser().resolve(strict=False)
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return candidate


def _ancestor_paths(path: Path, *, lsblk_bin: str = "lsblk") -> set[str]:
    """Return the block-device ancestry for a mounted path or /dev node."""
    try:
        source = str(path)
        if not source.startswith("/dev/"):
            source = str(_existing_path_anchor(path))
            cp, _ = run_command(["findmnt", "-no", "SOURCE", "--target", source], timeout=15)
            if cp.returncode != 0 or not cp.stdout.strip():
                return set()
            source = cp.stdout.strip().splitlines()[0]
        cp, _ = run_command([lsblk_bin, "-s", "-n", "-o", "PATH", source], timeout=15)
        if cp.returncode != 0:
            return {source} if source.startswith("/dev/") else set()
        return {line.strip() for line in cp.stdout.splitlines() if line.strip().startswith("/dev/")}
    except Exception:
        return set()


def discover_devices(
    *, output_dir: Optional[Path] = None, project_root: Optional[Path] = None,
    lsblk_bin: str = "lsblk",
) -> list[DeviceInfo]:
    fields = (
        "NAME,KNAME,PATH,TYPE,RO,RM,SIZE,VENDOR,MODEL,SERIAL,REV,TRAN,"
        "LOG-SEC,PHY-SEC,PTTYPE,FSTYPE,WWN,PKNAME,MOUNTPOINTS"
    )
    cp, _ = run_command([lsblk_bin, "-J", "-b", "-o", fields], timeout=30)
    if cp.returncode != 0:
        raise AcquisitionError(f"lsblk failed: {_clean_output(cp.stderr or cp.stdout, 2000)}")
    try:
        payload = json.loads(cp.stdout)
    except json.JSONDecodeError as exc:
        raise AcquisitionError(f"lsblk returned invalid JSON: {exc}") from exc

    system_ancestors = _ancestor_paths(Path("/"), lsblk_bin=lsblk_bin)
    output_ancestors = _ancestor_paths(output_dir, lsblk_bin=lsblk_bin) if output_dir else set()
    project_ancestors = _ancestor_paths(project_root, lsblk_bin=lsblk_bin) if project_root else set()

    results: list[DeviceInfo] = []
    for item in payload.get("blockdevices") or []:
        if str(item.get("type") or "") != "disk":
            continue
        path = str(item.get("path") or "")
        children = item.get("children") or []
        partition_records: list[dict[str, Any]] = []
        all_mounts: list[str] = [m for m in (item.get("mountpoints") or []) if m]
        for child in _flatten(children):
            mounts = [m for m in (child.get("mountpoints") or []) if m]
            all_mounts.extend(mounts)
            partition_records.append({
                "path": str(child.get("path") or ""),
                "type": str(child.get("type") or ""),
                "size_bytes": int(child.get("size") or 0),
                "filesystem_type": str(child.get("fstype") or ""),
                "read_only": bool(int(child.get("ro") or 0)),
                "mountpoints": mounts,
            })
        exclusions: list[str] = []
        if not path.startswith("/dev/"):
            exclusions.append("not a /dev block-device path")
        if path in system_ancestors:
            exclusions.append("system disk")
        if path in output_ancestors:
            exclusions.append("output destination disk")
        if path in project_ancestors:
            exclusions.append("AutoForensics project disk")
        result = DeviceInfo(
            path=path,
            name=str(item.get("name") or ""),
            kname=str(item.get("kname") or ""),
            device_type=str(item.get("type") or ""),
            read_only=bool(int(item.get("ro") or 0)),
            removable=bool(int(item.get("rm") or 0)),
            size_bytes=int(item.get("size") or 0),
            vendor=str(item.get("vendor") or "").strip(),
            model=str(item.get("model") or "").strip(),
            serial=str(item.get("serial") or "").strip(),
            firmware_revision=str(item.get("rev") or "").strip(),
            transport=str(item.get("tran") or "").strip(),
            logical_sector_size=int(item.get("log-sec") or 0),
            physical_sector_size=int(item.get("phy-sec") or 0),
            partition_table=str(item.get("pttype") or "").strip(),
            filesystem_type=str(item.get("fstype") or "").strip(),
            wwn=str(item.get("wwn") or "").strip(),
            parent_name=str(item.get("pkname") or "").strip(),
            mountpoints=sorted(set(all_mounts)),
            partitions=partition_records,
            is_system_disk=path in system_ancestors,
            is_output_disk=path in output_ancestors,
            is_project_disk=path in project_ancestors,
            exclusion_reasons=exclusions,
        )
        results.append(result)
    return results


def select_device(
    device_path: Path, *, output_dir: Path, project_root: Path,
    allow_regular_file_test: bool = False,
) -> DeviceInfo:
    path = Path(device_path).resolve()
    try:
        mode = path.stat().st_mode
    except OSError as exc:
        raise AcquisitionError(f"Source device is unavailable: {path}: {exc}") from exc
    if stat.S_ISREG(mode):
        if not allow_regular_file_test:
            raise AcquisitionError("A regular file cannot be claimed as an attached physical device.")
        return DeviceInfo(
            path=str(path), name=path.name, kname=path.name, device_type="test-file",
            read_only=not os.access(path, os.W_OK), size_bytes=path.stat().st_size,
            model="CONTROLLED REGRESSION FILE", serial="TEST-ONLY",
            transport="file", exclusion_reasons=[],
        )
    if not stat.S_ISBLK(mode):
        raise AcquisitionError(f"Source is not a block device: {path}")
    devices = {d.path: d for d in discover_devices(output_dir=output_dir, project_root=project_root)}
    info = devices.get(str(path))
    if not info:
        raise AcquisitionError(f"Device {path} was not returned as a whole disk by lsblk.")
    if info.exclusion_reasons:
        raise AcquisitionError(f"Refusing {path}: {', '.join(info.exclusion_reasons)}")
    return info


def _sysfs_ro_path(device: Path) -> Optional[Path]:
    name = device.name
    # Partition names such as nvme0n1p1 are not accepted here; selection is whole-disk only.
    candidate = Path("/sys/class/block") / name / "ro"
    return candidate if candidate.exists() else None


def _get_blockdev_ro(path: str) -> Optional[bool]:
    if not shutil.which("blockdev"):
        return None
    cp, _ = run_command(["blockdev", "--getro", path], timeout=15)
    if cp.returncode != 0:
        return None
    return cp.stdout.strip() == "1"


def prepare_write_protection(
    device: DeviceInfo,
    *, requested_method: str = "software",
    hardware_blocker: Optional[dict[str, str]] = None,
    allow_regular_file_test: bool = False,
) -> WriteProtectionRecord:
    source = Path(device.path)
    commands: list[CommandRecord] = []
    unmounted: list[str] = []
    limitations: list[str] = []
    requested = (requested_method or "software").strip().lower()
    hw = {str(k): str(v) for k, v in (hardware_blocker or {}).items() if v not in (None, "")}

    if device.device_type == "test-file":
        if not allow_regular_file_test:
            raise AcquisitionError("Regular-file write-protection mode is test-only.")
        limitations.append("Controlled regular-file regression source; not physical-device evidence.")
        return WriteProtectionRecord(
            source_device=device.path, requested_method="test", effective_method="TEST_FILE_READ_ONLY_OPEN",
            hardware_blocker={}, unmounted_paths=[], commands=[], sysfs_read_only=None,
            ioctl_read_only=None, partitions_read_only=True, no_mounted_partitions=True,
            verified=True, verification_method="source opened read-only by regression harness",
            limitations=limitations,
        )

    # Unmount every mounted child before setting the device read-only.
    mounts = sorted(set(device.mountpoints), key=len, reverse=True)
    for mountpoint in mounts:
        cp, record = run_command(["umount", "--", mountpoint], timeout=60)
        commands.append(record)
        if cp.returncode != 0:
            raise AcquisitionError(
                f"Cannot unmount evidence mount {mountpoint}: {_clean_output(cp.stderr or cp.stdout, 1000)}"
            )
        unmounted.append(mountpoint)

    if requested not in {"hardware", "software"}:
        raise AcquisitionError("Write protection method must be 'hardware' or 'software'.")

    if requested == "software":
        if not shutil.which("blockdev"):
            raise AcquisitionError("blockdev is required to enforce software read-only protection.")
        # Child partitions first, then the whole device.
        for child in device.partitions:
            child_path = str(child.get("path") or "")
            if child_path:
                cp, record = run_command(["blockdev", "--setro", child_path], timeout=15)
                commands.append(record)
                if cp.returncode != 0:
                    raise AcquisitionError(f"Could not set child read-only: {child_path}")
        cp, record = run_command(["blockdev", "--setro", device.path], timeout=15)
        commands.append(record)
        if cp.returncode != 0:
            raise AcquisitionError(f"Could not set source device read-only: {device.path}")
        effective = "SOFTWARE_ENFORCED_READ_ONLY"
        limitations.append(
            "Software read-only protection was used; it is not equivalent to a certified hardware forensic write blocker."
        )
    else:
        required = {"manufacturer", "model", "serial_number", "firmware_version", "connection_type"}
        missing = sorted(required - set(hw))
        if missing:
            raise AcquisitionError(
                "Hardware write-blocker mode requires recorded details: " + ", ".join(missing)
            )
        effective = "HARDWARE_FORENSIC_WRITE_BLOCKER"

    sysfs_path = _sysfs_ro_path(source)
    sysfs_ro: Optional[bool] = None
    if sysfs_path:
        try:
            sysfs_ro = sysfs_path.read_text(encoding="ascii").strip() == "1"
        except OSError:
            sysfs_ro = None
    ioctl_ro = _get_blockdev_ro(device.path)
    child_ro = all(_get_blockdev_ro(str(p.get("path"))) is True for p in device.partitions if p.get("path"))

    refreshed = {d.path: d for d in discover_devices()}.get(device.path)
    no_mounts = bool(refreshed is not None and not refreshed.mountpoints)
    read_only_confirmed = (sysfs_ro is True) or (ioctl_ro is True)
    verified = bool(read_only_confirmed and child_ro and no_mounts)
    if not verified:
        raise AcquisitionError(
            "Write protection could not be verified. "
            f"sysfs_ro={sysfs_ro}, ioctl_ro={ioctl_ro}, partitions_ro={child_ro}, no_mounts={no_mounts}"
        )
    method = "; ".join(x for x in (
        f"sysfs={sysfs_ro}" if sysfs_ro is not None else "",
        f"blockdev={ioctl_ro}" if ioctl_ro is not None else "",
        f"children_read_only={child_ro}", f"no_mounts={no_mounts}",
    ) if x)
    return WriteProtectionRecord(
        source_device=device.path, requested_method=requested, effective_method=effective,
        hardware_blocker=hw, unmounted_paths=unmounted, commands=commands,
        sysfs_read_only=sysfs_ro, ioctl_read_only=ioctl_ro,
        partitions_read_only=child_ro, no_mounted_partitions=no_mounts,
        verified=verified, verification_method=method, limitations=limitations,
    )


def sha256_stream(path: Path, *, chunk_size: int = 8 * 1024 * 1024) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    with Path(path).open("rb", buffering=0) as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
            total += len(chunk)
    return digest.hexdigest(), total


def _segment_paths(image_path: Path) -> list[Path]:
    suffix = image_path.suffix.lower()
    if suffix in {".e01", ".ex01"}:
        stem = image_path.with_suffix("")
        candidates: list[Path] = []
        # E01..E99 and Ex01..Ex99; preserve lexical order.
        for p in image_path.parent.iterdir():
            if p.is_file() and p.stem == stem.name and p.suffix.lower().startswith((".e", ".ex")):
                candidates.append(p)
        return sorted(candidates) or [image_path]
    return [image_path]


def hash_segments(image_path: Path) -> tuple[list[SegmentHash], str]:
    rows: list[SegmentHash] = []
    for index, segment in enumerate(_segment_paths(image_path), 1):
        digest, size = sha256_stream(segment)
        rows.append(SegmentHash(path=str(segment.resolve()), order=index, size_bytes=size, sha256=digest))
    canonical = json.dumps([asdict(row) for row in rows], sort_keys=True, separators=(",", ":")).encode("utf-8")
    return rows, hashlib.sha256(canonical).hexdigest()


def logical_media_sha256(image_path: Path) -> tuple[str, int]:
    suffix = image_path.suffix.lower()
    if suffix in {".e01", ".ex01"}:
        # Prefer the mature libewf verifier for acquired E01 media.  The native
        # parser remains a deterministic fallback for environments where
        # ewfverify is unavailable (for example isolated unit tests).
        if shutil.which(os.environ.get("AUTOFORENSICS_EWFVERIFY_BIN", "ewfverify")):
            digest, size, _record, _output = verify_ewf_with_libewf(
                image_path, live_output=False
            )
            if not size:
                try:
                    from core.native_evidence import parse_ewf
                    size = int(parse_ewf(image_path).media_size)
                except Exception:
                    size = 0
            return digest, size
        from core.native_evidence import hash_media_stream
        result = hash_media_stream(image_path)
        return str(result["sha256"]), int(result["size_bytes"])
    return sha256_stream(image_path)


def tool_version(binary: str) -> str:
    if not shutil.which(binary):
        return "not installed"
    for args in ([binary, "--version"], [binary, "-V"], [binary, "-h"]):
        try:
            cp, _ = run_command(list(args), timeout=15)
            output = (cp.stdout or cp.stderr).strip()
            if output:
                return output.splitlines()[0][:200]
        except Exception:
            continue
    return "installed; version unavailable"


def _write_manifest(record: AcquisitionRecord, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    record.manifest_path = str(path.resolve())
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(record), indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def acquire_device(
    *, source: DeviceInfo, output_dir: Path, case_id: str, evidence_id: str,
    investigator: str, acquisition_format: str = "e01",
    write_protection: WriteProtectionRecord,
    description: str = "", notes: str = "",
    allow_regular_file_test: bool = False,
) -> AcquisitionRecord:
    if not write_protection.verified:
        raise AcquisitionError("Acquisition refused because write protection is not verified.")
    if source.device_type == "test-file" and not allow_regular_file_test:
        raise AcquisitionError("Regular-file acquisition is test-only.")
    fmt = acquisition_format.strip().lower()
    if fmt not in {"e01", "raw", "dd"}:
        raise AcquisitionError("Supported acquisition formats are e01 and raw/dd.")

    out = Path(output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if str(out) == str(Path(source.path).resolve()):
        raise AcquisitionError("Source and output destination cannot be the same object.")

    # For E01, the default fast/stream mode avoids a redundant full-device
    # pre-hash pass.  ewfacquire calculates SHA-256 while it reads the source,
    # so the same physical read performs acquisition and source-stream hashing.
    # Set AUTOFORENSICS_SOURCE_HASH_MODE=strict to retain independent pre/post
    # full-device hashes at the cost of two additional source reads.
    hash_mode = os.environ.get("AUTOFORENSICS_SOURCE_HASH_MODE", "stream").strip().lower()
    if hash_mode not in {"stream", "strict"}:
        raise AcquisitionError(
            "AUTOFORENSICS_SOURCE_HASH_MODE must be 'stream' or 'strict'."
        )
    if fmt != "e01":
        hash_mode = "strict"  # raw/dd keeps the established exact-byte checks

    source_pre = ""
    source_post = ""
    source_size = int(source.size_bytes or 0)
    source_pre_basis = "ewfacquire acquisition-stream SHA-256"
    source_post_basis = "not separately read; source write protection remained verified"
    if hash_mode == "strict":
        print("[ACQUISITION] Stage 1/5 — hashing source before acquisition (strict mode)...", flush=True)
        source_pre, source_size = sha256_stream(Path(source.path))
        source_pre_basis = "separate pre-acquisition device read"

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_case = "".join(c if c.isalnum() or c in "-_" else "_" for c in case_id)
    safe_ev = "".join(c if c.isalnum() or c in "-_" else "_" for c in evidence_id)
    base = out / f"{safe_case}_{safe_ev}_{stamp}"
    commands: list[CommandRecord] = []
    read_error_log = ""
    acquisition_log_path = ""
    verification_log_path = ""
    started = utc_now()

    if fmt == "e01":
        binary = os.environ.get("AUTOFORENSICS_EWFACQUIRE_BIN", "ewfacquire")
        if not shutil.which(binary):
            raise AcquisitionError("ewfacquire is required for E01 acquisition.")
        acquisition_log = Path(str(base) + ".ewfacquire.log")
        acquisition_log_path = str(acquisition_log.resolve())
        command = [
            binary, "-t", str(base), "-f", "encase6", "-S", "2073741824",
            "-c", "fast", "-d", "sha256", "-l", str(acquisition_log),
            "-C", case_id, "-E", evidence_id,
            "-e", investigator, "-D", description or f"Physical acquisition of {source.path}",
            "-N", notes or "AutoForensics attached-device acquisition",
            "-u", source.path,
        ]
        print(
            "[ACQUISITION] Imaging source with ewfacquire. Progress below is emitted by libewf.",
            flush=True,
        )
        cp, cmd_record = run_command_live(command, timeout=None)
        commands.append(cmd_record)
        acq_log_text = _read_text_if_exists(acquisition_log)
        read_error_log = _clean_output(acq_log_text)
        if cp.returncode != 0:
            raise AcquisitionError(
                f"ewfacquire failed ({cp.returncode}). See {acquisition_log}"
            )
        image_path = Path(str(base) + ".E01")
        if not image_path.is_file():
            raise AcquisitionError(f"ewfacquire returned success but did not create {image_path}")
        tool = "ewfacquire"
        version = tool_version(binary)

        stream_hash = _extract_calculated_digest(acq_log_text, "sha256")
        if not stream_hash:
            raise AcquisitionError(
                f"ewfacquire completed but its source-stream SHA-256 could not be parsed from {acquisition_log}"
            )
        if hash_mode == "stream":
            source_pre = stream_hash
        elif source_pre != stream_hash:
            raise AcquisitionError(
                "Strict source pre-acquisition SHA-256 does not match the SHA-256 "
                "calculated by ewfacquire while reading the source."
            )

        verify_log = Path(str(base) + ".ewfverify.log")
        verification_log_path = str(verify_log.resolve())
        print(
            "[ACQUISITION] Verifying acquired E01 with libewf (no custom EWF parser dependency)...",
            flush=True,
        )
        acquired_hash, verified_size, verify_record, verify_text = verify_ewf_with_libewf(
            image_path, log_path=verify_log, live_output=True
        )
        commands.append(verify_record)
        acquired_size = int(verified_size or source_size or source.size_bytes or 0)
        logical_pre = acquired_hash  # same verified logical stream; do not hash it twice
        logical_size = acquired_size
    else:
        # Raw/dd regression and acquisition path retains separate source hashes.
        if not source_pre:
            print("[ACQUISITION] Hashing source before raw acquisition...", flush=True)
            source_pre, source_size = sha256_stream(Path(source.path))
            source_pre_basis = "separate pre-acquisition device read"
        image_path = Path(str(base) + ".raw")
        if shutil.which("ddrescue"):
            mapfile = Path(str(base) + ".ddrescue.map")
            command = ["ddrescue", "--force", "--no-scrape", source.path, str(image_path), str(mapfile)]
            cp, cmd_record = run_command_live(command, timeout=None)
            commands.append(cmd_record)
            if cp.returncode not in {0, 1}:
                raise AcquisitionError(f"ddrescue failed ({cp.returncode})")
            tool = "GNU ddrescue"
            version = tool_version("ddrescue")
        else:
            if source.device_type == "test-file":
                command = [
                    "dd", f"if={source.path}", f"of={image_path}",
                    "bs=4M", "iflag=fullblock", "status=none",
                ]
            else:
                sector_size = int(source.logical_sector_size or 512)
                if sector_size <= 0 or int(source.size_bytes or 0) <= 0:
                    raise AcquisitionError(
                        "GNU dd fallback requires reliable device size and logical "
                        "sector-size metadata; install GNU ddrescue otherwise."
                    )
                if int(source.size_bytes) % sector_size:
                    raise AcquisitionError(
                        "Device size is not an exact multiple of its logical sector "
                        "size; refusing an ambiguous dd fallback acquisition."
                    )
                sector_count = int(source.size_bytes) // sector_size
                command = [
                    "dd", f"if={source.path}", f"of={image_path}",
                    f"bs={sector_size}", f"count={sector_count}",
                    "iflag=fullblock", "conv=noerror,sync", "status=progress",
                ]
            cp, cmd_record = run_command_live(command, timeout=None)
            commands.append(cmd_record)
            if cp.returncode != 0:
                raise AcquisitionError(f"dd failed ({cp.returncode})")
            tool = "dd"
            version = tool_version("dd")
        if not image_path.is_file():
            raise AcquisitionError(f"Raw acquisition did not create {image_path}")
        acquired_hash, acquired_size = sha256_stream(image_path)
        logical_pre, logical_size = acquired_hash, acquired_size

    completed = utc_now()

    if hash_mode == "strict":
        print("[ACQUISITION] Hashing source after acquisition (strict mode)...", flush=True)
        source_post, source_post_size = sha256_stream(Path(source.path))
        source_post_basis = "separate post-acquisition device read"
        if source_size != source_post_size:
            raise AcquisitionError("Source readable byte count changed during acquisition.")
        source_pre_post = "MATCH" if source_pre == source_post else "MISMATCH"
    else:
        source_pre_post = "NOT_RUN_STREAM_MODE"

    segments, set_hash = hash_segments(image_path)
    # ewfacquire's source-stream SHA-256 and ewfverify's logical-media SHA-256
    # describe the same acquired byte stream.  Size is checked when libewf exposes
    # it; source metadata supplies the expected physical size otherwise.
    size_matches = (
        not source_size or not acquired_size or int(source_size) == int(acquired_size)
    )
    source_vs_acquired = (
        "MATCH" if source_pre == acquired_hash and size_matches else "MISMATCH"
    )
    verified = source_vs_acquired == "MATCH" and (
        source_pre_post == "MATCH" if hash_mode == "strict" else True
    )
    if not verified:
        raise AcquisitionError(
            f"Acquisition verification failed: source_vs_acquired={source_vs_acquired}, "
            f"source_pre_vs_post={source_pre_post}"
        )

    limitations = list(write_protection.limitations)
    if hash_mode == "stream":
        limitations.append(
            "FAST STREAM HASH MODE: the source SHA-256 was calculated by ewfacquire "
            "during acquisition; no separate full-device pre/post hash reads were "
            "performed. Source write protection and acquired-stream hash equality "
            "remain recorded. Set AUTOFORENSICS_SOURCE_HASH_MODE=strict for separate "
            "pre/post source-device hashes."
        )

    record = AcquisitionRecord(
        schema="autoforensics-acquisition-v2.8.4",
        case_id=case_id, evidence_id=evidence_id, investigator=investigator,
        source=source, write_protection=write_protection,
        acquisition_format="E01" if fmt == "e01" else "RAW",
        acquisition_tool=tool, acquisition_tool_version=version,
        acquisition_command=command, acquisition_started_at=started,
        acquisition_completed_at=completed, image_path=str(image_path.resolve()),
        image_segments=segments, read_error_log=read_error_log,
        bad_sector_count=None,
        source_pre_acquisition_sha256=source_pre,
        source_post_acquisition_sha256=source_post,
        acquired_content_sha256=acquired_hash,
        source_pre_vs_acquired=source_vs_acquired,
        source_pre_vs_source_post=source_pre_post,
        container_set_sha256_pre_analysis=set_hash,
        logical_media_sha256_pre_analysis=logical_pre,
        source_pre_hash_basis=source_pre_basis,
        source_post_hash_basis=source_post_basis,
        acquisition_log_path=acquisition_log_path,
        verification_log_path=verification_log_path,
        acquisition_verified=verified,
        limitations=limitations,
        commands=commands,
    )
    manifest = out / f"{safe_case}_{safe_ev}_acquisition_manifest.json"
    _write_manifest(record, manifest)
    print(
        f"[ACQUISITION] VERIFIED — source/acquired SHA-256 {source_vs_acquired}; "
        f"hash mode={hash_mode}.",
        flush=True,
    )
    return record

def verify_post_analysis(record: AcquisitionRecord) -> AcquisitionRecord:
    image_path = Path(record.image_path)
    if not image_path.is_file():
        raise AcquisitionError(f"Acquired image is missing before post-analysis verification: {image_path}")
    segments, set_hash = hash_segments(image_path)
    logical_hash, _ = logical_media_sha256(image_path)
    record.container_set_sha256_post_analysis = set_hash
    record.logical_media_sha256_post_analysis = logical_hash
    record.pre_vs_post_container_set = (
        "MATCH" if set_hash == record.container_set_sha256_pre_analysis else "MISMATCH"
    )
    record.pre_vs_post_logical_media = (
        "MATCH" if logical_hash == record.logical_media_sha256_pre_analysis else "MISMATCH"
    )
    record.analysis_integrity_verified = (
        record.pre_vs_post_container_set == "MATCH"
        and record.pre_vs_post_logical_media == "MATCH"
    )
    record.status = "VERIFIED_COMPLETE" if record.analysis_integrity_verified else "INTEGRITY_FAILURE"
    record.image_segments = segments
    if record.manifest_path:
        _write_manifest(record, Path(record.manifest_path))
    if not record.analysis_integrity_verified:
        raise AcquisitionError(
            "Post-analysis integrity verification failed: "
            f"container={record.pre_vs_post_container_set}, logical={record.pre_vs_post_logical_media}"
        )
    return record


def acquisition_integrity_rows(record: AcquisitionRecord) -> list[dict[str, str]]:
    source_stage = (
        "Source acquisition stream"
        if "ewfacquire" in str(record.source_pre_hash_basis or "").lower()
        else "Source pre-acquisition"
    )
    rows = [
        {
            "stage": source_stage, "object": record.source.path,
            "algorithm": "SHA-256", "hash": record.source_pre_acquisition_sha256,
            "comparison_target": "Acquired evidence content", "result": record.source_pre_vs_acquired,
        },
        {
            "stage": "Acquisition verification", "object": "reconstructed evidence byte stream",
            "algorithm": "SHA-256", "hash": record.acquired_content_sha256,
            "comparison_target": source_stage, "result": record.source_pre_vs_acquired,
        },
        {
            "stage": "Pre-analysis container set", "object": "ordered image segment manifest",
            "algorithm": "SHA-256", "hash": record.container_set_sha256_pre_analysis,
            "comparison_target": "Post-analysis container set", "result": record.pre_vs_post_container_set,
        },
        {
            "stage": "Post-analysis container set", "object": "ordered image segment manifest",
            "algorithm": "SHA-256", "hash": record.container_set_sha256_post_analysis,
            "comparison_target": "Pre-analysis container set", "result": record.pre_vs_post_container_set,
        },
        {
            "stage": "Pre-analysis logical media", "object": "reconstructed evidence byte stream",
            "algorithm": "SHA-256", "hash": record.logical_media_sha256_pre_analysis,
            "comparison_target": "Post-analysis logical media", "result": record.pre_vs_post_logical_media,
        },
        {
            "stage": "Post-analysis logical media", "object": "reconstructed evidence byte stream",
            "algorithm": "SHA-256", "hash": record.logical_media_sha256_post_analysis,
            "comparison_target": "Pre-analysis logical media", "result": record.pre_vs_post_logical_media,
        },
    ]
    if record.source_post_acquisition_sha256:
        rows.insert(1, {
            "stage": "Source post-acquisition", "object": record.source.path,
            "algorithm": "SHA-256", "hash": record.source_post_acquisition_sha256,
            "comparison_target": source_stage, "result": record.source_pre_vs_source_post,
        })
    return rows

def acquisition_record_from_dict(data: dict[str, Any]) -> AcquisitionRecord:
    """Rehydrate an acquisition manifest without trusting unknown fields.

    This is used only for post-analysis integrity verification.  Required
    nested structures are reconstructed as dataclasses so the same verifier is
    used by interactive and standalone workflows.
    """
    source_data = dict(data.get("source") or {})
    wp_data = dict(data.get("write_protection") or {})
    wp_data["commands"] = [CommandRecord(**row) for row in (wp_data.get("commands") or [])]
    segment_rows = [SegmentHash(**row) for row in (data.get("image_segments") or [])]
    command_rows = [CommandRecord(**row) for row in (data.get("commands") or [])]
    allowed = {field.name for field in __import__('dataclasses').fields(AcquisitionRecord)}
    values = {k: v for k, v in data.items() if k in allowed}
    values["source"] = DeviceInfo(**source_data)
    values["write_protection"] = WriteProtectionRecord(**wp_data)
    values["image_segments"] = segment_rows
    values["commands"] = command_rows
    return AcquisitionRecord(**values)
