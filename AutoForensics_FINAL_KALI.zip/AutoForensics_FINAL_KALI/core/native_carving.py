"""Dependency-free signature carving over a logical evidence byte stream.

This module deliberately reports *candidates*, not asserted deleted files.  A
signature hit can belong to an allocated file, an embedded object, slack, or
unallocated space.  The caller must retain that caveat in the report.
"""
from __future__ import annotations

import hashlib
import zipfile
import zlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional

from core.native_evidence import open_evidence_stream


@dataclass(frozen=True)
class CarveSpec:
    name: str
    extension: str
    header: bytes
    footer: bytes
    max_size: int
    footer_extra: int = 0


@dataclass
class CarvedCandidate:
    file_type: str
    offset_bytes: int
    size_bytes: int
    sha256: str
    output_path: str
    footer_found: bool
    validation_state: str = "ACCEPTED"
    validation_reason: str = ""
    payload_validated: bool = False
    caveat: str = (
        "Signature carving alone does not establish that the object was deleted; "
        "it may be allocated, embedded, slack, or unallocated content."
    )

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


DEFAULT_SPECS: tuple[CarveSpec, ...] = (
    CarveSpec("pdf", ".pdf", b"%PDF-", b"%%EOF", 128 * 1024 * 1024, 0),
    CarveSpec("jpeg", ".jpg", b"\xff\xd8\xff", b"\xff\xd9", 64 * 1024 * 1024, 0),
    CarveSpec("png", ".png", b"\x89PNG\r\n\x1a\n", b"IEND\xaeB`\x82", 64 * 1024 * 1024, 0),
    CarveSpec("gif87a", ".gif", b"GIF87a", b"\x3b", 64 * 1024 * 1024, 0),
    CarveSpec("gif89a", ".gif", b"GIF89a", b"\x3b", 64 * 1024 * 1024, 0),
    CarveSpec("zip", ".zip", b"PK\x03\x04", b"PK\x05\x06", 512 * 1024 * 1024, 22),
)


def _iter_header_hits(
    evidence_path: Path,
    specs: Iterable[CarveSpec],
    *,
    chunk_size: int,
    max_scan_bytes: Optional[int],
) -> Iterable[tuple[CarveSpec, int]]:
    specs = tuple(specs)
    overlap = max(len(spec.header) for spec in specs) - 1
    seen: set[tuple[str, int]] = set()
    with open_evidence_stream(evidence_path) as stream:
        logical_size = int(getattr(stream, "media_size", evidence_path.stat().st_size))
        limit = logical_size if max_scan_bytes is None else min(logical_size, max_scan_bytes)
        prior = b""
        absolute = 0
        while absolute < limit:
            block = stream.read(min(chunk_size, limit - absolute))
            if not block:
                break
            window = prior + block
            base = absolute - len(prior)
            for spec in specs:
                start = 0
                while True:
                    pos = window.find(spec.header, start)
                    if pos < 0:
                        break
                    logical_offset = base + pos
                    key = (spec.name, logical_offset)
                    if logical_offset >= 0 and key not in seen:
                        seen.add(key)
                        yield spec, logical_offset
                    start = pos + 1
            prior = window[-overlap:] if overlap else b""
            absolute += len(block)



def _gif_structured_length(data: bytes) -> int | None:
    """Return the exact GIF logical length after validating block structure."""
    if len(data) < 13 or data[:6] not in {b"GIF87a", b"GIF89a"}:
        return None
    packed = data[10]
    pos = 13
    if packed & 0x80:
        pos += 3 * (2 ** ((packed & 0x07) + 1))
    if pos > len(data):
        return None

    def skip_sub_blocks(offset: int) -> int | None:
        while True:
            if offset >= len(data):
                return None
            size = data[offset]
            offset += 1
            if size == 0:
                return offset
            offset += size
            if offset > len(data):
                return None

    while pos < len(data):
        marker = data[pos]
        if marker == 0x3B:  # trailer
            return pos + 1
        if marker == 0x21:  # extension introducer + label + data sub-blocks
            if pos + 2 > len(data):
                return None
            pos = skip_sub_blocks(pos + 2)
            if pos is None:
                return None
            continue
        if marker == 0x2C:  # image descriptor
            if pos + 10 > len(data):
                return None
            image_packed = data[pos + 9]
            pos += 10
            if image_packed & 0x80:
                pos += 3 * (2 ** ((image_packed & 0x07) + 1))
            if pos >= len(data):
                return None
            pos += 1  # LZW minimum code size
            pos = skip_sub_blocks(pos)
            if pos is None:
                return None
            continue
        return None
    return None

def _zip_geometry(data: bytes) -> tuple[int, set[int]] | None:
    """Validate a standard single-volume ZIP starting at byte zero.

    Returns:
        (complete_archive_length, member_local_header_offsets)

    The geometry is resolved from the EOCD and central directory. A random
    PK\x03\x04 local-member header therefore cannot be treated as the start
    of a complete archive merely because an EOCD exists later in the stream.

    ZIP64 and multi-volume archives are intentionally not asserted by this
    native validator.
    """
    eocd_sig = b"PK\x05\x06"
    cd_sig = b"PK\x01\x02"
    local_sig = b"PK\x03\x04"

    search_from = len(local_sig)

    while True:
        footer_at = data.find(eocd_sig, search_from)
        if footer_at < 0:
            return None

        fixed_end = footer_at + 22
        if fixed_end > len(data):
            return None

        eocd = data[footer_at:fixed_end]

        disk_number = int.from_bytes(eocd[4:6], "little")
        cd_start_disk = int.from_bytes(eocd[6:8], "little")
        entries_this_disk = int.from_bytes(eocd[8:10], "little")
        entries_total = int.from_bytes(eocd[10:12], "little")
        cd_size = int.from_bytes(eocd[12:16], "little")
        cd_offset = int.from_bytes(eocd[16:20], "little")
        comment_len = int.from_bytes(eocd[20:22], "little")

        candidate_end = fixed_end + comment_len

        if candidate_end > len(data):
            search_from = footer_at + 1
            continue

        # Reject structures this native validator cannot prove.
        if (
            disk_number != 0
            or cd_start_disk != 0
            or entries_this_disk != entries_total
            or entries_total in (0, 0xFFFF)
            or cd_size == 0xFFFFFFFF
            or cd_offset == 0xFFFFFFFF
        ):
            search_from = footer_at + 1
            continue

        # Central directory must terminate immediately before this EOCD,
        # relative to THIS candidate start.
        if cd_offset + cd_size != footer_at:
            search_from = footer_at + 1
            continue

        if cd_offset < len(local_sig) or cd_offset >= footer_at:
            search_from = footer_at + 1
            continue

        pos = cd_offset
        local_offsets: set[int] = set()
        valid = True

        for _ in range(entries_total):
            # Fixed central-directory record = 46 bytes.
            if pos + 46 > footer_at:
                valid = False
                break

            if data[pos:pos + 4] != cd_sig:
                valid = False
                break

            name_len = int.from_bytes(data[pos + 28:pos + 30], "little")
            extra_len = int.from_bytes(data[pos + 30:pos + 32], "little")
            file_comment_len = int.from_bytes(data[pos + 32:pos + 34], "little")
            local_offset = int.from_bytes(data[pos + 42:pos + 46], "little")

            record_end = (
                pos + 46 + name_len + extra_len + file_comment_len
            )

            if record_end > footer_at:
                valid = False
                break

            if local_offset == 0xFFFFFFFF:
                valid = False
                break

            if local_offset + 30 > cd_offset:
                valid = False
                break

            if data[local_offset:local_offset + 4] != local_sig:
                valid = False
                break

            # Validate the corresponding local-header geometry.
            local_name_len = int.from_bytes(
                data[local_offset + 26:local_offset + 28], "little"
            )
            local_extra_len = int.from_bytes(
                data[local_offset + 28:local_offset + 30], "little"
            )

            local_header_end = (
                local_offset + 30 + local_name_len + local_extra_len
            )

            if local_header_end > cd_offset:
                valid = False
                break

            cd_name_start = pos + 46
            cd_name_end = cd_name_start + name_len

            local_name_start = local_offset + 30
            local_name_end = local_name_start + local_name_len

            if data[cd_name_start:cd_name_end] != data[
                local_name_start:local_name_end
            ]:
                valid = False
                break

            local_offsets.add(local_offset)
            pos = record_end

        if not valid or pos != footer_at:
            search_from = footer_at + 1
            continue

        # Since the candidate begins at a PK\x03\x04 hit, a genuine archive
        # beginning here must have at least one member local header at
        # relative offset zero.
        if 0 not in local_offsets:
            search_from = footer_at + 1
            continue

        return candidate_end, local_offsets


def _carve_one(
    evidence_path: Path,
    spec: CarveSpec,
    offset: int,
    *,
    read_chunk_size: int = 256 * 1024,
) -> tuple[bytes, bool]:
    """Read only as far as required to resolve one candidate.

    Earlier builds issued ``stream.read(spec.max_size)`` for every header hit.
    On a multi-gigabyte EWF this turned thousands of otherwise small carving
    observations into hundreds of gigabytes of repeated logical-media reads.
    This implementation keeps exactly the same deterministic size bounds, but
    stops reading as soon as a provable footer/structure is reached.

    A missing footer can still consume the configured per-format ``max_size``;
    that is an explicit safety boundary rather than a silent coverage cap.
    """
    if read_chunk_size <= 0:
        read_chunk_size = 256 * 1024

    with open_evidence_stream(evidence_path) as stream:
        stream.seek(offset)
        first = stream.read(len(spec.header))
        if first != spec.header:
            return b"", False

        data = bytearray(first)
        search_from = len(spec.header)

        while len(data) < spec.max_size:
            remaining = spec.max_size - len(data)
            block = stream.read(min(read_chunk_size, remaining))
            if not block:
                break
            previous_len = len(data)
            data.extend(block)

            if spec.name in {"gif87a", "gif89a"}:
                # A GIF trailer byte can occur inside sub-block payloads.  Test
                # each newly reachable trailer position against the GIF block
                # grammar and accept only a structurally complete object.
                candidate_search = max(search_from, previous_len - 1)
                while True:
                    trailer_at = data.find(spec.footer, candidate_search)
                    if trailer_at < 0:
                        break
                    end = _gif_structured_length(bytes(data[:trailer_at + 1]))
                    if end is not None:
                        return bytes(data[:end]), True
                    candidate_search = trailer_at + 1
                search_from = max(len(spec.header), len(data) - 1)
                continue

            footer_at = data.find(spec.footer, max(search_from, previous_len - len(spec.footer) + 1))
            if footer_at < 0:
                search_from = max(len(spec.header), len(data) - len(spec.footer) + 1)
                continue

            end = footer_at + len(spec.footer)

            if spec.name == "pdf":
                # Preserve conventional CR/LF immediately after %%EOF without
                # reading the remainder of the 128 MiB safety window.
                while end < len(data) and data[end:end + 1] in (b"\r", b"\n"):
                    end += 1
                if end == len(data) and len(data) < spec.max_size:
                    extra = stream.read(2)
                    for byte in extra:
                        if byte in (0x0D, 0x0A) and end - footer_at < len(spec.footer) + 2:
                            data.append(byte)
                            end += 1
                        else:
                            break

            return bytes(data[:end]), True

    return b"", False


def _iter_signature_hits(
    evidence_path: Path,
    signature: bytes,
    *,
    chunk_size: int = 8 * 1024 * 1024,
    max_scan_bytes: Optional[int] = None,
) -> Iterable[int]:
    """Yield absolute occurrences of one byte signature in one sequential pass."""
    if not signature:
        return

    overlap = len(signature) - 1

    with open_evidence_stream(evidence_path) as stream:
        media_size = getattr(stream, "media_size", None)
        logical_size = (
            int(media_size)
            if media_size is not None
            else int(evidence_path.stat().st_size)
        )

        limit = (
            logical_size
            if max_scan_bytes is None
            else min(logical_size, int(max_scan_bytes))
        )

        stream.seek(0)
        absolute = 0
        carry = b""

        while absolute < limit:
            block = stream.read(min(chunk_size, limit - absolute))
            if not block:
                break

            window = carry + block
            window_base = absolute - len(carry)

            pos = 0
            while True:
                hit = window.find(signature, pos)
                if hit < 0:
                    break

                absolute_hit = window_base + hit
                if 0 <= absolute_hit < limit:
                    yield absolute_hit

                pos = hit + 1

            carry = window[-overlap:] if overlap else b""
            absolute += len(block)


def _validate_zip_eocd(
    stream,
    eocd_offset: int,
    logical_limit: int,
    max_archive_size: int,
) -> tuple[int, int, set[int]] | None:
    """Resolve and validate one standard single-volume ZIP from its EOCD.

    Returns ``(archive_start, archive_end, member_local_header_offsets)`` only
    when the central-directory geometry and referenced local headers prove a
    complete archive.  The member offsets are absolute logical-media offsets
    and are used to account for local-header signatures without misclassifying
    internal ZIP members as separate outer archives.
    """
    eocd_sig = b"PK\x05\x06"
    cd_sig = b"PK\x01\x02"
    local_sig = b"PK\x03\x04"

    stream.seek(eocd_offset)
    eocd = stream.read(22)

    if len(eocd) != 22 or not eocd.startswith(eocd_sig):
        return None

    disk_number = int.from_bytes(eocd[4:6], "little")
    cd_start_disk = int.from_bytes(eocd[6:8], "little")
    entries_this_disk = int.from_bytes(eocd[8:10], "little")
    entries_total = int.from_bytes(eocd[10:12], "little")
    cd_size = int.from_bytes(eocd[12:16], "little")
    cd_offset = int.from_bytes(eocd[16:20], "little")
    comment_len = int.from_bytes(eocd[20:22], "little")

    # Native validator deliberately does not assert multi-volume or ZIP64.
    if (
        disk_number != 0
        or cd_start_disk != 0
        or entries_this_disk != entries_total
        or entries_total in (0, 0xFFFF)
        or cd_size == 0xFFFFFFFF
        or cd_offset == 0xFFFFFFFF
    ):
        return None

    archive_end = eocd_offset + 22 + comment_len
    if archive_end > logical_limit:
        return None

    # EOCD states where the central directory begins relative to the
    # beginning of this ZIP. Therefore its actual archive start can be
    # derived rather than guessed from each PK\x03\x04 occurrence.
    archive_start = eocd_offset - cd_size - cd_offset

    if archive_start < 0 or archive_start >= eocd_offset:
        return None

    archive_size = archive_end - archive_start
    if archive_size <= 0 or archive_size > max_archive_size:
        return None

    stream.seek(archive_start)
    if stream.read(4) != local_sig:
        return None

    cd_absolute = archive_start + cd_offset

    if cd_absolute + cd_size != eocd_offset:
        return None

    pos = cd_absolute
    member_local_headers: set[int] = set()

    for _ in range(entries_total):
        if pos + 46 > eocd_offset:
            return None

        stream.seek(pos)
        fixed = stream.read(46)

        if len(fixed) != 46 or fixed[:4] != cd_sig:
            return None

        name_len = int.from_bytes(fixed[28:30], "little")
        extra_len = int.from_bytes(fixed[30:32], "little")
        file_comment_len = int.from_bytes(fixed[32:34], "little")
        local_offset = int.from_bytes(fixed[42:46], "little")

        if local_offset == 0xFFFFFFFF:
            return None

        record_end = (
            pos + 46 + name_len + extra_len + file_comment_len
        )

        if record_end > eocd_offset:
            return None

        cd_name = stream.read(name_len)
        if len(cd_name) != name_len:
            return None

        local_absolute = archive_start + local_offset

        if (
            local_absolute < archive_start
            or local_absolute + 30 > cd_absolute
        ):
            return None

        stream.seek(local_absolute)
        local_fixed = stream.read(30)

        if len(local_fixed) != 30 or local_fixed[:4] != local_sig:
            return None

        local_name_len = int.from_bytes(
            local_fixed[26:28], "little"
        )
        local_extra_len = int.from_bytes(
            local_fixed[28:30], "little"
        )

        local_header_end = (
            local_absolute
            + 30
            + local_name_len
            + local_extra_len
        )

        if local_header_end > cd_absolute:
            return None

        local_name = stream.read(local_name_len)

        if local_name != cd_name:
            return None

        member_local_headers.add(local_absolute)
        pos = record_end

    if pos != eocd_offset:
        return None

    return archive_start, archive_end, member_local_headers


def _copy_interval(
    stream,
    start: int,
    end: int,
    destination: Path,
    *,
    chunk_size: int = 8 * 1024 * 1024,
) -> tuple[str, int]:
    """Copy an already validated source interval while computing SHA-256."""
    digest = hashlib.sha256()
    remaining = end - start
    written = 0

    stream.seek(start)

    try:
        with destination.open("wb") as fh:
            while remaining:
                block = stream.read(min(chunk_size, remaining))
                if not block:
                    raise OSError(
                        "Unexpected EOF while copying validated ZIP interval"
                    )

                fh.write(block)
                digest.update(block)

                written += len(block)
                remaining -= len(block)

    except Exception:
        try:
            destination.unlink()
        except OSError:
            pass
        raise

    return digest.hexdigest(), written


def _validate_zip_payload(
    archive_path: Path,
) -> tuple[str, str, bool]:
    """Validate ZIP member payloads without treating inability to decode
    encrypted/unsupported content as corruption.

    Returns:
        (validation_state, reason, payload_validated)

    validation_state:
        ACCEPTED  - every member could be decoded and CRC validated
        CANDIDATE - integrity could not be established deterministically
        REJECTED  - payload corruption / CRC failure was demonstrated
    """
    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            members = archive.infolist()

            encrypted = [
                info.filename
                for info in members
                if info.flag_bits & 0x1
            ]

            if encrypted:
                return (
                    "CANDIDATE",
                    (
                        f"{len(encrypted)} encrypted ZIP member(s); "
                        "payload integrity was not tested without credentials."
                    ),
                    False,
                )

            try:
                bad_member = archive.testzip()

            except NotImplementedError as exc:
                return (
                    "CANDIDATE",
                    (
                        "ZIP uses a compression/encryption method not "
                        f"supported by the local validator: {exc}"
                    ),
                    False,
                )

            except RuntimeError as exc:
                message = str(exc)
                lowered = message.lower()

                if (
                    "encrypted" in lowered
                    or "password" in lowered
                    or "compression" in lowered
                    or "not supported" in lowered
                ):
                    return (
                        "CANDIDATE",
                        (
                            "ZIP payload integrity could not be "
                            f"established locally: {message}"
                        ),
                        False,
                    )

                # An otherwise unexplained runtime inability is not
                # sufficient evidence of corruption.
                return (
                    "CANDIDATE",
                    (
                        "ZIP payload validation was inconclusive: "
                        f"{message}"
                    ),
                    False,
                )

            except (zipfile.BadZipFile, zlib.error, EOFError) as exc:
                return (
                    "REJECTED",
                    (
                        "ZIP payload decompression/integrity validation "
                        f"failed: {exc}"
                    ),
                    False,
                )

            if bad_member is not None:
                return (
                    "REJECTED",
                    (
                        "ZIP CRC validation failed for member "
                        f"{bad_member!r}."
                    ),
                    False,
                )

            return (
                "ACCEPTED",
                (
                    f"All {len(members)} ZIP member(s) decompressed "
                    "successfully and passed CRC validation."
                ),
                True,
            )

    except (zipfile.BadZipFile, zlib.error, EOFError) as exc:
        return (
            "REJECTED",
            f"ZIP container/payload validation failed: {exc}",
            False,
        )

    except (NotImplementedError, RuntimeError, OSError, ValueError) as exc:
        # Environmental, encryption or unsupported-codec limitations
        # must not be mislabeled as proven corruption.
        return (
            "CANDIDATE",
            f"ZIP payload integrity could not be established: {exc}",
            False,
        )


def _read_partial_zip_local_header(stream, offset: int, logical_limit: int) -> tuple[bytes, str] | None:
    """Return a structurally plausible local ZIP header that lacks proven EOCD ownership.

    This is deliberately a candidate-only check.  It does not infer a complete
    archive, deletion state, or payload integrity.
    """
    if offset < 0 or offset + 30 > logical_limit:
        return None
    stream.seek(offset)
    fixed = stream.read(30)
    if len(fixed) != 30 or fixed[:4] != b"PK\x03\x04":
        return None
    version_needed = int.from_bytes(fixed[4:6], "little")
    flags = int.from_bytes(fixed[6:8], "little")
    method = int.from_bytes(fixed[8:10], "little")
    name_len = int.from_bytes(fixed[26:28], "little")
    extra_len = int.from_bytes(fixed[28:30], "little")
    # Bounds are format-generic sanity checks, not evidence-specific filters.
    if version_needed > 100 or name_len > 65535 or extra_len > 65535:
        return None
    header_end = offset + 30 + name_len + extra_len
    if header_end > logical_limit:
        return None
    tail = stream.read(name_len + extra_len)
    if len(tail) != name_len + extra_len:
        return None
    name_bytes = tail[:name_len]
    name = name_bytes.decode("utf-8", errors="replace")
    descriptor = (
        f"Plausible ZIP local header; version_needed={version_needed}, "
        f"flags=0x{flags:04x}, method={method}, member_name={name!r}. "
        "No validated EOCD/central-directory record referenced this header, "
        "so it is retained as a partial/embedded ZIP candidate only."
    )
    return fixed + tail, descriptor


def _carve_zips_from_eocd(
    source: Path,
    destination: Path,
    *,
    zip_spec: CarveSpec,
    chunk_size: int,
    max_scan_bytes: Optional[int],
    max_candidates: int,
) -> list[CarvedCandidate]:
    """Discover complete ZIPs and account for orphaned local ZIP headers.

    Complete archives are derived from EOCD/central-directory geometry and then
    payload/CRC validated.  Plausible local headers that are not referenced by
    any validated archive are retained as candidate-only observations instead
    of being silently discarded.
    """
    destination.mkdir(parents=True, exist_ok=True)

    with open_evidence_stream(source) as stream:
        media_size = getattr(stream, "media_size", None)
        logical_size = int(media_size) if media_size is not None else int(source.stat().st_size)

    logical_limit = logical_size if max_scan_bytes is None else min(logical_size, int(max_scan_bytes))
    results: list[CarvedCandidate] = []
    seen_intervals: set[tuple[int, int]] = set()
    accounted_local_headers: set[int] = set()

    with open_evidence_stream(source) as stream:
        for eocd_offset in _iter_signature_hits(
            source, b"PK\x05\x06", chunk_size=chunk_size, max_scan_bytes=max_scan_bytes
        ):
            if max_candidates > 0 and len(results) >= max_candidates:
                break
            geometry = _validate_zip_eocd(stream, eocd_offset, logical_limit, zip_spec.max_size)
            if geometry is None:
                continue
            archive_start, archive_end, member_headers = geometry
            interval = (archive_start, archive_end)
            if interval in seen_intervals:
                accounted_local_headers.update(member_headers)
                continue
            seen_intervals.add(interval)
            accounted_local_headers.update(member_headers)

            temporary = destination / f".zip_{archive_start:016x}_{archive_end:016x}.partial"
            digest, size_bytes = _copy_interval(
                stream, archive_start, archive_end, temporary, chunk_size=chunk_size
            )
            output = destination / f"zip_{archive_start:016x}_{digest[:12]}{zip_spec.extension}"
            if output.exists():
                temporary.unlink(missing_ok=True)
            else:
                temporary.replace(output)

            validation_state, validation_reason, payload_validated = _validate_zip_payload(output)
            results.append(CarvedCandidate(
                file_type="zip", offset_bytes=archive_start, size_bytes=size_bytes,
                sha256=digest, output_path=str(output), footer_found=True,
                validation_state=validation_state, validation_reason=validation_reason,
                payload_validated=payload_validated,
            ))

    # Second sequential signature pass: every plausible local ZIP header not
    # already accounted for by a validated archive becomes an explicit
    # candidate-only observation.  No large pseudo-archive is materialised.
    if max_candidates <= 0 or len(results) < max_candidates:
        with open_evidence_stream(source) as stream:
            for local_offset in _iter_signature_hits(
                source, b"PK\x03\x04", chunk_size=chunk_size, max_scan_bytes=max_scan_bytes
            ):
                if local_offset in accounted_local_headers:
                    continue
                if max_candidates > 0 and len(results) >= max_candidates:
                    break
                parsed = _read_partial_zip_local_header(stream, local_offset, logical_limit)
                if parsed is None:
                    continue
                header_bytes, reason = parsed
                results.append(CarvedCandidate(
                    file_type="zip_partial", offset_bytes=local_offset,
                    size_bytes=len(header_bytes), sha256=hashlib.sha256(header_bytes).hexdigest(),
                    output_path="", footer_found=False, validation_state="CANDIDATE",
                    validation_reason=reason, payload_validated=False,
                    caveat=(
                        "A plausible ZIP local header was found, but a complete archive could not be "
                        "proven from EOCD/central-directory geometry. The observation may be a partial, "
                        "embedded, damaged, deleted, slack, or unallocated fragment."
                    ),
                ))
    return results

def carve_signatures(
    evidence_path: str | Path,
    output_dir: str | Path,
    *,
    specs: Iterable[CarveSpec] = DEFAULT_SPECS,
    chunk_size: int = 8 * 1024 * 1024,
    max_scan_bytes: Optional[int] = None,
    max_candidates: int = 0,
) -> list[CarvedCandidate]:
    """Carve structurally complete objects from the logical media stream."""
    source = Path(evidence_path).resolve()
    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)

    selected_specs = tuple(specs)

    zip_specs = tuple(
        spec for spec in selected_specs
        if spec.name == "zip"
    )

    non_zip_specs = tuple(
        spec for spec in selected_specs
        if spec.name != "zip"
    )

    results: list[CarvedCandidate] = []

    # ZIP is handled from EOCD geometry. This avoids performing a large
    # random read for every PK\x03\x04 member-header occurrence.
    for zip_spec in zip_specs:
        if max_candidates > 0:
            remaining = max_candidates - len(results)
            if remaining <= 0:
                break
        else:
            remaining = 0

        results.extend(
            _carve_zips_from_eocd(
                source,
                destination,
                zip_spec=zip_spec,
                chunk_size=chunk_size,
                max_scan_bytes=max_scan_bytes,
                max_candidates=remaining,
            )
        )

    # Other formats retain their established deterministic header/footer
    # processing.
    if non_zip_specs and (max_candidates <= 0 or len(results) < max_candidates):
        for spec, offset in _iter_header_hits(
            source,
            non_zip_specs,
            chunk_size=chunk_size,
            max_scan_bytes=max_scan_bytes,
        ):
            if max_candidates > 0 and len(results) >= max_candidates:
                break

            data, complete = _carve_one(
                source,
                spec,
                offset,
            )

            if not complete or not data:
                # A header hit without a provable complete object is retained
                # as candidate-only metadata instead of disappearing silently.
                with open_evidence_stream(source) as _stream:
                    _stream.seek(offset)
                    header_bytes = _stream.read(len(spec.header))
                results.append(CarvedCandidate(
                    file_type=("gif" if spec.name.startswith("gif") else spec.name),
                    offset_bytes=offset,
                    size_bytes=len(header_bytes),
                    sha256=hashlib.sha256(header_bytes).hexdigest() if header_bytes else "",
                    output_path="", footer_found=False,
                    validation_state="CANDIDATE",
                    validation_reason=(
                        f"{spec.name.upper()} header signature was present at logical offset {offset}, "
                        "but a complete bounded structure/footer could not be deterministically validated. "
                        "Retained as a partial/fragment candidate."
                    ),
                    payload_validated=False,
                ))
                continue

            digest = hashlib.sha256(data).hexdigest()

            output = destination / (
                f"{spec.name}_{offset:016x}_{digest[:12]}"
                f"{spec.extension}"
            )

            if not output.exists():
                output.write_bytes(data)

            results.append(
                CarvedCandidate(
                    file_type=(
                        "gif"
                        if spec.name.startswith("gif")
                        else spec.name
                    ),
                    offset_bytes=offset,
                    size_bytes=len(data),
                    sha256=digest,
                    output_path=str(output),
                    footer_found=True,
                )
            )

    return results
