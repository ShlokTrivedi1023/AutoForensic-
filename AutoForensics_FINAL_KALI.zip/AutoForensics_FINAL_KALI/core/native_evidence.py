"""Native, read-only evidence stream support.

This module provides a dependency-free reader for raw images and the original
EWF/E01 container format.  It intentionally does not invoke ``ewfmount``, use
``sudo``, or mount filesystems.  External tools can still be used elsewhere as
an optional verification path, but the bytes exposed here are reconstructed
from the evidence container itself.

The EWF implementation follows libyal's public EWF specification and supports
classic E01 segment sets with ``header``/``header2``, ``volume``/``disk``,
``sectors``, ``table``/``table2``, ``hash`` and ``digest`` sections.  EWF2
(Ex01) is detected and reported as unsupported rather than silently treating
container bytes as media bytes.
"""
from __future__ import annotations

import hashlib
import io
from datetime import datetime, timezone
import os
import re
import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO, Iterator, Optional

EWF1_SIGNATURE = b"EVF\x09\x0d\x0a\xff\x00"
EWF2_SIGNATURE = b"EVF2\r\n\x81\x00"
_SECTION_DESCRIPTOR_SIZE = 76
_EWF_FILE_HEADER_SIZE = 13


class EvidenceFormatError(RuntimeError):
    """Raised when evidence is corrupt, truncated, or unsupported."""


@dataclass(frozen=True)
class EwfSection:
    segment_path: Path
    segment_number: int
    section_type: str
    offset: int
    next_offset: int
    size: int
    data_offset: int
    data_size: int
    descriptor_checksum_stored: Optional[int] = None
    descriptor_checksum_computed: Optional[int] = None
    descriptor_checksum_valid: Optional[bool] = None


@dataclass(frozen=True)
class EwfChunk:
    segment_path: Path
    start: int
    end: int
    compressed: bool
    expected_size: int


@dataclass
class EwfMetadata:
    case_number: str = ""
    evidence_number: str = ""
    description: str = ""
    examiner: str = ""
    notes: str = ""
    acquisition_date: str = ""
    system_date: str = ""
    acquisition_version: str = ""
    acquisition_platform: str = ""
    password_hash: str = ""
    password_state: str = "unknown"
    compression: str = ""
    model: str = ""
    serial_number: str = ""
    device_label: str = ""
    raw_values: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, object]:
        return {
            "case_number": self.case_number,
            "evidence_number": self.evidence_number,
            "description": self.description,
            "examiner": self.examiner,
            "notes": self.notes,
            "acquisition_date": self.acquisition_date,
            "system_date": self.system_date,
            "acquisition_version": self.acquisition_version,
            "acquisition_platform": self.acquisition_platform,
            "password_hash": self.password_hash,
            "password_state": self.password_state,
            "compression": self.compression,
            "model": self.model,
            "serial_number": self.serial_number,
            "device_label": self.device_label,
            "raw_values": dict(self.raw_values),
        }


@dataclass
class EwfInfo:
    segment_paths: list[Path]
    sections: list[EwfSection]
    chunks: list[EwfChunk]
    metadata: EwfMetadata
    embedded_hashes: dict[str, str]
    chunk_count: int
    sectors_per_chunk: int
    bytes_per_sector: int
    sector_count: int
    media_size: int
    media_type: Optional[int] = None
    media_flags: Optional[int] = None
    compression_level: Optional[int] = None
    warnings: list[str] = field(default_factory=list)


class RawEvidenceStream(io.BufferedReader):
    """Buffered read-only stream for raw/dd/img evidence."""

    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        super().__init__(open(self.path, "rb"))
        self.media_size = self.path.stat().st_size
        self.metadata: dict[str, object] = {}
        self.embedded_hashes: dict[str, str] = {}
        self.warnings: list[str] = []


class EwfEvidenceStream(io.RawIOBase):
    """Seekable logical-media stream reconstructed from classic E01 chunks."""

    def __init__(self, path: str | Path):
        super().__init__()
        self.path = Path(path).resolve()
        self.info = parse_ewf(self.path)
        self.media_size = self.info.media_size
        self.metadata = self.info.metadata.as_dict()
        self.embedded_hashes = dict(self.info.embedded_hashes)
        self.warnings = list(self.info.warnings)
        self._position = 0
        self._chunk_starts: list[int] = []
        logical = 0
        for chunk in self.info.chunks:
            self._chunk_starts.append(logical)
            logical += chunk.expected_size
        self._cache_index: Optional[int] = None
        self._cache_data = b""

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self._position

    def seek(self, offset: int, whence: int = os.SEEK_SET) -> int:
        if whence == os.SEEK_SET:
            new = offset
        elif whence == os.SEEK_CUR:
            new = self._position + offset
        elif whence == os.SEEK_END:
            new = self.media_size + offset
        else:
            raise ValueError(f"invalid whence: {whence}")
        if new < 0:
            raise ValueError("negative seek position")
        self._position = min(new, self.media_size)
        return self._position

    def readinto(self, b) -> int:  # type: ignore[override]
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    def read(self, size: int = -1) -> bytes:  # type: ignore[override]
        if self._position >= self.media_size:
            return b""
        if size is None or size < 0:
            size = self.media_size - self._position
        size = min(size, self.media_size - self._position)
        if size <= 0:
            return b""

        out = bytearray()
        while size > 0 and self._position < self.media_size:
            idx = self._chunk_index_for_position(self._position)
            data = self._load_chunk(idx)
            chunk_start = self._chunk_starts[idx]
            within = self._position - chunk_start
            take = min(size, len(data) - within)
            if take <= 0:
                raise EvidenceFormatError(
                    f"EWF chunk {idx} did not cover logical offset {self._position}"
                )
            out += data[within:within + take]
            self._position += take
            size -= take
        return bytes(out)

    def _chunk_index_for_position(self, position: int) -> int:
        # Chunk sizes are fixed except for the last one, so integer division is
        # normally sufficient.  The bounded correction handles unusual images.
        nominal = max(1, self.info.sectors_per_chunk * self.info.bytes_per_sector)
        idx = min(position // nominal, len(self.info.chunks) - 1)
        while idx + 1 < len(self._chunk_starts) and self._chunk_starts[idx + 1] <= position:
            idx += 1
        while idx > 0 and self._chunk_starts[idx] > position:
            idx -= 1
        return int(idx)

    def _load_chunk(self, index: int) -> bytes:
        if self._cache_index == index:
            return self._cache_data
        chunk = self.info.chunks[index]
        with open(chunk.segment_path, "rb") as fh:
            fh.seek(chunk.start)
            raw = fh.read(chunk.end - chunk.start)
        if len(raw) != chunk.end - chunk.start:
            raise EvidenceFormatError(
                f"Truncated EWF chunk {index} in {chunk.segment_path.name}"
            )

        data: bytes
        if chunk.compressed:
            data = _zlib_decompress(raw, context=f"chunk {index}")
        else:
            # Uncompressed chunks normally carry a trailing Adler-32 checksum.
            if len(raw) >= chunk.expected_size + 4:
                candidate = raw[:chunk.expected_size]
                stored = struct.unpack_from("<I", raw, chunk.expected_size)[0]
                if (zlib.adler32(candidate) & 0xFFFFFFFF) == stored:
                    data = candidate
                else:
                    data = raw[:chunk.expected_size]
            else:
                data = raw[:chunk.expected_size]

        if len(data) < chunk.expected_size:
            # The last chunk is allowed to be short, but parse_ewf has already
            # assigned its exact expected logical size. Anything shorter is a
            # real truncation/decompression problem.
            raise EvidenceFormatError(
                f"Decoded EWF chunk {index} is {len(data)} bytes; "
                f"expected {chunk.expected_size}"
            )
        data = data[:chunk.expected_size]
        self._cache_index = index
        self._cache_data = data
        return data


class BufferedEwfEvidenceStream(io.BufferedReader):
    """Buffered wrapper exposing EwfEvidenceStream metadata attributes."""

    def __init__(self, raw: EwfEvidenceStream):
        self._ewf_raw = raw
        super().__init__(raw, buffer_size=1024 * 1024)
        self.path = raw.path
        self.info = raw.info
        self.media_size = raw.media_size
        self.metadata = raw.metadata
        self.embedded_hashes = raw.embedded_hashes
        self.warnings = raw.warnings


def is_ewf(path: str | Path) -> bool:
    p = Path(path)
    try:
        with open(p, "rb") as fh:
            sig = fh.read(8)
        return sig in (EWF1_SIGNATURE, EWF2_SIGNATURE)
    except OSError:
        return False


def open_evidence_stream(path: str | Path) -> RawEvidenceStream | BufferedEwfEvidenceStream:
    """Open evidence as a seekable logical-media byte stream."""
    p = Path(path).resolve()
    with open(p, "rb") as fh:
        signature = fh.read(8)
    if signature == EWF2_SIGNATURE or p.suffix.lower() == ".ex01":
        raise EvidenceFormatError(
            "EWF2/Ex01 was detected. The native reader currently supports classic "
            "E01 only; the tool will not hash or parse Ex01 container bytes as media."
        )
    if signature == EWF1_SIGNATURE:
        return BufferedEwfEvidenceStream(EwfEvidenceStream(p))
    return RawEvidenceStream(p)


def materialize_media(
    evidence_path: str | Path,
    destination: str | Path,
    *,
    chunk_size: int = 8 * 1024 * 1024,
) -> Path:
    """Reconstruct logical media to a raw file without mount/sudo operations."""
    src = Path(evidence_path).resolve()
    if not is_ewf(src):
        return src
    dest = Path(destination).resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    temporary = dest.with_suffix(dest.suffix + ".partial")
    with open_evidence_stream(src) as stream, open(temporary, "wb") as out:
        while True:
            data = stream.read(chunk_size)
            if not data:
                break
            out.write(data)
        out.flush()
        os.fsync(out.fileno())
    os.replace(temporary, dest)
    return dest


def hash_media_stream(
    evidence_path: str | Path,
    *,
    chunk_size: int = 8 * 1024 * 1024,
) -> dict[str, object]:
    """Hash reconstructed media and return embedded-hash comparison details."""
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()
    total = 0
    with open_evidence_stream(evidence_path) as stream:
        embedded = dict(getattr(stream, "embedded_hashes", {}))
        metadata = dict(getattr(stream, "metadata", {}))
        warnings = list(getattr(stream, "warnings", []))
        while True:
            data = stream.read(chunk_size)
            if not data:
                break
            md5.update(data)
            sha1.update(data)
            sha256.update(data)
            total += len(data)
    computed = {
        "md5": md5.hexdigest(),
        "sha1": sha1.hexdigest(),
        "sha256": sha256.hexdigest(),
    }
    matches = {
        algo: computed[algo] == value.lower()
        for algo, value in embedded.items()
        if algo in computed and value
    }
    return {
        **computed,
        "size_bytes": total,
        "embedded_hashes": embedded,
        "embedded_hash_matches": matches,
        "metadata": metadata,
        "warnings": warnings,
        "stream_type": "ewf" if is_ewf(evidence_path) else "raw",
    }


def independent_sha256(evidence_path: str | Path) -> str:
    """Second top-line hash pass using a deliberately different read size."""
    h = hashlib.sha256()
    with open_evidence_stream(evidence_path) as stream:
        while True:
            data = stream.read(1_048_573)  # prime-ish size; independent chunk boundaries
            if not data:
                break
            h.update(data)
    return h.hexdigest()


def parse_ewf(path: str | Path) -> EwfInfo:
    first = Path(path).resolve()
    segments = _discover_segments(first)
    sections: list[EwfSection] = []
    warnings: list[str] = []

    for seg in segments:
        sections.extend(_parse_segment_sections(seg, warnings))

    metadata = EwfMetadata()
    embedded: dict[str, str] = {}
    chunk_count = sectors_per_chunk = bytes_per_sector = sector_count = 0
    media_type: Optional[int] = None
    media_flags: Optional[int] = None
    compression_level: Optional[int] = None

    for section in sections:
        data = _read_section_data(section)
        if section.section_type in ("header", "header2"):
            try:
                decoded = _decode_header_section(data, section.section_type)
                _merge_header_metadata(metadata, decoded)
            except EvidenceFormatError as exc:
                warnings.append(str(exc))
        elif section.section_type in ("volume", "disk") and not chunk_count:
            try:
                volume = _parse_volume(data)
                chunk_count = volume["chunk_count"]
                sectors_per_chunk = volume["sectors_per_chunk"]
                bytes_per_sector = volume["bytes_per_sector"]
                sector_count = volume["sector_count"]
                media_type = volume.get("media_type")
                media_flags = volume.get("media_flags")
                compression_level = volume.get("compression_level")
            except EvidenceFormatError as exc:
                warnings.append(str(exc))
        elif section.section_type == "digest":
            if len(data) >= 36:
                md5, sha1 = data[:16], data[16:36]
                if any(md5):
                    embedded["md5"] = md5.hex()
                if any(sha1):
                    embedded["sha1"] = sha1.hex()
        elif section.section_type == "hash":
            if len(data) >= 16 and any(data[:16]):
                embedded.setdefault("md5", data[:16].hex())

    # EWF writers vary between Unix-epoch text and six-field calendar text
    # for the m/u metadata columns.  Preserve raw_values, but expose a stable
    # examiner-readable ISO timestamp in the structured metadata.
    metadata.acquisition_date = _normalise_ewf_datetime(
        metadata.raw_values.get("m", "") or metadata.acquisition_date
    )
    metadata.system_date = _normalise_ewf_datetime(
        metadata.raw_values.get("u", "") or metadata.system_date
    )

    if not sectors_per_chunk or not bytes_per_sector:
        raise EvidenceFormatError("EWF volume/disk section did not provide a valid chunk geometry")
    if not sector_count and chunk_count:
        sector_count = chunk_count * sectors_per_chunk
        warnings.append("EWF sector count missing; inferred from chunk geometry")
    media_size = sector_count * bytes_per_sector
    if media_size <= 0:
        raise EvidenceFormatError("EWF media size is zero or invalid")

    chunks = _build_chunk_map(
        sections,
        nominal_chunk_size=sectors_per_chunk * bytes_per_sector,
        media_size=media_size,
        warnings=warnings,
    )
    if not chunks:
        raise EvidenceFormatError("EWF contains no readable table/chunk entries")
    if chunk_count and len(chunks) != chunk_count:
        warnings.append(
            f"EWF volume declares {chunk_count} chunks but {len(chunks)} table entries were parsed"
        )

    return EwfInfo(
        segment_paths=segments,
        sections=sections,
        chunks=chunks,
        metadata=metadata,
        embedded_hashes=embedded,
        chunk_count=chunk_count or len(chunks),
        sectors_per_chunk=sectors_per_chunk,
        bytes_per_sector=bytes_per_sector,
        sector_count=sector_count,
        media_size=media_size,
        media_type=media_type,
        media_flags=media_flags,
        compression_level=compression_level,
        warnings=warnings,
    )


def _discover_segments(first: Path) -> list[Path]:
    with open(first, "rb") as fh:
        sig = fh.read(8)
    if sig == EWF2_SIGNATURE:
        raise EvidenceFormatError("EWF2/Ex01 is not supported by the classic E01 parser")
    if sig != EWF1_SIGNATURE:
        raise EvidenceFormatError(f"Not a classic EWF/E01 file: {first}")

    # Prefer the segment number encoded in each candidate header rather than
    # relying only on extension lexicographic order (.E99 -> .EAA).
    stem = first.stem
    candidates: list[tuple[int, Path]] = []
    for p in first.parent.iterdir():
        if not p.is_file() or p.stem.lower() != stem.lower():
            continue
        try:
            with open(p, "rb") as fh:
                hdr = fh.read(_EWF_FILE_HEADER_SIZE)
            if len(hdr) == _EWF_FILE_HEADER_SIZE and hdr[:8] == EWF1_SIGNATURE:
                seg_no = struct.unpack_from("<H", hdr, 9)[0]
                if seg_no:
                    candidates.append((seg_no, p.resolve()))
        except OSError:
            continue
    if not candidates:
        return [first]
    candidates.sort(key=lambda item: item[0])
    # Reject duplicate segment numbers; using an arbitrary duplicate could
    # silently reconstruct the wrong media stream.
    seen: set[int] = set()
    ordered: list[Path] = []
    for num, p in candidates:
        if num in seen:
            raise EvidenceFormatError(f"Duplicate EWF segment number {num} near {p}")
        seen.add(num)
        ordered.append(p)
    return ordered


def _parse_segment_sections(path: Path, warnings: list[str]) -> list[EwfSection]:
    size = path.stat().st_size
    with open(path, "rb") as fh:
        header = fh.read(_EWF_FILE_HEADER_SIZE)
        if len(header) != _EWF_FILE_HEADER_SIZE or header[:8] != EWF1_SIGNATURE:
            raise EvidenceFormatError(f"Invalid EWF segment header: {path}")
        segment_number = struct.unpack_from("<H", header, 9)[0]
        offset = _EWF_FILE_HEADER_SIZE
        result: list[EwfSection] = []
        visited: set[int] = set()
        while offset + _SECTION_DESCRIPTOR_SIZE <= size:
            if offset in visited:
                warnings.append(f"Section loop detected in {path.name} at offset {offset}")
                break
            visited.add(offset)
            fh.seek(offset)
            raw = fh.read(_SECTION_DESCRIPTOR_SIZE)
            if len(raw) < _SECTION_DESCRIPTOR_SIZE:
                break
            section_type = raw[:16].split(b"\x00", 1)[0].decode("ascii", errors="replace").strip()
            if not section_type:
                warnings.append(f"Blank EWF section type in {path.name} at offset {offset}")
                break
            next_offset = struct.unpack_from("<Q", raw, 16)[0]
            section_size = struct.unpack_from("<Q", raw, 24)[0]
            # Classic EWF section descriptors store an Adler-32 checksum in
            # the final four bytes.  Validate it over the preceding 72 bytes
            # and retain both values.  This is a container-structure check,
            # separate from logical-media digest verification.
            descriptor_checksum_stored = struct.unpack_from("<I", raw, 72)[0]
            descriptor_checksum_computed = zlib.adler32(raw[:72]) & 0xFFFFFFFF
            descriptor_checksum_valid = (
                descriptor_checksum_stored == descriptor_checksum_computed
            )
            if not descriptor_checksum_valid:
                warnings.append(
                    f"EWF section descriptor checksum mismatch in {path.name} "
                    f"at offset {offset}: stored=0x{descriptor_checksum_stored:08x}, "
                    f"computed=0x{descriptor_checksum_computed:08x}"
                )
            if section_size >= _SECTION_DESCRIPTOR_SIZE:
                data_size = section_size - _SECTION_DESCRIPTOR_SIZE
            elif next_offset > offset:
                data_size = max(0, next_offset - offset - _SECTION_DESCRIPTOR_SIZE)
            else:
                data_size = 0
            if offset + _SECTION_DESCRIPTOR_SIZE + data_size > size:
                raise EvidenceFormatError(
                    f"EWF section {section_type!r} exceeds segment boundary in {path.name}"
                )
            result.append(EwfSection(
                segment_path=path,
                segment_number=segment_number,
                section_type=section_type.lower(),
                offset=offset,
                next_offset=next_offset,
                size=section_size,
                data_offset=offset + _SECTION_DESCRIPTOR_SIZE,
                data_size=data_size,
                descriptor_checksum_stored=descriptor_checksum_stored,
                descriptor_checksum_computed=descriptor_checksum_computed,
                descriptor_checksum_valid=descriptor_checksum_valid,
            ))
            if section_type.lower() in ("done", "next", "incomplete"):
                break
            if next_offset <= offset or next_offset > size:
                # Some old writers leave next_offset/size imperfect. Sequential
                # fallback is safe only when a positive section size is present.
                if section_size >= _SECTION_DESCRIPTOR_SIZE:
                    offset += section_size
                    continue
                warnings.append(
                    f"Invalid next-section offset for {section_type} in {path.name}: {next_offset}"
                )
                break
            offset = next_offset
        return result


def _read_section_data(section: EwfSection) -> bytes:
    with open(section.segment_path, "rb") as fh:
        fh.seek(section.data_offset)
        return fh.read(section.data_size)


def _zlib_decompress(data: bytes, *, context: str) -> bytes:
    errors: list[str] = []
    for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS, zlib.MAX_WBITS | 32):
        try:
            return zlib.decompress(data, wbits)
        except zlib.error as exc:
            errors.append(str(exc))
    raise EvidenceFormatError(f"Could not decompress EWF {context}: {errors[-1]}")


def _decode_header_section(data: bytes, section_type: str) -> str:
    payload = data
    try:
        payload = _zlib_decompress(data, context=section_type)
    except EvidenceFormatError:
        # FTK can emit an effectively uncompressed header when compression is 0.
        payload = data
    if section_type == "header2":
        for encoding in ("utf-16", "utf-16-le", "utf-16-be"):
            try:
                text = payload.decode(encoding)
                if "\t" in text or "main" in text.lower():
                    return text
            except UnicodeError:
                continue
        raise EvidenceFormatError("Could not decode EWF header2 metadata as UTF-16")
    for encoding in ("utf-8", "cp1252", "latin-1"):
        try:
            return payload.decode(encoding)
        except UnicodeError:
            continue
    raise EvidenceFormatError("Could not decode EWF header metadata")


_HEADER_KEYS = {
    "c": "case_number",
    "n": "evidence_number",
    "a": "description",
    "e": "examiner",
    "t": "notes",
    "m": "acquisition_date",
    "u": "system_date",
    "av": "acquisition_version",
    "ov": "acquisition_platform",
    "p": "password_hash",
    "r": "compression",
    "md": "model",
    "sn": "serial_number",
    "l": "device_label",
}


def _merge_header_metadata(metadata: EwfMetadata, text: str) -> None:
    lines = [line.rstrip("\x00\r") for line in text.replace("\r\n", "\n").split("\n")]
    values: dict[str, str] = {}
    for i in range(len(lines) - 1):
        ids = [v.strip() for v in lines[i].split("\t")]
        row = lines[i + 1].split("\t")
        if len(ids) < 2 or len(ids) != len(row):
            continue
        if not any(key in _HEADER_KEYS for key in ids):
            continue
        for key, value in zip(ids, row):
            if key in _HEADER_KEYS and value.strip():
                values[key] = value.strip()
    metadata.raw_values.update(values)
    for key, attr in _HEADER_KEYS.items():
        value = values.get(key, "")
        if value and not getattr(metadata, attr):
            setattr(metadata, attr, value)
    if metadata.password_hash:
        metadata.password_state = "not set" if metadata.password_hash == "0" else "set"


def _normalise_ewf_datetime(value: str) -> str:
    """Return an ISO-8601 UTC-like representation for common EWF dates.

    Classic EWF headers are inconsistent: some emit a ten-digit Unix epoch,
    while header/header2 may emit ``YYYY M D H M S``.  A value that cannot be
    interpreted is returned unchanged so reporting never invents a date.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    if text.isdigit() and len(text) in (9, 10, 11):
        try:
            return datetime.fromtimestamp(int(text), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except (OverflowError, OSError, ValueError):
            return text
    parts = text.replace("/", " ").replace("-", " ").replace(":", " ").split()
    if len(parts) == 6 and all(part.isdigit() for part in parts):
        try:
            y, mo, d, h, mi, sec = map(int, parts)
            return datetime(y, mo, d, h, mi, sec, tzinfo=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except ValueError:
            return text
    return text


def _parse_volume(data: bytes) -> dict[str, int]:
    if len(data) >= 1052:
        return {
            "media_type": data[0],
            "chunk_count": struct.unpack_from("<I", data, 4)[0],
            "sectors_per_chunk": struct.unpack_from("<I", data, 8)[0],
            "bytes_per_sector": struct.unpack_from("<I", data, 12)[0],
            "sector_count": struct.unpack_from("<Q", data, 16)[0],
            "media_flags": data[36],
            "compression_level": data[52],
        }
    if len(data) >= 94:
        return {
            "chunk_count": struct.unpack_from("<I", data, 4)[0],
            "sectors_per_chunk": struct.unpack_from("<I", data, 8)[0],
            "bytes_per_sector": struct.unpack_from("<I", data, 12)[0],
            "sector_count": struct.unpack_from("<I", data, 16)[0],
        }
    raise EvidenceFormatError(f"EWF volume section is too short ({len(data)} bytes)")


def _build_chunk_map(
    sections: list[EwfSection],
    *,
    nominal_chunk_size: int,
    media_size: int,
    warnings: list[str],
) -> list[EwfChunk]:
    chunks: list[EwfChunk] = []
    by_segment: dict[Path, list[EwfSection]] = {}
    for section in sections:
        by_segment.setdefault(section.segment_path, []).append(section)

    for seg_path in sorted(by_segment, key=lambda p: min(s.segment_number for s in by_segment[p])):
        seg_sections = sorted(by_segment[seg_path], key=lambda s: s.offset)
        processed_tables: set[tuple[int, ...]] = set()
        for idx, table in enumerate(seg_sections):
            if table.section_type not in ("table", "table2"):
                continue
            data = _read_section_data(table)
            if len(data) < 24:
                warnings.append(f"Short {table.section_type} section in {seg_path.name}")
                continue
            entry_count = struct.unpack_from("<I", data, 0)[0]
            if entry_count <= 0 or 24 + entry_count * 4 > len(data):
                warnings.append(
                    f"Invalid table entry count {entry_count} in {seg_path.name}"
                )
                continue
            base_offset = struct.unpack_from("<Q", data, 8)[0]
            raw_entries = struct.unpack_from(f"<{entry_count}I", data, 24)
            # A table2 mirror repeats both the table base offset and all entry
            # values.  Do NOT deduplicate on raw_entries alone: on highly
            # compressible media (for example mostly-zero USB images), separate
            # genuine tables can contain identical relative entry patterns while
            # referring to different base offsets.  Treating those as mirrors
            # truncates the logical chunk map at the first repeated pattern.
            identity = (base_offset, *raw_entries)
            if identity in processed_tables:
                continue  # table2 mirror of the same physical table
            processed_tables.add(identity)
            offsets = [base_offset + (value & 0x7FFFFFFF) for value in raw_entries]
            compressed = [bool(value & 0x80000000) for value in raw_entries]

            preceding_sectors = None
            for prior in reversed(seg_sections[:idx]):
                if prior.section_type == "sectors":
                    preceding_sectors = prior
                    break
            # EnCase 2+ chunks are in the preceding sectors section. EnCase 1
            # and SMART can store chunks in the table section itself.
            if preceding_sectors and offsets and (
                preceding_sectors.data_offset <= offsets[0] < table.offset
            ):
                final_end = table.offset
            else:
                final_end = table.offset + (table.size or (table.next_offset - table.offset))
                if final_end <= table.offset:
                    final_end = table.next_offset

            for i, start in enumerate(offsets):
                end = offsets[i + 1] if i + 1 < len(offsets) else final_end
                if start < 0 or end <= start or end > seg_path.stat().st_size:
                    warnings.append(
                        f"Rejected invalid EWF chunk extent {start}:{end} in {seg_path.name}"
                    )
                    continue
                remaining = media_size - len(chunks) * nominal_chunk_size
                expected = min(nominal_chunk_size, max(0, remaining))
                if expected <= 0:
                    break
                chunks.append(EwfChunk(
                    segment_path=seg_path,
                    start=start,
                    end=end,
                    compressed=compressed[i],
                    expected_size=expected,
                ))
    return chunks
