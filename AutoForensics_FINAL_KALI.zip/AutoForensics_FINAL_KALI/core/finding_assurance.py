"""Evidence-reference enforcement for AutoForensics findings.

Every finding that enters the canonical findings database must carry a usable,
evidence-derived reference.  The assurance layer is deliberately centralized so
modules cannot accidentally bypass it and so the rule is identical across disk,
memory, network and mobile evidence.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

from modules._base import (
    AssuranceVerdict,
    ModuleResult,
    ModuleStatus,
    SkipReason,
)

_HASH_KEYS = {
    "sha256", "sha-256", "md5", "sha1", "sha-1", "hash", "digest",
    "artifact_sha256", "recovered_sha256", "file_sha256", "content_sha256",
}
_LOCATOR_KEYS = {
    "path", "file_path", "source_path", "internal_path", "original_path",
    "inode", "inode_number", "record", "record_number", "mft_record",
    "cluster", "start_cluster", "sector", "offset", "byte_offset",
    "byte_length", "length", "packet", "packet_number", "frame_number",
    "stream", "stream_id", "tcp_stream", "registry_key", "key_path",
    "url", "uri", "message_id", "rowid", "database", "table",
    "chunk", "chunk_index", "section", "exhibit_id", "evidence_reference",
    "filesystem_type", "filesystem", "offset_sectors", "volume_label",
    "total_sectors", "bytes_per_sector", "sectors_per_cluster",
    "process_id", "pid", "virtual_address", "physical_address",
    "connection", "protocol", "src_ip", "dst_ip", "src_port", "dst_port",
    "archive_member", "member_name", "mobile_artifact", "report_file",
    "source_file", "image_file", "local_path", "extracted_file", "corpus_path",
    # Field-aware record and exact-format locators added in the canonical
    # evidence schema.  These are positions/identifiers, not semantic guesses.
    "line", "line_number", "csv_row", "json_path", "field_name",
    "value_name", "value_data", "offset_bytes", "source_offset",
    "logical_end_offset", "structured_length", "size_bytes",
    "volume_serial", "volume_serial_raw", "visit_time", "start_time",
    "end_time", "last_access_time", "coordinate_source",
    "content_occurrence_index", "content_occurrence_count",
}


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes):
        return {"encoding": "hex", "value": value.hex()}
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_json_safe(v) for v in value]
    return str(value)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _flatten_metadata(value: Any, prefix: str = "") -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            yield from _flatten_metadata(child, child_prefix)
    elif isinstance(value, (list, tuple)):
        # Lists are often samples rather than stable locators. Keep only a
        # compact count; individual sample rows remain in the finding metadata.
        if prefix:
            yield prefix + ".count", len(value)
    else:
        yield prefix, value


def build_evidence_reference(
    finding: Any,
    *,
    exhibit_id: str,
    source_evidence_path: str,
    source_evidence_sha256: str = "",
    logical_media_sha256: str = "",
) -> dict[str, Any]:
    """Build a canonical, independently usable reference for one finding."""
    metadata = dict(getattr(finding, "metadata", {}) or {})
    existing = getattr(finding, "evidence_reference", None)
    if isinstance(existing, dict):
        reference: dict[str, Any] = dict(existing)
    elif existing:
        reference = {"exhibit_id": str(existing)}
    else:
        reference = {}

    reference.setdefault("exhibit_id", exhibit_id)
    # Explicit container/media naming prevents an E01 path from being paired
    # with the reconstructed logical-media digest.
    reference.setdefault("source_evidence", source_evidence_path)  # legacy display key
    reference.setdefault("source_container_path", source_evidence_path)
    if source_evidence_sha256:
        reference.setdefault("source_evidence_sha256", source_evidence_sha256)  # legacy
        reference.setdefault("source_container_sha256", source_evidence_sha256)
    if logical_media_sha256:
        reference.setdefault("logical_media_sha256", logical_media_sha256)

    evidence_path = str(getattr(finding, "evidence_path", "") or "").strip()
    if evidence_path:
        reference.setdefault("artefact_location", evidence_path)

    artifact_path_text = str(getattr(finding, "artifact_path", "") or "").strip()
    if artifact_path_text:
        artifact = Path(artifact_path_text)
        if artifact.is_file():
            reference["retained_artifact"] = str(artifact.resolve())
            reference["retained_artifact_size"] = artifact.stat().st_size
            reference["retained_artifact_sha256"] = _sha256_file(artifact)

    locators: dict[str, Any] = {}
    hashes: dict[str, Any] = {}
    for dotted_key, value in _flatten_metadata(metadata):
        if value in (None, "", [], {}):
            continue
        leaf = dotted_key.rsplit(".", 1)[-1].lower().replace("-", "_")
        normalized = leaf.replace("_", "-")
        if leaf in _LOCATOR_KEYS or normalized in _LOCATOR_KEYS:
            locators[dotted_key] = _json_safe(value)
        if leaf in {k.replace("-", "_") for k in _HASH_KEYS}:
            hashes[dotted_key] = _json_safe(value)

    if locators:
        reference["locators"] = locators
    if hashes:
        reference["artefact_hashes"] = hashes

    # Bind the reference to the exact finding content. This is not a claim
    # about the evidence; it is a deterministic identifier for the record.
    binding_payload = {
        "finding_id": str(getattr(finding, "finding_id", "")),
        "finding_type": str(getattr(finding, "finding_type", "")),
        "description": str(getattr(finding, "description", "")),
        "reference": reference,
    }
    reference["finding_record_sha256"] = hashlib.sha256(
        json.dumps(binding_payload, sort_keys=True, ensure_ascii=True, default=str).encode("utf-8")
    ).hexdigest()
    return reference


def validate_evidence_reference(reference: dict[str, Any]) -> tuple[bool, str]:
    """Return whether a reference meets the platform's H2 traceability gate."""
    if not str(reference.get("exhibit_id") or "").strip():
        return False, "missing exhibit identifier"
    if not str(reference.get("source_evidence") or "").strip():
        return False, "missing source evidence path"

    source = str(reference.get("source_evidence") or "").strip()
    location = str(reference.get("artefact_location") or "").strip()
    # The whole-image path by itself is not a specific artefact reference.  It
    # becomes sufficient only when paired with a hash or a structural/raw
    # locator (sector, inode, packet, registry key, process address, etc.).
    has_specific_location = bool(location and Path(location) != Path(source))
    has_artifact = bool(reference.get("retained_artifact_sha256"))
    has_locator = bool(reference.get("locators"))
    has_hash = bool(reference.get("artefact_hashes"))
    if not any((has_specific_location, has_artifact, has_locator, has_hash)):
        return False, "no specific artefact path, retained-artifact hash, raw locator, or network/log reference"
    return True, ""


def assure_module_result(
    result: ModuleResult,
    *,
    exhibit_id: str,
    source_evidence_path: str,
    source_evidence_sha256: str = "",
    logical_media_sha256: str = "",
) -> tuple[list[Any], list[dict[str, Any]]]:
    """Attach references, reject unsupported findings, and reconcile verdicts.

    Returns ``(accepted_findings, rejected_records)``. Rejected observations are
    retained in module statistics for auditability but never enter the canonical
    findings store or a PRESENT verdict.
    """
    accepted: list[Any] = []
    rejected: list[dict[str, Any]] = []

    for finding in list(getattr(result, "findings", []) or []):
        reference = build_evidence_reference(
            finding,
            exhibit_id=exhibit_id,
            source_evidence_path=source_evidence_path,
            source_evidence_sha256=source_evidence_sha256,
            logical_media_sha256=logical_media_sha256,
        )
        metadata = dict(getattr(finding, "metadata", {}) or {})
        basis = str(metadata.get("finding_basis") or "").strip().lower()
        deterministic = bool(metadata.get("deterministic_validation"))
        # Candidate generators remain available, but a candidate can never be
        # promoted to PRESENT unless an explicit reproducible validator passed.
        if basis in {"heuristic", "candidate", "probabilistic"} and not deterministic:
            ok, reason = False, (
                "candidate observation was not promoted: no deterministic validator confirmed the claimed property"
            )
        else:
            ok, reason = validate_evidence_reference(reference)
        if ok:
            finding.evidence_reference = reference
            accepted.append(finding)
        else:
            rejected.append({
                "finding_id": str(getattr(finding, "finding_id", "")),
                "finding_type": str(getattr(finding, "finding_type", "")),
                "reason": reason,
                "description": str(getattr(finding, "description", ""))[:500],
            })

    result.findings = accepted
    stats = dict(getattr(result, "statistics", {}) or {})
    stats["finding_assurance"] = {
        "accepted": len(accepted),
        "rejected": len(rejected),
        "policy": "Every PRESENT finding must carry a specific evidence reference and any heuristic/probabilistic candidate must pass an explicit deterministic validator.",
        "rejected_findings": rejected,
    }
    result.statistics = stats

    if rejected:
        result.errors = list(getattr(result, "errors", []) or []) + [
            f"Finding assurance rejected {len(rejected)} unsupported observation(s); they were not reported as PRESENT."
        ]
        if result.status == ModuleStatus.COMPLETED:
            result.status = ModuleStatus.PARTIAL

    # Reconcile class-level PRESENT counts with the accepted finding set. A
    # module may summarize several raw artefacts into one finding, so preserve
    # explicitly summarised counts while preventing unsupported PRESENT verdicts.
    for class_result in list(getattr(result, "class_results", []) or []):
        if class_result.verdict == AssuranceVerdict.PRESENT and not accepted:
            class_result.verdict = AssuranceVerdict.INDETERMINATE
            class_result.skip_reason = SkipReason.PARTIAL_FAILURE
            class_result.count = 0
            note = "No evidence-referenced finding passed the H2 assurance gate."
            class_result.notes = (str(class_result.notes or "") + " " + note).strip()
        elif class_result.verdict == AssuranceVerdict.PRESENT and not getattr(class_result, "summarised", False):
            class_result.count = min(int(getattr(class_result, "count", 0) or 0), len(accepted)) or len(accepted)

    return accepted, rejected
