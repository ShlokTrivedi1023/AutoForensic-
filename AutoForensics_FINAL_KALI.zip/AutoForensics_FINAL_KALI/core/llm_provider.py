"""Optional OpenAI-only narrative synthesis for AutoForensics.

The forensic pipeline and accepted-finding ledger never depend on this module.
If OPENAI_API_KEY is absent or a request fails, callers must use the deterministic
report summary. The key is read only from the environment and is never logged.
"""
from __future__ import annotations

import errno
import json
import logging
import os
import re
import urllib.error
import urllib.request
import time
from typing import Optional

logger = logging.getLogger("autoforensics.llm_provider")
_OPENAI_ENDPOINT = "https://api.openai.com/v1/chat/completions"
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
DEFAULT_OPENAI_MAX_TOKENS = 12000
DEFAULT_OPENAI_TIMEOUT_SECONDS = 120
_KEY_RE = re.compile(r"sk-[A-Za-z0-9_-]{8,}")
_LAST_CALL_TELEMETRY: dict[str, object] = {}


class LLMUnavailable(RuntimeError):
    """Raised when optional OpenAI narrative synthesis is unavailable."""


def last_call_telemetry() -> dict[str, object]:
    """Return a copy of the most recent provider telemetry without secrets."""
    return dict(_LAST_CALL_TELEMETRY)


def openai_available() -> bool:
    return bool(os.environ.get("OPENAI_API_KEY", "").strip())


def _scrub(text: str, key: Optional[str]) -> str:
    text = _KEY_RE.sub("REDACTED", text or "")
    if key:
        text = text.replace(key, "REDACTED")
    return text


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _is_connection_error(exc: BaseException) -> bool:
    reason = getattr(exc, "reason", exc)
    for candidate in (exc, reason):
        if isinstance(candidate, (ConnectionRefusedError, ConnectionResetError)):
            return True
        if isinstance(candidate, OSError) and getattr(candidate, "errno", None) in (
            errno.ECONNREFUSED, errno.ECONNRESET,
        ):
            return True
    return False


def synthesize(
    prompt: str,
    *,
    purpose: str = "report_narrative",
    max_tokens: int = DEFAULT_OPENAI_MAX_TOKENS,
    temperature: float = 0.2,
    timeout: int = DEFAULT_OPENAI_TIMEOUT_SECONDS,
) -> str:
    """Use OpenAI only; accepted findings are supplied by the caller."""
    provider = os.environ.get("LLM_PROVIDER", "openai").strip().lower()
    if provider not in {"openai", ""}:
        raise LLMUnavailable(
            f"Unsupported LLM_PROVIDER={provider!r}; the final build permits only 'openai'."
        )
    return _synthesize_openai(
        prompt, purpose=purpose, max_tokens=max_tokens,
        temperature=temperature, timeout=timeout,
    )


def _synthesize_openai(
    prompt: str,
    *,
    purpose: str = "report_narrative",
    max_tokens: int = DEFAULT_OPENAI_MAX_TOKENS,
    temperature: float = 0.2,
    timeout: int = DEFAULT_OPENAI_TIMEOUT_SECONDS,
) -> str:
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise LLMUnavailable(
            "OPENAI_API_KEY is not set; optional narrative enhancement was skipped."
        )
    model = os.environ.get("OPENAI_MODEL", DEFAULT_OPENAI_MODEL).strip() or DEFAULT_OPENAI_MODEL
    max_tokens = _env_int("OPENAI_MAX_TOKENS", max_tokens)
    timeout = _env_int("OPENAI_TIMEOUT", timeout)
    body = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if os.environ.get("OPENAI_JSON_MODE", "1").strip().lower() not in {"0", "false", "no", "off"}:
        body["response_format"] = {"type": "json_object"}
    request = urllib.request.Request(
        _OPENAI_ENDPOINT,
        data=json.dumps(body).encode("utf-8"),
        method="POST",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    logger.info("OpenAI narrative synthesis: model=%s purpose=%s", model, purpose)
    started = time.monotonic()
    _LAST_CALL_TELEMETRY.clear()
    _LAST_CALL_TELEMETRY.update({"provider": "openai", "model": model, "purpose": purpose, "success": False})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = getattr(response, "status", None) or getattr(response, "code", 200)
            raw = response.read()
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", "replace")[:500]
        except Exception:
            pass
        raise LLMUnavailable(
            f"OpenAI HTTP {exc.code} ({exc.reason}) for model={model}: {_scrub(detail, key)}"
        ) from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        if _is_connection_error(exc):
            raise LLMUnavailable(f"OpenAI not reachable for model={model}; check connectivity.") from None
        raise LLMUnavailable(
            f"OpenAI request failed for model={model}: {_scrub(str(getattr(exc, 'reason', exc)), key)}"
        ) from None
    try:
        payload = json.loads(raw.decode("utf-8"))
        text = payload["choices"][0]["message"]["content"]
    except (ValueError, UnicodeDecodeError, KeyError, IndexError, TypeError):
        raise LLMUnavailable(
            f"OpenAI returned an unusable response (HTTP {status}) for model={model}."
        ) from None
    if not isinstance(text, str) or not text.strip():
        raise LLMUnavailable(f"OpenAI returned an empty completion for model={model}.")
    usage = payload.get("usage") if isinstance(payload, dict) else None
    usage = usage if isinstance(usage, dict) else {}
    _LAST_CALL_TELEMETRY.update({
        "success": True,
        "input_tokens": usage.get("prompt_tokens"),
        "output_tokens": usage.get("completion_tokens"),
        "total_tokens": usage.get("total_tokens"),
        "duration_ms": max(1, int((time.monotonic() - started) * 1000)),
        "response_id": payload.get("id") if isinstance(payload, dict) else None,
    })
    return text
