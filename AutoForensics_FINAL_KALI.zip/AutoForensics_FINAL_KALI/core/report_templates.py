"""
Deterministic narrative templates for each forensic module.
Every concrete value in the prose comes from a finding's metadata field.
No hardcoded case-specific text.
"""
from __future__ import annotations
from typing import Any


def registry_narrative(findings: list[dict]) -> str:
    accounts  = [f for f in findings if f.get("finding_type") == "USER_ACCOUNT"]
    usb_devs  = [f for f in findings if f.get("finding_type") == "USB_DEVICE"]
    programs  = [f for f in findings if f.get("finding_type") == "INSTALLED_PROGRAM"]
    comp_name = next(
        (f.get("metadata", {}).get("computer_name")
         for f in findings if f.get("finding_type") == "COMPUTER_NAME"),
        None
    )
    parts: list[str] = []
    if comp_name:
        parts.append(f"Registry analysis identified the computer name as '{comp_name}'.")
    if accounts:
        parts.append(f"The SAM hive contained {len(accounts)} local user account(s).")
    if usb_devs:
        parts.append(
            f"USBSTOR enumeration identified {len(usb_devs)} USB storage device(s) "
            f"previously connected to the system."
        )
    if programs:
        parts.append(f"SOFTWARE hive analysis identified {len(programs)} installed program(s).")
    if not parts:
        return "Registry analysis produced no findings for this evidence item."
    return " ".join(parts)


def filesystem_narrative(findings: list[dict]) -> str:
    deleted    = [f for f in findings if f.get("finding_type") == "DELETED_FILE"]
    mismatches = [f for f in findings if f.get("finding_type") == "EXTENSION_MISMATCH"]
    ads        = [f for f in findings if f.get("finding_type") == "ALTERNATE_DATA_STREAM"]
    parts: list[str] = []
    if deleted:
        parts.append(f"Filesystem analysis identified {len(deleted)} deleted file(s).")
    if mismatches:
        parts.append(
            f"{len(mismatches)} file(s) exhibited extension mismatches, "
            f"which is an observable filename/content anomaly. The mismatch does not, by itself, establish user intent, execution, or an anti-forensic act."
        )
    if ads:
        parts.append(f"{len(ads)} NTFS Alternate Data Stream(s) were detected.")
    if not parts:
        return "Filesystem deep analysis produced no notable findings for this evidence item."
    return " ".join(parts)


def email_narrative(findings: list[dict]) -> str:
    messages = [f for f in findings if f.get("finding_type") in ("EMAIL_MESSAGE", "DBX_MESSAGE")]
    contacts = {
        f.get("metadata", {}).get("from", "") for f in messages
        if f.get("metadata")
    } - {""}
    parts: list[str] = []
    if messages:
        parts.append(f"Email analysis recovered {len(messages)} message(s).")
    if contacts:
        parts.append(f"Unique sender addresses: {len(contacts)}.")
    return " ".join(parts) or "Email analysis produced no findings for this evidence item."


_TEMPLATES: dict[str, Any] = {
    "windows_registry_analyzer":      registry_narrative,
    "filesystem_deep_analyzer":       filesystem_narrative,
    "email_communications_analyzer":  email_narrative,
}


def render_module_narrative(module_name: str, findings: list[dict]) -> str:
    """Return prose narrative for a module's findings. Falls back to a count summary."""
    fn = _TEMPLATES.get(module_name)
    if fn:
        return fn(findings)
    if findings:
        return (
            f"Analysis identified {len(findings)} finding(s). "
            f"See the detailed findings table for full details."
        )
    return "Analysis produced no findings for this evidence item."
