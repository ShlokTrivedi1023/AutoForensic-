"""Canonical four-state evidence ledger helpers.

This module is case-neutral.  It never reads validation references or expected
answers.  It only classifies observations from their runtime validation metadata.
"""
from __future__ import annotations

from enum import Enum
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


class LedgerState(str, Enum):
    ACCEPTED = "ACCEPTED"
    CANDIDATE = "CANDIDATE"
    REJECTED = "REJECTED"
    UNRESOLVED = "UNRESOLVED"


_SPECIALIST_UNRESOLVED = {"foremost_carver", "scalpel_carver"}


def _text(metadata: dict[str, Any]) -> str:
    fields = (
        "candidate_reason", "semantic_limit", "validation_status",
        "validation_error", "rejection_reason", "candidate_method",
    )
    return " ".join(str(metadata.get(k) or "") for k in fields).casefold()


def infer_candidate_state(module_name: str, metadata: dict[str, Any]) -> LedgerState:
    """Infer a fail-closed ledger state from explicit runtime metadata.

    An explicit state always wins.  Otherwise, structurally failed candidates are
    rejected, specialist outputs that still require correlation are unresolved,
    and probabilistic/heuristic interpretations remain candidates.
    """
    explicit = str(
        metadata.get("ledger_state")
        or metadata.get("candidate_state")
        or metadata.get("observation_state")
        or ""
    ).upper().strip()
    if explicit in {state.value for state in LedgerState}:
        return LedgerState(explicit)

    fact_class = str(metadata.get("fact_class") or "").upper()
    if fact_class == "REJECTED" or metadata.get("rejected") is True:
        return LedgerState.REJECTED

    text = _text(metadata)
    rejected_markers = (
        "did not pass", "failed structural", "malformed", "invalid candidate",
        "not a valid", "parser rejected", "structure validator rejected",
        "source role derived_tool_output", "derived tool output may control/describe",
    )
    if any(marker in text for marker in rejected_markers):
        return LedgerState.REJECTED

    unresolved_markers = (
        "independent validation is required", "pending structural validation",
        "requires correlation", "requires specialist", "could not be resolved",
        "overlap remains", "unresolved",
    )
    if module_name in _SPECIALIST_UNRESOLVED or any(marker in text for marker in unresolved_markers):
        return LedgerState.UNRESOLVED

    return LedgerState.CANDIDATE


def canonical_candidate_id(module_name: str, record: dict[str, Any]) -> str:
    metadata = dict(record.get("metadata") or {})
    payload = {
        "module": module_name,
        "finding_type": str(record.get("finding_type") or ""),
        "description": str(record.get("description") or ""),
        "source": str(
            metadata.get("provenance_source_path")
            or metadata.get("source_file")
            or metadata.get("file_path")
            or metadata.get("image_file")
            or ""
        ),
        "locator": {
            key: metadata.get(key)
            for key in (
                "raw_offset", "offset_bytes", "byte_offset", "source_offset",
                "source_start", "source_end", "source_length", "file_name",
                "inode", "cluster", "packet_number", "frame_number", "rowid",
                "line", "json_path", "message_index",
            )
            if metadata.get(key) not in (None, "", [], {})
        },
    }
    digest = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()
    return f"co-{digest[:32]}"


def normalise_candidate_records(
    module_name: str, records: Iterable[dict[str, Any]]
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    normalised: list[dict[str, Any]] = []
    counts = {state.value: 0 for state in LedgerState}
    for raw in records:
        record = dict(raw or {})
        metadata = dict(record.get("metadata") or {})
        state = infer_candidate_state(module_name, metadata)
        metadata["ledger_state"] = state.value
        metadata["counts_toward_unique_evidence"] = False
        metadata["candidate_only"] = state in {LedgerState.CANDIDATE, LedgerState.UNRESOLVED}
        if state == LedgerState.REJECTED:
            metadata["fact_class"] = "REJECTED"
        else:
            metadata.setdefault("fact_class", "CANDIDATE_ONLY")
        record["metadata"] = metadata
        record["ledger_state"] = state.value
        record["candidate_id"] = canonical_candidate_id(module_name, record)
        counts[state.value] += 1
        normalised.append(record)
    return normalised, counts



def load_candidate_records(
    module_name: str,
    path: str | Path | None,
) -> tuple[list[dict[str, Any]], dict[str, int], str | None]:
    """Load and normalise one retained candidate ledger.

    The same helper is used by completion certification and the H2 audit so
    both assurance layers derive counts from the exact same runtime records.
    Missing ledgers are harmless only when no ledger path was declared; a
    declared but unreadable ledger fails closed through the returned error.
    """
    empty = {state.value: 0 for state in LedgerState}
    if path in (None, ""):
        return [], empty, None

    ledger_path = Path(str(path))
    if not ledger_path.is_file():
        return [], empty, f"candidate ledger not found: {ledger_path}"

    try:
        data = json.loads(ledger_path.read_text(encoding="utf-8", errors="strict"))
    except Exception as exc:
        return [], empty, f"candidate ledger unreadable: {ledger_path}: {exc}"

    records: list[dict[str, Any]]
    if isinstance(data, list):
        records = [item for item in data if isinstance(item, dict)]
    elif isinstance(data, dict):
        records = []
        for key in ("candidates", "observations", "records", "items"):
            value = data.get(key)
            if isinstance(value, list):
                records = [item for item in value if isinstance(item, dict)]
                break
        else:
            return [], empty, f"candidate ledger has no supported record list: {ledger_path}"
    else:
        return [], empty, f"candidate ledger is not a JSON object or list: {ledger_path}"

    normalised, counts = normalise_candidate_records(module_name, records)
    return normalised, counts, None


def candidate_ledger_path(statistics: dict[str, Any]) -> str:
    """Return the runtime candidate-ledger path recorded by reconciliation."""
    recon = statistics.get("deterministic_reconciliation") or {}
    if isinstance(recon, dict):
        value = recon.get("candidate_file")
        if value not in (None, ""):
            return str(value)
    value = statistics.get("candidate_file")
    return str(value) if value not in (None, "") else ""

def reconciliation_counts(statistics: dict[str, Any]) -> dict[str, int]:
    recon = statistics.get("deterministic_reconciliation") or {}
    ledger = recon.get("ledger_counts") or statistics.get("ledger_counts") or {}
    def value(name: str, fallback: int = 0) -> int:
        try:
            return int(ledger.get(name) if name in ledger else recon.get(name, fallback) or 0)
        except (TypeError, ValueError):
            return fallback
    candidate = value("CANDIDATE", value("candidate_observations", 0))
    rejected = value("REJECTED", value("rejected_observations", 0))
    unresolved = value("UNRESOLVED", value("unresolved_observations", 0))
    return {
        "candidate": candidate,
        "rejected": rejected,
        "unresolved": unresolved,
        "total_nonaccepted": candidate + rejected + unresolved,
    }


def ledger_counts(records):
    """Return four-state ledger counts for records or normalised dictionaries."""
    counts = {state.value: 0 for state in LedgerState}
    for record in records or []:
        if isinstance(record, dict):
            state = str(record.get("ledger_state") or (record.get("metadata") or {}).get("ledger_state") or "").upper()
            if state not in counts:
                state = infer_candidate_state(str(record.get("module_name") or ""), dict(record.get("metadata") or {})).value
            counts[state] += 1
    return counts
