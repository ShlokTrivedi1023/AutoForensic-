"""
core/custody_log.py — Chain of Custody Ledger for Auto Forensics

Implements an append-only, hash-chained audit ledger (.jsonl) with a
human-readable companion (.txt). The design is intentionally tamper-evident and independently verifiable:

  - Every entry hashes the previous entry's hash, so any insertion,
    deletion, modification, or reordering anywhere in the log breaks the
    chain and is mathematically detectable.
  - Each entry is flushed and fsync'd to disk immediately — a crash cannot
    produce a log that is ahead of what was actually persisted.
  - At case close, seal() computes a final seal hash and signs it with
    HMAC-SHA256, so post-seal tampering with the seal file itself is also
    detectable.
  - Log files are set read-only (0o400) after sealing to prevent accidental
    modification by the OS or other processes.

Injected into ForensicOrchestrator — never instantiated inside it — so
it can be independently tested and swapped for a test double.
"""

import hashlib
import hmac
import json
import logging
import os
import re
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Event type taxonomy
# Each event type maps to exactly one forensic action so the CoC reads like
# a narrative: what happened, in what order, performed by whom.
# ---------------------------------------------------------------------------

class EventType(str, Enum):
    """All event types that can appear in the chain of custody ledger."""

    INVESTIGATION_STARTED  = "INVESTIGATION_STARTED"
    AUTH_SUCCESS           = "AUTH_SUCCESS"
    AUTH_FAILURE           = "AUTH_FAILURE"
    CASE_REGISTERED        = "CASE_REGISTERED"
    DEVICE_DETECTED        = "DEVICE_DETECTED"
    WRITE_BLOCK_VERIFIED   = "WRITE_BLOCK_VERIFIED"
    WRITE_BLOCK_UNVERIFIED = "WRITE_BLOCK_UNVERIFIED"
    IMAGE_STARTED          = "IMAGE_STARTED"
    IMAGE_CREATED          = "IMAGE_CREATED"
    HASH_VERIFIED          = "HASH_VERIFIED"
    HASH_MISMATCH          = "HASH_MISMATCH"
    EVIDENCE_ACCEPTED      = "EVIDENCE_ACCEPTED"
    EVIDENCE_REJECTED      = "EVIDENCE_REJECTED"
    MODULE_LOADED          = "MODULE_LOADED"
    MODULE_STARTED         = "MODULE_STARTED"
    MODULE_COMPLETED       = "MODULE_COMPLETED"
    MODULE_INCOMPLETE      = "MODULE_INCOMPLETE"
    MODULE_FAILED          = "MODULE_FAILED"
    MODULE_SKIPPED         = "MODULE_SKIPPED"
    MODULE_OBSERVATION     = "MODULE_OBSERVATION"
    FINDING_RECORDED       = "FINDING_RECORDED"
    FINDING_REJECTED       = "FINDING_REJECTED"
    REPORT_GENERATED       = "REPORT_GENERATED"
    REPORT_SIGNED          = "REPORT_SIGNED"
    BENCHMARK_EVALUATED    = "BENCHMARK_EVALUATED"
    INVESTIGATION_SEALED   = "INVESTIGATION_SEALED"
    ERROR                  = "ERROR"


# ---------------------------------------------------------------------------
# CustodyEntry — a single hash-bound log record
# ---------------------------------------------------------------------------

class CustodyEntry:
    """
    A single chain of custody record.

    Hash-bound after construction: the self_hash is computed in __init__
    and covers every field including previous_hash. Mutating any field
    after construction would leave self_hash stale, which is intentional —
    the stale hash would then fail chain verification, catching the mutation.

    Fields
    ------
    timestamp       UTC ISO-8601 with millisecond precision. Courts require
                    precise, unambiguous timestamps; UTC avoids DST ambiguity.
    entry_id        UUID4 — unique even if two entries share the same timestamp
                    (e.g., rapid module starts).
    event_type      One of EventType — narrow vocabulary keeps the ledger
                    machine-parseable without a schema document.
    investigator_id Who performed or witnessed this action.
    case_id         Which case this entry belongs to.
    description     Human-readable narrative of the event.
    evidence_path   Filesystem path of the evidence being acted on, if any.
    metadata        Arbitrary key-value pairs for event-specific detail.
    previous_hash   SHA-256 of the previous entry's self_hash (or "GENESIS"
                    for the first entry). This is what makes the chain.
    self_hash       SHA-256 of all fields above, computed on construction.
                    Stored in the ledger alongside the entry so a verifier
                    can check it without recomputing from scratch.
    """

    __slots__ = (
        "timestamp", "entry_id", "event_type", "investigator_id",
        "case_id", "description", "evidence_path", "metadata",
        "previous_hash", "self_hash",
    )

    def __init__(
        self,
        event_type: EventType,
        investigator_id: str,
        case_id: str,
        description: str,
        previous_hash: str,
        evidence_path: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        # UTC with millisecond precision — no local timezone ambiguity in court records
        self.timestamp       = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
        self.entry_id        = str(uuid.uuid4())
        self.event_type      = event_type.value
        self.investigator_id = investigator_id
        self.case_id         = case_id
        self.description     = description
        self.evidence_path   = evidence_path
        # Defensive copy so callers cannot mutate the stored dict post-construction
        self.metadata        = dict(metadata) if metadata else {}
        self.previous_hash   = previous_hash
        # Compute hash last — it covers all fields set above
        self.self_hash       = self._compute_self_hash()

    def _compute_self_hash(self) -> str:
        """
        SHA-256 over the canonical JSON serialization of this entry's content.

        sort_keys=True ensures the serialization is deterministic regardless
        of Python dict insertion order across versions. ensure_ascii=True
        prevents encoding-dependent differences in the hash input.
        """
        content = {
            "timestamp":       self.timestamp,
            "entry_id":        self.entry_id,
            "event_type":      self.event_type,
            "investigator_id": self.investigator_id,
            "case_id":         self.case_id,
            "description":     self.description,
            "evidence_path":   self.evidence_path,
            "metadata":        self.metadata,
            "previous_hash":   self.previous_hash,
        }
        serialized = json.dumps(content, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Return the entry as a plain dict for JSON serialization."""
        return {
            "timestamp":       self.timestamp,
            "entry_id":        self.entry_id,
            "event_type":      self.event_type,
            "investigator_id": self.investigator_id,
            "case_id":         self.case_id,
            "description":     self.description,
            "evidence_path":   self.evidence_path,
            "metadata":        self.metadata,
            "previous_hash":   self.previous_hash,
            "self_hash":       self.self_hash,
        }

    def to_human_readable(self) -> str:
        """
        Produce a plain-text block for the companion .txt log.

        Judges and lawyers read the companion; this format is designed to be
        unambiguous without requiring JSON knowledge.
        """
        lines = [
            f"[{self.timestamp}]  {self.event_type}",
            f"  Case ID:      {self.case_id}",
            f"  Investigator: {self.investigator_id}",
            f"  Description:  {self.description}",
        ]
        if self.evidence_path:
            lines.append(f"  Evidence:     {self.evidence_path}")
        if self.metadata:
            for key, value in sorted(self.metadata.items()):
                lines.append(f"  {key}: {value}")
        lines.append(f"  Entry Hash:   {self.self_hash}")
        lines.append(f"  Prev Hash:    {self.previous_hash}")
        lines.append("")   # Blank line between entries for readability
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# CustodyLogger — the append-only ledger
# ---------------------------------------------------------------------------

class CustodyLogger:
    """
    Append-only, hash-chained chain of custody logger.

    Writes two parallel output files for every investigation:

    <case_id>_custody.jsonl
        Machine-readable ledger. Each line is one JSON object (CustodyEntry).
        Each entry's previous_hash field links it to the prior entry, forming
        a hash chain. Tamper-detection is O(n) — re-hash every entry and check
        the chain. This file is the forensic authority.

    <case_id>_custody.txt
        Human-readable companion. Plain timestamped narrative, one block per
        event. Intended for printing, physical signing, and non-technical review
        (judges, lawyers, reviewing boards). Not the tamper-evident document —
        that is the .jsonl file.

    <case_id>_custody_seal.json
        Written at seal() time. Contains the final chain hash, entry count,
        start/end timestamps, and an HMAC-SHA256 over the seal content so
        post-seal tampering with the seal file itself is detectable.

    Usage
    -----
    Instantiate once per investigation, inject into ForensicOrchestrator.
    Call log() for every significant event. Call seal() at case close — after
    sealing, log() raises RuntimeError and all files become read-only.

    Thread Safety
    -------------
    Not thread-safe. Auto Forensics runs modules sequentially in one process,
    so this is intentional. If parallel modules are added later, add a lock
    around log().
    """

    def __init__(
        self,
        output_dir: Path,
        case_id: str,
        investigator_id: str,
        hmac_key: Optional[bytes] = None,
    ) -> None:
        """
        Parameters
        ----------
        output_dir      Directory where log files are written. Created (0o700)
                        if it does not exist. Strict permissions because this
                        directory contains forensic evidence logs.
        case_id         Used to name the log files.
        investigator_id Recorded in every entry where no override is given.
        hmac_key        32-byte key for the HMAC seal. In production, supply
                        this from a key-management service or a per-case HSM
                        key. If None, a random key is generated (good for
                        integrity verification within this session; the key
                        must be preserved externally for later re-verification).
        """
        self._output_dir      = output_dir
        self._case_id         = case_id
        self._investigator_id = investigator_id
        self._hmac_key_path: Optional[Path] = None
        self._hmac_key_source = "supplied-by-caller"
        if hmac_key is not None:
            if len(hmac_key) < 32:
                raise ValueError("Chain-of-custody HMAC key must be at least 32 bytes")
            self._hmac_key = bytes(hmac_key)
        else:
            self._hmac_key, self._hmac_key_path, self._hmac_key_source = self._load_or_create_hmac_key(
                case_id
            )

        self._entries: list[CustodyEntry] = []
        # "GENESIS" is the sentinel for the first entry's previous_hash field.
        # It is a fixed known string so verifiers know what to expect.
        self._previous_hash = "GENESIS"

        self._sealed = False
        self._start_timestamp = datetime.now(timezone.utc).isoformat(timespec="milliseconds")

        # Prepare output directory with owner-only permissions
        output_dir.mkdir(parents=True, exist_ok=True)
        # 0o700 = rwx for owner only — log files must not be world-readable
        os.chmod(output_dir, 0o700)

        # Build file paths using a sanitized case_id to prevent filesystem issues
        safe_id = self._sanitize_filename(case_id)
        self._ledger_path    = output_dir / f"{safe_id}_custody.jsonl"
        self._companion_path = output_dir / f"{safe_id}_custody.txt"
        self._seal_path      = output_dir / f"{safe_id}_custody_seal.json"

        # Archive any existing log files from a prior investigation with the same
        # case ID so the new chain always starts clean from GENESIS.
        _ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        for _path in (self._ledger_path, self._companion_path, self._seal_path):
            if _path.exists():
                try:
                    os.chmod(_path, 0o600)
                except OSError:
                    pass
                _path.rename(_path.with_suffix(f".{_ts}{_path.suffix}"))

        # Open fresh files — each new investigation starts with a clean chain
        self._ledger_fh    = open(self._ledger_path, "w", encoding="utf-8")
        self._companion_fh = open(self._companion_path, "w", encoding="utf-8")

        self._logger = logging.getLogger(__name__)

    @property
    def hmac_key_path(self) -> Optional[Path]:
        """Path to the separately preserved verification key, when file-backed."""
        return self._hmac_key_path

    @staticmethod
    def _read_key_file(path: Path) -> bytes:
        raw = path.read_bytes().strip()
        # Accept raw 32+ byte keys and human-portable hex keys.
        try:
            text = raw.decode("ascii").strip()
            if re.fullmatch(r"[0-9a-fA-F]{64,}", text) and len(text) % 2 == 0:
                key = bytes.fromhex(text)
            else:
                key = raw
        except UnicodeDecodeError:
            key = raw
        if len(key) < 32:
            raise ValueError(f"HMAC key at {path} is shorter than 32 bytes")
        return key

    @classmethod
    def _load_or_create_hmac_key(cls, case_id: str) -> tuple[bytes, Path, str]:
        """Load an operator key or create a separately preserved per-run key.

        The key is never stored inside the case output directory.  This keeps the
        evidence package tamper-evident: an attacker who alters the ledger cannot
        simply recompute the HMAC from a key shipped beside it.
        """
        configured = os.environ.get("AUTOFORENSICS_COC_HMAC_KEY_FILE", "").strip()
        if configured:
            key_path = Path(configured).expanduser().resolve()
            if not key_path.is_file():
                raise FileNotFoundError(
                    f"AUTOFORENSICS_COC_HMAC_KEY_FILE does not exist: {key_path}"
                )
            return cls._read_key_file(key_path), key_path, "operator-key-file"

        key_dir = Path(
            os.environ.get(
                "AUTOFORENSICS_KEY_DIR",
                str(Path.home() / ".autoforensics" / "keys"),
            )
        ).expanduser().resolve()
        key_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(key_dir, 0o700)
        safe_id = cls._sanitize_filename(case_id)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        key_path = key_dir / f"{safe_id}_{stamp}.coc-hmac.key"
        key = os.urandom(32)
        # Hex makes manual transfer and independent verification reliable.
        fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o400)
        with os.fdopen(fd, "w", encoding="ascii") as fh:
            fh.write(key.hex() + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        return key, key_path, "generated-separate-key-file"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log(
        self,
        event_type: EventType,
        description: str,
        evidence_path: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        investigator_id: Optional[str] = None,
    ) -> CustodyEntry:
        """
        Append a new entry to the chain of custody ledger.

        This is the only method that writes to the ledger. The entry is
        flushed and fsync'd to disk before this method returns, so the
        caller can trust that the entry is durably recorded even if the
        process crashes immediately afterward.

        Parameters
        ----------
        event_type      One of EventType — what happened.
        description     Human-readable sentence describing the event.
        evidence_path   Path of the evidence being acted on (optional).
        metadata        Event-specific key-value pairs (hashes, sizes, etc.).
        investigator_id Override the default investigator ID for this entry.
                        Used when logging AUTH_FAILURE before authentication
                        completes, for example.

        Returns
        -------
        The CustodyEntry that was written, for callers that want to inspect
        the computed hash or entry ID.

        Raises
        ------
        RuntimeError    If the log has already been sealed.
        """
        if self._sealed:
            raise RuntimeError(
                "Chain of custody has been sealed. No further entries can be written."
            )

        entry = CustodyEntry(
            event_type      = event_type,
            investigator_id = investigator_id or self._investigator_id,
            case_id         = self._case_id,
            description     = description,
            evidence_path   = evidence_path,
            metadata        = metadata,
            previous_hash   = self._previous_hash,
        )

        # Write the JSON line immediately — do not accumulate in memory only.
        # If the process crashes, all entries up to this point remain readable.
        self._ledger_fh.write(json.dumps(entry.to_dict(), ensure_ascii=True) + "\n")
        self._ledger_fh.flush()
        # fsync forces the OS write buffer to disk — prevents data loss on power failure
        os.fsync(self._ledger_fh.fileno())

        # Write companion entry — less critical, no fsync needed
        self._companion_fh.write(entry.to_human_readable())
        self._companion_fh.flush()

        self._entries.append(entry)
        # Advance the chain — next entry will reference this entry's hash
        self._previous_hash = entry.self_hash

        self._logger.debug(
            "CoC entry [%s] case=%s hash=%s",
            entry.event_type, self._case_id, entry.self_hash[:16],
        )

        return entry

    def info(self, message: str, *args: Any) -> CustodyEntry:
        """Compatibility adapter for legacy module log helpers.

        Older modules emitted ``coc_logger.info("COC_EVENT ...")``.  Keeping
        this adapter ensures those observations are durably hash-chained rather
        than silently discarded, while the central FINDING_RECORDED gate remains
        the authoritative per-finding H2 record.
        """
        try:
            description = message % args if args else str(message)
        except Exception:
            description = " ".join([str(message), *(str(x) for x in args)])
        return self.log(
            EventType.MODULE_OBSERVATION,
            description=description[:4000],
            metadata={"legacy_adapter": True},
        )

    def verify_chain(self) -> bool:
        """
        Re-verify the hash chain by reading every persisted entry from disk.

        This catches:
        - In-memory vs on-disk divergence (OS-level write failures)
        - Any modification to a ledger entry that occurred since it was written
        - Missing or reordered entries

        Called automatically by seal(). Can also be called mid-investigation
        for a health-check (e.g., after a long module run on an untrusted host).

        Returns
        -------
        True  if every entry is intact and the chain is unbroken.
        False if any entry is malformed, missing, or has a hash mismatch.
        """
        self._ledger_fh.flush()

        try:
            with open(self._ledger_path, "r", encoding="utf-8") as f:
                raw_lines = [line.strip() for line in f if line.strip()]
        except OSError as exc:
            self._logger.error("Cannot open ledger for chain verification: %s", exc)
            return False

        expected_prev = "GENESIS"

        for index, raw_line in enumerate(raw_lines):
            try:
                data: dict = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                self._logger.error(
                    "Ledger entry %d is malformed JSON: %s", index, exc
                )
                return False

            # Check the previous_hash link before anything else
            stored_prev = data.get("previous_hash")
            if stored_prev != expected_prev:
                self._logger.error(
                    "Hash chain broken at entry %d: "
                    "expected previous_hash=%s … got %s",
                    index, expected_prev[:16], str(stored_prev)[:16],
                )
                return False

            # Recompute self_hash by removing it from data and hashing the rest
            stored_self = data.pop("self_hash", None)
            if stored_self is None:
                self._logger.error("Entry %d missing self_hash field", index)
                return False

            recomputed = hashlib.sha256(
                json.dumps(data, sort_keys=True, ensure_ascii=True).encode("utf-8")
            ).hexdigest()

            if recomputed != stored_self:
                self._logger.error(
                    "Entry %d self_hash mismatch — entry has been altered. "
                    "stored=%s computed=%s",
                    index, stored_self[:16], recomputed[:16],
                )
                return False

            expected_prev = stored_self

        return True

    def seal(self) -> dict[str, Any]:
        """
        Finalize and cryptographically seal the chain of custody.

        Steps
        -----
        1. Write a final INVESTIGATION_SEALED entry (already done by orchestrator
           before calling seal(), so this method just verifies + seals).
        2. Verify the full on-disk hash chain is intact.
        3. Build a seal document: entry count, timestamps, final hash, integrity status.
        4. Compute HMAC-SHA256 over the seal document so the seal itself is
           tamper-evident (any modification to the seal file breaks the HMAC).
        5. Write seal.json with 0o400 permissions (owner read-only).
        6. Set ledger and companion to 0o400 (read-only).
        7. Flush and close all file handles.

        Returns
        -------
        The seal document dict (also written to <case_id>_custody_seal.json).

        Raises
        ------
        RuntimeError    If seal() has already been called.
        """
        if self._sealed:
            raise RuntimeError("Chain of custody has already been sealed.")

        end_timestamp  = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
        chain_verified = self.verify_chain()

        # Build the seal content dict — this is what the HMAC covers
        seal_content: dict[str, Any] = {
            "case_id":                   self._case_id,
            "investigator_id":           self._investigator_id,
            "start_timestamp":           self._start_timestamp,
            "end_timestamp":             end_timestamp,
            "total_entries":             len(self._entries),
            "final_chain_hash":          self._previous_hash,
            "chain_integrity_verified":  chain_verified,
            "ledger_path":               str(self._ledger_path),
            "companion_path":            str(self._companion_path),
            "hmac_key_source":           self._hmac_key_source,
            "hmac_key_id":               hashlib.sha256(self._hmac_key).hexdigest()[:24],
            "hmac_key_filename":         self._hmac_key_path.name if self._hmac_key_path else "external",
        }

        # HMAC-SHA256 over the canonical JSON serialization of seal_content.
        # sort_keys=True is essential — dict ordering must not affect the MAC.
        seal_bytes = json.dumps(seal_content, sort_keys=True, ensure_ascii=True).encode("utf-8")
        seal_hmac  = hmac.new(self._hmac_key, seal_bytes, hashlib.sha256).hexdigest()

        # Store the HMAC key hash (not the key itself) in the seal so a verifier
        # can confirm they are using the right key without exposing the key.
        seal_document = {
            **seal_content,
            "seal_hmac": seal_hmac,
            # SHA-256 of the HMAC key — lets a key-holder verify they have the right key
            "hmac_key_sha256": hashlib.sha256(self._hmac_key).hexdigest(),
        }

        with open(self._seal_path, "w", encoding="utf-8") as f:
            json.dump(seal_document, f, indent=2, ensure_ascii=True)
        # 0o400 = read-only for owner — seal must not be modifiable post-creation
        os.chmod(self._seal_path, 0o400)

        # Write seal summary to companion log for human readers
        integrity_label = "VERIFIED" if chain_verified else "BROKEN — TAMPERING DETECTED"
        self._companion_fh.write(
            f"\n{'=' * 72}\n"
            f"CHAIN OF CUSTODY SEAL\n"
            f"Case ID:         {self._case_id}\n"
            f"Investigator:    {self._investigator_id}\n"
            f"Total Entries:   {len(self._entries)}\n"
            f"Start:           {self._start_timestamp}\n"
            f"End:             {end_timestamp}\n"
            f"Final Hash:      {self._previous_hash}\n"
            f"Chain Integrity: {integrity_label}\n"
            f"Seal HMAC:       {seal_hmac}\n"
            f"{'=' * 72}\n"
        )
        self._companion_fh.flush()

        self._close_file_handles()
        self._sealed = True

        # Make ledger and companion read-only to prevent accidental modification
        os.chmod(self._ledger_path, 0o400)
        os.chmod(self._companion_path, 0o400)

        self._logger.info(
            "CoC sealed: case=%s entries=%d chain_ok=%s",
            self._case_id, len(self._entries), chain_verified,
        )

        return seal_document

    @staticmethod
    def verify_seal_files(ledger_path: Path, seal_path: Path, key_path: Path) -> tuple[bool, str]:
        """Independently verify the persisted chain and HMAC seal."""
        try:
            lines = [line.strip() for line in Path(ledger_path).read_text(encoding="utf-8").splitlines() if line.strip()]
            expected_prev = "GENESIS"
            for index, raw in enumerate(lines):
                data = json.loads(raw)
                stored_self = data.pop("self_hash", None)
                if data.get("previous_hash") != expected_prev or not stored_self:
                    return False, f"hash chain broken at entry {index}"
                recomputed = hashlib.sha256(
                    json.dumps(data, sort_keys=True, ensure_ascii=True).encode("utf-8")
                ).hexdigest()
                if not hmac.compare_digest(recomputed, stored_self):
                    return False, f"entry {index} hash mismatch"
                expected_prev = stored_self

            seal_doc = json.loads(Path(seal_path).read_text(encoding="utf-8"))
            stored_hmac = str(seal_doc.pop("seal_hmac", ""))
            stored_key_hash = str(seal_doc.pop("hmac_key_sha256", ""))
            key = CustodyLogger._read_key_file(Path(key_path))
            if not hmac.compare_digest(hashlib.sha256(key).hexdigest(), stored_key_hash):
                return False, "verification key does not match seal key identifier"
            if seal_doc.get("total_entries") != len(lines):
                return False, "seal entry count does not match ledger"
            if seal_doc.get("final_chain_hash") != expected_prev:
                return False, "seal final chain hash does not match ledger"
            computed_hmac = hmac.new(
                key,
                json.dumps(seal_doc, sort_keys=True, ensure_ascii=True).encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()
            if not hmac.compare_digest(computed_hmac, stored_hmac):
                return False, "seal HMAC mismatch"
            return True, "chain and HMAC seal verified"
        except Exception as exc:
            return False, f"verification error: {exc}"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_filename(name: str) -> str:
        """
        Replace any character that is unsafe in a filename with an underscore.

        Case IDs come from user input. We must ensure they cannot produce
        paths like '../../etc/passwd' or filenames with shell-special chars.
        The allowlist (word chars + hyphens) is deliberately narrow.
        """
        return re.sub(r"[^\w\-]", "_", name)

    def _close_file_handles(self) -> None:
        """Flush and close both open file handles cleanly."""
        for fh in (self._ledger_fh, self._companion_fh):
            if not fh.closed:
                fh.flush()
                fh.close()

    def __del__(self) -> None:
        """Best-effort cleanup if the object is garbage-collected without sealing."""
        try:
            self._close_file_handles()
        except Exception:
            pass  # Never raise from __del__

    def entries_with_status(self) -> list[dict]:
        """
        Return all on-disk entries annotated with per-entry pass/fail status.

        Entry 0 (GENESIS sentinel) returns status='GENESIS' only when both the
        sentinel link (previous_hash == "GENESIS") and self-hash are valid,
        otherwise 'FAIL'. Subsequent entries return 'PASS' or 'FAIL' based on
        hash chain integrity.
        Never raises — returns empty list on any error.
        """
        try:
            self._ledger_fh.flush()
        except (OSError, ValueError):
            pass  # sealed or closed — proceed to read from disk

        try:
            with open(self._ledger_path, "r", encoding="utf-8") as f:
                raw_lines = [line.strip() for line in f if line.strip()]
        except OSError:
            return []

        results: list[dict] = []
        expected_prev = "GENESIS"

        for idx, raw in enumerate(raw_lines):
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                results.append({"status": "MALFORMED", "index": idx,
                                 "timestamp": "", "event_type": "MALFORMED",
                                 "description": "Malformed JSON entry",
                                 "self_hash": "", "previous_hash": ""})
                continue

            stored_prev = data.get("previous_hash", "")
            stored_self = data.get("self_hash", "")

            # Recompute self_hash by removing it and hashing the rest
            check = dict(data)
            check.pop("self_hash", None)
            recomputed = hashlib.sha256(
                json.dumps(check, sort_keys=True, ensure_ascii=True).encode("utf-8")
            ).hexdigest()

            if idx == 0:
                if stored_prev == "GENESIS" and recomputed == stored_self:
                    status = "GENESIS"
                else:
                    status = "FAIL"
            elif stored_prev != expected_prev:
                status = "FAIL"
            else:
                status = "PASS" if recomputed == stored_self else "FAIL"

            # Only advance the chain pointer when this entry fully passed
            if status in ("PASS", "GENESIS"):
                expected_prev = stored_self
            results.append({
                "status": status,
                "index": idx,
                "timestamp": data.get("timestamp", ""),
                "event_type": data.get("event_type", ""),
                "description": data.get("description", ""),
                "self_hash": (stored_self[:16] + "…") if len(stored_self) > 16 else stored_self,
                "previous_hash": (
                    (stored_prev[:16] + "…") if (stored_prev and stored_prev != "GENESIS"
                                                  and len(stored_prev) > 16)
                    else stored_prev
                ),
            })

        return results
