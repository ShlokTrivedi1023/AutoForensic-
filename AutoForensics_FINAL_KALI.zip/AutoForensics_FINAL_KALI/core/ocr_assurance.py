"""Case-neutral assurance checks for accepted OCR findings.

OCR engine output is probabilistic.  An OCR-derived record may enter the
accepted finding set only when the module records deterministic independent
corroboration.  This helper validates the assurance contract without knowing
or embedding any evidence-specific text, path, hash, filename, or count.
"""
from __future__ import annotations

from typing import Any, Iterable


def accepted_ocr_finding_is_corroborated(finding: dict[str, Any]) -> bool:
    """Return ``True`` only for an accepted OCR finding with independent support."""
    if not isinstance(finding, dict):
        return False
    metadata = finding.get("metadata") or {}
    if not isinstance(metadata, dict):
        return False
    if metadata.get("candidate_only") is True:
        return False
    if metadata.get("deterministic_validation") is not True:
        return False
    if str(finding.get("finding_type") or "") != "OCR_TRANSCRIPTION_CORROBORATED":
        return False
    if str(metadata.get("examiner_confirmation_status") or "") != "INDEPENDENTLY_CORROBORATED":
        return False

    corroboration = metadata.get("corroboration") or {}
    if not isinstance(corroboration, dict) or corroboration.get("confirmed") is not True:
        return False
    matched_fields = corroboration.get("matched_fields") or []
    if not isinstance(matched_fields, list) or len(matched_fields) < 2:
        return False

    source_hash = str(metadata.get("image_sha256") or "").strip().lower()
    transcript_hash = str(metadata.get("transcript_sha256") or "").strip().lower()
    excluded_hashes = {value for value in (source_hash, transcript_hash) if value}

    # Every accepted labelled value must have an exact match in a different
    # retained byte stream.  Merely repeating the OCR transcript or the source
    # image is not independent corroboration.
    for field in matched_fields:
        if not isinstance(field, dict) or not str(field.get("label") or "").strip():
            return False
        if not str(field.get("value") or "").strip():
            return False
        matches = field.get("matches") or []
        if not isinstance(matches, list) or not matches:
            return False
        independent = {
            str(match.get("sha256") or "").strip().lower()
            for match in matches
            if isinstance(match, dict)
            and str(match.get("sha256") or "").strip()
            and str(match.get("sha256") or "").strip().lower() not in excluded_hashes
        }
        if not independent:
            return False

    supporting = corroboration.get("supporting_sources") or []
    supporting_hashes = {
        str(item.get("sha256") or "").strip().lower()
        for item in supporting
        if isinstance(item, dict)
        and str(item.get("sha256") or "").strip()
        and str(item.get("sha256") or "").strip().lower() not in excluded_hashes
    }
    return bool(supporting_hashes)


def all_accepted_ocr_findings_are_corroborated(findings: Iterable[dict[str, Any]]) -> bool:
    """Validate that no accepted OCR finding lacks independent corroboration."""
    return all(accepted_ocr_finding_is_corroborated(item) for item in findings)
