"""Recursive, content-driven evidence inventory for extracted forensic corpora.

The inventory is deliberately case-agnostic.  It does not search for planted
values or known fixture filenames.  It classifies nested evidence using file
signatures, archive structure and database schemas, de-duplicates byte-identical
aliases and exposes explicit source lists to downstream modules.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import sqlite3
import struct
import tarfile
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from core.deterministic_memory import extract_structured_memory_markers
from core.source_provenance import SourceRole, infer_inventory_source_role

_MAX_HEADER = 1024 * 1024
_MAX_FILES = 0  # zero = exhaustive; positive values are explicit safety caps
_MAX_ARCHIVE_NAMES = 0  # 0 = exhaustive archive member enumeration


@dataclass
class EvidenceObject:
    path: str
    size_bytes: int
    sha256: str
    object_type: str
    subtype: str = ""
    validation_method: str = ""
    deterministic: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)
    source_role: str = SourceRole.EVIDENTIARY_CONTENT.value
    source_role_reason: str = ""
    canonical: bool = True
    alias_of: str | None = None


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _read_header(path: Path, limit: int = _MAX_HEADER) -> bytes:
    try:
        with path.open("rb") as fh:
            return fh.read(limit)
    except OSError:
        return b""


def _sqlite_schema(path: Path) -> dict[str, list[str]]:
    if _read_header(path, 16) != b"SQLite format 3\x00":
        return {}
    schema: dict[str, list[str]] = {}
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)
        try:
            for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table'"):
                if not isinstance(name, str) or not name:
                    continue
                try:
                    columns = [str(row[1]).lower() for row in conn.execute(f'PRAGMA table_info("{name.replace(chr(34), chr(34)*2)}")')]
                except sqlite3.Error:
                    columns = []
                schema[name.lower()] = columns
        finally:
            conn.close()
    except sqlite3.Error:
        return {}
    return schema


def _classify_sqlite(schema: dict[str, list[str]]) -> tuple[str, str, dict[str, Any]]:
    tables = set(schema)
    if not tables:
        return "sqlite_database", "unknown", {"tables": []}
    # Browser schemas.
    if "urls" in tables and {"url", "title"}.issubset(set(schema.get("urls", []))):
        return "browser_database", "chromium_history", {"tables": sorted(tables)}
    if "moz_places" in tables:
        return "browser_database", "firefox_history", {"tables": sorted(tables)}
    if "history_items" in tables or "browser_history" in tables:
        return "mobile_database", "ios_browser", {"tables": sorted(tables), "platform": "ios"}
    # Android and iOS communications.
    if "sms" in tables and "body" in schema.get("sms", []):
        return "mobile_database", "android_sms", {"tables": sorted(tables), "platform": "android"}
    if "calls" in tables and any(col in schema.get("calls", []) for col in ("number", "date", "duration")):
        return "mobile_database", "android_calls", {"tables": sorted(tables), "platform": "android"}
    if "message" in tables and any(col in schema.get("message", []) for col in ("text", "date", "handle_id")):
        return "mobile_database", "ios_messages", {"tables": sorted(tables), "platform": "ios"}
    if "zcallrecord" in tables:
        return "mobile_database", "ios_calls", {"tables": sorted(tables), "platform": "ios"}
    # Generic communications databases.
    if any(table in tables for table in ("messages", "chat", "chats", "contacts", "addressbook")):
        return "communications_database", "generic", {"tables": sorted(tables)}
    return "sqlite_database", "generic", {"tables": sorted(tables)}


def _pcap_type(header: bytes) -> str | None:
    if len(header) < 4:
        return None
    magic = header[:4]
    if magic in {b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\xc3\xd4", b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d"}:
        return "pcap"
    if magic == b"\x0a\x0d\x0d\x0a":
        return "pcapng"
    return None


def _packet_fingerprint(path: Path, kind: str) -> str | None:
    """Hash captured packet bytes, independent of PCAP/PCAPNG wrapper metadata."""
    h = hashlib.sha256()
    count = 0
    try:
        data = path.read_bytes()
    except OSError:
        return None
    try:
        if kind == "pcap":
            if len(data) < 24:
                return None
            little = data[:4] in {b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"}
            endian = "<" if little else ">"
            offset = 24
            while offset + 16 <= len(data):
                _ts1, _ts2, incl, _orig = struct.unpack_from(endian + "IIII", data, offset)
                offset += 16
                if incl < 0 or offset + incl > len(data):
                    return None
                packet = data[offset : offset + incl]
                offset += incl
                h.update(struct.pack(">I", len(packet)))
                h.update(packet)
                count += 1
        elif kind == "pcapng":
            offset = 0
            endian = "<"
            while offset + 12 <= len(data):
                block_type = struct.unpack_from(endian + "I", data, offset)[0]
                block_len = struct.unpack_from(endian + "I", data, offset + 4)[0]
                if block_type == 0x0A0D0D0A and offset + 12 <= len(data):
                    bom = data[offset + 8 : offset + 12]
                    endian = "<" if bom == b"\x4d\x3c\x2b\x1a" else ">" if bom == b"\x1a\x2b\x3c\x4d" else endian
                    block_len = struct.unpack_from(endian + "I", data, offset + 4)[0]
                if block_len < 12 or offset + block_len > len(data):
                    return None
                if block_type == 0x00000006 and block_len >= 32:  # Enhanced Packet Block
                    caplen = struct.unpack_from(endian + "I", data, offset + 20)[0]
                    packet_start = offset + 28
                    if packet_start + caplen > offset + block_len - 4:
                        return None
                    packet = data[packet_start : packet_start + caplen]
                    h.update(struct.pack(">I", len(packet)))
                    h.update(packet)
                    count += 1
                elif block_type == 0x00000003 and block_len >= 16:  # Simple Packet Block
                    origlen = struct.unpack_from(endian + "I", data, offset + 8)[0]
                    packet = data[offset + 12 : offset + block_len - 4]
                    packet = packet[: min(origlen, len(packet))]
                    h.update(struct.pack(">I", len(packet)))
                    h.update(packet)
                    count += 1
                offset += block_len
        else:
            return None
    except (struct.error, ValueError):
        return None
    return h.hexdigest() if count else None


def _registry_baseblock(header: bytes, size: int) -> dict[str, Any] | None:
    if len(header) < 4096 or header[:4] != b"regf":
        return None
    try:
        seq1, seq2 = struct.unpack_from("<II", header, 4)
        root_cell = struct.unpack_from("<I", header, 0x24)[0]
        hbins_size = struct.unpack_from("<I", header, 0x28)[0]
        stored = struct.unpack_from("<I", header, 0x1FC)[0]
        calc = 0
        for off in range(0, 0x1FC, 4):
            calc ^= struct.unpack_from("<I", header, off)[0]
        valid_checksum = stored == calc
        hbin = header[4096:4100] == b"hbin" if len(header) >= 4100 else False
        return {
            "sequence_1": seq1,
            "sequence_2": seq2,
            "sequence_match": seq1 == seq2,
            "root_cell_offset": root_cell,
            "hbins_size": hbins_size,
            "baseblock_checksum_valid": valid_checksum,
            "first_hbin_present": hbin,
            "size_bytes": size,
        }
    except struct.error:
        return None


def _prefetch_structure(header: bytes, size: int) -> tuple[str, dict[str, Any]] | None:
    if len(header) < 8:
        return None
    if header[:3] == b"MAM":
        return "compressed", {"size_bytes": size, "signature": "MAM"}
    if header[4:8] != b"SCCA":
        return None
    if len(header) < 84:
        return "marker_only", {"size_bytes": size, "reason": "shorter than Prefetch fixed header"}
    version = struct.unpack_from("<I", header, 0)[0]
    declared_size = struct.unpack_from("<I", header, 12)[0]
    known_version = version in {17, 23, 26, 30, 31}
    plausible_size = declared_size == size and declared_size >= 84
    return ("valid" if known_version and plausible_size else "marker_only"), {
        "version": version,
        "declared_size": declared_size,
        "actual_size": size,
        "known_version": known_version,
        "size_matches_header": declared_size == size,
    }


def _lnk_structure(header: bytes, size: int) -> tuple[str, dict[str, Any]] | None:
    if len(header) < 4:
        return None
    header_size = struct.unpack_from("<I", header, 0)[0]
    clsid = bytes.fromhex("0114020000000000c000000000000046")
    if header_size != 0x4C:
        return None
    valid = len(header) >= 76 and header[4:20] == clsid and size >= 76
    return ("valid" if valid else "marker_only"), {
        "header_size": header_size,
        "shell_link_clsid_valid": len(header) >= 20 and header[4:20] == clsid,
        "size_bytes": size,
    }


def _evtx_structure(header: bytes, size: int) -> tuple[str, dict[str, Any]] | None:
    if not header.startswith(b"ElfFile\x00"):
        return None
    valid = size >= 4096 and len(header) >= 128
    return ("valid" if valid else "marker_only"), {
        "size_bytes": size,
        "minimum_file_header_present": valid,
    }


def _memory_classification(path: Path, header: bytes, size: int) -> tuple[str, str, dict[str, Any], bool] | None:
    suffix = path.suffix.lower()
    memory_suffix = suffix in {".vmem", ".mem", ".raw", ".bin", ".dmp", ".lime"}
    signature_kind = ""
    if header.startswith((b"PAGEDUMP", b"PAGEDU64", b"DUMP")):
        signature_kind = "windows_crash_dump"
    elif header.startswith(b"MDMP"):
        signature_kind = "minidump"
    elif header[:4] in {b"LiME", b"EMiL"}:
        signature_kind = "lime"

    if not memory_suffix and not signature_kind:
        return None

    # Structured marker grammars are parsed from the complete bounded stream,
    # not only the first megabyte. This handles wrapped or sparse validation
    # corpora without treating extension-only files as genuine RAM.
    marker = extract_structured_memory_markers(path)
    marker_types = set(marker.get("record_types") or [])
    substantive = marker_types & {
        "process_marker", "network_marker", "hidden_process_marker",
        "rootkit_marker", "credential_marker", "malware_test_marker",
    }
    if len(marker.get("records") or []) >= 2 and substantive:
        meta = {
            "size_bytes": size,
            "wrapper_signature": signature_kind or "raw/extension-routed",
            "marker_record_count": marker.get("record_count", 0),
            "marker_record_types": marker.get("record_types", []),
            "marker_fingerprint": marker.get("marker_fingerprint", ""),
            "semantic_limit": marker.get("semantic_limit", "marker presence only"),
        }
        return "memory_marker_corpus", signature_kind or "structured_string_markers", meta, True

    if signature_kind:
        return "memory_image", signature_kind, {"signature": header[:8].hex(), "size_bytes": size}, True
    # No universal magic exists for raw/VMware memory. Extension is a routing
    # candidate only and cannot support VERIFIED_ABSENT or kernel semantics.
    return "memory_candidate", "extension_only", {"size_bytes": size, "suffix": suffix}, False


def _archive_names(path: Path) -> tuple[str, list[str]] | None:
    try:
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as zf:
                return "zip", [info.filename for info in (zf.infolist() if _MAX_ARCHIVE_NAMES <= 0 else zf.infolist()[:_MAX_ARCHIVE_NAMES])]
        if tarfile.is_tarfile(path):
            with tarfile.open(path, "r:*") as tf:
                names: list[str] = []
                for idx, member in enumerate(tf):
                    if _MAX_ARCHIVE_NAMES > 0 and idx >= _MAX_ARCHIVE_NAMES:
                        break
                    names.append(member.name)
                return "tar", names
        if _read_header(path, 2) == b"\x1f\x8b":
            return "gzip", []
    except (OSError, zipfile.BadZipFile, tarfile.TarError):
        return None
    return None


def _mobile_archive_subtype(kind: str, names: list[str], header: bytes, path: Path) -> tuple[str, dict[str, Any]] | None:
    lowered = "\n".join(name.lower() for name in (names if _MAX_ARCHIVE_NAMES <= 0 else names[:_MAX_ARCHIVE_NAMES]))
    android = sum(marker in lowered for marker in ("data/data/", "data/user/", "packages.xml", "com.android."))
    ios = sum(marker in lowered for marker in ("homedomain/", "private/var/", "library/sms/", "manifest.db"))
    if header.startswith(b"ANDROID BACKUP\n"):
        return "android_backup", {"platform": "android", "archive_kind": "android_backup"}
    if android or ios:
        platform = "android" if android > ios else "ios" if ios > android else "mixed"
        subtype = "ufdr_style_zip" if path.suffix.lower() == ".ufdr" and kind == "zip" else f"mobile_{kind}"
        return subtype, {"platform": platform, "archive_kind": kind, "member_count": len(names)}
    return None


def _classify_config(path: Path, header: bytes) -> tuple[str, str, dict[str, Any]] | None:
    suffix = path.suffix.lower()
    text = header.decode("utf-8", errors="replace")
    lines = [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]
    if suffix in {".yar", ".yara"} and re.search(r"(?m)^\s*(?:private\s+|global\s+)?rule\s+[A-Za-z_]\w*", text):
        return "detection_config", "yara_rules", {"declared_rules": len(re.findall(r"(?m)^\s*(?:private\s+|global\s+)?rule\s+[A-Za-z_]\w*", text))}
    if suffix == ".ndb" and any(re.fullmatch(r"[^:]+:[0-9]+:[0-9*]+:[0-9A-Fa-f*?]+", line) for line in lines):
        return "detection_config", "clamav_ndb", {"signature_lines": len(lines)}

    name_l = path.name.casefold()
    parent_tokens = {part.casefold() for part in path.parts}
    config_location = bool(parent_tokens & {"config", "configuration", "rules", "signatures", "validationconfig", "validation_config"})

    # Common hash-list shapes: HASH, HASH label, HASH:label, label:HASH, CSV.
    # A hash-looking value inside an ordinary evidence document is not enough to
    # reclassify the whole file as scanner configuration. Require a configuration
    # location/name in addition to a dense, line-oriented hash-list structure.
    hash_re = re.compile(r"(?i)(?<![0-9a-f])([0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{56}|[0-9a-f]{64}|[0-9a-f]{96}|[0-9a-f]{128})(?![0-9a-f])")
    hash_lines = [line for line in lines if hash_re.search(line)]
    hash_named = any(token in name_l for token in ("hash", "digest", "known", "nsrl"))
    if (config_location or hash_named) and hash_lines and len(hash_lines) >= max(1, (len(lines) + 1) // 2):
        values = [hash_re.search(line).group(1).lower() for line in hash_lines if hash_re.search(line)]
        return "detection_config", "hash_list", {"hash_count": len(values), "hash_lengths": sorted({len(v) for v in values})}

    # Keyword lists are search terms, not password dictionaries.
    if suffix in {".txt", ".lst", ".csv"} and "keyword" in name_l and lines:
        return "detection_config", "keyword_list", {"line_count": len(lines)}

    # IOC lists control exact matching. Ordinary notes/logs commonly contain IPs,
    # domains or URLs, so content alone must never reclassify them as configuration.
    # Require a configuration-style path/name plus a predominantly one-value-per-line
    # list shape.
    ioc_count = 0
    for line in lines:
        stripped = line.split("#", 1)[0].strip()
        tokens = stripped.split()
        value = tokens[0] if len(tokens) == 1 else ""
        if re.fullmatch(r"(?:[0-9]{1,3}\.){3}[0-9]{1,3}", value) or re.fullmatch(r"(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,63}", value) or value.startswith(("http://", "https://")):
            ioc_count += 1
    ioc_named = any(token in name_l for token in ("ioc", "indicator", "watchlist", "blocklist", "allowlist"))
    if (config_location or ioc_named) and ioc_count and ioc_count >= max(1, (len(lines) + 1) // 2):
        return "detection_config", "ioc_list", {"ioc_count": ioc_count}

    # Wordlists contain one printable password candidate per line. Exclude
    # keyword/search-term files explicitly.
    if suffix in {".txt", ".lst", ".dic", ".wordlist"} and 1 <= len(lines) <= 5_000_000:
        printable = sum(all(31 < ord(ch) < 127 or ch.isspace() for ch in line) for line in lines)
        if lines and printable / len(lines) >= 0.95 and all(len(line) <= 256 for line in lines):
            if "keyword" not in name_l and any(token in name_l for token in ("wordlist", "password", "candidate", "dictionary")):
                return "detection_config", "wordlist", {"line_count": len(lines)}
    return None


def _classify_file_content(path: Path) -> EvidenceObject:
    size = path.stat().st_size
    digest = _sha256(path)
    header = _read_header(path)

    pcap = _pcap_type(header)
    if pcap:
        packet_digest = _packet_fingerprint(path, pcap)
        return EvidenceObject(str(path), size, digest, "network_capture", pcap, "capture magic and block/record parsing", True, {"packet_fingerprint": packet_digest})

    schema = _sqlite_schema(path)
    if schema:
        obj, subtype, meta = _classify_sqlite(schema)
        return EvidenceObject(str(path), size, digest, obj, subtype, "SQLite header and schema", True, meta)

    registry = _registry_baseblock(header, size)
    if registry:
        return EvidenceObject(str(path), size, digest, "registry_hive", "regf", "REGF base-block structure", True, registry)

    prefetch = _prefetch_structure(header, size)
    if prefetch:
        subtype, meta = prefetch
        return EvidenceObject(str(path), size, digest, "windows_prefetch", subtype, "Prefetch signature, version and size invariants", subtype != "marker_only", meta)

    lnk = _lnk_structure(header, size)
    if lnk:
        subtype, meta = lnk
        return EvidenceObject(str(path), size, digest, "windows_shell_link", subtype, "Shell Link header and CLSID", subtype == "valid", meta)

    evtx = _evtx_structure(header, size)
    if evtx:
        subtype, meta = evtx
        return EvidenceObject(str(path), size, digest, "windows_event_log", subtype, "EVTX file-header invariants", subtype == "valid", meta)

    memory = _memory_classification(path, header, size)
    if memory:
        obj, subtype, meta, deterministic = memory
        return EvidenceObject(str(path), size, digest, obj, subtype, "memory signature or deterministic marker profile", deterministic, meta)

    config = _classify_config(path, header)
    if config:
        obj, subtype, meta = config
        return EvidenceObject(str(path), size, digest, obj, subtype, "configuration syntax/content", True, meta)

    # Android Backup is a dedicated wrapper, not a ZIP/TAR file until its
    # compression header is parsed. Detect it before generic archive probing.
    if header.startswith(b"ANDROID BACKUP\n"):
        lines = header.split(b"\n", 4)
        meta = {
            "platform": "android", "archive_kind": "android_backup",
            "version": lines[1].decode("ascii", errors="replace") if len(lines) > 1 else "",
            "compressed": lines[2].decode("ascii", errors="replace") if len(lines) > 2 else "",
            "encryption": lines[3].decode("ascii", errors="replace") if len(lines) > 3 else "",
        }
        return EvidenceObject(str(path), size, digest, "mobile_archive", "android_backup", "Android Backup header structure", True, meta)

    archive = _archive_names(path)
    if archive:
        kind, names = archive
        mobile = _mobile_archive_subtype(kind, names, header, path)
        if mobile:
            subtype, meta = mobile
            return EvidenceObject(str(path), size, digest, "mobile_archive", subtype, "archive signature and member paths", True, meta)
        return EvidenceObject(str(path), size, digest, "archive", kind, "archive structure", True, {"member_count": len(names)})

    return EvidenceObject(str(path), size, digest, "file", path.suffix.lower().lstrip(".") or "unknown", "byte hash and path inventory", True, {})


def classify_file(path: Path) -> EvidenceObject:
    """Classify content and assign a non-corroborating source role where required."""
    obj = _classify_file_content(path)
    role, reason = infer_inventory_source_role(
        path, object_type=obj.object_type, subtype=obj.subtype, header=_read_header(path, 64 * 1024)
    )
    obj.source_role = role.value
    obj.source_role_reason = reason
    obj.metadata = dict(obj.metadata or {})
    obj.metadata.setdefault("source_role", role.value)
    obj.metadata.setdefault("source_role_reason", reason)
    return obj


def _priority(path: str) -> tuple[int, int, str]:
    lowered = path.replace("\\", "/").casefold()
    # Prefer allocated native filesystem artefacts, then deleted native files,
    # then archive materialisations, then third-party carvers.
    if "/native_filesystem/" in lowered and "/extracted_files/" in lowered:
        rank = 0
    elif "/native_filesystem/" in lowered and "/deleted_files/" in lowered:
        rank = 1
    elif "mobile_input" in lowered or "archive" in lowered:
        rank = 2
    elif "foremost" in lowered:
        rank = 3
    elif "scalpel" in lowered:
        rank = 4
    else:
        rank = 2
    return rank, len(path), path


def _directory_mobile_roots(files: list[EvidenceObject]) -> list[dict[str, Any]]:
    """Find the extraction root immediately above a recognised mobile path.

    Absolute paths commonly contain generic components such as ``/mnt/data``.
    Selecting the first component named ``data`` therefore escapes the case
    corpus and can make the mobile module scan the whole host directory.  This
    routine instead recognises complete platform path sequences and chooses the
    directory immediately *before* that sequence.
    """
    roots: dict[tuple[str, str], list[str]] = {}
    for obj in files:
        if obj.object_type != "mobile_database":
            continue
        platform = str(obj.metadata.get("platform") or "unknown")
        p = Path(obj.path)
        candidate = p.parent
        parts = list(p.parts)
        lowered = [part.casefold() for part in parts]

        def before_sequence(sequence: tuple[str, ...]) -> Path | None:
            width = len(sequence)
            # Prefer the deepest matching platform sequence.  The root is the
            # parent immediately preceding it, never a generic host ancestor.
            matches = [
                idx for idx in range(0, len(lowered) - width + 1)
                if tuple(lowered[idx:idx + width]) == sequence and idx > 0
            ]
            if not matches:
                return None
            idx = matches[-1]
            return Path(*parts[:idx])

        if platform == "android":
            candidate = (
                before_sequence(("data", "data"))
                or before_sequence(("data", "user"))
                or before_sequence(("android", "data"))
                or candidate
            )
        elif platform == "ios":
            candidate = (
                before_sequence(("private", "var"))
                or before_sequence(("homedomain", "library"))
                or before_sequence(("library", "sms"))
                or candidate
            )
        roots.setdefault((str(candidate), platform), []).append(obj.path)
    return [
        {"path": path, "platform": platform, "database_paths": sorted(paths)}
        for (path, platform), paths in sorted(roots.items())
    ]


def build_inventory(roots: Iterable[Path], output_path: Path | None = None) -> dict[str, Any]:
    objects: list[EvidenceObject] = []
    seen_paths: set[str] = set()
    inventory_errors: list[dict[str, str]] = []
    discovered_paths = 0
    limit_reached = False
    for root in roots:
        root = Path(root)
        if root.is_file():
            candidates = [root]
        elif root.is_dir():
            candidates = sorted((p for p in root.rglob("*") if p.is_file() and not p.is_symlink()), key=lambda p: p.as_posix())
        else:
            continue
        for path in candidates:
            discovered_paths += 1
            if _MAX_FILES > 0 and len(objects) >= _MAX_FILES:
                limit_reached = True
                break
            key = str(path.resolve())
            if key in seen_paths:
                continue
            seen_paths.add(key)
            try:
                objects.append(classify_file(path))
            except (OSError, ValueError, sqlite3.Error) as exc:
                inventory_errors.append({"path": key, "error": f"{type(exc).__name__}: {exc}"})
                continue

    # Byte-identical de-duplication.  Objects with different semantic wrappers
    # (e.g. PCAP and PCAPNG) also receive packet-level alias grouping below.
    by_hash: dict[str, list[EvidenceObject]] = {}
    for obj in objects:
        by_hash.setdefault(obj.sha256, []).append(obj)
    for group in by_hash.values():
        if len(group) < 2:
            continue
        canonical = min(group, key=lambda item: _priority(item.path))
        for item in group:
            item.canonical = item is canonical
            item.alias_of = None if item is canonical else canonical.path

    # Wrapper-independent packet de-duplication.
    by_packets: dict[str, list[EvidenceObject]] = {}
    for obj in objects:
        fingerprint = str(obj.metadata.get("packet_fingerprint") or "")
        if obj.object_type == "network_capture" and fingerprint:
            by_packets.setdefault(fingerprint, []).append(obj)
    network_groups: list[dict[str, Any]] = []
    for fingerprint, group in by_packets.items():
        canonical = min(group, key=lambda item: _priority(item.path))
        network_groups.append({
            "packet_fingerprint": fingerprint,
            "canonical_path": canonical.path,
            "aliases": sorted(item.path for item in group if item.path != canonical.path),
            "wrapper_types": sorted({item.subtype for item in group}),
        })

    # Wrapper-independent memory-marker de-duplication. DMP/LiME/raw wrappers
    # carrying the same exact structured marker set are one logical corpus.
    by_marker_fingerprint: dict[str, list[EvidenceObject]] = {}
    for obj in objects:
        fingerprint = str(obj.metadata.get("marker_fingerprint") or "")
        if obj.object_type == "memory_marker_corpus" and fingerprint:
            by_marker_fingerprint.setdefault(fingerprint, []).append(obj)
    memory_marker_groups: list[dict[str, Any]] = []
    for fingerprint, group in by_marker_fingerprint.items():
        canonical = min(group, key=lambda item: _priority(item.path))
        memory_marker_groups.append({
            "marker_fingerprint": fingerprint,
            "canonical_path": canonical.path,
            "aliases": sorted(item.path for item in group if item.path != canonical.path),
            "wrapper_types": sorted({item.subtype for item in group}),
        })

    records = [asdict(obj) for obj in objects]
    mobile_roots = _directory_mobile_roots(objects)

    def canonical_paths(object_types: set[str], subtype: str | None = None, deterministic_only: bool = True) -> list[str]:
        values = []
        for obj in objects:
            if obj.object_type not in object_types or not obj.canonical:
                continue
            if subtype and obj.subtype != subtype:
                continue
            if deterministic_only and not obj.deterministic:
                continue
            values.append(obj.path)
        return sorted(values)

    inventory = {
        "schema": "autoforensics-evidence-inventory-v3",
        "objects": records,
        "object_count": len(records),
        "alias_groups": [
            {"sha256": digest, "canonical_path": min(group, key=lambda item: _priority(item.path)).path,
             "aliases": sorted(item.path for item in group if item.path != min(group, key=lambda item: _priority(item.path)).path)}
            for digest, group in by_hash.items() if len(group) > 1
        ],
        "network_capture_groups": network_groups,
        "memory_marker_groups": memory_marker_groups,
        "mobile_roots": mobile_roots,
        "sources": {
            "memory_structural": canonical_paths({"memory_image"}),
            "memory_markers": sorted({g["canonical_path"] for g in memory_marker_groups}) or canonical_paths({"memory_marker_corpus"}),
            "network": sorted({g["canonical_path"] for g in network_groups}) or canonical_paths({"network_capture"}),
            "mobile_archives": canonical_paths({"mobile_archive"}),
            "mobile_roots": [entry["path"] for entry in mobile_roots],
            "registry_hives": canonical_paths({"registry_hive"}),
            "yara_rules": canonical_paths({"detection_config"}, "yara_rules"),
            "clamav_signatures": canonical_paths({"detection_config"}, "clamav_ndb"),
            "hash_lists": canonical_paths({"detection_config"}, "hash_list"),
            "ioc_lists": canonical_paths({"detection_config"}, "ioc_list"),
            "wordlists": canonical_paths({"detection_config"}, "wordlist"),
            "keyword_lists": canonical_paths({"detection_config"}, "keyword_list"),
            "browser_databases": canonical_paths({"browser_database"}),
            "evidentiary_files": sorted(obj.path for obj in objects if obj.canonical and obj.source_role == SourceRole.EVIDENTIARY_CONTENT.value),
            "case_context_files": sorted(obj.path for obj in objects if obj.canonical and obj.source_role == SourceRole.CASE_CONTEXT.value),
            "analysis_configuration_files": sorted(obj.path for obj in objects if obj.canonical and obj.source_role == SourceRole.ANALYSIS_CONFIGURATION.value),
            "validation_reference_files": sorted(obj.path for obj in objects if obj.canonical and obj.source_role == SourceRole.VALIDATION_REFERENCE.value),
        },
        "source_role_counts": {
            role.value: sum(1 for obj in objects if obj.source_role == role.value)
            for role in SourceRole
        },
        "coverage": {
            "paths_discovered": discovered_paths,
            "paths_classified": len(records),
            "classification_errors": inventory_errors,
            "limit_configured": _MAX_FILES,
            "limit_reached": limit_reached,
            "coverage_complete": not limit_reached and not inventory_errors,
        },
    }
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(inventory, indent=2, ensure_ascii=True), encoding="utf-8")
    return inventory
