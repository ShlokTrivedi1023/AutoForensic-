"""Single source of truth for the AutoForensics release identifier."""
from __future__ import annotations
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
_VERSION_FILE = _ROOT / "VERSION"


def _load_version() -> str:
    try:
        value = _VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        value = "0.0.0-unknown"
    return value or "0.0.0-unknown"


VERSION = _load_version()
__version__ = VERSION
