"""Deterministic validators and evidence-promotion helpers.

This module separates *candidate generation* from *evidentiary promotion*.
Pattern/threshold engines may continue to generate candidates, but a candidate
is promoted to a PRESENT finding only after an explicit, reproducible validator
confirms the claimed property.  This avoids treating regex hits, entropy scores,
OCR guesses or co-occurrence as proof.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import ipaddress
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit

_EMAIL_RE = re.compile(
    r"(?<![A-Za-z0-9._%+\-])"
    r"[A-Za-z0-9](?:[A-Za-z0-9._%+\-]{0,62}[A-Za-z0-9])?"
    r"@"
    r"(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+"
    r"[A-Za-z]{2,63}"
    r"(?![A-Za-z0-9._%+\-])"
)
_URL_RE = re.compile(r"(?<![A-Za-z0-9])(?:https?|ftp)://[^\s<>\"{}|\\^`\[\]]+")
_IPV4_TOKEN_RE = re.compile(r"(?<![0-9.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![0-9.])")
_IPV6_TOKEN_RE = re.compile(r"(?<![0-9A-Fa-f:])[0-9A-Fa-f:]{2,39}(?![0-9A-Fa-f:])")
_BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_BASE58_INDEX = {c: i for i, c in enumerate(_BASE58_ALPHABET)}


@dataclass(frozen=True)
class LuhnIdentifier:
    digits: str
    kind: str
    context: str
    deterministic: bool
    reason: str


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def strict_emails(text: str) -> list[str]:
    """Return syntactically valid, token-bounded email addresses."""
    out: list[str] = []
    seen: set[str] = set()
    for m in _EMAIL_RE.finditer(text):
        value = m.group(0)
        local, domain = value.rsplit("@", 1)
        if len(local) > 64 or len(domain) > 253:
            continue
        labels = domain.split(".")
        if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in labels):
            continue
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            out.append(value)
    return out


def strict_ips(text: str) -> list[str]:
    """Return exact, token-bounded IP literals accepted by :mod:`ipaddress`."""
    out: list[str] = []
    seen: set[str] = set()
    for m in _IPV4_TOKEN_RE.finditer(text):
        try:
            value = str(ipaddress.ip_address(m.group(0)))
        except ValueError:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    # IPv6 tokenisation is intentionally conservative.  It cannot consume an
    # arbitrary neighbouring character and therefore cannot create substrings.
    for m in _IPV6_TOKEN_RE.finditer(text):
        raw = m.group(0)
        if ":" not in raw:
            continue
        try:
            value = str(ipaddress.ip_address(raw))
        except ValueError:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


def strict_urls(text: str) -> list[str]:
    """Return absolute URLs with a valid scheme and host.

    Trailing punctuation is removed only when it is not part of a balanced URL.
    The parser prevents SQLite/string-boundary concatenation from becoming a URL.
    """
    out: list[str] = []
    seen: set[str] = set()
    for m in _URL_RE.finditer(text):
        value = m.group(0).rstrip(".,;:!?)]}'\"")
        try:
            parts = urlsplit(value)
        except ValueError:
            continue
        if parts.scheme not in {"http", "https", "ftp"} or not parts.hostname:
            continue
        try:
            host = parts.hostname.encode("idna").decode("ascii")
        except UnicodeError:
            continue
        if len(host) > 253 or any(len(label) > 63 for label in host.split(".")):
            continue
        # Reject concatenated records such as "http://a/xTitlehttp://b/".
        lowered_path = (parts.path + "?" + parts.query).lower()
        if "http://" in lowered_path or "https://" in lowered_path or "ftp://" in lowered_path:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


def luhn_valid(number: str) -> bool:
    digits = [int(ch) for ch in number if ch.isdigit()]
    if len(digits) < 8 or len(set(digits)) == 1:
        return False
    total = 0
    parity = len(digits) % 2
    for idx, digit in enumerate(digits):
        if idx % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def classify_luhn_identifier(digits: str, context: str) -> LuhnIdentifier:
    """Classify a Luhn-valid number without guessing its semantic type.

    A payment-card claim requires explicit payment-card context.  A 15-digit
    number with IMEI/device context is classified as IMEI.  All other values
    remain a generic Luhn-valid identifier candidate and are not evidentiary
    payment-card findings.
    """
    normalized = re.sub(r"\D", "", digits)
    context_l = context.casefold()
    if not luhn_valid(normalized):
        return LuhnIdentifier(normalized, "invalid", context, False, "Luhn checksum failed")
    imei_words = ("imei", "device id", "mobile equipment identity", "tac")
    card_words = (
        "credit card", "debit card", "payment card", "card number", "pan", "primary account number",
        "visa", "mastercard", "american express", "amex", "discover", "cardholder",
    )
    if len(normalized) == 15 and any(word in context_l for word in imei_words):
        return LuhnIdentifier(normalized, "imei", context, True, "15 digits with explicit IMEI/device context")
    if 13 <= len(normalized) <= 19 and any(word in context_l for word in card_words):
        return LuhnIdentifier(normalized, "payment_card", context, True, "Luhn-valid value with explicit payment-card context")
    return LuhnIdentifier(
        normalized,
        "generic_luhn_identifier",
        context,
        False,
        "Luhn validity alone does not distinguish a payment card from IMEI or another check-digit identifier",
    )


def _b58decode(value: str) -> bytes | None:
    number = 0
    try:
        for ch in value:
            number = number * 58 + _BASE58_INDEX[ch]
    except KeyError:
        return None
    raw = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
    zeros = len(value) - len(value.lstrip("1"))
    return b"\x00" * zeros + raw


def bitcoin_base58check_valid(value: str) -> bool:
    raw = _b58decode(value)
    if raw is None or len(raw) < 5:
        return False
    payload, checksum = raw[:-4], raw[-4:]
    expected = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return checksum == expected and payload[:1] in {b"\x00", b"\x05", b"\x6f", b"\xc4"}


def _bech32_polymod(values: Iterable[int]) -> int:
    chk = 1
    generators = (0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3)
    for value in values:
        top = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ value
        for i, generator in enumerate(generators):
            if (top >> i) & 1:
                chk ^= generator
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(ch) >> 5 for ch in hrp] + [0] + [ord(ch) & 31 for ch in hrp]


def bitcoin_bech32_valid(value: str) -> bool:
    if value.lower() != value and value.upper() != value:
        return False
    value = value.lower()
    pos = value.rfind("1")
    if pos < 1 or pos + 7 > len(value) or len(value) > 90:
        return False
    hrp, data = value[:pos], value[pos + 1 :]
    if hrp not in {"bc", "tb", "bcrt"}:
        return False
    charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    try:
        values = [charset.index(ch) for ch in data]
    except ValueError:
        return False
    return _bech32_polymod(_bech32_hrp_expand(hrp) + values) in {1, 0x2BC830A3}


def validated_bitcoin_addresses(text: str) -> list[str]:
    candidates = set(re.findall(r"(?<![A-Za-z0-9])[13][1-9A-HJ-NP-Za-km-z]{25,34}(?![A-Za-z0-9])", text))
    candidates.update(re.findall(r"(?i)(?<![A-Za-z0-9])(?:bc1|tb1|bcrt1)[02-9ac-hj-np-z]{8,87}(?![A-Za-z0-9])", text))
    return sorted(value for value in candidates if bitcoin_base58check_valid(value) or bitcoin_bech32_valid(value))


def validated_base64(value: str) -> bytes | None:
    """Return decoded bytes only for canonical, round-trippable Base64."""
    compact = "".join(value.split())
    if len(compact) < 40 or len(compact) % 4:
        return None
    try:
        decoded = base64.b64decode(compact, validate=True)
    except (ValueError, binascii.Error):
        return None
    if base64.b64encode(decoded).decode("ascii") != compact:
        return None
    return decoded


def deterministic_metadata(method: str, *, validators: list[str] | None = None, **extra: Any) -> dict[str, Any]:
    """Create the common evidence-promotion metadata contract."""
    return {
        "finding_basis": "deterministic",
        "deterministic_validation": True,
        "validation_method": method,
        "validators": list(validators or []),
        **extra,
    }


def candidate_metadata(method: str, *, reason: str, **extra: Any) -> dict[str, Any]:
    """Create metadata for a retained, non-evidentiary candidate observation."""
    return {
        "finding_basis": "candidate",
        "deterministic_validation": False,
        "candidate_only": True,
        "fact_class": "CANDIDATE_ONLY",
        "counts_toward_unique_evidence": False,
        "candidate_method": method,
        "candidate_reason": reason,
        **extra,
    }
