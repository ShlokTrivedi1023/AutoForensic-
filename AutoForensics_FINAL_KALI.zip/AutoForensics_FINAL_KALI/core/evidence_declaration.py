"""Generic discovery of explicit evidence self-declarations.

This module does not know any fixture filename, case identifier, expected value,
or planted finding.  It scans runtime-discovered text-bearing evidence and
retains exact excerpts only when the content explicitly identifies the material
as synthetic, fabricated, training, test, demonstration, or validation data.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib
import re
from pathlib import Path
from typing import Any, Iterable

_TEXT_SUFFIXES={'.txt','.md','.json','.csv','.xml','.html','.htm','.log','.ini','.cfg','.conf','.yaml','.yml','.reg','.plist'}
_DECLARATION_RE=re.compile(
    r"(?is)(?:\b(?:synthetic|fabricated|training|validation|demonstration|test)\b.{0,120}\b(?:evidence|corpus|fixture|image|data|artefact|artifact|material)\b|"
    r"\b(?:evidence|corpus|fixture|image|data|artefact|artifact|material)\b.{0,120}\b(?:synthetic|fabricated|training|validation|demonstration|test)\b)"
)
_NEGATION_RE=re.compile(r"(?i)\b(?:not|isn't|is not|never)\s+(?:synthetic|fabricated|training|validation|demonstration|test)\b")

@dataclass(frozen=True)
class EvidenceDeclaration:
    path:str
    sha256:str
    encoding:str
    byte_offset:int
    excerpt:str
    matched_terms:list[str]

    def as_dict(self)->dict[str,Any]:
        return asdict(self)


def _sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as fh:
        for block in iter(lambda:fh.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def _decode(data:bytes)->tuple[str,str]:
    if data.startswith((b'\xff\xfe',b'\xfe\xff')):
        enc='utf-16'
    elif data.startswith(b'\xef\xbb\xbf'):
        enc='utf-8-sig'
    else:
        enc='utf-8'
    try:
        return data.decode(enc),enc
    except UnicodeDecodeError:
        try:
            return data.decode('utf-16-le'),'utf-16-le'
        except UnicodeDecodeError:
            return data.decode('latin-1'),'latin-1'


def _candidate_files(config:dict[str,Any])->Iterable[Path]:
    ws=config.get('_working_set') or {}
    values=[]
    for key in ('primary_evidence_roots','corpus_roots'):
        values.extend(ws.get(key) or [])
    for key in ('mounted_fs_root','native_deleted_root','extracted_files_dir'):
        if ws.get(key): values.append(ws[key])
    inventory=ws.get('evidence_inventory') or {}
    for obj in inventory.get('objects') or []:
        if isinstance(obj,dict) and obj.get('path'): values.append(obj['path'])
    seen=set()
    for value in values:
        path=Path(str(value))
        iterable=path.rglob('*') if path.is_dir() else [path]
        for item in iterable:
            if not item.is_file(): continue
            try: resolved=str(item.resolve())
            except OSError: resolved=str(item)
            if resolved in seen: continue
            seen.add(resolved)
            try: size=item.stat().st_size
            except OSError: continue
            if size<=0 or size>4*1024*1024: continue
            if item.suffix.casefold() in _TEXT_SUFFIXES:
                yield item
                continue
            try: sample=item.read_bytes()[:8192]
            except OSError: continue
            if sample and sample.count(b'\x00')/len(sample)<0.02 and sum(32<=b<127 or b in b'\r\n\t' for b in sample)/len(sample)>0.75:
                yield item


def discover_evidence_declarations(config:dict[str,Any], *, max_results:int=0)->list[EvidenceDeclaration]:
    results=[]
    for path in _candidate_files(config):
        try: data=path.read_bytes()
        except OSError: continue
        text,encoding=_decode(data)
        for match in _DECLARATION_RE.finditer(text):
            context=text[max(0,match.start()-80):min(len(text),match.end()+120)]
            if _NEGATION_RE.search(context):
                continue
            terms=sorted(set(re.findall(r'(?i)\b(?:synthetic|fabricated|training|validation|demonstration|test|evidence|corpus|fixture|image|data|artefact|artifact|material)\b',match.group(0))),key=str.casefold)
            prefix=text[:match.start()]
            try: byte_offset=len(prefix.encode(encoding,errors='replace'))
            except LookupError: byte_offset=match.start()
            excerpt=re.sub(r'\s+',' ',context).strip()
            results.append(EvidenceDeclaration(str(path),_sha256(path),encoding,byte_offset,excerpt,terms))
            break
        if max_results > 0 and len(results)>=max_results: break
    results.sort(key=lambda x:(x.sha256,x.path,x.byte_offset))
    return results
