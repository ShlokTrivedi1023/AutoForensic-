"""
core/__init__.py — AutoForensics core package.

The core package contains the two central components of the platform:

  custody_log.py  — append-only, hash-chained chain of custody ledger
  main.py         — ForensicOrchestrator that drives the full investigation pipeline

Import the public API from here; do not import directly from the sub-modules
unless you need implementation-level access.
"""

from __future__ import annotations

from core.custody_log import CustodyEntry, CustodyLogger, EventType

__all__ = [
    "CustodyLogger",
    "CustodyEntry",
    "EventType",
]
