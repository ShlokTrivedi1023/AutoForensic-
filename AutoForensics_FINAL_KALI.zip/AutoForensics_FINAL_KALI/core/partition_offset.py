"""Partition/filesystem offset detection with a native fallback."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

from modules._base import _run_subprocess

_log = logging.getLogger("autoforensics.partition_offset")
_COMMON_OFFSETS = [63, 2048, 64, 128, 0]


def _parse_mmls_output(output: str) -> Optional[int]:
    best: Optional[int] = None
    for line in output.splitlines():
        if re.search(r"NTFS|exFAT|FAT|Linux", line, re.IGNORECASE):
            m = re.search(r"\d{3}:\s+\S+\s+(\d+)", line)
            if m:
                return int(m.group(1))
        if best is None:
            m = re.search(r"\d{3}:\s+\d{3}:\d{3}\s+(\d+)", line)
            if m:
                best = int(m.group(1))
    return best


def _parse_fsstat_output(output: str) -> Optional[int]:
    match = re.search(r"Partition Start.*?(\d+)", output, re.IGNORECASE)
    return int(match.group(1)) if match else None


def _ewf_args(image_type: str) -> list[str]:
    return ["-i", "ewf"] if image_type == "ewf" else []


def detect_partition_offset(
    evidence_path: Path,
    image_type: str,
    logger: logging.Logger = _log,
) -> int:
    """Return a filesystem start in sectors, or ``-1`` if unrecognised."""
    img = str(evidence_path)
    ewf = _ewf_args(image_type)

    # Optional TSK path first, matching the legacy behaviour without sudo.
    for table_type in ("dos", "gpt"):
        rc, out, _ = _run_subprocess(
            ["mmls", "-t", table_type] + ewf + [img], timeout=30, logger=logger
        )
        if rc == 0 and out:
            offset = _parse_mmls_output(out)
            if offset is not None:
                logger.info("[OFFSET] Detected via mmls (%s): %d sectors", table_type, offset)
                return offset

    rc, out, _ = _run_subprocess(["fsstat"] + ewf + [img], timeout=60, logger=logger)
    if rc == 0 and out:
        offset = _parse_fsstat_output(out)
        if offset is not None:
            logger.info("[OFFSET] Detected via fsstat: %d sectors", offset)
            return offset

    for candidate in _COMMON_OFFSETS:
        args = ["-o", str(candidate)] if candidate > 0 else []
        rc, out, _ = _run_subprocess(["fls"] + ewf + args + [img], timeout=15, logger=logger)
        if rc == 0 and out.strip():
            logger.info("[OFFSET] Detected via fls probe: %d sectors", candidate)
            return candidate

    # Native path can parse raw/reconstructed files directly. If an E01 path is
    # supplied, callers should first materialize/open it via core.native_evidence.
    try:
        from core.native_filesystem import best_filesystem
        candidate = best_filesystem(evidence_path)
        if candidate is not None:
            logger.info(
                "[OFFSET] Detected natively: %d sectors (%s, %s)",
                candidate.offset_sectors, candidate.fs_type, candidate.source,
            )
            return candidate.offset_sectors
    except Exception as exc:
        logger.debug("[OFFSET] Native detection failed: %s", exc)

    logger.warning("[OFFSET] Filesystem not recognised by TSK or native detector")
    return -1


from core.evidence_access import probe_filesystem_offset


def detect_partition_offset_mounted(device_path: str, logger=None) -> int:
    import logging as _logging
    log = logger or _logging.getLogger("autoforensics.partition_offset")
    result = probe_filesystem_offset(device_path, log)
    return -1 if result is None else result
