"""Canonical per-case findings database (newline-delimited JSON).

One file: ``<output_dir>/<case_id>_findings.jsonl``.

Only observations that pass the centralized evidence-reference assurance gate
are accepted. Every stored record is content-bound with a SHA-256 digest and is
flushed to disk immediately so the report cannot silently consume an unsupported
or half-written finding.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from core.finding_assurance import validate_evidence_reference


class FindingsStore:
    def __init__(self, store_path: Path) -> None:
        self._path = Path(store_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _canonical_hash(record: dict[str, Any]) -> str:
        payload = dict(record)
        payload.pop("record_sha256", None)
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=True, default=str).encode("utf-8")
        ).hexdigest()

    def append_module_result(self, result: Any, evidence_index: int = 0) -> None:
        """Append all assured findings from a ModuleResult to the store.

        A finding without a valid evidence reference is a programming error at
        this layer and causes a hard failure. The orchestrator normally removes
        such observations before calling this method.
        """
        findings = getattr(result, "findings", []) or []
        for finding in findings:
            if hasattr(finding, "to_dict"):
                finding_data = finding.to_dict()
            else:
                finding_data = dict(vars(finding))
            reference = finding_data.get("evidence_reference") or {}
            if not isinstance(reference, dict):
                raise ValueError(
                    f"Finding {finding_data.get('finding_id', '<unknown>')} has a non-object evidence_reference"
                )
            ok, reason = validate_evidence_reference(reference)
            if not ok:
                raise ValueError(
                    f"Finding {finding_data.get('finding_id', '<unknown>')} failed evidence-reference validation: {reason}"
                )

            record: dict[str, Any] = {
                "evidence_index": evidence_index,
                "module_name": getattr(result, "module_name", ""),
                "module_status": getattr(
                    getattr(result, "status", None),
                    "value",
                    str(getattr(result, "status", "")),
                ),
                **finding_data,
            }
            record["record_sha256"] = self._canonical_hash(record)
            with open(self._path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, default=str, ensure_ascii=True) + "\n")
                fh.flush()
                os.fsync(fh.fileno())

    def all_findings(self, *, verify: bool = True) -> list[dict[str, Any]]:
        """Return all findings and optionally verify every record digest."""
        if not self._path.is_file():
            return []
        results: list[dict[str, Any]] = []
        with open(self._path, encoding="utf-8") as fh:
            for index, line in enumerate(fh):
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                if verify:
                    stored = str(data.get("record_sha256") or "")
                    computed = self._canonical_hash(data)
                    if not stored or stored != computed:
                        raise ValueError(f"Findings-store integrity failure at line {index + 1}")
                    ok, reason = validate_evidence_reference(data.get("evidence_reference") or {})
                    if not ok:
                        raise ValueError(
                            f"Findings-store evidence-reference failure at line {index + 1}: {reason}"
                        )
                results.append(data)
        return results

    def verify(self) -> tuple[bool, str]:
        try:
            records = self.all_findings(verify=True)
            return True, f"{len(records)} finding record(s) verified"
        except Exception as exc:
            return False, str(exc)

    def count_by_severity(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for finding in self.all_findings():
            severity = finding.get("severity", "Unknown")
            if hasattr(severity, "value"):
                severity = severity.value
            severity = str(severity)
            counts[severity] = counts.get(severity, 0) + 1
        return counts
