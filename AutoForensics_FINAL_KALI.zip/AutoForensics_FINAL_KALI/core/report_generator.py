"""
core/report_generator.py

Master report generator for AutoForensics.  Orchestrates the 7-section
forensic report structure (Introduction, Methodology, Isolation, Analysis,
Conclusions, Recommendations, References) plus appendices, renders a
professional PDF with headers, footers, watermark, bookmarks, and
severity-coded tables, mirrors the full output as JSON, then seals the
document with a SHA-256 hash page.

Rendering stack
---------------
ReportLab PLATYPUS  — PDF layout engine (required; install: pip install reportlab)
pypdf               — PDF merging for seal page (required; pip install pypdf)
Pillow (PIL)        — image embedding (already in requirements.txt)
matplotlib          — timeline chart (install: pip install matplotlib)

All four packages are imported conditionally; if one is absent the generator
degrades gracefully and logs a warning rather than raising at import time.

Security guarantees inherited from the rest of the platform
-----------------------------------------------------------
* No shell=True anywhere in this module.
* No raw evidence binaries are sent to any external service.
* All file paths are resolved with Path.resolve() before I/O.
"""

from __future__ import annotations

import base64
import functools
import hashlib
import html as _html
import io
import json
import logging
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Optional, Union

# ---------------------------------------------------------------------------
# Optional heavyweight dependencies — all imported conditionally
# ---------------------------------------------------------------------------

try:
    from reportlab.lib import colors
    from reportlab.lib.colors import HexColor
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm, mm
    from reportlab.platypus import (
        BaseDocTemplate,
        Frame,
        HRFlowable,
        Image,
        KeepTogether,
        ListFlowable,
        ListItem,
        PageBreak,
        PageTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
    )
    from reportlab.platypus.flowables import Flowable
    from reportlab.pdfgen import canvas as rl_canvas
    _REPORTLAB_AVAILABLE = True
except ImportError:  # pragma: no cover
    _REPORTLAB_AVAILABLE = False

try:
    from reportlab.platypus.tableofcontents import TableOfContents as _TOC
    _TOC_AVAILABLE = True
except ImportError:  # pragma: no cover
    _TOC_AVAILABLE = False

try:
    from pypdf import PdfWriter, PdfReader
    _PYPDF_AVAILABLE = True
except ImportError:  # pragma: no cover
    try:
        from PyPDF2 import PdfWriter, PdfReader   # type: ignore[assignment]
        _PYPDF_AVAILABLE = True
    except ImportError:
        _PYPDF_AVAILABLE = False

try:
    from PIL import Image as PILImage
    _PIL_AVAILABLE = True
except ImportError:  # pragma: no cover
    _PIL_AVAILABLE = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _MATPLOTLIB_AVAILABLE = True
except ImportError:  # pragma: no cover
    _MATPLOTLIB_AVAILABLE = False

# Internal package imports
from .case_config import exhibit_id_for
from .custody_log import CustodyEntry, CustodyLogger, EventType
from .report_sections import (
    CaseInfo,
    ContentBlock,
    EvidenceAcquisition,
    FindingItem,
    FindingSeverity,
    InvestigatorDetails,
    KeyFinding,
    ModuleResult,
    ReportMetadata,
    SectionContent,
    ToolEntry,
    _build_findings_subsection,
    _bullets,
    _bytes_to_human,
    _count_by_severity,
    _format_date,
    _format_datetime,
    _h1,
    _h2,
    _h3,
    _kv,
    _module_status_note,
    _numbered,
    _page_break,
    _para,
    _spacer,
    _status_badge,
    _table,
    build_cover_page,
    build_table_of_contents,
    build_executive_summary,
    build_section_one,
    build_investigation_background,
    build_objectives,
    build_legal_authorisation,
    build_chain_of_custody_summary,
    build_investigator_details,
    build_forensic_standards,
    build_methodology,
    build_section_three,
    build_file_system_analysis,
    build_registry_analysis,
    build_browser_activity,
    build_email_analysis,
    build_communication_analysis,
    build_network_analysis,
    build_memory_analysis,
    build_evidence_section,
)
from .report_ai import (
    APICallRecord,
    _build_5w1h,
    _build_5w1h_table,
    _get_jurisdiction_legislation,
    build_ai_deep_analysis,
    build_investigative_conclusions,
    build_recommendations,
    synthesize_report_narrative,
    build_section_malware_analysis,
    build_section_password_recovery,
    build_section_file_carving,
    build_section_metadata_exif,
    build_section_steganography,
    build_section_mobile_device,
    build_section_anti_forensics,
    build_section_cryptocurrency,
    build_section_document_media,
    build_section_geolocation,
    build_section_ai_deep_analysis,
    build_section_keyword_ioc,
    build_section_key_findings,
    build_section_conclusions,
    build_section_recommendations,
    rank_findings,
    _build_material_findings,
    _clean_material_text,
    _ai_disclosure_block,
)
from .report_appendices import (
    build_appendix_declaration,
    build_appendix_chain_of_custody,
    build_appendix_evidence_photos,
    build_appendix_authorisation_letter,
    build_appendix_charts,
    build_appendix_screenshots,
)


# ===========================================================================
# Module-level constants
# ===========================================================================

from core.version import VERSION as _VERSION
_logger  = logging.getLogger("autoforensics.report_generator")


def _reference_exhibit_id(reference: Any) -> str:
    """Extract an exhibit id from a legacy string or structured H2 reference."""
    if isinstance(reference, dict):
        return str(reference.get("exhibit_id") or "")
    return str(reference or "")

# Page geometry (A4)
_PAGE_W, _PAGE_H = A4 if _REPORTLAB_AVAILABLE else (595.28, 841.89)
_MARGIN          = 2.0 * (cm if _REPORTLAB_AVAILABLE else 28.35)
_HEADER_H        = 1.3 * (cm if _REPORTLAB_AVAILABLE else 28.35)
_FOOTER_H        = 0.9 * (cm if _REPORTLAB_AVAILABLE else 28.35)
_FRAME_W         = _PAGE_W - 2 * _MARGIN
_FRAME_H         = _PAGE_H - 2 * _MARGIN - _HEADER_H - _FOOTER_H

# Image dimension limits — proportional clamping prevents frame overflow
_IMG_MAX_W = 450.0   # max image width in points (≈ 158 mm)
_IMG_MAX_H = 620.0   # max image height in points (≈ 219 mm — leaves room for caption)

# Severity colour palette
_SEV_BG = {
    "Critical": "#C0392B",
    "High":     "#D35400",
    "Medium":   "#D4AC0D",
    "Low":      "#1E8449",
}
_SEV_FG = {
    "Critical": "#FFFFFF",
    "High":     "#FFFFFF",
    "Medium":   "#000000",
    "Low":      "#FFFFFF",
}

_TEAL            = "#1ABC9C"
_NAVY            = "#1A252F"
_TABLE_HEADER_BG = "#1A252F"
_TABLE_ROW_ALT   = "#F2F4F4"

# Forensic glossary — standard reference material for non-technical readers
_GLOSSARY: list[tuple[str, str]] = [
    ("Acquisition",         "Creating a forensic bit-for-bit copy (image) of a digital storage "
                            "device without modifying the original."),
    ("Artefact",            "Any file, registry entry, log record, database row, or other "
                            "digital object left behind by software or user activity."),
    ("Chain of Custody",    "The documented, unbroken sequence of possession and handling of "
                            "evidence from seizure through court presentation."),
    ("Carving",             "Recovering files from unallocated disk space by locating known "
                            "file-type signatures (magic bytes) rather than relying on the "
                            "file system directory structure."),
    ("Entropy",             "A statistical measure of randomness in data; high entropy often "
                            "indicates encrypted or compressed content."),
    ("EXIF",                "Exchangeable Image File Format — metadata embedded in image files "
                            "that may include camera model, GPS coordinates, and capture time."),
    ("Forensic Image",      "A sector-by-sector copy of a storage device, including deleted "
                            "files and unallocated space, verified by cryptographic hash."),
    ("Hash / Hash Value",   "A fixed-length cryptographic digest (e.g. SHA-256) that uniquely "
                            "identifies a file's contents; any change to the file produces a "
                            "different hash."),
    ("IOC",                 "Indicator of Compromise — an observable artefact such as a "
                            "malicious IP address, domain, file hash, or registry key that "
                            "suggests a system has been attacked."),
    ("Metadata",            "Data that describes other data — for example, a document's author "
                            "field, a file's creation timestamp, or an image's GPS location."),
    ("MFT",                 "Master File Table — the NTFS file system index that records "
                            "metadata (name, size, timestamps, location) for every file and "
                            "directory on a Windows volume."),
    ("Pagefile / Swap",     "A file on disk used by the operating system as an overflow area "
                            "for RAM; may contain fragments of previously active processes."),
    ("Prefetch",            "Windows files that record which programs have been executed and "
                            "when; useful for proving program execution."),
    ("RAM / Volatile Memory","Random Access Memory — the working memory of a running computer; "
                            "its contents are lost on shutdown, making acquisition time-critical."),
    ("Registry",            "A hierarchical database used by Microsoft Windows to store "
                            "configuration settings, user activity, and software installation "
                            "records."),
    ("Slack Space",         "Unused space between the end of a file's data and the end of its "
                            "allocated cluster; may contain residual data from previously "
                            "deleted files."),
    ("Steganography",       "The practice of concealing data (a payload) inside an innocent "
                            "carrier file such as an image or audio file."),
    ("Timestamp",           "A digital record of when an event occurred; forensic analysis "
                            "commonly examines Created, Modified, Accessed, and MFT-Changed "
                            "(MACE) timestamps."),
    ("Unallocated Space",   "Sectors on a storage device not currently assigned to any file "
                            "by the file system; may contain recoverable deleted file data."),
    ("Write Blocker",       "Hardware or software that prevents any write operation to an "
                            "evidence device during acquisition, preserving evidential "
                            "integrity."),
    ("YARA",                "A pattern-matching language and tool used to identify and classify "
                            "malware by matching byte patterns, strings, or logical conditions."),
]

# Standard forensic references
_DEFAULT_STANDARDS = [
    "ISO/IEC 27037:2012 — Guidelines for identification, collection, acquisition and "
    "preservation of digital evidence",
    "ISO/IEC 27042:2015 — Guidelines for the analysis and interpretation of digital evidence",
    "ACPO Good Practice Guide for Digital Evidence v5 (2012)",
    "NIST SP 800-86 — Guide to Integrating Forensic Techniques into Incident Response",
    "RFC 3227 — Guidelines for Evidence Collection and Archiving",
    "SWGDE Best Practices for Computer Forensics",
]

_DEFAULT_LEGISLATION = [
    "Computer Misuse Act 1990 (UK)",
    "Police and Criminal Evidence Act 1984 (PACE) — Code B",
    "Regulation of Investigatory Powers Act 2000 (RIPA)",
    "UK General Data Protection Regulation (UK GDPR)",
    "Criminal Justice Act 2003 — section 127 (admissibility of business records)",
]


# ===========================================================================
# ReportLab helper classes (only instantiated when _REPORTLAB_AVAILABLE)
# ===========================================================================

if _REPORTLAB_AVAILABLE:

    class _BookmarkFlowable(Flowable):
        """
        Zero-height flowable that inserts a PDF outline/bookmark entry at
        the point where it is drawn.  Used to build the navigation outline
        for every section heading.
        """

        def __init__(self, key: str, title: str, level: int = 0) -> None:
            Flowable.__init__(self)
            self.key   = key
            self.title = title
            self.level = level
            self.width  = 0
            self.height = 0

        def wrap(self, avail_w: float, avail_h: float) -> tuple[float, float]:
            return 0, 0

        def draw(self) -> None:
            self.canv.bookmarkPage(self.key)
            self.canv.addOutlineEntry(
                self.title, self.key, level=self.level, closed=False
            )

    class _AutoForensicsCanvas(rl_canvas.Canvas):
        """
        Two-pass canvas subclass that defers header/footer/watermark drawing
        until the total page count is known (enabling 'Page X of Y' footers).

        On the first pass (during doc.build()), showPage() saves the canvas
        state for each page instead of committing it.  On save(), every saved
        state is restored, decorations are painted, and then the page is
        finally committed to the output file.
        """

        def __init__(self, *args: Any, page_info: dict[str, str], extra_pages: int = 0, **kwargs: Any) -> None:
            rl_canvas.Canvas.__init__(self, *args, **kwargs)
            self._page_states: list[dict[str, Any]] = []
            self._page_info   = page_info
            self._extra_pages = extra_pages
            self.setTitle(f"Digital Forensic Investigation Report — {page_info.get('case_number') or page_info.get('case_id', '')}")
            self.setAuthor(page_info.get("org_name") or "AutoForensics")
            self.setSubject("Evidence-led digital forensic investigation report")
            self.setCreator(f"AutoForensics v{page_info.get('version', '')}")

        def showPage(self) -> None:
            """Save current page state instead of committing immediately."""
            self._page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self) -> None:
            """Revisit every page, paint decorations, then write the PDF."""
            total = len(self._page_states) + self._extra_pages
            for state in self._page_states:
                self.__dict__.update(state)
                self._paint_page(total)
                rl_canvas.Canvas.showPage(self)
            rl_canvas.Canvas.save(self)

        def _paint_page(self, total_pages: int) -> None:
            """Draw watermark, header rule, and footer on the current page."""
            pi = self._page_info
            self.saveState()

            # ---- diagonal watermark (0.05 alpha — barely visible) ----------
            self.setFont("Helvetica-Bold", 54)
            self.setFillColorRGB(0.0, 0.0, 0.0)
            self.setFillAlpha(0.05)
            self.translate(_PAGE_W / 2, _PAGE_H / 2)
            self.rotate(45)
            self.drawCentredString(0, 0, pi["classification"])
            self.setFillAlpha(1.0)
            self.restoreState()

            # ---- solid CONFIDENTIAL banner on cover page only ---------------
            if self._pageNumber == 1:
                self.saveState()
                self.setFillColorRGB(0.75, 0.0, 0.0)
                self.rect(0, 0, _PAGE_W, 22, fill=1, stroke=0)
                self.setFillColorRGB(1.0, 1.0, 1.0)
                self.setFont("Helvetica-Bold", 10)
                self.drawCentredString(_PAGE_W / 2, 7, pi["classification"])
                self.restoreState()

            self.saveState()

            # ---- header rule -----------------------------------------------
            rule_y = _PAGE_H - _MARGIN + 1 * mm
            self.setStrokeColor(HexColor("#2C3E50"))
            self.setLineWidth(0.6)
            self.line(_MARGIN, rule_y, _PAGE_W - _MARGIN, rule_y)

            text_y = rule_y + 1.5 * mm

            # left: branding
            self.setFont("Helvetica-Bold", 7.5)
            self.setFillColor(HexColor("#2C3E50"))
            self.drawString(_MARGIN, text_y, "AutoForensics")

            # centre: case ID
            self.setFont("Helvetica", 7.5)
            self.setFillColor(HexColor("#555555"))
            self.drawCentredString(
                _PAGE_W / 2, text_y, f"Case: {pi['case_id']}"
            )

            # right: classification
            self.setFont("Helvetica-Bold", 7.5)
            self.setFillColor(HexColor("#C0392B"))
            self.drawRightString(_PAGE_W - _MARGIN, text_y, pi["classification"])

            # ---- footer rule -----------------------------------------------
            foot_rule_y = _MARGIN - _FOOTER_H + 1 * mm
            self.setStrokeColor(HexColor("#006b6b"))
            self.setLineWidth(0.3)
            self.line(_MARGIN, foot_rule_y, _PAGE_W - _MARGIN, foot_rule_y)

            foot_y = foot_rule_y - 4 * mm
            case_num = pi.get("case_number", pi.get("case_id", ""))
            org_name = pi.get("org_name", "")

            # left: CONFIDENTIAL | case_number | report title | org
            self.setFont("Helvetica", 7)
            self.setFillColor(HexColor("#666666"))
            left_footer = " | ".join(filter(None, [
                pi["classification"], case_num,
                "Digital Forensic Investigation Report", org_name
            ]))
            self.drawString(_MARGIN, foot_y, left_footer[:100])

            # right: CONFIDENTIAL | Page X of Y
            self.setFont("Helvetica", 7)
            self.setFillColor(HexColor("#666666"))
            self.drawRightString(
                _PAGE_W - _MARGIN, foot_y,
                f"{pi['classification']} | Page {self._pageNumber} of {total_pages}"
            )
            self.restoreState()

    class _FindingBox(Flowable):
        """Coloured finding box with left accent bar for court reports."""

        def __init__(self, text: str, box_type: str = "critical", width_mm: float = 170):
            super().__init__()
            self._text = text
            self._box_type = box_type
            self._width = width_mm * mm
            if box_type == "critical":
                self._border = HexColor("#cc0000")
                self._bg     = HexColor("#fff0f0")
                self._accent = HexColor("#006b6b")
            else:
                self._border = HexColor("#0055cc")
                self._bg     = HexColor("#f0f5ff")
                self._accent = HexColor("#006b6b")

        def wrap(self, availWidth, availHeight):
            self.width = min(self._width, availWidth)
            chars = len(self._text)
            lines = max(2, chars // 70 + 1)
            self.height = lines * 14 + 16
            return self.width, self.height

        def draw(self):
            c = self.canv
            w, h = self.width, self.height
            c.setFillColor(self._bg)
            c.rect(0, 0, w, h, fill=1, stroke=0)
            c.setStrokeColor(self._border)
            c.setLineWidth(1)
            c.rect(0, 0, w, h, fill=0, stroke=1)
            c.setFillColor(self._accent)
            c.rect(0, 0, 4, h, fill=1, stroke=0)
            c.setFillColor(HexColor("#000000"))
            c.setFont("Helvetica-Bold", 9)
            c.drawString(10, h - 13, self._text[:120])
            if len(self._text) > 120:
                c.setFont("Helvetica", 9)
                c.drawString(10, h - 25, self._text[120:240])

    class _ForensicDocTemplate(BaseDocTemplate):
        """
        BaseDocTemplate subclass that hooks afterFlowable to collect
        heading positions for a two-level TableOfContents.
        Uses multiBuild() for two-pass page-number resolution.
        """
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.toc_ref: Any = kwargs.pop("toc_ref", None)
            BaseDocTemplate.__init__(self, *args, **kwargs)

        def afterFlowable(self, flowable: Any) -> None:
            if not self.toc_ref:
                return
            if not isinstance(flowable, Paragraph):
                return
            sname = getattr(getattr(flowable, "style", None), "name", "")
            text = flowable.getPlainText()
            if sname in ("AF_H1", "Heading1", "AF_CoverTitle"):
                key = f"toc-h1-{text[:40]}"
                self.canv.bookmarkPage(key)
                self.notify("TOCEntry", (0, text, self.page, key))
            elif sname in ("AF_H2", "Heading2"):
                key = f"toc-h2-{text[:40]}"
                self.canv.bookmarkPage(key)
                self.notify("TOCEntry", (1, text, self.page, key))

else:  # pragma: no cover — stubs so type-checkers don't complain

    class _BookmarkFlowable:  # type: ignore[no-redef]
        def __init__(self, *a: Any, **kw: Any) -> None: pass

    class _AutoForensicsCanvas:  # type: ignore[no-redef]
        def __init__(self, *a: Any, **kw: Any) -> None: pass

    class _FindingBox:  # type: ignore[no-redef]
        def __init__(self, *a: Any, **kw: Any) -> None: pass

    class _ForensicDocTemplate:  # type: ignore[no-redef]
        def __init__(self, *a: Any, **kw: Any) -> None: pass


def generate_critical_box(text: str, box_type: str = "critical") -> Any:
    """Return a _FindingBox flowable, or None if reportlab is unavailable."""
    if not _REPORTLAB_AVAILABLE:
        return None
    return _FindingBox(text, box_type)


def _std_table_style(has_header: bool = True) -> list:
    """Standard court-report table style (navy header, alternating rows)."""
    if not _REPORTLAB_AVAILABLE:
        return []
    style = [
        ("FONTNAME",      (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 0), (-1, -1), 9),
        ("GRID",          (0, 0), (-1, -1), 0.5, colors.black),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("TOPPADDING",    (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, HexColor("#f5f5f5")]),
    ]
    if has_header:
        style += [
            ("BACKGROUND", (0, 0), (-1, 0), HexColor("#1a2744")),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, 0), 9),
        ]
    return style


# ===========================================================================
# Style sheet factory
# ===========================================================================

def _build_styles() -> dict[str, Any]:
    """
    Create and return the complete ParagraphStyle registry used by the
    renderer.  Returns an empty dict if ReportLab is not installed.
    """
    if not _REPORTLAB_AVAILABLE:
        return {}

    base = getSampleStyleSheet()

    def _s(name: str, **kw: Any) -> ParagraphStyle:
        return ParagraphStyle(name, parent=base["Normal"], **kw)

    TEAL    = HexColor("#006b6b")
    NAVY    = HexColor("#1A252F")
    LTGREY  = HexColor("#F2F4F4")
    PINK_BG = HexColor("#FDEDEC")
    PINK_BD = HexColor("#E74C3C")
    BLUE_BG = HexColor("#EBF5FB")
    BLUE_BD = HexColor("#2E86C1")

    styles: dict[str, Any] = {
        "Normal": _s(
            "AF_Normal",
            fontName="Helvetica", fontSize=9.5, leading=14,
            spaceAfter=5, textColor=HexColor("#1A1A1A"),
            alignment=4,
        ),
        "Heading1": _s(
            "AF_H1",
            fontName="Helvetica-Bold", fontSize=16, leading=19,
            spaceBefore=12, spaceAfter=6,
            textColor=TEAL,
        ),
        "Heading2": _s(
            "AF_H2",
            fontName="Helvetica-Bold", fontSize=13, leading=16,
            spaceBefore=14, spaceAfter=5,
            textColor=TEAL,
        ),
        "Heading3": _s(
            "AF_H3",
            fontName="Helvetica-Bold", fontSize=11, leading=14,
            spaceBefore=9, spaceAfter=4,
            textColor=HexColor("#333333"),
        ),
        "Body": _s(
            "AF_Body",
            fontName="Helvetica", fontSize=10, leading=14,
            spaceAfter=6, textColor=HexColor("#1A1A1A"),
            alignment=4,
        ),
        "Code": _s(
            "AF_Code",
            fontName="Courier", fontSize=7.5, leading=11,
            textColor=HexColor("#1A252F"),
            backColor=HexColor("#F4F6F7"),
            borderColor=HexColor("#BDC3C7"),
            borderWidth=0.5, borderPad=6,
        ),
        "Caption": _s(
            "AF_Caption",
            fontName="Helvetica-Oblique", fontSize=8, leading=11,
            alignment=TA_CENTER, textColor=HexColor("#555555"),
            spaceBefore=2, spaceAfter=8,
        ),
        "CriticalBox": _s(
            "AF_Critical",
            fontName="Helvetica-Bold", fontSize=9.5, leading=13,
            textColor=HexColor("#7B241C"),
            backColor=PINK_BG,
            borderColor=PINK_BD, borderWidth=1.2, borderPad=6,
            spaceAfter=6,
        ),
        "MediumBox": _s(
            "AF_Medium",
            fontName="Helvetica", fontSize=9.5, leading=13,
            textColor=HexColor("#1A5276"),
            backColor=BLUE_BG,
            borderColor=BLUE_BD, borderWidth=1.0, borderPad=6,
            spaceAfter=6,
        ),
        "TableHeader": _s(
            "AF_TH",
            fontName="Helvetica-Bold", fontSize=8.5, leading=11,
            textColor=colors.white, alignment=TA_LEFT,
        ),
        "TableCell": _s(
            "AF_TC",
            fontName="Helvetica", fontSize=8.5, leading=11,
            textColor=HexColor("#1A1A1A"),
        ),
        "AIDisclosure": _s(
            "AF_AI",
            fontName="Helvetica-Oblique", fontSize=8, leading=12,
            textColor=HexColor("#5D4037"), spaceAfter=4,
        ),
        "HashLabel": _s(
            "AF_HL",
            fontName="Helvetica-Bold", fontSize=8.5, leading=11,
            textColor=NAVY,
        ),
        "HashValue": _s(
            "AF_HV",
            fontName="Courier", fontSize=7.5, leading=10,
            textColor=HexColor("#1A252F"),
        ),
        "GlossaryTerm": _s(
            "AF_GT",
            fontName="Helvetica-Bold", fontSize=9, leading=12,
            textColor=NAVY, spaceAfter=1,
        ),
        "GlossaryDef": _s(
            "AF_GD",
            fontName="Helvetica", fontSize=9, leading=13,
            textColor=HexColor("#333333"), spaceAfter=6, leftIndent=12,
        ),
        "SealHeading": _s(
            "AF_SH",
            fontName="Helvetica-Bold", fontSize=20, leading=24,
            alignment=TA_CENTER, textColor=NAVY,
            spaceBefore=30, spaceAfter=16,
        ),
        "SealBody": _s(
            "AF_SB",
            fontName="Helvetica", fontSize=10, leading=14,
            alignment=TA_CENTER, textColor=HexColor("#333333"),
        ),
        "CoverTitle": _s(
            "AF_CoverTitle",
            fontName="Helvetica-Bold", fontSize=22, leading=28,
            alignment=TA_CENTER, textColor=NAVY, spaceAfter=6,
        ),
        "CoverSubtitle": _s(
            "AF_CoverSub",
            fontName="Helvetica-Bold", fontSize=13, leading=17,
            alignment=TA_CENTER, textColor=TEAL, spaceAfter=12,
        ),
        "CoverMeta": _s(
            "AF_CoverMeta",
            fontName="Helvetica", fontSize=9.5, leading=13,
            alignment=TA_CENTER, textColor=HexColor("#444444"),
        ),
        "CoverConfidential": _s(
            "AF_CoverConf",
            fontName="Helvetica-Bold", fontSize=10, leading=14,
            alignment=TA_CENTER, textColor=HexColor("#C0392B"),
            spaceBefore=10, spaceAfter=10,
        ),
        "TocEntry1": _s(
            "AF_TOC1",
            fontName="Helvetica-Bold", fontSize=10, leading=14,
            textColor=NAVY, spaceAfter=2,
        ),
        "TocEntry2": _s(
            "AF_TOC2",
            fontName="Helvetica", fontSize=9, leading=13,
            textColor=HexColor("#333333"), leftIndent=16, spaceAfter=1,
        ),
        "FindingKeyHeading": _s(
            "AF_FKH",
            fontName="Helvetica-Bold", fontSize=10, leading=14,
            textColor=TEAL, spaceBefore=8, spaceAfter=3,
        ),
    }
    return styles


# ===========================================================================
# Output container
# ===========================================================================

@dataclass
class ReportOutput:
    """
    Return value of ReportGenerator.generate().

    Attributes
    ----------
    pdf_path:
        Absolute path to the sealed PDF report.
    json_path:
        Absolute path to the JSON mirror of all 42 sections.
    sha256_hash:
        SHA-256 hex digest of the PDF content BEFORE the seal page was
        appended.  Embed this in the seal page to allow independent
        verification.
    page_count:
        Total page count of the sealed PDF.
    generation_time:
        Wall-clock seconds elapsed from generate() entry to return.
    api_calls_made:
        Total number of successful language-model synthesis calls recorded during generation.
    quality_warnings:
        List of quality-check warning strings logged during generation.
    """

    pdf_path:         Path
    json_path:        Path
    sha256_hash:      str
    page_count:       int
    generation_time:  float
    api_calls_made:   int
    quality_warnings: list[str] = field(default_factory=list)
    signature_path: Optional[Path] = None
    ai_policy_record_path: Optional[Path] = None


# ===========================================================================
# ReportGenerator
# ===========================================================================

class ReportGenerator:
    """
    Master report generator — orchestrates all 42 sections, renders PDF
    and JSON outputs, and seals the document with a cryptographic hash page.

    Usage
    -----
    ::

        gen = ReportGenerator(
            case_id="C-2025-001",
            investigator=my_investigator_details,
            all_module_results=pipeline_outputs,
            coc_logger=custody_logger,
            output_dir=Path("/reports/C-2025-001"),
            api_key="",  # provider credentials are read from environment variables
        )
        result = gen.generate()
        print(result.pdf_path)

    All rendering is performed in-process; no subprocesses are spawned
    and no shell=True calls are made.
    """

    def __init__(
        self,
        case_id: str,
        investigator: Union[str, InvestigatorDetails],
        all_module_results: list[ModuleResult],
        coc_logger: Optional[CustodyLogger],
        output_dir: Union[str, Path],
        api_key: str = "",
        # ---- optional supplementary data -----------------------------------
        report_metadata: Optional[ReportMetadata] = None,
        case_info: Optional[CaseInfo] = None,
        evidence_items: Optional[list[EvidenceAcquisition]] = None,
        investigation_background: Optional[str] = None,
        investigation_objectives: Optional[list[str]] = None,
        legal_authorisation: Optional[dict[str, Any]] = None,
        forensic_standards: Optional[list[str]] = None,
        tools_used: Optional[list[ToolEntry]] = None,
        classification: str = "CONFIDENTIAL",
        case_config: Optional[Any] = None,   # core.case_config.CaseConfig
        case_dir: Optional[Path] = None,
        all_evidence_results: Optional[list] = None,  # per-evidence pipeline results
        findings_store_path: Optional[str] = None,    # path to <case_id>_findings.jsonl
        tool_versions: Optional[dict] = None,          # from populate_tool_versions()
        require_llm: bool = False,                     # STEP 4: strict LLM mode
    ) -> None:
        """
        Parameters
        ----------
        case_id:
            Unique case identifier — used in filenames, headers, and the
            chain of custody log.
        investigator:
            Lead examiner.  Accepts either a plain string (treated as the
            examiner's name) or a fully populated InvestigatorDetails object.
        all_module_results:
            Complete list of ModuleResult objects from every analysis module
            that was executed.
        coc_logger:
            Live CustodyLogger instance.  The generator logs a
            REPORT_GENERATED event at the start of generate(); pass None
            to skip CoC logging (useful in tests).
        output_dir:
            Directory where output files (PDF, JSON) are written.  Created
            if it does not exist.
        api_key:
            Deprecated compatibility parameter. Provider credentials are read
            only from the environment by ``core.llm_provider``. The value is
            ignored and must not be used to pass secrets in application code.
        report_metadata:
            Pre-built ReportMetadata.  If None a minimal default is
            constructed from case_id and investigator.
        case_info:
            Pre-built CaseInfo.  If None a minimal default is constructed.
        evidence_items:
            List of EvidenceAcquisition records for sections 8, 13, 39.
        investigation_background:
            Narrative text for section 5 (Investigation Background).
        investigation_objectives:
            Ordered list of objective sentences for section 6.
        legal_authorisation:
            Dict with keys: authority_description, authorising_officer,
            authorising_organisation, reference_number, date_of_authority,
            scope_of_authority.
        forensic_standards:
            List of standard names for section 10.  Defaults to
            _DEFAULT_STANDARDS.
        tools_used:
            List of ToolEntry objects for section 12.
        classification:
            Document classification level (default 'CONFIDENTIAL').
        """
        self._case_id          = case_id
        self._safe_case_id     = re.sub(r"[^\w\-]", "_", case_id)
        self._api_key          = api_key
        self._require_llm      = require_llm
        self._coc_logger       = coc_logger
        self._all_module_results = list(all_module_results)
        self._output_dir       = Path(output_dir).resolve()
        self._case_dir         = Path(case_dir).resolve() if case_dir else self._output_dir
        self._classification   = classification
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._api_log: list[APICallRecord] = []
        self._quality_warnings: list[str] = []
        self._tmp_chart_files: list[str] = []   # deleted after doc.build()

        # Normalise investigator to InvestigatorDetails
        if isinstance(investigator, str):
            self._investigator = InvestigatorDetails(
                name=investigator,
                title="Forensic Examiner",
                organisation="",
                role_in_case="Lead Examiner",
            )
        else:
            self._investigator = investigator

        # Build metadata if not supplied
        today = date.today()
        self._metadata = report_metadata or ReportMetadata(
            case_number=case_id,
            report_title=f"Digital Forensic Examination Report — {case_id}",
            examiner_name=self._investigator.name,
            examiner_organisation=self._investigator.organisation or "AutoForensics",
            report_date=today,
            classification=classification,
        )

        self._case_info = case_info or CaseInfo(
            case_number=case_id,
            case_title=f"Digital Forensic Examination — {case_id}",
            client_name="",
            client_organisation="",
            client_contact="",
            client_email="",
            date_received=today,
            date_commenced=today,
        )

        self._evidence_items    = evidence_items or []
        self._inv_background    = investigation_background
        self._objectives        = investigation_objectives
        self._legal_auth        = legal_authorisation
        self._forensic_standards = forensic_standards or list(_DEFAULT_STANDARDS)
        self._tools_used        = tools_used or []

        # CaseConfig overrides — apply after defaults so config wins
        self._case_config = case_config
        if case_config is not None:
            self._apply_case_config(case_config)

        # Per-evidence pipeline results — used for honest certification text
        self._all_evidence_results: list = list(all_evidence_results) if all_evidence_results else []

        # Tool versions detected at startup — used in references section
        self._tool_versions: dict = tool_versions or {}

        self._fig_counter: int = 0

        # Canonical findings store — read-only during report generation
        _store_path = findings_store_path or getattr(case_config, "findings_store_path", None)
        if _store_path and Path(_store_path).is_file():
            from core.findings_store import FindingsStore
            self._findings_store = FindingsStore(Path(_store_path))
        else:
            self._findings_store = None

        # ReportLab style sheet — empty dict when ReportLab is absent
        self._styles = _build_styles()

    def _next_fig(self, caption: str) -> str:
        """Return 'Fig N — caption' and increment the instance-level counter."""
        self._fig_counter += 1
        return f"Fig {self._fig_counter} — {caption}"

    # -----------------------------------------------------------------------
    # CaseConfig integration
    # -----------------------------------------------------------------------

    def _apply_case_config(self, cfg: Any) -> None:
        """Populate all metadata fields from a CaseConfig object."""
        from datetime import date as _date
        today = _date.today()

        self._metadata = ReportMetadata(
            case_number=cfg.case_number,
            report_title=cfg.case_title,
            examiner_name=cfg.examiner.name,
            examiner_organisation=cfg.org_name or cfg.examiner.institution,
            report_date=today,
            classification=cfg.classification,
            client_name=cfg.client_representative.name,
            client_organisation=cfg.client_representative.organisation,
            report_reference=cfg.report_reference,
        )

        dr = cfg.date_received
        dc = cfg.date_commenced or today

        self._case_info = CaseInfo(
            case_number=cfg.case_number,
            case_title=cfg.case_title,
            client_name=cfg.client_representative.name,
            client_organisation=cfg.client_representative.organisation,
            client_contact="",
            client_email=cfg.client_representative.email,
            date_received=dr,
            date_commenced=dc,
            jurisdiction=cfg.jurisdiction,
            case_type=", ".join(cfg.offence_types) if cfg.offence_types else "",
        )

        self._investigator = InvestigatorDetails(
            name=cfg.examiner.name,
            title="Forensic Examiner",
            organisation=cfg.org_name or cfg.examiner.institution,
            role_in_case="Lead Examiner",
            badge_number=cfg.examiner.badge,
            contact_email=cfg.examiner.email,
            certifications=cfg.examiner.certifications,
            supervisor_name=cfg.supervising_examiner.name,
            supervisor_email=cfg.supervising_examiner.email,
        )

        if cfg.investigation_background:
            self._inv_background = cfg.investigation_background

        if cfg.objectives:
            self._objectives = cfg.objectives

        if not self._legal_auth:
            auth = cfg.authorising_officer
            self._legal_auth = {
                "authority_description": (
                    f"Investigation authorised by {auth.name}, {auth.title}"
                    if auth.name else "Investigation authorised per standing instructions"
                ),
                "authorising_officer": auth.name,
                "authorising_organisation": auth.organisation,
                "reference_number": cfg.report_reference,
                "date_of_authority": dr.isoformat() if hasattr(dr, "isoformat") else (str(dr) if dr else "Not supplied"),
                "scope_of_authority": (
                    "Examination of submitted digital media in connection with "
                    + (", ".join(cfg.offence_types) or "the matter under investigation")
                ),
            }

    def _discover_evidence_exhibits(self) -> list[tuple[str, str]]:
        """Return ordered (exhibit_id, label) pairs for the per-evidence sections.

        Order and labels are taken from case_config evidence items when present;
        any exhibit that appears in the attributed findings but not in config is
        appended so no discovered evidence item is dropped.  The number of items
        is discovered at runtime — never assumed to be one.
        """
        ordered: list[tuple[str, str]] = []
        cfg = self._case_config
        items: list = []
        if cfg is not None:
            items = (cfg.get("evidence_items", []) if isinstance(cfg, dict)
                     else getattr(cfg, "evidence_items", None) or [])
        for i, it in enumerate(items):
            # Same resolver the orchestrator source-stamp uses, so a section's
            # exhibit id matches the id its findings were stamped with.
            exhibit = exhibit_id_for(i, cfg)
            if isinstance(it, dict):
                label = (it.get("label") or it.get("name")
                         or it.get("description") or f"Evidence {i + 1}")
            else:
                label = (getattr(it, "label", "") or getattr(it, "name", "")
                         or getattr(it, "description", "") or f"Evidence {i + 1}")
            ordered.append((exhibit, str(label)))

        known = {ex for ex, _ in ordered}
        has_unattributed = False
        for r in self._all_module_results:
            for f in getattr(r, "findings", []):
                ref = _reference_exhibit_id(getattr(f, "evidence_reference", ""))
                if not ref:
                    has_unattributed = True
                elif ref not in known:
                    known.add(ref)
                    ordered.append((ref, ref))
        # Safety net: findings that resolved to no configured exhibit are never
        # dropped or silently misattributed — they render under their own
        # clearly-labelled section so the report stays truthful.
        if has_unattributed:
            ordered.append(("", "Unattributed Findings (evidence not matched to a declared exhibit)"))
        return ordered

    def _manifest_exhibit_ids(self) -> set[str]:
        """Exhibit ids of the evidence items ingested this run, per the manifest.

        Resolved through the shared resolver so it matches the id each finding
        was stamped with at the source.  Empty when no evidence is declared.
        """
        cfg = self._case_config
        if cfg is None:
            return set()
        items = (cfg.get("evidence_items", []) if isinstance(cfg, dict)
                 else getattr(cfg, "evidence_items", None) or [])
        return {exhibit_id_for(i, cfg) for i in range(len(items))}

    def _assert_findings_attributed(self) -> None:
        """Fail hard if any finding lacks an exhibit id while exhibits are declared.

        On a correct run this is unreachable — the orchestrator stamps every
        finding at the source, where the evidence identity is unambiguous.  It
        fires only when attribution was skipped or lost, which is a real defect:
        evidence must never be silently bucketed or misattributed in a court
        report.  With no evidence declared there is nothing to attribute to, so
        the guard stands down (single-section render).
        """
        if not self._manifest_exhibit_ids():
            return
        orphans: set[str] = set()
        for r in self._all_module_results:
            for f in getattr(r, "findings", []) or []:
                if not (getattr(f, "evidence_reference", "") or ""):
                    orphans.add(getattr(r, "module_name", "?"))
                    break
        if orphans:
            raise RuntimeError(
                "Report assembly aborted: finding(s) without an exhibit id from "
                f"module(s): {', '.join(sorted(orphans))}. Every finding must "
                "carry the exhibit id stamped at the source."
            )

    def _build_evidence_analysis_sections(self, start_number: int = 4):
        """Build the per-evidence §4+ analysis sections — the real assembly path.

        Returns ``(sections, next_section_number)``.  One section per exhibit
        discovered at runtime; each finding is routed to the section of the
        exhibit it was stamped with, so no exhibit is dropped and no finding is
        misattributed.  Fails hard if a manifest exhibit produced no section.
        """
        exhibits = self._discover_evidence_exhibits()
        if not exhibits:
            # No evidence items and no attribution discoverable → single section.
            single = _build_section_analysis(
                self._all_module_results, self._evidence_items,
            )
            return [single], start_number + 1

        sections = []
        emitted_real: set[str] = set()
        for ev_idx, (exhibit, label) in enumerate(exhibits):
            # With one exhibit, every module outcome belongs to that exhibit even
            # when it produced zero findings.  Preserve those empty/caveated/
            # skipped outcomes so the report cannot confuse silence with a clean
            # result.  Multi-exhibit runs still require finding attribution until
            # the orchestrator stores per-evidence no-finding records.
            filtered = _results_for_exhibit(
                self._all_module_results, exhibit, include_empty=(len(exhibits) == 1)
            )
            sections.append(_build_section_analysis(
                filtered,
                self._evidence_items,
                section_number=start_number + ev_idx,
                section_title=f"Analysis: {label}",
            ))
            if exhibit:
                emitted_real.add(exhibit)

        # Regression guard (permanent): every exhibit in the manifest must have
        # produced its own analysis section.  A shortfall here is the
        # multi-exhibit dedup bug, which previously dropped a whole exhibit.
        missing = self._manifest_exhibit_ids() - emitted_real
        if missing:
            raise RuntimeError(
                "Analysis sections missing for ingested evidence item(s): "
                f"{', '.join(sorted(missing))} "
                f"(emitted {', '.join(sorted(emitted_real)) or 'none'})"
            )
        return sections, start_number + len(exhibits)

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def generate(self) -> ReportOutput:
        """
        Run the complete report generation pipeline.

        Steps
        -----
        1. Enforce the optional OpenAI policy or deterministic fallback.
        2. Log REPORT_GENERATED to the chain of custody.
        3. Run all AI synthesis functions (timeline, rankings, analysis,
           conclusions, recommendations).
        4. Build all 42 SectionContent objects.
        5. Quality-check the section list.
        6. Render PDF and JSON.
        7. Compute SHA-256 of the PDF content.
        8. Append the cryptographic seal page to the PDF.
        9. Return ReportOutput.

        Returns
        -------
        ReportOutput
            Paths to the sealed PDF and JSON, content hash, page count,
            elapsed time, and API call count.
        """
        t_start = time.monotonic()
        self._fig_counter = 0

        # Provider credentials are read directly by core.llm_provider from the
        # relevant environment variable.  The legacy constructor parameter is
        # deliberately ignored so secrets are not copied or re-routed here.

        # Privacy gate: cloud synthesis receives structured case-derived data,
        # so it is blocked unless the case file contains explicit, auditable
        # consent. Deterministic synthesis remains the safe default.
        from .ai_policy import enforce_ai_policy, write_ai_policy_record
        ai_policy_record = enforce_ai_policy(
            self._case_config, require_llm=self._require_llm
        )
        ai_policy_record_path = write_ai_policy_record(
            self._output_dir, self._case_id, ai_policy_record
        )

        # --- CoC event -----------------------------------------------------
        if self._coc_logger:
            try:
                self._coc_logger.log(
                    EventType.REPORT_GENERATED,
                    description=f"Report generation started for case {self._case_id}",
                    metadata={"generator_version": _VERSION},
                )
            except RuntimeError:
                # Logger already sealed — log locally only
                _logger.warning("CoC logger sealed before report generation; skipping event.")

        # --- Auto-detect tools if none supplied ----------------------------
        tools = self._tools_used or _detect_tools()

        # Apply tool_versions overrides from case_config only when runtime detection failed
        _tv_overrides: dict = getattr(self._case_config, "tool_versions", {}) if self._case_config else {}
        if _tv_overrides:
            _name_map = {"hashcat": "hashcat", "john": "John the Ripper"}
            for tool_entry in tools:
                for cfg_key, entry_name in _name_map.items():
                    if tool_entry.name == entry_name and cfg_key in _tv_overrides:
                        if tool_entry.version in ("", "unknown", "not installed"):
                            tool_entry.version = str(_tv_overrides[cfg_key])

        # --- AI synthesis ---------------------------------------------------
        _logger.info("Starting AI synthesis for case %s", self._case_id)
        ai_analysis       = build_ai_deep_analysis(
            self._all_module_results, self._case_info, self._api_log
        )
        key_findings_list = rank_findings(self._all_module_results)
        conclusions       = build_investigative_conclusions(
            self._all_module_results, ai_analysis, self._api_log,
            case_config=self._case_config,
        )
        recommendations   = build_recommendations(self._all_module_results, self._api_log, self._case_config)

        # --- Evidence-backed narrative (the ONE LLM synthesis per report) ----
        # Called exactly once here — never inside a per-section builder — so the
        # successful-call telemetry stays at one.  strict is driven by the
        # --require-llm / REQUIRE_LLM option (STEP 4), which sets self._require_llm.
        synthesis_payload = build_synthesis_payload(
            self._case_config, self._all_module_results
        )
        synthesis_payload["correlation_context"] = _rg_build_correlation_context(self._case_dir)
        _extra_times = _rg_collect_case_output_timestamps(self._case_dir)
        if _extra_times:
            _temporal = synthesis_payload.setdefault("temporal_context", {})
            _existing = list(_temporal.get("evidence_timestamp_records") or [])
            _merged_times = {(str(x.get("timestamp")), str(x.get("kind")), str(x.get("source"))): x for x in _existing + _extra_times}
            _records = sorted(_merged_times.values(), key=lambda x: x.get("timestamp", ""))
            _temporal["evidence_timestamp_records"] = _records
            for _kind, _key in (("artefact", "artefact_timestamp_range"), ("filesystem", "filesystem_timestamp_range")):
                _vals = sorted({x.get("timestamp") for x in _records if x.get("kind") == _kind and x.get("timestamp")})
                _temporal[_key] = {
                    "earliest": _vals[0] if _vals else "",
                    "latest": _vals[-1] if _vals else "",
                    "validated_timestamp_count": len(_vals),
                }
        _corr = synthesis_payload.get("correlation_context") or {}
        _ledger = synthesis_payload.setdefault("claim_ledger", [])
        _allowed = synthesis_payload.setdefault("allowed_evidence_ids", [])
        for _idx, _item in enumerate((_corr.get("recurring_values") or [])[:12], 1):
            _cid = f"COR-{_idx:02d}"
            _ledger.append({
                "id": _cid,
                "type": "artefact_correlation",
                "fact": (
                    f"The evidence-derived value {_item.get('value')} occurs in "
                    f"{', '.join(_item.get('sources') or [])}. Co-occurrence is an internal "
                    "artefact correlation and does not establish identity, ownership, motive or external communication."
                ),
            })
            _allowed.append(_cid)
        narrative = synthesize_report_narrative(
            synthesis_payload,
            strict=getattr(self, "_require_llm", False),
            api_log=self._api_log,
        )
        self._narrative_assurance = {
            "llm_attempted": bool(narrative.get("llm_attempted")),
            "llm_used": bool(narrative.get("llm_used")),
            "llm_rejected": bool(narrative.get("llm_rejected")),
            "provider": str(narrative.get("llm_provider") or ""),
            "model": str(narrative.get("llm_model") or ""),
            "attempts": int(narrative.get("llm_attempts") or 0),
            "rejection_reason": str(narrative.get("llm_rejection_reason") or ""),
            "structured_fields_evidence_locked": bool(narrative.get("structured_fields_evidence_locked")),
            "deterministic_fallback_used": bool(narrative.get("llm_rejected") and not narrative.get("llm_used")),
        }
        # LLM-composed prose (or the labelled fallback, banner included) supersedes
        # the deterministic conclusions/recommendations for §5.3 and §6.
        if narrative.get("conclusions"):
            conclusions = narrative["conclusions"]
        if narrative.get("recommendations"):
            recommendations = narrative["recommendations"]

        # --- Build 7-section structure --------------------------------------
        _logger.info("Building report sections (7-section structure)")
        all_f = self._all_findings()

        # Resolve custody JSONL path from the live logger or parent directory
        if self._coc_logger and hasattr(self._coc_logger, "_ledger_path"):
            custody_jsonl_path: Optional[Path] = self._coc_logger._ledger_path
        else:
            candidate = self._output_dir.parent / f"{self._safe_case_id}_custody.jsonl"
            custody_jsonl_path = candidate if candidate.exists() else None

        # Build chart ContentBlocks for Appendix B
        from .report_loader import (
            _chart_severity_pie, _chart_file_type_bar, _chart_timeline_from_files,
        )
        chart_blocks: list = []
        pie = _chart_severity_pie(all_f)
        if pie:
            chart_blocks.append(pie)
        for r in self._all_module_results:
            if r.raw_data:
                by_type = (
                    r.raw_data.get("by_type")
                    or r.raw_data.get("statistics", {}).get("by_type")
                    or r.raw_data.get("carving_summary", {}).get("by_type")
                    or r.raw_data.get("carving_summary", {}).get("file_counts")
                )
                if by_type:
                    bar = _chart_file_type_bar(by_type)
                    if bar:
                        chart_blocks.append(bar)
                    break
        for r in self._all_module_results:
            if r.raw_data and "file_listing" in r.raw_data:
                tl = _chart_timeline_from_files(r.raw_data["file_listing"])
                if tl:
                    chart_blocks.append(tl)
                break

        sections: list[SectionContent] = []
        sections.append(build_cover_page(
            self._metadata, self._case_info, self._investigator,
            case_config=self._case_config,
            tool_versions=self._tool_versions,
        ))
        sections.append(build_table_of_contents())
        sections.append(_build_section_introduction(self._case_info, self._metadata, [self._investigator], case_config=self._case_config))
        sections.append(_build_section_methodology(tools, None))
        sections.append(build_section_three(
            self._evidence_items,
            case_config=self._case_config,
            all_module_results=self._all_module_results,
        ))
        # Section 4+ are per-evidence analysis sections, one per evidence item
        # discovered at runtime.  Findings are read from the authoritative flat
        # list (self._all_module_results) — already stamped at the source with
        # the correct evidence_reference — and grouped per exhibit.  Fail hard
        # before assembly if any finding is unattributed while exhibits are
        # declared (a real defect; never silently bucketed or misattributed).
        self._assert_findings_attributed()
        _analysis_sections, conclusions_section_num = \
            self._build_evidence_analysis_sections(start_number=4)
        sections.extend(_analysis_sections)
        sections.append(_build_section_conclusions_5w1h(
            conclusions, key_findings_list, all_f, self._case_info,
            self._all_module_results, self._case_config,
            section_number=conclusions_section_num,
            narrative=narrative,
        ))
        sections.append(build_section_recommendations(recommendations, self._api_log))
        # ── Assurance sections ──────────────────────────────────────────────────
        _cov_sec = _build_section_coverage_summary(self._all_module_results)
        if _cov_sec is not None:
            sections.append(_cov_sec)
        _lim_sec = _build_section_global_limitations(self._all_module_results)
        if _lim_sec is not None:
            sections.append(_lim_sec)
        sections.append(_build_section_references(tools, self._case_config, self._tool_versions))
        # ── Appendices ────────────────────────────────────────────────────
        sections.append(build_appendix_declaration(
            case_config=self._case_config,
            investigator=self._investigator,
            metadata=self._metadata,
            coc_logger=self._coc_logger,
            all_evidence_results=self._all_evidence_results or None,
            evidence_items=self._evidence_items or None,
        ))
        sections.append(build_appendix_chain_of_custody(
            coc_logger=self._coc_logger,
            case_config=self._case_config,
            investigator=self._investigator,
        ))
        sections.append(build_appendix_evidence_photos(
            case_config=self._case_config,
        ))
        sections.append(build_appendix_authorisation_letter(
            case_config=self._case_config,
        ))
        sections.append(build_appendix_charts(
            all_module_results=self._all_module_results,
            coc_logger=self._coc_logger,
            case_output_dir=self._case_dir,
            all_evidence_results=self._all_evidence_results or None,
        ))
        from .report_loader import collect_module_screenshots
        _auto_sc = collect_module_screenshots(self._case_dir)
        sections.append(build_appendix_screenshots(
            case_config=self._case_config,
            auto_screenshots=_auto_sc,
        ))

        # --- Quality checks -------------------------------------------------
        self._check_quality(sections)

        # --- Write outputs --------------------------------------------------
        final_pdf = self._write_pdf(sections)
        final_hash = self._compute_file_hash(final_pdf)
        json_path = self._write_json(sections, final_hash)
        json_hash = self._compute_file_hash(json_path)
        manifest_path = self._output_dir / f"{self._safe_case_id}_report_manifest.json"
        manifest = {
            "case_id": self._case_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "generator_version": _VERSION,
            "report_pdf": final_pdf.name,
            "report_pdf_sha256": final_hash,
            "report_json": json_path.name,
            "report_json_sha256": json_hash,
            "statement": (
                "These hashes permit file-integrity verification only. They do not certify "
                "forensic accuracy, examination completeness, physical custody or examiner approval."
            ),
        }
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        (self._output_dir / f"{self._safe_case_id}_report.sha256").write_text(
            f"{final_hash}  {final_pdf.name}\n{json_hash}  {json_path.name}\n",
            encoding="utf-8",
        )
        page_count = self._count_pages(final_pdf)

        # Fail closed on the generated package itself.  This checks the PDF and
        # JSON that will be handed to the examiner, not merely intermediate data.
        audit_tool = Path(__file__).resolve().parent.parent / "tools" / "report_output_audit.py"
        if audit_tool.is_file():
            import subprocess as _subprocess, sys as _sys
            audit_cmd = [_sys.executable, str(audit_tool), "--pdf", str(final_pdf), "--report-json", str(json_path)]
            if getattr(self, "_require_llm", False):
                audit_cmd.append("--require-llm-record")
            audit = _subprocess.run(audit_cmd, capture_output=True, text=True, timeout=180)
            (self._output_dir / f"{self._safe_case_id}_report_audit.txt").write_text(
                (audit.stdout or "") + (audit.stderr or ""), encoding="utf-8"
            )
            if audit.returncode != 0:
                raise RuntimeError(
                    "Post-generation report audit failed; report is not approved for distribution. "
                    + ((audit.stdout or audit.stderr or "").strip()[-1200:])
                )

        # Detached Ed25519 examiner signature. When required by the case
        # configuration, absence/mismatch of the key fails closed.
        signature_path = None
        signing_cfg = getattr(self._case_config, "signing", None) if self._case_config else None
        require_signature = bool(getattr(signing_cfg, "require_signature", False))
        private_key_path = str(getattr(signing_cfg, "private_key_path", "") or "")
        public_key_path = str(getattr(signing_cfg, "public_key_path", "") or "")
        if require_signature or private_key_path:
            if not private_key_path:
                raise RuntimeError(
                    "Report signature is required but signing.private_key_path is empty."
                )
            from .report_signing import sign_report_package
            signature_path = sign_report_package(
                case_id=self._case_id,
                pdf_path=final_pdf,
                json_path=json_path,
                private_key_path=private_key_path,
                public_key_path=public_key_path or None,
                signer_name=self._investigator.name,
                signer_role=str(getattr(signing_cfg, "signer_role", "Forensic Examiner")),
            )
            signature_doc = json.loads(signature_path.read_text(encoding="utf-8"))
            manifest["detached_signature"] = signature_path.name
            manifest["signature_algorithm"] = signature_doc.get("algorithm")
            manifest["signing_public_key_sha256"] = signature_doc.get("public_key_sha256")
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            if self._coc_logger:
                try:
                    self._coc_logger.log(
                        EventType.REPORT_SIGNED,
                        description=f"Detached Ed25519 signature created for {final_pdf.name}",
                        evidence_path=str(final_pdf),
                        metadata={
                            "signature_path": str(signature_path),
                            "report_pdf_sha256": final_hash,
                            "report_json_sha256": json_hash,
                            "public_key_sha256": signature_doc.get("public_key_sha256"),
                        },
                    )
                except RuntimeError:
                    _logger.warning("CoC logger sealed before report-signature event.")

        elapsed = time.monotonic() - t_start
        _logger.info(
            "Report complete: pages=%d api_calls=%d time=%.1fs path=%s",
            page_count, len(self._api_log), elapsed, final_pdf,
        )

        return ReportOutput(
            pdf_path=final_pdf,
            json_path=json_path,
            sha256_hash=final_hash,
            page_count=page_count,
            generation_time=elapsed,
            api_calls_made=len(self._api_log),
            quality_warnings=list(self._quality_warnings),
            signature_path=signature_path,
            ai_policy_record_path=ai_policy_record_path,
        )

    # -----------------------------------------------------------------------
    # Section assembly helpers
    # -----------------------------------------------------------------------

    def _get_module(self, keyword: str) -> Optional[ModuleResult]:
        """
        Return the first ModuleResult whose name contains keyword
        (case-insensitive).  Returns None if no match is found.
        """
        kw = keyword.lower()
        for r in self._all_module_results:
            if kw in r.module_name.lower():
                return r
        return None

    def _placeholder_module(self, name: str) -> ModuleResult:
        """
        Return a zero-finding ModuleResult with status='failed' to stand
        in for a module that was not part of this investigation pipeline.
        """
        return ModuleResult(
            module_name=name,
            module_version="N/A",
            run_timestamp=datetime.now(timezone.utc),
            status="failed",
            error_message=f"{name} was not executed in this investigation pipeline.",
        )

    def _all_findings(self) -> list[FindingItem]:
        """Collect every FindingItem from every module result."""
        return [f for r in self._all_module_results for f in r.findings]

    # -----------------------------------------------------------------------
    # Quality checks
    # -----------------------------------------------------------------------

    def _check_quality(self, sections: list["SectionContent"]) -> list[str]:
        """
        Validate the section list before PDF rendering.

        Checks that sections 1-7 are present (7-section structure) and
        that no numbered section has an empty blocks list.
        """
        warnings: list[str] = []
        section_numbers = {s.section_number for s in sections}
        for expected in range(1, 8):
            if expected not in section_numbers:
                msg = f"Section {expected} missing from report"
                warnings.append(msg)
                self._quality_warnings.append(msg)
                _logger.warning("Quality check: %s", msg)
        for s in sections:
            if s.section_number > 0 and not s.blocks:
                msg = f"Section {s.section_number} ({s.section_title}) has no content blocks"
                warnings.append(msg)
                self._quality_warnings.append(msg)
                _logger.warning("Quality check: %s", msg)
        return warnings

    # -----------------------------------------------------------------------
    # PDF rendering
    # -----------------------------------------------------------------------

    def _render_block(self, block: ContentBlock) -> list[Any]:
        """
        Convert one ContentBlock to a list of ReportLab Flowables.

        Unknown block types are rendered as a plain paragraph prefixed with
        the block type name so they are visible rather than silently dropped.
        """
        if not _REPORTLAB_AVAILABLE:
            return []

        bt = block.block_type
        d  = block.data
        S  = self._styles   # style shorthand

        # ---- headings with PDF bookmarks -----------------------------------
        if bt == "heading1":
            text = d.get("text", "")
            key  = f"s{abs(hash(text)) % 99999}"
            return [
                _BookmarkFlowable(key, text, level=0),
                Paragraph(f"<b>{text}</b>", S["Heading1"]),
                HRFlowable(
                    width="100%", thickness=1.5,
                    color=HexColor("#2C3E50"), spaceAfter=4,
                ),
            ]

        if bt == "heading2":
            text = d.get("text", "")
            key  = f"h2_{abs(hash(text)) % 99999}"
            return [
                _BookmarkFlowable(key, text, level=1),
                Paragraph(f"<b>{text}</b>", S["Heading2"]),
            ]

        if bt == "heading3":
            return [Paragraph(f"<b><i>{d.get('text', '')}</i></b>", S["Heading3"])]

        # ---- body text -----------------------------------------------------
        if bt == "paragraph":
            raw = d.get("text", "")
            # Escape XML special chars that are not already wrapped in tags
            # Only escape if the text does not already contain markup
            if "<" not in raw and "&" not in raw:
                raw = (raw.replace("&", "&amp;")
                           .replace("<", "&lt;")
                           .replace(">", "&gt;"))
            return [Paragraph(raw, S["Normal"])]

        # ---- table ---------------------------------------------------------
        if bt == "table":
            return self._render_table(d.get("headers", []), d.get("rows", []))

        # ---- list types ----------------------------------------------------
        if bt == "bullet_list":
            items = d.get("items", [])
            if not items:
                return []
            return [
                ListFlowable(
                    [ListItem(Paragraph(str(i), S["Normal"]), leftIndent=12)
                     for i in items],
                    bulletType="bullet",
                    leftIndent=12,
                )
            ]

        if bt == "numbered_list":
            items = d.get("items", [])
            if not items:
                return []
            return [
                ListFlowable(
                    [ListItem(Paragraph(str(i), S["Normal"]), leftIndent=16)
                     for i in items],
                    bulletType="1",
                    leftIndent=16,
                )
            ]

        # ---- key-value pairs -----------------------------------------------
        if bt == "key_value":
            return self._render_kv(d.get("pairs", []))

        # ---- spacer / page break -------------------------------------------
        if bt == "spacer":
            return [Spacer(1, d.get("height_mm", 4) * mm)]

        if bt == "page_break":
            return [PageBreak()]

        # ---- image from file path ------------------------------------------
        if bt == "image":
            return self._render_image_from_path(d)

        # ---- chart placeholder — dispatch to live chart generators ---------
        if bt == "chart_placeholder":
            chart_key = d.get("chart", "")
            from .report_loader import (
                _chart_severity_pie,
                _chart_file_type_bar,
                _chart_timeline_from_files,
            )
            if chart_key == "severity_distribution":
                cb = _chart_severity_pie(self._all_findings())
            elif chart_key == "file_types":
                # Build extension→count from findings artefact_location paths
                by_type: dict[str, int] = {}
                for r in self._all_module_results:
                    if r.raw_data:
                        bt_data = (
                            r.raw_data.get("by_type")
                            or r.raw_data.get("statistics", {}).get("by_type")
                            or r.raw_data.get("carving_summary", {}).get("by_type")
                        )
                        if bt_data:
                            by_type = bt_data
                            break
                if not by_type:
                    # Fallback: derive from findings artefact_location extensions
                    import os as _os_mod
                    for r in self._all_module_results:
                        for f in r.findings:
                            loc = getattr(f, "artefact_location", "") or ""
                            ext = _os_mod.path.splitext(loc)[-1].lower()
                            if ext:
                                by_type[ext] = by_type.get(ext, 0) + 1
                cb = _chart_file_type_bar(by_type) if by_type else None
            elif chart_key in ("module_timeline", "module_timing"):
                # Render the module-timing chart from the single canonical
                # source used by Appendix E.3 — no separate file_listing path
                # that silently degrades to "chart not available".
                from .report_loader import build_durations_map, _chart_module_timing
                cb = _chart_module_timing(build_durations_map(
                    self._all_module_results, self._all_evidence_results,
                ))
            else:
                cb = None

            if cb is not None:
                return self._render_block(cb)
            # No chart available — render a short placeholder note
            return [Paragraph(
                f"<i>[Chart not available: {chart_key or 'unknown'}]</i>",
                self._styles["Normal"],
            )]

        # ---- image from base64 (chart) -------------------------------------
        if bt in ("chart_image", "image_bytes"):
            return self._render_image_from_b64(d)

        # ---- hash display --------------------------------------------------
        if bt == "hash_block":
            label = d.get("label", "Hash")
            value = d.get("value", "")
            return [
                Paragraph(f"<b>{label}:</b>", S["HashLabel"]),
                Paragraph(f"<font name='Courier' size='7.5'>{value}</font>",
                          S["HashValue"]),
                Spacer(1, 2 * mm),
            ]

        # ---- severity badge ------------------------------------------------
        if bt == "status_badge":
            return [self._render_badge(d)]

        # ---- AI disclosure box ---------------------------------------------
        if bt == "ai_disclosure":
            return [self._render_ai_disclosure(d.get("text", ""))]

        # ---- signature block -----------------------------------------------
        if bt == "signature_block":
            return self._render_signature(d)

        # ---- cover page block types ----------------------------------------
        elif bt == "cover_org_header":
            org = d.get("org_name", "")
            addr = d.get("org_address", "")
            out = []
            if org:
                out.append(Paragraph(f"<b>{org}</b>", self._styles["CoverMeta"]))
            if addr:
                out.append(Paragraph(addr, self._styles["CoverMeta"]))
            out.append(Spacer(1, 6 * mm))
            return out

        elif bt == "teal_rule":
            return [HRFlowable(width="100%", thickness=2,
                               color=HexColor(_TEAL), spaceAfter=8, spaceBefore=4)]

        elif bt == "cover_title":
            return [
                Spacer(1, 8 * mm),
                Paragraph(d.get("title", ""), self._styles["CoverTitle"]),
                Spacer(1, 4 * mm),
            ]

        elif bt == "cover_subtitle":
            return [Paragraph(d.get("subtitle", ""), self._styles["CoverSubtitle"])]

        elif bt == "metadata_table":
            rows = d.get("rows", [])
            tdata = []
            for label, value in rows:
                tdata.append([
                    Paragraph(str(label), self._styles["TableHeader"]),
                    Paragraph(str(value), self._styles["TableCell"]),
                ])
            if not tdata:
                return []
            col_w = [160, _FRAME_W - 160]
            t = Table(tdata, colWidths=col_w)
            t.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (0, -1), HexColor(_NAVY)),
                ("TEXTCOLOR",     (0, 0), (0, -1), colors.white),
                ("BACKGROUND",    (1, 0), (1, -1), colors.white),
                ("ROWBACKGROUNDS",(1, 0), (1, -1),
                 [colors.white, HexColor(_TABLE_ROW_ALT)]),
                ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING",    (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("BOX",           (0, 0), (-1, -1), 0.5, HexColor("#BDC3C7")),
                ("LINEBELOW",     (0, 0), (-1, -2), 0.3, HexColor("#BDC3C7")),
            ]))
            return [Spacer(1, 6 * mm), t, Spacer(1, 6 * mm)]

        elif bt == "cover_meta_table":
            rows = d.get("rows", [])
            tdata = []
            for label, value in rows:
                tdata.append([
                    Paragraph(label, self._styles["TableHeader"]),
                    Paragraph(str(value), self._styles["TableCell"]),
                ])
            if not tdata:
                return []
            col_w = [140, _FRAME_W - 140]
            t = Table(tdata, colWidths=col_w)
            t.setStyle(TableStyle([
                ("BACKGROUND",  (0, 0), (0, -1), HexColor(_NAVY)),
                ("BACKGROUND",  (1, 0), (1, -1), colors.white),
                ("ROWBACKGROUNDS", (1, 0), (1, -1),
                 [colors.white, HexColor(_TABLE_ROW_ALT)]),
                ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING",  (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("BOX",         (0, 0), (-1, -1), 0.5, HexColor("#BDC3C7")),
                ("LINEBELOW",   (0, 0), (-1, -2), 0.3, HexColor("#BDC3C7")),
            ]))
            return [Spacer(1, 6 * mm), t, Spacer(1, 6 * mm)]

        elif bt == "cover_confidential":
            return [Paragraph(d.get("text", ""), self._styles["CoverConfidential"])]

        elif bt == "cover_copyright":
            txt = d.get("text", "")
            tdata = [[
                "",   # teal bar column
                Paragraph(txt, ParagraphStyle(
                    "CoverCopy",
                    parent=self._styles["Normal"],
                    fontSize=8, textColor=HexColor("#555555"),
                )),
            ]]
            t = Table(tdata, colWidths=[4, _FRAME_W - 4])
            t.setStyle(TableStyle([
                ("BACKGROUND",   (0, 0), (0, -1), HexColor(_TEAL)),
                ("VALIGN",       (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",  (1, 0), (1, -1), 8),
                ("TOPPADDING",   (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]))
            return [Spacer(1, 4 * mm), t]

        if bt == "image_path":
            path_str = d.get("path", "")
            caption  = d.get("caption", "")
            if not path_str:
                return []
            if not _PIL_AVAILABLE:
                _logger.warning("Pillow not installed — cannot embed image: %s", path_str)
                return [Paragraph(
                    f"[Image omitted — Pillow not installed: {path_str}]",
                    S["Caption"],
                )]
            img_path = Path(path_str)
            if not img_path.is_file():
                return [Paragraph(f"[Image not found: {path_str}]", S["Caption"])]
            try:
                with PILImage.open(img_path) as _pil:
                    _orig_w, _orig_h = _pil.size
                _scale = min(_IMG_MAX_W / _orig_w, _IMG_MAX_H / _orig_h) if _orig_w and _orig_h else 1.0
                _target_w = _orig_w * _scale
                _target_h = _orig_h * _scale
                flowables = [Image(str(img_path), width=_target_w, height=_target_h)]
                if caption:
                    flowables.append(Paragraph(
                        f"<i>{self._next_fig(caption)}</i>",
                        S["Caption"],
                    ))
                return flowables
            except Exception as exc:
                _logger.warning("Could not embed image %s: %s", img_path, exc)
                return []

        if bt == "finding_box":
            severity = d.get("severity", "low").lower()
            title    = _html.escape(d.get("title", "Finding"))
            body     = _html.escape(d.get("body", ""))
            ref_id   = _html.escape(d.get("ref_id", ""))
            if severity in ("critical", "high"):
                style = S["CriticalBox"]
            elif severity == "medium":
                style = S["MediumBox"]
            else:
                style = S["Normal"]
            label = f"[{severity.upper()}] {ref_id}  {title}" if ref_id else f"[{severity.upper()}] {title}"
            return [
                Paragraph(f"<b>{label}</b><br/>{body}", style),
                Spacer(1, 2 * mm),
            ]

        if bt == "code_block":
            text = d.get("text", "")
            caption = d.get("caption", "")
            out: list[Any] = [Paragraph(
                _html.escape(text).replace("\n", "<br/>"),
                S["Code"],
            )]
            if caption:
                out.append(Paragraph(
                    f"<i>{self._next_fig(caption)}</i>",
                    S["Caption"],
                ))
            return out

        if bt in ("toc", "real_toc"):
            if not _TOC_AVAILABLE:
                return [Paragraph("Table of Contents — ReportLab TOC not available", S["Normal"])]
            toc = _TOC()
            toc.levelStyles = [
                ParagraphStyle(
                    "TOCHeading1", fontName="Helvetica-Bold", fontSize=10,
                    leading=14, textColor=HexColor(_NAVY), spaceAfter=2,
                ),
                ParagraphStyle(
                    "TOCHeading2", fontName="Helvetica", fontSize=9,
                    leading=13, textColor=HexColor("#333333"),
                    leftIndent=16, spaceAfter=1,
                ),
            ]
            return [toc]

        # ---- unknown — render as visible placeholder -----------------------
        preview = json.dumps(d, default=str)[:120]
        return [Paragraph(f"<i>[{bt}]</i> {preview}", S["Normal"])]

    def _render_table(
        self, headers: list[str], rows: list[list[str]]
    ) -> list[Any]:
        """Render a page-safe table without losing long forensic notes.

        ReportLab can split a table between rows but cannot split a single row
        taller than the body frame.  Each logical row is therefore divided into
        continuation rows at word boundaries.  This prevents LayoutError while
        preserving every character of the source data.
        """
        import html as _html

        S = self._styles
        col_count = max(len(headers), 1)
        names = [str(v or "").strip().lower() for v in headers]
        if names == ["module", "artefact class", "locus", "verdict", "count", "notes"]:
            weights = [0.16, 0.19, 0.11, 0.14, 0.07, 0.33]
        elif col_count == 6:
            weights = [0.16, 0.18, 0.13, 0.15, 0.09, 0.29]
        elif col_count == 5:
            weights = [0.18, 0.21, 0.16, 0.14, 0.31]
        elif col_count == 4:
            weights = [0.22, 0.24, 0.18, 0.36]
        else:
            weights = [1.0 / col_count] * col_count
        total = sum(weights)
        col_widths = [_FRAME_W * (w / total) for w in weights]
        compact = col_count >= 5
        header_style = ParagraphStyle(
            "AFSafeTableHeader", parent=S["TableHeader"],
            fontSize=7.0 if compact else 7.5,
            leading=8.2 if compact else 9.0,
            wordWrap="CJK", splitLongWords=True,
        )
        cell_style = ParagraphStyle(
            "AFSafeTableCell", parent=S["TableCell"],
            fontSize=6.8 if compact else 7.3,
            leading=8.1 if compact else 8.8,
            wordWrap="CJK", splitLongWords=True,
        )

        def split_value(value: Any, limit: int = 320) -> list[str]:
            remaining = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
            if not remaining:
                return [""]
            chunks: list[str] = []
            while len(remaining) > limit:
                area = remaining[: limit + 1]
                cut = max(
                    area.rfind("\n"), area.rfind("; "), area.rfind(". "),
                    area.rfind(", "), area.rfind(": "), area.rfind(" "),
                )
                cut = limit if cut < limit // 2 else cut + 1
                chunks.append(remaining[:cut].strip())
                remaining = remaining[cut:].lstrip()
            chunks.append(remaining)
            return chunks

        def para(value: Any, style: ParagraphStyle) -> Paragraph:
            safe = _html.escape(str(value or ""), quote=False).replace("\n", "<br/>")
            return Paragraph(safe, style)

        data: list[list[Paragraph]] = [[para(h, header_style) for h in headers]]
        for original in rows:
            row = (list(original) + [""] * col_count)[:col_count]
            parts = [split_value(v) for v in row]
            count = max((len(v) for v in parts), default=1)
            for idx in range(count):
                data.append([para(v[idx] if idx < len(v) else "", cell_style) for v in parts])

        table = Table(
            data, colWidths=col_widths, repeatRows=1,
            splitByRow=1, hAlign="LEFT",
        )
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), HexColor(_TABLE_HEADER_BG)),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, HexColor(_TABLE_ROW_ALT)]),
            ("GRID", (0, 0), (-1, -1), 0.35, HexColor("#CCCCCC")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 3),
            ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ("TOPPADDING", (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        return [table, Spacer(1, 3 * mm)]

    def _render_kv(self, pairs: list[tuple[str, str]]) -> list[Any]:
        """
        Render a two-column label / value table.

        The label column is fixed at 6 cm; the value column fills the
        remaining frame width.
        """
        S = self._styles
        label_w = 6.0 * cm
        value_w = _FRAME_W - label_w

        def safe(text: str) -> str:
            return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        data = [
            [
                Paragraph(f"<b>{safe(k)}</b>", S["Normal"]),
                Paragraph(safe(str(v)), S["Normal"]),
            ]
            for k, v in pairs
        ]
        if not data:
            return []

        t = Table(data, colWidths=[label_w, value_w])
        t.setStyle(TableStyle([
            ("ROWBACKGROUNDS", (0, 0), (-1, -1),
             [HexColor("#F8F9FA"), colors.white]),
            ("GRID",          (0, 0), (-1, -1), 0.25, HexColor("#E0E0E0")),
            ("VALIGN",        (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING",   (0, 0), (-1, -1), 4),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
            ("TOPPADDING",    (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        return [t, Spacer(1, 2 * mm)]

    def _render_badge(self, data: dict[str, str]) -> Any:
        """Render a small coloured severity badge as a single-cell Table."""
        sev   = data.get("severity", "Low")
        label = data.get("label", sev)
        bg    = HexColor(_SEV_BG.get(sev, "#888888"))
        fg    = HexColor(_SEV_FG.get(sev, "#FFFFFF"))
        style = ParagraphStyle(
            f"badge_{sev}",
            fontName="Helvetica-Bold", fontSize=8,
            textColor=fg, alignment=TA_CENTER,
        )
        t = Table([[Paragraph(label, style)]], colWidths=[3.5 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (0, 0), bg),
            ("LEFTPADDING",   (0, 0), (0, 0), 6),
            ("RIGHTPADDING",  (0, 0), (0, 0), 6),
            ("TOPPADDING",    (0, 0), (0, 0), 3),
            ("BOTTOMPADDING", (0, 0), (0, 0), 3),
            ("BOX",           (0, 0), (0, 0), 0.5, bg),
        ]))
        return t

    def _render_ai_disclosure(self, text: str) -> Any:
        """Render the AI disclosure banner inside a yellow-tinted box."""
        S   = self._styles
        raw = str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        p   = Paragraph(raw, S["AIDisclosure"])
        t   = Table([[p]], colWidths=[_FRAME_W])
        t.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (0, 0), HexColor("#FFF9C4")),
            ("BOX",           (0, 0), (0, 0), 1.0, HexColor("#F9A825")),
            ("LEFTPADDING",   (0, 0), (0, 0), 8),
            ("RIGHTPADDING",  (0, 0), (0, 0), 8),
            ("TOPPADDING",    (0, 0), (0, 0), 6),
            ("BOTTOMPADDING", (0, 0), (0, 0), 6),
        ]))
        return t

    def _render_signature(self, data: dict[str, str]) -> list[Any]:
        """Render an examiner signature block with underline placeholders."""
        S    = self._styles
        name = data.get("name",  "")
        title= data.get("title", "")
        dt   = data.get("date",  "")
        rows = [
            ["Examiner Name:", name],
            ["Title:",         title],
            ["Date:",          dt],
            ["Signature:", ""],
        ]
        table_data = [
            [
                Paragraph(f"<b>{r[0]}</b>", S["Normal"]),
                Paragraph(str(r[1]), S["Normal"]),
            ]
            for r in rows
        ]
        t = Table(table_data, colWidths=[5 * cm, _FRAME_W - 5 * cm])
        t.setStyle(TableStyle([
            ("BOX",           (0, 0), (-1, -1), 0.5, HexColor("#AAAAAA")),
            ("GRID",          (0, 0), (-1, -1), 0.25, HexColor("#DDDDDD")),
            ("TOPPADDING",    (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING",   (0, 0), (-1, -1), 6),
            # Signature row: larger height so there is room to sign
            ("MINROWHEIGHT", (0, 3), (-1, 3), 1.5 * cm),
        ]))
        return [t, Spacer(1, 4 * mm)]

    def _render_image_from_path(self, data: dict[str, Any]) -> list[Any]:
        """
        Embed an image referenced by file path.

        Renders a caption (file description) and SHA-256 hash beneath the
        image if provided.  Returns an empty list if the file does not exist
        or PIL is unavailable.
        """
        path_str = data.get("path", "")
        if not path_str or not _PIL_AVAILABLE:
            return []

        img_path = Path(path_str)
        if not img_path.is_file():
            _logger.warning("Image not found: %s", img_path)
            return []

        try:
            with PILImage.open(img_path) as _pil:
                _orig_w, _orig_h = _pil.size
            _scale = min(_IMG_MAX_W / _orig_w, _IMG_MAX_H / _orig_h) if _orig_w and _orig_h else 1.0
            _target_w = _orig_w * _scale
            _target_h = _orig_h * _scale
            flowables: list[Any] = [
                Image(str(img_path), width=_target_w, height=_target_h),
            ]
            if data.get("caption"):
                flowables.append(
                    Paragraph(str(data["caption"]), self._styles["Caption"])
                )
            if data.get("sha256"):
                flowables.extend(self._render_block(ContentBlock(
                    block_type="hash_block",
                    data={"label": "SHA-256", "value": data["sha256"]},
                )))
            return flowables
        except Exception as exc:
            _logger.warning("Could not embed image %s: %s", img_path, exc)
            return []

    def _render_image_from_b64(self, data: dict[str, Any]) -> list[Any]:
        """
        Decode a base64-encoded PNG/JPEG and embed it as an Image flowable.

        Writes bytes to a named temp file (not BytesIO) so ReportLab can read
        them reliably during doc.build().  The temp file is tracked in
        self._tmp_chart_files and deleted after build() completes.
        """
        b64 = data.get("data_b64", "")
        if not b64:
            return []

        try:
            import tempfile as _tf_mod
            raw_bytes = base64.b64decode(b64)
            tf = _tf_mod.NamedTemporaryFile(suffix=".png", delete=False)
            tmp_path = tf.name
            tf.write(raw_bytes)
            tf.close()
            self._tmp_chart_files.append(tmp_path)

            if _PIL_AVAILABLE:
                with PILImage.open(io.BytesIO(raw_bytes)) as _pil:
                    _orig_w, _orig_h = _pil.size
                _scale = min(_IMG_MAX_W / _orig_w, _IMG_MAX_H / _orig_h) if _orig_w and _orig_h else 1.0
                _target_w = _orig_w * _scale
                _target_h = _orig_h * _scale
            else:
                _target_w = _IMG_MAX_W
                _target_h = _target_w   # cannot compute aspect ratio without PIL — leave as square
            img = Image(tmp_path, width=_target_w, height=_target_h)
            img.hAlign = "CENTER"
            flowables: list[Any] = [img]
            if data.get("label"):
                flowables.append(
                    Paragraph(str(data["label"]), self._styles["Caption"])
                )
            return flowables
        except Exception as exc:
            _logger.warning("Could not render chart image: %s", exc)
            return []

    def _render_section(self, section: SectionContent) -> list[Any]:
        """
        Convert a SectionContent to an ordered list of ReportLab Flowables.

        Adds a PageBreak before every heading-1 section (except section 1,
        the cover page, which is assumed to be the first thing in the story).
        """
        flowables: list[Any] = []
        if section.section_number > 1:
            flowables.append(PageBreak())
        for block in section.blocks:
            flowables.extend(self._render_block(block))
        return flowables

    # -----------------------------------------------------------------------
    # PDF writing
    # -----------------------------------------------------------------------

    def _write_pdf(self, sections: list[SectionContent]) -> Path:
        """
        Render all sections to a PDF file and return its path.

        If ReportLab is not installed, writes a plain-text fallback file
        instead and logs a warning.
        """
        pdf_path = self._output_dir / f"{self._safe_case_id}_report.pdf"

        if not _REPORTLAB_AVAILABLE:
            _logger.warning(
                "ReportLab not installed — writing plain-text fallback instead of PDF."
            )
            txt_path = pdf_path.with_suffix(".txt")
            with open(txt_path, "w", encoding="utf-8") as fh:
                for sec in sections:
                    fh.write(f"\n{'='*72}\n{sec.section_number}. {sec.section_title}\n")
                    for blk in sec.blocks:
                        fh.write(f"[{blk.block_type}] {json.dumps(blk.data)[:200]}\n")
            return txt_path

        # Build the story (list of Flowables)
        story: list[Any] = []
        for section in sections:
            story.extend(self._render_section(section))

        # Frame occupies the body area, leaving room for header/footer
        frame = Frame(
            x1=_MARGIN,
            y1=_MARGIN + _FOOTER_H,
            width=_FRAME_W,
            height=_FRAME_H,
            id="body",
            leftPadding=0, rightPadding=0,
            topPadding=0,  bottomPadding=0,
        )
        # PageTemplate with no onPage callback — decorations are applied by
        # the custom canvas class during save()
        page_tpl = PageTemplate(id="AutoForensics", frames=[frame])
        gen_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        canvas_factory = functools.partial(
            _AutoForensicsCanvas,
            page_info={
                "case_id":        self._case_id,
                "case_number":    self._metadata.case_number,
                "org_name":       self._metadata.examiner_organisation,
                "classification": self._classification,
                "timestamp":      gen_ts,
                "version":        _VERSION,
            },
            extra_pages=0,
        )

        # Safety sweep: drop any Image with invalid/unknown dimensions before
        # handing the story to ReportLab — drawHeight=None or 0 causes a
        # LayoutError ("??? too large") that aborts the entire build.
        _safe_story: list[Any] = []
        for _fl in story:
            if isinstance(_fl, Image):
                _dw = getattr(_fl, "drawWidth", None)
                _dh = getattr(_fl, "drawHeight", None)
                if not _dw or _dw <= 0 or not _dh or _dh <= 0 or _dh > 650:
                    _logger.warning(
                        "Dropping Image with invalid dimensions "
                        "(drawWidth=%s drawHeight=%s) — PDF build will continue",
                        _dw, _dh,
                    )
                    continue
            _safe_story.append(_fl)
        story = _safe_story

        toc_flowable: Any = None
        if _TOC_AVAILABLE:
            for fl in story:
                if isinstance(fl, _TOC):
                    toc_flowable = fl
                    break

        doc = _ForensicDocTemplate(
            str(pdf_path),
            pagesize=A4,
            leftMargin=_MARGIN, rightMargin=_MARGIN,
            topMargin=_MARGIN,  bottomMargin=_MARGIN,
            toc_ref=toc_flowable,
        )
        doc.addPageTemplates([page_tpl])

        doc.multiBuild(story, canvasmaker=canvas_factory)
        _logger.info("PDF content written: %s", pdf_path)
        return pdf_path

    # -----------------------------------------------------------------------
    # Seal page
    # -----------------------------------------------------------------------

    def _write_seal_page(
        self, path: Path, content_hash: str, gen_ts: str
    ) -> None:
        """
        Render a single-page seal PDF containing the content hash,
        generation timestamp, and investigator identity.

        The hash covers the PDF file at the time of sealing (the content PDF
        before this page was appended). A different hash indicates that those
        bytes are no longer identical. The seal does not certify forensic
        accuracy, completeness, physical custody, or examiner approval.
        """
        S = self._styles

        story: list[Any] = [
            Spacer(1, 3 * cm),
            Paragraph("DOCUMENT INTEGRITY SEAL", S["SealHeading"]),
            HRFlowable(
                width="60%", thickness=2,
                color=HexColor("#2C3E50"), spaceAfter=20,
            ),
            Paragraph(
                "This page records the SHA-256 value of the report content "
                "before the seal page was appended. A later mismatch indicates "
                "that the pre-seal bytes are not identical to those originally "
                "hashed. This file-integrity record does not certify forensic "
                "accuracy, examination completeness, physical chain of custody, "
                "or examiner approval.",
                S["SealBody"],
            ),
            Spacer(1, 1.5 * cm),
            Paragraph(
                "SHA-256 of report content (pre-seal):",
                ParagraphStyle(
                    "SealLabel",
                    fontName="Helvetica-Bold", fontSize=10,
                    alignment=TA_CENTER, textColor=HexColor("#1A252F"),
                ),
            ),
            Spacer(1, 4 * mm),
            Paragraph(
                f"<font name='Courier' size='9'>{content_hash}</font>",
                ParagraphStyle(
                    "SealHash",
                    fontName="Courier", fontSize=9,
                    alignment=TA_CENTER, textColor=HexColor("#2C3E50"),
                    backColor=HexColor("#F4F4F4"),
                    borderPad=6,
                ),
            ),
            Spacer(1, 1.5 * cm),
            Paragraph(
                f"Generated: {gen_ts}",
                S["SealBody"],
            ),
            Paragraph(
                f"Examiner: {self._investigator.name}",
                S["SealBody"],
            ),
            Paragraph(
                f"Case: {self._case_id}",
                S["SealBody"],
            ),
            Paragraph(
                "AutoForensics",
                S["SealBody"],
            ),
            Spacer(1, 2 * cm),
            HRFlowable(
                width="60%", thickness=1,
                color=HexColor("#AAAAAA"), spaceBefore=10,
            ),
            Paragraph(
                "To verify: compute SHA-256 of the report file excluding this "
                "seal page and compare to the hash above.",
                ParagraphStyle(
                    "SealNote",
                    fontName="Helvetica-Oblique", fontSize=8,
                    alignment=TA_CENTER, textColor=HexColor("#666666"),
                    spaceBefore=8,
                ),
            ),
        ]

        frame = Frame(
            x1=_MARGIN, y1=_MARGIN, width=_FRAME_W,
            height=_PAGE_H - 2 * _MARGIN, id="seal",
        )
        tpl = PageTemplate(id="Seal", frames=[frame])
        doc = BaseDocTemplate(
            str(path), pagesize=A4,
            leftMargin=_MARGIN, rightMargin=_MARGIN,
            topMargin=_MARGIN,  bottomMargin=_MARGIN,
        )
        doc.addPageTemplates([tpl])

        gen_ts_canvas = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        canvas_factory = functools.partial(
            _AutoForensicsCanvas,
            page_info={
                "case_id":        self._case_id,
                "case_number":    self._metadata.case_number,
                "org_name":       self._metadata.examiner_organisation,
                "classification": self._classification,
                "timestamp":      gen_ts_canvas,
                "version":        _VERSION,
            },
        )
        doc.build(story, canvasmaker=canvas_factory)

        # Clean up temp chart image files written by _render_image_from_b64
        for _p in self._tmp_chart_files:
            try:
                os.unlink(_p)
            except OSError:
                pass
        self._tmp_chart_files.clear()

    def _append_seal_page(self, content_pdf: Path, content_hash: str) -> Path:
        """
        Generate a seal page PDF, merge it after the content PDF, and return
        the path to the sealed output file.

        If pypdf is not installed, copies the content PDF unchanged and
        writes a companion .seal.json file containing the hash.
        """
        gen_ts    = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        seal_tmp  = self._output_dir / f"{self._safe_case_id}_seal_page_tmp.pdf"
        final_pdf = self._output_dir / f"{self._safe_case_id}_report.pdf"

        if _REPORTLAB_AVAILABLE:
            self._write_seal_page(seal_tmp, content_hash, gen_ts)

        if _PYPDF_AVAILABLE and _REPORTLAB_AVAILABLE and seal_tmp.is_file():
            writer = PdfWriter()
            for page in PdfReader(str(content_pdf)).pages:
                writer.add_page(page)
            for page in PdfReader(str(seal_tmp)).pages:
                writer.add_page(page)
            with open(final_pdf, "wb") as fh:
                writer.write(fh)
            seal_tmp.unlink(missing_ok=True)
            _logger.info("Seal page appended: %s", final_pdf)
        else:
            # Fallback: copy content PDF and write seal companion
            if content_pdf != final_pdf:
                shutil.copy2(content_pdf, final_pdf)
            seal_json = self._output_dir / f"{self._safe_case_id}_seal.json"
            seal_json.write_text(
                json.dumps(
                    {
                        "content_sha256":        content_hash,
                        "sealed_at":             gen_ts,
                        "examiner":              self._investigator.name,
                        "case_id":               self._case_id,
                        "generator_version":     _VERSION,
                        "note": (
                            "Seal page not appended to PDF because pypdf is not "
                            "installed.  Verify the hash in this file against "
                            f"{final_pdf.name} manually."
                        ),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            _logger.warning(
                "pypdf not installed — seal written to %s instead of PDF page.",
                seal_json,
            )

        return final_pdf

    # -----------------------------------------------------------------------
    # JSON output
    # -----------------------------------------------------------------------

    def _section_to_dict(self, section: SectionContent) -> dict[str, Any]:
        """Convert a SectionContent to a JSON-serialisable dict."""
        return {
            "section_number": section.section_number,
            "section_title":  section.section_title,
            "blocks": [
                {
                    "type": blk.block_type,
                    "data": self._sanitise_for_json(blk.data),
                }
                for blk in section.blocks
            ],
        }

    @staticmethod
    def _sanitise_for_json(obj: Any) -> Any:
        """Recursively convert non-JSON-serialisable types to safe equivalents."""
        if isinstance(obj, dict):
            return {k: ReportGenerator._sanitise_for_json(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [ReportGenerator._sanitise_for_json(i) for i in obj]
        if isinstance(obj, (str, int, float, bool)) or obj is None:
            return obj
        return str(obj)

    def _write_json(
        self, sections: list[SectionContent], content_hash: str
    ) -> Path:
        """
        Write a structured JSON mirror of all 42 sections.

        The JSON includes a metadata envelope (generation timestamp, hash,
        version) followed by the serialised section list.
        """
        json_path = self._output_dir / f"{self._safe_case_id}_report.json"
        output    = {
            "report_metadata": {
                "case_id":           self._case_id,
                "examiner":          self._investigator.name,
                "generated_at":      datetime.now(timezone.utc).isoformat(),
                "generator_version": _VERSION,
                "total_sections":    len(sections),
                "content_sha256":    content_hash,
                "classification":    self._classification,
                "quality_warnings":  list(self._quality_warnings),
                "narrative_assurance": self._sanitise_for_json(
                    getattr(self, "_narrative_assurance", {})
                ),
                "api_calls": [
                    {
                        "purpose":       r.purpose,
                        "model":         r.model,
                        "input_tokens":  r.input_tokens if r.input_tokens is not None else "not_recorded",
                        "output_tokens": r.output_tokens if r.output_tokens is not None else "not_recorded",
                        "success":       r.success,
                        "duration_ms":   r.duration_ms if r.duration_ms is not None else "not_recorded",
                    }
                    for r in self._api_log
                ],
            },
            "sections": [self._section_to_dict(s) for s in sections],
        }
        json_path.write_text(
            json.dumps(output, indent=2, default=str, ensure_ascii=False),
            encoding="utf-8",
        )
        _logger.info("JSON output written: %s", json_path)
        return json_path

    # -----------------------------------------------------------------------
    # Utility helpers
    # -----------------------------------------------------------------------

    @staticmethod
    def _compute_file_hash(path: Path) -> str:
        """
        Compute and return the SHA-256 hex digest of the file at path.

        Reads in 1 MiB chunks to avoid loading large files into memory.
        """
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1_048_576), b""):
                h.update(chunk)
        return h.hexdigest()

    @staticmethod
    def _count_pages(pdf_path: Path) -> int:
        """Return a bounded, best-effort PDF page count.

        Page traversal is isolated in a short-lived subprocess. A malformed or
        unusually complex page tree can therefore never stall the investigation
        after the PDF has already been written.
        """
        if _PYPDF_AVAILABLE:
            try:
                import subprocess as _subprocess, sys as _sys
                code = (
                    "from pypdf import PdfReader; import sys; "
                    "print(len(PdfReader(sys.argv[1]).pages))"
                )
                completed = _subprocess.run(
                    [_sys.executable, "-c", code, str(pdf_path)],
                    capture_output=True, text=True, timeout=45, check=False,
                )
                if completed.returncode == 0:
                    return max(1, int((completed.stdout or "0").strip()))
                _logger.warning("pypdf page-count subprocess failed: %s", (completed.stderr or "").strip())
            except Exception as exc:
                _logger.warning("bounded pypdf page count failed: %s", exc)
        try:
            data = pdf_path.read_bytes()
            count = data.count(b"/Type /Page") + data.count(b"/Type/Page")
            return max(count, 1)
        except Exception:
            return 0


# ===========================================================================
# 7-section report builders (module-level functions)
# ===========================================================================

def _build_section_introduction(case_info: "CaseInfo", metadata: "ReportMetadata",
                                investigators: list, case_config: Any = None) -> "SectionContent":
    blocks = []
    blocks.append(_h1("Section 1 — Introduction"))
    blocks.append(_spacer())
    blocks.append(_h2("1.1 Case Information"))
    blocks.append(_kv([
        ("Case Number",         case_info.case_number),
        ("Case Title",          case_info.case_title),
        ("Case Type",           getattr(case_info, "case_type", None) or "N/A"),
        ("Jurisdiction",        getattr(case_info, "jurisdiction", None) or "N/A"),
        ("Client",              getattr(case_info, "client_name", "") or "N/A"),
        ("Client Organisation", getattr(case_info, "client_organisation", "") or "N/A"),
        ("Date Received",       _format_date(getattr(case_info, "date_received", None)) if getattr(case_info, "date_received", None) else "Not supplied"),
        ("Date Commenced",      _format_date(getattr(case_info, "date_commenced", None)) if getattr(case_info, "date_commenced", None) else "Not recorded"),
        # Completion date defaults to the report-generation date — the run's own
        # completion timestamp — rather than showing "N/A".
        ("Date Completed",      _format_date(
            getattr(case_info, "date_completed", None)
            or getattr(metadata, "report_date", None))),
    ]))
    blocks.append(_spacer())
    blocks.append(_h2("1.2 Examining Personnel"))
    for inv in investigators:
        blocks.append(_h3(f"{inv.name} — {inv.role_in_case}"))
        blocks.append(_kv([
            ("Title",          inv.title),
            ("Organisation",   inv.organisation or "N/A"),
            ("Certifications", ", ".join(inv.certifications) if getattr(inv, "certifications", None) else "N/A"),
            ("Contact Email",  getattr(inv, "contact_email", None) or "N/A"),
        ]))
        blocks.append(_spacer(4))
    blocks.append(_spacer())
    blocks.append(_h2("1.3 Investigation Background and Objectives"))
    if case_config:
        bg = getattr(case_config, "investigation_background", "") or ""
        if bg:
            blocks.append(_para(bg))
        offences = getattr(case_config, "offence_types", []) or []
        if offences:
            blocks.append(_h3("Applicable Legislation"))
            blocks.append(_bullets(offences))
        objectives = getattr(case_config, "objectives", []) or []
        if objectives:
            blocks.append(_h3("Investigation Objectives"))
            blocks.append(_numbered(objectives))
    else:
        blocks.append(_para("Investigation background not available — see case_config.json."))
    return SectionContent(section_number=1, section_title="Introduction", blocks=blocks)


def _build_section_methodology(tools: list, os_environment: Any) -> "SectionContent":
    blocks = []
    blocks.append(_h1("Section 2 — Methodology"))
    blocks.append(_spacer())
    blocks.append(_h2("2.1 Governing Standards"))
    blocks.append(_bullets([
        "NIST SP 800-86: Guide to Integrating Forensic Techniques into Incident Response",
        "ACPO Good Practice Guide for Digital Evidence v5 (2012)",
        "ISO/IEC 27037:2012 — Guidelines for identification, collection, acquisition, and preservation of digital evidence",
        "ISO/IEC 27042:2015 — Guidelines for the analysis and interpretation of digital evidence",
    ]))
    blocks.append(_spacer())
    blocks.append(_h2("2.2 ACPO Principles"))
    blocks.append(_numbered([
        "No action shall change data held on a digital device or storage medium which may subsequently be relied upon in court.",
        "A person accessing original data must be competent to do so and able to give evidence explaining the relevance and implications of their actions.",
        "An audit trail of all processes applied to digital evidence must be created and preserved so an independent third party can examine and achieve the same result.",
        "The person in charge of the investigation has overall responsibility for ensuring that the law and these principles are adhered to.",
    ]))
    blocks.append(_spacer())
    blocks.append(_h2("2.3 Examination Steps"))
    blocks.append(_numbered([
        "Register the supplied evidence image and its declared provenance.",
        "Reconstruct the logical media stream and compute MD5, SHA-1 and SHA-256.",
        "Compare only algorithms for which an embedded/reference digest is present; independently self-check the top-line SHA-256.",
        "Detect partitioning/filesystem structure natively and expose evidence-derived files without a writable mount.",
        "Execute each configured module and record one of: ran/found X, ran/found nothing, did not run, or ran with caveat.",
        "Preserve module output, artefact paths, hashes, errors and known limitations.",
        "Generate a draft report for examiner verification; no manual review, physical handling, signature or custody event is inferred unless recorded.",
    ]))
    blocks.append(_spacer())
    blocks.append(_h2("2.4 Tools and Software"))
    if tools:
        headers = ["Tool", "Version", "Purpose", "Runtime Note"]
        rows = [[t.name, t.version, t.purpose, t.validation_reference or "Detected"] for t in tools]
        blocks.append(_table(headers, rows))
        from .report_loader import _render_tools_table_image
        tools_img = _render_tools_table_image(tools)
        if tools_img:
            blocks.append(tools_img)
    else:
        blocks.append(_para(
            "No runtime tool inventory was available. Consult the per-module "
            "execution table and logs before stating that any optional tool ran."
        ))
    return SectionContent(section_number=2, section_title="Methodology", blocks=blocks)


def _build_section_isolation(evidence_acquisitions: list, hash_image: "ContentBlock | None" = None) -> "SectionContent":
    blocks = []
    blocks.append(_h1("Section 3 — Isolation and Preservation"))
    blocks.append(_spacer())
    blocks.append(_para(
        "All digital evidence was acquired using forensically sound write-blocking "
        "techniques. Cryptographic hash values confirm that examined images are "
        "identical to those originally acquired. No modifications were made to "
        "original media at any stage of the examination."
    ))
    blocks.append(_spacer())
    blocks.append(_h2("3.1 Evidence Properties"))
    if evidence_acquisitions:
        headers = ["Exhibit", "Description", "Acquisition Method", "Tool", "MD5", "SHA-256", "Verified"]
        rows = [[
            e.exhibit_ref, e.description, e.acquisition_method,
            f"{e.tool_used} v{e.tool_version}",
            (e.md5_hash[:16] + "…") if e.md5_hash else "N/A",
            (e.sha256_hash[:16] + "…") if e.sha256_hash else "N/A",
            "YES" if e.verified else "NO",
        ] for e in evidence_acquisitions]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())
        for e in evidence_acquisitions:
            blocks.append(_h3(f"Exhibit {e.exhibit_ref} — {e.description}"))
            blocks.append(_kv([
                ("Source Size", _bytes_to_human(e.source_size_bytes) if e.source_size_bytes else "N/A"),
                ("Image Size",  _bytes_to_human(e.image_size_bytes) if e.image_size_bytes else "N/A"),
                ("Acquired By", e.acquired_by or "N/A"),
                ("Date",        _format_date(e.acquisition_date)),
            ]))
            if e.md5_hash:
                blocks.append(ContentBlock(block_type="hash_block", data={"label": "MD5",     "value": e.md5_hash}))
            if e.sha256_hash:
                blocks.append(ContentBlock(block_type="hash_block", data={"label": "SHA-256", "value": e.sha256_hash}))
            if e.notes:
                blocks.append(_para(e.notes))
            blocks.append(_spacer(4))
    else:
        blocks.append(_para("No evidence acquisition records were registered for this case."))
    if hash_image is not None:
        blocks.append(_spacer())
        blocks.append(_h2("3.2 Hash Verification Record"))
        blocks.append(hash_image)
    return SectionContent(section_number=3, section_title="Isolation and Preservation", blocks=blocks)


def _results_for_exhibit(
    all_module_results: list, exhibit: str, *, include_empty: bool = False
) -> list:
    """Return per-module views for ``exhibit`` without hiding zero-output runs.

    ``include_empty`` is used for a single-evidence case, where every module's
    execution outcome unambiguously belongs to the only exhibit.  This is the
    report-honesty invariant: ran-and-found-nothing, did-not-run, and caveated
    runs must remain visible instead of being filtered out with empty findings.
    """
    import dataclasses as _dc
    out = []
    for r in all_module_results:
        sel = [f for f in r.findings
               if _reference_exhibit_id(getattr(f, "evidence_reference", "")) == exhibit]
        if sel or include_empty:
            out.append(_dc.replace(r, findings=sel))
    return out


def _display_module_name(name: str) -> str:
    """Convert a runtime module id into a professional report label."""
    overrides = {
        "ewf_metadata": "EWF Metadata and Container Analysis",
        "evidence_validator": "Evidence Integrity Validator",
        "image_mounter": "Native Evidence Access",
        "filesystem_analyzer": "Filesystem Identification",
        "timeline_builder": "Forensic Timeline Builder",
        "deleted_file_recovery": "Deleted File Recovery",
        "native_signature_carver": "Native Signature Carving",
        "file_signature_analyzer": "File Signature Analysis",
        "native_malware_scanner": "Native Malware/Test-Signature Scan",
        "suspicious_file_detector": "Suspicious File Analysis",
        "criminal_network_mapper": "Identifier Correlation Analysis",
        "anti_forensic_detector": "Anti-Forensic Indicator Analysis",
    }
    raw = str(name or "")
    return overrides.get(raw, raw.replace("_", " ").strip().title())


def _build_section_analysis(
    all_module_results: list,
    evidence_acquisitions: list,
    section_number: int = 4,
    section_title: str = "Analysis",
) -> "SectionContent":
    from .report_loader import (
        _render_file_system_tree_image,
        _render_user_accounts_image,
        _render_deleted_files_image,
        _render_registry_hives_image,
        _render_keyword_hits_image,
        _render_suspicious_files_image,
        _render_carved_files_image,
        _render_string_analysis_image,
        _render_anti_forensic_image,
        _render_severity_bar_image,
        _render_network_ioc_image,
        _render_timeline_evidence_image,
    )

    _IMAGE_RENDERERS = [
        ("file",     _render_file_system_tree_image),
        ("disk",     _render_file_system_tree_image),
        ("user",     _render_user_accounts_image),
        ("account",  _render_user_accounts_image),
        ("deleted",  _render_deleted_files_image),
        ("recovery", _render_deleted_files_image),
        ("registry", _render_registry_hives_image),
        ("keyword",  _render_keyword_hits_image),
        ("ioc",      _render_keyword_hits_image),
        ("malware",  _render_suspicious_files_image),
        ("carv",     _render_carved_files_image),
        ("string",   _render_string_analysis_image),
        ("anti",     _render_anti_forensic_image),
        ("network",  _render_network_ioc_image),
        # New modules
        ("browser",  _render_keyword_hits_image),
        ("email",    _render_deleted_files_image),
        ("criminal", _render_network_ioc_image),
        ("image content", _render_suspicious_files_image),
    ]

    blocks = []
    blocks.append(_h1(f"Section {section_number} — {section_title}"))
    blocks.append(_spacer())
    _with_findings = sum(1 for r in all_module_results if getattr(r, "findings", []))
    _did_not_run = sum(1 for r in all_module_results
                       if getattr(r, "execution_outcome", "") == "did_not_run")
    blocks.append(_para(
        f"This section records all {len(all_module_results)} configured module outcomes "
        f"for this evidence item: {_with_findings} produced findings and "
        f"{_did_not_run} did not run. A zero-finding outcome is reported explicitly and "
        "is not treated as proof that an artefact class is absent unless the module "
        "records a VERIFIED_ABSENT assurance verdict."
    ))
    blocks.append(_spacer())
    blocks.append(_h2(f"{section_number}.1 Module Execution Summary"))
    if all_module_results:
        headers = ["Module", "Execution Outcome", "Status", "Evidence Assurance", "Examined", "Findings / Reason"]
        rows = []
        for r in all_module_results:
            outcome = getattr(r, "execution_outcome", "") or (
                "ran_found_x" if r.findings else
                "did_not_run" if str(r.status).lower() in {"failed", "skipped", "indeterminate"}
                else "ran_with_caveat" if str(r.status).lower() in {"partial", "degraded"}
                else "ran_found_nothing"
            )
            reason = str(len(r.findings))
            if outcome in {"did_not_run", "ran_with_caveat"}:
                reason = (getattr(r, "summary", "") or r.error_message or reason)[:120]
            module_display = _display_module_name(r.module_name)
            result_stats = ((getattr(r, "raw_data", {}) or {}).get("statistics", {}) or {})
            completion = result_stats.get("completion_certificate", {}) or {}
            evidence_assurance = str(
                completion.get("evidence_assurance") or result_stats.get("evidence_assurance") or "INDETERMINATE"
            ).upper()
            count_units = completion.get("count_units") or result_stats.get("count_units") or {}
            examined_unit = count_units.get("supported_objects") or count_units.get("source_objects") or {}
            examined_display = str(r.artefacts_examined)
            if isinstance(examined_unit, dict) and examined_unit.get("unit"):
                examined_display = f"{examined_unit.get('processed', r.artefacts_examined)} {examined_unit.get('unit')} processed"
            if str(r.module_name).lower() in {"foremost_carver", "scalpel_carver", "foremost file carver", "scalpel file carver"}:
                examined_display = f"{r.artefacts_examined} RAW CARVING CANDIDATES — NOT VALIDATED RECOVERED FILES"
                if not r.findings:
                    reason = "0 accepted findings; raw carving candidates retained separately"
            rows.append([
                module_display, outcome.replace("_", " ").upper(), r.status.upper(),
                evidence_assurance, examined_display, reason,
            ])
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())
        # Render one technical subsection for every configured module, including
        # successful zero-finding and candidate-only outcomes.  Omitting those
        # sections previously made a 45-module run appear to contain fewer than
        # 46 technical examinations and concealed the distinction between a
        # verified negative, a candidate-only result and an untested capability.
        _detail_results = list(all_module_results)
        for idx, result in enumerate(_detail_results, 2):
            blocks.append(_h2(f"{section_number}.{idx} {_display_module_name(result.module_name)}"))
            blocks.append(_module_status_note(result))

            # Try to render a module-specific evidence image
            mod_lower = result.module_name.lower()
            img_block = None
            for keyword, renderer in _IMAGE_RENDERERS:
                if keyword in mod_lower:
                    img_block = renderer(result)
                    break
            if img_block is None:
                img_block = _render_severity_bar_image(result)
            if img_block is not None:
                blocks.append(img_block)
                blocks.append(_spacer(4))

            if result.raw_data:
                for key, val in result.raw_data.items():
                    if key.startswith("_chart_") and val is not None:
                        blocks.append(val)
                        blocks.append(_spacer(4))
                embedded = result.raw_data.get("_embedded_images")
                if embedded and isinstance(embedded, list):
                    for img_cb in embedded[:10]:
                        blocks.append(img_cb)
                        blocks.append(_spacer(4))

            if result.findings:
                headers2 = ["ID", "Severity", "Title", "Source"]
                rows2 = [
                    [
                        f.finding_id,
                        f.severity.value,
                        f.title[:70],
                        f"Source: {_display_module_name(result.module_name)} → {f.artefact_location[:40]}"
                        if f.artefact_location else _display_module_name(result.module_name),
                    ]
                    for f in result.findings
                ]
                blocks.append(_table(headers2, rows2))
                blocks.extend(_build_findings_subsection(
                    _display_module_name(result.module_name),
                    result.findings,
                ))
            else:
                blocks.extend(_build_findings_subsection(
                    _display_module_name(result.module_name),
                    [],
                ))

            # Emit terminal output as a figure if captured
            if result.terminal_output and result.terminal_output.strip():
                blocks.append(ContentBlock("code_block", {
                    "text": result.terminal_output.strip(),
                    "caption": f"Terminal output — {_display_module_name(result.module_name)}",
                }))

            blocks.append(_spacer())
    else:
        blocks.append(_para(
            "No module execution records were available for this evidence item. "
            "No inference about artefact absence can be made."
        ))
    return SectionContent(
        section_number=section_number, section_title=section_title, blocks=blocks,
    )


def _build_section_conclusions_5w1h(conclusions_text: str, key_findings: list,
                                    all_findings: list, case_info: "CaseInfo",
                                    all_module_results: Optional[list] = None,
                                    case_config: Any = None,
                                    section_number: int = 5,
                                    narrative: Optional[dict] = None) -> "SectionContent":
    """Build the executive interpretation section.

    The technical analysis remains exhaustive, while this section presents a
    grouped, plain-language account of material facts. It must never become a
    second dump of raw module findings or host-specific paths.
    """
    blocks = [_h1(f"Section {section_number} — Conclusions"), _spacer()]

    blocks.append(_h2(f"{section_number}.1 Investigation Summary (5W1H)"))
    if narrative and narrative.get("llm_used"):
        blocks.append(_para(
            "Narrative synthesis was produced only from the accepted structured finding ledger. "
            "It is explanatory text, introduces no new findings, and requires examiner review."
        ))
        blocks.append(_spacer())

    if narrative and narrative.get("five_w_one_h"):
        blocks.append(_para(str(narrative["five_w_one_h"])))
    else:
        if all_module_results is not None:
            all_f = [f for r in all_module_results for f in getattr(r, "findings", [])]
            if case_config:
                table_rows = _build_5w1h_table(case_config, all_f)
            else:
                w5h1 = _build_5w1h(all_module_results, case_config)
                table_rows = [[k, w5h1[k]] for k in ("WHO", "WHAT", "WHEN", "WHERE", "WHY", "HOW")]
        else:
            table_rows = [
                ["Who", _extract_who(key_findings)],
                ["What", _extract_what(key_findings)],
                ["When", _extract_when(key_findings)],
                ["Where", _extract_where(all_findings)],
                ["Why", _extract_why(key_findings, case_info)],
                ["How", _extract_how(key_findings)],
            ]
        blocks.append(_table(["Question", "Answer"], table_rows))

    blocks.append(_spacer())
    blocks.append(_h2(f"{section_number}.2 Key Findings"))
    if key_findings:
        headers = ["#", "Material Finding", "Severity", "Plain-Language Summary", "Evidence"]
        rows = []
        for i, kf in enumerate(key_findings, 1):
            refs = "; ".join(kf.supporting_evidence[:3]) if getattr(kf, "supporting_evidence", None) else ""
            rows.append([
                str(i),
                kf.title,
                kf.severity.value,
                _clean_material_text(kf.description, limit=430),
                refs,
            ])
        blocks.append(_table(headers, rows))
    else:
        blocks.append(_para("No grouped material findings were available for executive interpretation."))

    blocks.append(_spacer())
    blocks.append(_h2(f"{section_number}.3 Investigative Conclusions"))
    if conclusions_text:
        for paragraph in [p.strip() for p in str(conclusions_text).split("\n\n") if p.strip()]:
            blocks.append(_para(paragraph))
            blocks.append(_spacer(4))
    else:
        blocks.append(_para(
            "No evidence-bounded executive conclusion was generated. Refer to the "
            "grouped key findings and the complete technical analysis, and complete "
            "examiner review before relying on the report."
        ))

    pfs = narrative.get("per_finding_significance") if narrative else None
    if isinstance(pfs, dict):
        entries = [
            (str(ref), _clean_material_text(prose, limit=1000))
            for ref, prose in pfs.items()
            if ref != "__banner__" and str(prose).strip()
        ]
        if pfs.get("__banner__") or entries:
            blocks.append(_spacer())
            blocks.append(_h2(f"{section_number}.4 Material-Finding Significance"))
            blocks.append(_para(
                "The following interpretation groups corroborating detections into "
                "material evidential themes. Raw module findings and artefact-level "
                "details remain in Section 4."
            ))
            if pfs.get("__banner__"):
                blocks.append(_para(str(pfs["__banner__"])))
            if entries:
                blocks.append(_table(
                    ["Material Finding", "Why It Matters / Evidential Limit"],
                    [[ref, prose] for ref, prose in entries[:18]],
                ))

    return SectionContent(
        section_number=section_number,
        section_title="Conclusions",
        blocks=blocks,
    )


# ===========================================================================
# LLM synthesis payload — discovered-entity aggregation (STEP 2)
# ===========================================================================
#
# Every value in the payload is discovered at runtime from the per-module
# results; no case fact, entity, count, or timestamp is hardcoded here.  The
# extractor is deliberately tolerant of the heterogeneous shapes the report
# loader produces (iocs as list OR dict; accounts under accounts/user_accounts/
# cover_accounts; emails under emails/emails_summary; urls under urls/
# suspicious_urls/typedurlsmru; etc.) and falls back to regex over finding
# text so entities are surfaced whether they sit in a tidy key or only in prose.

_SP_EMAIL_RE = re.compile(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}')
# Canonical validator applied to each candidate so offset-prefixed runs, partial
# tokens and no-TLD strings are rejected — only real addresses survive.
_SP_EMAIL_VALIDATE = re.compile(
    r'^[A-Za-z0-9](?:[A-Za-z0-9._%+\-]{0,62}[A-Za-z0-9])?'
    r'@(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24}$'
)
_SP_URL_RE = re.compile(r'https?://[^\s"\'<>)\]]+')
_SP_IP_RE = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
_SP_PHONE_RE = re.compile(r'(?<!\w)\+?\d[\d\s().\-]{6,}\d(?!\w)')


def _sp_valid_emails(text: str) -> list[str]:
    """Extract syntactically valid email addresses from free text.

    Candidates are found by pattern, then each is fully validated, so a value
    included as a network/IOC sample is a real address rather than extraction
    noise (an offset-prefixed run, a partial token, or a string with no TLD).
    Order is preserved and duplicates removed.
    """
    out: list[str] = []
    seen: set[str] = set()
    for m in _SP_EMAIL_RE.finditer(text or ""):
        cand = m.group(0)
        if _SP_EMAIL_VALIDATE.fullmatch(cand) and cand not in seen:
            seen.add(cand)
            out.append(cand)
    return out

_SP_ACCOUNT_KEYS = ("accounts", "user_accounts", "cover_accounts")
_SP_EMAIL_KEYS = ("emails", "emails_summary", "email_addresses")
_SP_PHONE_KEYS = ("phones", "phone_numbers")
_SP_URL_KEYS = ("urls", "suspicious_urls", "typedurlsmru")
_SP_IP_KEYS = ("ips", "ip_addresses", "ipv4", "ipv6")


def _sp_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Read ``name`` from an object attribute or a dict key."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _sp_flatten(value: Any, depth: int = 0) -> list[str]:
    """Recursively flatten a value into a list of non-empty scalar strings."""
    out: list[str] = []
    if value is None or depth > 6:
        return out
    if isinstance(value, str):
        s = value.strip()
        if s:
            out.append(s)
    elif isinstance(value, (int, float)):
        out.append(str(value))
    elif isinstance(value, dict):
        for v in value.values():
            out.extend(_sp_flatten(v, depth + 1))
    elif isinstance(value, (list, tuple, set)):
        for v in value:
            out.extend(_sp_flatten(v, depth + 1))
    return out


def _sp_ioc_bucket(key: str) -> Optional[str]:
    """Map an iocs-dict subkey to a canonical bucket, or None."""
    k = key.lower()
    if k in ("emails", "email", "email_addresses"):
        return "emails"
    if k in ("phones", "phone", "phone_numbers"):
        return "phones"
    if k in ("urls", "url"):
        return "urls"
    if k in ("ips", "ip", "ip_addresses", "ipv4", "ipv6", "ip_address"):
        return "ips"
    return None


def build_synthesis_payload(case: Any, evidence_results: list) -> dict[str, Any]:
    """
    Aggregate discovered entities from the per-module results into a JSON-safe
    dict for the LLM narrative generator.

    Parameters
    ----------
    case:
        Case config/context object (used only for interface symmetry; NO case
        facts are copied into the payload here — the narrative is composed from
        discovered artefacts).
    evidence_results:
        The already-loaded per-module results (report_sections.ModuleResult or
        equivalent dicts).

    Returns
    -------
    dict
        Keys: accounts, timestamps, anti_forensic_acts, iocs{emails,phones,
        urls,ips}, files_of_significance, cross_links, findings, coverage.
    """
    accounts: set[str] = set()
    emails: set[str] = set()
    phones: set[str] = set()
    urls: set[str] = set()
    ips: set[str] = set()
    timestamps: set[str] = set()
    anti_forensic_acts: list[dict[str, str]] = []
    files_of_significance: list[dict[str, str]] = []
    findings_out: list[dict[str, str]] = []
    coverage_out: list[dict[str, Any]] = []
    # value -> set of module names it appeared in (for cross_links)
    link_modules: dict[str, set[str]] = {}

    def _link(value: str, module: str) -> None:
        v = (value or "").strip()
        if v:
            link_modules.setdefault(v, set()).add(module)

    def _add_iocs_from_strings(strings: list[str], module: str) -> None:
        for s in strings:
            for m in _sp_valid_emails(s):
                emails.add(m); _link(m, module)
            for m in _SP_URL_RE.findall(s):
                urls.add(m); _link(m, module)
            for m in _SP_IP_RE.findall(s):
                ips.add(m); _link(m, module)

    for r in evidence_results or []:
        module = str(_sp_attr(r, "module_name", "") or _sp_attr(r, "module", "") or "unknown")
        rd = _sp_attr(r, "raw_data", {}) or {}
        if not isinstance(rd, dict):
            rd = {}
        module_findings = _sp_attr(r, "findings", []) or []

        # --- iocs container (dict of buckets, or flat list) ------------------
        ioc_blob = rd.get("iocs")
        if isinstance(ioc_blob, dict):
            for k, v in ioc_blob.items():
                bucket = _sp_ioc_bucket(k)
                flat = _sp_flatten(v)
                if bucket == "phones":
                    for s in flat:
                        phones.add(s); _link(s, module)
                elif bucket == "emails":
                    for s in flat:
                        emails.add(s); _link(s, module)
                elif bucket == "urls":
                    for s in flat:
                        urls.add(s); _link(s, module)
                elif bucket == "ips":
                    for s in flat:
                        ips.add(s); _link(s, module)
                else:
                    _add_iocs_from_strings(flat, module)
        elif ioc_blob is not None:
            _add_iocs_from_strings(_sp_flatten(ioc_blob), module)

        if isinstance(rd.get("ioc_summary"), dict):
            for k, v in rd["ioc_summary"].items():
                bucket = _sp_ioc_bucket(k)
                flat = _sp_flatten(v)
                if bucket == "phones":
                    for s in flat:
                        phones.add(s); _link(s, module)
                else:
                    _add_iocs_from_strings(flat, module)

        # --- typed key aliases ----------------------------------------------
        for key in _SP_EMAIL_KEYS:
            for m in _sp_valid_emails(" ".join(_sp_flatten(rd.get(key)))):
                emails.add(m); _link(m, module)
        for key in _SP_URL_KEYS:
            for s in _sp_flatten(rd.get(key)):
                matches = _SP_URL_RE.findall(s)
                if matches:
                    for m in matches:
                        urls.add(m); _link(m, module)
                elif s.lower().startswith("www."):
                    urls.add(s); _link(s, module)
        for key in _SP_IP_KEYS:
            for m in _SP_IP_RE.findall(" ".join(_sp_flatten(rd.get(key)))):
                ips.add(m); _link(m, module)
        for key in _SP_PHONE_KEYS:
            for s in _sp_flatten(rd.get(key)):
                if _SP_PHONE_RE.search(s):
                    phones.add(s); _link(s, module)

        # --- accounts -------------------------------------------------------
        for key in _SP_ACCOUNT_KEYS:
            for item in (rd.get(key) or []):
                if isinstance(item, dict):
                    ident = (item.get("username") or item.get("name")
                             or item.get("account") or item.get("user")
                             or item.get("sid") or item.get("email") or "")
                else:
                    ident = str(item)
                ident = (ident or "").strip()
                if ident:
                    accounts.add(ident); _link(ident, module)

        # --- anti-forensic acts ---------------------------------------------
        af_raw = rd.get("anti_forensic_acts") or []
        module_had_af = bool(af_raw)
        for item in af_raw:
            if isinstance(item, dict):
                name = (item.get("name") or item.get("act") or item.get("type")
                        or item.get("technique") or item.get("title")
                        or "anti-forensic act")
                src = (item.get("evidence_source") or item.get("source")
                       or item.get("evidence") or item.get("path")
                       or item.get("file") or item.get("description") or module)
            else:
                name, src = str(item), module
            anti_forensic_acts.append({"act": str(name), "evidence_source": str(src)})
        # Anti-forensic module with no structured act list: derive from findings.
        if not module_had_af and "anti_forensic" in module.lower():
            for f in module_findings:
                anti_forensic_acts.append({
                    "act": str(_sp_attr(f, "title", "anti-forensic act")),
                    "evidence_source": str(_sp_attr(f, "artefact_location", "") or module),
                })

        # --- findings, files of significance, per-finding iocs/accounts -----
        for f in module_findings:
            sev = _sp_attr(f, "severity", None)
            sev_val = getattr(sev, "value", None) or (str(sev) if sev is not None else "")
            ts = _sp_attr(f, "timestamp", None)
            ts_str = ts.isoformat() if hasattr(ts, "isoformat") else (str(ts) if ts else "")
            if ts_str:
                timestamps.add(ts_str)
            path = str(_sp_attr(f, "artefact_location", "") or "")
            title = str(_sp_attr(f, "title", "") or "")
            detail = str(_sp_attr(f, "description", "") or "")

            finding_type = str(_sp_attr(f, "finding_type", "") or "")
            metadata = _sp_attr(f, "metadata", {}) or {}
            if not isinstance(metadata, dict):
                metadata = {}

            findings_out.append({
                "ref": _reference_exhibit_id(_sp_attr(f, "evidence_reference", "")),
                "module": module,
                "severity": sev_val,
                "title": title,
                "path": path,
                "detail": detail,
                "timestamp": ts_str,
                # These structural fields are required for evidence-led material
                # grouping.  Text-token matching is retained only as a fallback
                # for legacy results that pre-date typed findings.
                "category": str(_sp_attr(f, "category", "") or ""),
                "finding_type": finding_type,
                "metadata": dict(metadata),
            })

            if sev_val in ("Critical", "High"):
                files_of_significance.append({
                    "path": path or title,
                    "reason": title,
                    "severity": sev_val,
                    "module": module,
                })

            # Finding-level metadata (raw_data is a JSON string) + prose regex.
            meta: dict = {}
            raw = _sp_attr(f, "raw_data", "")
            if isinstance(raw, dict):
                meta = raw
            elif isinstance(raw, str) and raw.strip().startswith("{"):
                try:
                    meta = json.loads(raw)
                except (ValueError, TypeError):
                    meta = {}
            if isinstance(meta, dict):
                acct = (meta.get("username") or meta.get("account") or meta.get("user"))
                if acct:
                    accounts.add(str(acct)); _link(str(acct), module)
                for mk in ("email", "emails"):
                    for m in _sp_valid_emails(" ".join(_sp_flatten(meta.get(mk)))):
                        emails.add(m); _link(m, module)
            _add_iocs_from_strings([f"{title} {detail}"], module)

        # --- passthrough files_of_significance if the module supplies one ----
        for item in (rd.get("files_of_significance") or []):
            if isinstance(item, dict):
                files_of_significance.append({
                    "path": str(item.get("path") or item.get("file") or ""),
                    "reason": str(item.get("reason") or item.get("why") or ""),
                    "severity": str(item.get("severity") or ""),
                    "module": module,
                })

        # --- coverage from class_results ------------------------------------
        for cr in (_sp_attr(r, "class_results", []) or []):
            verdict = _sp_attr(cr, "verdict", "")
            reason = _sp_attr(cr, "skip_reason", None)
            coverage_out.append({
                "module": module,
                "artefact_class": str(_sp_attr(cr, "artefact_class", "") or ""),
                "verdict": getattr(verdict, "value", None) or str(verdict or ""),
                "count": int(_sp_attr(cr, "count", 0) or 0),
                "reason": (getattr(reason, "value", None) or (str(reason) if reason else "")),
            })

        # --- timeline timestamps --------------------------------------------
        for te in (_sp_attr(r, "timeline_entries", []) or []):
            te_ts = _sp_attr(te, "timestamp", None)
            if te_ts:
                timestamps.add(te_ts.isoformat() if hasattr(te_ts, "isoformat") else str(te_ts))

    # De-duplicate files_of_significance by path, keeping first (highest module order).
    seen_paths: set[str] = set()
    files_dedup: list[dict[str, str]] = []
    for item in files_of_significance:
        p = item.get("path", "")
        if p and p not in seen_paths:
            seen_paths.add(p)
            files_dedup.append(item)

    cross_links = [
        {"value": v, "modules": sorted(mods)}
        for v, mods in sorted(link_modules.items())
        if len(mods) >= 2
    ]

    # Administrative context is included only to constrain interpretation.
    # In particular, a synthetic/validation designation must override any
    # narrative temptation to infer real actors, criminality or legal liability.
    def _case_value(*names: str) -> str:
        for name in names:
            if isinstance(case, dict):
                value = case.get(name)
            else:
                value = getattr(case, name, None) if case is not None else None
                if not value and case is not None:
                    raw = getattr(case, "_raw", {}) or {}
                    value = raw.get(name) if isinstance(raw, dict) else None
            if value:
                return str(value)
        return ""

    _case_context = {
        "case_number": _case_value("case_number", "case_id"),
        "case_title": _case_value("case_title", "title"),
        "classification": _case_value("classification"),
        "background": _case_value("investigation_background", "background"),
    }
    _ctx_blob = " ".join(_case_context.values()).lower()
    _case_context["synthetic_validation"] = any(
        marker in _ctx_blob for marker in
        ("synthetic", "fabricated test", "validation exhibit", "test / validation")
    )

    material_findings = _build_material_findings(findings_out)

    module_outcomes: list[dict[str, Any]] = []
    for r in evidence_results:
        module_outcomes.append({
            "module": str(_sp_attr(r, "module_name", "") or ""),
            "status": str(_sp_attr(r, "status", "") or ""),
            "execution_outcome": str(_sp_attr(r, "execution_outcome", "") or ""),
            "summary": _clean_material_text(_sp_attr(r, "summary", "") or _sp_attr(r, "error_message", ""), limit=320),
            "finding_count": len(_sp_attr(r, "findings", []) or []),
        })

    return {
        "case_context": _case_context,
        "reporting_context": {
            "audience": "non-technical and technical readers",
            "narrative_must_group_duplicates": True,
            "narrative_must_avoid_absolute_paths": True,
            "raw_findings_are_module_output_not_a_key-findings_list": True,
        },
        "accounts": sorted(accounts),
        "timestamps": sorted(timestamps),
        "anti_forensic_acts": anti_forensic_acts,
        "iocs": {
            "emails": sorted(emails),
            "phones": sorted(phones),
            "urls": sorted(urls),
            "ips": sorted(ips),
        },
        "files_of_significance": files_dedup,
        "cross_links": cross_links,
        "material_findings": material_findings,
        "findings": findings_out,
        "coverage": coverage_out,
        "module_outcomes": module_outcomes,
    }


def _extract_who(key_findings: list) -> str:
    actors = [kf.title for kf in key_findings if any(
        w in kf.title.lower() for w in ("user", "account", "subject", "suspect"))]
    return actors[0] if actors else "Not determined from available evidence"


def _extract_what(key_findings: list) -> str:
    crit = [kf.title for kf in key_findings if kf.severity.value in ("Critical", "High")]
    return "; ".join(crit[:3]) if crit else "See key findings table"


def _extract_when(key_findings: list) -> str:
    ts_hints = [kf.description[:100] for kf in key_findings if any(
        w in kf.description.lower()
        for w in ("2020", "2021", "2022", "2023", "2024", "2025", "2026")
    )]
    return ts_hints[0] if ts_hints else "Refer to timeline of events"


def _extract_where(all_findings: list) -> str:
    """Extract location from FindingItem objects (which have artefact_location)."""
    locs = [f.artefact_location for f in all_findings if f.artefact_location]
    return locs[0] if locs else "Digital evidence media (see acquisition section)"


def _extract_why(key_findings: list, case_info: "CaseInfo") -> str:
    return getattr(case_info, "case_type", None) or "Under investigation — refer to case background"


def _extract_how(key_findings: list) -> str:
    methods = [kf.title for kf in key_findings if any(
        w in kf.title.lower()
        for w in ("malware", "carved", "deleted", "keyword", "encrypted", "usb")
    )]
    return "; ".join(methods[:3]) if methods else "Via digital artefacts recovered from evidence media"


def _build_section_references(tools: list, case_config: Any = None, tool_versions: dict = None) -> "SectionContent":
    from .report_sections import build_references_section
    extra: list[str] = []
    for tool in tools:
        extra.append(
            f"{tool.name} v{tool.version}. {tool.vendor}. "
            f"Runtime-detected tool; actual use or non-use is recorded in the relevant module outcome. Purpose: {tool.purpose}."
        )
    return build_references_section(extra_refs=extra or None, tool_versions=tool_versions)


def _build_section_coverage_summary(
    all_module_results: list,
) -> "SectionContent | None":
    """Build Section 7 with one execution row for every configured module.

    Class-level assurance rows are retained separately.  This prevents skipped,
    failed, zero-finding and partial modules from disappearing from coverage.
    """
    from core.coverage_registry import CoverageRegistry
    from modules._base import AssuranceVerdict

    if not all_module_results:
        return None

    reg = CoverageRegistry()
    reg.ingest_all(all_module_results)
    entries = list(reg.all_entries())

    finding_counts = {
        getattr(r, "module_name", ""): len(getattr(r, "findings", []) or [])
        for r in all_module_results
    }

    def display_count(entry) -> str:
        if entry.verdict != AssuranceVerdict.PRESENT:
            return "—"
        rendered = finding_counts.get(entry.module_name, 0)
        if not entry.summarised and rendered > 0 and entry.count != rendered:
            return str(rendered)
        return str(entry.count)

    not_tested_reasons = {"NO_CORPUS", "NOT_APPLICABLE", "WRONG_FS", "NO_EVIDENCE"}

    blocks = [_h1("Section 7 — Examination Coverage")]
    blocks.append(_para(
        "This section records every configured module outcome and every available "
        "artefact-class assurance verdict. PRESENT means an evidence-backed class was "
        "found; VERIFIED ABSENT means an appropriate complete examination ran and found "
        "none; INDETERMINATE means the check was incomplete or unavailable; NOT TESTED "
        "means the required evidence type or corpus was not supplied. NOT TESTED entries "
        "are not scored as passes or failures."
    ))
    blocks.append(_spacer())

    module_names = [str(getattr(r, "module_name", "Unknown") or "Unknown") for r in all_module_results]
    represented = reg.represented_modules()
    missing_modules = [name for name in module_names if name not in represented]
    blocks.append(_para(
        f"Configured module outcomes: {len(all_module_results)}; modules represented in "
        f"assurance coverage: {len(represented)}; artefact-class assurance rows: {len(entries)}."
        + (f" Missing coverage records: {', '.join(missing_modules)}." if missing_modules else "")
    ))
    blocks.append(_spacer())

    # One row per configured module, independent of whether it found anything.
    module_rows = []
    entries_by_module: dict[str, list] = {}
    for entry in entries:
        entries_by_module.setdefault(entry.module_name, []).append(entry)
    for result in all_module_results:
        name = str(getattr(result, "module_name", "Unknown") or "Unknown")
        status = str(getattr(result, "status", "unknown") or "unknown").upper()
        outcome_raw = str(getattr(result, "execution_outcome", "") or "").lower()
        outcome = {
            "ran_found_x": "RAN FOUND X",
            "ran_found_nothing": "RAN FOUND NOTHING",
            "did_not_run": "DID NOT RUN",
            "ran_with_caveat": "RAN WITH CAVEAT",
        }.get(outcome_raw, outcome_raw.replace("_", " ").upper() or "NOT RECORDED")
        result_entries = entries_by_module.get(name, [])
        verdict_labels = []
        for entry in result_entries:
            reason = entry.skip_reason.value if entry.skip_reason else ""
            label = "NOT TESTED" if reason in not_tested_reasons else entry.verdict.value
            if label not in verdict_labels:
                verdict_labels.append(label)
        raw_data = getattr(result, "raw_data", {}) or {}
        statistics = raw_data.get("statistics", {}) or {}
        completion = statistics.get("completion_certificate", {}) or {}
        explicit_execution = str(completion.get("execution_status") or statistics.get("execution_status") or "").upper()
        explicit_assurance = str(completion.get("evidence_assurance") or statistics.get("evidence_assurance") or "").upper()
        reconciliation = statistics.get("deterministic_reconciliation", {}) or {}
        candidate_count = int(
            raw_data.get("candidate_observation_count", 0) or
            reconciliation.get("candidate_observations", 0) or 0
        )
        module_rows.append([
            _display_module_name(name),
            str(completion.get("release_status") or status),
            explicit_execution or outcome,
            str(len(getattr(result, "findings", []) or [])),
            str(candidate_count),
            explicit_assurance or ", ".join(verdict_labels) or "INDETERMINATE",
            str(getattr(result, "summary", "") or getattr(result, "error_message", "") or "")[:700],
        ])
    blocks.append(_h2("7.1 Configured Module Execution Coverage"))
    blocks.append(_table(
        ["Module", "Status", "Execution Status", "Canonical Findings", "Candidates", "Assurance", "Reason / Summary"],
        module_rows,
    ))

    not_tested = [e for e in entries if e.skip_reason and e.skip_reason.value in not_tested_reasons]
    tested = [e for e in entries if e not in not_tested]
    present = sum(1 for e in tested if e.verdict == AssuranceVerdict.PRESENT)
    absent = sum(1 for e in tested if e.verdict == AssuranceVerdict.VERIFIED_ABSENT)
    indeterminate = sum(1 for e in tested if e.verdict == AssuranceVerdict.INDETERMINATE)
    blocks.append(_h2("7.2 Artefact-Class Assurance Coverage"))
    blocks.append(_para(
        f"Assurance rows: {len(entries)} — CORPUS-RELEVANT / ASSESSMENT ATTEMPTED: {len(tested)} "
        f"(PRESENT: {present}, VERIFIED ABSENT: {absent}, INDETERMINATE: {indeterminate}); "
        f"NOT TESTED / NOT APPLICABLE: {len(not_tested)}. "
        "An attempted row is not equivalent to full semantic validation; INDETERMINATE rows remain limitations."
    ))
    blocks.append(_spacer())
    blocks.append(_para(
        "Count is the artefact tally supplied by the module. It is not forced to equal "
        "the number of rendered findings because a single finding may summarise several "
        "artefacts and some factual outputs do not use severity findings."
    ))
    blocks.append(_spacer())

    rows = []
    for entry in entries:
        reason = entry.skip_reason.value if entry.skip_reason else ""
        verdict = "NOT TESTED" if reason in not_tested_reasons else entry.verdict.value
        rows.append([
            _display_module_name(entry.module_name),
            entry.artefact_class,
            entry.locus.value,
            verdict,
            display_count(entry),
            entry.notes or ("Reason: " + reason if reason else ""),
        ])
    blocks.append(_table(["Module", "Artefact Class", "Locus", "Verdict", "Count", "Notes"], rows))
    return SectionContent(section_number=7, section_title="Examination Coverage", blocks=blocks)


def _build_section_global_limitations(
    all_module_results: list,
) -> "SectionContent":
    """Always emit Section 8 so report numbering and limitations stay complete."""
    from core.coverage_registry import CoverageRegistry

    reg = CoverageRegistry()
    reg.ingest_all(all_module_results)
    all_limitations = reg.global_limitations()
    not_tested_reasons = {"NO_CORPUS", "NO_EVIDENCE", "NOT_APPLICABLE", "WRONG_FS"}
    limitations = [
        item for item in all_limitations
        if not item.skip_reason or item.skip_reason.value not in not_tested_reasons
    ]
    not_tested = [item for item in all_limitations if item not in limitations]

    blocks = [_h1("Section 8 — Scope and Limitations")]
    blocks.append(_para(
        "This section identifies capability limits and evidence classes that were not "
        "available in the supplied case. A missing corpus is not a module failure and is "
        "not interpreted as evidence that the artefact class is absent."
    ))
    blocks.append(_spacer())

    if not_tested:
        blocks.append(_h2("8.1 Out of Scope / Not Tested"))
        rows = []
        for item in not_tested:
            rows.append([
                item.module_name,
                item.artefact_class,
                item.skip_reason.value if item.skip_reason else "NOT_APPLICABLE",
                item.notes,
            ])
        blocks.append(_table(["Module", "Artefact Class", "Reason", "Notes"], rows))
    else:
        blocks.append(_h2("8.1 Out of Scope / Not Tested"))
        blocks.append(_para("No artefact class was explicitly recorded as NOT APPLICABLE or NO CORPUS by the completed module results. This does not establish that separate evidence domains—such as genuine RAM, live-disk acquisition or physical mobile acquisition—were tested."))

    if limitations:
        blocks.append(_h2("8.2 Relevant Examination Limitations"))
        rows = []
        for item in limitations:
            rows.append([
                item.module_name,
                item.artefact_class,
                item.skip_reason.value if item.skip_reason else "INDETERMINATE",
                item.notes,
            ])
        blocks.append(_table(["Module", "Artefact Class", "Limitation", "Notes"], rows))
    else:
        blocks.append(_h2("8.2 Relevant Examination Limitations"))
        blocks.append(_para(
            "No INDETERMINATE artefact-class limitation was recorded. This statement "
            "does not imply that unconfigured or out-of-scope evidence classes were examined."
        ))

    return SectionContent(section_number=8, section_title="Scope and Limitations", blocks=blocks)


def _detect_tools() -> list:
    """Auto-detect installed forensic tools and return ToolEntry objects."""
    import subprocess as _sp
    import re as _re
    import sys as _sys

    def _ver(cmd: list, pattern: str = r"[\d]+\.[\d.]+") -> str:
        try:
            result = _sp.run(cmd, capture_output=True, text=True, timeout=5)
            out = (result.stdout or "") + (result.stderr or "")
            m = _re.search(pattern, out)
            return m.group(0) if m else "detected"
        except Exception:
            return "unknown"

    _TOOL_DEFS = [
        (["ewfacquire", "--version"], "ewfacquire",    "libewf project",       "Forensic E01 image acquisition",              "Detected at report generation; use shown per module"),
        (["fls", "-V"],               "fls (TSK)",     "The Sleuth Kit",       "File system listing and timeline",            "Detected at report generation; use shown per module"),
        (["vol.py", "--info"],         "Volatility 3",  "Volatility Foundation","Volatile memory forensics",                  "Detected at report generation; use shown per module"),
        (["bulk_extractor", "--version"], "bulk_extractor", "NPS Forensics",   "String/pattern extraction from disk images",  "Detected at report generation; use shown per module"),
        (["foremost", "-V"],          "foremost",      "Jesse Kornblum",       "File carving by signature",                   "Detected at report generation; use shown per module"),
        (["scalpel", "--version"],    "scalpel",       "Golden G. Richard",    "File carving by signature",                   "Detected at report generation; use shown per module"),
        (["clamscan", "--version"],   "ClamAV",        "Cisco Talos",          "Antivirus/malware detection",                 "Detected at report generation; use shown per module"),
        (["yara", "--version"],       "YARA",          "VirusTotal",           "Malware indicator matching",                  "Detected at report generation; use shown per module"),
        (["exiftool", "-ver"],        "ExifTool",      "Phil Harvey",          "Metadata extraction from files",              "Detected at report generation; use shown per module"),
        (["tesseract", "--version"],  "Tesseract OCR", "Google/HP",            "Text extraction from images",                 "Detected at report generation; use shown per module"),
        (["steghide", "--version"],   "steghide",      "Stefan Hetzl",         "Steganography detection/extraction",          "Detected at report generation; use shown per module"),
        (["strings", "--version"],    "strings",       "GNU binutils",         "String extraction from binary files",         "Detected at report generation; use shown per module"),
        (["hashcat", "--version"],    "hashcat",       "hashcat project",      "Password hash cracking",                      "Detected at report generation; use shown per module"),
        (["john"],                    "John the Ripper","Openwall",            "Password hash cracking",                      "Detected at report generation; use shown per module"),
    ]

    tools = []
    for cmd, name, vendor, purpose, court in _TOOL_DEFS:
        try:
            _sp.run([cmd[0]], capture_output=True, timeout=3)
            ver = _ver(cmd)
            tools.append(ToolEntry(
                name=name, version=ver, vendor=vendor,
                purpose=purpose, validation_reference=court,
            ))
        except Exception:
            pass

    tools.append(ToolEntry(
        name="Python",
        version=_sys.version.split()[0],
        vendor="Python Software Foundation",
        purpose="Scripted analysis pipeline orchestration",
        validation_reference="N/A",
    ))
    tools.append(ToolEntry(
        name="AutoForensics",
        version=_VERSION,
        vendor="Custom forensic platform",
        purpose="Automated multi-module digital forensics pipeline",
        validation_reference="N/A",
    ))
    return tools

# ===========================================================================
# Assurance-hardened report assembly overrides
# ===========================================================================

_EVIDENCE_TIME_KEYS = {
    "timestamp", "datetime", "date_time_original", "datetimeoriginal", "capture_time",
    "captured_at", "last_visit_time", "visit_time", "visited_at",
    "created", "modified", "accessed", "mtime", "atime", "ctime", "crtime",
    "file_created", "file_modified", "timestamp_utc", "event_time",
}

_REPORT_SEMANTIC_TIMESTAMP_MODULES = {
    "pcap_analyzer", "network_protocol_decoder", "dns_analyzer", "http_reconstructor",
    "browser_history_analyzer", "email_communications_analyzer", "mobile_analyzer",
    "document_analyzer", "exiftool_metadata", "windows_registry_analyzer",
}

_PROCESS_TIME_TOKENS = {
    "generated", "generation", "module_start", "module_end", "start_time",
    "end_time", "completed", "run_time", "report_time", "processing_time",
    "finding_time", "recorded_time", "created_at", "updated_at", "run_timestamp",
}


def _rg_collect_evidence_timestamps(evidence_results: list) -> list[dict[str, str]]:
    """Collect only evidence-derived timestamps, never module run timestamps."""
    found: dict[tuple[str, str], dict[str, str]] = {}

    def add(value: Any, kind: str, source: str) -> None:
        dt = _rg_parse_datetime(value)
        if dt is None:
            return
        iso = dt.astimezone(timezone.utc).isoformat()
        found[(iso, kind)] = {"timestamp": iso, "kind": kind, "source": source[:160]}

    def walk(value: Any, key: str = "", source: str = "") -> None:
        low = key.lower()
        if any(tok in low for tok in _PROCESS_TIME_TOKENS):
            return
        if isinstance(value, dict):
            for k, v in value.items():
                walk(v, str(k), source)
            return
        if isinstance(value, (list, tuple, set)):
            for item in value:
                walk(item, key, source)
            return
        if low in _EVIDENCE_TIME_KEYS or any(tok in low for tok in (
            "last_visit", "date_time_original", "capture_date", "filetime",
        )):
            kind = "filesystem" if low in {"created", "modified", "accessed", "mtime", "atime", "ctime", "crtime", "file_created", "file_modified"} else "artefact"
            # Extracted-file stat values in module findings are host-copy times,
            # not source-evidence timestamps. Source filesystem times are loaded
            # exclusively from the native filesystem manifest below.
            if kind == "filesystem":
                return
            add(value, kind, source or key)

    for result in evidence_results or []:
        module = str(getattr(result, "module_name", "") or "unknown")
        if module not in _REPORT_SEMANTIC_TIMESTAMP_MODULES:
            continue
        for entry in getattr(result, "timeline_entries", []) or []:
            add(getattr(entry, "timestamp", None), "artefact", module)
        # Raw module dictionaries often contain parser-generation or finding-record times.
        # They are not admitted into activity chronology. Modules must emit explicit
        # TimelineEntry records for evidence-derived event times.
        for finding in getattr(result, "findings", []) or []:
            # Finding.timestamp is the module processing timestamp and is
            # deliberately excluded. Only metadata fields may contribute.
            raw = getattr(finding, "raw_data", None)
            if isinstance(raw, str) and raw.strip().startswith("{"):
                try:
                    raw = json.loads(raw)
                except Exception:
                    raw = {}
            # Finding metadata is retained for traceability but never used as a
            # chronology source unless the module emitted a typed TimelineEntry.
            _ = raw
    return sorted(found.values(), key=lambda x: x["timestamp"])


def _rg_mask_excerpt(text: str) -> str:
    """Return a bounded, non-secret excerpt for evidence correlation."""
    text = str(text or "")
    text = re.sub(r"(?i)(password|passcode|vpn\s+pw|wifi|admin\s+console)\s*[:=]\s*\S+", r"\1: [REDACTED]", text)
    text = re.sub(r"(?<!\d)\d{12,19}(?!\d)", lambda m: "*" * (len(m.group(0)) - 4) + m.group(0)[-4:], text)
    return " ".join(text.split())[:360]


def _rg_build_correlation_context(case_dir: Path) -> dict[str, Any]:
    """Derive a generic cross-artefact context from extracted evidence files.

    No case value is pre-fed. The function reads only the current run's
    evidence-derived corpus and reports recurring strings with their source
    filenames. It is intentionally conservative and bounded.
    """
    bases = [Path(case_dir)]
    if Path(case_dir).parent not in bases:
        bases.append(Path(case_dir).parent)
    roots: list[Path] = []
    for base in bases:
        roots.extend(base.rglob("extracted_files"))
        roots.extend(base.rglob("deleted_files"))
    # Preserve order while removing duplicate directories.
    roots = list(dict.fromkeys(root.resolve() for root in roots if root.is_dir()))
    records: list[dict[str, Any]] = []
    values: dict[str, set[str]] = {}
    screen_names: set[str] = set()
    excerpts: list[dict[str, str]] = []
    allowed_ext = {".txt", ".csv", ".log", ".md", ".xml", ".json"}
    for root in roots:
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            try:
                if not path.is_file() or path.stat().st_size > 1_000_000:
                    continue
            except OSError:
                continue
            if path.suffix.lower() not in allowed_ext and path.name.lower() not in {"history"}:
                continue
            try:
                data = path.read_bytes()
                text = data.decode("utf-8", errors="ignore")
            except OSError:
                continue
            if not text.strip():
                continue
            rel = str(path.relative_to(root)).replace("\\", "/")
            # Native deleted-file extraction may prefix recovered filenames to
            # avoid collisions.  Remove presentation-only prefixes while
            # retaining the evidence-derived basename and source category.
            rel = re.sub(r"(?i)^DELETED_", "", rel)
            for value in re.findall(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", text):
                values.setdefault(value.lower(), set()).add(rel)
            for value in re.findall(r"(?i)https?://[^\s\"'<>]+", text):
                values.setdefault(value.rstrip(".,;)").lower(), set()).add(rel)
            for value in re.findall(r"(?i)\b(?:PROJECT|OPERATION)\s+[A-Z][A-Z0-9_-]{2,}\b", text):
                values.setdefault(value.upper(), set()).add(rel)
            for value in re.findall(r"(?i)\b(?:dock|drop|server)\s+[A-Za-z0-9_-]{1,24}\b", text):
                values.setdefault(value.lower(), set()).add(rel)
            for line in text.splitlines():
                m = re.match(r"\s*\[[^\]]+\]\s*([A-Za-z0-9_.-]{2,32})\s*:", line)
                if m:
                    screen_names.add(m.group(1))
            if len(excerpts) < 12 and any(tok in text.lower() for tok in (
                "project ", "operation ", "buyer", "dock ", "customer", "deleted:",
            )):
                excerpts.append({"source": rel, "excerpt": _rg_mask_excerpt(text)})
    for value, sources in sorted(values.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        if len(sources) >= 2:
            records.append({"value": value, "sources": sorted(sources)})
    return {
        "recurring_values": records[:12],
        "screen_name_strings": sorted(screen_names)[:12],
        "evidence_excerpts": excerpts[:8],
        "interpretation_rule": "Recurring strings correlate artefacts within the evidence; they do not establish a real identity, communication, ownership, motive or offence.",
    }


def _rg_collect_case_output_timestamps(case_dir: Path) -> list[dict[str, str]]:
    """Load chronology only from the timeline builder's typed semantic CSV.

    Generic JSON scanning is deliberately prohibited here because module result,
    candidate, report and parser-output JSON frequently contain processing times
    under ordinary keys such as ``timestamp``.  The timeline builder is the single
    chronology authority and must classify evidence-derived events before they can
    enter the report.
    """
    import csv
    base = Path(case_dir)
    paths = list(base.rglob("semantic_timeline.csv"))
    records: dict[tuple[str, str, str], dict[str, str]] = {}
    for path in paths:
        try:
            with path.open(encoding="utf-8", errors="replace", newline="") as handle:
                for row in csv.DictReader(handle):
                    raw = str(row.get("timestamp") or "").strip()
                    dt = _rg_parse_datetime(raw)
                    if dt is None:
                        continue
                    event = str(row.get("event") or "").strip()
                    source = str(row.get("source") or path.name).strip()
                    low = f"{event} {source}".lower()
                    if any(tok in low for tok in _PROCESS_TIME_TOKENS):
                        continue
                    kind = "filesystem" if "filesystem" in low else "artefact"
                    iso = dt.astimezone(timezone.utc).isoformat()
                    records[(iso, kind, source)] = {
                        "timestamp": iso, "kind": kind, "source": source[:160]
                    }
        except Exception:
            continue
    return sorted(records.values(), key=lambda x: x["timestamp"])


_legacy_build_synthesis_payload = build_synthesis_payload


def _rg_case_value(case: Any, *names: str) -> str:
    for name in names:
        if isinstance(case, dict):
            value = case.get(name)
        else:
            value = getattr(case, name, None) if case is not None else None
            if not value and case is not None:
                raw = getattr(case, "_raw", {}) or {}
                value = raw.get(name) if isinstance(raw, dict) else None
        if value:
            return str(value)
    return ""


def _rg_parse_datetime(value: Any) -> Optional[datetime]:
    text = str(value or "").strip()
    if not text or re.search(r"(?i)\bxxx\b|\b0000\b", text):
        return None
    text = text.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        pass
    for fmt in (
        "%a %b %d %H:%M:%S %Y", "%Y-%m-%d %H:%M:%S", "%Y:%m:%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S", "%d %B %Y", "%d %b %Y",
    ):
        try:
            return datetime.strptime(text[:32], fmt).replace(tzinfo=timezone.utc)
        except Exception:
            continue
    return None


def build_synthesis_payload(case: Any, evidence_results: list) -> dict[str, Any]:
    """Extend the discovered-fact payload with a traceable claim ledger."""
    payload = _legacy_build_synthesis_payload(case, evidence_results)
    material = payload.get("material_findings") or []

    case_admin = {
        "date_received": _rg_case_value(case, "date_received"),
        "date_commenced": _rg_case_value(case, "date_commenced"),
        "date_completed": _rg_case_value(case, "date_completed"),
    }
    case_admin = {k: v for k, v in case_admin.items() if v}

    evidence_times = _rg_collect_evidence_timestamps(evidence_results)
    artefact_ts = [x["timestamp"] for x in evidence_times if x["kind"] == "artefact"]
    filesystem_ts = [x["timestamp"] for x in evidence_times if x["kind"] == "filesystem"]
    valid_ts = sorted(set(artefact_ts + filesystem_ts))
    unparseable = 0

    acquisition_values: list[str] = []
    for item in material:
        if item.get("theme") != "ewf_metadata":
            continue
        text = " ".join(str(x) for x in item.get("facts") or [])
        for match in re.findall(
            r"(?i)(?:acquisition_date|system_date)\s*[=:]\s*([0-9]{4}[-:/][0-9]{2}[-:/][0-9]{2}(?:[ T][0-9:]{5,8})?)",
            text,
        ):
            dt = _rg_parse_datetime(match.replace("/", "-"))
            value = dt.astimezone(timezone.utc).isoformat() if dt else match
            if value not in acquisition_values:
                acquisition_values.append(value)

    temporal_context = {
        "case_administration": case_admin,
        "acquisition_metadata": acquisition_values,
        "artefact_timestamp_range": {
            "earliest": min(artefact_ts) if artefact_ts else "",
            "latest": max(artefact_ts) if artefact_ts else "",
            "validated_timestamp_count": len(set(artefact_ts)),
        },
        "filesystem_timestamp_range": {
            "earliest": min(filesystem_ts) if filesystem_ts else "",
            "latest": max(filesystem_ts) if filesystem_ts else "",
            "validated_timestamp_count": len(set(filesystem_ts)),
        },
        "evidence_timestamp_records": evidence_times[:200],
        "unparseable_timestamp_count": unparseable,
        "interpretation_rule": (
            "Acquisition, artefact, module-processing and report-generation timestamps are distinct. "
            "Only parseable evidence-derived timestamps may be used for activity chronology."
        ),
    }

    ledger: list[dict[str, Any]] = []
    ctx = payload.get("case_context") or {}
    if ctx.get("synthetic_validation"):
        ledger.append({
            "id": "CTX-01",
            "type": "case_context",
            "fact": "The case is expressly classified as a synthetic or validation examination; planted values are not independently verified real-world conduct.",
        })
    if ctx.get("background"):
        ledger.append({
            "id": "CTX-02",
            "type": "case_context",
            "fact": _clean_material_text(ctx.get("background"), limit=500),
        })
    if case_admin:
        ledger.append({
            "id": "TMP-01",
            "type": "administrative_time",
            "fact": f"Case administrative dates supplied by the case configuration: {case_admin}.",
        })
    if acquisition_values:
        ledger.append({
            "id": "TMP-02",
            "type": "acquisition_time",
            "fact": f"EWF acquisition metadata contains: {acquisition_values}.",
        })
    if artefact_ts or filesystem_ts:
        parts = []
        if artefact_ts:
            parts.append(f"artefact-content timestamps range from {min(artefact_ts)} to {max(artefact_ts)}")
        if filesystem_ts:
            parts.append(f"filesystem timestamps range from {min(filesystem_ts)} to {max(filesystem_ts)}")
        ledger.append({
            "id": "TMP-03",
            "type": "evidence_time",
            "fact": "Validated " + "; ".join(parts) + ". Module-processing and report-generation timestamps are excluded from activity chronology.",
        })

    for item in material:
        ledger.append({
            "id": str(item.get("id")),
            "type": "material_finding",
            "title": str(item.get("title")),
            "assessment_status": str(item.get("assessment_status")),
            "severity": str(item.get("severity")),
            "fact": str(item.get("establishes") or item.get("description") or ""),
            "limit": str(item.get("limitations") or ""),
            "facts": list(item.get("facts") or []),
            "evidence_references": list(item.get("supporting_evidence") or []),
        })

    for idx, link in enumerate((payload.get("cross_links") or [])[:12], 1):
        ledger.append({
            "id": f"XL-{idx:02d}",
            "type": "cross_link",
            "fact": (
                f"The same evidence-derived value appears in these analysis sources: "
                f"{', '.join(link.get('modules') or [])}. Co-occurrence does not establish ownership or a relationship."
            ),
        })

    outcomes = payload.get("module_outcomes") or []
    partial = [o for o in outcomes if str(o.get("status", "")).lower() in {"partial", "error"}]
    skipped = [o for o in outcomes if str(o.get("execution_outcome", "")).lower() == "did_not_run"]
    ledger.append({
        "id": "COV-01",
        "type": "coverage",
        "fact": (
            f"Configured module outcomes include {len(partial)} partial/error outcome(s) and "
            f"{len(skipped)} did-not-run outcome(s). The report must preserve their reasons."
        ),
    })

    payload["temporal_context"] = temporal_context
    payload["claim_ledger"] = ledger
    payload["allowed_evidence_ids"] = [x["id"] for x in ledger if x.get("id")]
    payload.setdefault("reporting_context", {})["required_output_structure"] = {
        "conclusions": "4-6 paragraph objects with text and evidence_basis",
        "five_w_one_h": "WHO/WHAT/WHEN/WHERE/WHY/HOW objects with answer and evidence_basis",
        "significance": "one structured entry per material finding",
        "recommendations": "4-8 priority/action/rationale/evidence_basis objects",
    }
    return payload


def _rg_conclusion_paragraphs(value: Any) -> list[str]:
    if isinstance(value, list):
        out = []
        for item in value:
            text = item.get("text") if isinstance(item, dict) else item
            if str(text or "").strip():
                out.append(str(text).strip())
        return out
    if isinstance(value, str):
        return [p.strip() for p in value.split("\n\n") if p.strip()]
    return []


def _build_section_conclusions_5w1h(conclusions_text: Any, key_findings: list,
                                    all_findings: list, case_info: "CaseInfo",
                                    all_module_results: Optional[list] = None,
                                    case_config: Any = None,
                                    section_number: int = 5,
                                    narrative: Optional[dict] = None) -> "SectionContent":
    """Render examiner-led conclusions, a true 5W1H table and bounded significance."""
    narrative = narrative or {}
    blocks: list[ContentBlock] = [_h1(f"Section {section_number} — Conclusions"), _spacer()]

    blocks.append(_h2(f"{section_number}.1 Executive Investigation Conclusion — Evidence-grounded summary"))
    if narrative.get("llm_used"):
        blocks.append(_ai_disclosure_block())
        provider = str(narrative.get("llm_provider") or "configured provider")
        model = str(narrative.get("llm_model") or "configured model")
        blocks.append(_para(
            f"Provider record: {provider}; model: {model}. The model received the structured claim ledger, "
            "not the raw evidence. Every executive statement remains subject to examiner verification against Section 4."
        ))
        if narrative.get("llm_structural_repair_applied"):
            repair_count = len(narrative.get("llm_structural_repair_notes") or [])
            blocks.append(_para(
                "Report-assurance note: the language-model draft passed substantive grounding controls, "
                f"but {repair_count} under-developed or structurally incomplete field(s) were completed "
                "locally from the same evidence-derived material-finding ledger. No new case fact was "
                "introduced by this structural completion; examiner verification remains mandatory."
            ))
        blocks.append(_spacer())
    elif narrative.get("llm_rejected"):
        blocks.append(_para(
            "The configured language-model output was unavailable or rejected by the evidence/quality controls. "
            "The following bounded deterministic interpretation was used and requires examiner review."
        ))
        blocks.append(_spacer())

    paragraphs = _rg_conclusion_paragraphs(conclusions_text)
    if paragraphs:
        for paragraph in paragraphs:
            blocks.append(_para(paragraph))
            blocks.append(_spacer(5))
    else:
        blocks.append(_para(
            "No executive conclusion passed the evidence and quality controls. The report must not be signed "
            "until an examiner completes a source-bounded conclusion from the technical findings."
        ))

    blocks.append(_h2(f"{section_number}.2 Key Forensic Questions (5W1H)"))
    fw = narrative.get("five_w_one_h")
    fw_rows: list[list[str]] = []
    if isinstance(fw, dict):
        for key in ("WHO", "WHAT", "WHEN", "WHERE", "WHY", "HOW"):
            value = fw.get(key) or {}
            answer = value.get("answer") if isinstance(value, dict) else value
            basis = value.get("evidence_basis") if isinstance(value, dict) else []
            basis_text = ", ".join(str(x) for x in (basis or []))
            fw_rows.append([key, str(answer or "Not established from the supplied evidence."), basis_text])
    if not fw_rows:
        if all_module_results is not None:
            fallback = _build_5w1h(all_module_results, case_config)
            fw_rows = [[k, fallback[k], "Examiner-generated fallback"] for k in ("WHO", "WHAT", "WHEN", "WHERE", "WHY", "HOW")]
    blocks.append(_table(["Question", "Evidence-Based Answer", "Evidence Basis"], fw_rows))

    material = narrative.get("material_findings") or []
    blocks.append(_spacer())
    blocks.append(_h2(f"{section_number}.3 Material Findings"))
    if material:
        rows: list[list[str]] = []
        for idx, item in enumerate(material, 1):
            refs = ", ".join(str(x) for x in (item.get("supporting_evidence") or []))
            fact_id = str(item.get("id") or "")
            evidence = ", ".join(x for x in (fact_id, refs) if x)
            rows.append([
                str(idx),
                str(item.get("title") or "Material finding"),
                str(item.get("assessment_status") or "REVIEW REQUIRED"),
                str(item.get("severity") or "Low"),
                str(item.get("establishes") or item.get("description") or ""),
                evidence,
            ])
        blocks.append(_table(
            ["No.", "Material Finding", "Assessment", "Severity", "What the Evidence Establishes", "Evidence"],
            rows,
        ))
    elif key_findings:
        blocks.append(_table(
            ["No.", "Material Finding", "Severity", "Summary", "Evidence"],
            [[str(i), k.title, k.severity.value, k.description, ", ".join(k.supporting_evidence)] for i, k in enumerate(key_findings, 1)],
        ))
    else:
        blocks.append(_para("No grouped material findings were available for executive interpretation."))

    blocks.append(_spacer())
    blocks.append(_h2(f"{section_number}.4 Evidential Significance and Limits"))
    pfs = narrative.get("per_finding_significance") or {}
    rows: list[list[str]] = []
    if isinstance(pfs, dict):
        for item in material:
            title = str(item.get("title") or "")
            value = pfs.get(title) or {}
            if isinstance(value, dict):
                significance = str(value.get("significance") or item.get("establishes") or "")
                limit_text = str(value.get("evidential_limit") or item.get("limitations") or "")
                basis = ", ".join(str(x) for x in (value.get("evidence_basis") or [item.get("id")]))
            else:
                significance = str(value)
                limit_text = str(item.get("limitations") or "")
                basis = str(item.get("id") or "")
            rows.append([title, significance, limit_text, basis])
    if rows:
        blocks.append(_table(
            ["Material Finding", "Evidential Significance", "Limit / Caution", "Evidence Basis"],
            rows,
        ))
    else:
        blocks.append(_para(
            "No structured significance assessment was available. The examiner must document what each material "
            "finding establishes and what it does not establish before relying on the report."
        ))

    blocks.append(_spacer())
    blocks.append(_para(
        "Executive interpretation does not replace the artefact-level records in Section 4. Where any summary "
        "conflicts with a technical finding, the underlying evidence, module output and examiner verification take precedence."
    ))
    return SectionContent(section_number=section_number, section_title="Conclusions", blocks=blocks)


def _rg_is_synthetic(case_config: Any) -> bool:
    blob = " ".join(
        _rg_case_value(case_config, key)
        for key in ("classification", "case_title", "investigation_background", "background")
    ).lower()
    return any(x in blob for x in ("synthetic", "validation", "fabricated test", "training exhibit"))


def _build_section_references(tools: list, case_config: Any = None, tool_versions: dict = None) -> "SectionContent":
    """Build references without implying that detected tools or laws were used."""
    refs = [
        "Kent, K. et al. (2006). NIST SP 800-86 - Guide to Integrating Forensic Techniques into Incident Response. NIST.",
        "ACPO (2012). Good Practice Guide for Digital Evidence v5. ACPO.",
        "NPCC (2015). Good Practice Guide for Digital Forensics. NPCC.",
        "ISO/IEC 27037:2012 - Guidelines for identification, collection, acquisition and preservation of digital evidence.",
        "ISO/IEC 27042:2015 - Guidelines for the analysis and interpretation of digital evidence.",
        "Casey, E. (2011). Digital Evidence and Computer Crime (3rd ed.). Academic Press.",
        "Carrier, B. (2005). File System Forensic Analysis. Addison-Wesley.",
    ]
    offence_types = []
    if isinstance(case_config, dict):
        offence_types = case_config.get("offence_types") or []
    elif case_config is not None:
        offence_types = getattr(case_config, "offence_types", None) or []
    if offence_types and not _rg_is_synthetic(case_config):
        jurisdiction = _rg_case_value(case_config, "jurisdiction").lower()
        if any(x in jurisdiction for x in ("england", "wales", "united kingdom", "uk")):
            refs.extend([
                "Computer Misuse Act 1990 (c.18).",
                "Fraud Act 2006 (c.35).",
                "Police and Criminal Evidence Act 1984 (c.60), where applicable to the instructed matter.",
            ])

    detected: list[str] = []
    seen: set[str] = set()
    for tool in tools or []:
        name = str(getattr(tool, "name", "") or "").strip()
        version = str(getattr(tool, "version", "") or "").strip()
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        detected.append(
            f"{name}{(' ' + version) if version else ''} - detected in the runtime environment. "
            "The relevant module outcome records whether the tool was actually invoked, skipped or used only for verification."
        )
    refs.extend(detected)

    blocks = [_h1("Section 9 — References"), _spacer(), _numbered(refs)]
    blocks.append(_spacer())
    blocks.append(_para(
        "Legislation is included only where the instructed case context identifies a relevant alleged offence. "
        "Runtime detection of a utility is not represented as proof that it was used."
    ))
    return SectionContent(section_number=9, section_title="References", blocks=blocks)
