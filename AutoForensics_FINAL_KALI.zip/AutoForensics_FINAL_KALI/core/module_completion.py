"""Strict, case-neutral module completion certification.

A module process returning normally is not evidence that its forensic scope was
completed.  This layer evaluates the runtime source inventory, module counters,
accepted finding provenance, candidate quarantine and specialist-tool proof.
It contains no case identifiers, expected artefacts, known hashes or answer-key
values.  The rules are declared in ``config/module_scope_contracts.yaml``.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable
import hashlib
import json

import yaml

from modules._base import ModuleResult, ModuleStatus
from core.fact_classification import duplicate_identity
from core.evidence_ledger import candidate_ledger_path, load_candidate_records, reconciliation_counts
from core.count_schema import build_canonical_counts, count_units as canonical_count_units

_ROOT = Path(__file__).resolve().parents[1]
_CONTRACT_PATH = _ROOT / "config" / "module_scope_contracts.yaml"

_FAILURE_STATES = {
    "ERROR", "FAILED", "FAILED_OFFSET", "IMPORT_FAILED", "FAILED_ISOLATED",
}
_NON_COMPLETE_STATES = {
    "PARTIAL", "COMPLETED_WITH_FALLBACK", "INCOMPLETE", "VERIFY_LATER",
}
_ABSENCE_STATES = {"SKIPPED", "NOT_APPLICABLE", "OUT_OF_SCOPE"}


def _status_name(value: Any) -> str:
    return str(getattr(value, "value", value) or "").upper().strip()


@lru_cache(maxsize=1)
def load_scope_contracts() -> dict[str, dict[str, Any]]:
    data = yaml.safe_load(_CONTRACT_PATH.read_text(encoding="utf-8")) or {}
    modules = data.get("modules") or {}
    if not isinstance(modules, dict):
        raise RuntimeError("module_scope_contracts.yaml has no modules mapping")
    return {str(k): dict(v or {}) for k, v in modules.items()}


def _as_int(value: Any, default: int = 0) -> int:
    try:
        if isinstance(value, bool):
            return int(value)
        return int(value)
    except (TypeError, ValueError):
        return default


def _lookup(stats: dict[str, Any], key: str) -> Any:
    """Find a key at the top level or in known nested statistics blocks."""
    if key in stats:
        return stats[key]
    for block_name in (
        "coverage", "module_statistics", "canonical_result",
        "deterministic_reconciliation", "finding_assurance", "tool_execution",
    ):
        block = stats.get(block_name)
        if isinstance(block, dict) and key in block:
            return block[key]
    return None


def _first_int(stats: dict[str, Any], names: Iterable[str], default: int = 0) -> int:
    """Return the first emitted counter from an ordered same-unit alias list.

    Earlier revisions selected the maximum across aliases.  That could silently
    combine counters with different meanings when a module emitted both a path
    count and a record count.  Callers must order aliases from most specific to
    least specific and the certificate records the unit separately.
    """
    for name in names:
        value = _lookup(stats, name)
        if value not in (None, ""):
            return _as_int(value, default)
    return default


def _dedup_paths(values: Iterable[Any]) -> list[Path]:
    out: list[Path] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        path = Path(str(value))
        try:
            key = str(path.resolve())
        except OSError:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        if path.exists():
            out.append(path)
    return out


def _source_paths(domain: str, config: dict[str, Any]) -> list[Path]:
    ws = config.get("_working_set") or {}
    if domain == "memory_sources":
        return _dedup_paths(
            list(config.get("memory_paths") or [])
            + list(config.get("memory_marker_paths") or [])
            + list(ws.get("nested_memory_sources") or [])
            + list(ws.get("nested_memory_marker_sources") or [])
        )
    if domain == "network_sources":
        values = list(config.get("pcap_paths") or []) + list(ws.get("nested_network_sources") or [])
        if config.get("pcap_path"):
            values.append(config["pcap_path"])
        return _dedup_paths(values)
    if domain == "registry_sources":
        return _dedup_paths(
            list(config.get("registry_hive_paths") or [])
            + list(ws.get("registry_hive_sources") or [])
        )
    if domain == "mobile_sources":
        values: list[Any] = []
        for key in ("mobile_sources", "mobile_roots"):
            values.extend(config.get(key) or [])
        for key in ("nested_mobile_sources", "nested_mobile_roots"):
            values.extend(ws.get(key) or [])
        for key in ("mobile_root_records", "nested_mobile_root_records"):
            for record in (config.get(key) or ws.get(key) or []):
                if isinstance(record, dict):
                    values.append(record.get("path"))
        return _dedup_paths(values)
    if domain == "all_files":
        roots = []
        for key in ("primary_evidence_roots", "corpus_roots"):
            roots.extend(ws.get(key) or [])
        if ws.get("mounted_fs_root"):
            roots.append(ws["mounted_fs_root"])
        return _dedup_paths(roots)
    if domain == "canonical_findings":
        # Canonical records are not paths. Their count is handled separately.
        return []
    evidence = config.get("analysis_path") or config.get("_ewf_device")
    return _dedup_paths([evidence]) if evidence else []


def _canonical_input_count(config: dict[str, Any]) -> int:
    ws = config.get("_working_set") or {}
    by_module = ws.get("canonical_findings_by_module") or {}
    if not isinstance(by_module, dict):
        return 0
    return sum(len(v or []) for v in by_module.values())


def _inventory_complete(config: dict[str, Any]) -> bool:
    ws = config.get("_working_set") or {}
    inventory = ws.get("evidence_inventory")
    return isinstance(inventory, dict) and not ws.get("evidence_inventory_error")


def _is_candidate_or_rejected(metadata: dict[str, Any]) -> bool:
    fact_class = str(metadata.get("fact_class") or "").upper()
    return (
        bool(metadata.get("candidate_only"))
        or str(metadata.get("finding_basis") or "").casefold() == "candidate"
        or fact_class in {"CANDIDATE_ONLY", "REJECTED"}
    )


def _provenance_gaps(result: ModuleResult) -> int:
    """Count accepted findings that lack one complete H2 provenance route.

    H2 accepts either a container/record reference or an exact local file path
    plus its verified SHA-256.  This avoids rejecting a genuine file-backed fact
    merely because it has no raw byte offset, while still failing closed on
    missing or mismatched path/hash pairs.
    """
    gaps = 0
    hash_keys = (
        "source_hash", "file_sha256", "image_sha256", "source_container_sha256", "sha256",
        "database_sha256", "pcap_sha256", "transcript_sha256",
    )
    path_keys = (
        "provenance_source_path", "source_path", "file_path", "image_file",
        "source_file", "database", "pcap_file", "original_source", "source_container_path",
    )
    for finding in result.findings or []:
        metadata = dict(getattr(finding, "metadata", {}) or {})
        if _is_candidate_or_rejected(metadata):
            continue
        ref = getattr(finding, "evidence_reference", None)
        if isinstance(ref, dict) and str(ref.get("source_evidence_sha256") or ""):
            locator = ref.get("artefact_location") or ref.get("locators") or metadata.get("source_offset_cluster_packet_or_row")
            if locator not in (None, "", {}, []):
                continue
        # Exact file-backed provenance: path and matching SHA-256 are sufficient.
        source_value = next((metadata.get(k) for k in path_keys if metadata.get(k)), None)
        if source_value is None:
            # The evidence path identifies the source object; artifact_path may
            # instead point to a generated module report or retained derivative.
            source_value = getattr(finding, "evidence_path", None) or getattr(finding, "artifact_path", None)
        digests = [
            str(metadata.get(k)).lower() for k in hash_keys
            if isinstance(metadata.get(k), str) and len(str(metadata.get(k))) == 64
        ]
        if source_value and digests:
            try:
                source = Path(str(source_value))
                if source.is_file():
                    actual = hashlib.sha256(source.read_bytes()).hexdigest()
                    if actual in digests:
                        continue
            except (OSError, ValueError):
                pass
        gaps += 1
    return gaps


def _unsupported_accepted(result: ModuleResult, *, candidate_only_allowed: bool = False) -> int:
    count = 0
    for finding in result.findings or []:
        metadata = dict(getattr(finding, "metadata", {}) or {})
        candidate = _is_candidate_or_rejected(metadata)
        if candidate:
            # A candidate is permitted only when the module contract explicitly
            # allows it and the record cannot inflate the unique-evidence total.
            if candidate_only_allowed and not metadata.get("counts_toward_unique_evidence", True):
                continue
            count += 1
            continue
        if metadata.get("deterministic_validation") is False:
            count += 1
    return count

def _duplicate_primary_count(result: ModuleResult, module_name: str) -> int:
    """Count unresolved duplicate *facts*, not different facts from one artefact.

    Stored duplicate identities from an earlier pipeline revision are deliberately
    ignored.  Identity is recalculated from source provenance plus semantic record
    fields so an MD5 and SHA-1 confirmation, or an HTTP request and response, do not
    collapse merely because they came from the same file or packet capture.
    Alternative representations and candidates never inflate this count.
    """
    seen: set[str] = set()
    duplicates = 0
    for finding in result.findings or []:
        metadata = dict(getattr(finding, "metadata", {}) or {})
        if not metadata.get("counts_toward_unique_evidence", True):
            continue
        if metadata.get("duplicate_of") or metadata.get("alternative_representation"):
            continue
        identity = duplicate_identity(module_name, finding)
        if identity in seen:
            duplicates += 1
        else:
            seen.add(identity)
    return duplicates


def _specialist_proof(contract: dict[str, Any], stats: dict[str, Any]) -> tuple[bool, list[str]]:
    rule = contract.get("specialist_tool")
    if not isinstance(rule, dict):
        return True, []
    applicable = bool(rule.get("required"))
    if rule.get("required_when_applicable"):
        explicit = _lookup(stats, "specialist_applicable")
        if explicit is not None:
            applicable = bool(explicit)
        else:
            applicable = bool(
                _lookup(stats, "tool_applicable")
                or _lookup(stats, "hashes_attempted")
                or _lookup(stats, "targets_discovered")
            )
    if not applicable:
        return True, []
    missing: list[str] = []
    for field in rule.get("success_fields") or []:
        if not bool(_lookup(stats, str(field))):
            missing.append(str(field))
    return not missing, missing


def _counter_value(stats: dict[str, Any], key: str) -> int | None:
    value = _lookup(stats, key)
    if value in (None, ""):
        return None
    return _as_int(value, 0)


def _paired_counter(
    stats: dict[str, Any],
    pairs: Iterable[tuple[Iterable[str], Iterable[str], str]],
    *,
    normal_completion: bool,
) -> tuple[int, int, str, bool]:
    """Select one discovered/processed pair that measures the same unit.

    A counter is never compared with an unrelated counter.  A processed-only
    exhaustive iterator may self-certify discovery when the module returned a
    normal completion state; a discovered-only counter cannot certify processing.
    """
    for discovered_names, processed_names, unit in pairs:
        discovered = next(
            (v for name in discovered_names if (v := _counter_value(stats, name)) is not None),
            None,
        )
        processed = next(
            (v for name in processed_names if (v := _counter_value(stats, name)) is not None),
            None,
        )
        if discovered is None and processed is None:
            continue
        if discovered is None and processed is not None and normal_completion:
            discovered = processed
        if discovered is not None and processed is None:
            # A discovered-only counter is informative but cannot prove coverage.
            # Do not compare it with zero or with a different-unit counter.
            continue
        return int(discovered or 0), int(processed or 0), unit, True
    return 0, 0, "not-declared", False


def _coverage(result: ModuleResult, contract: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    """Build deterministic coverage from counters that share an explicit unit.

    The previous implementation took a maximum across folders, files, findings,
    packets and records.  That produced false incompleteness.  This implementation
    uses at most one same-unit pair for each dimension and records whether the
    dimension was actually asserted by the module.
    """
    stats = dict(result.statistics or {})
    domain = str(contract.get("input_domain") or "disk_or_evidence")
    status = _status_name(result.status)
    normal_completion = status in {"COMPLETED", "PASS_COMPLETE"}

    explicit_source = _paired_counter(stats, (
        (("sources_discovered",), ("sources_processed", "sources_examined"), "source"),
        (("pcap_files_discovered",), ("pcap_files_processed", "total_pcaps_analyzed"), "pcap"),
        (("memory_sources_discovered",), ("memory_sources_examined",), "memory-source"),
        (("images_scheduled",), ("images_processed",), "image"),
        (("hives_found",), ("hives_processed", "hives_extracted"), "registry-hive"),
    ), normal_completion=normal_completion)

    source_discovered, source_processed, source_unit, source_asserted = explicit_source
    if not source_asserted:
        # The orchestrator invokes a module only after accepting its evidence input.
        # Root directories and wrapper aliases are not independent source objects.
        source_discovered = 1
        source_processed = 1 if normal_completion else 0
        source_unit = "accepted-evidence-input"
        source_asserted = True

    supported_discovered, supported_processed, supported_unit, supported_asserted = _paired_counter(stats, (
        (("supported_objects_discovered",), ("supported_objects_processed",), "supported-object"),
        (("objects_discovered",), ("objects_processed", "objects_examined"), "object"),
        (("files_discovered",), ("files_processed", "files_examined", "files_scanned", "files_hashed"), "file"),
        (("documents_discovered",), ("documents_processed", "documents_analyzed"), "document"),
        (("office_files_discovered",), ("office_files_analyzed",), "office-document"),
        (("candidate_files", "total_candidates"), ("objects_processed", "files_processed"), "candidate"),
        (("hives_found",), ("hives_extracted", "hives_processed"), "registry-hive"),
        (("images_scheduled",), ("images_processed",), "image"),
        (("protected_files_discovered",), ("protected_files_examined", "protected_files_cracked"), "protected-file"),
        (("total_files_scanned",), ("total_files_scanned",), "file"),
        (("files_hashed",), ("files_hashed",), "file"),
        (("total_pcaps_analyzed",), ("total_pcaps_analyzed",), "pcap"),
        (("decoded_frames",), ("decoded_frames",), "network-frame"),
        (("coordinate_records",), ("coordinate_records",), "coordinate-record"),
        (("total_recovered",), ("total_recovered",), "recovered-file"),
        (("metadata_fields_populated",), ("metadata_fields_populated",), "metadata-field"),
        (("filesystem_count",), ("objects_examined", "filesystem_count"), "filesystem"),
        (("files_analyzed",), ("files_analyzed",), "file"),
    ), normal_completion=normal_completion)

    records_discovered, records_processed, records_unit, records_asserted = _paired_counter(stats, (
        (("records_discovered",), ("records_processed", "records_examined", "records_parsed"), "record"),
        (("packets_discovered",), ("packets_processed", "packet_count"), "packet"),
        (("total_packets",), ("total_packets",), "packet"),
        (("total_dns_questions",), ("exact_dns_records",), "dns-record"),
        (("total_requests",), ("total_requests",), "http-request"),
        (("emails_parsed",), ("emails_parsed",), "email-message"),
        (("total_urls",), ("total_urls",), "browser-visit"),
        (("timeline_event_count",), ("timeline_event_count",), "timeline-event"),
        (("technical_event_count",), ("technical_event_count",), "technical-event"),
        (("raw_observations",), ("raw_observations_processed",), "raw-observation"),
    ), normal_completion=normal_completion)

    if domain == "canonical_findings" and not source_asserted:
        canonical_count = _canonical_input_count(config)
        source_discovered = source_processed = canonical_count
        source_unit = "canonical-finding"
        source_asserted = True

    parser_errors = _first_int(stats, ("parser_errors", "parse_errors", "decode_errors"), 0)
    timeouts = _first_int(stats, ("timeouts", "timeout_count"), 0)
    unresolved = _first_int(stats, (
        "unresolved_items", "unresolved_supported_objects", "unresolved_records",
        "unmatched_requests", "unmatched_responses",
    ), 0)
    unsupported = _first_int(stats, ("unsupported_objects", "unsupported_records", "unsupported_formats"), 0)
    skipped = _first_int(stats, ("skipped_objects",), 0)

    return {
        "source_domain": domain,
        "source_objects_discovered": source_discovered,
        "source_objects_processed": source_processed,
        "source_unit": source_unit,
        "source_accounting_asserted": source_asserted,
        "supported_objects_discovered": supported_discovered,
        "supported_objects_processed": supported_processed,
        "supported_object_unit": supported_unit,
        "supported_object_accounting_asserted": supported_asserted,
        "records_discovered": records_discovered,
        "records_processed": records_processed,
        "record_unit": records_unit,
        "record_accounting_asserted": records_asserted,
        "unsupported_objects": unsupported,
        "parser_errors": parser_errors,
        "timeouts": timeouts,
        "unresolved_items": unresolved,
        "skipped_objects": skipped,
        "inventory_completed": _inventory_complete(config),
    }


def certify_module_result(
    result: ModuleResult,
    *,
    module_name: str,
    config: dict[str, Any],
) -> ModuleResult:
    """Attach a completion certificate and enforce the strict final status."""
    contracts = load_scope_contracts()
    contract = contracts.get(module_name)
    stats = dict(result.statistics or {})
    ledger_counts = reconciliation_counts(stats)
    candidate_count = int(ledger_counts["candidate"])
    rejected_count = int(ledger_counts["rejected"])
    unresolved_candidate_count = int(ledger_counts["unresolved"])
    reasons: list[str] = []

    # Completion certificates and the H2 gate must derive all canonical counts
    # from the same retained four-state ledger. Earlier releases certified
    # source_paths from accepted findings only while H2 correctly included
    # retained candidate/rejected records, producing contradictory counts.
    ledger_path = candidate_ledger_path(stats)
    candidate_records, loaded_state_counts, candidate_ledger_error = load_candidate_records(
        module_name, ledger_path
    )
    expected_state_counts = {
        "CANDIDATE": candidate_count,
        "REJECTED": rejected_count,
        "UNRESOLVED": unresolved_candidate_count,
    }
    expected_nonaccepted = sum(expected_state_counts.values())
    if expected_nonaccepted and not ledger_path:
        candidate_ledger_error = "candidate ledger path was not recorded"
    if candidate_ledger_error:
        if expected_nonaccepted:
            reasons.append(f"Canonical candidate ledger unavailable: {candidate_ledger_error}.")
    else:
        for state, expected in expected_state_counts.items():
            actual = int(loaded_state_counts.get(state, 0))
            if actual != expected:
                reasons.append(
                    f"Canonical candidate ledger {state} count {actual} does not match reconciliation count {expected}."
                )

    status = _status_name(result.status)

    if contract is None:
        reasons.append("No declared module scope contract exists.")
        contract = {
            "baseline_group": "UNCLASSIFIED",
            "input_domain": "disk_or_evidence",
            "requires_zero_errors": True,
            "requires_complete_source_accounting": True,
            "requires_provenance_for_accepted_findings": True,
        }

    coverage = _coverage(result, contract, config)
    provenance_gaps = _provenance_gaps(result)
    unsupported_accepted = _unsupported_accepted(
        result, candidate_only_allowed=bool(contract.get("candidate_only_allowed"))
    )
    duplicate_primary = _duplicate_primary_count(result, module_name)

    if status in _FAILURE_STATES:
        final = ModuleStatus.FAILED_ISOLATED
        reasons.append("The module did not complete its declared examination.")
    elif status == "OUT_OF_SCOPE":
        final = ModuleStatus.OUT_OF_SCOPE
    elif status in _ABSENCE_STATES:
        # NOT_APPLICABLE is defensible only when the source inventory was checked
        # or the current evidence domain itself proves non-applicability.
        domain_checked = bool(
            coverage["inventory_completed"]
            or coverage["source_objects_discovered"] == 0
            or _lookup(stats, "applicability_check_completed")
        )
        if status == "OUT_OF_SCOPE":
            final = ModuleStatus.OUT_OF_SCOPE
        elif domain_checked:
            final = ModuleStatus.NOT_APPLICABLE
        else:
            final = ModuleStatus.INCOMPLETE
            reasons.append("Non-applicability was not supported by a completed source inventory.")
    elif status in _NON_COMPLETE_STATES:
        final = ModuleStatus.INCOMPLETE
        reasons.append(f"Returned execution status {status}; successful fallback or partial output cannot make the named module complete.")
    else:
        if result.errors and contract.get("requires_zero_errors", True):
            reasons.append(f"{len(result.errors)} module error(s) remain.")
        if coverage["source_objects_processed"] < coverage["source_objects_discovered"]:
            reasons.append("Not every discovered source object was processed.")
        if coverage["supported_objects_discovered"] and coverage["supported_objects_processed"] < coverage["supported_objects_discovered"]:
            reasons.append("Not every discovered supported object was processed.")
        if coverage["records_discovered"] and coverage["records_processed"] < coverage["records_discovered"]:
            reasons.append("Not every discovered supported record was processed.")
        for key in ("unsupported_objects", "parser_errors", "timeouts", "unresolved_items"):
            if coverage[key] > 0:
                reasons.append(f"{key}={coverage[key]}.")
        # skipped candidates are permitted only when the module records them as
        # rejected/candidate and does not silently omit supported material.
        if coverage["skipped_objects"] > 0 and not contract.get("candidate_only_allowed"):
            reasons.append(f"skipped_objects={coverage['skipped_objects']}.")
        if provenance_gaps and contract.get("requires_provenance_for_accepted_findings", True):
            reasons.append(f"{provenance_gaps} accepted finding(s) lack complete provenance.")
        if unsupported_accepted:
            reasons.append(f"{unsupported_accepted} candidate/non-deterministic record(s) remained in accepted findings.")
        if unresolved_candidate_count and contract.get(
            "block_unresolved_candidates", not bool(contract.get("candidate_only_allowed"))
        ):
            reasons.append(f"unresolved_candidate_observations={unresolved_candidate_count}.")
        if candidate_count and contract.get("block_candidate_observations", False):
            reasons.append(f"candidate_observations={candidate_count}.")
        if duplicate_primary:
            reasons.append(f"{duplicate_primary} duplicate primary representation(s) remained accepted.")

        for field in contract.get("required_zero_fields") or []:
            value = _lookup(stats, str(field))
            if value is None:
                reasons.append(f"Required completion counter '{field}' was not emitted.")
            elif _as_int(value, 0) != 0:
                reasons.append(f"{field}={_as_int(value, 0)}.")

        specialist_ok, missing_fields = _specialist_proof(contract, stats)
        if not specialist_ok:
            reasons.append("Specialist-tool completion proof missing: " + ", ".join(missing_fields) + ".")

        final = ModuleStatus.PASS_COMPLETE if not reasons else ModuleStatus.INCOMPLETE

    # Procedural completion and evidentiary assurance are separate.  A module
    # can completely execute a candidate-generation procedure while the claimed
    # evidentiary interpretation remains INDETERMINATE.
    accepted = [f for f in (result.findings or []) if not _is_candidate_or_rejected(dict(getattr(f, "metadata", {}) or {}))]
    # Candidate observations are quarantined by deterministic_reconciler and no
    # longer live in result.findings.  Use the four-state ledger counts rather
    # than silently reporting zero after reconciliation.
    candidates = candidate_count
    if final == ModuleStatus.FAILED_ISOLATED:
        execution_status = "EXECUTION_FAILED"
        evidence_assurance = "INDETERMINATE"
    elif final == ModuleStatus.OUT_OF_SCOPE:
        execution_status = "OUT_OF_SCOPE"
        evidence_assurance = "OUT_OF_SCOPE"
    elif final == ModuleStatus.NOT_APPLICABLE:
        execution_status = "NOT_APPLICABLE"
        evidence_assurance = "NOT_APPLICABLE"
    elif final == ModuleStatus.INCOMPLETE:
        execution_status = "EXECUTION_PARTIAL"
        evidence_assurance = "MIXED" if accepted else "INDETERMINATE"
    else:
        execution_status = "EXECUTION_COMPLETE"
        if accepted and (candidate_count or unresolved_candidate_count):
            evidence_assurance = "MIXED"
        elif accepted:
            evidence_assurance = "PRESENT"
        elif candidate_count or unresolved_candidate_count:
            evidence_assurance = "INDETERMINATE"
        else:
            evidence_assurance = "SCOPED_ABSENCE"

    canonical_counts = build_canonical_counts(
        accepted_findings=accepted,
        candidate_records=candidate_records,
        statistics=stats,
        limitations=stats.get("limitations") or stats.get("known_limitations"),
    )
    # The deterministic reconciliation ledger is authoritative for non-accepted
    # observations.  Reassert it explicitly so no absent record list can silently
    # turn a retained candidate/rejection/unresolved observation into zero.
    canonical_counts["candidate_observations"] = candidate_count
    canonical_counts["rejected_observations"] = rejected_count
    canonical_counts["unresolved_observations"] = unresolved_candidate_count
    count_units = canonical_count_units(canonical_counts)
    count_units.update({
        "source_objects": {"discovered": coverage["source_objects_discovered"], "processed": coverage["source_objects_processed"], "unit": coverage["source_unit"]},
        "supported_objects": {"discovered": coverage["supported_objects_discovered"], "processed": coverage["supported_objects_processed"], "unit": coverage["supported_object_unit"]},
        "records": {"discovered": coverage["records_discovered"], "processed": coverage["records_processed"], "unit": coverage["record_unit"]},
        "unresolved_objects": {"count": coverage["unresolved_items"], "unit": "unresolved-object"},
    })

    certificate = {
        "schema": "autoforensics-module-completion-v4",
        "module": module_name,
        "baseline_group": contract.get("baseline_group"),
        "declared_input_domain": contract.get("input_domain"),
        "declared_scope": contract.get("declared_scope") or contract.get("completion_claim"),
        "original_status": status,
        "execution_status": execution_status,
        "evidence_assurance": evidence_assurance,
        "release_status": _status_name(final),
        "final_status": _status_name(final),
        "coverage": coverage,
        "candidate_ledger": {
            "path": ledger_path,
            "loaded_records": len(candidate_records),
            "state_counts": loaded_state_counts,
            "load_error": candidate_ledger_error or "",
        },
        "count_units": count_units,
        "canonical_counts": canonical_counts,
        "accepted_findings": canonical_counts["accepted_findings"],
        "candidate_observations": candidate_count,
        "rejected_observations": rejected_count,
        "unresolved_observations": unresolved_candidate_count,
        "provenance_gaps": provenance_gaps,
        "unsupported_accepted_findings": unsupported_accepted,
        "duplicate_primary_representations": duplicate_primary,
        "errors": len(result.errors or []),
        "reasons": reasons,
        "claim": (
            contract.get("completion_claim")
            if _status_name(final) == "PASS_COMPLETE"
            else "No completeness or absence claim is made beyond the successfully processed records."
        ),
        "case_specific_reference_used": False,
    }
    canonical = json.dumps(certificate, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    certificate["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    stats["completion_certificate"] = certificate
    stats["execution_status"] = execution_status
    stats["evidence_assurance"] = evidence_assurance
    stats["release_status"] = _status_name(final)
    stats["count_units"] = count_units
    stats["canonical_counts"] = canonical_counts
    stats["coverage"] = coverage
    result.statistics = stats
    result.status = final

    # Make the final status and reason visible without deleting the module's
    # original domain-specific summary.
    base = str(result.summary or "").strip()
    suffix = (
        "PASS — complete within declared scope; no additional supported findings remain unreported."
        if final == ModuleStatus.PASS_COMPLETE
        else f"{_status_name(final)} — " + ("; ".join(reasons[:4]) if reasons else "declared scope not executed")
    )
    if "Completion certification:" in base:
        base = base.split("Completion certification:", 1)[0].rstrip(" .;")
    result.summary = f"{base} Completion certification: {suffix}".strip()
    return result
