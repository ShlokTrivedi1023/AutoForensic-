"""Evidence-access and filesystem-offset probing.

External Sleuth Kit tools are an optional verification/acceleration path.  The
native detector is always available for ordinary image files and no operation
requires ``sudo`` or an OS mount.
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional

_CANDIDATE_OFFSETS = [0, 63, 2048, 128, 64]
_FLS_TIMEOUT = 30


def probe_filesystem_offset(device: str, logger: logging.Logger) -> Optional[int]:
    """Return the first readable filesystem's sector offset, or ``None``.

    Order:
      1. Try Sleuth Kit when callable (mmls + fls verification).
      2. Probe common offsets with fls.
      3. Fall back to native MBR/GPT/super-floppy/signature detection.

    The function never assumes sector 63 and never invokes sudo.
    """
    for mmls_type in ("dos", "gpt"):
        try:
            r = subprocess.run(
                ["mmls", "-t", mmls_type, device],
                capture_output=True, text=True, timeout=30,
            )
        except Exception as exc:
            logger.debug("mmls -t %s unavailable/failed: %s", mmls_type, exc)
            continue
        if r.returncode == 0 and r.stdout:
            for start in _parse_mmls_starts(r.stdout):
                if _fls_probe(device, start, logger):
                    logger.info("Offset resolved via mmls -t %s: %d sectors", mmls_type, start)
                    return start

    for offset in _CANDIDATE_OFFSETS:
        if _fls_probe(device, offset, logger):
            logger.info("Offset resolved via optional fls probe: %d sectors", offset)
            return offset

    # Native fallback works on a regular reconstructed/raw image file. Block
    # devices may also work where the current process has read permission.
    try:
        from core.native_filesystem import best_filesystem
        candidate = best_filesystem(Path(device))
        if candidate is not None:
            logger.info(
                "Offset resolved natively: %d sectors (%s, %s)",
                candidate.offset_sectors, candidate.fs_type, candidate.source,
            )
            return candidate.offset_sectors
    except Exception as exc:
        logger.debug("Native filesystem offset detection failed: %s", exc)

    logger.warning("Could not resolve a valid filesystem offset for %s", device)
    return None


def _parse_mmls_starts(mmls_output: str) -> list[int]:
    """Extract plausible start-sector integers from mmls tabular output."""
    starts: list[int] = []
    for line in mmls_output.splitlines():
        parts = line.split()
        if len(parts) >= 3:
            try:
                starts.append(int(parts[2]))
            except ValueError:
                pass
    return sorted(set(starts))


def _fls_probe(device: str, offset: int, logger: logging.Logger) -> bool:
    cmd = ["fls", "-o", str(offset), device]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=_FLS_TIMEOUT)
    except Exception as exc:
        logger.debug("fls probe offset=%d unavailable/failed: %s", offset, exc)
        return False
    return r.returncode == 0 and bool([line for line in r.stdout.splitlines() if line.strip()])


class EvidenceAccess:
    """Thin wrapper holding a readable media path and detected sector offset."""

    def __init__(self, device: str, offset: Optional[int]):
        self.device = device
        self.offset = offset

    @classmethod
    def from_mounted(cls, device: str, logger: logging.Logger) -> "EvidenceAccess":
        return cls(device=device, offset=probe_filesystem_offset(device, logger))
