"""
5W1H aggregator: synthesises only from existing findings.
No claim appears if it has no supporting finding_id.
"""
from __future__ import annotations
from typing import Any


def build_5w1h(all_findings: list[dict]) -> dict[str, list[dict]]:
    """
    Returns {who, what, when, where, why_how} where each value is a list of
    {claim: str, finding_id: str, severity: str} dicts.
    """
    result: dict[str, list[dict]] = {k: [] for k in ("who", "what", "when", "where", "why_how")}

    for f in all_findings:
        fid   = f.get("finding_id", "")
        ftype = f.get("finding_type", "")
        meta  = f.get("metadata") or {}
        sev   = f.get("severity", "Info")
        title = f.get("title", f.get("description", ""))[:120]

        if ftype in ("USER_ACCOUNT", "REGISTERED_OWNER", "EMAIL_PARTICIPANT", "COVER_ACCOUNT"):
            name = meta.get("username") or meta.get("name") or title
            result["who"].append({"claim": name, "finding_id": fid, "severity": sev})

        if ftype in ("MALWARE_DETECTED", "HIGH_ENTROPY_FILE", "PACKED_EXECUTABLE",
                     "PROTECTED_DOCUMENT", "EXTENSION_MISMATCH", "HIDDEN_PROCESS_DKOM",
                     "BITCOIN_ADDRESS", "EMAIL_ADDRESS_IOC"):
            result["what"].append({"claim": title, "finding_id": fid, "severity": sev})

        if ftype in ("TIMELINE_EVENT", "USERASSIST_ENTRY", "DELETED_FILE",
                     "LNK_TARGET", "USB_DEVICE"):
            ts = meta.get("timestamp") or meta.get("last_exec") or meta.get("mtime") or ""
            if ts:
                result["when"].append({"claim": f"{title} at {ts}", "finding_id": fid, "severity": sev})

        if ftype in ("TIMEZONE", "GEO_LOCATION", "NETWORK_SHARE", "IP_ADDRESS_IOC"):
            result["where"].append({"claim": title, "finding_id": fid, "severity": sev})

        if ftype in ("ANTI_FORENSIC_TOOL", "WIPING_TOOL", "DOUBLE_EXTENSION",
                     "ALTERNATE_DATA_STREAM", "ENCRYPTED_ARCHIVE", "RECOVERED_PASSWORD",
                     "MACRO_DETECTED"):
            result["why_how"].append({"claim": title, "finding_id": fid, "severity": sev})

    return result
