"""
core/report_loader.py

Scans a completed AutoForensics case output directory, parses every known
module manifest JSON file, and converts the raw findings into
core.report_sections.ModuleResult + FindingItem objects ready for
ReportGenerator.generate().

Supported manifests
-------------------
disk_analysis.json        — pure-Python disk image analysis (from tools/analyze_image.py)
artifacts_manifest.json   — artifact_extractor module output
scalpel_manifest.json     — scalpel_carver module output
foremost_manifest.json    — foremost_carver module output
strings_manifest.json     — string_extractor module output
recovery_manifest.json    — deleted_file_recovery module output
evidence_info.json        — optional evidence acquisition record

Also loads any generic module result JSON files that contain a 'module_name'
and 'findings' key, regardless of the originating module.

Embedded screenshots (Fix 5)
-----------------------------
When matplotlib is available this module generates two embedded charts:
  - Timeline bar chart derived from file timestamps
  - Finding severity distribution pie chart
These are injected as ``chart_image`` ContentBlocks into the file system
and executive summary sections respectively.
"""

from __future__ import annotations

import base64
import io
import json
import logging
import hashlib
import os as _os
import tempfile as _tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .report_sections import (
    EvidenceAcquisition,
    FindingItem,
    FindingSeverity,
    ModuleResult,
    TimelineEntry,
    ContentBlock,
)

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _MPL = True
except ImportError:
    _MPL = False

_logger = logging.getLogger("autoforensics.report_loader")


def _savefig_b64(fig, *, dpi: int = 120, facecolor=None) -> str:
    """Save a matplotlib figure to a named temp file and return base64-encoded PNG.

    Uses a real file on disk instead of BytesIO to avoid 'I/O on closed file'
    errors that occur when matplotlib or ReportLab close a shared buffer.
    """
    tf = _tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    tmp = tf.name
    tf.close()
    try:
        kwargs: dict = {"format": "png", "bbox_inches": "tight", "dpi": dpi}
        if facecolor is not None:
            kwargs["facecolor"] = facecolor
        fig.savefig(tmp, **kwargs)
        plt.close(fig)
        with open(tmp, "rb") as f:
            return base64.b64encode(f.read()).decode("ascii")
    finally:
        try:
            _os.unlink(tmp)
        except OSError:
            pass

# ---------------------------------------------------------------------------
# Evidence-index helpers (Defect 2 fix)
# ---------------------------------------------------------------------------

import re as _re_loader


def _derive_evidence_index(path: Path) -> Optional[int]:
    r"""Return the 0-based evidence index from an ev\d\d path component, else None."""
    for part in path.parts:
        m = _re_loader.match(r'^ev(\d{2})$', part)
        if m:
            return int(m.group(1))
    return None


def _cfg_get(item: Any, *keys: str, default: str = "") -> str:
    """Read the first present key from a dict-or-object config item."""
    for k in keys:
        if isinstance(item, dict):
            v = item.get(k)
        else:
            v = getattr(item, k, None)
        if v:
            return str(v)
    return default


def _build_evidence_descriptors(case_config: Any) -> list[dict]:
    """Build an ordered list of evidence descriptors discovered from case_config.

    Each descriptor carries the exhibit id and the identity signals used to
    attribute a module result to it: image path, basename, and image hashes.
    The list is empty when no case_config / evidence items are available; in
    that case attribution falls back to evNN path components only.  No exhibit
    ids, counts, or paths are hardcoded — every value is read from config.
    """
    if case_config is None:
        return []
    if isinstance(case_config, dict):
        items = case_config.get("evidence_items", []) or case_config.get("evidence", [])
    else:
        items = getattr(case_config, "evidence_items", None)
        if items is None:
            items = getattr(case_config, "evidence", []) or []
    descriptors: list[dict] = []
    for i, it in enumerate(items or []):
        path = _cfg_get(it, "path", "source_path", "image_path")
        exhibit = _cfg_get(it, "id", "exhibit", "exhibit_number") or f"EX-{i + 1:03d}"
        descriptors.append({
            "index": i,
            "exhibit": exhibit,
            "path": path,
            "basename": Path(path).name.lower() if path else "",
            "md5": _cfg_get(it, "hash_md5", "md5", "image_md5").lower(),
            "sha256": _cfg_get(it, "hash_sha256", "sha256", "image_sha256").lower(),
        })
    return descriptors


def _peek_source_identity(path: Path) -> dict:
    """Read image path/hash identity from a manifest JSON without full parsing."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    return {
        "image_path": data.get("image_path") or data.get("evidence_path")
        or data.get("source_image") or "",
        "md5": str(data.get("image_md5") or data.get("md5") or "").lower(),
        "sha256": str(data.get("image_sha256") or data.get("sha256") or "").lower(),
    }


def _resolve_exhibit(
    descriptors: list[dict],
    *,
    manifest_path: Optional[Path] = None,
    identity: Optional[dict] = None,
) -> Optional[str]:
    """Resolve a module result to an exhibit id from discovered signals.

    Priority: evNN path component -> image hash match -> image path/basename
    match.  Returns None when no signal resolves (caller decides fallback).
    """
    # 1. evNN directory component — authoritative when the pipeline lays output
    #    out per evidence item.
    if manifest_path is not None:
        idx = _derive_evidence_index(manifest_path)
        if idx is not None:
            for d in descriptors:
                if d["index"] == idx:
                    return d["exhibit"]
            return f"EX-{idx + 1:03d}"

    identity = identity or {}
    md5 = str(identity.get("md5", "")).lower()
    sha256 = str(identity.get("sha256", "")).lower()
    image_path = str(identity.get("image_path", ""))

    # 2. image hash match — strongest content-based signal
    for d in descriptors:
        if (md5 and d["md5"] and md5 == d["md5"]) or \
           (sha256 and d["sha256"] and sha256 == d["sha256"]):
            return d["exhibit"]

    # 3. image path / basename match
    if image_path:
        ip = image_path.lower()
        bn = Path(image_path).name.lower()
        for d in descriptors:
            if d["path"] and d["path"].lower() == ip:
                return d["exhibit"]
        for d in descriptors:
            if d["basename"] and d["basename"] == bn:
                return d["exhibit"]
        # 4. containment — an artefact path recorded *under* an evidence image
        #    (e.g. a per-image output tree) still identifies that image.  Longest
        #    descriptor path wins so nested roots resolve unambiguously.
        _norm = ip.replace("\\", "/")
        _hits = [
            d for d in descriptors
            if d["path"] and d["path"].lower().replace("\\", "/") in _norm
        ]
        if _hits:
            return max(_hits, key=lambda d: len(d["path"]))["exhibit"]
        for d in descriptors:
            if d["basename"] and d["basename"] in _norm:
                return d["exhibit"]
    return None


def _stamp_exhibit(
    result: ModuleResult, exhibit: str, *, overwrite: bool = False
) -> None:
    """Stamp one exhibit id onto a result's findings and timeline entries.

    By default an existing attribution is never overwritten: a single
    ModuleResult may aggregate entries from several evidence items (see
    ``_load_combined_report_json``), and each finding already carries the
    attribution resolved for its own entry.  Clobbering those would collapse
    every exhibit into one — the multi-exhibit dedup regression.
    """
    for f in result.findings:
        if overwrite or not (getattr(f, "evidence_reference", "") or ""):
            f.evidence_reference = exhibit
    for t in result.timeline_entries:
        if overwrite or not (getattr(t, "exhibit_number", "") or ""):
            t.exhibit_number = exhibit
    result.raw_data["_exhibit"] = exhibit


def _apply_evidence_index(
    result: ModuleResult,
    path: Path,
    descriptors: Optional[list[dict]] = None,
) -> None:
    """Attribute a freshly loaded module result to its evidence item.

    Uses evNN path components and (when descriptors are supplied) the manifest's
    own image identity.  The identity is stashed on raw_data so the final
    attribution pass can resolve results that no per-manifest signal covered.
    """
    descriptors = descriptors or []
    identity = _peek_source_identity(path)
    if identity:
        result.raw_data.setdefault("_source_identity", identity)
    ref = _resolve_exhibit(descriptors, manifest_path=path, identity=identity)
    if ref is None and not descriptors:
        # Legacy single-evidence behaviour: evNN or first exhibit.
        idx = _derive_evidence_index(path)
        ref = f"EX-{(idx or 0) + 1:03d}"
    if ref:
        _stamp_exhibit(result, ref)


def _attribute_findings_to_evidence(
    results: list[ModuleResult],
    descriptors: list[dict],
) -> None:
    """Final attribution pass over every loaded result.

    Resolves results that no per-manifest signal covered (e.g. modules loaded
    from a combined report.json, which carry no manifest path).  Discovers the
    evidence-item count at runtime from descriptors; never assumes one item.
    """
    if not descriptors:
        return
    if len(descriptors) == 1:
        # Exactly one evidence item: every result belongs to it, by definition.
        only = descriptors[0]["exhibit"]
        for r in results:
            _stamp_exhibit(r, only)
        return
    for r in results:
        # Per-finding attribution first: a result merged from several evidence
        # items must not be attributed as a whole.  Each finding is resolved
        # from its own artefact location, so exhibits stay distinct.
        for f in r.findings:
            if getattr(f, "evidence_reference", "") or "":
                continue
            loc = (getattr(f, "artefact_location", "") or "")
            if not loc:
                continue
            ref_f = _resolve_exhibit(descriptors, identity={"image_path": loc})
            if ref_f:
                f.evidence_reference = ref_f

        if r.raw_data.get("_exhibit"):
            continue  # already resolved during load
        identity = r.raw_data.get("_source_identity") or {}
        ref = _resolve_exhibit(descriptors, identity=identity)
        if ref is None:
            ref = _resolve_by_findings(r, descriptors)
        if ref:
            # Fills only findings that no per-finding signal resolved.
            _stamp_exhibit(r, ref)


def _recorded_exhibit_ids(case_dir: Path) -> list[str]:
    """Exhibit numbers recorded in evidence_info.json acquisition files on disk.

    These are authoritative per-output acquisition records the pipeline writes
    alongside a module output.  They are used only as a last-resort attribution
    signal for outputs that carry no evNN directory and whose image identity
    matched no declared evidence item (e.g. a single-evidence output loaded in
    report-only mode).  Order is preserved and duplicates removed.
    """
    ids: list[str] = []
    for p in Path(case_dir).rglob("evidence_info.json"):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        items = data if isinstance(data, list) else [data]
        for it in items:
            ex = str((it or {}).get("exhibit_number", "") or "").strip()
            if ex:
                ids.append(ex)
    seen: set[str] = set()
    out: list[str] = []
    for x in ids:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def _finalise_attribution(
    results: list[ModuleResult],
    descriptors: list[dict],
    case_dir: Path,
    logger: logging.Logger,
) -> None:
    """Guarantee every finding carries an exhibit id from an on-disk record.

    Runs after signal-based attribution (evNN, hash, path).  Any residual
    orphan is stamped only when the source is unambiguous: a single recorded
    ``evidence_info.json`` exhibit number, or the sole declared evidence
    descriptor.  When two or more candidates remain with no per-result signal
    to disambiguate, orphans are left unresolved on purpose — a court report
    must fail loudly at assembly rather than guess which exhibit produced a
    piece of evidence.
    """
    def _has_orphan(r: ModuleResult) -> bool:
        return any(not (getattr(f, "evidence_reference", "") or "")
                   for f in r.findings)

    orphaned = [r for r in results if _has_orphan(r)]
    if not orphaned:
        return
    candidates = _recorded_exhibit_ids(case_dir) or [d["exhibit"] for d in descriptors]
    if len(candidates) == 1:
        only = candidates[0]
        for r in orphaned:
            _stamp_exhibit(r, only)
        logger.info(
            "Attributed %d residual result(s) to the sole recorded exhibit %s",
            len(orphaned), only,
        )


def _resolve_by_findings(result: ModuleResult, descriptors: list[dict]) -> Optional[str]:
    """Best-effort attribution from a result's own findings' artefact locations."""
    for f in result.findings:
        loc = (getattr(f, "artefact_location", "") or "")
        if not loc:
            continue
        ref = _resolve_exhibit(descriptors, identity={"image_path": loc})
        if ref:
            return ref
    return None


# ---------------------------------------------------------------------------
# Severity mapping helpers
# ---------------------------------------------------------------------------

_SEV_MAP: dict[str, FindingSeverity] = {
    "critical": FindingSeverity.CRITICAL,
    "high":     FindingSeverity.HIGH,
    "medium":   FindingSeverity.MEDIUM,
    "low":      FindingSeverity.LOW,
    "info":     FindingSeverity.LOW,
    "informational": FindingSeverity.LOW,
}


def _sev(raw: str) -> FindingSeverity:
    return _SEV_MAP.get(str(raw).lower(), FindingSeverity.LOW)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(raw: Any) -> Optional[datetime]:
    if not raw:
        return None
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f+00:00",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ):
        try:
            return datetime.strptime(str(raw), fmt)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# Chart generation helpers (Fix 5 — embedded screenshots)
# ---------------------------------------------------------------------------

def _chart_severity_pie(findings: list[FindingItem]) -> Optional[ContentBlock]:
    """Generate a severity distribution pie chart as a base64 chart_image block."""
    if not _MPL or not findings:
        return None
    counts = {s.value: 0 for s in FindingSeverity}
    for f in findings:
        counts[f.severity.value] += 1
    labels = [k for k, v in counts.items() if v > 0]
    sizes  = [counts[k] for k in labels]
    if not sizes:
        return None
    colours = {"Critical": "#C0392B", "High": "#D35400", "Medium": "#D4AC0D", "Low": "#1E8449"}
    try:
        fig, ax = plt.subplots(figsize=(5, 3.5))
        ax.pie(sizes, labels=labels, autopct="%1.0f%%",
               colors=[colours.get(l, "#888888") for l in labels],
               startangle=90, textprops={"fontsize": 9})
        ax.set_title("Finding Severity Distribution", fontsize=10, fontweight="bold")
        b64 = _savefig_b64(fig, dpi=120)
        return ContentBlock(
            block_type="chart_image",
            data={"data_b64": b64, "label": "Figure 1 — Finding severity distribution",
                  "width_mm": 100},
        )
    except Exception as exc:
        _logger.warning("Severity pie chart failed: %s", exc)
        return None


def _chart_timeline(timeline_entries: list[TimelineEntry]) -> Optional[ContentBlock]:
    """Generate a timeline bar chart from timeline entries."""
    if not _MPL or not timeline_entries:
        return None
    try:
        monthly: dict[str, int] = {}
        for te in timeline_entries:
            key = te.timestamp.strftime("%Y-%m")
            monthly[key] = monthly.get(key, 0) + 1
        if not monthly:
            return None
        sorted_keys = sorted(monthly.keys())
        values = [monthly[k] for k in sorted_keys]
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.bar(range(len(sorted_keys)), values, color="#2C3E50", alpha=0.75)
        ax.set_xticks(range(len(sorted_keys)))
        ax.set_xticklabels(sorted_keys, rotation=45, ha="right", fontsize=7)
        ax.set_ylabel("Events", fontsize=8)
        ax.set_title("Timeline Event Distribution by Month", fontsize=9, fontweight="bold")
        ax.grid(axis="y", linestyle="--", alpha=0.4)
        plt.tight_layout()
        b64 = _savefig_b64(fig, dpi=120)
        return ContentBlock(
            block_type="chart_image",
            data={"data_b64": b64, "label": "Figure 2 — Timeline event distribution",
                  "width_mm": 150},
        )
    except Exception as exc:
        _logger.warning("Timeline chart failed: %s", exc)
        return None


def _chart_file_type_bar(by_type: dict[str, int]) -> Optional[ContentBlock]:
    """Generate a file type distribution bar chart."""
    if not _MPL or not by_type:
        return None
    try:
        sorted_items = sorted(by_type.items(), key=lambda x: x[1], reverse=True)[:15]
        labels = [x[0] for x in sorted_items]
        values = [x[1] for x in sorted_items]
        fig, ax = plt.subplots(figsize=(8, 3.5))
        bars = ax.barh(labels, values, color="#2471A3", alpha=0.8)
        ax.set_xlabel("Count", fontsize=8)
        ax.set_title("File Type Distribution", fontsize=9, fontweight="bold")
        for bar, val in zip(bars, values):
            ax.text(bar.get_width() + 0.2, bar.get_y() + bar.get_height() / 2,
                    str(val), va="center", fontsize=7)
        plt.tight_layout()
        b64 = _savefig_b64(fig, dpi=120)
        return ContentBlock(
            block_type="chart_image",
            data={"data_b64": b64, "label": "Figure 3 — File type distribution",
                  "width_mm": 150},
        )
    except Exception as exc:
        _logger.warning("File type bar chart failed: %s", exc)
        return None


def build_durations_map(results: list, all_evidence_results: list = None) -> dict:
    """Collect module_name -> execution seconds from every available source.

    Reads durations from report-domain results' raw_data (captured by the
    manifest loaders) and from per-evidence pipeline dicts, keeping the longest
    run per module so each module appears once.  This is the single source the
    timing chart consumes, so E.3 and the supporting-charts appendix agree.
    """
    dm: dict[str, float] = {}
    for r in (results or []):
        name = getattr(r, "module_name", "") or ""
        rd = getattr(r, "raw_data", {}) or {}
        dur = rd.get("duration_seconds")
        if not dur:
            dur = (rd.get("statistics", {}) or {}).get("duration_seconds", 0)
        try:
            dur = float(dur or 0)
        except (TypeError, ValueError):
            dur = 0.0
        if name and dur > 0:
            dm[name] = max(dm.get(name, 0.0), dur)
    for ev in (all_evidence_results or []):
        for r in ev.get("module_results", []):
            name = r.get("module_name") or r.get("module") or ""
            try:
                dur = float(r.get("duration_seconds") or 0)
            except (TypeError, ValueError):
                dur = 0.0
            if name and dur > 0:
                dm[name] = max(dm.get(name, 0.0), dur)
    return dm


def _chart_module_timing(durations_map: dict) -> Optional[ContentBlock]:
    """Horizontal bar of module execution times from a name->seconds map.

    The single canonical timing-chart generator: both the charts appendix and
    the supporting-charts section call this so the chart is produced from one
    code path and never diverges into a 'chart not available' placeholder.
    """
    if not _MPL or not durations_map:
        return None
    timed = [(n, d) for n, d in durations_map.items() if d and d > 0]
    if not timed:
        return None
    timed.sort(key=lambda x: x[1], reverse=True)
    try:
        names = [str(t[0])[:22] for t in timed[:15]]
        values = [t[1] for t in timed[:15]]
        fig, ax = plt.subplots(figsize=(8, max(3, len(names) * 0.35)))
        bars = ax.barh(names, values, color="#2980B9", alpha=0.85)
        ax.set_xlabel("Seconds", fontsize=8)
        ax.set_title("Module Execution Times", fontsize=9, fontweight="bold")
        ax.invert_yaxis()
        for bar, val in zip(bars, values):
            ax.text(bar.get_width() + 0.2, bar.get_y() + bar.get_height() / 2,
                    f"{val:.1f}", va="center", fontsize=7)
        plt.tight_layout()
        b64 = _savefig_b64(fig, dpi=120)
        return ContentBlock(
            block_type="chart_image",
            data={"data_b64": b64,
                  "label": "Module execution times in seconds", "width_mm": 150},
        )
    except Exception as exc:
        _logger.warning("Module timing chart failed: %s", exc)
        return None


def _chart_timeline_from_files(file_listing: list) -> Optional[ContentBlock]:
    """Generate a year-based timeline bar chart from raw file listing dicts."""
    if not _MPL or not file_listing:
        return None
    try:
        from collections import Counter
        years = []
        for f in file_listing:
            for ts_field in ("modified", "created", "accessed"):
                raw = f.get(ts_field, "")
                if raw and len(str(raw)) >= 4:
                    try:
                        years.append(int(str(raw)[:4]))
                        break
                    except ValueError:
                        pass
        if not years:
            return None
        year_counts = Counter(y for y in years if 1990 <= y <= 2030)
        if not year_counts:
            return None
        sorted_years = sorted(year_counts.keys())
        values = [year_counts[y] for y in sorted_years]
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.bar([str(y) for y in sorted_years], values, color="#27AE60", alpha=0.8)
        ax.set_xlabel("Year", fontsize=8)
        ax.set_ylabel("File Count", fontsize=8)
        ax.set_title("File System Timeline (by Year)", fontsize=9, fontweight="bold")
        ax.grid(axis="y", linestyle="--", alpha=0.4)
        plt.xticks(rotation=45, ha="right", fontsize=7)
        plt.tight_layout()
        b64 = _savefig_b64(fig, dpi=120)
        return ContentBlock(
            block_type="chart_image",
            data={"data_b64": b64, "label": "Figure — File system timeline by year",
                  "width_mm": 150},
        )
    except Exception as exc:
        _logger.warning("Timeline from file listing chart failed: %s", exc)
        if _MPL:
            try:
                plt.close("all")
            except Exception:
                pass
        return None


# ---------------------------------------------------------------------------
# Individual manifest loaders
# ---------------------------------------------------------------------------

def _load_disk_analysis(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """
    Load a disk_analysis.json produced by tools/analyze_image.py.

    Expected keys: module, case_id, generated_at, image_path, image_sha256,
    image_md5, image_size_bytes, partition_table, ntfs_info,
    file_listing, strings_ioc, findings[{type, severity, description, ...}]
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    raw_data: dict[str, Any] = {}

    # Volume info for report_sections.build_file_system_analysis
    partitions = data.get("partition_table", [])
    volume_info = []
    for i, part in enumerate(partitions):
        volume_info.append({"label": f"Partition {i}", "value": str(part)})
    ntfs = data.get("ntfs_info", {})
    if ntfs:
        for k, v in ntfs.items():
            volume_info.append({"label": k, "value": str(v)})

    raw_data["volume_info"] = volume_info

    # File statistics
    file_listing = data.get("file_listing", [])
    deleted = [f for f in file_listing if f.get("deleted")]
    raw_data["file_stats"] = {
        "total_files": len(file_listing),
        "allocated":   len(file_listing) - len(deleted),
        "deleted":     len(deleted),
        "recovered":   0,
    }

    # Notable files table
    notable_files = []
    for entry in file_listing[:200]:
        notable_files.append({
            "path":     entry.get("path", ""),
            "size":     str(entry.get("size_bytes", "")),
            "created":  entry.get("created", ""),
            "modified": entry.get("modified", ""),
            "accessed": entry.get("accessed", ""),
            "hash":     entry.get("sha256", "")[:16] + "…" if entry.get("sha256") else "",
        })
    raw_data["notable_files"] = notable_files

    # File type distribution chart
    by_type: dict[str, int] = {}
    for entry in file_listing:
        ext = entry.get("extension", "unknown") or "unknown"
        by_type[ext] = by_type.get(ext, 0) + 1
    chart = _chart_file_type_bar(by_type)
    if chart:
        raw_data["_chart_file_type"] = chart

    # IOC / string findings
    ioc_data = data.get("strings_ioc", {})
    fid_counter = 1
    for category, matches in ioc_data.items():
        if not matches:
            continue
        sev = FindingSeverity.MEDIUM if category in ("url", "email", "bitcoin", "ethereum") \
              else FindingSeverity.LOW
        for match in (matches[:10] if isinstance(matches, list) else list(matches)[:10]):
            findings.append(FindingItem(
                finding_id=f"STR-{fid_counter:04d}",
                title=f"String IOC: {category.upper()} match",
                description=(
                    f"String extraction identified a {category.upper()} indicator "
                    f"in the disk image: {str(match)[:200]}"
                ),
                severity=sev,
                category="IOC / String Match",
                artefact_location=str(path.parent),
                evidence_reference="",  # attribution assigned by _apply_evidence_index
                raw_data=str(match)[:300],
                recommendation=(
                    "Investigate the identified indicator to determine whether "
                    "it represents malicious activity or legitimate use."
                ),
            ))
            fid_counter += 1

    # Raw findings list (from the analyzer's own structured findings)
    for raw_f in data.get("findings", []):
        sev_raw = raw_f.get("severity", "medium")
        ts = _parse_ts(raw_f.get("timestamp"))
        findings.append(FindingItem(
            finding_id=f"DA-{fid_counter:04d}",
            title=raw_f.get("type", "Disk Finding"),
            description=raw_f.get("description", ""),
            severity=_sev(sev_raw),
            category=raw_f.get("category", "Disk Analysis"),
            artefact_location=raw_f.get("location", str(path.parent)),
            timestamp=ts,
            evidence_reference="",  # attribution assigned by _apply_evidence_index
            raw_data=raw_f.get("raw_data", ""),
            recommendation=raw_f.get("recommendation", ""),
        ))
        if ts:
            timeline.append(TimelineEntry(
                timestamp=ts,
                event_description=raw_f.get("description", ""),
                source="Disk Analysis",
            ))
        fid_counter += 1

    # Build timeline from file timestamps
    for entry in file_listing:
        for ts_key in ("created", "modified"):
            ts = _parse_ts(entry.get(ts_key))
            if ts:
                timeline.append(TimelineEntry(
                    timestamp=ts,
                    event_description=(
                        f"File {'created' if ts_key == 'created' else 'modified'}: "
                        f"{entry.get('path', 'unknown')}"
                    ),
                    source="File System",
                ))

    # Image hash info for evidence section
    raw_data["image_info"] = {
        "path":   data.get("image_path", ""),
        "sha256": data.get("image_sha256", ""),
        "md5":    data.get("image_md5", ""),
        "size":   data.get("image_size_bytes", 0),
    }

    # IOC list for Appendix C
    ioc_list = []
    for category, matches in ioc_data.items():
        for m in (matches[:50] if isinstance(matches, list) else list(matches)[:50]):
            ioc_list.append({
                "type": category,
                "value": str(m),
                "matches_found": 1,
                "first_seen": "",
                "last_seen": "",
            })
    raw_data["iocs"] = ioc_list

    return ModuleResult(
        module_name="Disk Image Analysis",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if findings or file_listing else "partial",
        findings=findings,
        timeline_entries=timeline,
        raw_data=raw_data,
        artefacts_examined=len(file_listing),
        artefacts_relevant=len(findings),
        error_message="" if findings or file_listing else "No files found in disk image.",
    )


def _load_artifacts_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load artifacts_manifest.json from artifact_extractor."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    fid = 1

    files = data.get("files", data.get("notable_files", []))
    by_type: dict[str, int] = {}

    for rec in files:
        ext = rec.get("extension", rec.get("mime_type", "unknown")) or "unknown"
        by_type[ext] = by_type.get(ext, 0) + 1

        sev = FindingSeverity.HIGH if ext.lower() in ("exe", "dll", "ps1", "bat", "cmd") \
              else (FindingSeverity.MEDIUM if ext.lower() in ("pdf", "doc", "docx", "xls", "zip") \
              else FindingSeverity.LOW)

        ts = _parse_ts(rec.get("modified") or rec.get("created"))

        findings.append(FindingItem(
            finding_id=f"ART-{fid:04d}",
            title=f"Extracted artefact: {rec.get('file_name', rec.get('name', 'unknown'))}",
            description=(
                f"Artefact extracted from evidence image: "
                f"{rec.get('full_path', rec.get('path', 'unknown'))}\n"
                f"Size: {rec.get('size_bytes', 'N/A')} bytes  "
                f"SHA-256: {rec.get('sha256', 'N/A')}"
            ),
            severity=sev,
            category="Extracted Artefact",
            artefact_location=rec.get("full_path", rec.get("path", str(path.parent))),
            timestamp=ts,
            evidence_reference="",  # attribution assigned by _apply_evidence_index
            raw_data=f"SHA-256: {rec.get('sha256', 'N/A')}",
            recommendation=(
                "Review the extracted file for forensic significance."
                if sev in (FindingSeverity.HIGH, FindingSeverity.MEDIUM)
                else ""
            ),
        ))
        if ts:
            timeline.append(TimelineEntry(
                timestamp=ts,
                event_description=f"Artefact: {rec.get('path', 'unknown')}",
                source="Artifact Extractor",
            ))
        fid += 1

    # Registry hive results
    hives_examined: list[str] = []
    user_accounts: list[dict] = []
    usb_devices: list[dict] = []
    run_keys: list[dict] = []

    for rec in files:
        if rec.get("extension", "").upper() in ("SAM", "SECURITY", "SOFTWARE", "SYSTEM", "NTUSER"):
            hive_path = rec.get("full_path", rec.get("path", ""))
            hives_examined.append(hive_path)
            # Registry parse results may be in the rec itself
            reg_data = rec.get("registry_parsed", {})
            if reg_data:
                for user in reg_data.get("sam_users", []):
                    user_accounts.append({
                        "username": user.get("name", ""),
                        "sid":      user.get("rid", ""),
                        "last_login": user.get("last_login", "N/A"),
                    })
                for usb in reg_data.get("usb_history", []):
                    usb_devices.append({
                        "device_name":    str(usb),
                        "serial":         "",
                        "last_connected": "",
                        "drive_letter":   "",
                    })

    raw_data: dict[str, Any] = {
        "by_type": by_type,
        "hives_examined": hives_examined,
        "user_accounts":  user_accounts,
        "usb_devices":    usb_devices,
        "run_keys":       run_keys,
    }

    chart = _chart_file_type_bar(by_type)
    if chart:
        raw_data["_chart_types"] = chart

    total = data.get("total_files", len(files))
    return ModuleResult(
        module_name="Artifact Extractor",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success",
        findings=findings,
        timeline_entries=timeline,
        raw_data=raw_data,
        artefacts_examined=total,
        artefacts_relevant=len(findings),
    )


def _fmt_bytes(n: int) -> str:
    """Convert byte count to human-readable string."""
    n = max(0, n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _carving_summary_text(
    tool: str, total: int, total_bytes: int, type_summary: str, caveat: str
) -> tuple[str, str]:
    """Build an honest carving title/description.

    When the carver over-carved (carved volume exceeds the source image size,
    signalled by a non-empty caveat), the byte total is not presented as
    recovered data: the title and description report the file COUNT and label
    the volume an overlapping-candidate carving artefact.
    """
    if caveat:
        title = f"File Carving ({tool}): {total} candidate files (volume is a carving artefact)"
        desc = (
            f"{tool} carved {total} candidate files from unallocated/slack space. "
            f"File type breakdown (top 10): {type_summary}. {caveat}"
        )
    else:
        title = f"File Carving ({tool}): {total} files recovered ({_fmt_bytes(total_bytes)})"
        desc = (
            f"{tool} recovered {total} files from unallocated/slack space "
            f"totalling {_fmt_bytes(total_bytes)}. "
            f"File type breakdown (top 10): {type_summary}."
        )
    # Phase 2b — collapse any "<n> EXE, <n> BMP" per-type enumeration in the
    # carver description (the one banned framing these curated descriptions still
    # emit).  The byte-volume honesty here is already handled above: a
    # within-bounds carve keeps its real volume, an over-carve is replaced by the
    # count + artefact caveat.  The caveat text is deliberately not passed
    # through the sentence-level validator, which would corrupt it.
    try:
        from core.report_ai import strip_filetype_enumeration
        desc = strip_filetype_enumeration(desc)
    except Exception:
        pass
    return title, desc


def _load_scalpel_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load a raw Scalpel manifest as candidate-only diagnostic data.

    Raw carver output is never an accepted evidentiary finding. The canonical
    module_result.json remains the only source for report findings and counts.
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    files = list(data.get("files") or [])
    return ModuleResult(
        module_name="Scalpel File Carver", module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="partial" if files else "success", findings=[],
        raw_data={"candidate_only": True, "candidate_count": len(files),
                  "manifest_path": str(path), "volume_caveat": data.get("volume_caveat", "")},
        artefacts_examined=len(files), artefacts_relevant=0,
        error_message=("Raw carving candidates retained for examiner review; no candidate was promoted "
                       "without structural, allocation and duplicate validation." if files else ""),
    )


def _load_foremost_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load a raw Foremost manifest as candidate-only diagnostic data."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    files = list(data.get("files") or [])
    return ModuleResult(
        module_name="Foremost File Carver", module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="partial" if files else "success", findings=[],
        raw_data={"candidate_only": True, "candidate_count": len(files),
                  "manifest_path": str(path), "volume_caveat": data.get("volume_caveat", "")},
        artefacts_examined=len(files), artefacts_relevant=0,
        error_message=("Raw carving candidates retained for examiner review; no candidate was promoted "
                       "without structural, allocation and duplicate validation." if files else ""),
    )


def _load_strings_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load strings_manifest.json from string_extractor."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    fid = 1
    ioc_list: list[dict] = []

    for category, matches in data.get("ioc_summary", {}).items():
        if not matches:
            continue
        sev = FindingSeverity.MEDIUM if category in ("url", "email", "bitcoin", "ethereum") \
              else FindingSeverity.LOW
        for m in (matches[:10] if isinstance(matches, list) else []):
            findings.append(FindingItem(
                finding_id=f"STR-{fid:04d}",
                title=f"IOC: {category.upper()} — {str(m)[:60]}",
                description=(
                    f"String extraction identified a {category.upper()} indicator "
                    f"in the evidence: {str(m)[:300]}"
                ),
                severity=sev,
                category="IOC / String",
                artefact_location=str(path.parent),
                evidence_reference="",  # attribution assigned by _apply_evidence_index
                raw_data=str(m)[:300],
                recommendation="Verify the indicator against threat intelligence databases.",
            ))
            ioc_list.append({"type": category, "value": str(m), "matches_found": 1,
                             "first_seen": "", "last_seen": ""})
            fid += 1

    return ModuleResult(
        module_name="String / IOC Extractor",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if findings else "partial",
        findings=findings,
        raw_data={"iocs": ioc_list, "ioc_summary": data.get("ioc_summary", {})},
        artefacts_examined=data.get("total_strings", 0),
        artefacts_relevant=len(findings),
    )


def _load_recovery_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load legacy or native ``recovery_manifest.json`` safely.

    The native recovery path writes ``deleted_records`` plus ``recovered_files``;
    older external-tool manifests use ``files`` or ``entries``.  This loader
    normalises all supported forms without turning a successful native recovery
    into the contradictory message "No deleted files were recovered".
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    records = data.get("deleted_records")
    if not isinstance(records, list):
        records = data.get("files")
    if not isinstance(records, list):
        records = data.get("entries")
    if not isinstance(records, list):
        records = []

    recovered_paths = [str(v) for v in (data.get("recovered_files") or []) if v]
    recovered_by_name = {Path(v).name.lower(): v for v in recovered_paths}

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    recovered_count = 0

    for fid, raw in enumerate(records, start=1):
        rec = raw if isinstance(raw, dict) else {"original_path": str(raw)}
        original = str(
            rec.get("original_path") or rec.get("path") or rec.get("name") or "unknown"
        )
        extracted = str(
            rec.get("extracted_path") or rec.get("artifact_path") or
            recovered_by_name.get(Path(original).name.lower(), "")
        )
        status = str(
            rec.get("recovery_status") or rec.get("status") or
            ("recovered" if extracted else "metadata_only")
        ).lower()
        recovered = status in {"recovered", "complete", "ok", "success"} or bool(extracted)
        if recovered:
            recovered_count += 1

        size = rec.get("size_bytes", rec.get("size", "N/A"))
        sha256 = str(rec.get("sha256") or "")
        ts = _parse_ts(rec.get("mtime") or rec.get("modified") or rec.get("ctime"))
        caveats = rec.get("caveats") or []
        if isinstance(caveats, str):
            caveats = [caveats]

        if recovered:
            title = f"Deleted file recovered: {original}"
            description = (
                "A filesystem record marked deleted was recovered from its recorded "
                f"cluster chain. Original path: {original}; size: {size} bytes; "
                f"recovery status: {status}."
            )
            if sha256:
                description += f" Recovered-content SHA-256: {sha256}."
            severity = FindingSeverity.MEDIUM
        else:
            title = f"Deleted filesystem record: {original}"
            description = (
                "A filesystem record marked deleted was identified, but reliable file "
                f"content was not recovered. Original path: {original}; size: {size} "
                f"bytes; status: {status}."
            )
            if caveats:
                description += " Caveat: " + "; ".join(str(c) for c in caveats[:4])
            severity = FindingSeverity.LOW

        findings.append(FindingItem(
            finding_id=f"DEL-{fid:04d}",
            title=title,
            description=description,
            severity=severity,
            category="Deleted File Recovery",
            artefact_location=extracted or original,
            timestamp=ts,
            evidence_reference="",
            raw_data=json.dumps({
                "original_path": original,
                "extracted_path": extracted,
                "status": status,
                "size_bytes": size,
                "sha256": sha256,
                "caveats": caveats,
            }, ensure_ascii=True, default=str),
            recommendation=(
                "Preserve and hash the recovered content, verify its file structure, "
                "and assess its relevance alongside other case artefacts. The deleted "
                "state does not establish who deleted it or why."
            ),
        ))
        if ts:
            timeline.append(TimelineEntry(
                timestamp=ts,
                event_description=f"Filesystem record marked deleted: {original}",
                source="Deleted File Recovery",
            ))

    outcome = str(data.get("execution_outcome") or "")
    if records:
        status = "success" if recovered_count == len(records) else "partial"
        error = "" if recovered_count else (
            "Deleted records were identified, but no record yielded reliable recovered content."
        )
    elif outcome == "ran_found_nothing":
        status = "success"
        error = "Native deleted-record scan completed and found no deleted records."
    else:
        status = "partial"
        error = "Recovery manifest contained no deleted-record entries."

    return ModuleResult(
        module_name="Deleted File Recovery",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status=status,
        findings=findings,
        timeline_entries=timeline,
        raw_data={
            "execution_outcome": outcome or ("ran_found_x" if records else "ran_found_nothing"),
            "recovery_source": data.get("recovery_source", "unspecified"),
            "deleted_records": records,
            "recovered_files": recovered_paths,
            "deleted_record_count": len(records),
            "recovered_count": recovered_count,
        },
        artefacts_examined=len(records),
        artefacts_relevant=len(findings),
        error_message=error,
    )

def _load_generic_module_result(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load the standardized ``module_result.json`` written by the orchestrator.

    The standardized result is authoritative for execution state, H2 assurance
    verdicts, summary text and retained findings.  Older versions discarded
    ``class_results`` and converted SKIPPED outcomes to FAILED while loading the
    report, which caused missing-corpus modules to disappear from Section 7 and
    created a misleading all-success coverage table.
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    if "module_name" not in data:
        return None

    findings: list[FindingItem] = []
    for index, raw_f in enumerate(data.get("findings", []) or [], start=1):
        if not isinstance(raw_f, dict):
            continue
        ts = _parse_ts(raw_f.get("timestamp"))
        sev_raw = raw_f.get("severity", "low")
        meta = raw_f.get("metadata", {}) or {}
        evidence_reference = raw_f.get("evidence_reference") or ""
        findings.append(FindingItem(
            finding_id=str(raw_f.get("finding_id") or f"MOD-{index:04d}"),
            title=(
                raw_f.get("title")
                or str(raw_f.get("finding_type", "Finding")).replace("_", " ").title()
            ),
            description=str(raw_f.get("description", "") or ""),
            severity=_sev(sev_raw),
            category=str(raw_f.get("category") or raw_f.get("finding_type", "General")).replace("_", " ").title(),
            artefact_location=str(
                raw_f.get("artefact_location")
                or raw_f.get("evidence_path")
                or raw_f.get("artifact_path")
                or ""
            ),
            timestamp=ts,
            evidence_reference=evidence_reference,
            raw_data=json.dumps(meta, default=str)[:2000] if meta else "",
            finding_type=str(raw_f.get("finding_type") or ""),
            metadata=dict(meta) if isinstance(meta, dict) else {},
        ))

    status_raw = str(data.get("status") or "failed").strip().lower()
    if status_raw in {"completed", "success", "pass_complete"}:
        status = "success"
    elif status_raw == "completed_with_fallback":
        # Legacy input: a fallback cannot make the named module complete.
        status = "partial"
    elif status_raw in {"partial", "incomplete"}:
        status = "partial"
    elif status_raw in {"not_applicable", "out_of_scope", "verify_later", "skipped", "degraded", "indeterminate"}:
        status = status_raw
    elif status_raw in {"failed_isolated", "failed", "error", "import_failed", "failed_offset"}:
        status = "failed_isolated"
    else:
        status = "failed_isolated"

    try:
        from modules._base import (
            AssuranceVerdict as _AV,
            ClassResult as _ClassResult,
            Locus as _Locus,
            SkipReason as _SR,
        )
        _locus_values = {e.value for e in _Locus}
        _verdict_values = {e.value for e in _AV}
        _skip_values = {e.value for e in _SR}
        class_results = []
        for raw_cr in data.get("class_results", []) or []:
            if not isinstance(raw_cr, dict):
                continue
            locus_raw = str(raw_cr.get("locus") or "OTHER")
            verdict_raw = str(raw_cr.get("verdict") or "INDETERMINATE")
            skip_raw = raw_cr.get("skip_reason")
            class_results.append(_ClassResult(
                locus=_Locus(locus_raw) if locus_raw in _locus_values else _Locus.OTHER,
                artefact_class=str(raw_cr.get("artefact_class") or data.get("module_name") or "Module Outcome"),
                verdict=_AV(verdict_raw) if verdict_raw in _verdict_values else _AV.INDETERMINATE,
                skip_reason=_SR(str(skip_raw)) if skip_raw and str(skip_raw) in _skip_values else None,
                count=int(raw_cr.get("count", 0) or 0),
                notes=str(raw_cr.get("notes", "") or ""),
                summarised=bool(raw_cr.get("summarised", False)),
            ))
    except Exception as exc:
        logger.debug("Could not reconstruct class_results from %s: %s", path, exc)
        class_results = []

    stats = data.get("statistics", {}) or {}
    errors_raw = data.get("errors", []) or []
    if isinstance(errors_raw, str):
        errors = [errors_raw]
    else:
        errors = [str(item) for item in errors_raw if str(item)]
    direct_error = str(data.get("error") or data.get("error_message") or "")
    if direct_error and direct_error not in errors:
        errors.append(direct_error)

    execution_outcome = str(
        data.get("execution_outcome")
        or stats.get("execution_outcome")
        or ""
    ).strip()
    if not execution_outcome:
        if status in {"not_applicable", "out_of_scope", "verify_later", "skipped", "failed", "failed_isolated"}:
            execution_outcome = "did_not_run"
        elif status in {"partial", "degraded", "indeterminate"}:
            execution_outcome = "ran_with_caveat"
        elif findings:
            execution_outcome = "ran_found_x"
        else:
            execution_outcome = "ran_found_nothing"

    # The standard module result stores scope counters under several
    # versioned locations.  Resolve one same-unit object counter in a strict
    # priority order; never substitute accepted findings for examined objects
    # and never take the maximum of heterogeneous counters.
    module_stats = stats.get("module_statistics") or {}
    if not isinstance(module_stats, dict):
        module_stats = {}

    examined_candidates = [
        data.get("artefacts_examined"),
        data.get("artifacts_examined"),
        module_stats.get("objects_examined"),
        stats.get("supported_objects_processed"),
        stats.get("records_processed"),
        stats.get("files_examined"),
        stats.get("objects_examined"),
        stats.get("records_examined"),
        stats.get("documents_discovered"),
        stats.get("sources_processed"),
        stats.get("total_files"),
        stats.get("total_carved_files"),
    ]
    examined_i = 0
    for examined in examined_candidates:
        try:
            value = int(examined or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            examined_i = value
            break

    candidate_records: list[dict[str, Any]] = []
    candidate_path = path.with_name("candidate_observations.json")
    if candidate_path.is_file():
        try:
            candidate_payload = json.loads(candidate_path.read_text(encoding="utf-8", errors="replace"))
            for item in candidate_payload.get("candidates", []) or []:
                if not isinstance(item, dict):
                    continue
                meta = dict(item.get("metadata") or {})
                candidate_records.append({
                    "finding_type": str(item.get("finding_type") or "Candidate Observation"),
                    "description": str(item.get("description") or ""),
                    "method": str(meta.get("candidate_method") or meta.get("validation_method") or "candidate generator"),
                    "reason": str(meta.get("candidate_reason") or meta.get("semantic_limit") or "independent deterministic validation not completed"),
                    "source": str(meta.get("provenance_source_path") or meta.get("source_file") or meta.get("file_path") or meta.get("image_file") or ""),
                })
        except Exception as exc:
            logger.debug("Could not load candidate observations from %s: %s", candidate_path, exc)

    if candidate_records and not findings and execution_outcome == "ran_found_nothing" and status == "success":
        execution_outcome = "ran_with_caveat"

    raw_data = {
        "_source": "module_result_json",
        "statistics": stats,
        "summary": str(data.get("summary", "") or ""),
        "duration_seconds": data.get("duration_seconds", 0),
        "output_dir": str(data.get("output_dir", "") or ""),
        "candidate_observations": candidate_records,
        "candidate_observation_count": len(candidate_records),
        "candidate_policy": (
            "Candidate generators remain available, but candidate output is not an evidentiary finding "
            "unless an independent deterministic validator confirms the precise claim."
        ),
    }
    ts = _parse_ts(data.get("end_time") or data.get("start_time"))
    return ModuleResult(
        module_name=str(data.get("module_name") or path.stem),
        module_version=str(data.get("module_version") or "1.0"),
        run_timestamp=ts or _utc_now(),
        status=status,
        findings=findings,
        raw_data=raw_data,
        error_message="; ".join(dict.fromkeys(errors)),
        artefacts_examined=examined_i,
        artefacts_relevant=int(data.get("artefacts_relevant", len(findings)) or len(findings)),
        terminal_output=str(data.get("terminal_output", "") or ""),
        class_results=class_results,
        execution_outcome=execution_outcome,
        summary=str(data.get("summary", "") or ""),
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# New module manifest loaders
# ---------------------------------------------------------------------------

def _load_registry_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load registry_manifest.json from windows_registry_analyzer."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    fid = 1
    results = data.get("results", {})

    # User accounts table.  Live accounts are stamped ACTIVE; recovered deleted
    # accounts are merged in with a DELETED state so the body table shows the
    # full picture, and each deleted account is also surfaced as a finding a
    # reader sees (a deleted SAM account is a real anti-forensic signal).
    def _acct_identity(acc: dict) -> str:
        # Resolve identity from whatever the record still holds: name if
        # present, else the RID — decided from the record, never assumed.
        name = str(acc.get("username", "") or "").strip()
        return name or f"RID {acc.get('rid', '?')}"

    live_accounts = results.get("user_accounts", [])
    body_accounts: list[dict] = []
    for acc in live_accounts[:50]:
        body_accounts.append({**acc, "state": "ACTIVE"})
        findings.append(FindingItem(
            finding_id=f"REG-{fid:04d}",
            title=f"User Account: {_acct_identity(acc)}",
            description=(
                f"Local user account found in SAM hive: '{_acct_identity(acc)}'. "
                f"Creation time: {acc.get('creation_time','N/A')}. "
                f"SAM key last-write: {acc.get('last_write','N/A')}. "
                f"Last login: {acc.get('last_login','N/A')}."
            ),
            severity=FindingSeverity.LOW,
            category="User Account",
            artefact_location="SAM hive",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    deleted_accounts = results.get("deleted_accounts", [])
    for acc in deleted_accounts[:50]:
        body_accounts.append({**acc, "state": "DELETED"})
        findings.append(FindingItem(
            finding_id=f"REG-{fid:04d}",
            title=f"DELETED User Account: {_acct_identity(acc)}",
            description=(
                f"A deleted local user account was recovered from unallocated "
                f"SAM hive space: '{_acct_identity(acc)}' (state: DELETED). "
                f"SAM key last-write: {acc.get('last_write','N/A')}. "
                "Deletion of a user account can be an anti-forensic act to remove "
                "evidence of an identity used on the system."
            ),
            severity=FindingSeverity.HIGH,
            category="Deleted User Account",
            artefact_location="SAM hive (unallocated)",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1
    user_accounts = body_accounts

    # Cover accounts (CRITICAL)
    for ca in results.get("cover_accounts", []):
        findings.append(FindingItem(
            finding_id=f"REG-{fid:04d}",
            title=f"COVER ACCOUNT: {ca.get('account_a')} / {ca.get('account_b')}",
            description=(
                f"Cover account detected: '{ca.get('account_a')}' and "
                f"'{ca.get('account_b')}' created within "
                f"{ca.get('delta_seconds',0):.0f} seconds. "
                "Accounts created <120s apart indicate false identity creation."
            ),
            severity=FindingSeverity.CRITICAL,
            category="Cover Account",
            artefact_location="SAM hive",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # USB devices
    usb_devices = results.get("usb_devices", [])
    for usb in usb_devices[:20]:
        findings.append(FindingItem(
            finding_id=f"REG-{fid:04d}",
            title=f"USB Device: {usb.get('friendly_name','?')}",
            description=(
                f"USB storage device in USBSTOR registry: "
                f"{usb.get('friendly_name','?')} — {usb.get('device_class','?')}"
            ),
            severity=FindingSeverity.HIGH,
            category="USB History",
            artefact_location="SYSTEM hive — USBSTOR",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # Suspicious software
    for prog in results.get("suspicious_software", []):
        name = prog.get("displayname") or prog.get("key_name", "?")
        findings.append(FindingItem(
            finding_id=f"REG-{fid:04d}",
            title=f"Suspicious Software: {name}",
            description=(
                f"Anti-forensic/suspicious software: '{name}'. "
                f"Publisher: {prog.get('publisher','N/A')}. "
                "Wiping, encryption, or privacy tool detected."
            ),
            severity=FindingSeverity.HIGH,
            category="Suspicious Software",
            artefact_location="SOFTWARE hive — Uninstall",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    os_info = results.get("os_info", {})
    comp_name = results.get("computer_name", "")

    raw_data: dict[str, Any] = {
        "user_accounts":    user_accounts[:30],
        "cover_accounts":   results.get("cover_accounts", []),
        "usb_devices":      usb_devices[:30],
        "network_shares":   results.get("network_shares", [])[:20],
        "userassist":       results.get("userassist", {}),
        "recentdocs":       results.get("recentdocs", {}),
        "opensavemru":      results.get("opensavemru", {}),
        "typedurlsmru":     results.get("typedurlsmru", [])[:30],
        "shellbags":        results.get("shellbags", [])[:30],
        "installed_programs": results.get("installed_programs", [])[:50],
        "suspicious_software": results.get("suspicious_software", []),
        "os_info":          os_info,
        "computer_name":    comp_name,
        "timezone":         results.get("timezone", ""),
        "hives_parsed":     results.get("hives_parsed", []),
    }

    # Chart: user accounts table
    if user_accounts:
        rows = [[a.get("username","?"), str(a.get("creation_time","N/A"))[:19],
                 str(a.get("last_login","N/A"))[:19]]
                for a in user_accounts[:15]]
        chart = _chart_table_image(
            "User Account Profile — SAM Hive",
            ["Username", "Account Created", "Last Login"],
            rows, label="User Accounts (SAM Hive)",
        )
        if chart:
            raw_data["_chart_user_accounts"] = chart

    # Chart: USB devices
    if usb_devices:
        rows = [[u.get("device_class","?")[:20], u.get("instance_id","?")[:30],
                 u.get("friendly_name","?")[:40]]
                for u in usb_devices[:15]]
        chart = _chart_table_image(
            "USBSTOR Device History — SYSTEM Hive",
            ["Device Class", "Instance ID", "Friendly Name"],
            rows, label="USB Device History (USBSTOR)",
        )
        if chart:
            raw_data["_chart_usb"] = chart

    # Chart: installed programs
    installed = results.get("installed_programs", [])
    if installed:
        rows = [[p.get("displayname") or p.get("key_name","?"),
                 str(p.get("displayversion","?"))[:15],
                 str(p.get("publisher","?"))[:30]]
                for p in installed[:20]]
        chart = _chart_table_image(
            "Installed Programs — SOFTWARE Hive",
            ["Program Name", "Version", "Publisher"],
            rows, label="Installed Programs",
        )
        if chart:
            raw_data["_chart_installed"] = chart

    return ModuleResult(
        module_name="Windows Registry Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if findings else "partial",
        findings=findings,
        timeline_entries=timeline,
        raw_data=raw_data,
        artefacts_examined=data.get("hives_found", 0),
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_filesystem_deep_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load filesystem_manifest.json from filesystem_deep_analyzer."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    fid = 1

    total_files   = data.get("total_files", 0)
    deleted_files = data.get("deleted_files", 0)
    mismatches    = data.get("mismatches", [])
    ads_list      = data.get("ads_list", [])
    efs_list      = data.get("efs_list", [])
    timeline_top  = data.get("timeline_top50", [])
    pw_files      = data.get("pw_files", [])

    # Magic-byte-vs-extension mismatch findings (shared single-source result).
    # Severity is the category-derived value computed once by signature_check —
    # a benign category (e.g. a renamed image) renders low, an executable under
    # a document extension renders high — never a blanket HIGH.  A legacy record
    # lacking the field is recomputed through the same function, never defaulted.
    from modules.signature_check import _mismatch_severity
    for mm in mismatches[:20]:
        findings.append(FindingItem(
            finding_id=f"FS-{fid:04d}",
            title=f"Extension Mismatch: {mm.get('path','?')[-50:]}",
            description=(
                f"Extension mismatch: declared .{mm.get('declared_ext','?')} "
                f"but magic bytes = {mm.get('detected_mime','?')} "
                f"(expected .{mm.get('expected_ext','?')})."
            ),
            severity=_sev(mm.get("severity")
                          or _mismatch_severity(mm.get("detected_type", ""),
                                                mm.get("declared_ext", ""))),
            category="Extension Mismatch",
            artefact_location=mm.get("path",""),
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # Double-extension filename findings — a distinct signal from the magic-byte
    # mismatch above, rendered under its own label so the two are never conflated.
    for de in data.get("double_extension_list", [])[:20]:
        findings.append(FindingItem(
            finding_id=f"FS-{fid:04d}",
            title=f"Double Extension: {de.get('path','?')[-50:]}",
            description=(
                f"Double-extension filename: '{de.get('name','?')}' declares "
                f".{de.get('declared_ext','?')} with inner extension "
                f"{de.get('inner_ext','?')} — a common obfuscation pattern."
            ),
            severity=FindingSeverity.HIGH,
            category="Double Extension",
            artefact_location=de.get("path",""),
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # ADS findings
    for ads in ads_list[:10]:
        findings.append(FindingItem(
            finding_id=f"FS-{fid:04d}",
            title=f"NTFS ADS: {ads.get('path','?')[-40:]}:{ads.get('stream_name','?')}",
            description=(
                f"Alternate Data Stream: '{ads.get('path','')}:{ads.get('stream_name','')}'. "
                f"Size: {ads.get('size','?')} bytes. ADS can hide data inside legitimate files."
            ),
            severity=FindingSeverity.HIGH,
            category="NTFS ADS",
            artefact_location=ads.get("path",""),
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # EFS finding
    if efs_list:
        findings.append(FindingItem(
            finding_id=f"FS-{fid:04d}",
            title=f"EFS Encrypted Files: {len(efs_list)} file(s)",
            description=(
                f"{len(efs_list)} EFS encrypted file(s) detected. "
                f"Samples: {'; '.join(str(e)[:60] for e in efs_list[:3])}"
            ),
            severity=FindingSeverity.HIGH,
            category="EFS Encryption",
            artefact_location="Filesystem",
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # Timeline entries
    for evt in timeline_top[:50]:
        ts = _parse_ts(evt.get("timestamp",""))
        if ts:
            timeline.append(TimelineEntry(
                timestamp=ts,
                event_description=f"{evt.get('type','MAC')}: {evt.get('path','')}",
                source="File System (mactime)",
            ))

    # Main file system summary finding
    findings.append(FindingItem(
        finding_id=f"FS-{fid:04d}",
        title=f"File System listing: {total_files} entries, {deleted_files} deleted records",
        description=(
            f"Full recursive filesystem listing: {total_files} entries (including traversal and metadata rows), "
            f"{deleted_files} deleted. {len(mismatches)} extension mismatch(es), "
            f"{len(ads_list)} NTFS ADS, {len(efs_list)} EFS files, "
            f"{len(pw_files)} password-protected candidates."
        ),
        severity=FindingSeverity.LOW,
        category="File System Analysis",
        artefact_location="Filesystem",
        evidence_reference="",  # attribution assigned by _apply_evidence_index
    ))

    raw_data: dict[str, Any] = {
        "total_files":   total_files,
        "deleted_files": deleted_files,
        "ext_counts":    data.get("ext_counts", {}),
        "mismatches":    mismatches[:30],
        "ads_list":      ads_list[:20],
        "efs_list":      efs_list[:20],
        "timeline_top50": timeline_top,
        "pw_files":      pw_files[:20],
    }

    # Chart: extension mismatch table
    if mismatches:
        rows = [[mm.get("path","?")[-40:], mm.get("declared_ext","?"),
                 mm.get("detected_mime","?")[:30], mm.get("expected_ext","?")]
                for mm in mismatches[:15]]
        chart = _chart_table_image(
            "Extension Mismatch Detection — fls Analysis",
            ["File Path", "Declared Ext", "True MIME Type", "Expected Ext"],
            rows, label="Extension Mismatches (fls output)",
        )
        if chart:
            raw_data["_chart_mismatches"] = chart

    # Chart: timeline top 20 events
    if timeline_top:
        rows = [[evt.get("timestamp","?")[:19], evt.get("type","?")[:10],
                 evt.get("path","?")[-50:]]
                for evt in timeline_top[:20]]
        chart = _chart_table_image(
            "MAC Timeline — Top 20 Events",
            ["Timestamp", "Event Type", "File Path"],
            rows, label="MAC Timeline (mactime output)",
        )
        if chart:
            raw_data["_chart_timeline_top20"] = chart

    return ModuleResult(
        module_name="File System Deep Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if total_files > 0 else "partial",
        findings=findings,
        timeline_entries=timeline,
        raw_data=raw_data,
        artefacts_examined=total_files,
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_email_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load email_manifest.json from email_communications_analyzer."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    fid = 1

    for email_rec in data.get("emails_summary", []):
        senders = email_rec.get("senders", [])
        subjects = email_rec.get("subjects", [])
        count = email_rec.get("message_count", 0)
        fmt = email_rec.get("format", "?").upper()
        if count > 0:
            findings.append(FindingItem(
                finding_id=f"EMAIL-{fid:04d}",
                title=f"Email Archive ({fmt}): {count} messages",
                description=(
                    f"Email archive '{email_rec.get('path','?')}' ({fmt}). "
                    f"{count} message(s). "
                    f"Senders: {'; '.join(senders[:3])}. "
                    f"Subjects: {'; '.join(str(s)[:50] for s in subjects[:3])}."
                ),
                severity=FindingSeverity.MEDIUM,
                category="Email Evidence",
                artefact_location=email_rec.get("path",""),
                evidence_reference="",  # attribution assigned by _apply_evidence_index
            ))
            fid += 1

    for im_rec in data.get("im_summary", []):
        lc = im_rec.get("line_count", 0)
        if lc > 0:
            findings.append(FindingItem(
                finding_id=f"EMAIL-{fid:04d}",
                title=f"IM Chat Log ({im_rec.get('im_type','?')}): {lc} lines",
                description=(
                    f"IM log '{im_rec.get('path','?')}' ({im_rec.get('im_type','?')}). "
                    f"{lc} lines. "
                    + (
                        f"Recorded screen-name strings: {'; '.join(im_rec.get('participants',[])[:5])}. "
                        "These strings are not independently verified identities."
                        if im_rec.get("participants") else
                        "No participant screen-name strings were parsed from the artefact."
                    )
                ),
                severity=FindingSeverity.MEDIUM,
                category="Instant Messenger",
                artefact_location=im_rec.get("path",""),
                evidence_reference="",  # attribution assigned by _apply_evidence_index
            ))
            fid += 1

    raw_data: dict[str, Any] = {
        "emails_summary": data.get("emails_summary", []),
        "im_summary":     data.get("im_summary", []),
    }

    # Chart: email stores table
    emails = data.get("emails_summary", [])
    if emails:
        rows = [[e.get("format","?"), e.get("path","?")[-40:],
                 str(e.get("message_count",0)),
                 "; ".join(e.get("senders",[])[:2])[:50]]
                for e in emails[:10]]
        chart = _chart_table_image(
            "Email Archives Found",
            ["Format", "Path", "Messages", "Senders"],
            rows, label="Email Archives (fls + readpst output)",
        )
        if chart:
            raw_data["_chart_emails"] = chart

    return ModuleResult(
        module_name="Email & Communications Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if findings else "partial",
        findings=findings,
        raw_data=raw_data,
        artefacts_examined=data.get("email_files_found", 0),
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_browser_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load browser_manifest.json from browser_history_analyzer."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    timeline: list[TimelineEntry] = []
    fid = 1

    all_history = data.get("history", [])
    suspicious = [h for h in all_history
                  if any(p in h.get("url","").lower()
                          for p in ("onion", "bitcoin", "vpn", "ccleaner", "bleachbit",
                                    "pastebin", "mega.nz", "steghide"))]

    for h in all_history[:30]:
        ts = _parse_ts(h.get("visit_time",""))
        sev = (FindingSeverity.HIGH
               if any(p in h.get("url","").lower()
                      for p in ("onion", "bitcoin", "steghide", "ccleaner"))
               else FindingSeverity.LOW)
        findings.append(FindingItem(
            finding_id=f"BH-{fid:04d}",
            title=f"URL Visited: {h.get('url','?')[:60]}",
            description=(
                f"Browser visit: {h.get('url','?')[:200]}. "
                f"Title: {h.get('title','N/A')[:100]}. "
                f"Visits: {h.get('visit_count','N/A')}. "
                f"Browser: {h.get('browser','?')}."
            ),
            severity=sev,
            category="Browser History",
            artefact_location=h.get("url",""),
            timestamp=ts,
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        if ts:
            timeline.append(TimelineEntry(
                timestamp=ts,
                event_description=f"URL visited: {h.get('url','')[:100]}",
                source="Browser History",
            ))
        fid += 1

    raw_data: dict[str, Any] = {
        "total_urls": data.get("total_urls", 0),
        "suspicious_urls": [h.get("url","") for h in suspicious[:20]],
        "history_sample": all_history[:50],
    }

    if all_history:
        rows = [[h.get("url","?")[:60], h.get("browser","?"),
                 str(h.get("visit_count","?")),
                 str(h.get("visit_time","?"))[:19]]
                for h in all_history[:20]]
        chart = _chart_table_image(
            "Browser History — URL Visits",
            ["URL", "Browser", "Visits", "Last Visited"],
            rows, label="Browser History (SQLite/index.dat output)",
        )
        if chart:
            raw_data["_chart_browser"] = chart

    return ModuleResult(
        module_name="Browser History Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if all_history else "partial",
        findings=findings,
        timeline_entries=timeline,
        raw_data=raw_data,
        artefacts_examined=data.get("browser_files", 0),
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_network_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load the conservative identifier-correlation manifest."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    fid = 1
    iocs = data.get("iocs", {})
    network_map = data.get("network_map", [])

    ioc_types = [
        ("emails", "Email Addresses", FindingSeverity.LOW),
        ("public_ips", "Public IP Addresses", FindingSeverity.LOW),
        ("phones", "Phone Numbers", FindingSeverity.LOW),
        ("btc_wallets", "Bitcoin Wallets", FindingSeverity.MEDIUM),
        ("twitter_handles", "Twitter Handles", FindingSeverity.LOW),
    ]

    for key, label, sev in ioc_types:
        vals = iocs.get(key, [])
        if vals:
            findings.append(FindingItem(
                finding_id=f"NET-{fid:04d}",
                title=f"Identifier extraction: {len(vals)} {label}",
                description=(
                    f"{len(vals)} syntactically valid {label} extracted from "
                    f"evidence-derived artefacts. Sample: {'; '.join(str(v)[:50] for v in vals[:5])}. "
                    "Presence alone does not establish identity, ownership, relationship, or criminality."
                ),
                severity=sev,
                category="Identifier Correlation",
                artefact_location="Case artifacts",
                evidence_reference="",  # attribution assigned by _apply_evidence_index
                raw_data=json.dumps(vals[:20]),
            ))
            fid += 1

    raw_data: dict[str, Any] = {
        "iocs": iocs,
        "network_map": network_map,
    }

    if network_map:
        rows = [[str(e.get("entry","?")), e.get("type","?"),
                 str(e.get("value","?"))[:60], e.get("note","?")[:40]]
                for e in network_map[:20]]
        chart = _chart_table_image(
            "Identifier Correlation — Extracted Values",
            ["#", "Type", "Value", "Source"],
            rows, label="Identifier correlation (evidence-derived regex output)",
        )
        if chart:
            raw_data["_chart_network"] = chart

    return ModuleResult(
        module_name="Identifier Correlation Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if network_map else "partial",
        findings=findings,
        raw_data=raw_data,
        artefacts_examined=sum(len(v) for v in iocs.values()),
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_image_content_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load image_content_manifest.json from image_content_analyzer."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    findings: list[FindingItem] = []
    fid = 1

    for img in data.get("flagged_details", []):
        findings.append(FindingItem(
            finding_id=f"IMG-{fid:04d}",
            title=f"Document Image: {img.get('doc_type','?')} — {Path(img.get('path','')).name}",
            description=(
                f"Image classified as '{img.get('doc_type','?')}'. "
                f"OCR: {img.get('ocr_preview','')[:200]}"
            ),
            severity=FindingSeverity.HIGH,
            category="Document Image",
            artefact_location=img.get("path",""),
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    for gps in data.get("gps_data", []):
        findings.append(FindingItem(
            finding_id=f"IMG-{fid:04d}",
            title=f"GPS Coordinates in Image: {Path(gps.get('path','')).name}",
            description=(
                f"GPS coordinates extracted from image '{gps.get('path','')}': "
                f"{gps.get('gps','?')}"
            ),
            severity=FindingSeverity.HIGH,
            category="GPS Geolocation",
            artefact_location=gps.get("path",""),
            evidence_reference="",  # attribution assigned by _apply_evidence_index
        ))
        fid += 1

    # Embed images as chart_image blocks in raw_data
    image_data = data.get("image_data", [])
    embedded_blocks: list[ContentBlock] = []

    for img in data.get("image_data", [])[:20]:
        if img.get("b64"):
            embedded_blocks.append(ContentBlock(
                block_type="chart_image",
                data={
                    "data_b64": img["b64"],
                    "label": f"Extracted Image — {Path(img.get('path','')).name}"
                             + (f" [{img['doc_type']}]" if img.get("doc_type") else ""),
                    "width_mm": 100,
                    "is_evidence_image": True,
                },
            ))

    raw_data: dict[str, Any] = {
        "total_images": data.get("total_images", 0),
        "analyzed":     data.get("analyzed", 0),
        "flagged":      data.get("flagged", 0),
        "gps_images":   data.get("gps_images", 0),
    }

    if embedded_blocks:
        raw_data["_embedded_images"] = embedded_blocks

    return ModuleResult(
        module_name="Image Content Analyzer",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="success" if findings or image_data else "partial",
        findings=findings,
        raw_data=raw_data,
        artefacts_examined=data.get("total_images", 0),
        artefacts_relevant=len(findings),
        error_message="; ".join(data.get("errors", [])),
    )


def _load_antiforensic_manifest(path: Path, logger: logging.Logger) -> Optional[ModuleResult]:
    """Load anti-forensic supporting data without manufacturing findings.

    ``anti_forensic_acts`` is an examiner-review indicator table.  The module's
    standardized ``module_result.json`` is the authoritative source for concrete
    H2-retained findings.  Earlier loaders converted every indicator row into a
    PRESENT finding, contradicting the live module result and custody ledger.
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    acts = list(data.get("anti_forensic_acts", []) or [])
    errors = [str(item) for item in (data.get("errors", []) or []) if str(item)]
    concrete_count = int(data.get("findings", 0) or 0)

    raw_data: dict[str, Any] = {
        "_source": "antiforensic_supporting_manifest",
        "prefetch_empty": data.get("prefetch_empty", False),
        "prefetch_count": data.get("prefetch_count", 0),
        "wiping_tools": data.get("wiping_tools", []),
        "af_commands": data.get("af_commands", []),
        "anti_forensic_acts": acts,
        "concrete_finding_count": concrete_count,
    }

    if acts:
        rows = [[
            str(a.get("act_number", "?")),
            str(a.get("act", "?"))[:40],
            str(a.get("severity", "?")),
            str(a.get("evidence", "?"))[:40],
        ] for a in acts[:15]]
        chart = _chart_table_image(
            "Anti-Forensic Indicators — Examiner Review Table",
            ["#", "Indicator", "Severity", "Evidence Source"],
            rows,
            label="Anti-forensic indicator table (not automatically a finding)",
        )
        if chart:
            raw_data["_chart_af_acts"] = chart

    # Do not emit findings or a class verdict from this supporting manifest.
    # The standardized module result carries the actual concrete findings and
    # assurance verdict.  If it is unavailable, the report will add an honest
    # fallback INDETERMINATE row rather than turning indicator metadata into a
    # PRESENT claim.
    return ModuleResult(
        module_name="Anti-Forensic Detector",
        module_version="1.0",
        run_timestamp=_parse_ts(data.get("generated_at")) or _utc_now(),
        status="partial" if errors else "success",
        findings=[],
        raw_data=raw_data,
        artefacts_examined=len(acts),
        artefacts_relevant=0,
        error_message="; ".join(errors),
        class_results=[],
        execution_outcome=(
            "ran_with_caveat" if errors or concrete_count or acts
            else "ran_found_nothing"
        ),
        summary=(
            f"Supporting anti-forensic indicator table contains {len(acts)} indicator(s); "
            f"{concrete_count} concrete finding(s) are recorded only in module_result.json."
        ),
    )


# Maps from filename → loader function
_MANIFEST_LOADERS: list[tuple[str, Any]] = [
    ("disk_analysis.json",             _load_disk_analysis),
    ("artifacts_manifest.json",        _load_artifacts_manifest),
    ("strings_manifest.json",          _load_strings_manifest),
    ("recovery_manifest.json",         _load_recovery_manifest),
    ("registry_manifest.json",         _load_registry_manifest),
    ("filesystem_manifest.json",       _load_filesystem_deep_manifest),
    ("email_manifest.json",            _load_email_manifest),
    ("browser_manifest.json",          _load_browser_manifest),
    ("network_manifest.json",          _load_network_manifest),
    ("image_content_manifest.json",    _load_image_content_manifest),
    ("antiforensic_manifest.json",     _load_antiforensic_manifest),
]


def _resolve_entry_exhibit(entry: dict, descriptors: list[dict]) -> str:
    """Resolve the exhibit id for one combined-report entry from its own signals.

    An entry represents a single module run against a single evidence item.
    Signals, in priority order: an explicit attribution written by the
    orchestrator, the entry's recorded image identity (hash, then path), and
    finally an evNN component in any path the entry carries.  Returns "" when
    nothing resolves, leaving attribution to the later per-finding pass.
    """
    explicit = str(
        entry.get("evidence_reference")
        or entry.get("exhibit")
        or entry.get("exhibit_number")
        or ""
    )
    if explicit:
        return explicit
    if not descriptors:
        return ""

    identity = {
        "image_path": str(
            entry.get("image_path") or entry.get("evidence_path")
            or entry.get("source_image") or entry.get("evidence_source") or ""
        ),
        "md5": str(entry.get("image_md5") or entry.get("md5") or "").lower(),
        "sha256": str(entry.get("image_sha256") or entry.get("sha256") or "").lower(),
    }
    if any(identity.values()):
        ref = _resolve_exhibit(descriptors, identity=identity)
        if ref:
            return ref

    # evNN component in any path-like value the entry carries.
    for key in ("output_dir", "output_path", "manifest_path", "working_dir"):
        val = entry.get(key)
        if not val:
            continue
        idx = _derive_evidence_index(Path(str(val)))
        if idx is not None:
            for d in descriptors:
                if d["index"] == idx:
                    return d["exhibit"]
    return ""


def _load_combined_report_json(
    report_json_path: Path,
    logger: logging.Logger,
    descriptors: Optional[list[dict]] = None,
) -> "list[ModuleResult]":
    """
    Load ALL module results from the authoritative combined report.json written
    by the orchestrator at pipeline end.  Returns [] on any error.

    Supports the current orchestrator layout where module entries live under
    ``pipeline.results`` as well as alternative layouts that use top-level keys
    ``modules``, ``results``, or ``module_results`` (or a top-level list).

    Each entry is converted to a ``core.report_sections.ModuleResult``.
    Findings embedded in the entry (field ``findings``) are reconstructed as
    ``FindingItem`` objects if present; otherwise the finding list is empty.
    """
    results: list[ModuleResult] = []
    try:
        data = json.loads(report_json_path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Could not read combined report.json %s: %s", report_json_path, exc)
        return results

    # ── Locate the module-entries list ────────────────────────────────────────
    # Orchestrator (current): pipeline.results — entries use key "module" for name
    # Possible future layouts: top-level "modules" / "results" / "module_results" / bare list
    modules_raw = (
        data.get("modules")
        or data.get("results")
        or data.get("module_results")
        or (data.get("pipeline") or {}).get("results")
        or (data if isinstance(data, list) else [])
    )

    # ── First pass: collect all raw entries per module_name ───────────────────
    # A 33-module / 2-image run produces 66 entries (one per module per image).
    # We merge them here so the caller receives exactly N unique ModuleResults.
    descriptors = descriptors or []
    _entries_by_name: dict[str, list[dict]] = {}
    _total_entries = 0
    for entry in modules_raw:
        if not isinstance(entry, dict):
            continue
        module_name = (
            entry.get("module_name")
            or entry.get("module")
            or entry.get("name")
            or ""
        )
        if not module_name:
            continue
        _total_entries += 1
        _entries_by_name.setdefault(module_name, []).append(entry)

    # Lazy import of ClassResult enums — only needed when class_results are present
    try:
        from modules._base import ClassResult as _ClassResult, AssuranceVerdict as _AV, Locus as _Locus, SkipReason as _SR
        _locus_values = {e.value for e in _Locus}
        _av_values    = {e.value for e in _AV}
        _sr_values    = {e.value for e in _SR}
        _enums_ok = True
    except ImportError:
        _enums_ok = False

    # ── Second pass: merge all per-image entries for each module ─────────────
    fid_counter = 1
    for module_name, entries in _entries_by_name.items():
        try:
            merged_findings: list[FindingItem] = []
            merged_class_results = []
            merged_errors: list[str] = []
            merged_terminal: list[str] = []
            merged_summaries: list[str] = []
            merged_outcomes: list[str] = []
            merged_statistics: dict[str, Any] = {}
            artefacts_examined_total = 0
            best_ts_run = None
            statuses: list[str] = []

            for entry in entries:
                # --- findings ---
                raw_findings = entry.get("findings") or []
                # Each entry is one module run against ONE evidence item.  Its
                # exhibit is resolved from the entry's own signals so the merge
                # below cannot collapse several exhibits into one.
                ev_ref_fallback = _resolve_entry_exhibit(entry, descriptors)
                for f in raw_findings:
                    if not isinstance(f, dict):
                        continue
                    try:
                        sev_raw = f.get("severity", "low")
                        ts = _parse_ts(f.get("timestamp"))
                        meta = f.get("metadata") or {}
                        merged_findings.append(FindingItem(
                            finding_id=f.get("finding_id") or f"MOD-{fid_counter:04d}",
                            title=(
                                f.get("title")
                                or (f.get("finding_type") or "Finding").replace("_", " ").title()
                            ),
                            description=f.get("description", ""),
                            severity=_sev(sev_raw),
                            category=(
                                f.get("category")
                                or (f.get("finding_type") or "General").replace("_", " ").title()
                            ),
                            artefact_location=(
                                f.get("artefact_location")
                                or f.get("evidence_path")
                                or f.get("artifact_path")
                                or ""
                            ),
                            timestamp=ts,
                            evidence_reference=f.get("evidence_reference", ev_ref_fallback),
                            raw_data=json.dumps(meta, default=str)[:500] if meta else "",
                            finding_type=str(f.get("finding_type") or ""),
                            metadata=dict(meta) if isinstance(meta, dict) else {},
                        ))
                        fid_counter += 1
                    except Exception as fe:
                        logger.debug("Skipping malformed finding in %s: %s", module_name, fe)

                # --- class_results: take first non-empty set across images ---
                if not merged_class_results and _enums_ok:
                    class_results_raw = entry.get("class_results") or []
                    for cr_dict in class_results_raw:
                        try:
                            locus_val   = cr_dict.get("locus", "OTHER")
                            verdict_val = cr_dict.get("verdict", "INDETERMINATE")
                            skip_raw    = cr_dict.get("skip_reason")
                            merged_class_results.append(_ClassResult(
                                locus=_Locus(locus_val) if locus_val in _locus_values else _Locus.OTHER,
                                artefact_class=cr_dict.get("artefact_class", ""),
                                verdict=_AV(verdict_val) if verdict_val in _av_values else _AV.INDETERMINATE,
                                skip_reason=_SR(skip_raw) if skip_raw and skip_raw in _sr_values else None,
                                count=int(cr_dict.get("count", 0)),
                                notes=str(cr_dict.get("notes", "") or ""),
                            ))
                        except Exception:
                            pass

                # --- honest execution state / summary / statistics ---
                _outcome = str(entry.get("execution_outcome") or "").strip()
                if _outcome:
                    merged_outcomes.append(_outcome)
                _summary = str(entry.get("summary") or "").strip()
                if _summary:
                    merged_summaries.append(_summary)
                _stats = entry.get("statistics") or {}
                if isinstance(_stats, dict):
                    merged_statistics.update(_stats)
                    _module_stats = _stats.get("module_statistics") or {}
                    _stat_sources = [_stats]
                    if isinstance(_module_stats, dict):
                        _stat_sources.insert(0, _module_stats)
                    _examined_added = False
                    for _source in _stat_sources:
                        for _key in ("artefacts_examined", "artifacts_examined", "total_files",
                                     "files_examined", "objects_examined", "records_examined"):
                            try:
                                _value = int(_source.get(_key, 0) or 0)
                            except (TypeError, ValueError):
                                continue
                            if _value:
                                artefacts_examined_total += _value
                                _examined_added = True
                                break
                        if _examined_added:
                            break
                try:
                    artefacts_examined_total += int(entry.get("artefacts_examined", 0) or 0)
                except (TypeError, ValueError):
                    pass

                # --- status ---
                status_raw = str(entry.get("status") or "COMPLETED").lower()
                statuses.append(status_raw)

                # --- timestamps ---
                ts_run = (
                    _parse_ts(entry.get("end_time"))
                    or _parse_ts(entry.get("start_time"))
                    or _utc_now()
                )
                if best_ts_run is None:
                    best_ts_run = ts_run

                # --- errors / terminal ---
                err = str(entry.get("error") or entry.get("error_message") or "")
                if err:
                    merged_errors.append(err)
                term = str(entry.get("terminal_output") or "")
                if term:
                    merged_terminal.append(term)

            # Derive merged status preserving SKIPPED/DEGRADED/INDETERMINATE
            _success_set = {"completed", "success", "pass_complete"}
            _incomplete_set = {"partial", "incomplete", "completed_with_fallback", "degraded", "indeterminate", "verify_later"}
            _skip_set = {"skipped", "not_applicable", "out_of_scope"}
            _error_set = {"failed", "error", "import_failed", "failed_offset", "failed_isolated"}
            if any(state in _error_set for state in statuses):
                merged_status = "partial" if any(state in _success_set | _incomplete_set for state in statuses) else "failed_isolated"
            elif all(state in _success_set for state in statuses):
                merged_status = "success"
            elif all(state in _skip_set for state in statuses):
                merged_status = statuses[0]
            elif any(state in _incomplete_set for state in statuses):
                merged_status = "partial"
            else:
                merged_status = "partial"

            # Preserve the four-way outcome.  When several evidence items were
            # merged, choose the least-successful truthful state rather than
            # collapsing everything to SUCCESS.
            if "did_not_run" in merged_outcomes and not merged_findings:
                merged_outcome = "did_not_run"
            elif "ran_with_caveat" in merged_outcomes or ("did_not_run" in merged_outcomes and merged_findings):
                merged_outcome = "ran_with_caveat"
            elif merged_findings:
                merged_outcome = "ran_found_x"
            else:
                merged_outcome = "ran_found_nothing"

            mr = ModuleResult(
                module_name=module_name,
                module_version="1.0",
                run_timestamp=best_ts_run or _utc_now(),
                status=merged_status,
                findings=merged_findings,
                raw_data={"statistics": merged_statistics},
                error_message="; ".join(merged_errors),
                artefacts_examined=artefacts_examined_total,
                artefacts_relevant=len(merged_findings),
                terminal_output="\n---\n".join(merged_terminal),
                execution_outcome=merged_outcome,
                summary=" | ".join(dict.fromkeys(merged_summaries)),
            )
            mr.class_results = merged_class_results
            results.append(mr)
            logger.info(
                "report.json: %s — %d findings, %d class_results, status=%s (%d image(s))",
                module_name, len(merged_findings), len(merged_class_results),
                merged_status, len(entries),
            )
        except Exception as exc:
            logger.warning(
                "Could not reconstruct ModuleResult for %s: %s", module_name, exc
            )

    logger.debug(
        "report.json dedup: %d unique modules from %d total entries",
        len(results), _total_entries,
    )
    return results



_MODULE_ALIASES: dict[str, str] = {
    "artifact extractor": "artifact_extractor",
    "scalpel file carver": "scalpel_carver",
    "foremost file carver": "foremost_carver",
    "deleted file recovery": "deleted_file_recovery",
    "windows registry analyzer": "windows_registry_analyzer",
    "file system deep analyzer": "filesystem_deep_analyzer",
    "email & communications analyzer": "email_communications_analyzer",
    "email and communications analyzer": "email_communications_analyzer",
    "browser history analyzer": "browser_history_analyzer",
    "identifier correlation analyzer": "criminal_network_mapper",
    "criminal network mapper": "criminal_network_mapper",
    "image content analyzer": "image_content_analyzer",
    "anti-forensic detector": "anti_forensic_detector",
    "anti forensic detector": "anti_forensic_detector",
}


def _canonical_module_name(name: str) -> str:
    """Map compatibility/display labels to one stable runtime module id."""
    raw = " ".join(str(name or "").strip().lower().replace("_", " ").split())
    return _MODULE_ALIASES.get(raw, str(name or "").strip())


def _finding_merge_key(finding: FindingItem) -> tuple[str, str, str, str]:
    """Content key for exact/corroborating duplicates across loader aliases."""
    title = " ".join(str(getattr(finding, "title", "") or "").lower().split())
    location = str(getattr(finding, "artefact_location", "") or "")
    basename = Path(location.replace("\\", "/")).name.lower()
    desc = " ".join(str(getattr(finding, "description", "") or "").lower().split())
    # Absolute output roots and generated UUIDs are not part of the evidential
    # identity. Keep enough detail to avoid collapsing genuinely distinct facts.
    desc = _re_loader.sub(r"/[^\s,;:)]+", lambda m: Path(m.group(0)).name, desc)
    desc = _re_loader.sub(
        r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
        "", desc,
    )
    return (
        str(getattr(finding, "evidence_reference", "") or ""),
        title,
        basename,
        desc[:600],
    )


def _consolidate_module_aliases(
    results: list[ModuleResult], logger: logging.Logger
) -> list[ModuleResult]:
    """Merge compatibility/display aliases into one honest module outcome.

    Older loaders may emit both a machine module id and a human display name for
    the same run. Keeping both inflates the configured-module count and may
    create contradictory outcomes. This pass preserves the union of findings,
    timeline entries, class results and caveats under one canonical module id.
    """
    grouped: dict[str, list[ModuleResult]] = {}
    order: list[str] = []
    for result in results:
        canonical = _canonical_module_name(result.module_name)
        if canonical not in grouped:
            grouped[canonical] = []
            order.append(canonical)
        grouped[canonical].append(result)

    merged_results: list[ModuleResult] = []
    for canonical in order:
        group = grouped[canonical]
        # Prefer the runtime-id record as the base because it carries the most
        # structured native raw_data and execution outcome.
        base = next((r for r in group if r.module_name == canonical), group[0])
        if len(group) == 1:
            base.module_name = canonical
            merged_results.append(base)
            continue

        findings: list[FindingItem] = []
        seen_findings: set[tuple[str, str, str, str]] = set()
        timeline: list[TimelineEntry] = []
        seen_timeline: set[tuple] = set()
        class_results: list[Any] = []
        seen_classes: set[tuple] = set()
        summaries: list[str] = []
        errors: list[str] = []
        terminals: list[str] = []
        examined = 0
        relevant = 0

        for result in group:
            examined = max(examined, int(getattr(result, "artefacts_examined", 0) or 0))
            relevant = max(relevant, int(getattr(result, "artefacts_relevant", 0) or 0))
            if result.summary and result.summary not in summaries:
                summaries.append(result.summary)
            if result.error_message and result.error_message not in errors:
                errors.append(result.error_message)
            if result.terminal_output and result.terminal_output not in terminals:
                terminals.append(result.terminal_output)

            for finding in result.findings or []:
                key = _finding_merge_key(finding)
                if key not in seen_findings:
                    seen_findings.add(key)
                    findings.append(finding)
            for entry in result.timeline_entries or []:
                key = (
                    str(getattr(entry, "timestamp", "")),
                    str(getattr(entry, "event_type", "")),
                    str(getattr(entry, "description", "")),
                    str(getattr(entry, "source", "")),
                    str(getattr(entry, "exhibit_number", "")),
                )
                if key not in seen_timeline:
                    seen_timeline.add(key)
                    timeline.append(entry)
            for cr in result.class_results or []:
                key = (
                    str(getattr(cr, "artefact_class", "")),
                    str(getattr(cr, "locus", "")),
                )
                # Keep all candidates temporarily; contradictory aliases are
                # reconciled below with PRESENT > INDETERMINATE > ABSENT.
                class_results.append(cr)

        # Reconcile one verdict per artefact class.  A concrete retained finding
        # can never coexist with VERIFIED_ABSENT for the same single-class module.
        _cr_groups: dict[tuple[str, str], list[Any]] = {}
        for _cr in class_results:
            _key = (str(getattr(_cr, "artefact_class", "")), str(getattr(_cr, "locus", "")))
            _cr_groups.setdefault(_key, []).append(_cr)
        _reconciled: list[Any] = []
        for _key, _candidates in _cr_groups.items():
            def _rank(_item: Any) -> int:
                _value = str(getattr(getattr(_item, "verdict", ""), "value", getattr(_item, "verdict", ""))).upper()
                return {"PRESENT": 3, "INDETERMINATE": 2, "VERIFIED_ABSENT": 1}.get(_value, 0)
            _chosen = max(_candidates, key=_rank)
            if findings and len(_cr_groups) == 1:
                try:
                    from modules._base import AssuranceVerdict as _AV, SkipReason as _SR
                    _chosen.verdict = _AV.PRESENT
                    _chosen.skip_reason = None
                    _chosen.count = max(int(getattr(_chosen, "count", 0) or 0), len(findings))
                except Exception:
                    pass
            _notes = [str(getattr(x, "notes", "") or "").strip() for x in _candidates]
            _chosen.notes = " | ".join(dict.fromkeys(x for x in _notes if x))
            _reconciled.append(_chosen)
        class_results = _reconciled

        def _status_value(result: ModuleResult) -> str:
            value = getattr(getattr(result, "status", ""), "value", getattr(result, "status", ""))
            text = str(value or "").strip().lower()
            if text.startswith("modulestatus."):
                text = text.split(".", 1)[1]
            return text

        statuses = {_status_value(r) for r in group}
        outcomes = {str(getattr(r, "execution_outcome", "") or "").strip().lower() for r in group}
        skip_reasons = {
            str(getattr(getattr(cr, "skip_reason", ""), "value", getattr(cr, "skip_reason", "")) or "").strip().lower()
            for cr in class_results
        }

        # Preserve truthful non-execution states during alias consolidation.
        # A native or compatibility alias must not convert NOT_APPLICABLE,
        # VERIFY_LATER, or an isolated external-tool failure into "success".
        if findings:
            if statuses & {"partial", "incomplete", "degraded", "indeterminate", "completed_with_fallback"}:
                status = "partial"
            else:
                status = "success"
        elif (statuses and statuses <= {"not_applicable", "skipped"}) or "not_applicable" in skip_reasons:
            status = "not_applicable"
        elif statuses and statuses <= {"out_of_scope", "skipped"}:
            status = "out_of_scope"
        elif (statuses and statuses <= {"verify_later", "skipped"}) or "verify_later" in skip_reasons:
            status = "verify_later"
        elif statuses & {"failed_isolated", "failed"}:
            status = "failed_isolated"
        elif statuses & {"partial", "incomplete", "degraded", "indeterminate", "completed_with_fallback"}:
            status = "partial"
        elif statuses <= {"skipped"}:
            status = "skipped"
        else:
            status = "success"

        if findings:
            outcome = "ran_found_x"
        elif status in {"partial", "completed_with_fallback"}:
            outcome = "ran_with_caveat"
        elif status in {"not_applicable", "out_of_scope", "verify_later", "failed_isolated", "failed", "skipped"}:
            outcome = "did_not_run"
        elif outcomes == {"did_not_run"}:
            outcome = "did_not_run"
        else:
            outcome = "ran_found_nothing"

        raw_data = dict(base.raw_data or {})
        raw_data["_consolidated_aliases"] = [r.module_name for r in group]
        merged = ModuleResult(
            module_name=canonical,
            module_version=base.module_version,
            run_timestamp=min((r.run_timestamp for r in group), default=base.run_timestamp),
            status=status,
            findings=findings,
            timeline_entries=timeline,
            raw_data=raw_data,
            error_message=" | ".join(errors),
            artefacts_examined=examined,
            artefacts_relevant=max(relevant, len(findings)),
            terminal_output=terminals[0] if terminals else "",
            class_results=class_results,
            execution_outcome=outcome,
            summary=" | ".join(summaries),
        )
        logger.info(
            "Consolidated module aliases %s -> %s (%d findings)",
            ", ".join(r.module_name for r in group), canonical, len(findings),
        )
        merged_results.append(merged)
    return merged_results


def _assurance_finding_identity(finding: FindingItem) -> tuple[str, ...]:
    """Return a conservative identity for duplicate observations.

    The identity is derived only from the finding itself.  It is intentionally
    narrow: it de-duplicates corroborating rows for the same deleted record or
    same byte-identical artefact while retaining genuinely distinct files.
    """
    title = str(finding.title or "")
    desc = str(finding.description or "")
    category = str(finding.category or "")
    location = str(finding.artefact_location or "")
    blob = f"{title} {category} {desc} {location}".lower()

    if "deleted file" in blob or "deleted record" in blob:
        candidates = [location]
        candidates += _re_loader.findall(r"(?i)(?:original path|path)\s*[:=]\s*['\"]?([^;'\"\s]+)", desc)
        candidates += _re_loader.findall(r"(?i)(/[A-Za-z0-9_.()\-]+(?:\s*\(deleted\))?)", f"{title} {desc}")
        for value in candidates:
            base = Path(str(value).replace('\\', '/')).name.lower()
            base = _re_loader.sub(r"(?i)\s*\(deleted\)$", "", base).strip()
            base = _re_loader.sub(r"(?i)^deleted_", "", base)
            if base and '.' in base:
                return ("deleted", str(getattr(finding, "evidence_reference", "") or ""), base)

    # A full SHA-256, when present, is the strongest identity for an object.
    hashes = _re_loader.findall(r"(?i)\b[0-9a-f]{64}\b", desc)
    if hashes:
        return ("sha256", str(getattr(finding, "evidence_reference", "") or ""), hashes[0].lower())

    base = Path(location.replace('\\', '/')).name.lower()
    clean_title = _re_loader.sub(r"\s+", " ", title.lower()).strip()
    clean_desc = _re_loader.sub(r"\s+", " ", desc.lower()).strip()
    clean_desc = _re_loader.sub(r"/[A-Za-z0-9_./()\-]+", lambda m: Path(m.group(0)).name, clean_desc)
    return ("generic", str(getattr(finding, "evidence_reference", "") or ""), clean_title, base, clean_desc[:500])


def _assurance_normalise_loaded_findings(results: list[ModuleResult]) -> list[ModuleResult]:
    """Apply conservative reporting semantics and de-duplicate corroborating rows.

    This pass never invents evidence.  It removes duplicate presentation rows,
    narrows claims that exceed the artefact, and normalises coverage/status text
    so report-only regeneration cannot carry forward a known overstatement.
    """
    for result in results:
        kept: list[FindingItem] = []
        seen: dict[tuple[str, ...], int] = {}
        for finding in result.findings:
            title = str(finding.title or "")
            desc = str(finding.description or "")
            category = str(finding.category or "")
            blob = f"{title} {category} {desc}".lower()

            if "anti-forensic acts table" in blob or "anti forensic acts table" in blob:
                continue

            replacements = {
                ("attributes the file to a device " + "and a point in time."): (
                    "records device and capture-time fields stored in the file metadata. "
                    "These fields do not independently establish device ownership, file provenance, "
                    "physical presence, or clock accuracy."
                ),
                ("Indicates deliberate file " + "deletion by the user."): (
                    "Records deletion metadata. This does not identify the user or establish why the item was deleted."
                ),
                ("Prefetch proves a program " + "was executed on this system even if the executable has since been deleted."): (
                    "Prefetch is generally consistent with program execution on the examined Windows installation, "
                    "subject to parser and clock limitations. It does not identify the user or prove later deletion."
                ),
                ("May indicate deliberate " + "obfuscation."): (
                    "This is an observable filename-masquerading anomaly; intent and execution are not established."
                ),
                ("deliberate attempts to obstruct forensic analysis " + "and destroy evidence"): (
                    "observable indicators that require contextual review; obstruction, destruction and user intent are not established"
                ),
            }
            for old, new_text in replacements.items():
                desc = desc.replace(old, new_text)

            desc = desc.replace("Participants: .", "No participant screen-name strings were parsed.")
            desc = desc.replace("Participants:  .", "No participant screen-name strings were parsed.")

            if "double-extension" in blob or "double extension" in blob:
                finding.title = "Double-extension filename indicator"
                finding.category = "File Masquerading Indicator"
                finding.severity = FindingSeverity.MEDIUM
                if "intent" not in desc.lower():
                    desc += " The filename alone does not establish user intent, execution, or an anti-forensic act."

            if "extension mismatch" in blob or "signature mismatch" in blob:
                finding.severity = FindingSeverity.MEDIUM
                if "does not establish" not in desc.lower():
                    desc += " The mismatch does not by itself establish malware, execution, concealment, or user intent."

            if "deleted file" in blob or "deleted filesystem record" in blob or "deleted record" in blob:
                if finding.severity in {FindingSeverity.HIGH, FindingSeverity.CRITICAL}:
                    finding.severity = FindingSeverity.MEDIUM
                if "does not establish" not in desc.lower():
                    desc += " The deleted state does not establish who deleted the item, when the action occurred, or why."

            if "gps" in blob or "geolocation" in blob:
                finding.severity = FindingSeverity.LOW
                if "physical presence" not in desc.lower():
                    desc += " The stored coordinates do not establish physical presence, device ownership, or clock accuracy."

            if "eicar" in blob:
                finding.severity = FindingSeverity.LOW
                if "test signature" not in desc.lower():
                    desc += " EICAR is a harmless antivirus test signature and is not live malware."

            if "ocr" in blob and any(x in blob for x in ("credential", "password", "wifi", "vpn", "admin")):
                finding.severity = FindingSeverity.MEDIUM
                if "candidate transcription" not in desc.lower():
                    desc += " OCR is a candidate transcription; exact characters require manual review of the source image."

            if "capture metadata" in blob or "camera metadata" in blob:
                finding.severity = FindingSeverity.LOW

            if "stegan" in blob or "pixel anomaly" in blob or "lsb payload" in blob:
                if finding.severity in {FindingSeverity.HIGH, FindingSeverity.CRITICAL}:
                    finding.severity = FindingSeverity.MEDIUM
                metadata = dict(getattr(finding, "metadata", {}) or {})
                deterministic_decode = bool(
                    metadata.get("deterministic_validation")
                    and (metadata.get("decoded_payload") or metadata.get("payload_sha256")
                         or "payload decoded" in blob or "deterministically decoded" in blob)
                )
                if deterministic_decode:
                    if "repeatably decoded" not in desc.lower():
                        desc += " The payload was repeatably decoded by the declared deterministic method; this does not establish authorship or intent."
                elif "no hidden payload is established" not in desc.lower():
                    desc += " This remains a candidate indicator; no hidden payload is established unless repeatable deterministic extraction succeeds."

            finding.description = desc
            identity = _assurance_finding_identity(finding)
            if identity in seen:
                existing = kept[seen[identity]]
                # Prefer the richer observation (hash, size, recovery basis), but
                # preserve its original evidential reference and severity.
                if len(str(finding.description or "")) > len(str(existing.description or "")):
                    kept[seen[identity]] = finding
                continue
            seen[identity] = len(kept)
            kept.append(finding)

        result.findings = kept
        result.artefacts_relevant = len(kept)
        lower_name = result.module_name.lower()
        if "anti_forensic" in lower_name or "anti-forensic" in lower_name:
            result.summary = str(result.summary or "").replace("acts", "indicators")
        if lower_name in {"deleted file recovery", "deleted_file_recovery"}:
            records = len({
                _assurance_finding_identity(f)
                for f in kept
                if _assurance_finding_identity(f)[0] == "deleted"
            })
            recovered = sum(
                1 for f in kept
                if "recovered" in (f.title or "").lower()
                or "status=recovered" in (f.description or "").lower()
            )
            recovered = min(records, recovered)
            if records:
                result.status = "success" if recovered == records else "partial"
                result.execution_outcome = "ran_found_x" if recovered else "ran_with_caveat"
                result.error_message = "" if recovered else result.error_message
                result.artefacts_examined = records
                result.artefacts_relevant = records
                result.summary = f"RAN AND FOUND {records} distinct deleted record(s); {recovered} file(s) recovered natively."

        # A missing corpus is not a failed or partially executed analysis.
        # Any memory module without a supplied memory corpus cannot certify
        # absence, even if the module returned SUCCESS with zero findings.
        if lower_name.startswith("memory_") and not result.findings:
            raw = json.dumps(result.raw_data or {}, default=str).lower()
            summary_blob = f"{result.summary or ''} {result.error_message or ''} {raw}".lower()
            no_memory_source = not any(token in summary_blob for token in (
                ".raw", ".lime", ".dmp", ".vmem", "hiberfil.sys", "pagefile.sys",
                "memory image supplied", "memory corpus supplied",
            ))
            current_status = str(
                getattr(getattr(result, "status", ""), "value", getattr(result, "status", "")) or ""
            ).strip().lower()
            if current_status.startswith("modulestatus."):
                current_status = current_status.split(".", 1)[1]
            # A disk image containing deterministically parsed memory-marker
            # corpora may produce literal marker findings, while genuine RAM
            # structure analysis remains NOT_APPLICABLE. Preserve that split;
            # do not turn a marker-aware result into a blanket memory absence.
            if current_status in {"not_applicable", "verify_later"}:
                result.execution_outcome = "did_not_run"
            elif (
                str(result.execution_outcome or "").lower() == "did_not_run"
                or current_status == "skipped"
                or result.artefacts_examined == 0
                or no_memory_source
            ):
                result.status = "not_applicable"
                result.execution_outcome = "did_not_run"
                result.error_message = (
                    "NOT APPLICABLE — no genuine supported memory image was supplied; "
                    "nested marker strings are handled by filesystem/string analysis only."
                )
                result.summary = result.error_message
                try:
                    from modules._base import AssuranceVerdict, SkipReason
                    for cr in result.class_results or []:
                        cr.verdict = AssuranceVerdict.INDETERMINATE
                        cr.skip_reason = SkipReason.NOT_APPLICABLE
                        cr.notes = result.error_message
                except Exception:
                    pass

        if lower_name in {"image_mounter", "image mounter", "native evidence access"} and not result.findings:
            raw_mount = json.dumps(result.raw_data or {}, default=str).lower()
            mount_succeeded = any(token in raw_mount for token in (
                '"mount_succeeded": true', '"os_mount_used": true', '"mounted": 1'
            ))
            if not mount_succeeded:
                result.status = "partial"
                result.execution_outcome = "ran_with_caveat"
                result.summary = (
                    "Direct read-only parsing completed; OS-level image mounting was not attempted or validated. "
                    "Direct parsing is reported separately and does not prove mounting capability."
                )

        if lower_name == "windows_registry_analyzer" and not result.findings:
            raw = json.dumps(result.raw_data or {}, default=str).lower()
            if "parsed 0" in (result.summary or "").lower() or "hive" in raw:
                result.status = "skipped"
                result.execution_outcome = "did_not_run"
                result.error_message = "No Windows registry-hive corpus was identified in the supplied evidence."
                result.summary = result.error_message

        # Reconcile per-class assurance with what actually ran.  An empty or
        # partial/no-corpus run can never certify an artefact class absent.
        if result.class_results:
            from modules._base import AssuranceVerdict, SkipReason
            status_lower = str(result.status or "").lower()
            outcome_lower = str(getattr(result, "execution_outcome", "") or "").lower()
            no_corpus = outcome_lower == "did_not_run" or status_lower in {
                "skipped", "failed", "failed_isolated", "error", "not_applicable", "verify_later"
            }
            partial_zero = status_lower in {"partial", "degraded", "indeterminate"} and not result.findings
            dedicated_timeline_empty = lower_name == "timeline_builder" and not result.findings
            for cr in result.class_results:
                if cr.verdict == AssuranceVerdict.VERIFIED_ABSENT and (no_corpus or partial_zero or dedicated_timeline_empty):
                    cr.verdict = AssuranceVerdict.INDETERMINATE
                    if dedicated_timeline_empty:
                        cr.skip_reason = SkipReason.PARTIAL_FAILURE
                        cr.notes = (
                            "The dedicated timeline module produced no validated evidence-activity timeline. "
                            "Other modules may contain timestamps, which are reported separately and are not a verified absence."
                        )
                    elif no_corpus:
                        if status_lower == "not_applicable":
                            cr.skip_reason = SkipReason.NOT_APPLICABLE
                        elif status_lower == "verify_later":
                            cr.skip_reason = SkipReason.OTHER
                        else:
                            cr.skip_reason = SkipReason.NO_CORPUS
                        cr.notes = cr.notes or result.error_message or result.summary or "Required evidence corpus was not supplied."
                    else:
                        cr.skip_reason = SkipReason.PARTIAL_FAILURE
                        cr.notes = cr.notes or result.error_message or result.summary or "The relevant technique did not complete conclusively."
                if cr.verdict == AssuranceVerdict.PRESENT:
                    # Counts for deleted records are distinct artefacts, not
                    # duplicate report rows produced by compatibility loaders.
                    if lower_name == "deleted_file_recovery":
                        cr.count = result.artefacts_examined or len(result.findings)

    return results

def load_case_results(
    case_dir: Path,
    logger: logging.Logger,
    case_config: Any = None,
) -> list[ModuleResult]:
    """
    Scan case_dir for all known module manifest files and return a list of
    core.report_sections.ModuleResult objects ready for ReportGenerator.

    Search order: known manifest names first (in priority order), then any
    additional *_manifest.json files, then any *_result.json files containing
    a 'module_name' key.

    Parameters
    ----------
    case_dir:
        Root of the case output directory.
    logger:
        Logger for progress and warning messages.

    Returns
    -------
    list[ModuleResult]
        One entry per successfully loaded manifest; empty list if none found.
    """
    results: list[ModuleResult] = []
    seen_paths: set[Path] = set()
    # module names already loaded from the authoritative combined report.json.
    # report.json entries are merged ACROSS all exhibits (each finding keeps its
    # own exhibit reference), so a module it covers must not be re-loaded from a
    # per-exhibit manifest — that would duplicate findings.
    loaded_from_report: set[str] = set()
    # Manifests are laid out one dir per (exhibit, module): module_output/evNN/<mod>/.
    # The SAME module runs on EVERY exhibit and therefore has the SAME module_name
    # on each, so manifest de-duplication must be keyed per (module_name, exhibit)
    # — never per module_name alone, which would keep only the first exhibit and
    # silently drop every later one (the multi-exhibit regression).
    loaded_module_exhibit: set[tuple[str, str]] = set()
    # Evidence descriptors discovered from case_config drive per-item attribution.
    descriptors = _build_evidence_descriptors(case_config)

    def _dedup_key(r: ModuleResult, manifest_path: Path) -> tuple[str, str]:
        """Key a loaded manifest by (module_name, exhibit).

        The exhibit is read from the attribution stamped by _apply_evidence_index
        (raw_data['_exhibit']).  When no exhibit could be resolved the manifest
        path is used instead so distinct files are never collapsed together.
        """
        ex = ""
        if isinstance(r.raw_data, dict):
            ex = str(r.raw_data.get("_exhibit") or "")
        return (r.module_name, ex or str(manifest_path))

    def _inject_terminal(r: ModuleResult, manifest_path: Path) -> None:
        """Populate terminal_output from a sibling terminal_output.txt if present."""
        if r.terminal_output:
            return
        txt = manifest_path.parent / "terminal_output.txt"
        if txt.exists():
            try:
                r.terminal_output = txt.read_text(encoding="utf-8")
            except OSError:
                pass

    # ── Stage 0: combined report.json (AUTHORITATIVE) ─────────────────────────
    # Search ONLY within case_dir for *_report.json (the orchestrator writes it
    # to case_dir/reports/).  The previous code also scanned case_dir.parent,
    # which — when this case had no report.json of its own — bled a sibling
    # case's report.json in from the shared output root (Phase 1d leftover
    # bleed).  Every legitimate report.json lives under case_dir, so the parent
    # scan was never needed and is removed.  Use the newest file found; stop
    # after the first non-empty result so we don't double-load.
    _rj_candidates: list[Path] = sorted(
        Path(case_dir).rglob("*_report.json"), reverse=True
    )

    for rj_path in _rj_candidates:
        rj_results = _load_combined_report_json(rj_path, logger, descriptors)
        if rj_results:
            _rj_raw_count = 0  # _load_combined_report_json logs the raw count internally
            for mr in rj_results:
                if _canonical_module_name(mr.module_name) not in loaded_from_report:
                    # Mark provenance so a findings-less report.json entry can be
                    # superseded by the on-disk manifest that actually holds the
                    # findings (see the manifest-supersedes-stub pass below).
                    if isinstance(mr.raw_data, dict):
                        mr.raw_data["_source"] = "report_json"
                    results.append(mr)
                    # Only treat report.json as AUTHORITATIVE for a module when it
                    # actually carried that module's findings.  The orchestrator
                    # writes report.json entries with run metadata but NO findings
                    # (findings live in module_output/evNN/<mod>/ manifests), so a
                    # blanket block here would shadow every exhibit's findings and
                    # render an empty report.  Blocking only findings-bearing
                    # entries keeps the double-load guard for fixtures/layouts that
                    # do embed findings, while letting the manifests supply them
                    # when report.json does not.
                    if mr.findings:
                        loaded_from_report.add(_canonical_module_name(mr.module_name))
                    _rj_raw_count += 1
            logger.info(
                "Stage 0: %d unique modules from %s (%d with findings are authoritative)",
                len(rj_results), rj_path.name, len(loaded_from_report),
            )
            break  # use the newest report.json; don't double-load

    # 1. Try priority-ordered known manifests (search root and all sub-dirs)
    for fname, loader_fn in _MANIFEST_LOADERS:
        candidates = list(case_dir.rglob(fname))
        for candidate in candidates:
            if candidate in seen_paths:
                continue
            seen_paths.add(candidate)
            try:
                result = loader_fn(candidate, logger)
                if result is not None:
                    _inject_terminal(result, candidate)
                    _apply_evidence_index(result, candidate, descriptors)
                    # Guard: skip if report.json already merged this module
                    # (report.json covers every exhibit for the module).
                    if _canonical_module_name(result.module_name) in loaded_from_report:
                        logger.debug(
                            "Skipping manifest %s — superseded by report.json",
                            candidate.name,
                        )
                        continue
                    # Per-exhibit dedup: keep this module's manifest from EVERY
                    # exhibit, skipping only a repeat of the same module+exhibit.
                    _k = _dedup_key(result, candidate)
                    if _k in loaded_module_exhibit:
                        continue
                    loaded_module_exhibit.add(_k)
                    logger.info("Loaded module result from %s (%d findings)",
                                candidate.name, len(result.findings))
                    results.append(result)
            except Exception as exc:
                logger.warning("Failed to load %s: %s", candidate, exc)

    # 2. Pick up any other *_manifest.json files not already loaded
    for candidate in case_dir.rglob("*_manifest.json"):
        if candidate in seen_paths:
            continue
        seen_paths.add(candidate)
        try:
            result = _load_generic_module_result(candidate, logger)
            if result:
                _inject_terminal(result, candidate)
                _apply_evidence_index(result, candidate, descriptors)
                # Guard: skip if report.json already merged this module.
                if _canonical_module_name(result.module_name) in loaded_from_report:
                    logger.debug(
                        "Skipping manifest %s — superseded by report.json",
                        candidate.name,
                    )
                    continue
                _k = _dedup_key(result, candidate)
                if _k in loaded_module_exhibit:
                    continue
                loaded_module_exhibit.add(_k)
                logger.info("Loaded generic manifest from %s (%d findings)",
                            candidate.name, len(result.findings))
                results.append(result)
        except Exception as exc:
            logger.warning("Failed to parse %s: %s", candidate, exc)

    # 3. Pick up any *_result.json files with a module_name key
    for candidate in case_dir.rglob("*_result.json"):
        if candidate in seen_paths:
            continue
        seen_paths.add(candidate)
        try:
            result = _load_generic_module_result(candidate, logger)
            if result:
                _inject_terminal(result, candidate)
                _apply_evidence_index(result, candidate, descriptors)
                # Guard: skip if report.json already merged this module.
                if _canonical_module_name(result.module_name) in loaded_from_report:
                    logger.debug(
                        "Skipping manifest %s — superseded by report.json",
                        candidate.name,
                    )
                    continue
                _k = _dedup_key(result, candidate)
                if _k in loaded_module_exhibit:
                    continue
                loaded_module_exhibit.add(_k)
                logger.info("Loaded module result from %s (%d findings)",
                            candidate.name, len(result.findings))
                results.append(result)
        except Exception as exc:
            logger.warning("Failed to parse %s: %s", candidate, exc)

    # 4. Always read pipeline_manifest.json: scan each module's output dir for JSON findings,
    #    then create stubs for modules that still have no result.
    _pipeline_entries: list[dict] = []
    _pipeline_paths = sorted(case_dir.glob("pipeline_manifest*.json"))
    for pipeline_manifest in _pipeline_paths:
        try:
            _loaded = json.loads(pipeline_manifest.read_text(encoding="utf-8"))
            if isinstance(_loaded, list):
                _pipeline_entries.extend(_loaded)
        except Exception as exc:
            logger.warning("Failed to read %s: %s", pipeline_manifest.name, exc)

    def _norm(name: str) -> str:
        return name.lower().replace(" ", "_").replace("-", "_").replace("/", "_")

    _loaded_names = {_norm(r.module_name) for r in results}

    for entry in _pipeline_entries:
        mname = entry.get("module_name", "Unknown Module")
        status_raw = entry.get("status", "unknown")
        out_dir_str = entry.get("output_dir", "")
        error_msg = entry.get("error", "")
        terminal_out = entry.get("terminal_output", "")
        out_dir = Path(out_dir_str) if out_dir_str else None

        found_new = False

        if out_dir and out_dir.is_dir():
            # Check for known manifest files in this output dir first
            for fname, loader_fn in _MANIFEST_LOADERS:
                mp = out_dir / fname
                if not mp.exists():
                    continue
                if mp in seen_paths:
                    # Already loaded in steps 1-3 — count as found so no stub is created
                    found_new = True
                    continue
                seen_paths.add(mp)
                try:
                    r = loader_fn(mp, logger)
                    if r:
                        _inject_terminal(r, mp)
                        _apply_evidence_index(r, mp, descriptors)
                        results.append(r)
                        _loaded_names.add(_norm(r.module_name))
                        found_new = True
                        logger.info("Loaded %s from %s output dir", fname, mname)
                except Exception as exc:
                    logger.warning("Failed to load %s: %s", mp, exc)

            # Then scan for any other JSON files not yet loaded
            for jf in out_dir.rglob("*.json"):
                if jf in seen_paths:
                    found_new = True  # already loaded in steps 1-3
                    continue
                seen_paths.add(jf)
                try:
                    r = _load_generic_module_result(jf, logger)
                    if r:
                        _inject_terminal(r, jf)
                        _apply_evidence_index(r, jf, descriptors)
                        results.append(r)
                        _loaded_names.add(_norm(r.module_name))
                        found_new = True
                        logger.info("Loaded generic result from %s (%d findings)",
                                    jf.name, len(r.findings))
                except Exception as exc:
                    logger.warning("Failed to load %s: %s", jf, exc)

            # Read terminal_output.txt if not in manifest
            if not terminal_out:
                txt_path = out_dir / "terminal_output.txt"
                if txt_path.exists():
                    try:
                        terminal_out = txt_path.read_text(encoding="utf-8")
                    except OSError:
                        pass

        # Create a stub for any module that ran but produced no loadable output
        if not found_new and _norm(mname) not in _loaded_names:
            _status_map = {
                "completed": "success",
                "completed_with_fallback": "partial",
                "partial": "partial",
                "failed": "failed_isolated",
                "failed_isolated": "failed_isolated",
                "not_applicable": "not_applicable",
                "verify_later": "verify_later",
                "skipped": "skipped",
            }
            status = _status_map.get(status_raw, "failed_isolated")
            if not terminal_out:
                terminal_out = (
                    f"Module: {mname}\nStatus: {status_raw.upper()}\n"
                    + (f"Error: {error_msg}" if error_msg else "No output captured.")
                )
            _execution_outcome = str(entry.get("execution_outcome") or "").strip() or (
                "did_not_run" if status in {"failed", "failed_isolated", "skipped", "not_applicable", "verify_later"}
                else "ran_with_caveat" if status == "partial"
                else "ran_found_nothing"
            )
            results.append(ModuleResult(
                module_name=mname,
                module_version="1.0",
                run_timestamp=_utc_now(),
                status=status,
                findings=[],
                raw_data={"statistics": entry.get("statistics") or {}},
                error_message=error_msg,
                terminal_output=terminal_out,
                execution_outcome=_execution_outcome,
                summary=str(entry.get("summary") or ""),
            ))
            _loaded_names.add(_norm(mname))
            logger.info("Created stub result for module: %s (status: %s)", mname, status_raw)

    if _pipeline_entries:
        logger.info("Pipeline manifest processed: %d module entries → %d total results",
                    len(_pipeline_entries), len(results))

    # ── Manifest supersedes the findings-less report.json stub ────────────────
    # A report.json entry that carried run metadata but no findings was appended
    # above as a placeholder and NOT allowed to block manifests.  When a manifest
    # for the same module was subsequently loaded (it holds the real findings for
    # one or more exhibits), drop the empty report.json placeholder so the module
    # is not double-listed and its findings are attributed per exhibit.
    _manifest_names = {
        r.module_name for r in results
        if not (isinstance(r.raw_data, dict) and r.raw_data.get("_source") == "report_json")
    }
    if _manifest_names:
        results = [
            r for r in results
            if not (
                isinstance(r.raw_data, dict)
                and r.raw_data.get("_source") == "report_json"
                and not r.findings
                and r.module_name in _manifest_names
            )
        ]

    if not results:
        logger.warning(
            "No module manifest files found in %s — report will show no findings.", case_dir
        )

    # Inject terminal_output from terminal_output.txt files for any result still empty
    for r in results:
        if not r.terminal_output:
            # Look for terminal_output.txt in module_output subdirs
            safe_name = r.module_name.lower().replace(" ", "_").replace("/", "_")
            for candidate_dir in case_dir.rglob("module_output"):
                txt = candidate_dir / safe_name / "terminal_output.txt"
                if txt.exists():
                    r.terminal_output = txt.read_text(encoding="utf-8")
                    break

    # Final attribution pass — resolve any result not covered by a per-manifest
    # signal (e.g. modules loaded from the combined report.json).  Count of
    # evidence items is discovered from descriptors, never assumed.
    _attribute_findings_to_evidence(results, descriptors)

    # Totalisation — after every signal-based attribution above (evNN, hash,
    # path) has had its chance, stamp any residual orphan from an authoritative
    # on-disk acquisition record.  Must run last so the stronger signals win.
    _finalise_attribution(results, descriptors, Path(case_dir), logger)

    # Consolidate legacy display-name aliases after attribution so findings from
    # all source manifests retain their exhibit references.
    results = _consolidate_module_aliases(results, logger)

    # Apply evidence-restraint semantics to both fresh and historical manifests.
    # This permits report-only regeneration without carrying forward known
    # overstatements from a previous module version.
    results = _assurance_normalise_loaded_findings(results)

    # Inject severity pie chart into the first module's raw_data
    all_findings = [f for r in results for f in r.findings]
    if all_findings and results:
        chart = _chart_severity_pie(all_findings)
        if chart:
            results[0].raw_data["_chart_severity"] = chart

    # Inject timeline chart into the first module that has timeline entries
    all_timeline = [te for r in results for te in r.timeline_entries]
    if all_timeline:
        chart = _chart_timeline(all_timeline)
        if chart:
            for r in results:
                if r.timeline_entries:
                    r.raw_data["_chart_timeline"] = chart
                    break

    return results


def collect_module_screenshots(case_dir: Path) -> list[dict]:
    """
    Scan case_dir for screenshots_index.json files written by module screenshot
    capture, and return a flat list of {figure_id, path, caption} dicts sorted
    by figure_id.
    """
    screenshots: list[dict] = []
    for idx_path in sorted(case_dir.rglob("screenshots_index.json")):
        try:
            entries = json.loads(idx_path.read_text(encoding="utf-8"))
            for entry in entries:
                png_path = Path(entry.get("path", ""))
                if png_path.is_file():
                    caption = str(entry.get("caption", "") or "")
                    if "registry" in caption.lower() and "hive" in caption.lower():
                        caption = (
                            "Registry-hive search output. Interpret with the module outcome; "
                            "a zero-result screen means no registry hives were identified, not that hive locations were shown."
                        )
                    screenshots.append({
                        "figure_id": entry.get("figure_id", ""),
                        "path":      str(png_path),
                        "caption":   caption,
                    })
        except Exception as exc:
            _logger.warning("Failed to load screenshots_index from %s: %s", idx_path, exc)
    screenshots.sort(key=lambda x: x.get("figure_id", ""))
    return screenshots


def load_evidence_acquisition(case_dir: Path) -> list[EvidenceAcquisition]:
    """
    Load evidence acquisition records from evidence_info.json if present,
    or synthesise a minimal record from disk_analysis.json.

    Parameters
    ----------
    case_dir:
        Root of the case output directory.

    Returns
    -------
    list[EvidenceAcquisition]
        Evidence records for embedding in the report.  Empty list if none found.
    """
    from datetime import date as _date

    # Try explicit evidence_info.json
    evidence_json = case_dir / "evidence_info.json"
    if evidence_json.exists():
        try:
            with open(evidence_json, encoding="utf-8") as f:
                items = json.load(f)
            if isinstance(items, dict):
                items = [items]
            results = []
            for item in items:
                acq_date_raw = item.get("acquisition_date", "")
                try:
                    acq_date = _date.fromisoformat(acq_date_raw)
                except (ValueError, TypeError):
                    acq_date = _date.today()
                results.append(EvidenceAcquisition(
                    exhibit_number=item.get("exhibit_number"),
                    description=item.get("description", "Digital evidence"),
                    acquisition_date=acq_date,
                    acquisition_method=item.get("acquisition_method", "DD image"),
                    tool_used=item.get("tool_used", "dd"),
                    tool_version=item.get("tool_version", "unknown"),
                    md5_hash=item.get("md5_hash", ""),
                    sha256_hash=item.get("sha256_hash", ""),
                    sha1_hash=item.get("sha1_hash", ""),
                    md5_reference=item.get("md5_reference", ""),
                    sha1_reference=item.get("sha1_reference", ""),
                    sha256_reference=item.get("sha256_reference", ""),
                    source_container_path=item.get("source_container_path", item.get("path", "")),
                    source_container_md5=item.get("source_container_md5", ""),
                    source_container_sha1=item.get("source_container_sha1", ""),
                    source_container_sha256=item.get("source_container_sha256", ""),
                    source_container_size_bytes=int(item.get("source_container_size_bytes", item.get("source_size_bytes", 0)) or 0),
                    source_container_hash_basis=item.get("source_container_hash_basis", "source-file-bytes"),
                    logical_media_size_bytes=int(item.get("logical_media_size_bytes", item.get("image_size_bytes", 0)) or 0),
                    source_size_bytes=int(item.get("source_size_bytes", 0)),
                    image_size_bytes=int(item.get("image_size_bytes", 0)),
                    acquired_by=item.get("acquired_by", "AutoForensics"),
                    verified=item.get("verified", False),
                    notes=item.get("notes", ""),
                ))
            return results
        except Exception as exc:
            _logger.warning("Failed to load evidence_info.json: %s", exc)

    # Synthesise from disk_analysis.json if present
    disk_analysis = next(case_dir.rglob("disk_analysis.json"), None)
    if disk_analysis:
        try:
            with open(disk_analysis, encoding="utf-8") as f:
                data = json.load(f)
            return [EvidenceAcquisition(
                exhibit_number=None,
                description=f"Forensic disk image: {Path(data.get('image_path', 'unknown')).name}",
                acquisition_date=_date.today(),
                acquisition_method="Raw sector-by-sector DD image",
                tool_used="AutoForensics Disk Analyzer",
                tool_version="1.0",
                md5_hash=data.get("image_md5", ""),
                sha256_hash=data.get("image_sha256", ""),
                source_size_bytes=int(data.get("image_size_bytes", 0)),
                image_size_bytes=int(data.get("image_size_bytes", 0)),
                acquired_by="AutoForensics",
                verified=bool(data.get("image_sha256")),
                notes="Image analyzed by AutoForensics tools/analyze_image.py",
            )]
        except Exception as exc:
            _logger.warning("Failed to synthesise evidence from disk_analysis.json: %s", exc)

    return []


def _render_hash_verification_image(
    evidence_items: list,
) -> "ContentBlock | None":
    """
    Render a forensic hash verification table as a PNG image ContentBlock.

    Produces a dark-themed matplotlib figure with alternating-row table
    showing exhibit numbers, MD5, and SHA-256 for each evidence item.
    Returns None if matplotlib is unavailable or the list is empty.
    """
    if not _MPL or not evidence_items:
        return None

    headers = ["Exhibit", "Description", "MD5 (first 16)", "SHA-256 (first 32)", "Verified"]
    rows = []
    for e in evidence_items:
        md5_short = (getattr(e, "md5_hash", None) or "N/A")[:16] + "…"
        sha_short = (getattr(e, "sha256_hash", None) or "N/A")[:32] + "…"
        verified = "✓ VERIFIED" if getattr(e, "verified", False) else "UNVERIFIED"
        rows.append([
            getattr(e, "exhibit_number", "N/A"),
            (getattr(e, "description", "") or "")[:30],
            md5_short,
            sha_short,
            verified,
        ])

    fig_h = max(2.0, len(rows) * 0.7 + 1.5)
    fig, ax = plt.subplots(figsize=(10, fig_h))
    fig.patch.set_facecolor("#1A2744")
    ax.set_facecolor("#F4F6F9")
    ax.axis("off")

    tbl = ax.table(
        cellText=rows,
        colLabels=headers,
        loc="center",
        cellLoc="left",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    tbl.scale(1, 1.6)

    for col in range(len(headers)):
        cell = tbl[0, col]
        cell.set_facecolor("#1A2744")
        cell.set_text_props(color="white", fontweight="bold")

    for row_idx in range(1, len(rows) + 1):
        bg = "#FFFFFF" if row_idx % 2 == 1 else "#E8EEF4"
        for col in range(len(headers)):
            tbl[row_idx, col].set_facecolor(bg)
        verified_val = rows[row_idx - 1][4]
        tbl[row_idx, 4].set_text_props(
            color="#1E8449" if "VERIFIED" in verified_val and "UN" not in verified_val else "#C0392B",
            fontweight="bold",
        )

    ax.set_title(
        "Hash Verification Record — Evidence Integrity Confirmation",
        color="white", fontsize=10, fontweight="bold",
        x=0.5, y=1.04, ha="center", transform=ax.transAxes,
    )

    b64 = _savefig_b64(fig, dpi=120, facecolor=fig.get_facecolor())

    return ContentBlock(
        block_type="chart_image",
        data={"data_b64": b64, "label": "Hash Verification Record", "width_mm": 160},
    )


# ---------------------------------------------------------------------------
# Module evidence image renderers — shared helper + 13 per-module functions
# ---------------------------------------------------------------------------

def _chart_table_image(
    title: str,
    headers: list,
    rows: list,
    label: str,
    width_mm: int = 155,
    dpi: int = 120,
) -> "ContentBlock | None":
    """Render a styled table as a dark-themed PNG ContentBlock."""
    if not _MPL or not rows:
        return None
    try:
        nrows = len(rows)
        fig_h = max(2.5, nrows * 0.45 + 1.2)
        fig, ax = plt.subplots(figsize=(12, fig_h))
        fig.patch.set_facecolor("#1A2744")
        ax.set_facecolor("#F4F6F9")
        ax.axis("off")
        tbl = ax.table(cellText=rows, colLabels=headers, loc="center", cellLoc="left")
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(7.5)
        tbl.scale(1, 1.5)
        for col in range(len(headers)):
            cell = tbl[0, col]
            cell.set_facecolor("#1A2744")
            cell.set_text_props(color="white", fontweight="bold")
        for r in range(1, nrows + 1):
            bg = "#FFFFFF" if r % 2 == 1 else "#E8EEF4"
            for col in range(len(headers)):
                tbl[r, col].set_facecolor(bg)
        ax.set_title(title, color="white", fontsize=10, fontweight="bold",
                     x=0.5, y=1.03, ha="center", transform=ax.transAxes)
        b64 = _savefig_b64(fig, dpi=dpi, facecolor=fig.get_facecolor())
        return ContentBlock(block_type="chart_image",
                            data={"data_b64": b64, "label": label, "width_mm": width_mm})
    except Exception as exc:
        _logger.warning("_chart_table_image failed for %r: %s", label, exc)
        return None


def _render_file_system_tree_image(module_result) -> "ContentBlock | None":
    """Image 1: File system listing — path, size, modified timestamp."""
    files = (module_result.raw_data or {}).get("file_listing", [])
    if not files:
        return None
    rows = []
    for f in files[:25]:
        path = str(f.get("path", f.get("name", "N/A")))[-50:]
        size = f.get("size", 0)
        size_str = f"{size:,}" if isinstance(size, int) else str(size)
        mtime = str(f.get("modified", f.get("mtime", "N/A")))[:19]
        rows.append([path, size_str, mtime])
    return _chart_table_image(
        "File System Listing (first 25 files)",
        ["Path", "Size (bytes)", "Modified (UTC)"],
        rows, label="File System Tree",
    )


def _render_user_accounts_image(module_result) -> "ContentBlock | None":
    """Image 2: User accounts table."""
    users = (module_result.raw_data or {}).get("user_accounts", [])
    if not users:
        return None
    rows = [[
        str(u.get("username", u.get("name", "N/A"))),
        str(u.get("uid", u.get("id", "N/A"))),
        str(u.get("last_login", u.get("last_logon", "N/A")))[:19],
        str(u.get("groups", u.get("group", "N/A"))),
    ] for u in users[:20]]
    return _chart_table_image(
        "User Accounts", ["Username", "UID", "Last Login", "Groups"],
        rows, label="User Accounts",
    )


def _render_deleted_files_image(module_result) -> "ContentBlock | None":
    """Image 3: Deleted / recovered files table."""
    files = (module_result.raw_data or {}).get(
        "deleted_files", (module_result.raw_data or {}).get("recovered_files", []))
    if not files:
        return None
    rows = [[
        str(f.get("path", f.get("name", "N/A")))[-50:],
        str(f.get("size", "N/A")),
        str(f.get("deleted_at", f.get("mtime", "N/A")))[:19],
        str(f.get("status", "recovered")),
    ] for f in files[:20]]
    return _chart_table_image(
        "Deleted / Recovered Files",
        ["Path", "Size", "Deleted At", "Status"],
        rows, label="Deleted Files",
    )


def _render_registry_hives_image(module_result) -> "ContentBlock | None":
    """Image 4: Registry hive entries."""
    hives = (module_result.raw_data or {}).get(
        "registry_keys", (module_result.raw_data or {}).get("hives", []))
    if not hives:
        return None
    rows = [[
        str(h.get("hive", h.get("key_path", "N/A")))[-50:],
        str(h.get("value_name", h.get("name", "N/A")))[:30],
        str(h.get("data", h.get("value", "N/A")))[:40],
    ] for h in hives[:20]]
    return _chart_table_image(
        "Registry Hive Entries",
        ["Hive / Key Path", "Value Name", "Data"],
        rows, label="Registry Hives",
    )


def _render_keyword_hits_image(module_result) -> "ContentBlock | None":
    """Image 5: Keyword / IOC match hits."""
    hits = (module_result.raw_data or {}).get(
        "keyword_hits", (module_result.raw_data or {}).get("ioc_hits", []))
    if not hits:
        return None
    rows = [[
        str(h.get("keyword", h.get("term", "N/A"))),
        str(h.get("file", h.get("source", "N/A")))[-40:],
        str(h.get("context", h.get("match", "N/A")))[:50],
    ] for h in hits[:20]]
    return _chart_table_image(
        "Keyword / IOC Hits",
        ["Keyword", "Source File", "Context"],
        rows, label="Keyword Hits",
    )


def _render_suspicious_files_image(module_result) -> "ContentBlock | None":
    """Image 6: Suspicious files table."""
    suspicious = (module_result.raw_data or {}).get(
        "suspicious_files", (module_result.raw_data or {}).get("malware_hits", []))
    if not suspicious:
        return None
    rows = [[
        str(f.get("path", f.get("name", "N/A")))[-45:],
        str(f.get("reason", f.get("indicator", "N/A")))[:40],
        (str(f.get("sha256", f.get("hash", "N/A")))[:32] + "…"),
    ] for f in suspicious[:20]]
    return _chart_table_image(
        "Suspicious Files",
        ["Path", "Indicator", "SHA-256 (first 32)"],
        rows, label="Suspicious Files",
    )


def _render_carved_files_image(module_result) -> "ContentBlock | None":
    """Image 7: Carved files from scalpel/foremost results."""
    carved = (module_result.raw_data or {}).get(
        "carved_files", (module_result.raw_data or {}).get("recovered_files", []))
    if not carved:
        return None
    rows = [[
        str(f.get("file_type", f.get("extension", "N/A"))),
        str(f.get("filename", f.get("name", "N/A")))[-40:],
        str(f.get("size_bytes", f.get("size", "N/A"))),
        str(f.get("offset", "N/A")),
    ] for f in carved[:20]]
    return _chart_table_image(
        "Carved Files (File Carving Results)",
        ["Type", "Filename", "Size (bytes)", "Offset"],
        rows, label="Carved Files",
    )


def _render_string_analysis_image(module_result) -> "ContentBlock | None":
    """Image 8: String analysis hits."""
    strings = (module_result.raw_data or {}).get(
        "strings", (module_result.raw_data or {}).get("string_hits", []))
    if not strings:
        return None
    rows = []
    for s in strings[:25]:
        if isinstance(s, dict):
            rows.append([str(s.get("value", s.get("string", "N/A")))[:60],
                         str(s.get("offset", "N/A"))])
        else:
            rows.append([str(s)[:60], "N/A"])
    return _chart_table_image(
        "String Analysis — Notable Strings Extracted",
        ["String Value", "Offset"],
        rows, label="String Analysis",
    )


def _render_anti_forensic_image(module_result) -> "ContentBlock | None":
    """Image 9: Anti-forensic indicators."""
    indicators = (module_result.raw_data or {}).get(
        "anti_forensic_indicators", (module_result.raw_data or {}).get("indicators", []))
    if not indicators:
        return None
    rows = [[
        str(i.get("type", i.get("indicator_type", "N/A"))),
        str(i.get("description", i.get("detail", "N/A")))[:60],
        str(i.get("severity", "Medium")),
    ] for i in indicators[:20]]
    return _chart_table_image(
        "Anti-Forensic Indicators",
        ["Type", "Description", "Severity"],
        rows, label="Anti-Forensic Indicators",
    )


def _render_tools_table_image(tools: list) -> "ContentBlock | None":
    """Image 10: Tools and software inventory."""
    if not _MPL or not tools:
        return None
    rows = [[
        t.name, t.version, t.vendor, t.purpose[:40],
        t.validation_reference or "N/A",
    ] for t in tools[:15]]
    return _chart_table_image(
        "Forensic Tools and Software Inventory",
        ["Tool", "Version", "Vendor", "Purpose", "Runtime Note"],
        rows, label="Tools Table",
    )


def _render_severity_bar_image(module_result) -> "ContentBlock | None":
    """Image 11: Per-module finding severity distribution bar chart."""
    if not _MPL or not module_result.findings:
        return None
    try:
        from collections import Counter
        counts = Counter(f.severity.value for f in module_result.findings)
        labels = ["Critical", "High", "Medium", "Low"]
        values = [counts.get(l, 0) for l in labels]
        colours = ["#C0392B", "#D35400", "#D4AC0D", "#1E8449"]
        fig, ax = plt.subplots(figsize=(7, 3))
        fig.patch.set_facecolor("#1A2744")
        ax.set_facecolor("#F4F6F9")
        bars = ax.bar(labels, values, color=colours, edgecolor="white", linewidth=0.5)
        ax.set_title(f"{module_result.module_name} — Finding Severity Distribution",
                     color="white", fontsize=10, fontweight="bold", pad=8)
        ax.set_ylabel("Count", color="#CCCCCC")
        ax.tick_params(colors="#CCCCCC")
        for spine in ax.spines.values():
            spine.set_edgecolor("#CCCCCC")
        for bar, val in zip(bars, values):
            if val > 0:
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
                        str(val), ha="center", va="bottom", color="white", fontsize=9)
        b64 = _savefig_b64(fig, dpi=120, facecolor=fig.get_facecolor())
        return ContentBlock(block_type="chart_image",
                            data={"data_b64": b64,
                                  "label": f"{module_result.module_name} Severity Distribution",
                                  "width_mm": 140})
    except Exception as exc:
        _logger.warning("_render_severity_bar_image failed for %r: %s",
                        module_result.module_name, exc)
        return None


def _render_network_ioc_image(module_result) -> "ContentBlock | None":
    """Image 12: Network IOC / connection log table."""
    raw = module_result.raw_data or {}
    # network_map is a list of {"entry", "type", "value", "note"} dicts written by
    # criminal_network_mapper; "connections"/"network_events" are used by other modules.
    connections = raw.get("connections") or raw.get("network_events") or raw.get("network_map") or []
    if not connections or not isinstance(connections, list):
        return None
    sample = connections[0]
    if isinstance(sample, dict) and "type" in sample and "value" in sample:
        rows = [[
            str(c.get("type", "N/A")),
            str(c.get("value", "N/A"))[:60],
            str(c.get("note", "")),
        ] for c in connections[:20]]
        return _chart_table_image(
            "Criminal Network Indicators",
            ["Type", "Value", "Note"],
            rows, label="Network IOC Map",
        )
    rows = [[
        str(c.get("remote_ip", c.get("ip", c.get("dst_ip", "N/A")))),
        str(c.get("port", c.get("dst_port", "N/A"))),
        str(c.get("protocol", c.get("proto", "TCP"))),
        str(c.get("timestamp", c.get("time", "N/A")))[:19],
        str(c.get("bytes_sent", c.get("bytes", "N/A"))),
    ] for c in connections[:20]]
    return _chart_table_image(
        "Network Connections / IOC Events",
        ["Remote IP", "Port", "Protocol", "Timestamp", "Bytes"],
        rows, label="Network IOC Events",
    )


def _render_timeline_evidence_image(module_result) -> "ContentBlock | None":
    """Image 13: Timeline of events hourly distribution bar chart."""
    if not _MPL:
        return None
    try:
        from collections import Counter
        hours: list = []
        for entry in module_result.timeline_entries:
            ts = entry.timestamp
            if ts:
                hours.append(ts.hour)
        if not hours:
            return None
        counts = Counter(hours)
        h_labels = [f"{h:02d}:00" for h in range(24)]
        h_values = [counts.get(h, 0) for h in range(24)]
        fig, ax = plt.subplots(figsize=(12, 3.5))
        fig.patch.set_facecolor("#1A2744")
        ax.set_facecolor("#F4F6F9")
        ax.bar(h_labels, h_values, color="#2980B9", edgecolor="white", linewidth=0.3)
        ax.set_title(f"{module_result.module_name} — Event Timeline (Hourly Distribution)",
                     color="white", fontsize=10, fontweight="bold", pad=8)
        ax.set_xlabel("Hour (UTC)", color="#CCCCCC")
        ax.set_ylabel("Events", color="#CCCCCC")
        ax.tick_params(axis="x", rotation=45, colors="#CCCCCC", labelsize=7)
        ax.tick_params(axis="y", colors="#CCCCCC")
        for spine in ax.spines.values():
            spine.set_edgecolor("#CCCCCC")
        b64 = _savefig_b64(fig, dpi=120, facecolor=fig.get_facecolor())
        return ContentBlock(block_type="chart_image",
                            data={"data_b64": b64,
                                  "label": f"{module_result.module_name} Timeline",
                                  "width_mm": 155})
    except Exception as exc:
        _logger.warning("_render_timeline_evidence_image failed for %r: %s",
                        module_result.module_name, exc)
        return None
