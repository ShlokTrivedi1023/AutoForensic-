"""Canonical count schema shared by ledgers, certificates, reports and H2 audit.

The schema is deliberately case-neutral.  It counts retained runtime records and
never reads expected answers, validation tables or corpus-specific constants.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

CANONICAL_COUNT_SCHEMA = "autoforensics-canonical-counts-v1"
CANONICAL_COUNT_FIELDS: tuple[str, ...] = (
    "accepted_findings",
    "candidate_observations",
    "rejected_observations",
    "unresolved_observations",
    "source_paths",
    "unique_byte_streams",
    "semantic_objects",
    "physical_occurrences",
    "aliases",
    "parser_errors",
    "skipped_items",
    "limitations",
)

COUNT_UNITS: dict[str, str] = {
    "accepted_findings": "accepted-finding",
    "candidate_observations": "candidate-observation",
    "rejected_observations": "rejected-observation",
    "unresolved_observations": "unresolved-observation",
    "source_paths": "distinct-source-path",
    "unique_byte_streams": "sha256-distinct-byte-stream",
    "semantic_objects": "canonical-semantic-object",
    "physical_occurrences": "physical-occurrence",
    "aliases": "alias-representation",
    "parser_errors": "parser-error",
    "skipped_items": "skipped-item",
    "limitations": "declared-limitation",
}


class CountSchemaError(ValueError):
    """Raised when a required canonical count is absent or malformed."""


@dataclass(frozen=True)
class CountSchemaValidation:
    valid: bool
    errors: tuple[str, ...]


def _as_nonnegative_int(value: Any, *, field: str, strict: bool) -> int:
    if isinstance(value, bool):
        value = int(value)
    try:
        result = int(value)
    except (TypeError, ValueError):
        if strict:
            raise CountSchemaError(f"{field}: expected an integer count, received {value!r}")
        return 0
    if result < 0:
        if strict:
            raise CountSchemaError(f"{field}: count must be non-negative, received {result}")
        return 0
    return result


def _get_nested(mapping: Mapping[str, Any], *paths: Sequence[str]) -> Any:
    for path in paths:
        value: Any = mapping
        found = True
        for key in path:
            if not isinstance(value, Mapping) or key not in value:
                found = False
                break
            value = value[key]
        if found and value not in (None, ""):
            return value
    return None


def _first_count(stats: Mapping[str, Any], names: Iterable[str]) -> int | None:
    blocks: tuple[Mapping[str, Any], ...] = tuple(
        block for block in (
            stats,
            stats.get("canonical_counts") if isinstance(stats, Mapping) else None,
            stats.get("canonical_result") if isinstance(stats, Mapping) else None,
            stats.get("module_statistics") if isinstance(stats, Mapping) else None,
            stats.get("deterministic_reconciliation") if isinstance(stats, Mapping) else None,
            stats.get("coverage") if isinstance(stats, Mapping) else None,
        ) if isinstance(block, Mapping)
    )
    for name in names:
        for block in blocks:
            if name in block and block[name] not in (None, ""):
                try:
                    value = int(block[name])
                except (TypeError, ValueError):
                    continue
                return max(0, value)
    return None


def _record_mapping(value: Any) -> Mapping[str, Any] | None:
    if isinstance(value, Mapping):
        return value
    if value is None:
        return None
    keys = ("finding_id", "finding_type", "description", "evidence_path", "artifact_path", "metadata")
    record = {key: getattr(value, key) for key in keys if hasattr(value, key)}
    return record or None


def _iter_records(value: Any) -> list[Mapping[str, Any]]:
    if value is None:
        return []
    if isinstance(value, Mapping):
        for key in ("candidates", "observations", "records", "items"):
            nested = value.get(key)
            if isinstance(nested, list):
                return [record for item in nested if (record := _record_mapping(item)) is not None]
        return [value]
    if isinstance(value, (list, tuple)):
        return [record for item in value if (record := _record_mapping(item)) is not None]
    record = _record_mapping(value)
    return [record] if record is not None else []


def ledger_state_counts(records: Any) -> dict[str, int]:
    """Count the four canonical ledger states without inferring missing states."""
    counts = {"ACCEPTED": 0, "CANDIDATE": 0, "REJECTED": 0, "UNRESOLVED": 0}
    for record in _iter_records(records):
        metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
        state = str(record.get("ledger_state") or metadata.get("ledger_state") or "").upper().strip()
        if state in counts:
            counts[state] += 1
    return counts


def _source_path(record: Mapping[str, Any]) -> str:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    for value in (
        metadata.get("provenance_source_path"), metadata.get("retained_source_path"),
        metadata.get("source_path"), metadata.get("analysis_source"),
        record.get("evidence_path"), record.get("source_path"),
    ):
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _digest(record: Mapping[str, Any]) -> str:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    for value in (
        metadata.get("source_hash"), metadata.get("file_sha256"), metadata.get("sha256"),
        record.get("sha256"),
    ):
        text = str(value or "").lower().strip()
        if len(text) == 64 and all(ch in "0123456789abcdef" for ch in text):
            return text
    return ""


def _semantic_id(record: Mapping[str, Any]) -> str:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    for value in (
        metadata.get("semantic_object_id"), metadata.get("evidence_object_id"),
        metadata.get("canonical_object_id"), record.get("finding_id"),
    ):
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _physical_occurrence_count(record: Mapping[str, Any]) -> int:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    occurrences = metadata.get("physical_occurrences")
    if isinstance(occurrences, list):
        return len(occurrences)
    for key in ("physical_occurrence_count", "occurrence_count"):
        if metadata.get(key) not in (None, ""):
            try:
                return max(0, int(metadata[key]))
            except (TypeError, ValueError):
                pass
    return 1


def _alias_count(record: Mapping[str, Any]) -> int:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    total = 0
    for key in ("aliases", "source_aliases", "duplicate_aliases", "duplicate_tool_aliases", "recovery_aliases"):
        value = metadata.get(key)
        if isinstance(value, list):
            total += len(value)
    return total


def build_canonical_counts(
    *,
    accepted_findings: Any = None,
    candidate_records: Any = None,
    statistics: Mapping[str, Any] | None = None,
    limitations: Any = None,
) -> dict[str, int]:
    """Build the one canonical count dictionary used by every assurance layer.

    Runtime records are preferred. ``source_paths`` is the union of distinct
    source locations represented by accepted findings and every retained
    non-accepted ledger record (candidate, rejected or unresolved). Exact module
    counters are used only when a record-derived value is unavailable; unrelated
    units are never combined.
    """
    accepted = _iter_records(accepted_findings)
    candidates = _iter_records(candidate_records)
    stats: Mapping[str, Any] = statistics or {}
    states = ledger_state_counts(candidates)
    if not candidates:
        states["CANDIDATE"] = _first_count(stats, ("candidate_observations", "CANDIDATE")) or 0
        states["REJECTED"] = _first_count(stats, ("rejected_observations", "REJECTED")) or 0
        states["UNRESOLVED"] = _first_count(stats, ("unresolved_observations", "UNRESOLVED")) or 0

    source_values = {path for record in accepted + candidates if (path := _source_path(record))}
    digest_values = {digest for record in accepted if (digest := _digest(record))}
    semantic_values = {sid for record in accepted if (sid := _semantic_id(record))}

    source_paths = len(source_values)
    if not source_values:
        source_paths = _first_count(stats, ("source_paths", "distinct_source_paths")) or 0

    unique_byte_streams = len(digest_values)
    if not digest_values:
        unique_byte_streams = _first_count(stats, ("unique_byte_streams",)) or 0

    semantic_objects = len(semantic_values)
    if not semantic_values:
        semantic_objects = _first_count(stats, (
            "semantic_objects", "canonical_semantic_objects", "unique_evidence_objects",
        )) or 0

    physical_occurrences = sum(_physical_occurrence_count(record) for record in accepted)
    if not accepted:
        physical_occurrences = _first_count(stats, ("physical_occurrences",)) or 0

    aliases = sum(_alias_count(record) for record in accepted)
    if aliases == 0:
        aliases = _first_count(stats, (
            "aliases", "duplicate_aliases", "duplicate_representations",
            "duplicate_image_aliases", "duplicate_physical_occurrences",
        )) or 0

    parser_errors = _first_count(stats, ("parser_errors", "parse_errors", "decode_errors")) or 0
    skipped_items = _first_count(stats, (
        "skipped_items", "skipped_objects", "invalid_candidates_skipped",
    )) or 0

    if limitations is None:
        limitations_value = stats.get("limitations") if isinstance(stats, Mapping) else None
    else:
        limitations_value = limitations
    if isinstance(limitations_value, (list, tuple, set)):
        limitation_count = len(limitations_value)
    elif isinstance(limitations_value, str):
        limitation_count = 1 if limitations_value.strip() else 0
    elif limitations_value in (None, ""):
        limitation_count = _first_count(stats, ("limitation_count",)) or 0
    else:
        try:
            limitation_count = max(0, int(limitations_value))
        except (TypeError, ValueError):
            limitation_count = 0

    return {
        "accepted_findings": len(accepted),
        "candidate_observations": states["CANDIDATE"],
        "rejected_observations": states["REJECTED"],
        "unresolved_observations": states["UNRESOLVED"],
        "source_paths": source_paths,
        "unique_byte_streams": unique_byte_streams,
        "semantic_objects": semantic_objects,
        "physical_occurrences": physical_occurrences,
        "aliases": aliases,
        "parser_errors": parser_errors,
        "skipped_items": skipped_items,
        "limitations": limitation_count,
    }


def count_units(counts: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    validate_canonical_counts(counts, raise_on_error=True)
    return {
        field: {"count": int(counts[field]), "unit": COUNT_UNITS[field]}
        for field in CANONICAL_COUNT_FIELDS
    }


def validate_canonical_counts(
    counts: Mapping[str, Any], *, raise_on_error: bool = False
) -> CountSchemaValidation:
    errors: list[str] = []
    if not isinstance(counts, Mapping):
        errors.append("canonical counts must be a mapping")
    else:
        missing = [field for field in CANONICAL_COUNT_FIELDS if field not in counts]
        if missing:
            errors.append("missing required count field(s): " + ", ".join(missing))
        for field in CANONICAL_COUNT_FIELDS:
            if field not in counts:
                continue
            try:
                _as_nonnegative_int(counts[field], field=field, strict=True)
            except CountSchemaError as exc:
                errors.append(str(exc))
    result = CountSchemaValidation(valid=not errors, errors=tuple(errors))
    if raise_on_error and errors:
        raise CountSchemaError("; ".join(errors))
    return result


def counts_from_certificate(certificate: Mapping[str, Any]) -> dict[str, int]:
    """Read canonical counts from a completion certificate, fail-closed."""
    block = certificate.get("canonical_counts")
    if isinstance(block, Mapping):
        counts = {field: block.get(field) for field in CANONICAL_COUNT_FIELDS}
    else:
        units = certificate.get("count_units") if isinstance(certificate.get("count_units"), Mapping) else {}
        counts = {}
        for field in CANONICAL_COUNT_FIELDS:
            unit = units.get(field) if isinstance(units, Mapping) else None
            if isinstance(unit, Mapping) and "count" in unit:
                counts[field] = unit.get("count")
            elif field in certificate:
                counts[field] = certificate.get(field)
    validate_canonical_counts(counts, raise_on_error=True)
    return {field: int(counts[field]) for field in CANONICAL_COUNT_FIELDS}
