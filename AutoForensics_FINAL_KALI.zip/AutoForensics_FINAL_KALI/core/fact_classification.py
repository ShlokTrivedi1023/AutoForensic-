"""Canonical forensic fact classification and evidence-object identity.

The investigation engine may retain primary evidence, validated decoded evidence,
derived interpretations and aggregate summaries in one module result.  Those
classes are not interchangeable for counting.  This module supplies a single,
generic classification and identity policy so derived/cross-module records cannot
inflate unique-evidence totals.

No case identifier, fixture filename, expected hash or MASTER value is used.
"""
from __future__ import annotations

from enum import Enum
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable


class FactClass(str, Enum):
    PRIMARY_EVIDENCE = "PRIMARY_EVIDENCE"
    VERIFIED_DECODED_EVIDENCE = "VERIFIED_DECODED_EVIDENCE"
    DERIVED_FACT = "DERIVED_FACT"
    AGGREGATE_SUMMARY = "AGGREGATE_SUMMARY"
    ALTERNATIVE_REPRESENTATION = "ALTERNATIVE_REPRESENTATION"
    CANDIDATE_ONLY = "CANDIDATE_ONLY"
    REJECTED = "REJECTED"
    SCOPED_ABSENCE = "SCOPED_ABSENCE"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    VERIFY_LATER = "VERIFY_LATER"


UNIQUE_EVIDENCE_CLASSES = {
    FactClass.PRIMARY_EVIDENCE.value,
    FactClass.VERIFIED_DECODED_EVIDENCE.value,
}

_DERIVED_MODULES = {
    "criminal_network_mapper",
    "anti_forensic_detector",
}

_AGGREGATE_MODULES = {
    "timeline_builder",
}

# These modules ordinarily produce interpretations of already parsed primary
# objects.  A module may override this by setting an explicit fact_class.
_INTERPRETIVE_MODULES = {
    "suspicious_file_detector",
}

_DECODED_TYPES = (
    "DECRYPT", "PASSWORD_RECOVERED", "LSB_", "APPENDED_", "ARCHIVE_MEMBER",
    "HTTP_", "DNS_", "BROWSER_", "EMAIL_", "MOBILE_", "REGISTRY_",
    "DOCUMENT_", "PDF_", "OOXML_", "METADATA_", "FILE_SIGNATURE",
    "DELETED_FILE_RECOVERED", "CARVED_FILE_STRUCTURALLY_VALIDATED",
)


def _enum_value(value: Any) -> str:
    return str(getattr(value, "value", value) or "")


def _normalise_path(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    # Preserve logical path case while removing run-local duplicate separators.
    text = re.sub(r"/{2,}", "/", text)
    return text


def _stable_json(value: Any) -> str:
    def clean(obj: Any) -> Any:
        if obj is None or isinstance(obj, (str, int, float, bool)):
            return obj
        if isinstance(obj, Path):
            return str(obj)
        if isinstance(obj, dict):
            return {str(k): clean(v) for k, v in sorted(obj.items(), key=lambda kv: str(kv[0]))}
        if isinstance(obj, (list, tuple)):
            return [clean(v) for v in obj]
        if isinstance(obj, (set, frozenset)):
            return sorted((clean(v) for v in obj), key=lambda v: json.dumps(v, sort_keys=True, default=str))
        return str(obj)
    return json.dumps(clean(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _first(metadata: dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        value = metadata.get(key)
        if value not in (None, "", [], {}):
            return value
    return ""


def classify_fact(module_name: str, finding: Any) -> str:
    """Return one canonical fact class for an accepted or candidate record."""
    _metadata_raw = getattr(finding, "metadata", {}) or {}
    metadata = dict(_metadata_raw) if isinstance(_metadata_raw, dict) else {}
    explicit = str(metadata.get("fact_class") or "").upper().strip()
    if explicit in {item.value for item in FactClass}:
        return explicit

    basis = str(metadata.get("finding_basis") or "").casefold()
    if (
        metadata.get("candidate_only") is True
        or metadata.get("deterministic_validation") is False
        or basis in {"candidate", "heuristic", "probabilistic", "statistical", "model"}
    ):
        return FactClass.CANDIDATE_ONLY.value

    ftype = str(getattr(finding, "finding_type", "") or "").upper()
    module = str(module_name or "").casefold()

    if ftype in {"SCOPED_ABSENCE", "VERIFIED_ABSENCE"}:
        return FactClass.SCOPED_ABSENCE.value
    if module in _DERIVED_MODULES:
        return (
            FactClass.AGGREGATE_SUMMARY.value
            if metadata.get("source_finding_ids") or ftype.endswith("_SUMMARY")
            else FactClass.DERIVED_FACT.value
        )
    if module in _AGGREGATE_MODULES:
        return FactClass.AGGREGATE_SUMMARY.value
    if module in _INTERPRETIVE_MODULES:
        return FactClass.DERIVED_FACT.value
    if metadata.get("duplicate_of") or metadata.get("alternative_representation"):
        return FactClass.ALTERNATIVE_REPRESENTATION.value
    if any(token in ftype for token in _DECODED_TYPES):
        return FactClass.VERIFIED_DECODED_EVIDENCE.value
    return FactClass.PRIMARY_EVIDENCE.value


def evidence_object_components(module_name: str, finding: Any) -> dict[str, Any]:
    """Build a stable, evidence-driven identity basis for one forensic fact.

    The identity deliberately excludes run-local finding UUIDs, module runtime
    timestamps and output paths.  It favours source hashes and exact locators.
    """
    _metadata_raw = getattr(finding, "metadata", {}) or {}
    metadata = dict(_metadata_raw) if isinstance(_metadata_raw, dict) else {}
    _reference_raw = getattr(finding, "evidence_reference", {}) or {}
    reference = dict(_reference_raw) if isinstance(_reference_raw, dict) else {}
    _locators_raw = reference.get("locators") or {}
    locators = dict(_locators_raw) if isinstance(_locators_raw, dict) else {"legacy_locator": str(_locators_raw)}
    _location_raw = reference.get("artefact_location") or {}
    artefact_location = dict(_location_raw) if isinstance(_location_raw, dict) else {"path": str(_location_raw)}

    source_hash = _first(metadata, (
        "file_sha256", "source_sha256", "artifact_sha256", "recovered_sha256",
        "source_report_sha256", "image_sha256", "database_sha256",
    )) or _first(reference, (
        "artefact_sha256", "source_container_sha256", "source_evidence_sha256",
        "logical_media_sha256",
    ))
    source_path = _first(metadata, (
        "logical_path", "original_path", "source_file", "file_path", "database",
        "image_file", "archive_path", "mobile_source",
    )) or _first(artefact_location, ("path", "source_path", "file_path")) \
       or getattr(finding, "evidence_path", "")

    locator_keys = (
        "semantic_record_id", "logical_record_id", "record_identity",
        "byte_offset", "offset", "offset_bytes", "source_offset", "logical_end_offset",
        "cluster", "start_cluster", "first_cluster", "chain", "packet", "packet_number",
        "frame_number", "tcp_stream", "transaction_id", "direction", "method",
        "status_code", "table", "rowid", "row", "line", "line_number",
        "occurrence_index", "match_offset", "message_id", "json_path", "field_name",
        "metadata_namespace", "namespace", "property", "registry_key", "key_path",
        "value_name", "archive_member", "member_name", "record_id", "record_number",
        "inode", "timestamp", "date", "sender", "recipient",
    )
    locator: dict[str, Any] = {}
    for key in locator_keys:
        value = metadata.get(key, locators.get(key, artefact_location.get(key)))
        if value not in (None, "", [], {}):
            locator[key] = value

    material_value = _first(metadata, (
        "semantic_record_id", "logical_record_id", "record_identity",
        "algorithm", "hash_algorithm", "computed_hash", "embedded_hash",
        "identifier_value", "keyword", "match", "query", "domain", "answer",
        "url", "uri", "subject", "sender", "recipient", "from", "to",
        "message", "body", "text", "record_type", "method", "status_code",
        "metadata_field", "field_name", "metadata_value", "value_data", "value",
        "plaintext", "password", "decoded_payload", "coordinate", "latitude",
        "longitude", "declared_type", "detected_type", "member_name",
        "event_type", "semantic_object",
    ))
    if material_value in (None, "", [], {}):
        # Final semantic discriminator for records whose module has not yet
        # emitted a dedicated record id. Exact duplicate prose still groups,
        # while distinct facts from the same source remain distinct.
        material_value = re.sub(r"\s+", " ", str(getattr(finding, "description", "") or "")).strip()
    ftype = str(getattr(finding, "finding_type", "") or "")
    fact_class = classify_fact(module_name, finding)

    # Derived records are identified by the exact accepted findings from which
    # they were computed; primary identity remains source+locator+value based.
    derived_from = metadata.get("source_finding_ids") or metadata.get("derived_from") or []
    if isinstance(derived_from, str):
        derived_from = [derived_from]

    return {
        "source_hash": str(source_hash or "").casefold(),
        "source_path": _normalise_path(source_path),
        "locator": locator,
        "finding_type": ftype,
        "material_value": material_value,
        "fact_class": fact_class,
        "derived_from": sorted(str(v) for v in derived_from if v),
    }


def evidence_object_id(module_name: str, finding: Any) -> str:
    components = evidence_object_components(module_name, finding)
    digest = hashlib.sha256(_stable_json(components).encode("utf-8")).hexdigest()
    return f"eo-{digest[:32]}"


def duplicate_identity(module_name: str, finding: Any) -> str:
    """Return a cross-module identity that ignores representation/module labels."""
    components = evidence_object_components(module_name, finding)
    components.pop("fact_class", None)
    # Exact source+locator+material value is the duplicate boundary.  A different
    # semantic finding type may still be a distinct fact about the same object.
    components["finding_type"] = str(components.get("finding_type") or "").upper()
    digest = hashlib.sha256(_stable_json(components).encode("utf-8")).hexdigest()
    return f"dup-{digest[:32]}"


def annotate_finding(module_name: str, finding: Any) -> Any:
    """Attach canonical fact/counting metadata without altering evidence values."""
    _metadata_raw = getattr(finding, "metadata", {}) or {}
    metadata = dict(_metadata_raw) if isinstance(_metadata_raw, dict) else {}
    fact_class = classify_fact(module_name, finding)
    metadata["fact_class"] = fact_class
    metadata["responsible_module"] = str(module_name)
    metadata.setdefault("evidence_object_id", evidence_object_id(module_name, finding))
    metadata.setdefault("duplicate_identity", duplicate_identity(module_name, finding))
    if fact_class in {FactClass.DERIVED_FACT.value, FactClass.AGGREGATE_SUMMARY.value}:
        source_ids = metadata.get("source_finding_ids") or metadata.get("derived_from") or []
        if isinstance(source_ids, str):
            source_ids = [source_ids]
        metadata["derived_from"] = sorted(str(v) for v in source_ids if v)
        metadata["counts_toward_unique_evidence"] = False
    elif fact_class in UNIQUE_EVIDENCE_CLASSES:
        metadata["counts_toward_unique_evidence"] = True
    else:
        metadata["counts_toward_unique_evidence"] = False
    finding.metadata = metadata
    return finding


def annotate_findings(module_name: str, findings: Iterable[Any]) -> list[Any]:
    return [annotate_finding(module_name, finding) for finding in findings]
