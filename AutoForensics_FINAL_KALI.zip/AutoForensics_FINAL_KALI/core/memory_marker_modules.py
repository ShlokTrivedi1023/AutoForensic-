"""Deterministic marker-scope execution for memory-related modules.

Disk images may contain memory-like files with exact structured test or export
records without containing a genuine RAM acquisition.  These records are
forensically examinable as literal content, but they are not kernel objects.
This adapter lets each relevant module complete its marker scope while keeping
Volatility structural analysis explicitly NOT_APPLICABLE.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib

from core.deterministic_memory import canonical_marker_sources
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

_RECORD_SCOPE: dict[str, dict[str, tuple[str, Severity]]] = {
    "memory_process_list": {
        "process_marker": ("MEMORY_PROCESS_MARKER", Severity.INFO),
        "hidden_process_marker": ("HIDDEN_PROCESS_MARKER", Severity.MEDIUM),
    },
    "memory_network_connections": {
        "network_marker": ("MEMORY_NETWORK_MARKER", Severity.INFO),
        "dns_marker": ("MEMORY_DNS_MARKER", Severity.INFO),
        "url_marker": ("MEMORY_URL_MARKER", Severity.INFO),
    },
    "memory_artifact_extractor": {
        "credential_marker": ("MEMORY_CREDENTIAL_MARKER", Severity.MEDIUM),
        "api_key_marker": ("MEMORY_API_KEY_MARKER", Severity.MEDIUM),
        "keyword_marker": ("MEMORY_KEYWORD_MARKER", Severity.INFO),
        "os_banner_marker": ("MEMORY_OS_BANNER_MARKER", Severity.INFO),
        "kernel_debugger_marker": ("MEMORY_KERNEL_DEBUGGER_MARKER", Severity.INFO),
        "validation_marker": ("MEMORY_VALIDATION_MARKER", Severity.INFO),
    },
    "memory_malware_scanner": {
        "malware_test_marker": ("MEMORY_MALWARE_TEST_MARKER", Severity.INFO),
    },
    "rootkit_detector": {
        "rootkit_marker": ("ROOTKIT_TEST_MARKER", Severity.INFO),
        "hidden_process_marker": ("HIDDEN_PROCESS_TEST_MARKER", Severity.INFO),
    },
}


def marker_capable_modules() -> frozenset[str]:
    return frozenset(_RECORD_SCOPE)


def _safe_metadata(record: dict[str, Any]) -> dict[str, Any]:
    excluded = {"raw_text", "password", "value"}
    safe = {k: v for k, v in record.items() if k not in excluded}
    if record.get("record_type") == "credential_marker":
        password = str(record.get("password") or "")
        safe["password_sha256"] = hashlib.sha256(password.encode("utf-8")).hexdigest() if password else ""
        safe["password_length"] = len(password)
        safe["restricted_content"] = True
    elif record.get("record_type") in {"api_key_marker"}:
        value = str(record.get("value") or "")
        safe["value_sha256"] = hashlib.sha256(value.encode("utf-8")).hexdigest() if value else ""
        safe["value_length"] = len(value)
        safe["restricted_content"] = True
    else:
        if record.get("value") not in (None, ""):
            safe["marker_value"] = record.get("value")
    return safe


def _description(module_name: str, record: dict[str, Any]) -> str:
    record_type = str(record.get("record_type") or "structured_marker")
    source = Path(str(record.get("source_file") or "memory-like source")).name
    return (
        f"Exact {record_type.replace('_', ' ')} record found in {source} at byte offset "
        f"{record.get('byte_offset', 0)}. This proves the literal record exists; it does not "
        "by itself establish a live operating-system process, socket, malware infection or rootkit."
    )


def run_marker_scope(
    *,
    module_name: str,
    case_id: str,
    marker_paths: list[str] | list[Path],
) -> ModuleResult:
    start = utc_now()
    mapping = _RECORD_SCOPE.get(module_name, {})
    parsed_sources = canonical_marker_sources(Path(p) for p in marker_paths if Path(p).is_file())
    findings = []
    parse_errors = 0
    total_records = 0
    supported_records = 0
    artifacts: list[str] = []

    for source in parsed_sources:
        if source.get("error"):
            parse_errors += 1
            continue
        source_path = str(source.get("path") or "")
        if source_path:
            artifacts.append(source_path)
        records = list(source.get("records") or [])
        total_records += len(records)
        for record in records:
            record_type = str(record.get("record_type") or "")
            spec = mapping.get(record_type)
            if not spec:
                continue
            supported_records += 1
            finding_type, severity = spec
            metadata = {
                **_safe_metadata(record),
                "finding_basis": "deterministic",
                "deterministic_validation": True,
                "validation_method": "exact structured marker grammar with source byte offset",
                "semantic_limit": (
                    "Literal marker presence only; no operating-system object or real-world attribution is inferred."
                ),
                "file_sha256": source.get("file_sha256"),
                "marker_fingerprint": source.get("marker_fingerprint"),
                "source_offset_cluster_packet_or_row": {
                    "byte_offset": record.get("byte_offset"),
                    "byte_length": record.get("byte_length"),
                },
            }
            findings.append(make_finding(
                finding_type=finding_type,
                severity=severity,
                description=_description(module_name, record),
                evidence_path=source_path,
                artifact_path=None,
                metadata=metadata,
            ))

    marker_verdict = AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT
    end = utc_now()
    stats = {
        "analysis_mode": "STRUCTURED_MEMORY_MARKER_SCOPE",
        "memory_sources_examined": len(parsed_sources),
        "sources_discovered": len(parsed_sources),
        "sources_processed": len(parsed_sources) - parse_errors,
        "supported_objects_discovered": len(parsed_sources),
        "supported_objects_processed": len(parsed_sources) - parse_errors,
        "records_discovered": supported_records,
        "records_processed": supported_records,
        "all_marker_records_seen": total_records,
        "unsupported_objects": 0,
        "parser_errors": parse_errors,
        "timeouts": 0,
        "unresolved_items": 0,
        "marker_scope_completed": parse_errors == 0,
        "structural_memory_applicable": False,
        "volatility_scope_status": "NOT_APPLICABLE",
        "execution_outcome": "ran_found_x" if findings else "ran_found_nothing",
    }
    status = ModuleStatus.COMPLETED if parse_errors == 0 else ModuleStatus.PARTIAL
    return ModuleResult(
        module_name=module_name,
        case_id=case_id,
        status=status,
        start_time=start,
        end_time=end,
        findings=findings,
        artifact_paths=sorted(set(artifacts)),
        errors=[] if parse_errors == 0 else [f"{parse_errors} marker source(s) could not be parsed"],
        statistics=stats,
        summary=(
            f"Examined {len(parsed_sources)} canonical memory-marker source(s) and processed "
            f"{supported_records} record(s) in the declared {module_name} marker scope. "
            "Genuine RAM structural analysis was not applicable to these marker-only files."
        ),
        class_results=[
            ClassResult(
                locus=Locus.MEMORY,
                artefact_class=f"{module_name.replace('_', ' ').title()} — structured marker records",
                verdict=marker_verdict,
                count=len(findings),
                notes="Exact marker grammar and source offsets examined exhaustively.",
            ),
            ClassResult(
                locus=Locus.MEMORY,
                artefact_class=f"{module_name.replace('_', ' ').title()} — genuine RAM structures",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NOT_APPLICABLE,
                count=0,
                notes="No genuine supported RAM acquisition was supplied; marker files cannot establish kernel structures.",
            ),
        ],
    )


def augment_with_marker_scope(
    result: ModuleResult,
    *,
    module_name: str,
    case_id: str,
    marker_paths: list[str] | list[Path],
) -> ModuleResult:
    marker_result = run_marker_scope(module_name=module_name, case_id=case_id, marker_paths=marker_paths)
    result.findings.extend(marker_result.findings)
    result.artifact_paths = sorted(set((result.artifact_paths or []) + marker_result.artifact_paths))
    stats = dict(result.statistics or {})
    stats["marker_scope"] = dict(marker_result.statistics or {})
    stats["marker_scope_completed"] = marker_result.status == ModuleStatus.COMPLETED
    # Aggregate explicit completion counters without hiding structural failures.
    stats["sources_discovered"] = int(stats.get("sources_discovered") or 0) + int(marker_result.statistics.get("sources_discovered") or 0)
    stats["sources_processed"] = int(stats.get("sources_processed") or 0) + int(marker_result.statistics.get("sources_processed") or 0)
    stats["records_discovered"] = int(stats.get("records_discovered") or 0) + int(marker_result.statistics.get("records_discovered") or 0)
    stats["records_processed"] = int(stats.get("records_processed") or 0) + int(marker_result.statistics.get("records_processed") or 0)
    result.statistics = stats
    result.class_results.extend(marker_result.class_results[:1])
    if marker_result.errors:
        result.errors.extend(marker_result.errors)
    return result
