"""Source-role classification and corpus iteration for forensic evidence.

The platform distinguishes original/retained evidentiary content from files that
control the analysis, validation/ground-truth references, case-context documents,
and tool-generated derivatives.  This prevents scanners and correlation modules
from treating their own output or an answer/configuration file as corroborating
case evidence.

The classification is generic.  It uses runtime roots, object types, structured
headers and source location.  It contains no case identifiers or planted values.
"""
from __future__ import annotations

import csv
import hashlib
import re
from enum import Enum
from pathlib import Path
from typing import Any, Iterable, Iterator


class SourceRole(str, Enum):
    EVIDENTIARY_CONTENT = "EVIDENTIARY_CONTENT"
    CASE_CONTEXT = "CASE_CONTEXT"
    ANALYSIS_CONFIGURATION = "ANALYSIS_CONFIGURATION"
    VALIDATION_REFERENCE = "VALIDATION_REFERENCE"
    DERIVED_TOOL_OUTPUT = "DERIVED_TOOL_OUTPUT"
    UNKNOWN = "UNKNOWN"


_VALIDATION_DIR_NAMES = {
    "validation", "ground_truth", "groundtruth", "answer_key", "reference",
    "references", "expected", "fixtures", "test_fixture", "test_fixtures",
}
_VALIDATION_NAME_TOKENS = {
    "ground_truth", "groundtruth", "answer_key", "expected_result", "expected_results",
    "test_matrix", "module_matrix", "validation_matrix", "master_reference",
    "supported_formats", "coverage_matrix",
}
_VALIDATION_HEADER_TOKENS = {
    "expected", "expected_result", "expected_status", "ground_truth", "answer",
    "answer_key", "planted", "planted_or_prerequisite", "reference_value",
    "should_detect", "expected_count", "expected_hash", "expected_path",
}
_CONTEXT_NAME_TOKENS = {"readme", "scope", "limitations", "manifest", "provenance"}


def _resolve(path: Path) -> Path:
    try:
        return path.resolve()
    except OSError:
        return path.absolute()


def _is_under(path: Path, root: Path) -> bool:
    try:
        _resolve(path).relative_to(_resolve(root))
        return True
    except (ValueError, OSError):
        return False


def _path_parts(path: Path) -> set[str]:
    return {part.casefold() for part in path.parts}


def _name_tokens(path: Path) -> set[str]:
    stem = re.sub(r"[^a-z0-9]+", "_", path.stem.casefold()).strip("_")
    return set(stem.split("_")) | {stem}


def _csv_header(path: Path) -> set[str]:
    try:
        with path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
            sample = handle.read(64 * 1024)
        dialect = csv.Sniffer().sniff(sample[:4096], delimiters=",\t;|")
        row = next(csv.reader(sample.splitlines(), dialect=dialect), [])
    except (OSError, csv.Error, StopIteration):
        return set()
    return {
        re.sub(r"[^a-z0-9]+", "_", str(value).casefold()).strip("_")
        for value in row if str(value).strip()
    }


def infer_inventory_source_role(
    path: Path,
    *,
    object_type: str = "",
    subtype: str = "",
    header: bytes | None = None,
) -> tuple[SourceRole, str]:
    """Classify a retained source before module execution.

    Detection rules are deliberately conservative.  A file becomes a validation
    reference only when its location/name and structured content support that
    role.  A generic README/scope document is retained as case context rather
    than discarded.
    """
    path = Path(path)
    object_type_l = str(object_type).casefold()
    subtype_l = str(subtype).casefold()
    if object_type_l == "detection_config" or subtype_l in {
        "yara_rules", "clamav_ndb", "hash_list", "ioc_list", "wordlist", "keyword_list",
    }:
        return SourceRole.ANALYSIS_CONFIGURATION, "Recognised scanner/search configuration syntax"

    parts = _path_parts(path)
    tokens = _name_tokens(path)
    in_validation_location = bool(parts & _VALIDATION_DIR_NAMES)
    validation_named = bool(tokens & _VALIDATION_NAME_TOKENS)

    if path.suffix.casefold() in {".csv", ".tsv"}:
        fields = _csv_header(path)
        if (in_validation_location or validation_named) and fields & _VALIDATION_HEADER_TOKENS:
            return SourceRole.VALIDATION_REFERENCE, "Validation-like location/name plus expected/ground-truth columns"
        if validation_named and len(fields) >= 2:
            return SourceRole.VALIDATION_REFERENCE, "Validation matrix/reference filename and structured table"

    if in_validation_location and tokens & _CONTEXT_NAME_TOKENS:
        return SourceRole.CASE_CONTEXT, "Scope/readme/limitations document retained as case context"

    # Explicit validation/reference names are not ordinary corroborating content,
    # even when they use plain text rather than a table.
    if validation_named and in_validation_location:
        return SourceRole.VALIDATION_REFERENCE, "Validation/reference path and filename"

    return SourceRole.EVIDENTIARY_CONTENT, "Original retained content from the evidence filesystem"


def _inventory_role_index(working_set: dict[str, Any] | None) -> dict[str, str]:
    """Return the runtime inventory role index with deterministic caching.

    Source-role classification may be invoked thousands of times for specialist
    carver output. Rebuilding the complete inventory index for every finding
    changes no answer but causes O(findings × inventory_objects) work.
    """
    ws = working_set or {}
    inventory = ws.get("evidence_inventory") or {}
    objects = inventory.get("objects") or []

    cache = ws.get("_source_role_inventory_index_cache")
    if isinstance(cache, dict):
        if (
            cache.get("inventory_identity") == id(inventory)
            and cache.get("object_count") == len(objects)
            and isinstance(cache.get("index"), dict)
        ):
            return cache["index"]

    index: dict[str, str] = {}
    for obj in objects:
        value = obj.get("path")
        role = obj.get("source_role")
        if value and role:
            index[str(_resolve(Path(str(value))))] = str(role)

    if working_set is not None:
        ws["_source_role_inventory_index_cache"] = {
            "inventory_identity": id(inventory),
            "object_count": len(objects),
            "index": index,
        }

    return index


def source_role_for_path(
    path: Path,
    working_set: dict[str, Any] | None,
    *,
    output_dir: Path | None = None,
) -> SourceRole:
    """Return the runtime role of ``path``.

    Primary evidence roots override the fact that extraction directories live
    inside the case output directory.  Tool-generated module roots are always
    derivative unless explicitly materialised as a primary evidence root.
    """
    path = _resolve(Path(path))
    ws = working_set or {}

    # The exact read-only logical media stream (for example libewf's ewf1)
    # is an evidentiary lineage target for byte-offset findings. It is kept
    # separate from primary corpus roots so scanners do not treat the entire
    # block image as an ordinary extracted file.
    logical_media_stream = ws.get("logical_media_stream")
    if logical_media_stream:
        try:
            if path == _resolve(Path(str(logical_media_stream))):
                return SourceRole.EVIDENTIARY_CONTENT
        except (OSError, ValueError):
            pass

    # Inventory classification carries *semantic* provenance.  A file can be
    # physically retained inside an evidence image while still being an
    # analysis configuration, validation reference, or case-context document.
    # Those roles must remain non-corroborating.  Conversely, an inventory entry
    # must never turn an ordinary original evidence object into derived output
    # merely because the extraction directory happens to live below the case
    # output tree.
    index = _inventory_role_index(ws)
    indexed_role: SourceRole | None = None
    indexed = index.get(str(path))
    if indexed:
        try:
            indexed_role = SourceRole(indexed)
        except ValueError:
            indexed_role = None

    primary_roots = [Path(str(v)) for v in (
        ws.get("primary_evidence_roots") or []
    ) if v]
    primary_roots += [Path(str(v)) for v in (
        ws.get("mounted_fs_root"), ws.get("native_deleted_root")
    ) if v]
    for root in primary_roots:
        if (root.is_dir() and _is_under(path, root)) or (root.is_file() and path == _resolve(root)):
            if indexed_role in {
                SourceRole.ANALYSIS_CONFIGURATION,
                SourceRole.VALIDATION_REFERENCE,
                SourceRole.CASE_CONTEXT,
            }:
                return indexed_role
            return SourceRole.EVIDENTIARY_CONTENT

    if indexed_role is not None:
        return indexed_role

    derived_roots = [Path(str(v)) for v in (ws.get("derived_corpus_roots") or []) if v]
    for root in derived_roots:
        if root.is_dir() and _is_under(path, root):
            return SourceRole.DERIVED_TOOL_OUTPUT

    if output_dir is not None:
        try:
            case_root = _resolve(Path(output_dir)).parents[2]
        except IndexError:
            case_root = _resolve(Path(output_dir)).parent
        for name in ("module_output", "reports", "logs", "evidence_inventory", "native_media"):
            root = case_root / name
            if root.exists() and _is_under(path, root):
                return SourceRole.DERIVED_TOOL_OUTPUT

    return SourceRole.UNKNOWN


def iter_corpus_files(
    roots: Iterable[Path],
    working_set: dict[str, Any] | None,
    *,
    output_dir: Path | None = None,
    allowed_roles: set[SourceRole] | None = None,
    deduplicate_by_hash: bool = False,
) -> Iterator[Path]:
    """Yield regular corpus files whose provenance role is allowed."""
    allowed = allowed_roles or {SourceRole.EVIDENTIARY_CONTENT}
    seen_paths: set[str] = set()
    seen_hashes: set[str] = set()
    for root_value in roots:
        root = Path(root_value)
        if root.is_file():
            candidates = [root]
        elif root.is_dir():
            candidates = sorted(
                (p for p in root.rglob("*") if p.is_file() and not p.is_symlink()),
                key=lambda p: p.as_posix(),
            )
        else:
            continue
        for path in candidates:
            resolved = str(_resolve(path))
            if resolved in seen_paths:
                continue
            seen_paths.add(resolved)
            role = source_role_for_path(path, working_set, output_dir=output_dir)
            # Files under primary roots that predate a v3 inventory can be
            # UNKNOWN; treat those as evidence for backward compatibility.
            if role == SourceRole.UNKNOWN:
                ws = working_set or {}
                primary_values = list(ws.get("primary_evidence_roots") or [])
                if not primary_values:
                    primary_values.extend(ws.get("corpus_roots") or [])
                    primary_values.extend(v for v in (
                        ws.get("mounted_fs_root"), ws.get("native_deleted_root"),
                        ws.get("extracted_files_dir"), ws.get("tsk_recover_dir"),
                    ) if v)
                primary = [Path(str(v)) for v in primary_values if v]
                if any(_is_under(path, r) for r in primary):
                    role = SourceRole.EVIDENTIARY_CONTENT
            if role not in allowed:
                continue
            if deduplicate_by_hash:
                try:
                    h = hashlib.sha256()
                    with path.open("rb") as fh:
                        for block in iter(lambda: fh.read(1024 * 1024), b""):
                            h.update(block)
                    digest = h.hexdigest()
                except OSError:
                    continue
                if digest in seen_hashes:
                    continue
                seen_hashes.add(digest)
            yield path


def provenance_metadata(path: Path, working_set: dict[str, Any] | None, *, output_dir: Path | None = None) -> dict[str, str]:
    role = source_role_for_path(path, working_set, output_dir=output_dir)
    return {
        "source_role": role.value,
        "source_role_policy": (
            "Only EVIDENTIARY_CONTENT may support ordinary canonical case findings; "
            "configuration, validation references and derived output are non-corroborating."
        ),
    }
