# core/report_appendices.py
"""
Appendix section builders for AutoForensics.

Each build_appendix_* function returns a SectionContent ready for the PDF renderer.
All functions accept optional file paths — missing files produce placeholder text
rather than raising exceptions.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .report_sections import ContentBlock, SectionContent, integrity_verdict

_logger = logging.getLogger("autoforensics.appendices")

_DUMMY_WARNING = "DUMMY VALIDATION MATERIAL — INGESTION TEST ONLY — NOT VERIFIED"

def _dummy_validation_material(case_config: Any) -> bool:
    """Return True only when the case explicitly labels attachments as dummy/test material."""
    if case_config is None:
        return False
    raw = getattr(case_config, "_raw", {}) or {}
    notes = raw.get("validation_notes", {}) if isinstance(raw, dict) else {}
    values = [
        getattr(case_config, "case_title", ""),
        getattr(case_config, "investigation_background", ""),
        json.dumps(notes, sort_keys=True) if isinstance(notes, dict) else str(notes),
    ]
    text = " ".join(str(v or "") for v in values).lower()
    return "dummy" in text and ("validation" in text or "ingestion" in text or "test" in text)

def _dummy_warning_block() -> ContentBlock:
    return ContentBlock("paragraph", {"text": _DUMMY_WARNING})

def _attachment_caption(case_config: Any, ordinary: str) -> str:
    return f"{_DUMMY_WARNING} — {ordinary}" if _dummy_validation_material(case_config) else ordinary



def _is_synthetic_case(case_config: Any) -> bool:
    if case_config is None:
        return False
    values = [
        getattr(case_config, "classification", ""),
        getattr(case_config, "case_title", ""),
        getattr(case_config, "investigation_background", ""),
    ]
    raw = getattr(case_config, "_raw", {}) or {}
    if isinstance(raw, dict):
        values.extend([raw.get("classification", ""), raw.get("case_title", "")])
    text = " ".join(str(v or "") for v in values).lower()
    return any(token in text for token in ("synthetic", "validation", "test fixture", "training exhibit"))

def _pdf_to_temp_png(pdf_path: Path) -> Optional[str]:
    """Convert first page of a PDF to a temporary PNG via wand. Returns PNG path or None."""
    try:
        from wand.image import Image as _WandImage  # type: ignore
        import tempfile
        with _WandImage(filename=f"{pdf_path}[0]", resolution=150) as img:
            img.format = "png"
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                img.save(filename=tf.name)
                return tf.name
    except Exception:
        return None


def _safe_img_block(path: str, caption: str) -> Optional[ContentBlock]:
    """Return an image_path block if file exists, else None. Converts PDF → PNG via wand."""
    if not path:
        return None
    p = Path(path)
    if not p.is_file():
        return None
    # PIL cannot read PDFs — convert first page to PNG via wand
    if p.suffix.lower() == ".pdf":
        png_path = _pdf_to_temp_png(p)
        if png_path:
            return ContentBlock("image_path", {"path": png_path, "caption": caption, "width_mm": 140})
        return None
    return ContentBlock("image_path", {"path": path, "caption": caption, "width_mm": 140})


def _build_case_notes_table(case_config: Any, coc_entries: list) -> ContentBlock:
    """Build case notes only from recorded events; never invent handling events."""
    rows: list[list[str]] = []
    for entry in coc_entries:
        ts = str(entry.get("timestamp", ""))[:25].replace("T", " ")
        stage = str(entry.get("event_type", "")).replace("_", " ").title()
        narr = str(entry.get("description", ""))[:500]
        rows.append([ts or "—", stage or "Recorded Event", narr or "—"])

    if not rows:
        rows.append([
            "—", "No recorded custody/case-note events",
            "No chain-of-custody or case-note ledger was supplied to the report generator. "
            "No receipt, seal, write-blocker, acquisition, transfer, storage, or physical-handling event is inferred."
        ])

    return ContentBlock("table", {
        "headers": ["Date/Time", "Recorded Stage", "Recorded Narrative"],
        "rows": rows,
    })

def _find_coc_file(case_config: Any, case_id: str) -> Optional[Path]:
    """Return an explicitly configured custody ledger; do not search host-specific paths."""
    candidates: list[Path] = []
    if case_config:
        # A photographed/signed CoC form is an attachment, not an automated ledger,
        # but it may still be displayed in the relevant appendix.
        supp = getattr(case_config, "supplementary", None)
        for owner in (case_config, supp):
            if owner is None:
                continue
            for attr in (
                "custody_log", "custody_ledger", "custody_jsonl",
                "chain_of_custody_log", "chain_of_custody_json",
            ):
                value = getattr(owner, attr, "")
                if value:
                    candidates.append(Path(str(value)).expanduser())
        raw = getattr(case_config, "_raw", None)
        if isinstance(raw, dict):
            for key in (
                "custody_log", "custody_ledger", "custody_jsonl",
                "chain_of_custody_log", "chain_of_custody_json",
            ):
                value = raw.get(key)
                if value:
                    candidates.append(Path(str(value)).expanduser())
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None

def _find_evidence_bag_photo(case_config: Any) -> Optional[Path]:
    """Check config keys for evidence bag photo. Uses pathlib — no shell escaping."""
    if not case_config:
        return None
    supp = case_config.supplementary
    for p_str in (supp.evidence_bag_photos or []):
        p = Path(p_str)
        if p.is_file():
            return p
    for attr in ("evidence_bag_photo", "evidence_bag_photograph", "evidence_photo_path"):
        p_str = getattr(supp, attr, "")
        if p_str:
            p = Path(p_str)
            if p.is_file():
                return p
    return None


def _embed_auth_letter(letter_path: Path, blocks: list, caption: str = "") -> None:
    """Convert and embed authorisation letter. Handles PDF, PNG, JPG, DOCX."""
    suffix = letter_path.suffix.lower()
    if not caption:
        caption = _attachment_caption(
        case_config,
        "Appendix D.1 — Authorisation-letter attachment; authority is subject to independent verification.",
    )

    if suffix in (".png", ".jpg", ".jpeg", ".bmp"):
        blocks.append(ContentBlock("image_path", {
            "path": str(letter_path), "caption": caption, "width_mm": 170,
        }))
        return

    if suffix == ".pdf":
        try:
            from wand.image import Image as _WandImage  # type: ignore
            import tempfile
            with _WandImage(filename=f"{letter_path}[0]", resolution=150) as img:
                img.format = "png"
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                    img.save(filename=tf.name)
                    blocks.append(ContentBlock("image_path", {
                        "path": tf.name, "caption": caption, "width_mm": 170,
                    }))
            return
        except ImportError:
            pass
        except Exception:
            pass

    if suffix == ".docx":
        import subprocess
        import shutil
        import tempfile
        if shutil.which("libreoffice"):
            with tempfile.TemporaryDirectory() as td:
                subprocess.run(
                    ["libreoffice", "--headless", "--convert-to", "pdf",
                     "--outdir", td, str(letter_path)],
                    capture_output=True, timeout=60,
                )
                pdf_out = Path(td) / (letter_path.stem + ".pdf")
                if pdf_out.is_file():
                    _embed_auth_letter(pdf_out, blocks, caption=caption)
                    return

    blocks.append(ContentBlock("paragraph", {
        "text": f"[Authorisation letter — could not convert {letter_path.name}. Attach manually.]"
    }))


# ────────────────────────────────────────────────────────────────────────────
# Appendix A — Examiner Declaration
# ────────────────────────────────────────────────────────────────────────────

def _evidence_integrity_status(ev: Any) -> str:
    """Derive one integrity status string from a single evidence record.

    Routes through ``integrity_verdict`` — the single source of truth §3.3 also
    uses — recomputed from the recorded hash/reference values, so the examiner
    declaration and §3.3 can never disagree.  Never assumes VERIFIED.
    """
    return {
        "VERIFIED":        "MEDIA HASH VERIFIED against embedded acquisition hash",
        "MISMATCH":        "MEDIA HASH MISMATCH against embedded acquisition hash",
        "COMPUTED_NO_REF": "MEDIA HASH COMPUTED — NO EMBEDDED REFERENCE",
        "NOT_COMPUTED":    "NOT VERIFIED — media hash not computed",
    }[integrity_verdict(ev)]


def build_appendix_declaration(
    case_config: Any = None,
    investigator: Any = None,
    metadata: Any = None,
    coc_entries: Optional[list] = None,
    coc_logger: Any = None,
    all_evidence_results: Optional[list] = None,
    evidence_items: Optional[list] = None,
) -> SectionContent:
    """Appendix A — Case Notes + Examiner Declaration, fully populated from CaseConfig."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX A — CASE NOTES"}))

    # Technical processing and cryptographic report signing do not replace
    # human authorisation, physical-custody records or examiner signatures.
    # Surface one unambiguous status sentence whenever any required attachment
    # is not actually present at report-generation time.
    missing_admin: list[str] = []
    supp = getattr(case_config, "supplementary", None) if case_config else None
    admin_fields = (
        ("authorisation letter", getattr(supp, "authorisation_letter", "") if supp else ""),
        ("chain-of-custody form", getattr(supp, "coc_form_image", "") if supp else ""),
        ("examiner signature", getattr(supp, "examiner_signature", "") if supp else ""),
        ("supervisor signature", getattr(supp, "supervisor_signature", "") if supp else ""),
    )
    for label, value in admin_fields:
        if not value or not Path(str(value)).expanduser().is_file():
            missing_admin.append(label)
    bag_photos = list(getattr(supp, "evidence_bag_photos", []) or []) if supp else []
    if not any(Path(str(value)).expanduser().is_file() for value in bag_photos):
        missing_admin.append("evidence-bag photographs")
    if missing_admin:
        blocks.append(ContentBlock("paragraph", {"text": (
            "Administrative appendices incomplete — unsigned draft. Missing or unavailable: "
            + ", ".join(missing_admin) + "."
        )}))

    ex_name   = ""
    ex_inst   = ""
    ex_email  = ""
    ex_badge  = ""
    sup_name  = ""
    auth_name = ""
    case_num  = ""
    report_dt = ""
    ex_sig    = ""
    sup_sig   = ""

    if case_config:
        ex_name   = case_config.examiner.name
        ex_inst   = case_config.examiner.institution or case_config.org_name
        ex_email  = case_config.examiner.email
        ex_badge  = case_config.examiner.badge
        sup_name  = case_config.supervising_examiner.name
        auth_name = case_config.authorising_officer.name
        case_num  = case_config.case_number
        ex_sig    = case_config.supplementary.examiner_signature
        sup_sig   = case_config.supplementary.supervisor_signature
    if investigator:
        ex_name   = ex_name or getattr(investigator, "name", "")
        ex_inst   = ex_inst or getattr(investigator, "organisation", "")
        ex_badge  = ex_badge or getattr(investigator, "badge_number", "")
        sup_name  = sup_name or getattr(investigator, "supervisor_name", "")
    if metadata:
        case_num  = case_num or getattr(metadata, "case_number", "")
        report_dt = str(getattr(metadata, "report_date", ""))

    # ── A.1 Case Notes Log ────────────────────────────────────────────────
    # Resolve coc_entries from coc_logger if not supplied directly
    resolved_entries: list = coc_entries or []
    if not resolved_entries and coc_logger is not None:
        try:
            resolved_entries = coc_logger.entries_with_status()
        except Exception:
            resolved_entries = []
    blocks.append(ContentBlock("heading2", {"text": "A.1 — Case Notes Log"}))
    blocks.append(_build_case_notes_table(case_config, resolved_entries))

    # ── A.2 Examiner Declaration ──────────────────────────────────────────
    blocks.append(ContentBlock("heading2", {"text": "A.2 — Examiner Declaration"}))
    blocks.append(ContentBlock("paragraph", {"text": (
        "DRAFT DECLARATION — AutoForensics cannot make or sign an expert-witness "
        "declaration on behalf of an examiner. The named examiner must review the "
        "source artefacts, module caveats, acquisition provenance and conclusions, "
        "correct any error, and sign a separate declaration only if personally "
        "satisfied that it is accurate and complete. An unsigned generated report "
        "must not be represented as a completed expert declaration. A detached "
        "Ed25519 package signature is generated after PDF rendering when signing is "
        "required; that cryptographic signature proves file integrity and signer-key "
        "control, but it does not replace the examiner's personal expert declaration."
    )}))

    decl_rows = [
        ["Examiner Name",        ex_name or "—"],
        ["Institution",          ex_inst or "—"],
        ["Contact Email",        ex_email or "—"],
        ["Badge / Staff ID",     ex_badge or "—"],
        ["Supervising Examiner", sup_name or "—"],
        ["Authorising Officer",  auth_name or "—"],
        ["Case Number",          case_num or "—"],
        ["Report Date",          report_dt or "—"],
    ]
    # Per-evidence status rows.  The verification status is read from the SAME
    # per-item record that Section 3.3 renders (the EvidenceAcquisition items),
    # so the declaration never restates a status that could contradict §3.3.
    # It is never defaulted to "VERIFIED" — an unverified item says so.
    if evidence_items:
        for ev in evidence_items:
            label = (getattr(ev, "label", "") or getattr(ev, "device_label", "")
                     or getattr(ev, "evidence_path", "") or "Evidence")
            decl_rows.append([f"{Path(str(label)).name} Status",
                              _evidence_integrity_status(ev)])
    elif all_evidence_results:
        for ev_result in all_evidence_results:
            ev_path = ev_result.get("evidence_path", "Evidence")
            label   = Path(ev_path).name if ev_path else "Evidence"
            _hash_present = bool(ev_result.get("evidence_hash") or ev_result.get("sha256")
                                 or ev_result.get("md5"))
            # "VERIFIED" is only asserted when a computed digest was re-verified
            # against an embedded acquisition reference and matched.
            _matches = ev_result.get("hash_matches") or {}
            _has_reference = bool(ev_result.get("embedded_hashes"))
            _all_match = _has_reference and all(v == "MATCH" for v in _matches.values())
            _mismatch = any(v == "MISMATCH" for v in _matches.values())
            if _all_match:
                _integrity = "VERIFIED against embedded acquisition hash"
            elif _mismatch:
                _integrity = "MISMATCH against embedded acquisition hash"
            elif _hash_present:
                _integrity = "HASH COMPUTED, NO EMBEDDED REFERENCE"
            else:
                _integrity = "HASH NOT COMPUTED"
            if ev_result.get("fs_analysed", True):   # default True for backward compat
                status_text = _integrity
            else:
                status_text = f"FS PREFLIGHT FAILED — {_integrity} — FILESYSTEM NOT ANALYSED"
            decl_rows.append([f"{label} Status", status_text])
    else:
        decl_rows.append(["Evidence Status",
                          "NOT VERIFIED — no per-evidence integrity record available"])
    blocks.append(ContentBlock("table", {"headers": ["FIELD", "VALUE"], "rows": decl_rows}))

    blocks.append(ContentBlock("paragraph", {"text": "\n\n"}))
    if ex_sig and Path(ex_sig).is_file() and not _dummy_validation_material(case_config):
        sig_line = f"Examiner named: {ex_name.upper() or '—'}   Report date: {(report_dt or '—').upper()}"
    elif ex_sig and Path(ex_sig).is_file():
        sig_line = (
            f"Examiner named: {ex_name.upper() or '—'}   "
            "Dummy signature attachment supplied for ingestion testing; examiner approval is NOT VERIFIED"
        )
    else:
        sig_line = (
            f"Examiner named: {ex_name.upper() or '—'}   "
            "Signature: NOT SUPPLIED / NOT SIGNED"
        )
    blocks.append(ContentBlock("paragraph", {"text": sig_line}))
    if sup_name:
        blocks.append(ContentBlock("paragraph", {"text": f"Supervisory: {sup_name.upper()}"}))

    blocks.append(ContentBlock("spacer", {"height_mm": 6}))

    if ex_sig and Path(ex_sig).is_file() and _dummy_validation_material(case_config):
        blocks.append(_dummy_warning_block())
    img = _safe_img_block(ex_sig, _attachment_caption(case_config, "Examiner signature attachment"))
    if img:
        blocks.append(img)
    else:
        blocks.append(ContentBlock("paragraph", {"text": "[ Examiner signature not supplied to AutoForensics — attach wet signature copy ]"}))

    if sup_name or (sup_sig and Path(sup_sig).is_file()):
        blocks.append(ContentBlock("paragraph", {"text": (
            f"\nSupervisor named: {sup_name or 'NOT SPECIFIED'}" if not _dummy_validation_material(case_config)
            else "\nSupervisor attachment supplied for ingestion testing only; no countersignature or approval is inferred."
        )}))
        blocks.append(ContentBlock("spacer", {"height_mm": 6}))
        if sup_sig and Path(sup_sig).is_file() and _dummy_validation_material(case_config):
            blocks.append(_dummy_warning_block())
        simg = _safe_img_block(sup_sig, _attachment_caption(case_config, "Supervisor signature attachment"))
        if simg:
            blocks.append(simg)
        else:
            blocks.append(ContentBlock("paragraph", {"text": "[ Supervisor signature not supplied to AutoForensics — attach wet signature copy ]"}))

    return SectionContent(section_number=90, section_title="Appendix A — Case Notes", blocks=blocks)


# ────────────────────────────────────────────────────────────────────────────
# Appendix B — Chain of Custody
# ────────────────────────────────────────────────────────────────────────────

def build_appendix_chain_of_custody(
    coc_logger: Any = None,
    case_config: Any = None,
    investigator: Any = None,
) -> SectionContent:
    """Appendix B — formal chain of custody form + per-entry log table."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX B — CHAIN OF CUSTODY"}))

    # Agency / case header table
    case_num  = (case_config.case_number if case_config else "") or ""
    org_name  = (case_config.org_name if case_config else "") or ""
    ex_name   = (case_config.examiner.name if case_config else "") or ""
    ex_badge  = (case_config.examiner.badge if case_config else "") or ""
    sup_name  = (case_config.supervising_examiner.name if case_config else "") or ""
    auth_name = (case_config.authorising_officer.name if case_config else "") or ""

    agency_rows = [
        ["Case Number",          case_num],
        ["Examining Agency",     org_name],
        ["Forensic Examiner",    f"{ex_name}  (Badge: {ex_badge})".strip()],
        ["Supervising Examiner", sup_name],
        ["Authorising Officer",  auth_name],
    ]
    if case_config and case_config.evidence_items:
        for i, ev in enumerate(case_config.evidence_items, 1):
            agency_rows.append([f"Exhibit {i}", ev.label + (" — " + ev.description if ev.description else "")])
    blocks.append(ContentBlock("table", {"headers": ["FIELD", "DETAIL"], "rows": agency_rows}))

    # Per-entry log
    blocks.append(ContentBlock("heading2", {"text": "B.1  Automated Processing Audit Ledger"}))
    blocks.append(ContentBlock("paragraph", {"text": (
        "This ledger records software-processing events and hash links generated "
        "during the AutoForensics run. It is not a substitute for a physical chain-"
        "of-custody record showing receipt, transfer, storage, handlers and seals."
    )}))

    entries: list[dict] = []
    if coc_logger is not None:
        try:
            entries = coc_logger.entries_with_status()
        except Exception as e:
            _logger.warning("Could not load CoC entries: %s", e)

    if entries:
        # Collapse MODULE_LOADED rows
        collapsed: list[dict] = []
        loaded_count = 0
        for e in entries:
            if e.get("event_type") == "MODULE_LOADED":
                loaded_count += 1
                continue
            collapsed.append(e)
        if loaded_count:
            collapsed.insert(
                next((i for i, e in enumerate(collapsed)
                      if e.get("event_type") not in ("INVESTIGATION_STARTED", "AUTH_SUCCESS", "CASE_REGISTERED")),
                     len(collapsed)),
                {
                    "status": "PASS",
                    "timestamp": "",
                    "event_type": "MODULE_LOADED",
                    "description": f"All {loaded_count} analysis modules loaded from module registry",
                    "self_hash": "",
                    "previous_hash": "",
                },
            )

        rows = [["#", "TIMESTAMP", "EVENT", "DESCRIPTION", "STATUS", "HASH (partial)"]]
        for i, e in enumerate(collapsed, 1):
            status = e.get("status", "")
            if status == "GENESIS":
                status_disp = "GENESIS"
            elif status == "PASS":
                status_disp = "PASS ✓"
            else:
                status_disp = status
            rows.append([
                str(i),
                e.get("timestamp", "")[:19],
                e.get("event_type", ""),
                e.get("description", "")[:60],
                status_disp,
                e.get("self_hash", ""),
            ])
        blocks.append(ContentBlock("table", {"headers": rows[0], "rows": rows[1:]}))

        # Overall chain status — verify_chain() is authoritative; fall back to per-entry flags
        all_pass = all(e.get("status") in ("GENESIS", "PASS") for e in entries)
        if not all_pass and coc_logger is not None and hasattr(coc_logger, "verify_chain"):
            try:
                if coc_logger.verify_chain():
                    # Chain passed the authoritative check: override per-entry display status
                    for i, e in enumerate(entries):
                        if e.get("status") != "MALFORMED":
                            e["status"] = "GENESIS" if i == 0 else "PASS"
                    all_pass = True
            except Exception:
                pass
        status_summary = (
            "LEDGER HASH LINKS CONSISTENT" if all_pass
            else "LEDGER HASH-LINK CHECK FAILED — REVIEW REQUIRED"
        )
        blocks.append(ContentBlock("paragraph", {"text": (
            f"\nAutomated Ledger Status: {status_summary}. This status concerns "
            "the generated processing ledger only and does not prove physical "
            "custody, evidence-bag integrity, or absence of pre-intake tampering."
        )}))
    else:
        blocks.append(ContentBlock("paragraph", {"text":
            "No chain of custody entries available. The investigation may not have "
            "been run with a live CustodyLogger, or the ledger file was not found."
        }))

    # COC form image
    coc_img_path = ""
    if case_config and case_config.supplementary.coc_form_image:
        coc_img_path = case_config.supplementary.coc_form_image

    blocks.append(ContentBlock("heading2", {"text": "B.2  Original Chain of Custody Form"}))
    if coc_img_path and Path(coc_img_path).is_file():
        if _dummy_validation_material(case_config):
            blocks.append(_dummy_warning_block())
        blocks.append(ContentBlock("image_path", {
            "path": coc_img_path,
            "caption": _attachment_caption(case_config, "Chain-of-custody form attachment"),
            "width_mm": 170,
        }))
        if _dummy_validation_material(case_config):
            blocks.append(ContentBlock("paragraph", {"text": (
                "This attachment verifies file ingestion and placement only. It does not establish physical receipt, "
                "transfer, storage, handler identity, seal integrity or authorised custody."
            )}))
    else:
        if _is_synthetic_case(case_config):
            blocks.append(ContentBlock("paragraph", {"text": (
                "Not applicable to this electronically supplied synthetic validation exhibit. "
                "No physical transfer or signed custody form was represented to AutoForensics; "
                "the automated processing ledger above records software events only."
            )}))
        else:
            configured = coc_img_path or "not configured"
            blocks.append(ContentBlock("paragraph", {
                "text": (
                    "SIGNED SUPPORTING RECORD NOT SUPPLIED — the original Chain of Custody form "
                    f"is not attached (configured path: {configured}). This generated report remains "
                    "a draft until the examiner resolves whether the form is required and attaches it."
                ),
            }))

    return SectionContent(section_number=91, section_title="Appendix B — Chain of Custody", blocks=blocks)


# ────────────────────────────────────────────────────────────────────────────
# Appendix C — Evidence Bag Photographs
# ────────────────────────────────────────────────────────────────────────────

def build_appendix_evidence_photos(case_config: Any = None) -> SectionContent:
    """Appendix C — Evidence bag photographs."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX C — EVIDENCE BAG PHOTOGRAPHS"}))

    photo_path = _find_evidence_bag_photo(case_config)
    if photo_path:
        _caption = _attachment_caption(
            case_config,
            "Appendix C.1 — Evidence-bag image attachment; receipt, seal state and physical custody are not inferred.",
        )
        # Convert PDF bag photos to PNG so PIL can embed them
        _img_path = str(photo_path)
        if photo_path.suffix.lower() == ".pdf":
            _png = _pdf_to_temp_png(photo_path)
            if _png:
                _img_path = _png
        if _dummy_validation_material(case_config):
            blocks.append(_dummy_warning_block())
        blocks.append(ContentBlock("image_path", {
            "path": _img_path,
            "caption": _caption,
            "width_mm": 170,
        }))
    else:
        if _is_synthetic_case(case_config):
            blocks.append(ContentBlock("paragraph", {"text": (
                "Not applicable to this electronically supplied synthetic validation exhibit. "
                "No physical evidence bag or bag photograph was represented to AutoForensics."
            )}))
        else:
            configured = (
                str(case_config.supplementary.evidence_bag_photos[0])
                if case_config and case_config.supplementary.evidence_bag_photos
                else "not configured"
            )
            blocks.append(ContentBlock("paragraph", {
                "text": (
                    "SUPPORTING RECORD NOT SUPPLIED — evidence-bag photographs are not attached "
                    f"(configured path: {configured}). The examiner must decide whether they are required before approval."
                ),
            }))

    return SectionContent(section_number=92, section_title="Appendix C — Evidence Bag Photographs", blocks=blocks)


# ────────────────────────────────────────────────────────────────────────────
# Appendix D — Authorisation Letter
# ────────────────────────────────────────────────────────────────────────────

def build_appendix_authorisation_letter(case_config: Any = None) -> SectionContent:
    """Appendix D — Authorisation letter (converted to images if PDF provided)."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX D — AUTHORISATION LETTER"}))

    letter_path_str = ""
    if case_config:
        for attr in ("authorisation_letter", "auth_letter_path", "authorization_letter_path"):
            v = getattr(case_config.supplementary, attr, "")
            if v:
                letter_path_str = v
                break

    caption = _attachment_caption(
        case_config,
        "Appendix D.1 — Authorisation-letter attachment; authority is subject to independent verification.",
    )
    if case_config and not _dummy_validation_material(case_config):
        ao = getattr(case_config, "authorising_officer", None)
        if ao:
            name = getattr(ao, "name", "") or ""
            title = getattr(ao, "title", "") or ""
            org = getattr(case_config, "org_name", "") or ""
            if name:
                caption = f"Appendix D.1 — Authorisation letter from {name}"
                if title:
                    caption += f", {title}"
                if org:
                    caption += f", {org}"
                caption += ", authorising this forensic examination."

    if letter_path_str and Path(letter_path_str).is_file():
        if _dummy_validation_material(case_config):
            blocks.append(_dummy_warning_block())
            blocks.append(ContentBlock("paragraph", {"text": (
                "This attachment confirms ingestion only. It does not establish genuine authority, scope, consent, "
                "ethics approval or legal approval."
            )}))
        _embed_auth_letter(Path(letter_path_str), blocks, caption=caption)
    else:
        if _is_synthetic_case(case_config):
            blocks.append(ContentBlock("paragraph", {"text": (
                "Not applicable to this synthetic validation exercise unless an institution-specific "
                "authorisation record is separately required. No signed authority is inferred by the tool."
            )}))
        else:
            blocks.append(ContentBlock("paragraph", {
                "text": (
                    "SIGNED SUPPORTING RECORD NOT SUPPLIED — the authorisation letter is not attached "
                    f"(configured path: {letter_path_str or 'not configured'}). The generated report remains a draft."
                ),
            }))

    return SectionContent(section_number=93, section_title="Appendix D — Authorisation Letter", blocks=blocks)


# ────────────────────────────────────────────────────────────────────────────
# Appendix E — Charts and Visualisations
# ────────────────────────────────────────────────────────────────────────────

def _read_carved_type_counts(case_output_dir: Any) -> dict:
    """Read carved file type breakdown from foremost audit.txt and scalpel results."""
    import re as _re
    from pathlib import Path as _P
    if not case_output_dir:
        return {}
    counts: dict = {}
    try:
        for audit in _P(case_output_dir).rglob("audit.txt"):
            for line in audit.read_text(errors="replace").splitlines():
                m = _re.match(r'\s*(\w+):\s+(\d+)', line)
                if m and int(m.group(2)) > 0:
                    ext = m.group(1).lower()
                    counts[ext] = counts.get(ext, 0) + int(m.group(2))
        for results_dir in _P(case_output_dir).rglob("scalpel-output"):
            for type_dir in results_dir.iterdir():
                if type_dir.is_dir():
                    n = sum(1 for _ in type_dir.iterdir())
                    if n > 0:
                        counts[type_dir.name.lower()] = counts.get(type_dir.name.lower(), 0) + n
    except Exception:
        pass
    return counts


def build_appendix_charts(
    all_module_results: list = None,
    coc_logger: Any = None,
    case_output_dir: Any = None,
    all_evidence_results: list = None,
) -> SectionContent:
    """Appendix E — severity bar, file-type pie, module timing bar, timeline."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX E — CHARTS AND VISUALISATIONS"}))

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        _plt_ok = True
    except ImportError:
        _plt_ok = False

    if not _plt_ok:
        blocks.append(ContentBlock("paragraph", {"text":
            "matplotlib not installed — install with: pip install matplotlib"
        }))
        return SectionContent(section_number=94, section_title="Appendix E — Charts", blocks=blocks)

    results = all_module_results or []

    # ── Chart 1: Findings by Severity ─────────────────────────────────────
    blocks.append(ContentBlock("heading2", {"text": "E.1  Findings by Severity"}))
    from collections import Counter
    from .report_ai import rank_findings
    material_findings = rank_findings(results)
    sev_counts: Counter = Counter()
    for finding in material_findings:
        value = getattr(getattr(finding, "severity", None), "value", str(getattr(finding, "severity", "Low")))
        sev_counts[value] += 1

    if sev_counts:
        fig, ax = plt.subplots(figsize=(6, 3))
        colours = {"Critical": "#C0392B", "High": "#D35400", "Medium": "#D4AC0D",
                   "Low": "#1E8449", "Info": "#7F8C8D"}
        labels = list(sev_counts.keys())
        vals   = [sev_counts[k] for k in labels]
        bars   = ax.bar(labels, vals, color=[colours.get(l, "#7F8C8D") for l in labels])
        ax.bar_label(bars)
        ax.set_title("Distinct Material Findings by Severity", fontsize=11)
        ax.set_ylabel("Count")
        ax.set_xlabel("Severity")
        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120)
        plt.close(fig)
        buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode()
        blocks.append(ContentBlock("chart_image", {
            "data_b64": b64, "width_mm": 150,
            "label": "Chart E.1 — Distribution of distinct grouped material findings by severity",
        }))
    else:
        blocks.append(ContentBlock("paragraph", {"text": "No findings to chart."}))

    # ── Chart 2: File Types Recovered by Carving ──────────────────────────
    blocks.append(ContentBlock("heading2", {"text": "E.2  Signature-Carving Candidate Types"}))
    # Primary source: by_type dict from carving module raw_data (set by loader)
    ext_counts: Counter = Counter()
    for r in results:
        mod = getattr(r, "module_name", "").lower()
        if "carv" in mod or "foremost" in mod or "scalpel" in mod:
            rd = getattr(r, "raw_data", {}) or {}
            by_type = (
                rd.get("carving_summary", {}).get("by_type")
                or rd.get("by_type")
            )
            if by_type:
                for ext, cnt in by_type.items():
                    ext_counts[ext] += cnt

    if not ext_counts and case_output_dir:
        # The native carver records authoritative candidate types in its
        # manifest.  Read that evidence-derived output directly instead of
        # guessing from presentation text.
        try:
            root = Path(case_output_dir)
            for manifest in root.rglob("native_signature_carving_manifest.json"):
                data = json.loads(manifest.read_text(encoding="utf-8"))
                for candidate in data.get("candidates") or []:
                    if not isinstance(candidate, dict):
                        continue
                    file_type = str(
                        candidate.get("file_type")
                        or candidate.get("type")
                        or candidate.get("extension")
                        or "unknown"
                    ).lower().strip().lstrip(".")
                    if file_type:
                        ext_counts[file_type] += 1
        except Exception:
            # The report retains the textual candidate findings; a chart is
            # optional and must never fabricate a type when the manifest is
            # unreadable.
            pass

    if not ext_counts:
        import re as _re
        for r in results:
            mod = getattr(r, "module_name", "").lower()
            if not any(x in mod for x in ("carv", "foremost", "scalpel")):
                continue
            for finding in getattr(r, "findings", []) or []:
                source = " ".join((str(getattr(finding, "title", "") or ""), str(getattr(finding, "description", "") or ""), str(getattr(finding, "artefact_location", "") or "")))
                candidates = _re.findall(r"(?i)\b([A-Za-z0-9_-]+\.(?:pdf|jpg|jpeg|png|gif|bmp|zip|exe|txt|docx?|xlsx?|pptx?))\b", source)
                for name in candidates[:1]:
                    ext = Path(name).suffix.lower().lstrip(".") or "unknown"
                    ext_counts[ext] += 1

    if ext_counts:
        # Show the largest slices individually and fold the long tail into
        # "Other" so the percentages are computed over the FULL carved set,
        # not a truncated top-N (which would report misleading proportions).
        top = ext_counts.most_common(8)
        total = sum(ext_counts.values())
        other = total - sum(c for _, c in top)
        labels_pie = [str(t[0]) for t in top]
        sizes      = [t[1] for t in top]
        if other > 0:
            labels_pie.append("Other")
            sizes.append(other)
        fig2, ax2  = plt.subplots(figsize=(6.5, 4))
        _cmap = plt.cm.tab20.colors
        wedges, _t, _a = ax2.pie(
            sizes,
            # Inline labels overlap badly for many small slices; render the
            # percentage inside the wedge only when it is large enough to read,
            # and move the category names to a legend beside the pie.
            autopct=lambda p: f"{p:.0f}%" if p >= 4 else "",
            pctdistance=0.75,
            startangle=140,
            colors=[_cmap[i % len(_cmap)] for i in range(len(sizes))],
        )
        ax2.legend(
            wedges,
            [f"{l} ({s}, {s * 100.0 / total:.0f}%)" for l, s in zip(labels_pie, sizes)],
            title="File type", loc="center left",
            bbox_to_anchor=(1.02, 0.5), fontsize=8,
        )
        ax2.axis("equal")
        ax2.set_title("Signature-Carving Candidate Types", fontsize=11)
        plt.tight_layout()
        buf2 = io.BytesIO()
        fig2.savefig(buf2, format="png", dpi=120)
        plt.close(fig2)
        buf2.seek(0)
        b64_2 = base64.b64encode(buf2.read()).decode()
        blocks.append(ContentBlock("chart_image", {
            "data_b64": b64_2, "width_mm": 130,
            "label": "Chart E.2 — Candidate object types reported by signature-carving modules; candidates are not confirmed deleted files",
        }))
    else:
        blocks.append(ContentBlock("paragraph", {"text": "No signature-carving candidate objects were reported."}))

    # ── Chart 3: Module Execution Times ───────────────────────────────────
    blocks.append(ContentBlock("heading2", {"text": "E.3  Module Execution Times"}))
    # Single canonical timing source + generator (shared with the supporting-
    # charts section) so durations render from one code path in every context —
    # both full-pipeline (per-evidence dicts) and report-only (result raw_data).
    from .report_loader import build_durations_map, _chart_module_timing
    _timing_cb = _chart_module_timing(build_durations_map(results, all_evidence_results))
    if _timing_cb is not None:
        blocks.append(ContentBlock("chart_image", {
            "data_b64": _timing_cb.data.get("data_b64", ""), "width_mm": 150,
            "label": "Chart E.3 — Module execution times in seconds",
        }))
    else:
        blocks.append(ContentBlock("paragraph", {"text": "No timing data available."}))

    # ── Chart 4: Investigation Timeline ───────────────────────────────────
    blocks.append(ContentBlock("heading2", {"text": "E.4  Investigation Event Timeline"}))
    if coc_logger is not None:
        try:
            entries = coc_logger.entries_with_status()
            if entries:
                times  = []
                labels_tl = []
                for e in entries:
                    ts_str = e.get("timestamp", "")
                    evt    = e.get("event_type", "")
                    if ts_str and evt not in ("MODULE_LOADED",):
                        try:
                            ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                            times.append(ts)
                            labels_tl.append(evt.replace("_", " ")[:24])
                        except ValueError:
                            pass
                if times:
                    # Scale for readability: with many events, per-event labels
                    # collide and the figure grows unbounded.  Cap the number of
                    # plotted+labelled markers by evenly downsampling; the rule
                    # (1 in N) is stated in the caption so nothing is hidden
                    # silently.  Small timelines render every event.
                    _MAX_MARKERS = 40
                    n_total = len(times)
                    if n_total > _MAX_MARKERS:
                        step = (n_total + _MAX_MARKERS - 1) // _MAX_MARKERS
                        sel = list(range(0, n_total, step))
                        # Always include the final event so the end time is shown.
                        if sel[-1] != n_total - 1:
                            sel.append(n_total - 1)
                        sample_note = (
                            f" (showing {len(sel)} of {n_total} events, 1 in {step})"
                        )
                    else:
                        sel = list(range(n_total))
                        sample_note = ""
                    times_p = [times[i] for i in sel]
                    labels_p = [labels_tl[i] for i in sel]

                    fig_h = min(11.0, max(3.0, len(times_p) * 0.32))
                    fig4, ax4 = plt.subplots(figsize=(8, fig_h))
                    ys = list(range(len(times_p)))
                    xs = [(t - times[0]).total_seconds() / 60 for t in times_p]
                    ax4.scatter(xs, ys, marker="o", color="#1ABC9C", zorder=3)
                    for x, y, lbl in zip(xs, ys, labels_p):
                        ax4.text(x + 0.2, y, lbl, va="center", fontsize=7)
                    ax4.set_xlabel("Minutes elapsed from investigation start")
                    ax4.set_yticks([])
                    ax4.set_title("Investigation Event Timeline" + sample_note, fontsize=11)
                    ax4.grid(axis="x", linestyle="--", alpha=0.5)
                    plt.tight_layout()
                    buf4 = io.BytesIO()
                    fig4.savefig(buf4, format="png", dpi=120)
                    plt.close(fig4)
                    buf4.seek(0)
                    b64_4 = base64.b64encode(buf4.read()).decode()
                    blocks.append(ContentBlock("chart_image", {
                        "data_b64": b64_4, "width_mm": 160,
                        "label": "Chart E.4 — Investigation event timeline from chain of custody log",
                    }))
        except Exception as e:
            _logger.warning("Could not build timeline chart: %s", e)
            blocks.append(ContentBlock("paragraph", {"text": "Timeline chart could not be generated."}))
    else:
        blocks.append(ContentBlock("paragraph", {"text": "No custody log available for timeline chart."}))

    return SectionContent(section_number=94, section_title="Appendix E — Charts", blocks=blocks)


# ────────────────────────────────────────────────────────────────────────────
# Appendix F — Supporting Forensic Screenshots
# ────────────────────────────────────────────────────────────────────────────

def build_appendix_screenshots(
    case_config: Any = None,
    auto_screenshots: Optional[list] = None,
    **kwargs,
) -> SectionContent:
    """Appendix F — Supporting Forensic Screenshots.

    Parameters
    ----------
    case_config:
        Case configuration object (for manually-attached supplementary screenshots).
    auto_screenshots:
        List of {figure_id, path, caption} dicts produced by
        report_loader.collect_module_screenshots().  When provided these are
        embedded as full-page images in section F.2.
    """
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading1", {"text": "APPENDIX F — SUPPORTING FORENSIC SCREENSHOTS"}))

    supp = case_config.supplementary if case_config else None

    # F.1 — Manually-supplied supplementary screenshots (from case config)
    blocks.append(ContentBlock("heading2", {"text": "F.1 — Manually Attached Evidence Screenshots"}))
    manual_sections = [
        ("F.1.1", "FTK Imager Acquisition Evidence",   "ftk_screenshot"),
        ("F.1.3", "Registry Analysis Evidence",          "registry_screenshot"),
        ("F.1.4", "Password Recovery Evidence",          "password_recovery_screenshot"),
        ("F.1.5", "Malware Analysis Evidence (REMnux)",  "malware_screenshot"),
        ("F.1.6", "Email Analysis Evidence",             "email_screenshot"),
        ("F.1.7", "Anti-Forensic Evidence",              "antiforensic_screenshot"),
    ]
    any_manual = False
    for label, title, attr in manual_sections:
        img_path = getattr(supp, attr, "") if supp else ""
        if img_path and Path(img_path).is_file():
            any_manual = True
            blocks.append(ContentBlock("heading2", {"text": f"{label} — {title}"}))
            blocks.append(ContentBlock("image_path", {
                "path": img_path,
                "caption": f"Fig {label} — {title}",
                "width_mm": 160,
            }))
    if not any_manual:
        blocks.append(ContentBlock("paragraph", {
            "text": "[No manually-attached screenshots provided in case configuration.]"
        }))

    # F.2 — Auto-generated visualisations (not independent screenshots)
    blocks.append(ContentBlock("heading2", {"text": "F.2 — Automated Pipeline Output Visualisations"}))
    if auto_screenshots:
        blocks.append(ContentBlock("paragraph", {
            "text": (
                f"The following {len(auto_screenshots)} image(s) were generated by "
                "the pipeline from module output. They are presentation aids, not "
                "independent photographic screenshots and not additional proof of the "
                "underlying finding. The cited artefact/hash/offset remains authoritative."
            )
        }))
        for sc in auto_screenshots:
            png_path = sc.get("path", "")
            caption  = sc.get("caption", sc.get("figure_id", ""))
            if png_path and Path(png_path).is_file():
                blocks.append(ContentBlock("image_path", {
                    "path":      png_path,
                    "caption":   caption,
                    "width_mm":  160,
                }))
    else:
        blocks.append(ContentBlock("paragraph", {
            "text": (
                "[No automated screenshots found. Ensure the forensic pipeline ran "
                "with PIL/Pillow installed (pip install Pillow) and that module output "
                "directories contain screenshots_index.json files.]"
            )
        }))

    blocks.append(ContentBlock("heading2", {"text": "F.3 — Network Indicators"}))
    blocks.append(ContentBlock("paragraph", {"text": "See the neutral identifier-correlation table in the relevant analysis section. Co-occurrence does not establish a relationship or criminal network."}))

    # The examiner declaration is rendered once, authoritatively, in Appendix A
    # (build_appendix_declaration) from the case configuration; it is not
    # repeated here to avoid a duplicate declaration/status block.

    blocks.append(ContentBlock("heading2", {"text": "F.4 — Investigation Charts and Visualisations"}))
    blocks.append(ContentBlock("paragraph", {
        "text": (
            "The authoritative investigation charts are presented once in Appendix E. "
            "They are not duplicated in this screenshot appendix."
        )
    }))

    return SectionContent(section_number=95, section_title="Appendix F — Screenshots", blocks=blocks)
