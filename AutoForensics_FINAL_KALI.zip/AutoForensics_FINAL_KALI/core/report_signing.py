"""Detached Ed25519 signatures for final AutoForensics report packages.

The signature covers a canonical JSON manifest containing the final PDF and JSON
SHA-256 values, case identifier, signer identity, and signing timestamp.  It does
not alter the PDF bytes and is independently verifiable with the exported public
key.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "Report signing requires the 'cryptography' package. "
        "Install requirements.txt before using signing."
    ) from exc


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical(data: dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("utf-8")


def generate_signing_key(private_key_path: str | Path, public_key_path: str | Path, *, force: bool = False) -> tuple[Path, Path]:
    private_path = Path(private_key_path).expanduser().resolve()
    public_path = Path(public_key_path).expanduser().resolve()
    for path in (private_path, public_path):
        path.parent.mkdir(parents=True, exist_ok=True)
    if not force and (private_path.exists() or public_path.exists()):
        raise FileExistsError("Refusing to overwrite an existing signing key; use --force explicitly.")

    key = Ed25519PrivateKey.generate()
    private_bytes = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    fd = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o400)
    with os.fdopen(fd, "wb") as fh:
        fh.write(private_bytes)
        fh.flush()
        os.fsync(fh.fileno())
    public_path.write_bytes(public_bytes)
    os.chmod(public_path, 0o444)
    return private_path, public_path


def _load_private(path: Path) -> Ed25519PrivateKey:
    key = serialization.load_pem_private_key(path.read_bytes(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise TypeError("Configured report private key is not an Ed25519 key.")
    return key


def _load_public(path: Path) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(path.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        raise TypeError("Configured report public key is not an Ed25519 key.")
    return key


def public_key_fingerprint(public_key: Ed25519PublicKey) -> str:
    der = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return hashlib.sha256(der).hexdigest()


def sign_report_package(
    *,
    case_id: str,
    pdf_path: str | Path,
    json_path: str | Path,
    private_key_path: str | Path,
    public_key_path: str | Path | None,
    signer_name: str,
    signer_role: str,
    output_path: str | Path | None = None,
) -> Path:
    pdf = Path(pdf_path).resolve()
    report_json = Path(json_path).resolve()
    private_path = Path(private_key_path).expanduser().resolve()
    if not pdf.is_file() or not report_json.is_file():
        raise FileNotFoundError("Both final PDF and report JSON must exist before signing.")
    if not private_path.is_file():
        raise FileNotFoundError(f"Report signing private key not found: {private_path}")

    private_key = _load_private(private_path)
    derived_public = private_key.public_key()
    if public_key_path:
        configured_public = _load_public(Path(public_key_path).expanduser().resolve())
        if public_key_fingerprint(configured_public) != public_key_fingerprint(derived_public):
            raise ValueError("Configured public key does not match the report private key.")

    signed_content = {
        "schema": "autoforensics-report-signature-v1",
        "case_id": case_id,
        "signed_at": datetime.now(timezone.utc).isoformat(),
        "algorithm": "Ed25519 (RFC 8032)",
        "signer_name": signer_name,
        "signer_role": signer_role,
        "report_pdf": pdf.name,
        "report_pdf_sha256": _sha256(pdf),
        "report_json": report_json.name,
        "report_json_sha256": _sha256(report_json),
        "public_key_sha256": public_key_fingerprint(derived_public),
    }
    signature = private_key.sign(_canonical(signed_content))
    document = dict(signed_content)
    document["signature_base64"] = base64.b64encode(signature).decode("ascii")
    document["statement"] = (
        "The detached signature authenticates the listed file hashes and signer key. "
        "It does not replace independent forensic review or establish legal admissibility."
    )

    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in case_id)
    out = Path(output_path).resolve() if output_path else pdf.parent / f"{safe}_report_signature.json"
    out.write_text(json.dumps(document, indent=2, sort_keys=True), encoding="utf-8")
    os.chmod(out, 0o444)

    exported_public = pdf.parent / f"{safe}_report_signing_public.pem"
    exported_public.write_bytes(derived_public.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ))
    os.chmod(exported_public, 0o444)
    return out


def verify_report_signature(
    signature_path: str | Path,
    public_key_path: str | Path,
    *,
    base_dir: str | Path | None = None,
) -> dict[str, Any]:
    sig_path = Path(signature_path).resolve()
    doc = json.loads(sig_path.read_text(encoding="utf-8"))
    signature_b64 = str(doc.pop("signature_base64", ""))
    doc.pop("statement", None)
    if not signature_b64:
        raise ValueError("Signature document is missing signature_base64.")
    public_key = _load_public(Path(public_key_path).expanduser().resolve())
    if public_key_fingerprint(public_key) != doc.get("public_key_sha256"):
        raise ValueError("Public-key fingerprint does not match the signature document.")
    public_key.verify(base64.b64decode(signature_b64), _canonical(doc))

    root = Path(base_dir).resolve() if base_dir else sig_path.parent
    pdf = root / str(doc["report_pdf"])
    report_json = root / str(doc["report_json"])
    if _sha256(pdf) != doc["report_pdf_sha256"]:
        raise ValueError("PDF hash does not match the signed manifest.")
    if _sha256(report_json) != doc["report_json_sha256"]:
        raise ValueError("Report JSON hash does not match the signed manifest.")
    return {"valid": True, **doc}
