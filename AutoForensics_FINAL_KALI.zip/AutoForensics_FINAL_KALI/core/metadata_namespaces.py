"""Deterministic metadata namespace helpers.

The investigation engine keeps the origin namespace of each field.  XMP,
EXIF, PNG text, PDF Info and OOXML core properties are never collapsed into a
single ambiguous metadata bucket.
"""
from __future__ import annotations

import hashlib
import re
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def field_namespace(field: str, *, group: str = "", file_type: str = "") -> str:
    """Return one canonical namespace without inferring a different source."""
    f = str(field or "")
    g = str(group or "").casefold()
    ft = str(file_type or "").casefold()
    if g.startswith("xmp") or f.startswith("XMP:"):
        return "XMP"
    if g.startswith("exif") or f.startswith("EXIF:"):
        return "EXIF"
    if g.startswith("png") or f.startswith("PNG:"):
        return "PNG_TEXT"
    if g.startswith("pdf") or ft == "pdf":
        return "PDF_INFO"
    if g.startswith("ooxml") or ft in {"docx", "docm", "xlsx", "xlsm", "pptx", "pptm"}:
        return "OOXML_CORE"
    if g.startswith("application"):
        return "APPLICATION_METADATA"
    if g.startswith("appended"):
        return "APPENDED_TEXT"
    return "APPLICATION_METADATA"


def _xml_local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag.split(":")[-1]


def _xmp_records(data: bytes) -> list[dict[str, Any]]:
    """Extract exact XMP attributes/elements from retained packet XML."""
    records: list[dict[str, Any]] = []
    starts = [m.start() for m in re.finditer(br"<(?:x:xmpmeta|xmpmeta)\b", data, re.I)]
    for start in starts:
        end_match = re.search(br"</(?:x:xmpmeta|xmpmeta)\s*>", data[start:], re.I)
        if not end_match:
            continue
        end = start + end_match.end()
        packet = data[start:end]
        try:
            root = ET.fromstring(packet.decode("utf-8", errors="replace"))
        except ET.ParseError:
            continue
        for elem in root.iter():
            for key, value in elem.attrib.items():
                value = str(value).strip()
                if value:
                    records.append({
                        "namespace": "XMP",
                        "field": _xml_local(key),
                        "value": value,
                        "raw_offset": start,
                        "parser": "xml.etree.ElementTree",
                    })
            text = (elem.text or "").strip()
            if text and len(list(elem)) == 0:
                records.append({
                    "namespace": "XMP",
                    "field": _xml_local(elem.tag),
                    "value": text,
                    "raw_offset": start,
                    "parser": "xml.etree.ElementTree",
                })
    # Preserve one record per exact namespace/field/value tuple.
    seen: set[tuple[str, str, str]] = set()
    out: list[dict[str, Any]] = []
    for record in records:
        key = (record["namespace"], record["field"], record["value"])
        if key not in seen:
            seen.add(key)
            out.append(record)
    return out


def _ooxml_core_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    try:
        with zipfile.ZipFile(path) as archive:
            if "docProps/core.xml" not in archive.namelist():
                return []
            data = archive.read("docProps/core.xml")
            root = ET.fromstring(data)
            for child in root:
                value = (child.text or "").strip()
                if value:
                    records.append({
                        "namespace": "OOXML_CORE",
                        "field": _xml_local(child.tag),
                        "value": value,
                        "raw_reference": "docProps/core.xml",
                        "parser": "zipfile+xml.etree.ElementTree",
                    })
    except (OSError, zipfile.BadZipFile, KeyError, ET.ParseError):
        return []
    return records


def native_metadata_records(path: Path) -> list[dict[str, Any]]:
    """Parse metadata using format libraries without changing namespace labels."""
    records: list[dict[str, Any]] = []
    suffix = path.suffix.casefold()
    try:
        data = path.read_bytes()
    except OSError:
        return records

    if suffix in {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".webp", ".bmp"}:
        try:
            from PIL import ExifTags, Image
            with Image.open(path) as image:
                try:
                    exif = image.getexif()
                except Exception:
                    exif = {}
                for numeric, value in dict(exif or {}).items():
                    name = str(ExifTags.TAGS.get(numeric, numeric))
                    if value not in (None, "", b""):
                        records.append({
                            "namespace": "EXIF", "field": name,
                            "value": str(value), "parser": "Pillow.getexif",
                        })
                if suffix == ".png":
                    for key, value in dict(getattr(image, "text", {}) or {}).items():
                        if value not in (None, ""):
                            records.append({
                                "namespace": "PNG_TEXT", "field": str(key),
                                "value": str(value), "parser": "Pillow PNG text parser",
                            })
        except Exception:
            pass
        records.extend(_xmp_records(data))

    if suffix in {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"}:
        records.extend(_ooxml_core_records(path))

    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path), strict=False)
            for key, value in dict(reader.metadata or {}).items():
                if value not in (None, ""):
                    records.append({
                        "namespace": "PDF_INFO", "field": str(key).lstrip("/"),
                        "value": str(value), "parser": "pypdf",
                    })
        except Exception:
            pass
        # XMP packet is a distinct namespace even inside a PDF.
        records.extend(_xmp_records(data))

    digest = sha256_file(path)
    for record in records:
        record.setdefault("source_path", str(path))
        record.setdefault("source_sha256", digest)
        record.setdefault("validation_method", "format-aware deterministic parser")
    return records
