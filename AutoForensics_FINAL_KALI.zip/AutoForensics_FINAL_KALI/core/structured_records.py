"""Deterministic structured-record extraction for evidence artefacts.

This module deliberately separates field-aware parsing from arbitrary byte-string
search.  A value may enter the canonical findings layer only when the parser can
identify the exact source record and field that contained it.  Printable strings
recovered from opaque binary data remain candidate observations.

The parsers are generic and content/schema driven.  They do not contain fixture
names, case identifiers or planted values.
"""
from __future__ import annotations

import csv
import hashlib
import json
import mailbox
import re
import sqlite3
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable, Iterator

_MAX_TEXT_BYTES = 0  # zero = exhaustive
_MAX_RECORDS = 0  # zero = exhaustive
_MAX_FIELD_CHARS = 0  # zero = exhaustive


@dataclass(frozen=True)
class StructuredRecord:
    source_path: str
    source_sha256: str
    source_kind: str
    locator: dict[str, Any]
    fields: dict[str, str]
    roles: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return ""
    text = str(value)
    return text if _MAX_FIELD_CHARS <= 0 else text[:_MAX_FIELD_CHARS]


def _printable_text(path: Path) -> str | None:
    try:
        raw = path.read_bytes()
    except OSError:
        return None
    if (_MAX_TEXT_BYTES > 0 and len(raw) > _MAX_TEXT_BYTES) or b"\x00" in raw[:8192]:
        return None
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = raw.decode("utf-16")
        except UnicodeError:
            return None
    sample = text[:8192]
    if sample:
        printable = sum(ch.isprintable() or ch in "\r\n\t" for ch in sample) / len(sample)
        if printable < 0.92:
            return None
    return text


def _sqlite_records(path: Path, digest: str) -> list[StructuredRecord]:
    try:
        if path.read_bytes()[:16] != b"SQLite format 3\x00":
            return []
    except OSError:
        return []
    out: list[StructuredRecord] = []
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            tables = [str(r[0]) for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )]
            for table in tables:
                if _MAX_RECORDS > 0 and len(out) >= _MAX_RECORDS:
                    break
                quoted = table.replace('"', '""')
                try:
                    columns = [str(r[1]) for r in conn.execute(f'PRAGMA table_info("{quoted}")')]
                    query = f'SELECT rowid AS __af_rowid__, * FROM "{quoted}"'
                    cursor = conn.execute(query)
                except sqlite3.Error:
                    try:
                        query = f'SELECT * FROM "{quoted}"'
                        cursor = conn.execute(query)
                    except sqlite3.Error:
                        continue
                for index, row in enumerate(cursor, 1):
                    if _MAX_RECORDS > 0 and len(out) >= _MAX_RECORDS:
                        break
                    values = dict(row)
                    rowid = values.pop("__af_rowid__", index)
                    fields = {str(k): _stringify(v) for k, v in values.items() if _stringify(v)}
                    if not fields:
                        continue
                    roles = {key: semantic_role(key) for key in fields}
                    out.append(StructuredRecord(
                        str(path), digest, "sqlite",
                        {"database": str(path), "table": table, "rowid": rowid},
                        fields, roles,
                    ))
        finally:
            conn.close()
    except sqlite3.Error:
        return []
    return out


def _walk_json(value: Any, path_tokens: tuple[str, ...] = ()) -> Iterator[tuple[tuple[str, ...], dict[str, str]]]:
    if isinstance(value, dict):
        scalar = {str(k): _stringify(v) for k, v in value.items() if not isinstance(v, (dict, list)) and _stringify(v)}
        if scalar:
            yield path_tokens, scalar
        for key, child in value.items():
            if isinstance(child, (dict, list)):
                yield from _walk_json(child, path_tokens + (str(key),))
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            if isinstance(child, (dict, list)):
                yield from _walk_json(child, path_tokens + (str(idx),))
            elif _stringify(child):
                yield path_tokens + (str(idx),), {"value": _stringify(child)}


def _json_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        # JSONL fallback.
        values: list[Any] = []
        for line in text.splitlines():
            if not line.strip():
                continue
            try:
                values.append(json.loads(line))
            except json.JSONDecodeError:
                return []
        value = values
    out: list[StructuredRecord] = []
    for idx, (tokens, fields) in enumerate(_walk_json(value), 1):
        if _MAX_RECORDS > 0 and idx > _MAX_RECORDS:
            break
        out.append(StructuredRecord(
            str(path), digest, "json",
            {"json_path": "$" + "".join(f"[{t}]" if t.isdigit() else f".{t}" for t in tokens), "record_index": idx},
            fields, {key: semantic_role(key) for key in fields},
        ))
    return out


def _csv_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    try:
        sample = text[:65536]
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
        has_header = csv.Sniffer().has_header(sample)
    except csv.Error:
        dialect = csv.excel
        has_header = True
    out: list[StructuredRecord] = []
    try:
        rows = csv.reader(text.splitlines(), dialect)
        headers: list[str]
        first = next(rows, None)
        if first is None:
            return []
        if has_header:
            headers = [str(v).strip() or f"column_{i+1}" for i, v in enumerate(first)]
        else:
            headers = [f"column_{i+1}" for i in range(len(first))]
            rows = iter([first, *rows])
        for row_index, row in enumerate(rows, 2 if has_header else 1):
            if _MAX_RECORDS > 0 and len(out) >= _MAX_RECORDS:
                break
            fields = {headers[i] if i < len(headers) else f"column_{i+1}": _stringify(v) for i, v in enumerate(row) if _stringify(v)}
            if not fields:
                continue
            out.append(StructuredRecord(
                str(path), digest, "csv",
                {"row": row_index}, fields, {key: semantic_role(key) for key in fields},
            ))
    except csv.Error:
        return []
    return out


def _mbox_records(path: Path, digest: str) -> list[StructuredRecord]:
    out: list[StructuredRecord] = []
    try:
        box = mailbox.mbox(str(path), create=False)
        for idx, message in enumerate(box, 1):
            if _MAX_RECORDS > 0 and idx > _MAX_RECORDS:
                break
            fields: dict[str, str] = {}
            for name in ("Message-ID", "Date", "From", "To", "Cc", "Bcc", "Reply-To", "Subject"):
                value = message.get(name)
                if value:
                    fields[name] = str(value)
            payload = message.get_payload(decode=True)
            if isinstance(payload, bytes):
                charset = message.get_content_charset() or "utf-8"
                try:
                    fields["body"] = payload.decode(charset, errors="replace") if _MAX_FIELD_CHARS <= 0 else payload.decode(charset, errors="replace")[:_MAX_FIELD_CHARS]
                except LookupError:
                    fields["body"] = payload.decode("utf-8", errors="replace") if _MAX_FIELD_CHARS <= 0 else payload.decode("utf-8", errors="replace")[:_MAX_FIELD_CHARS]
            elif isinstance(message.get_payload(), str):
                fields["body"] = str(message.get_payload()) if _MAX_FIELD_CHARS <= 0 else str(message.get_payload())[:_MAX_FIELD_CHARS]
            out.append(StructuredRecord(
                str(path), digest, "mbox", {"message_index": idx, "message_id": fields.get("Message-ID", "")},
                fields, {key: semantic_role(key) for key in fields},
            ))
    except (OSError, mailbox.Error):
        return []
    return out


def _reg_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    out: list[StructuredRecord] = []
    current_key = ""
    for line_no, raw_line in enumerate(text.splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith((";", "Windows Registry Editor")):
            continue
        if line.startswith("[") and line.endswith("]"):
            current_key = line[1:-1]
            continue
        match = re.match(r'^(?:"(?P<name>(?:[^"\\]|\\.)*)"|@)\s*=\s*(?P<value>.+)$', line)
        if match and current_key:
            name = match.group("name") or "(Default)"
            value = match.group("value")
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1].replace('\\"', '"').replace('\\\\', '\\')
            fields = {"registry_key": current_key, "value_name": name, "value_data": value}
            out.append(StructuredRecord(
                str(path), digest, "registry_export", {"line": line_no, "registry_key": current_key, "value_name": name},
                fields, {"registry_key": "registry_key", "value_name": "registry_value_name", "value_data": "registry_value_data"},
            ))
    return out


def _hosts_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    out: list[StructuredRecord] = []
    for line_no, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        fields = {"ip": parts[0], "hostnames": " ".join(parts[1:])}
        out.append(StructuredRecord(
            str(path), digest, "hosts", {"line": line_no}, fields,
            {"ip": "ip", "hostnames": "hostname"},
        ))
    return out


def _xml_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return []
    out: list[StructuredRecord] = []
    for idx, elem in enumerate(root.iter(), 1):
        if _MAX_RECORDS > 0 and idx > _MAX_RECORDS:
            break
        fields = {str(k): _stringify(v) for k, v in elem.attrib.items() if _stringify(v)}
        if elem.text and elem.text.strip():
            fields["text"] = elem.text.strip() if _MAX_FIELD_CHARS <= 0 else elem.text.strip()[:_MAX_FIELD_CHARS]
        if fields:
            out.append(StructuredRecord(
                str(path), digest, "xml", {"element": elem.tag, "element_index": idx}, fields,
                {key: semantic_role(key) for key in fields},
            ))
    return out


def _plain_records(path: Path, digest: str, text: str) -> list[StructuredRecord]:
    out: list[StructuredRecord] = []
    for line_no, line in enumerate(text.splitlines(), 1):
        if _MAX_RECORDS > 0 and line_no > _MAX_RECORDS:
            break
        if not line.strip():
            continue
        fields: dict[str, str] = {"line_text": line if _MAX_FIELD_CHARS <= 0 else line[:_MAX_FIELD_CHARS]}
        label_match = re.match(r"^\s*([A-Za-z][A-Za-z0-9 _./-]{0,80})\s*[:=]\s*(.+?)\s*$", line)
        if label_match:
            fields = {label_match.group(1).strip(): (label_match.group(2).strip() if _MAX_FIELD_CHARS <= 0 else label_match.group(2).strip()[:_MAX_FIELD_CHARS])}
        out.append(StructuredRecord(
            str(path), digest, "text", {"line": line_no}, fields,
            {key: semantic_role(key) for key in fields},
        ))
    return out


def semantic_role(field_name: str) -> str:
    name = re.sub(r"[^a-z0-9]+", "_", field_name.casefold()).strip("_")
    if name in {"message_id", "messageid", "in_reply_to", "references"}:
        return "message_identifier"
    if any(token in name for token in ("email", "e_mail")) or name in {"from", "to", "cc", "bcc", "reply_to", "sender", "recipient"}:
        return "email"
    if name in {"url", "uri", "link", "href", "referrer", "original_url", "target_url"} or name.endswith("_url"):
        return "url"
    if name in {"ip", "src_ip", "dst_ip", "source_ip", "destination_ip", "remote_ip", "local_ip"} or name.endswith("_ip"):
        return "ip"
    if any(token in name for token in ("phone", "telephone", "mobile_number", "msisdn")):
        return "phone"
    if any(token in name for token in ("imei", "device_id", "equipment_identity")):
        return "imei"
    if name in {"password", "passwd", "pwd", "passphrase"} or name.endswith("_password"):
        return "password"
    if any(token in name for token in ("api_key", "apikey", "access_token", "auth_token", "secret_key")):
        return "api_key"
    if name in {"host", "hostname", "domain", "fqdn", "hostnames"}:
        return "hostname"
    if "registry_key" in name or name == "key_path":
        return "registry_key"
    if name in {"body", "text", "content", "message", "line_text", "subject", "title", "value_data"}:
        return "free_text"
    return "unknown"


def extract_structured_records(path: Path) -> list[StructuredRecord]:
    """Return exact records for supported structures; opaque binary files return []."""
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        return []
    try:
        digest = sha256_file(path)
        header = path.read_bytes()[:32]
    except OSError:
        return []
    if header.startswith(b"SQLite format 3\x00"):
        return _sqlite_records(path, digest)
    suffix = path.suffix.casefold()
    if suffix in {".mbox", ".mbx"} or path.name.casefold().endswith("mailbox"):
        records = _mbox_records(path, digest)
        if records:
            return records
    text = _printable_text(path)
    if text is None:
        return []
    if suffix in {".json", ".jsonl", ".ndjson"}:
        records = _json_records(path, digest, text)
        if records:
            return records
    if suffix in {".csv", ".tsv"}:
        records = _csv_records(path, digest, text)
        if records:
            return records
    if suffix == ".reg" or text.lstrip().startswith("Windows Registry Editor"):
        records = _reg_records(path, digest, text)
        if records:
            return records
    lower_parts = [part.casefold() for part in path.parts]
    if path.name.casefold() == "hosts" or ("etc" in lower_parts and path.name.casefold() == "hosts"):
        records = _hosts_records(path, digest, text)
        if records:
            return records
    if suffix in {".xml", ".plist", ".xhtml", ".html", ".htm"}:
        records = _xml_records(path, digest, text)
        if records:
            return records
    # Plain text lines are exact records.  Their semantic interpretation remains
    # bounded to the literal value and never implies ownership or intent.
    return _plain_records(path, digest, text)


def record_context(record: StructuredRecord) -> str:
    return "\n".join(f"{key}: {value}" for key, value in record.fields.items())


def value_role(record: StructuredRecord, field_name: str) -> str:
    return record.roles.get(field_name) or semantic_role(field_name)


def record_locator_metadata(record: StructuredRecord, field_name: str | None = None) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "source_file": record.source_path,
        "file_path": record.source_path,
        "file_sha256": record.source_sha256,
        "source_kind": record.source_kind,
        **record.locator,
    }
    if field_name:
        metadata["field_name"] = field_name
    return metadata
