# core/case_config.py
"""
CaseConfig — central case metadata object for AutoForensics.

Loaded from a JSON file (--case flag) or built interactively by the wizard.
Flows from CLI intake through ForensicOrchestrator into ReportGenerator so
every report field is dynamic — nothing is hardcoded.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Optional


@dataclass
class ExaminerInfo:
    name: str
    email: str = ""
    institution: str = ""
    badge: str = ""
    certifications: list[str] = field(default_factory=list)


@dataclass
class PersonRef:
    name: str
    title: str = ""
    organisation: str = ""
    email: str = ""


@dataclass
class EvidenceItem:
    label: str           # e.g. "Exhibit 1 — Seagate SSD"
    path: str            # path to .E01 or device
    description: str = ""
    serial_number: str = ""
    make_model: str = ""
    hostname: str = ""      # e.g. "WASHER1"
    owner: str = ""         # optional declared owner/custodian
    os: str = ""            # e.g. "Windows XP (x86)"
    exhibit_id: str = ""    # e.g. "EX-001"
    evidence_type: str = "" # disk, memory, network, mobile, or auto
    device_type: str = ""   # android/ios for mobile evidence when known


@dataclass
class SupplementaryFiles:
    authorisation_letter: str = ""      # path to PDF
    evidence_bag_photos: list[str] = field(default_factory=list)   # list of image paths
    coc_form_image: str = ""            # path to image/PDF
    examiner_signature: str = ""        # path to PNG/JPG
    supervisor_signature: str = ""      # path to PNG/JPG
    ftk_screenshot: str = ""
    registry_screenshot: str = ""
    password_recovery_screenshot: str = ""
    malware_screenshot: str = ""
    email_screenshot: str = ""
    antiforensic_screenshot: str = ""
    # Arbitrary case-supporting documents retained as administrative context.
    # They are hashed/copied into the case but never promoted to forensic findings.
    additional_files: list[str] = field(default_factory=list)




@dataclass
class AIPolicy:
    """Controls whether case-derived material may leave the examination host."""
    mode: str = "local_only"  # local_only | cloud_opt_in
    allow_cloud_case_data: bool = False
    consent_reference: str = ""
    permitted_providers: list[str] = field(default_factory=lambda: ["openai"])


@dataclass
class SigningConfig:
    """Detached Ed25519 report-signature configuration."""
    require_signature: bool = False
    private_key_path: str = ""
    public_key_path: str = ""
    signer_role: str = "Forensic Examiner"


@dataclass
class CaseConfig:
    # Core identifiers
    case_number: str
    case_title: str

    # People
    examiner: ExaminerInfo

    # Versioned on-disk schema. Canonical evidence key: ``evidence_items``.
    schema_version: str = "1.0"
    supervising_examiner: PersonRef = field(default_factory=lambda: PersonRef(""))
    authorising_officer: PersonRef = field(default_factory=lambda: PersonRef(""))
    client_representative: PersonRef = field(default_factory=lambda: PersonRef(""))

    # Organisation
    org_name: str = ""
    org_address: str = ""

    # Case details
    date_received: Optional[date] = None
    date_commenced: Optional[date] = None
    jurisdiction: str = "England and Wales"
    offence_types: list[str] = field(default_factory=list)
    investigation_background: str = ""
    objectives: list[str] = field(default_factory=list)

    # Evidence
    evidence_items: list[EvidenceItem] = field(default_factory=list)

    # Supplementary files
    supplementary: SupplementaryFiles = field(default_factory=SupplementaryFiles)

    # Report metadata
    classification: str = "CONFIDENTIAL"
    report_reference: str = ""

    # Investigation profile for pipeline (e.g. "usb", "full", "memory")
    investigation_profile: str = ""

    # Contact
    org_phone: str = ""
    org_email: str = ""

    # Report target
    report_target_pages: int = 80

    # Report date override and tool version overrides
    report_date: Optional[date] = None
    tool_versions: dict = field(default_factory=dict)

    # Privacy and cryptographic approval controls
    ai_policy: AIPolicy = field(default_factory=AIPolicy)
    signing: SigningConfig = field(default_factory=SigningConfig)


def load_case_config(path: str | Path) -> CaseConfig:
    """Load CaseConfig from a JSON file. Raises ValueError on bad data."""
    p = Path(path).resolve()
    if not p.is_file():
        raise ValueError(f"Case config not found: {p}")
    try:
        raw: dict[str, Any] = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {p}: {exc}") from exc

    def _date(s: str | None) -> Optional[date]:
        if not s:
            return None
        try:
            return date.fromisoformat(s)
        except (ValueError, TypeError):
            return None

    def _person(d: dict | None) -> PersonRef:
        if not d:
            return PersonRef("")
        return PersonRef(
            name=d.get("name", ""),
            title=d.get("title", ""),
            organisation=d.get("organisation", ""),
            email=d.get("email", ""),
        )

    examiner_raw = raw.get("examiner", {})
    examiner = ExaminerInfo(
        name=examiner_raw.get("name", ""),
        email=examiner_raw.get("email", ""),
        institution=examiner_raw.get("institution", ""),
        badge=examiner_raw.get("badge", ""),
        certifications=examiner_raw.get("certifications", []),
    )

    def _resolve_path(s: str) -> str:
        if not s:
            return s
        candidate = Path(s).expanduser()
        if candidate.is_absolute():
            return str(candidate.resolve())
        return str((p.parent / candidate).resolve())

    supp_raw = raw.get("supplementary_files", raw.get("supplementary", {}))
    supplementary = SupplementaryFiles(
        authorisation_letter=_resolve_path(supp_raw.get("authorisation_letter", "")),
        evidence_bag_photos=[_resolve_path(x) for x in supp_raw.get("evidence_bag_photos", [])],
        coc_form_image=_resolve_path(supp_raw.get("coc_form_image", "")),
        examiner_signature=_resolve_path(supp_raw.get("examiner_signature", "")),
        supervisor_signature=_resolve_path(supp_raw.get("supervisor_signature", "")),
        ftk_screenshot=_resolve_path(supp_raw.get("ftk_screenshot", "")),
        registry_screenshot=_resolve_path(supp_raw.get("registry_screenshot", "")),
        password_recovery_screenshot=_resolve_path(supp_raw.get("password_recovery_screenshot", "")),
        malware_screenshot=_resolve_path(supp_raw.get("malware_screenshot", "")),
        email_screenshot=_resolve_path(supp_raw.get("email_screenshot", "")),
        antiforensic_screenshot=_resolve_path(supp_raw.get("antiforensic_screenshot", "")),
        additional_files=[_resolve_path(x) for x in supp_raw.get("additional_files", [])],
    )

    schema_version = str(raw.get("schema_version", "1.0"))
    major = schema_version.split(".", 1)[0]
    if major != "1":
        raise ValueError(
            f"Unsupported case-config schema_version {schema_version!r}; expected 1.x"
        )

    # ``evidence_items`` is the canonical v1 key. ``evidence`` is accepted only
    # as a legacy migration path so older case files remain readable. Never
    # continue silently with an empty list: that previously produced a report
    # while analysing no evidence at all.
    if "evidence_items" in raw:
        evidence_raw = raw.get("evidence_items")
    elif "evidence" in raw:
        evidence_raw = raw.get("evidence")
    else:
        raise ValueError(
            "Case config is missing required 'evidence_items' list "
            "(legacy key 'evidence' is also accepted)."
        )
    if not isinstance(evidence_raw, list) or not evidence_raw:
        raise ValueError("Case config must contain at least one evidence item.")

    evidence_items: list[EvidenceItem] = []
    for i, e in enumerate(evidence_raw):
        if not isinstance(e, dict):
            raise ValueError(f"Evidence item {i + 1} must be a JSON object.")
        raw_path = str(e.get("path", "")).strip()
        if not raw_path:
            raise ValueError(f"Evidence item {i + 1} is missing required 'path'.")
        evidence_items.append(EvidenceItem(
            label=e.get("label", f"Exhibit {i+1}"),
            path=_resolve_path(raw_path),
            description=e.get("description", ""),
            serial_number=e.get("serial_number", ""),
            make_model=e.get("make_model", ""),
            hostname=e.get("hostname", ""),
            owner=e.get("owner", ""),
            os=e.get("os", ""),
            exhibit_id=e.get("id", e.get("exhibit_id", "")),
            evidence_type=str(e.get("evidence_type", e.get("type", "")) or ""),
            device_type=str(e.get("device_type", "") or ""),
        ))

    org = raw.get("organisation", {})
    org_phone = org.get("phone", raw.get("org_phone", ""))
    org_email = org.get("email", raw.get("org_email", ""))

    ai_raw = raw.get("ai_policy", {}) or {}
    ai_policy = AIPolicy(
        mode=str(ai_raw.get("mode", "local_only") or "local_only").strip().lower(),
        allow_cloud_case_data=bool(ai_raw.get("allow_cloud_case_data", False)),
        consent_reference=str(ai_raw.get("consent_reference", "") or ""),
        permitted_providers=[str(x).strip().lower() for x in (ai_raw.get("permitted_providers") or ["openai"]) if str(x).strip()],
    )
    if ai_policy.mode not in {"local_only", "cloud_opt_in"}:
        raise ValueError("ai_policy.mode must be 'local_only' or 'cloud_opt_in'.")

    sign_raw = raw.get("signing", {}) or {}
    signing = SigningConfig(
        require_signature=bool(sign_raw.get("require_signature", False)),
        private_key_path=_resolve_path(str(sign_raw.get("private_key_path", "") or "")),
        public_key_path=_resolve_path(str(sign_raw.get("public_key_path", "") or "")),
        signer_role=str(sign_raw.get("signer_role", "Forensic Examiner") or "Forensic Examiner"),
    )

    config_obj = CaseConfig(
        case_number=raw.get("case_number", ""),
        schema_version=schema_version,
        case_title=raw.get("case_title", ""),
        examiner=examiner,
        supervising_examiner=_person(raw.get("supervising_examiner")),
        authorising_officer=_person(raw.get("authorising_officer")),
        client_representative=_person(raw.get("client_representative")),
        org_name=org.get("name", raw.get("org_name", "")),
        org_address=org.get("address", raw.get("org_address", "")),
        date_received=_date(raw.get("date_received")),
        date_commenced=_date(raw.get("date_commenced")),
        jurisdiction=raw.get("jurisdiction", "England and Wales"),
        offence_types=raw.get("offence_types", []),
        investigation_background=raw.get("investigation_background", ""),
        objectives=raw.get("objectives", []),
        evidence_items=evidence_items,
        supplementary=supplementary,
        classification=raw.get("classification", "CONFIDENTIAL"),
        report_reference=raw.get("report_reference", ""),
        investigation_profile=raw.get("investigation_profile", raw.get("profile", "")),
        org_phone=org_phone,
        org_email=org_email,
        report_target_pages=int(raw.get("report_target_pages", 80)),
        report_date=_date(raw.get("report_date")),
        tool_versions=raw.get("tool_versions", {}),
        ai_policy=ai_policy,
        signing=signing,
    )
    # Preserve a read-only copy of the original case JSON for report-time
    # provenance and validation labels. This is intentionally not part of the
    # public dataclass schema and never changes evidence findings.
    setattr(config_obj, "_raw", dict(raw))
    return config_obj


def _ask(prompt: str, default: str = "", required: bool = False) -> str:
    """Single prompt with optional default. Loops until non-empty if required."""
    suffix = f" [{default}]" if default else (" (required)" if required else "")
    while True:
        raw = input(f"  {prompt}{suffix}: ").strip()
        val = raw or default
        if required and not val:
            print("    This field is required.")
            continue
        return val


def _ask_list(prompt: str) -> list[str]:
    """Collect multiple values until blank line."""
    print(f"  {prompt} (one per line, blank line to finish):")
    items: list[str] = []
    while True:
        line = input("    > ").strip()
        if not line:
            break
        items.append(line)
    return items


def _ask_int(prompt: str, *, minimum: int = 1, default: int | None = None) -> int:
    """Collect one bounded positive integer without accepting ambiguous input."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"  {prompt}{suffix}: ").strip()
        if not raw and default is not None:
            return default
        try:
            value = int(raw)
        except ValueError:
            print("    Enter a whole number.")
            continue
        if value < minimum:
            print(f"    Enter a value of at least {minimum}.")
            continue
        return value


def _ask_yes_no(prompt: str, *, default: bool = False) -> bool:
    marker = "Y/n" if default else "y/N"
    while True:
        raw = input(f"  {prompt} [{marker}]: ").strip().casefold()
        if not raw:
            return default
        if raw in {"y", "yes"}:
            return True
        if raw in {"n", "no"}:
            return False
        print("    Enter y or n.")


def run_wizard(examiner_defaults: dict[str, Any] | None = None) -> CaseConfig:
    """Interactive case-intake wizard.

    Evidence is supplied explicitly at runtime.  One independent image/device is one
    evidence item; a segmented EWF set (E01/E02/...) is one item and only its E01
    entry point should be selected because libewf discovers companion segments.
    """
    defaults = dict(examiner_defaults or {})
    print("\n" + "=" * 62)
    print("                         AUTOFORENSICS")
    print("                       CASE INTAKE WIZARD")
    print("=" * 62)
    print("  Enter the information available for this investigation.")
    print("  Optional fields may be left blank; they are never fabricated.")

    print("\n── CASE IDENTIFIERS ──────────────────────────────────────")
    case_number = _ask("Case number", required=True)
    case_title  = _ask("Case / investigation title", default=f"Digital Forensic Investigation — {case_number}")
    report_ref  = _ask("Incident / internal reference", default="")
    classification = _ask("Classification", default="CONFIDENTIAL")

    print("\n── FORENSIC EXAMINER ─────────────────────────────────────")
    ex_name   = _ask("Examiner full name", default=str(defaults.get("name") or ""), required=not bool(defaults.get("name")))
    ex_email  = _ask("Examiner email")
    ex_inst   = _ask("Examiner institution / organisation")
    ex_badge  = _ask("Examiner badge / staff ID", default=str(defaults.get("badge") or ""))
    ex_certs  = _ask_list("Examiner certifications")

    print("\n── CASE DETAILS ──────────────────────────────────────────")
    date_recv  = _ask("Date evidence received (YYYY-MM-DD)")
    date_comm  = _ask("Date examination commenced (YYYY-MM-DD)")
    juris      = _ask("Jurisdiction", default="England and Wales")
    offences   = _ask_list("Offence / matter types")

    print("\n── INVESTIGATION BACKGROUND / ADDITIONAL INFORMATION ─────")
    print("  Case description / investigation notes (blank line to finish):")
    bg_lines: list[str] = []
    while True:
        line = input("    > ").strip()
        if not line:
            break
        bg_lines.append(line)
    relevant_range = _ask("Relevant date/time range (optional)")
    case_timezone = _ask("Case timezone (optional; e.g. Europe/London)")
    context_terms = _ask("Known context / keywords (optional; comma-separated, context only)")
    objectives = _ask_list("Investigation objectives")
    background_parts = [" ".join(bg_lines).strip()]
    if relevant_range:
        background_parts.append(f"Relevant date/time range: {relevant_range}")
    if case_timezone:
        background_parts.append(f"Case timezone: {case_timezone}")
    if context_terms:
        background_parts.append(
            "Investigator-provided context terms (case context only; not independent forensic evidence): "
            + context_terms
        )
    background = "\n\n".join(part for part in background_parts if part)

    print("\n── EVIDENCE INPUT ────────────────────────────────────────")
    print("  Add each independent evidence item once.")
    print("  Segmented EWF: select only the .E01; companion .E02/.E03 segments are discovered automatically.")
    count = _ask_int("Number of evidence items", minimum=1, default=1)
    evidence_items: list[EvidenceItem] = []
    seen_paths: set[str] = set()
    for idx in range(1, count + 1):
        print(f"\n  Evidence item {idx} of {count}")
        while True:
            ev_path = _ask("Path", required=True)
            expanded = str(Path(ev_path).expanduser())
            suffix = Path(expanded).suffix.casefold()
            if suffix.startswith(".e0") and suffix != ".e01":
                print("    Segmented EWF input must start with the .E01 segment; enter that path instead.")
                continue
            key = str(Path(expanded).resolve()) if Path(expanded).exists() else expanded
            if key in seen_paths:
                print("    That evidence path is already listed; enter each independent item once.")
                continue
            seen_paths.add(key)
            ev_path = expanded
            break
        label = _ask("Label", default=f"Evidence item {idx}")
        exhibit = _ask("Exhibit ID", default=f"EX-{idx:03d}")
        ev_desc = _ask("Description")
        ev_type = _ask("Evidence type", default="auto")
        dev_type = _ask("Mobile device type (android/ios; blank if not mobile)")
        ev_make = _ask("Make / model (optional)")
        ev_ser = _ask("Serial number (optional)")
        evidence_items.append(EvidenceItem(
            label=label, path=ev_path, description=ev_desc,
            make_model=ev_make, serial_number=ev_ser,
            evidence_type=ev_type, device_type=dev_type, exhibit_id=exhibit,
        ))

    print("\n── PEOPLE / ORGANISATION (optional) ──────────────────────")
    sup_name  = _ask("Supervising examiner name")
    sup_org   = _ask("Supervising examiner organisation")
    auth_name  = _ask("Authorising officer name")
    auth_title = _ask("Authorising officer title")
    auth_org   = _ask("Authorising officer organisation")
    cli_name = _ask("Client representative name")
    cli_org  = _ask("Client organisation")
    org_name    = _ask("Examiner organisation name", default=ex_inst)
    org_address = _ask("Organisation address")

    print("\n── SUPPORTING MATERIAL (optional) ─────────────────────────")
    print("  Supporting files are hashed and retained as case context; they do not become forensic findings.")
    auth_letter = _ask("Authorisation letter path")
    coc_form    = _ask("Existing chain-of-custody form path")
    ex_sig      = _ask("Examiner signature path")
    sup_sig     = _ask("Supervisor / authorising signature path")
    photos      = _ask_list("Evidence bag / exhibit photograph paths")
    additional_files = _ask_list("Other supporting document/file paths")

    print("\n── ANALYSIS PROFILE ───────────────────────────────────────")
    print("  [1] Full investigation")
    print("  [2] Disk / filesystem")
    print("  [3] Memory")
    print("  [4] Network")
    print("  [5] Mobile")
    profile_map = {"1": "full", "2": "disk", "3": "memory", "4": "network", "5": "mobile"}
    while True:
        profile_choice = _ask("Select profile", default="1")
        if profile_choice in profile_map:
            investigation_profile = profile_map[profile_choice]
            break
        print("    Select 1, 2, 3, 4 or 5.")

    print("\n── OPTIONAL AI NARRATIVE ─────────────────────────────────")
    print("  OpenAI is optional and is used only for narrative synthesis from the")
    print("  structured case summary; AutoForensics does not transmit raw evidence bytes.")
    use_openai = _ask_yes_no("Enable OpenAI narrative enhancement", default=False)
    if use_openai:
        consent = _ask("Consent / authorisation reference for cloud narrative", required=True)
        ai_policy = AIPolicy(
            mode="cloud_opt_in", allow_cloud_case_data=True,
            consent_reference=consent, permitted_providers=["openai"],
        )
    else:
        ai_policy = AIPolicy(mode="local_only", allow_cloud_case_data=False)

    def _d(value: str) -> Optional[date]:
        try:
            return date.fromisoformat(value) if value else None
        except ValueError:
            return None

    cfg = CaseConfig(
        case_number=case_number,
        case_title=case_title,
        examiner=ExaminerInfo(
            name=ex_name, email=ex_email, institution=ex_inst,
            badge=ex_badge, certifications=ex_certs,
        ),
        supervising_examiner=PersonRef(name=sup_name, organisation=sup_org),
        authorising_officer=PersonRef(name=auth_name, title=auth_title, organisation=auth_org),
        client_representative=PersonRef(name=cli_name, organisation=cli_org),
        org_name=org_name,
        org_address=org_address,
        date_received=_d(date_recv),
        date_commenced=_d(date_comm),
        jurisdiction=juris,
        offence_types=offences,
        investigation_background=background,
        objectives=objectives,
        evidence_items=evidence_items,
        supplementary=SupplementaryFiles(
            authorisation_letter=auth_letter,
            evidence_bag_photos=photos,
            coc_form_image=coc_form,
            examiner_signature=ex_sig,
            supervisor_signature=sup_sig,
            additional_files=additional_files,
        ),
        classification=classification,
        report_reference=report_ref,
        investigation_profile=investigation_profile,
        ai_policy=ai_policy,
    )

    print("\n" + "=" * 62)
    print("                    CASE INTAKE SUMMARY")
    print("=" * 62)
    print(f"  Case ID:          {cfg.case_number}")
    print(f"  Investigator:     {cfg.examiner.name}")
    print(f"  Evidence items:   {len(cfg.evidence_items)}")
    for i, item in enumerate(cfg.evidence_items, 1):
        print(f"    [{i}] {item.path}")
    print(f"  Profile:          {cfg.investigation_profile}")
    print(f"  OpenAI narrative: {'Enabled' if use_openai else 'Disabled'}")
    print(f"  Supporting files: {len(additional_files) + len(photos) + sum(bool(x) for x in (auth_letter, coc_form, ex_sig, sup_sig))}")
    print("=" * 62)
    return cfg


# ---------------------------------------------------------------------------
# Exhibit-id resolution — single source of truth
# ---------------------------------------------------------------------------
# The exhibit id for a given evidence index must be identical wherever it is
# rendered: the orchestrator's source-stamp, the EvidenceAcquisition table, and
# the per-evidence report sections.  Resolving it in one place stops the three
# surfaces drifting (an explicit configured id was previously ignored by the
# report, which read a non-existent `.id` field and silently fell back).


def _evidence_items_of(case_config) -> list:
    """Return the evidence-item list from a CaseConfig object or a plain dict."""
    if case_config is None:
        return []
    if isinstance(case_config, dict):
        return case_config.get("evidence_items", []) or []
    return getattr(case_config, "evidence_items", None) or []


def _explicit_exhibit_id(item) -> str:
    """The operator-supplied exhibit id on an evidence item, if any."""
    if isinstance(item, dict):
        return str(item.get("exhibit_id") or item.get("id") or "")
    return str(getattr(item, "exhibit_id", "") or getattr(item, "id", "") or "")


def exhibit_id_for(idx: int, case_config=None) -> str:
    """Resolve the exhibit id for a zero-based evidence index.

    Honours an operator-supplied exhibit id on the matching evidence item;
    otherwise falls back to the positional ``EX-NNN`` label.  The index is
    discovered at runtime — never assumed to be zero/one item.
    """
    items = _evidence_items_of(case_config)
    if 0 <= idx < len(items):
        explicit = _explicit_exhibit_id(items[idx])
        if explicit:
            return explicit
    return f"EX-{idx + 1:03d}"


def stamp_result_exhibit(result, exhibit_id: str) -> None:
    """Stamp a module result and its findings with an exhibit id at the source.

    Only fills findings that carry no attribution yet, so a per-finding signal
    on a result merged from several images (each finding already stamped) is
    never clobbered.  Records the id on ``raw_data`` too, so later passes can
    tell the result was resolved at the source.
    """
    if not exhibit_id:
        return
    raw = getattr(result, "raw_data", None)
    if isinstance(raw, dict):
        raw.setdefault("_exhibit", exhibit_id)
    for f in getattr(result, "findings", []) or []:
        if not (getattr(f, "evidence_reference", "") or ""):
            f.evidence_reference = exhibit_id
