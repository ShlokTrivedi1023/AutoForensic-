"""Validated intake of administrative case attachments.

Administrative records are never fabricated and never treated as forensic
findings.  Supplied files are hashed, copied into the protected case directory,
recorded in custody, and referenced by the report through the copied path.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
from pathlib import Path
from typing import Any


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_name(label: str, source: Path, index: int = 0) -> str:
    prefix = re.sub(r"[^a-z0-9]+", "_", label.casefold()).strip("_") or "attachment"
    suffix = source.suffix.casefold()
    ordinal = f"_{index:02d}" if index else ""
    return f"{prefix}{ordinal}{suffix}"


def ingest_administrative_attachments(case_config: Any, case_dir: Path, coc_logger: Any = None) -> dict[str, Any]:
    result: dict[str, Any] = {
        "schema": "autoforensics-administrative-attachments-v1",
        "attachments": [], "missing": [], "errors": [],
        "administratively_complete": False,
    }
    if case_config is None or getattr(case_config, "supplementary", None) is None:
        result["missing"] = [
            "authorisation letter", "chain-of-custody form", "examiner signature",
            "supervisor signature", "evidence-bag photographs",
        ]
        return result
    supp = case_config.supplementary
    target_dir = (Path(case_dir) / "administrative_attachments").resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(target_dir, 0o700)
    except OSError:
        pass

    scalar = [
        ("authorisation letter", "authorisation_letter"),
        ("chain-of-custody form", "coc_form_image"),
        ("examiner signature", "examiner_signature"),
        ("supervisor signature", "supervisor_signature"),
    ]
    entries: list[tuple[str, str, int]] = []
    for label, attr in scalar:
        value = str(getattr(supp, attr, "") or "")
        if value:
            entries.append((label, value, 0))
        else:
            result["missing"].append(label)
    photos = list(getattr(supp, "evidence_bag_photos", []) or [])
    if photos:
        entries.extend(("evidence-bag photograph", str(value), index) for index, value in enumerate(photos, 1))
    else:
        result["missing"].append("evidence-bag photographs")
    additional_files = list(getattr(supp, "additional_files", []) or [])
    entries.extend(("additional supporting file", str(value), index) for index, value in enumerate(additional_files, 1))

    copied_by_attr: dict[str, str] = {}
    copied_photos: list[str] = []
    copied_additional: list[str] = []
    for label, raw, index in entries:
        source = Path(raw).expanduser().resolve()
        if not source.is_file():
            result["errors"].append({"label": label, "path": str(source), "error": "file not found or unreadable"})
            if label not in result["missing"]:
                result["missing"].append(label)
            continue
        destination = target_dir / _safe_name(label, source, index)
        try:
            original_hash = _sha256(source)
            shutil.copy2(source, destination)
            copied_hash = _sha256(destination)
            if copied_hash != original_hash:
                destination.unlink(missing_ok=True)
                raise OSError("copy hash mismatch")
            try:
                os.chmod(destination, 0o440)
            except OSError:
                pass
            record = {
                "label": label, "original_path": str(source),
                "retained_path": str(destination), "size_bytes": destination.stat().st_size,
                "sha256": copied_hash,
            }
            result["attachments"].append(record)
            if label == "evidence-bag photograph":
                copied_photos.append(str(destination))
            elif label == "additional supporting file":
                copied_additional.append(str(destination))
            else:
                attr = dict(scalar)[label]
                copied_by_attr[attr] = str(destination)
            if coc_logger is not None:
                try:
                    from core.custody_log import EventType
                    coc_logger.log(
                        event_type=EventType.MODULE_OBSERVATION,
                        description=f"Administrative attachment retained: {label}",
                        evidence_path=str(destination),
                        metadata={"attachment_label": label, "sha256": copied_hash, "size_bytes": destination.stat().st_size},
                    )
                except Exception:
                    pass
        except OSError as exc:
            result["errors"].append({"label": label, "path": str(source), "error": str(exc)})
            if label not in result["missing"]:
                result["missing"].append(label)

    for attr, value in copied_by_attr.items():
        setattr(supp, attr, value)
    if copied_photos:
        supp.evidence_bag_photos = copied_photos
    if copied_additional:
        supp.additional_files = copied_additional
    result["missing"] = list(dict.fromkeys(result["missing"]))
    result["administratively_complete"] = not result["missing"] and not result["errors"]
    manifest = target_dir / "administrative_attachments_manifest.json"
    manifest.write_text(json.dumps(result, indent=2, ensure_ascii=True), encoding="utf-8")
    try:
        os.chmod(manifest, 0o440)
    except OSError:
        pass
    result["manifest_path"] = str(manifest)
    return result
