"""Final deterministic promotion and semantic-safety gate.

Modules may retain pattern, entropy, OCR, ML, co-occurrence and other heuristic
engines as candidate generators.  This reconciler prevents those observations
from becoming evidentiary PRESENT findings unless a reproducible validator has
confirmed the precise claim.  It also downgrades semantic overclaims when the
underlying object is only a marker/minimal container.

The implementation is intentionally evidence-agnostic: it uses signatures,
checksums, schemas, token boundaries and parser invariants rather than fixture
filenames or planted values.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import re
import zipfile
from pathlib import Path
from typing import Any

from core.deterministic_validation import (
    bitcoin_base58check_valid,
    bitcoin_bech32_valid,
    candidate_metadata,
    classify_luhn_identifier,
    deterministic_metadata,
    strict_emails,
    strict_ips,
)
from core.evidence_inventory import classify_file
from core.native_carving import _gif_structured_length
from core.source_provenance import SourceRole, provenance_metadata, source_role_for_path
from core.evidence_ledger import normalise_candidate_records
from core.deterministic_memory import canonical_marker_sources
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding,
)


def _clean_local_path(value: Any) -> Path | None:
    """Return an existing local file path, removing record fragments such as #L12."""
    if value in (None, ""):
        return None
    text = str(value).strip()
    text = re.sub(r"#L\d+(?:-L?\d+)?$", "", text)
    try:
        path = Path(text)
    except (TypeError, ValueError):
        return None
    return path if path.is_file() else None


def _path_from_finding(finding: Any) -> Path | None:
    md = dict(getattr(finding, "metadata", {}) or {})
    for key in (
        "file_path", "source_file", "source_path", "original_source",
        "local_path", "extracted_file", "infected_file", "database",
        "source_database", "_source_database", "image_file",
        "artifact_path", "carved_path", "output_path", "manifest_path",
        "report_file",
    ):
        path = _clean_local_path(md.get(key))
        if path:
            return path
    path = _clean_local_path(getattr(finding, "artifact_path", None))
    if path:
        return path
    return _clean_local_path(getattr(finding, "evidence_path", None))

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()



_PATH_KEY_TOKENS = (
    "path", "file", "database", "image", "source", "evidence", "artifact",
    "segment", "alias", "container", "input", "original", "retained",
)


def _metadata_path_candidates(value: Any, key_hint: str = "") -> list[Path]:
    """Collect existing paths embedded anywhere in structured module metadata."""
    out: list[Path] = []
    if isinstance(value, dict):
        for key, child in value.items():
            out.extend(_metadata_path_candidates(child, str(key).casefold()))
    elif isinstance(value, (list, tuple, set)):
        for child in value:
            out.extend(_metadata_path_candidates(child, key_hint))
    elif isinstance(value, (str, Path)) and any(token in key_hint for token in _PATH_KEY_TOKENS):
        path = _clean_local_path(value)
        if path:
            out.append(path)
    return out


def _inventory_sha_index(inventory: dict[str, Any]) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = {}
    for obj in inventory.get("objects") or []:
        raw_path = obj.get("path")
        if not raw_path:
            continue
        path = _clean_local_path(raw_path)
        if not path:
            continue
        hashes = obj.get("hashes") or {}
        digest = str(
            obj.get("sha256") or obj.get("file_sha256") or
            hashes.get("sha256") or (obj.get("metadata") or {}).get("sha256") or ""
        ).casefold()
        if re.fullmatch(r"[0-9a-f]{64}", digest):
            index.setdefault(digest, []).append(path)
    return index


def _primary_evidence_roots(working_set: dict[str, Any]) -> list[Path]:
    """Return unique retained evidence roots in deterministic priority order."""
    ws = working_set or {}
    values = list(ws.get("primary_evidence_roots") or [])
    values.extend(v for v in (
        ws.get("mounted_fs_root"), ws.get("extracted_files_dir"),
        ws.get("native_deleted_root"), ws.get("tsk_recover_dir"),
    ) if v)
    roots: list[Path] = []
    seen: set[str] = set()
    for value in values:
        try:
            root = Path(str(value)).resolve()
        except (OSError, ValueError):
            continue
        key = str(root)
        if key not in seen and root.exists():
            seen.add(key)
            roots.append(root)
    return roots


def _logical_relative_path_values(finding: Any) -> list[str]:
    """Collect relative logical evidence locators without interpreting them fuzzily."""
    values: list[str] = []
    md = dict(getattr(finding, "metadata", {}) or {})
    ref = getattr(finding, "evidence_reference", {}) or {}
    direct = getattr(finding, "evidence_path", None)
    if direct not in (None, ""):
        values.append(str(direct))

    exact_keys = {
        "path", "logical_path", "logical_evidence_path", "evidence_relative_path",
        "relative_path", "source_relative_path", "filename", "file_name",
        "host_file", "matched_file",
    }

    def walk(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                walk(child, str(child_key).casefold())
        elif isinstance(value, (list, tuple, set)):
            for child in value:
                walk(child, key)
        elif key in exact_keys and value not in (None, ""):
            values.append(str(value))

    walk(md)
    walk(ref)
    return list(dict.fromkeys(values))


def _resolve_logical_relative_path(
    finding: Any, working_set: dict[str, Any], output_dir: Path
) -> Path | None:
    """Resolve an exact logical path beneath a retained evidence root.

    No basename similarity, fuzzy matching, case-folded guessing, or suffix search
    is used.  A path is accepted only when normalisation remains below the root,
    exactly one existing file is addressed, and runtime source-role policy labels
    it evidentiary content.
    """
    roots = _primary_evidence_roots(working_set)
    for raw in _logical_relative_path_values(finding):
        text = re.sub(r"#L\d+(?:-L?\d+)?$", "", str(raw).strip()).replace("\\", "/")
        # Host absolute paths are handled by _clean_local_path.  Windows drive
        # paths are not mapped to arbitrary local roots.
        if not text or re.match(r"^[A-Za-z]:/", text):
            continue
        rel_text = text.lstrip("/")
        if not rel_text:
            continue
        rel = Path(rel_text)
        if any(part in {"", ".", ".."} for part in rel.parts):
            continue
        matches: list[Path] = []
        for root in roots:
            if not root.is_dir():
                continue
            candidate = (root / rel).resolve()
            try:
                candidate.relative_to(root.resolve())
            except (ValueError, OSError):
                continue
            if candidate.is_file() and source_role_for_path(candidate, working_set, output_dir=output_dir) == SourceRole.EVIDENTIARY_CONTENT:
                matches.append(candidate)
        unique = list(dict.fromkeys(str(path) for path in matches))
        if len(unique) == 1:
            return Path(unique[0])
    return None


def _resolve_evidentiary_lineage(
    finding: Any,
    *,
    evidence_path: Path,
    working_set: dict[str, Any],
    output_dir: Path,
    inventory_sha: dict[str, list[Path]],
) -> tuple[Path | None, str]:
    """Resolve a derivative/parser record to the retained evidence object it came from.

    Resolution is generic and fail-closed.  It accepts only an existing original
    path under an evidence root, an exact SHA-256 identity to such a path, or the
    supplied source container for findings that describe that container itself.
    """
    md = dict(getattr(finding, "metadata", {}) or {})
    candidates: list[Path] = []
    direct = _clean_local_path(getattr(finding, "evidence_path", None))
    if direct:
        candidates.append(direct)
    candidates.extend(_metadata_path_candidates(md))
    ref = getattr(finding, "evidence_reference", {}) or {}
    candidates.extend(_metadata_path_candidates(ref))

    seen: set[str] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path.absolute()
        if str(resolved) in seen:
            continue
        seen.add(str(resolved))
        if source_role_for_path(resolved, working_set, output_dir=output_dir) == SourceRole.EVIDENTIARY_CONTENT:
            return resolved, "explicit_original_evidence_path"

    # Resolve a logical filesystem path (for example, a TSK/native listing
    # record) by exact containment beneath one retained evidence root.
    logical_path = _resolve_logical_relative_path(finding, working_set, output_dir)
    if logical_path is not None:
        return logical_path, "exact_logical_path_under_evidence_root"

    # A retained derivative can be traced to an original object by exact content
    # identity.  No filename similarity or fuzzy matching is used.
    derivative_paths = list(candidates)
    current = _path_from_finding(finding)
    if current:
        derivative_paths.insert(0, current)
    for path in derivative_paths:
        try:
            digest = _sha256(path)
        except OSError:
            continue
        for original in inventory_sha.get(digest, []):
            if source_role_for_path(original, working_set, output_dir=output_dir) == SourceRole.EVIDENTIARY_CONTENT:
                return original.resolve(), "sha256_identity_to_original_evidence"

    ftype = str(getattr(finding, "finding_type", "") or "").upper()
    container_types = (
        ftype.startswith("EWF_") or ftype.startswith("EVIDENCE_") or
        ftype.startswith("SOURCE_CONTAINER_") or
        ftype in {"NATIVE_EVIDENCE_ACCESS", "NATIVE_EVIDENCE_ACCESS_STATUS", "FILESYSTEM_STRUCTURE_CONFIRMED", "TIMELINE_CONSTRUCTED"}
    )
    source_container = _clean_local_path(evidence_path)
    if container_types and source_container:
        return source_container.resolve(), "supplied_source_container"
    return None, ""


def _allow_evidence_resident_configuration(
    finding_type: str,
    path: Path | None,
    working_set: dict[str, Any],
    output_dir: Path,
) -> bool:
    """Allow exact self-observations about configuration retained inside evidence.

    This does not convert a configured list into external truth.  It permits only
    exact statements such as "this retained hash was recomputed to this plaintext"
    or "this exact configured literal occurs at this source location".
    """
    if not path:
        return False
    safe_types = {
        "PASSWORD_RECOVERED", "HASH_DATABASE_MATCH", "KNOWN_HASH_MATCH",
        "IOC_EXACT_MATCH", "SIGNATURE_TEXT_OCCURRENCE",
        "ANALYSIS_CONFIGURATION_RETAINED",
    }
    if finding_type not in safe_types:
        return False
    # The path must physically reside beneath a primary evidence root even if
    # inventory syntax classifies its content as configuration.
    ws = working_set or {}
    roots = [Path(str(v)) for v in (ws.get("primary_evidence_roots") or []) if v]
    roots += [Path(str(v)) for v in (ws.get("mounted_fs_root"), ws.get("native_deleted_root")) if v]
    try:
        resolved = path.resolve()
    except OSError:
        resolved = path.absolute()
    for root in roots:
        try:
            resolved.relative_to(root.resolve())
            return True
        except (ValueError, OSError):
            continue
    return False



def _structurally_validate_carved_file(path: Path) -> tuple[bool, str, dict[str, Any]]:
    """Validate a carved object using format structure, not extension alone."""
    try:
        data = path.read_bytes()
    except OSError as exc:
        return False, "unreadable", {"error": str(exc)}
    if len(data) < 4:
        return False, "unknown", {"reason": "too short"}
    if data.startswith(b"%PDF-"):
        eof = data.rstrip(b"\x00\r\n \t").endswith(b"%%EOF")
        return eof, "pdf", {"header": True, "terminal_eof": eof}
    if data.startswith(b"\xff\xd8\xff"):
        valid = data.rstrip(b"\x00").endswith(b"\xff\xd9")
        if valid:
            try:
                from PIL import Image
                with Image.open(path) as image:
                    image.verify()
            except Exception:
                valid = False
        return valid, "jpeg", {"soi": True, "eoi": data.rstrip(b"\x00").endswith(b"\xff\xd9")}
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        import zlib
        pos = 8
        chunks = 0
        valid = False
        while pos + 12 <= len(data):
            length = int.from_bytes(data[pos:pos+4], "big")
            kind = data[pos+4:pos+8]
            end = pos + 12 + length
            if end > len(data):
                return False, "png", {"reason": "truncated chunk", "chunks": chunks}
            payload = data[pos+8:pos+8+length]
            stored = int.from_bytes(data[pos+8+length:end], "big")
            if zlib.crc32(kind + payload) & 0xffffffff != stored:
                return False, "png", {"reason": "CRC mismatch", "chunk": kind.decode("latin1", errors="replace")}
            chunks += 1
            pos = end
            if kind == b"IEND":
                valid = True
                break
        return valid, "png", {"chunks": chunks, "iend": valid, "structured_length": pos}
    if data.startswith((b"GIF87a", b"GIF89a")):
        length = _gif_structured_length(data)
        valid = length is not None
        return valid, "gif", {
            "header": data[:6].decode("ascii"),
            "structured_length": length or 0,
            "trailer": bool(length and data[length - 1:length] == b";"),
        }
    if data.startswith(b"PK\x03\x04"):
        try:
            with zipfile.ZipFile(path) as zf:
                infos = zf.infolist()
                if not infos:
                    return False, "zip", {"reason": "empty central directory"}
                encrypted = [info.filename for info in infos if info.flag_bits & 0x1]
                bad_member = None
                # CRC-test only members that are readable without a password.
                # Encrypted entries remain structurally valid when the central
                # directory and local headers parse; decryption belongs to the
                # password-recovery modules.
                for info in infos:
                    if info.flag_bits & 0x1:
                        continue
                    try:
                        with zf.open(info, "r") as member:
                            while member.read(1024 * 1024):
                                pass
                    except (RuntimeError, OSError, zipfile.BadZipFile):
                        bad_member = info.filename
                        break
                return bad_member is None, "zip", {
                    "members": len(infos),
                    "encrypted_members": len(encrypted),
                    "encrypted_member_names": encrypted,
                    "bad_member": bad_member,
                    "validation_scope": "central directory/local headers plus CRC for unencrypted members",
                }
        except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
            return False, "zip", {"error": str(exc)}
    return False, "unknown", {"reason": "unsupported or missing structural signature"}


def _valid_zip_encryption(path: Path) -> bool:
    try:
        with zipfile.ZipFile(path) as zf:
            infos = zf.infolist()
            return bool(infos) and any(bool(info.flag_bits & 0x1) for info in infos)
    except (OSError, zipfile.BadZipFile):
        return False


def _validate_exact_identifier_finding(finding: Any) -> bool:
    """Validate exact identifier claims and rewrite unsafe semantic labels."""
    ftype = str(getattr(finding, "finding_type", "") or "").upper()
    md = dict(getattr(finding, "metadata", {}) or {})

    if "EMAIL" in ftype:
        values = []
        for key in ("email", "value", "address"):
            if md.get(key):
                values.append(str(md[key]))
        for key in ("emails", "addresses"):
            values.extend(str(v) for v in (md.get(key) or []))
        valid = [v for v in values if strict_emails(v) == [v]]
        if values and len(valid) != len(values):
            md["rejected_invalid_identifiers"] = sorted(set(values) - set(valid))
            for key in ("emails", "addresses"):
                if key in md:
                    md[key] = valid
            if "email" in md and md["email"] not in valid:
                return False
        if valid:
            md.update(deterministic_metadata("RFC-style token boundaries and domain-label validation", validators=["strict_emails"]))
            finding.metadata = md
            return True

    if "IP" in ftype:
        values = []
        for key in ("ip", "src_ip", "dst_ip", "value"):
            if md.get(key):
                values.append(str(md[key]))
        for key in ("ips", "public_ips", "reserved_ips"):
            values.extend(str(v) for v in (md.get(key) or []))
        valid: list[str] = []
        for v in values:
            try:
                parsed = str(ipaddress.ip_address(v))
            except ValueError:
                continue
            if strict_ips(v) == [parsed]:
                valid.append(parsed)
        if values and len(valid) != len(values):
            md["rejected_invalid_identifiers"] = sorted(set(values) - set(valid))
            for key in ("ips", "public_ips", "reserved_ips"):
                if key in md:
                    md[key] = valid
            if any(key in md and str(md[key]) not in valid for key in ("ip", "src_ip", "dst_ip", "value")):
                return False
        if valid:
            md.update(deterministic_metadata("ipaddress parsing with exact token boundaries", validators=["strict_ips", "ipaddress.ip_address"]))
            finding.metadata = md
            return True

    if ftype in {"CREDIT_CARD_NUMBER", "PAYMENT_CARD_NUMBER"}:
        digits = str(md.get("digits") or md.get("number") or md.get("masked") or "")
        if "*" in digits and md.get("file_path") and md.get("byte_offset") is not None:
            path = Path(str(md["file_path"]))
            try:
                raw = path.read_bytes()
                start = max(0, int(md["byte_offset"]) - 80)
                end = min(len(raw), int(md["byte_offset"]) + 160)
                context = raw[start:end].decode("utf-8", errors="replace")
                candidates = re.findall(rb"(?<!\d)(?:\d[ -]?){12,19}(?!\d)", raw[start:end])
                unmasked = [re.sub(r"\D", "", c.decode("ascii", errors="ignore")) for c in candidates]
                target_last4 = str(md.get("last4") or "")
                digits = next((d for d in unmasked if (not target_last4 or d.endswith(target_last4))), "")
            except (OSError, ValueError):
                context = ""
        else:
            context = str(md.get("context") or md.get("source_context") or "")
        classified = classify_luhn_identifier(digits, context)
        if classified.kind == "imei":
            finding.finding_type = "IMEI_IDENTIFIER"
            finding.severity = Severity.INFO
            finding.description = "A 15-digit Luhn-valid IMEI was confirmed in explicit device/IMEI context."
            md.update(deterministic_metadata("Luhn checksum plus explicit IMEI context", validators=["classify_luhn_identifier"], identifier_kind="IMEI"))
            md["digits"] = classified.digits
            finding.metadata = md
            return True
        if classified.kind == "payment_card" and classified.deterministic:
            md.update(deterministic_metadata("Luhn checksum plus explicit payment-card context", validators=["classify_luhn_identifier"], identifier_kind="payment_card"))
            finding.metadata = md
            return True
        md.update(candidate_metadata("Luhn checksum", reason=classified.reason, candidate_kind=classified.kind))
        finding.metadata = md
        return False

    if "CRYPTO" in ftype or "BITCOIN" in ftype or "WALLET" in ftype:
        values = []
        for key in ("address", "value", "wallet"):
            if md.get(key):
                values.append(str(md[key]))
        for key in ("addresses", "wallets", "bitcoin_addresses"):
            values.extend(str(v) for v in (md.get(key) or []))
        valid = [v for v in values if bitcoin_base58check_valid(v) or bitcoin_bech32_valid(v)]
        if not valid:
            md.update(candidate_metadata("cryptocurrency address regex", reason="No Base58Check/Bech32 checksum validated"))
            finding.metadata = md
            return False
        md.update(deterministic_metadata("Bitcoin Base58Check/Bech32 checksum validation", validators=["bitcoin_base58check_valid", "bitcoin_bech32_valid"]))
        md["validated_addresses"] = valid
        finding.metadata = md
        return True

    return False


def _semantic_safety(finding: Any, inventory_by_path: dict[str, dict[str, Any]]) -> bool:
    """Rewrite or quarantine findings whose semantics exceed parsed structure."""
    ftype = str(getattr(finding, "finding_type", "") or "").upper()
    md = dict(getattr(finding, "metadata", {}) or {})
    path = _path_from_finding(finding)
    inv = inventory_by_path.get(str(path.resolve())) if path else None
    if path and inv is None:
        # A module may retain an extracted derivative whose original source is
        # referenced by inode/offset. Re-classify the retained bytes only for
        # structural semantics; provenance promotion is handled separately.
        try:
            classified = classify_file(path)
            inv = {
                "object_type": classified.object_type,
                "subtype": classified.subtype,
                "deterministic": classified.deterministic,
                "metadata": dict(classified.metadata or {}),
            }
        except Exception:
            inv = None

    if ftype in {"SIGNATURE_CARVED_OBJECT", "SIGNATURE_CARVING_CANDIDATE"}:
        if not path:
            return False
        valid, format_name, details = _structurally_validate_carved_file(path)
        if not valid:
            md.update(candidate_metadata("header/footer carving", reason="The retained bytes did not pass a complete format-structure validator", validation_details=details))
            finding.metadata = md
            return False
        digest = _sha256(path)
        finding.finding_type = "CARVED_FILE_VALIDATED"
        finding.severity = Severity.INFO
        finding.description = (
            f"A structurally complete {format_name.upper()} object was carved and retained; "
            "carving establishes byte presence, not deletion state or provenance."
        )
        md.update(deterministic_metadata(
            "complete format parser validation and SHA-256",
            validators=["format structure", "SHA-256"],
            carved_format=format_name, validation_details=details,
            file_sha256=digest, semantic_limit="Byte presence only; deletion/provenance not inferred",
        ))
        finding.metadata = md
        return True

    if ftype == "CARVING_VOLUME_ARTEFACT":
        md.update(deterministic_metadata(
            "exact sum of candidate byte lengths compared with source size",
            validators=["integer arithmetic"],
            semantic_limit="Overlap/duplication warning; not recovered unique-byte volume",
        ))
        finding.finding_type = "CARVING_OVERLAP_VOLUME_WARNING"
        finding.severity = Severity.INFO
        finding.metadata = md
        return True

    if ftype in {"FILE_SYSTEM_LISTING_COMPLETE", "FILESYSTEM_LISTING_SUMMARY"}:
        total = md.get("total_entries", md.get("total_files"))
        deleted = md.get("deleted_entries", md.get("deleted"))
        manifest_path = _clean_local_path(md.get("listing_manifest") or md.get("report_file"))
        try:
            total_i = int(total)
            deleted_i = int(deleted)
        except (TypeError, ValueError):
            return False
        if total_i < 0 or deleted_i < 0 or deleted_i > total_i or manifest_path is None:
            return False
        manifest_hash = _sha256(manifest_path)
        finding.finding_type = "FILESYSTEM_LISTING_SUMMARY"
        finding.severity = Severity.INFO
        finding.description = (
            f"A retained filesystem listing contains {total_i} entries, including "
            f"{deleted_i} records marked deleted/unallocated by the parser."
        )
        md.update(deterministic_metadata(
            "exact count of retained parser records and SHA-256 of listing manifest",
            validators=["integer bounds", "retained listing manifest", "SHA-256"],
            total_entries=total_i, deleted_entries=deleted_i,
            listing_manifest=str(manifest_path), listing_manifest_sha256=manifest_hash,
            semantic_limit="Count of parser records only; not a count of unique logical files unless separately reconciled",
        ))
        finding.metadata = md
        return True

    if ftype in {"EXTENSION_MISMATCH", "DOUBLE_EXTENSION", "DOUBLE_EXTENSION_FILENAME"} and str(md.get("method") or "").casefold() == "double_extension":
        name = str(md.get("filename") or (path.name if path else ""))
        suffixes = [s.casefold() for s in Path(name).suffixes]
        declared = str(md.get("declared_ext") or "").casefold().lstrip(".")
        inner = str(md.get("inner_ext") or "").casefold().lstrip(".")
        if len(suffixes) < 2:
            return False
        if declared and suffixes[-1].lstrip(".") != declared:
            return False
        if inner and suffixes[-2].lstrip(".") != inner:
            return False
        finding.finding_type = "DOUBLE_EXTENSION_FILENAME"
        finding.severity = Severity.INFO
        finding.description = (
            f"The retained filename '{name}' contains multiple suffix tokens "
            f"({', '.join(suffixes)}). Filename structure alone does not establish concealment intent or execution."
        )
        md.update(deterministic_metadata(
            "exact filename suffix tokenisation", validators=["pathlib.Path.suffixes"],
            suffixes=suffixes, semantic_limit="Filename anomaly only; no intent, execution or maliciousness inferred",
        ))
        finding.metadata = md
        return True

    if ftype in {"TIMELINE_RECONSTRUCTION", "FILESYSTEM_TIMESTAMP_RECORD_SUMMARY"}:
        total = md.get("total_events")
        retained = _clean_local_path(md.get("timeline_manifest") or md.get("report_file") or md.get("mactime_output"))
        try:
            total_i = int(total)
        except (TypeError, ValueError):
            return False
        if total_i < 0 or retained is None:
            return False
        finding.finding_type = "FILESYSTEM_TIMESTAMP_RECORD_SUMMARY"
        finding.severity = Severity.INFO
        finding.description = f"The retained filesystem timestamp output contains {total_i} parser event records."
        md.update(deterministic_metadata(
            "exact count of retained filesystem timestamp records",
            validators=["retained timeline output", "integer count", "SHA-256"],
            timeline_manifest=str(retained), timeline_manifest_sha256=_sha256(retained),
            semantic_limit="Filesystem timestamp records only; cross-corpus chronology is provided by the dedicated timeline builder",
        ))
        finding.metadata = md
        return True

    # High entropy is a measurement, not an evidentiary concealment/malware fact.
    if ftype == "HIGH_ENTROPY_FILE":
        md.update(candidate_metadata("Shannon entropy threshold", reason="Entropy alone cannot distinguish compression, encryption, packing or random data"))
        finding.metadata = md
        return False

    # Password-protected ZIP can be proven from the general-purpose bit flag.
    if ftype == "PASSWORD_PROTECTED_ARCHIVE" and path and _valid_zip_encryption(path):
        md.update(deterministic_metadata("ZIP central/local header encryption flag", validators=["zipfile.ZipInfo.flag_bits"]))
        md["file_sha256"] = _sha256(path)
        finding.metadata = md
        return True

    if ftype == "INVALID_KDBX_SIGNATURE" and path and path.suffix.casefold() == ".kdbx":
        try:
            header = path.read_bytes()[:8]
        except OSError:
            return False
        expected = bytes.fromhex("03d9a29a67fb4bb5")
        if header == expected:
            return False
        md.update(deterministic_metadata(
            "exact KeePass KDBX signature comparison",
            validators=["fixed KDBX file signature", "retained source bytes", "SHA-256"],
            observed_header_hex=header.hex(), expected_signature_hex=expected.hex(),
            semantic_limit="Invalid container signature only; no password, compromise or maliciousness inferred",
        ))
        md["file_sha256"] = _sha256(path)
        finding.metadata = md
        return True

    if "DOUBLE_EXTENSION" in ftype and path:
        suffixes = [s.casefold() for s in path.suffixes]
        if len(suffixes) >= 2:
            md.update(deterministic_metadata("filename suffix tokenisation", validators=["Path.suffixes"]))
            finding.metadata = md
            return True
        return False

    if ftype.startswith("ARTIFACT_EXTRACTED_") or ftype == "USER_REGISTRY_HIVE_FOUND":
        if not path or not inv:
            return False
        obj = str(inv.get("object_type") or "file")
        subtype = str(inv.get("subtype") or "unknown")
        deterministic = bool(inv.get("deterministic"))
        if obj == "windows_shell_link" and not deterministic:
            finding.finding_type = "SHELL_LINK_LIKE_MARKER"
            finding.severity = Severity.INFO
            finding.description = "A Shell-Link-like marker was extracted, but it is not a structurally valid Windows .LNK record."
        elif obj == "windows_event_log" and not deterministic:
            finding.finding_type = "EVTX_LIKE_MARKER"
            finding.severity = Severity.INFO
            finding.description = "An EVTX-like marker was extracted, but it is not a structurally complete Windows Event Log."
        elif obj == "registry_hive":
            finding.finding_type = "REGISTRY_HIVE_CONTAINER"
            finding.severity = Severity.INFO
            finding.description = "A structurally valid REGF registry-hive container was extracted; key/value semantics are reported only when parsed."
        elif deterministic:
            finding.finding_type = "STRUCTURED_ARTIFACT_EXTRACTED"
            finding.severity = Severity.INFO
            finding.description = f"A deterministically classified {obj}/{subtype} artefact was extracted."
        else:
            return False
        md.update(deterministic_metadata("content signature and structural-invariant classification", validators=["evidence_inventory"], object_type=obj, object_subtype=subtype, semantic_limit=("container/marker only" if not deterministic else "parsed structure")))
        md["file_sha256"] = _sha256(path)
        finding.metadata = md
        return True

    if ftype in {"PREFETCH_EXECUTION_RECORD", "PREFETCH_EXECUTION"}:
        if inv and inv.get("object_type") == "windows_prefetch" and inv.get("subtype") == "valid" and inv.get("deterministic"):
            md.update(deterministic_metadata("Prefetch structural parser invariants", validators=["signature", "version", "declared_size"]))
            finding.metadata = md
            return True
        finding.finding_type = "PREFETCH_LIKE_MARKER"
        finding.severity = Severity.INFO
        finding.description = "A Prefetch-like marker was found, but the structure is incomplete and does not prove program execution."
        md.update(deterministic_metadata("Prefetch marker signature/size classification", validators=["evidence_inventory"], semantic_limit="No execution claim"))
        finding.metadata = md
        return True

    if ftype in {"CREDENTIAL_STORE_EXTRACTED", "SAM_PASSWORD_HASHES", "SAM_CREDENTIAL_STORE"}:
        parsed_accounts = int(md.get("account_count") or md.get("hash_count") or 0)
        if parsed_accounts > 0 and md.get("parsed_account_cells"):
            md.update(deterministic_metadata("SAM account/V-cell parser", validators=["registry cell parser"]))
            finding.metadata = md
            return True
        finding.finding_type = "REGISTRY_HIVE_CONTAINER"
        finding.severity = Severity.INFO
        finding.description = "A SAM-named REGF container was found; user-account and password-hash semantics were not structurally validated."
        md.update(deterministic_metadata("REGF container signature/base-block validation", validators=["evidence_inventory"], semantic_limit="No credential/hash claim"))
        finding.metadata = md
        return True

    if ftype in {"ROOTKIT_DETECTED", "HIDDEN_PROCESS", "HIDDEN_PROCESS_DETECTED"}:
        if inv and inv.get("object_type") == "memory_image" and md.get("cross_view_structural_validation"):
            md.update(deterministic_metadata("independent structural memory cross-view", validators=["pslist", "psscan"]))
            finding.metadata = md
            return True
        finding.finding_type = "MEMORY_MARKER_PRESENT"
        finding.severity = Severity.INFO
        finding.description = "A hidden-process/rootkit test marker was present in the memory corpus; no genuine kernel object or rootkit was established."
        md.update(deterministic_metadata("exact byte-string marker extraction", validators=["byte search"], semantic_limit="Marker presence only"))
        finding.metadata = md
        return True

    if ftype in {"PROCESS_FOUND", "MEMORY_PROCESS", "NETWORK_CONNECTION_FOUND"} and inv and inv.get("object_type") == "memory_marker_corpus":
        finding.finding_type = "MEMORY_MARKER_PRESENT"
        finding.severity = Severity.INFO
        finding.description = "A structured process/network marker was extracted from a marker-only memory corpus; no operating-system object semantics are claimed."
        md.update(deterministic_metadata("exact marker record parsing", validators=["byte/string parser"], semantic_limit="No kernel/process/socket provenance"))
        finding.metadata = md
        return True

    # OCR remains useful, but character recognition is inherently probabilistic.
    # Record the engine output as a candidate unless an independent exact source
    # (e.g. embedded text layer) corroborates it.
    if ftype.startswith("OCR_") or ftype in {"TEXT_FROM_IMAGE", "OCR_TEXT_EXTRACTED"}:
        if md.get("corroborated_exact_text_source"):
            md.update(deterministic_metadata("OCR transcription corroborated by exact embedded/structured text", validators=["independent exact source comparison"]))
            finding.metadata = md
            return True
        md.update(candidate_metadata("OCR engine transcription", reason="Character recognition is probabilistic; output retained for examiner review"))
        finding.metadata = md
        return False

    # Co-occurrence is deterministic as a fact only when the exact source record
    # is retained. It must never be elevated to criminality, ownership or intent.
    if "CRIMINAL" in ftype or "NETWORK_MAP" in ftype or "CORRELATION" in ftype:
        if md.get("source_records") or md.get("record_locations") or md.get("cooccurrence_source"):
            finding.finding_type = "IDENTIFIER_COOCCURRENCE"
            finding.severity = Severity.INFO
            finding.description = "Exact identifiers co-occur in the retained source record(s); no identity, ownership, intent or criminal relationship is inferred."
            md.update(deterministic_metadata("exact record-level co-occurrence", validators=["structured record/path equality"], semantic_limit="Correlation only"))
            finding.metadata = md
            return True
        md.update(candidate_metadata("global corpus co-occurrence", reason="No exact shared source record was retained"))
        finding.metadata = md
        return False

    return False



def _apply_memory_marker_fallback(
    result: ModuleResult,
    *,
    module_name: str,
    config: dict[str, Any],
    output_dir: Path,
) -> ModuleResult:
    """Replace a failed structural-memory run with exact marker-level results.

    This is not a claim that Volatility succeeded. The result remains PARTIAL
    for process/network/malware/rootkit modules because kernel-object semantics
    were not available. The string module can complete because exact byte/string
    extraction is its intended technique.
    """
    if not (module_name.startswith("memory_") or module_name == "rootkit_detector"):
        return result
    inventory = ((config.get("_working_set") or {}).get("evidence_inventory") or {})
    # Include every structurally classified marker corpus, not only the one
    # canonical wrapper path. canonical_marker_sources then groups alternate
    # RAW/BIN/MEM/VMEM/DMP/LiME wrappers by the exact marker fingerprint and
    # retains all paths as aliases.
    source_values = [
        str(obj.get("path"))
        for obj in (inventory.get("objects") or [])
        if obj.get("object_type") == "memory_marker_corpus" and obj.get("path")
    ]
    source_values += list((inventory.get("sources") or {}).get("memory_markers") or [])
    source_values += list(config.get("memory_marker_paths") or [])
    source_values = list(dict.fromkeys(source_values))
    groups = canonical_marker_sources([Path(str(v)) for v in source_values if Path(str(v)).is_file()])
    if not groups:
        return result

    relevant_types = {
        "memory_process_list": {"process_marker"},
        "memory_network_connections": {"network_marker"},
        "memory_artifact_extractor": {
            "dns_marker", "url_marker", "email_marker", "credential_marker",
            "api_key_marker", "keyword_marker", "kernel_debugger_marker",
            "os_banner_marker", "validation_marker",
        },
        "memory_malware_scanner": {"malware_test_marker", "validation_marker"},
        "memory_string_analyzer": {
            "process_marker", "network_marker", "hidden_process_marker", "rootkit_marker",
            "dns_marker", "url_marker", "email_marker", "credential_marker", "api_key_marker",
            "keyword_marker", "malware_test_marker", "kernel_debugger_marker",
            "os_banner_marker", "validation_marker",
        },
        "rootkit_detector": {"hidden_process_marker", "rootkit_marker"},
    }.get(module_name, set())

    findings = []
    retained_records: list[dict[str, Any]] = []
    for group in groups:
        aliases = list(group.get("aliases") or [])
        # ASCII and UTF-16LE copies of the same structured record are one
        # logical marker with multiple exact byte occurrences.
        logical_records: dict[tuple[str, str], dict[str, Any]] = {}
        for record in group.get("records") or []:
            if record.get("record_type") not in relevant_types:
                continue
            key = (str(record.get("record_type") or ""), str(record.get("raw_text") or ""))
            current = logical_records.get(key)
            occurrence = {
                "byte_offset": record.get("byte_offset"),
                "byte_length": record.get("byte_length"),
                "source_file": record.get("source_file"),
            }
            if current is None:
                current = dict(record)
                current["occurrences"] = [occurrence]
                logical_records[key] = current
            else:
                current.setdefault("occurrences", []).append(occurrence)

        for record in logical_records.values():
            md = {
                **record,
                "occurrence_count": len(record.get("occurrences") or []),
                "file_sha256": group.get("file_sha256"),
                "marker_fingerprint": group.get("marker_fingerprint"),
                "wrapper_aliases": aliases,
                **deterministic_metadata(
                    "exact structured marker grammar parsed at retained byte offset(s)",
                    validators=["core.deterministic_memory", "byte-offset verification"],
                    semantic_limit="Marker presence only; no kernel/process/socket/malware/rootkit object provenance",
                ),
            }
            rtype = str(record.get("record_type") or "memory_marker")
            finding_type = {
                "process_marker": "MEMORY_PROCESS_MARKER",
                "network_marker": "MEMORY_NETWORK_MARKER",
                "hidden_process_marker": "MEMORY_HIDDEN_PROCESS_MARKER",
                "rootkit_marker": "MEMORY_ROOTKIT_MARKER",
                "malware_test_marker": "MEMORY_MALWARE_TEST_MARKER",
            }.get(rtype, "MEMORY_STRUCTURED_MARKER")
            offsets = [o.get("byte_offset") for o in record.get("occurrences") or []]
            desc = (
                f"Exact {rtype.replace('_', ' ')} bytes were parsed from a marker-oriented memory corpus "
                f"at {len(offsets)} retained occurrence(s); no operating-system object semantics are claimed."
            )
            findings.append(make_finding(
                finding_type=finding_type,
                severity=Severity.INFO,
                description=desc,
                evidence_path=str(group.get("path")),
                metadata=md,
                artifact_path=str(group.get("path")),
            ))
            retained_records.append(md)

    if not findings:
        return result

    output_dir.mkdir(parents=True, exist_ok=True)
    artifact = output_dir / "deterministic_memory_marker_records.json"
    artifact.write_text(json.dumps({
        "module": module_name,
        "case_id": result.case_id,
        "structural_engine_status": str(getattr(result, "status", "")),
        "structural_engine_errors": list(result.errors or []),
        "records": retained_records,
    }, indent=2, ensure_ascii=True, default=str), encoding="utf-8")

    original_errors = list(result.errors or [])
    result.findings = findings
    result.artifact_paths = list(result.artifact_paths or []) + [str(artifact)]
    result.status = ModuleStatus.COMPLETED if module_name == "memory_string_analyzer" else ModuleStatus.PARTIAL
    result.summary = (
        f"Parsed {len(findings)} exact structured marker record(s) from {len(groups)} canonical memory corpus/corpora. "
        + ("String-level examination completed." if module_name == "memory_string_analyzer" else
           "Volatility structural semantics remained indeterminate and no genuine process/socket/malware/rootkit claim is made.")
    )
    stats = dict(result.statistics or {})
    stats.update({
        "marker_records": len(findings),
        "marker_corpora": len(groups),
        "structural_analysis_successful": False,
        "marker_fallback_applied": True,
    })
    result.statistics = stats
    result.errors = original_errors
    result.class_results = [ClassResult(
        locus=Locus.MEMORY if module_name != "rootkit_detector" else Locus.MALWARE,
        artefact_class="Structured Memory Markers",
        verdict=AssuranceVerdict.PRESENT,
        count=len(findings),
        notes="Exact marker records are present; operating-system structural semantics are INDETERMINATE.",
    )]
    return result



def _candidate_record(finding: Any, metadata: dict[str, Any]) -> dict[str, Any]:
    """Serialise one quarantined observation with explicit non-counting semantics.

    An observation can be deterministically *classified* as rejected/candidate while
    still being ineligible for evidentiary promotion.  Preserve an explicit REJECTED
    state instead of rewriting every non-accepted observation as CANDIDATE_ONLY.
    """
    md = dict(metadata or {})
    explicit_state = str(
        md.get("ledger_state") or md.get("validation_state") or md.get("candidate_state") or ""
    ).upper().strip()
    rejected = bool(md.get("rejected")) or str(md.get("fact_class") or "").upper() == "REJECTED" or explicit_state == "REJECTED"
    md.setdefault("finding_basis", "candidate")
    md["deterministic_validation"] = False
    md["counts_toward_unique_evidence"] = False
    if rejected:
        md["ledger_state"] = "REJECTED"
        md["candidate_only"] = False
        md["rejected"] = True
        md["fact_class"] = "REJECTED"
    else:
        if explicit_state == "UNRESOLVED":
            md["ledger_state"] = "UNRESOLVED"
        elif explicit_state == "CANDIDATE":
            md["ledger_state"] = "CANDIDATE"
        md["candidate_only"] = True
        md["rejected"] = False
        md["fact_class"] = "CANDIDATE_ONLY"
    finding.metadata = md
    return {
        "finding_id": getattr(finding, "finding_id", ""),
        "finding_type": getattr(finding, "finding_type", ""),
        "description": getattr(finding, "description", ""),
        "metadata": md,
    }

def reconcile_module_result(
    result: ModuleResult,
    *,
    module_name: str,
    evidence_path: Path,
    config: dict[str, Any],
    output_dir: Path,
) -> ModuleResult:
    """Apply evidence-agnostic deterministic promotion rules to a module result."""
    inventory = ((config.get("_working_set") or {}).get("evidence_inventory") or {})
    inventory_by_path: dict[str, dict[str, Any]] = {}
    for obj in inventory.get("objects") or []:
        try:
            inventory_by_path[str(Path(str(obj.get("path"))).resolve())] = obj
        except OSError:
            continue

    inventory_sha = _inventory_sha_index(inventory)
    working_set = config.get("_working_set") or {}
    sources = inventory.get("sources") or {}
    marker_only_memory = bool(sources.get("memory_markers")) and not bool(sources.get("memory_structural"))

    if module_name.startswith("memory_") or module_name == "rootkit_detector":
        if result.status in {ModuleStatus.ERROR, ModuleStatus.SKIPPED, ModuleStatus.PARTIAL} or not list(result.findings or []):
            result = _apply_memory_marker_fallback(
                result, module_name=module_name, config=config, output_dir=output_dir
            )

    kept = []
    candidates: list[dict[str, Any]] = []
    exact_types = {
        "FILE_SIGNATURE_MISMATCH", "YARA_RULE_MATCH", "CLAMAV_DETECTION",
        "HASH_DATABASE_MATCH", "KNOWN_HASH_MATCH", "DELETED_FILE_RECOVERED",
        "GPS_COORDINATES_FOUND", "TRAILING_DATA_PRESENT", "STEGANOGRAPHIC_PAYLOAD_DECODED",
        "REGISTRY_HIVE_CONTAINER", "PCAP_CAPTURE", "DNS_RECORD", "HTTP_TRANSACTION", "NETWORK_PROTOCOL_RECORD",
        "PASSWORD_RECOVERED", "IOC_EXACT_MATCH", "MOBILE_DATABASE_RECORD",
        "FILE_SLACK_DATA", "NONZERO_UNALLOCATED_RUN", "UNALLOCATED_DUPLICATE_OBJECT",
        "GEOLOCATION_SOURCE_DISCREPANCY", "STRUCTURED_DOCUMENT_ROWS", "STRUCTURED_JSON_DOCUMENT",
        "DOCUMENT_CASE_IDENTIFIER_MISMATCH", "KDBX_CONTAINER_VALID", "KDBX_LIKE_MARKER",
        "MACRO_DETECTED", "EMBEDDED_OLE_OBJECT", "EXTERNAL_DOCUMENT_RELATIONSHIP",
        "MEMORY_PROCESS_MARKER", "MEMORY_NETWORK_MARKER", "MEMORY_HIDDEN_PROCESS_MARKER",
        "MEMORY_ROOTKIT_MARKER", "MEMORY_MALWARE_TEST_MARKER", "MEMORY_STRUCTURED_MARKER",
        "FILESYSTEM_STRUCTURE_CONFIRMED", "HOSTS_FILE_ENTRY", "REGISTRY_EXPORT_VALUE",
        "EVTX_LIKE_MARKER", "SHELL_LINK_LIKE_MARKER", "PREFETCH_LIKE_MARKER",
        "BROWSER_DATABASE_PARSED", "BROWSER_VISIT_RECORD", "BROWSER_DOWNLOAD_RECORD",
        "IDENTIFIER_LITERAL_OCCURRENCE", "IDENTIFIER_RECORD_COOCCURRENCE",
        "EMAIL_ADDRESS_LITERAL", "MESSAGE_IDENTIFIER_LITERAL", "URL_LITERAL",
        "IP_ADDRESS_LITERAL", "REGISTRY_PATH_LITERAL", "BITCOIN_ADDRESS_CHECKSUM_VALID",
        "BASE64_PAYLOAD_VALIDATED", "GEOLOCATION_ARTIFACT_COORDINATES",
        "PASSWORD_PROTECTED_ARCHIVE", "NATIVE_EVIDENCE_ACCESS_STATUS",
    }

    for finding in list(result.findings or []):
        md = dict(getattr(finding, "metadata", {}) or {})
        ftype = str(getattr(finding, "finding_type", "") or "").upper()
        finding_path = _path_from_finding(finding)
        source_role = (
            source_role_for_path(finding_path, working_set, output_dir=output_dir)
            if finding_path else SourceRole.UNKNOWN
        )
        lineage_path, lineage_method = _resolve_evidentiary_lineage(
            finding, evidence_path=evidence_path, working_set=working_set,
            output_dir=output_dir, inventory_sha=inventory_sha,
        )
        # Explicit evidence self-declarations are already bound to an exact retained
        # source path/hash/excerpt by evidence_validator.  Do not rewrite that
        # path through generic lineage resolution, which could cross-wire it to
        # an unrelated deleted/derived object.
        if ftype == "SYNTHETIC_VALIDATION_DECLARATION":
            exact = Path(str(md.get("retained_source_path") or getattr(finding, "evidence_path", "") or ""))
            if exact.is_file():
                lineage_path = exact
                lineage_method = "exact_declaration_source"
                finding_path = exact
                source_role = SourceRole.EVIDENTIARY_CONTENT

        if lineage_path is not None:
            prior_evidence_path = str(getattr(finding, "evidence_path", "") or "")
            if finding_path and source_role == SourceRole.DERIVED_TOOL_OUTPUT:
                if not getattr(finding, "artifact_path", None):
                    finding.artifact_path = str(finding_path)
                md["derived_artifact_path"] = str(finding_path)
            if prior_evidence_path and not _clean_local_path(prior_evidence_path):
                md.setdefault("logical_evidence_path", prior_evidence_path)
            finding.evidence_path = str(lineage_path)
            md["provenance_source_path"] = str(lineage_path)
            md["provenance_lineage_method"] = lineage_method
            md["source_role"] = SourceRole.EVIDENTIARY_CONTENT.value
            md["source_role_policy"] = "Canonical findings require a retained evidentiary source or exact deterministic lineage to it."
            source_role = SourceRole.EVIDENTIARY_CONTENT
            finding_path = lineage_path
        else:
            md.update(provenance_metadata(finding_path, working_set, output_dir=output_dir) if finding_path else {"source_role": SourceRole.UNKNOWN.value})
        finding.metadata = md

        # A module may deterministically establish that an object is a candidate
        # (for example, a structurally valid encrypted ZIP whose payload cannot be
        # integrity-checked without credentials).  Deterministic knowledge of the
        # *candidate state* is not deterministic validation of the evidentiary claim.
        # Quarantine explicit candidate/rejected states before generic promotion so
        # they can never leak into accepted findings merely because another metadata
        # field says deterministic_validation=true.
        _explicit_state = str(
            md.get("ledger_state") or md.get("validation_state") or md.get("candidate_state") or ""
        ).upper().strip()
        _explicit_fact_class = str(md.get("fact_class") or "").upper().strip()
        if (
            bool(md.get("candidate_only"))
            or _explicit_fact_class == "CANDIDATE_ONLY"
            or _explicit_state in {"CANDIDATE", "UNRESOLVED"}
        ):
            candidates.append(_candidate_record(finding, md))
            continue
        if (
            bool(md.get("rejected"))
            or _explicit_fact_class == "REJECTED"
            or _explicit_state == "REJECTED"
        ):
            candidates.append(_candidate_record(finding, md))
            continue

        # Configuration, validation references and module-generated derivatives
        # may be retained as provenance/context, but they cannot corroborate an
        # ordinary case finding. This is a final fail-closed gate even if a
        # module accidentally scans such a path.
        non_evidentiary_roles = {
            SourceRole.ANALYSIS_CONFIGURATION,
            SourceRole.VALIDATION_REFERENCE,
            SourceRole.DERIVED_TOOL_OUTPUT,
        }
        context_only_types = {
            "ANALYSIS_CONFIGURATION_RETAINED", "VALIDATION_REFERENCE_RETAINED",
            "DERIVED_OUTPUT_RETAINED", "CASE_CONTEXT_DECLARATION",
            "SYNTHETIC_VALIDATION_DECLARATION",
        }
        original_locator_keys = (
            "raw_offset", "offset_bytes", "byte_offset", "source_offset",
            "source_start", "source_end", "source_length",
            "inode", "meta_address", "cluster", "first_cluster",
            "packet_number", "frame_number", "frame.number", "stream_id",
            "table", "rowid", "row", "line", "json_path", "message_index",
        )
        has_original_locator = any(md.get(k) not in (None, "", [], {}) for k in original_locator_keys)
        evidence_resident_configuration = (
            source_role == SourceRole.ANALYSIS_CONFIGURATION and
            _allow_evidence_resident_configuration(ftype, finding_path, working_set, output_dir)
        )
        if evidence_resident_configuration:
            md["source_role"] = "EVIDENTIARY_CONFIGURATION"
            md["semantic_limit"] = (
                "Exact observation about configuration retained inside the evidence; "
                "the configured value is not treated as external ground truth or reputation."
            )
            md["promotion_source"] = "evidence_resident_configuration_exact_validation"
            source_role = SourceRole.EVIDENTIARY_CONTENT
            finding.metadata = md

        # Preserve the explicit locator promotion marker even when the newer
        # lineage resolver has already rewritten a derivative to its original
        # evidentiary source.  This keeps the report clear about *why* the
        # retained tool output was accepted rather than making the derivative
        # appear self-authenticating.
        if (
            lineage_path is not None
            and md.get("derived_artifact_path")
            and has_original_locator
        ):
            md.setdefault("promotion_source", "original_evidence_locator")
            finding.metadata = md

        derived_with_locator = source_role == SourceRole.DERIVED_TOOL_OUTPUT and has_original_locator
        if derived_with_locator:
            md["retained_derivative_role"] = SourceRole.DERIVED_TOOL_OUTPUT.value
            md["promotion_source"] = "original_evidence_locator"
            md["source_role"] = SourceRole.EVIDENTIARY_CONTENT.value
            finding.metadata = md
        if source_role in non_evidentiary_roles and not derived_with_locator and ftype not in context_only_types:
            md.update(candidate_metadata(
                "non-evidentiary source occurrence",
                reason=(
                    f"Source role {source_role.value} may control/describe the analysis "
                    "but cannot independently support an ordinary case finding"
                ),
            ))
            finding.metadata = md
            candidates.append(_candidate_record(finding, md))
            continue
        if source_role == SourceRole.CASE_CONTEXT and ftype not in context_only_types:
            md.update(candidate_metadata(
                "case-context occurrence",
                reason="Case-context documents do not independently corroborate ordinary artefact findings",
            ))
            finding.metadata = md
            candidates.append(_candidate_record(finding, md))
            continue

        # Detection engines establish an exact rule/signature match, not
        # maliciousness.  Matches in rule/configuration/documentation material
        # are classified as signature-text occurrences rather than detections
        # against an operational artefact.
        if ftype in {"YARA_RULE_MATCH", "CLAMAV_DETECTION"}:
            det_path = _path_from_finding(finding)
            inv_obj = inventory_by_path.get(str(det_path.resolve())) if det_path else None
            suffix = det_path.suffix.casefold() if det_path else ""
            det_role = source_role_for_path(det_path, config.get("_working_set") or {}, output_dir=output_dir) if det_path else SourceRole.UNKNOWN
            logical = str(det_path or "").replace("\\", "/").casefold()
            if det_role in {SourceRole.ANALYSIS_CONFIGURATION, SourceRole.VALIDATION_REFERENCE, SourceRole.DERIVED_TOOL_OUTPUT} or suffix in {".yar", ".yara", ".ndb"}:
                finding.finding_type = "SIGNATURE_TEXT_OCCURRENCE"
                finding.severity = Severity.INFO
                finding.description = (
                    "The exact rule/signature target text occurs in retained configuration or validation material; "
                    "this is not a malware verdict for the file."
                )
                md["source_role"] = "configuration_or_validation_material"
                md["semantic_limit"] = "Exact signature-text occurrence only; no malware behaviour or maliciousness inferred."
                md.update(deterministic_metadata(
                    "engine match plus source-role classification",
                    validators=[module_name, "evidence inventory source role"],
                ))
                finding.metadata = md
                ftype = "SIGNATURE_TEXT_OCCURRENCE"
            else:
                finding.severity = Severity.INFO
                md["semantic_limit"] = "Exact rule/signature match only; malicious behaviour and intent are not inferred."
                finding.metadata = md

        accepted = False
        basis = str(md.get("finding_basis") or "").casefold()
        semantic_gate_types = {
            "FILE_SYSTEM_LISTING_COMPLETE", "FILESYSTEM_LISTING_SUMMARY",
            "EXTENSION_MISMATCH", "DOUBLE_EXTENSION", "DOUBLE_EXTENSION_FILENAME",
            "TIMELINE_RECONSTRUCTION", "FILESYSTEM_TIMESTAMP_RECORD_SUMMARY",
            "HIGH_ENTROPY_FILE", "PASSWORD_PROTECTED_ARCHIVE", "INVALID_KDBX_SIGNATURE",
        }
        if ftype in semantic_gate_types:
            accepted = _semantic_safety(finding, inventory_by_path)
        elif basis in {"candidate", "heuristic", "probabilistic"} and not md.get("deterministic_validation"):
            # A syntactically valid token does not upgrade a probabilistic source
            # such as OCR, entropy or opaque-binary strings into evidence.
            accepted = False
        elif md.get("deterministic_validation"):
            accepted = True
        elif marker_only_memory and (module_name.startswith("memory_") or module_name == "rootkit_detector"):
            # Exact bytes/records in a marker-only memory fixture are valid
            # evidence of marker presence, but not of genuine kernel objects,
            # processes, sockets, malware or rootkits.
            finding.finding_type = "MEMORY_MARKER_PRESENT"
            finding.severity = Severity.INFO
            finding.description = (
                "An exact structured marker/string was extracted from a marker-only memory corpus; "
                "no operating-system object, process, socket, malware or rootkit semantic is claimed."
            )
            md.update(deterministic_metadata(
                "exact byte/string marker extraction from inventory-classified marker corpus",
                validators=["evidence_inventory", module_name],
                semantic_limit="marker presence only",
                memory_marker_sources=sources.get("memory_markers"),
            ))
            finding.metadata = md
            accepted = True
        elif _validate_exact_identifier_finding(finding):
            accepted = True
        elif _semantic_safety(finding, inventory_by_path):
            accepted = True
        elif ftype in exact_types:
            path = _path_from_finding(finding)
            # Exact engine/parser matches must carry at least the rule/signature,
            # a retained path/offset, or a hash before automatic promotion.
            has_locator = bool(path or any(md.get(k) not in (None, "", [], {}) for k in (
                "raw_offset", "byte_offset", "packet_number", "stream_id", "rule_name",
                "virus_name", "hash", "sha256", "inode", "database", "rowid",
            )))
            if has_locator:
                md.update(deterministic_metadata("module parser/engine exact match", validators=[module_name]))
                if path:
                    md.setdefault("file_sha256", _sha256(path))
                finding.metadata = md
                accepted = True
        else:
            # Strong deterministic filename/content anomalies can be promoted.
            if ftype in {"DOUBLE_EXTENSION", "PASSWORD_PROTECTED_ARCHIVE"}:
                accepted = _semantic_safety(finding, inventory_by_path)

        if accepted:
            kept.append(finding)
        else:
            md = dict(getattr(finding, "metadata", {}) or {})
            if not md.get("finding_basis"):
                md.update(candidate_metadata("unclassified module observation", reason="No deterministic validator confirmed the precise claim"))
                finding.metadata = md
            candidates.append(_candidate_record(finding, md))

    # Deterministic de-duplication.  Byte-identical carved objects and exact
    # duplicate findings are represented once with retained aliases.
    deduped = []
    seen_keys: dict[tuple[str, str, str], Any] = {}
    carve_registry = ((config.get("_working_set") or {}).setdefault("_deterministic_carve_registry", {}))
    for finding in kept:
        md = dict(getattr(finding, "metadata", {}) or {})
        ftype = str(getattr(finding, "finding_type", "") or "")
        digest = str(md.get("file_sha256") or md.get("sha256") or "")
        locator_fields = (
            "raw_offset", "offset_bytes", "byte_offset", "source_offset",
            "source_start", "source_end", "source_length", "file_name",
            "packet_number", "frame_number", "frame.number", "stream_id", "tcp.stream",
            "rowid", "row", "line", "line_number", "json_path", "message_index",
            "field_name", "record_id", "record_index", "database", "table",
            # Semantic sub-record identity. Multiple deterministic facts may
            # legitimately originate from one file and therefore share its hash.
            # They must not be collapsed merely because the container is equal.
            "metadata_namespace", "metadata_field", "metadata_value",
            "namespace", "field", "value", "archive_member", "member_name",
            "registry_key", "key_path", "value_name", "value_data",
            "query_name", "query", "answer", "record_type", "event_type",
            "timestamp_meaning", "subject", "message_id",
        )
        locator_payload = {k: md.get(k) for k in locator_fields if md.get(k) not in (None, "", [], {})}
        locator = (
            json.dumps(locator_payload, sort_keys=True, default=str)
            if locator_payload else str(getattr(finding, "evidence_path", "") or "")
        )
        if ftype == "CARVED_FILE_VALIDATED" and digest:
            # One canonical content object is retained per SHA-256. Every exact
            # physical occurrence remains visible in ``physical_occurrences``;
            # tool-generated copies without a source offset are aliases only.
            alias_path = str(_path_from_finding(finding) or "")
            source_path = str(getattr(finding, "evidence_path", "") or "")
            offset_raw = next((md.get(key) for key in (
                "raw_offset", "offset_bytes", "byte_offset", "source_offset", "source_start"
            ) if md.get(key) not in (None, "")), None)
            try:
                reliable_offset = int(offset_raw) if offset_raw is not None else None
            except (TypeError, ValueError):
                reliable_offset = None
            size_raw = next((md.get(key) for key in (
                "structured_length", "size_bytes", "length", "carved_size"
            ) if md.get(key) not in (None, "")), None)
            try:
                occurrence_size = int(size_raw) if size_raw is not None else None
            except (TypeError, ValueError):
                occurrence_size = None

            group = carve_registry.setdefault(digest, {
                "finding": None, "physical_occurrences": [], "tool_aliases": [],
            })
            occurrence = {
                "module": module_name, "path": alias_path, "source_path": source_path,
                "offset": reliable_offset, "size": occurrence_size,
            }
            if reliable_offset is not None:
                occurrence_key = (reliable_offset, occurrence_size, source_path)
                existing_keys = {
                    (o.get("offset"), o.get("size"), o.get("source_path"))
                    for o in group["physical_occurrences"]
                }
                if occurrence_key not in existing_keys:
                    group["physical_occurrences"].append(occurrence)
            else:
                group["tool_aliases"].append({
                    **occurrence, "match_basis": "content_sha256_only_offset_unavailable",
                })

            prior_finding = group.get("finding")
            if prior_finding is not None:
                prior_md = dict(getattr(prior_finding, "metadata", {}) or {})
                prior_md["physical_occurrences"] = list(group["physical_occurrences"])
                prior_md["physical_occurrence_count"] = len(group["physical_occurrences"])
                prior_md["duplicate_tool_aliases"] = list(group["tool_aliases"])
                prior_finding.metadata = prior_md
                continue

            group["finding"] = finding
            md["physical_occurrences"] = list(group["physical_occurrences"])
            md["physical_occurrence_count"] = len(group["physical_occurrences"])
            md["duplicate_tool_aliases"] = list(group["tool_aliases"])
            md["content_object_identity"] = "sha256"
            finding.metadata = md
        # Signature-engine outputs are grouped by the logical target and rule,
        # not by every wrapper/extraction path.  Marker-only memory wrappers
        # share an inventory marker fingerprint even when DMP/LiME headers make
        # their whole-file hashes differ.
        if ftype in {"YARA_RULE_MATCH", "CLAMAV_DETECTION", "SIGNATURE_TEXT_OCCURRENCE"}:
            path_obj = _path_from_finding(finding)
            inv_obj = inventory_by_path.get(str(path_obj.resolve())) if path_obj else None
            logical_target = str(((inv_obj or {}).get("metadata") or {}).get("marker_fingerprint") or digest)
            signature_name = str(md.get("rule_name") or md.get("virus_name") or md.get("signature") or "")
            key = (ftype, signature_name, logical_target)
        elif ftype == "REGISTRY_HIVE_CONTAINER" and digest:
            key = (ftype, digest, "")
        elif ftype == "HTTP_TRANSACTION":
            direction = str(md.get("direction") or "")
            frame = str(md.get("frame.number") or md.get("frame_number") or "")
            stream = str(md.get("tcp.stream") or md.get("stream_id") or "")
            semantic = "|".join(str(md.get(k) or "") for k in (
                "http.request.method", "http.request.uri", "http.response.code",
                "ip.src", "ip.dst", "tcp.srcport", "tcp.dstport",
            ))
            key = (ftype, digest, direction + "|" + (frame or stream or semantic))
        elif ftype == "HOSTS_FILE_ENTRY":
            record_key = json.dumps({k: md.get(k) for k in (
                "line", "line_number", "ip", "hostname", "hostnames", "value"
            )}, sort_keys=True, default=str)
            key = (ftype, digest, record_key)
        elif ftype in {"IDENTIFIER_LITERAL_OCCURRENCE", "IDENTIFIER_RECORD_COOCCURRENCE",
                       "EMAIL_ADDRESS_LITERAL", "MESSAGE_IDENTIFIER_LITERAL", "URL_LITERAL",
                       "IP_ADDRESS_LITERAL", "REGISTRY_PATH_LITERAL"}:
            value = str(md.get("identifier_value") or md.get("value") or md.get("source_identifier") or "")
            record_key = json.dumps({k: md.get(k) for k in ("table", "rowid", "row", "line", "json_path", "message_index", "field_name")}, sort_keys=True, default=str)
            key = (ftype, value, digest + record_key)
        else:
            key = (ftype, digest, locator)
        key_trackable = bool(digest or ftype in {
            "YARA_RULE_MATCH", "CLAMAV_DETECTION", "SIGNATURE_TEXT_OCCURRENCE",
            "IDENTIFIER_LITERAL_OCCURRENCE", "IDENTIFIER_RECORD_COOCCURRENCE",
            "EMAIL_ADDRESS_LITERAL", "MESSAGE_IDENTIFIER_LITERAL", "URL_LITERAL",
            "IP_ADDRESS_LITERAL", "REGISTRY_PATH_LITERAL",
        })
        if key_trackable and key in seen_keys:
            first = seen_keys[key]
            first_md = dict(getattr(first, "metadata", {}) or {})
            first_md.setdefault("duplicate_aliases", []).append({
                "module": module_name, "path": str(_path_from_finding(finding) or ""),
                "finding_id": getattr(finding, "finding_id", ""),
            })
            first.metadata = first_md
            continue
        if key_trackable:
            seen_keys[key] = finding
        deduped.append(finding)

    kept = deduped
    result.findings = kept
    original_summary = str(result.summary or "").strip()
    result.summary = (
        f"Canonical deterministic outcome: {len(kept)} accepted finding(s); "
        f"{len(candidates)} candidate observation(s) retained separately."
        + (f" Module execution note: {original_summary}" if original_summary else "")
    )
    # Place every non-accepted observation into exactly one ledger state.  This
    # happens before completion certification so candidate/rejected/unresolved
    # counts cannot disappear from module certificates.
    candidates, ledger_counts = normalise_candidate_records(module_name, candidates)
    stats = dict(result.statistics or {})
    stats["deterministic_reconciliation"] = {
        "promoted_findings": len(kept),
        "candidate_observations": ledger_counts.get("CANDIDATE", 0),
        "rejected_observations": ledger_counts.get("REJECTED", 0),
        "unresolved_observations": ledger_counts.get("UNRESOLVED", 0),
        "total_nonaccepted_observations": sum(ledger_counts.values()),
        "ledger_counts": ledger_counts,
        "policy": (
            "Every observation is ACCEPTED, CANDIDATE, REJECTED or UNRESOLVED. "
            "Only accepted, reproducibly validated claims enter PRESENT findings."
        ),
    }
    if candidates:
        candidate_path = output_dir / "candidate_observations.json"
        candidate_path.parent.mkdir(parents=True, exist_ok=True)
        candidate_path.write_text(json.dumps({
            "module": module_name,
            "case_id": result.case_id,
            "ledger_counts": ledger_counts,
            "candidates": candidates,
        }, indent=2, ensure_ascii=True, default=str), encoding="utf-8")
        result.artifact_paths = list(result.artifact_paths or []) + [str(candidate_path)]
        stats["deterministic_reconciliation"]["candidate_file"] = str(candidate_path)
    # A carver may emit many overlapping or malformed candidates. Once those
    # candidates are quarantined and at least one complete structurally valid
    # object remains, the carving technique itself completed successfully; the
    # rejected candidates are not a module failure.
    if module_name == "native_signature_carver":
        unresolved_carves = int(ledger_counts.get("UNRESOLVED", 0))
        if result.status == ModuleStatus.PARTIAL and not list(result.errors or []) and kept and unresolved_carves == 0:
            result.status = ModuleStatus.COMPLETED
            result.summary = (
                f"Carving completed with {len(kept)} deterministic retained result(s); "
                f"{len(candidates)} overlapping, incomplete or unvalidated candidate(s) were quarantined."
            )
            for cr in list(result.class_results or []):
                cr.count = len([f for f in kept if str(getattr(f, "finding_type", "")) == "CARVED_FILE_VALIDATED"])
                cr.notes = (str(cr.notes or "") + " Unvalidated/overlapping outputs were retained only as candidate observations.").strip()

    result.statistics = stats
    return result
