"""Deterministic reconciliation for specialist file-carver output.

The carver process is only a candidate generator.  This module validates the
retained bytes, proves their exact source interval, correlates duplicate and
overlap relationships, and classifies every output as ACCEPTED, REJECTED or
UNRESOLVED.  It contains no corpus-specific values and never reads a reference
answer key.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from io import BytesIO
import hashlib
import json
import struct
import zlib
import zipfile
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class StructureResult:
    valid: bool
    format_name: str
    structured_length: int | None
    details: dict[str, Any]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha256_interval(path: Path, start: int, length: int) -> str:
    if start < 0 or length < 0:
        raise ValueError("negative source interval")
    h = hashlib.sha256()
    remaining = length
    with path.open("rb") as fh:
        fh.seek(start)
        while remaining:
            block = fh.read(min(1024 * 1024, remaining))
            if not block:
                raise EOFError("source interval extends beyond source")
            h.update(block)
            remaining -= len(block)
    return h.hexdigest()


def _png(data: bytes) -> StructureResult:
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        return StructureResult(False, "png", None, {"reason": "PNG signature missing"})
    pos = 8
    chunks = 0
    seen_ihdr = False
    while pos + 12 <= len(data):
        length = int.from_bytes(data[pos:pos + 4], "big")
        kind = data[pos + 4:pos + 8]
        end = pos + 12 + length
        if end > len(data):
            return StructureResult(False, "png", None, {"reason": "truncated chunk", "chunk": kind.decode("latin1", "replace")})
        payload = data[pos + 8:pos + 8 + length]
        stored_crc = int.from_bytes(data[pos + 8 + length:end], "big")
        actual_crc = zlib.crc32(kind + payload) & 0xFFFFFFFF
        if stored_crc != actual_crc:
            return StructureResult(False, "png", None, {"reason": "CRC mismatch", "chunk": kind.decode("latin1", "replace")})
        chunks += 1
        if kind == b"IHDR":
            if seen_ihdr or chunks != 1 or length != 13:
                return StructureResult(False, "png", None, {"reason": "invalid IHDR placement/length"})
            seen_ihdr = True
        if kind == b"IEND":
            if length != 0 or not seen_ihdr:
                return StructureResult(False, "png", None, {"reason": "invalid IEND/IHDR sequence"})
            return StructureResult(True, "png", end, {"chunks": chunks, "trailing_bytes": len(data) - end})
        pos = end
    return StructureResult(False, "png", None, {"reason": "IEND not found", "chunks": chunks})


def _gif(data: bytes) -> StructureResult:
    if not (data.startswith(b"GIF87a") or data.startswith(b"GIF89a")) or len(data) < 13:
        return StructureResult(False, "gif", None, {"reason": "GIF header/logical descriptor missing"})
    packed = data[10]
    pos = 13
    if packed & 0x80:
        pos += 3 * (2 ** ((packed & 0x07) + 1))
    frames = 0
    try:
        while pos < len(data):
            marker = data[pos]
            pos += 1
            if marker == 0x3B:
                return StructureResult(True, "gif", pos, {"frames": frames, "trailing_bytes": len(data) - pos})
            if marker == 0x2C:  # image descriptor
                if pos + 9 > len(data):
                    raise ValueError("truncated image descriptor")
                image_packed = data[pos + 8]
                pos += 9
                if image_packed & 0x80:
                    pos += 3 * (2 ** ((image_packed & 0x07) + 1))
                if pos >= len(data):
                    raise ValueError("missing LZW minimum code size")
                pos += 1
                frames += 1
            elif marker == 0x21:  # extension introducer
                if pos >= len(data):
                    raise ValueError("truncated extension")
                pos += 1
            else:
                raise ValueError(f"unexpected block marker 0x{marker:02x}")
            while True:  # sub-block sequence
                if pos >= len(data):
                    raise ValueError("truncated sub-block sequence")
                size = data[pos]
                pos += 1
                if size == 0:
                    break
                pos += size
                if pos > len(data):
                    raise ValueError("truncated sub-block")
    except ValueError as exc:
        return StructureResult(False, "gif", None, {"reason": str(exc), "frames": frames})
    return StructureResult(False, "gif", None, {"reason": "GIF trailer not found", "frames": frames})


def _jpeg(data: bytes) -> StructureResult:
    if not data.startswith(b"\xff\xd8\xff"):
        return StructureResult(False, "jpeg", None, {"reason": "JPEG SOI missing"})
    # Complete decode is the primary structural validator.  The last EOI before
    # trailing bytes is retained as the deterministic encoded-stream boundary.
    try:
        from PIL import Image
        with Image.open(BytesIO(data)) as image:
            image.load()
            dimensions = [int(image.width), int(image.height)]
            mode = str(image.mode)
    except Exception as exc:
        return StructureResult(False, "jpeg", None, {"reason": f"complete decode failed: {exc}"})
    eoi = data.rfind(b"\xff\xd9")
    if eoi < 2:
        return StructureResult(False, "jpeg", None, {"reason": "EOI marker missing"})
    end = eoi + 2
    return StructureResult(True, "jpeg", end, {"dimensions": dimensions, "mode": mode, "trailing_bytes": len(data) - end})


def _bmp(data: bytes) -> StructureResult:
    if len(data) < 54 or not data.startswith(b"BM"):
        return StructureResult(False, "bmp", None, {"reason": "BMP file header missing"})
    declared = int.from_bytes(data[2:6], "little")
    pixel_offset = int.from_bytes(data[10:14], "little")
    dib_size = int.from_bytes(data[14:18], "little")
    if dib_size < 12 or 14 + dib_size > len(data):
        return StructureResult(False, "bmp", None, {"reason": "invalid DIB header size", "dib_size": dib_size})
    if dib_size >= 40:
        width = int.from_bytes(data[18:22], "little", signed=True)
        height = int.from_bytes(data[22:26], "little", signed=True)
        planes = int.from_bytes(data[26:28], "little")
        bpp = int.from_bytes(data[28:30], "little")
        compression = int.from_bytes(data[30:34], "little")
        if width == 0 or height == 0 or planes != 1 or bpp == 0:
            return StructureResult(False, "bmp", None, {"reason": "invalid dimensions/planes/bpp"})
        if compression in {0, 3}:
            row = ((abs(width) * bpp + 31) // 32) * 4
            required = pixel_offset + row * abs(height)
        else:
            image_size = int.from_bytes(data[34:38], "little")
            required = pixel_offset + image_size
    else:
        width = int.from_bytes(data[18:20], "little")
        height = int.from_bytes(data[20:22], "little")
        bpp = int.from_bytes(data[24:26], "little")
        required = pixel_offset + (((width * bpp + 31) // 32) * 4 * height)
        compression = 0
    if declared < required or declared > len(data) or pixel_offset < 14 + dib_size:
        return StructureResult(False, "bmp", None, {"reason": "declared size/pixel extent invalid", "declared_size": declared, "required_minimum": required})
    return StructureResult(True, "bmp", declared, {
        "declared_size": declared, "width": width, "height": height,
        "bits_per_pixel": bpp, "compression": compression,
        "trailing_bytes": len(data) - declared,
    })


def _pdf(data: bytes) -> StructureResult:
    if not data.startswith(b"%PDF-"):
        return StructureResult(False, "pdf", None, {"reason": "PDF header missing"})
    eof = data.rfind(b"%%EOF")
    if eof < 0:
        return StructureResult(False, "pdf", None, {"reason": "%%EOF missing"})
    end = eof + 5
    while end < len(data) and data[end] in b"\r\n \t":
        end += 1
    pages = None
    parser_error = ""
    try:
        from pypdf import PdfReader
        reader = PdfReader(BytesIO(data[:end]), strict=True)
        pages = len(reader.pages)
    except Exception as exc:
        parser_error = str(exc)
        # pypdf can reject deliberately minimal but internally readable PDFs.
        # Require at least xref/startxref/trailer markers when strict parser fails.
        if b"startxref" not in data[:end] or b"xref" not in data[:end] or b"trailer" not in data[:end]:
            return StructureResult(False, "pdf", None, {"reason": f"PDF parser failed: {exc}"})
    return StructureResult(True, "pdf", end, {"pages": pages, "parser_note": parser_error, "trailing_bytes": len(data) - end})


def _zip(data: bytes, expected_type: str) -> StructureResult:
    eocd = data.rfind(b"PK\x05\x06")
    if eocd < 0 or eocd + 22 > len(data):
        return StructureResult(False, expected_type, None, {"reason": "ZIP EOCD missing/truncated"})
    comment_len = int.from_bytes(data[eocd + 20:eocd + 22], "little")
    end = eocd + 22 + comment_len
    if end > len(data):
        return StructureResult(False, expected_type, None, {"reason": "ZIP comment extends beyond candidate"})
    try:
        with zipfile.ZipFile(BytesIO(data[:end])) as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos]
            encrypted = [info.filename for info in infos if info.flag_bits & 0x1]
            bad_member = None
            for info in infos:
                if info.flag_bits & 0x1 or info.is_dir():
                    continue
                try:
                    with archive.open(info) as fh:
                        while fh.read(1024 * 1024):
                            pass
                except Exception:
                    bad_member = info.filename
                    break
    except Exception as exc:
        return StructureResult(False, expected_type, None, {"reason": f"ZIP parser failed: {exc}"})
    if bad_member:
        return StructureResult(False, expected_type, None, {"reason": "member CRC/decompression failed", "bad_member": bad_member})
    if expected_type == "docx" and "[Content_Types].xml" not in names:
        return StructureResult(False, "docx", None, {"reason": "OOXML content-types member missing"})
    return StructureResult(True, expected_type, end, {
        "members": len(infos), "encrypted_members": encrypted,
        "trailing_bytes": len(data) - end,
    })


def _gzip(data: bytes) -> StructureResult:
    if not data.startswith(b"\x1f\x8b\x08"):
        return StructureResult(False, "gzip", None, {"reason": "GZIP signature missing"})
    try:
        dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
        payload = dec.decompress(data)
        payload += dec.flush()
    except Exception as exc:
        return StructureResult(False, "gzip", None, {"reason": f"GZIP decompression failed: {exc}"})
    if not dec.eof:
        return StructureResult(False, "gzip", None, {"reason": "GZIP stream incomplete"})
    end = len(data) - len(dec.unused_data)
    return StructureResult(True, "gzip", end, {"uncompressed_bytes": len(payload), "trailing_bytes": len(dec.unused_data)})


def _pe(data: bytes) -> StructureResult:
    if len(data) < 0x40 or not data.startswith(b"MZ"):
        return StructureResult(False, "pe", None, {"reason": "DOS header missing"})
    pe_off = int.from_bytes(data[0x3C:0x40], "little")
    if pe_off < 0x40 or pe_off + 24 > len(data) or data[pe_off:pe_off + 4] != b"PE\x00\x00":
        return StructureResult(False, "pe", None, {"reason": "PE signature/e_lfanew invalid"})
    section_count = int.from_bytes(data[pe_off + 6:pe_off + 8], "little")
    opt_size = int.from_bytes(data[pe_off + 20:pe_off + 22], "little")
    table = pe_off + 24 + opt_size
    if section_count <= 0 or section_count > 96 or table + section_count * 40 > len(data):
        return StructureResult(False, "pe", None, {"reason": "section table invalid", "sections": section_count})
    end = table + section_count * 40
    for idx in range(section_count):
        off = table + idx * 40
        raw_size = int.from_bytes(data[off + 16:off + 20], "little")
        raw_ptr = int.from_bytes(data[off + 20:off + 24], "little")
        if raw_size:
            end = max(end, raw_ptr + raw_size)
    if end > len(data):
        return StructureResult(False, "pe", None, {"reason": "section data truncated", "required_end": end})
    return StructureResult(True, "pe", end, {"sections": section_count, "trailing_bytes": len(data) - end})


def validate_structure(path: Path, claimed_type: str = "") -> StructureResult:
    try:
        data = path.read_bytes()
    except OSError as exc:
        return StructureResult(False, claimed_type or "unknown", None, {"reason": f"unreadable: {exc}"})
    ext = (claimed_type or path.suffix.lstrip(".")).casefold()
    if data.startswith(b"\x89PNG\r\n\x1a\n") or ext == "png":
        return _png(data)
    if data.startswith((b"GIF87a", b"GIF89a")) or ext == "gif":
        return _gif(data)
    if data.startswith(b"\xff\xd8\xff") or ext in {"jpg", "jpeg"}:
        return _jpeg(data)
    if data.startswith(b"BM") or ext == "bmp":
        return _bmp(data)
    if data.startswith(b"%PDF-") or ext == "pdf":
        return _pdf(data)
    if data.startswith(b"PK\x03\x04") or ext in {"zip", "docx", "xlsx", "pptx"}:
        return _zip(data, ext if ext in {"docx", "xlsx", "pptx"} else "zip")
    if data.startswith(b"\x1f\x8b\x08") or ext in {"gz", "gzip"}:
        return _gzip(data)
    if data.startswith(b"MZ") or ext in {"exe", "dll"}:
        return _pe(data)
    return StructureResult(False, ext or "unknown", None, {"reason": "unsupported or mismatched file structure"})


def _merge_intervals(intervals: Iterable[tuple[int, int]]) -> list[tuple[int, int]]:
    merged: list[list[int]] = []
    for start, end in sorted((int(a), int(b)) for a, b in intervals if int(b) > int(a)):
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return [(a, b) for a, b in merged]


def interval_metrics(records: Iterable[dict[str, Any]]) -> dict[str, int]:
    recs = list(records)
    intervals = [(int(r["source_start"]), int(r["source_end"])) for r in recs if r.get("source_start") is not None and r.get("source_end") is not None]
    interval_bytes = sum(b - a for a, b in intervals)
    unique = sum(b - a for a, b in _merge_intervals(intervals))
    total_output = sum(int(r.get("candidate_size_bytes") or 0) for r in recs)
    by_hash: dict[str, list[int]] = {}
    for r in recs:
        digest = str(r.get("output_sha256") or "")
        if len(digest) == 64:
            by_hash.setdefault(digest, []).append(int(r.get("candidate_size_bytes") or 0))
    duplicate_output = sum(sum(sizes[1:]) for sizes in by_hash.values() if len(sizes) > 1)
    malformed = sum(int(r.get("candidate_size_bytes") or 0) for r in recs if r.get("final_state") == "REJECTED")
    accepted_unique_hashes: set[str] = set()
    validated_unique = 0
    for r in recs:
        digest = str(r.get("output_sha256") or "")
        if r.get("final_state") == "ACCEPTED" and digest and digest not in accepted_unique_hashes:
            accepted_unique_hashes.add(digest)
            validated_unique += int(r.get("structured_length") or r.get("candidate_size_bytes") or 0)
    return {
        "total_candidate_output_bytes": total_output,
        "interval_bytes": interval_bytes,
        "unique_source_bytes_covered": unique,
        "overlapping_source_bytes": max(0, interval_bytes - unique),
        "duplicate_output_bytes": duplicate_output,
        "malformed_output_bytes": malformed,
        "validated_unique_recovery_bytes": validated_unique,
    }


def assign_groups(records: list[dict[str, Any]]) -> None:
    hash_groups: dict[str, list[int]] = {}
    for idx, rec in enumerate(records):
        digest = str(rec.get("output_sha256") or "")
        if digest:
            hash_groups.setdefault(digest, []).append(idx)
    for group_no, (_, indices) in enumerate(sorted(hash_groups.items()), 1):
        group_id = f"hash-{group_no:04d}"
        for idx in indices:
            records[idx]["duplicate_group"] = group_id
            records[idx]["duplicate_occurrence_count"] = len(indices)

    # Connected components of intersecting source intervals.
    indexed = [(idx, int(rec["source_start"]), int(rec["source_end"])) for idx, rec in enumerate(records)
               if rec.get("source_start") is not None and rec.get("source_end") is not None]
    indexed.sort(key=lambda item: (item[1], item[2]))
    groups: list[list[int]] = []
    current: list[int] = []
    current_end = -1
    for idx, start, end in indexed:
        if not current or start >= current_end:
            if current:
                groups.append(current)
            current = [idx]
            current_end = end
        else:
            current.append(idx)
            current_end = max(current_end, end)
    if current:
        groups.append(current)
    for group_no, indices in enumerate(groups, 1):
        group_id = f"overlap-{group_no:04d}"
        for idx in indices:
            records[idx]["overlap_group"] = group_id
            records[idx]["overlap_occurrence_count"] = len(indices)


def load_native_relationships(paths: Iterable[Path]) -> tuple[dict[tuple[int, str], list[dict[str, Any]]], dict[str, list[dict[str, Any]]]]:
    by_offset_hash: dict[tuple[int, str], list[dict[str, Any]]] = {}
    by_hash: dict[str, list[dict[str, Any]]] = {}
    for path in paths:
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        for raw in data.get("candidates", data.get("files", [])) or []:
            rec = dict(raw or {})
            digest = str(rec.get("sha256") or rec.get("output_sha256") or "")
            offset = rec.get("offset_bytes", rec.get("source_start", rec.get("offset")))
            if digest:
                by_hash.setdefault(digest, []).append(rec)
            try:
                if digest and offset is not None:
                    by_offset_hash.setdefault((int(offset), digest), []).append(rec)
            except (TypeError, ValueError):
                pass
    return by_offset_hash, by_hash


def load_filesystem_ownership(manifest_path: Path | None) -> list[dict[str, Any]]:
    if manifest_path is None or not manifest_path.is_file():
        return []
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return []
    candidate = data.get("candidate") or {}
    fs = candidate.get("metadata") or candidate
    bps = int(fs.get("bytes_per_sector") or 512)
    spc = int(fs.get("sectors_per_cluster") or 1)
    cluster_size = int(fs.get("cluster_size") or (bps * spc))
    data_start = int(fs.get("data_start_sector") or 0) * bps
    owners: list[dict[str, Any]] = []
    for raw in data.get("files", []) or []:
        rec = dict(raw or {})
        if rec.get("is_dir") or rec.get("directory"):
            continue
        chain = [int(value) for value in (rec.get("cluster_chain") or []) if int(value) >= 2]
        remaining = int(rec.get("size") or rec.get("size_bytes") or 0)
        logical_path = str(rec.get("path") or rec.get("logical_path") or "")
        deleted = bool(rec.get("deleted"))
        for chain_index, cluster in enumerate(chain):
            start = data_start + (cluster - 2) * cluster_size
            length = min(cluster_size, max(0, remaining)) if remaining else cluster_size
            if length <= 0:
                break
            owners.append({
                "logical_path": logical_path,
                "deleted": deleted,
                "cluster": cluster,
                "chain_index": chain_index,
                "start": start,
                "end": start + length,
            })
            remaining -= length
    return owners


def ownership_for_interval(start: int, end: int, owners: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, bool], dict[str, Any]] = {}
    for owner in owners:
        overlap_start = max(start, int(owner["start"]))
        overlap_end = min(end, int(owner["end"]))
        if overlap_end <= overlap_start:
            continue
        key = (str(owner["logical_path"]), bool(owner["deleted"]))
        item = grouped.setdefault(key, {
            "logical_path": key[0], "deleted": key[1], "overlap_bytes": 0, "clusters": [],
        })
        item["overlap_bytes"] += overlap_end - overlap_start
        item["clusters"].append(int(owner["cluster"]))
    result = []
    for item in grouped.values():
        item["clusters"] = sorted(set(item["clusters"]))
        result.append(item)
    return sorted(result, key=lambda item: (-int(item["overlap_bytes"]), item["logical_path"]))


def reconcile_candidates(
    *,
    tool_name: str,
    source_path: Path,
    candidates: Iterable[dict[str, Any]],
    filesystem_manifest: Path | None = None,
    native_manifests: Iterable[Path] = (),
    peer_hashes: set[str] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Resolve all carver candidates using runtime bytes and metadata only."""
    source_path = source_path.resolve()
    source_size = source_path.stat().st_size
    owners = load_filesystem_ownership(filesystem_manifest)
    native_by_offset_hash, native_by_hash = load_native_relationships(native_manifests)
    peer_hashes = set(peer_hashes or set())
    resolved: list[dict[str, Any]] = []

    for raw in candidates:
        rec = dict(raw or {})
        output_path = Path(str(rec.get("output_path") or rec.get("carved_path") or ""))
        claimed_type = str(rec.get("file_type") or rec.get("extension") or output_path.suffix.lstrip("."))
        start_raw = rec.get("source_start", rec.get("offset", rec.get("offset_bytes")))
        audit_size_raw = rec.get("audit_reported_size_bytes", rec.get("size_bytes"))
        record: dict[str, Any] = {
            "tool": tool_name,
            "output_name": str(rec.get("file_name") or output_path.name),
            "output_path": str(output_path),
            "claimed_type": claimed_type.casefold(),
            "audit_reported_size_bytes": audit_size_raw,
            "chop": bool(rec.get("chop", False)),
            "unique_to_scalpel": bool(rec.get("unique_to_scalpel", False)),
            "matched_foremost_hashes": list(rec.get("matched_foremost_hashes") or []),
            "final_state": "UNRESOLVED",
            "resolution_reason": "",
        }
        if not output_path.is_file():
            record["resolution_reason"] = "retained carver output is missing"
            resolved.append(record)
            continue
        actual_size = output_path.stat().st_size
        digest = sha256_file(output_path)
        record.update({"candidate_size_bytes": actual_size, "output_sha256": digest})
        try:
            start = int(start_raw)
        except (TypeError, ValueError):
            record["resolution_reason"] = "exact source start is absent or invalid"
            resolved.append(record)
            continue
        end = start + actual_size
        record.update({"source_start": start, "source_length": actual_size, "source_end": end})
        if start < 0 or end > source_size:
            record["final_state"] = "REJECTED"
            record["resolution_reason"] = "candidate interval is outside the source byte stream"
            resolved.append(record)
            continue
        try:
            source_digest = sha256_interval(source_path, start, actual_size)
        except Exception as exc:
            record["resolution_reason"] = f"source interval could not be read: {exc}"
            resolved.append(record)
            continue
        record["source_interval_sha256"] = source_digest
        record["source_bytes_match_output"] = source_digest == digest
        if source_digest != digest:
            record["final_state"] = "REJECTED"
            record["resolution_reason"] = "retained output does not equal the declared source interval"
            resolved.append(record)
            continue
        structure = validate_structure(output_path, claimed_type)
        record["structural_validation"] = asdict(structure)
        record["structured_length"] = structure.structured_length
        record["header_validated"] = bool(structure.valid)
        if not structure.valid:
            record["final_state"] = "REJECTED"
            record["resolution_reason"] = str(structure.details.get("reason") or "format structure rejected")
        elif structure.structured_length is None or int(structure.structured_length) != actual_size:
            record["final_state"] = "REJECTED"
            record["resolution_reason"] = (
                "carver output contains bytes beyond the deterministically validated object boundary"
                if structure.structured_length is not None and int(structure.structured_length) < actual_size
                else "deterministic object boundary does not equal the retained candidate length"
            )
        else:
            record["final_state"] = "ACCEPTED"
            record["resolution_reason"] = "exact source interval and complete format structure validated"
        record["allocation_ownership"] = ownership_for_interval(start, end, owners)
        record["allocation_state"] = (
            "DELETED_FILE_CONTENT" if any(item.get("deleted") for item in record["allocation_ownership"])
            else "ALLOCATED_FILE_CONTENT" if record["allocation_ownership"]
            else "UNALLOCATED_OR_UNMAPPED"
        )
        archive_exts = {".zip", ".docx", ".xlsx", ".pptx", ".tar", ".tgz", ".gz", ".ufdr", ".ab"}
        record["archive_embedding_relationships"] = [
            item for item in record["allocation_ownership"]
            if Path(str(item.get("logical_path") or "")).suffix.casefold() in archive_exts
        ]
        record["deleted_recovery_relationships"] = [item for item in record["allocation_ownership"] if item.get("deleted")]
        exact_native = native_by_offset_hash.get((start, digest), [])
        hash_native = native_by_hash.get(digest, [])
        record["native_carver_relationship"] = {
            "exact_offset_and_hash_matches": len(exact_native),
            "hash_only_matches": max(0, len(hash_native) - len(exact_native)),
        }
        record["peer_carver_hash_match"] = digest in peer_hashes
        if tool_name.casefold() == "scalpel":
            record["matched_foremost_hashes"] = [digest] if digest in peer_hashes else []
            record["unique_to_scalpel"] = bool(peer_hashes) and digest not in peer_hashes
        resolved.append(record)

    assign_groups(resolved)
    metrics = interval_metrics(resolved)
    state_counts = {state: sum(1 for rec in resolved if rec.get("final_state") == state) for state in ("ACCEPTED", "REJECTED", "UNRESOLVED")}
    accepted_hashes = {str(rec.get("output_sha256")) for rec in resolved if rec.get("final_state") == "ACCEPTED"}
    summary: dict[str, Any] = {
        "candidate_count": len(resolved),
        "state_counts": state_counts,
        "all_candidates_resolved": state_counts["UNRESOLVED"] == 0,
        "accepted_unique_byte_streams": len(accepted_hashes),
        **metrics,
    }
    return resolved, summary
