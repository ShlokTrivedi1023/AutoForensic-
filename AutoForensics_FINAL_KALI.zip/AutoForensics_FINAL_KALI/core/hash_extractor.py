"""
hash_extractor.py — Hash Extraction Utility for AutoForensics.

Scans a filesystem (or a forensic image via icat) for password-protected
documents and extracts their hashes using john-compatible tools:
  - office2john.py  for OLE/OOXML Office documents
  - pdf2john.pl     for PDF files
  - zip2john        for ZIP archives

Used by john_recovery.py and hashcat_recovery.py.

Target platform : Kali Linux, Python 3.11+
External tools  : office2john.py, pdf2john.pl, zip2john (john package)
                  icat (sleuthkit; optional)
"""

from __future__ import annotations

import logging
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: File extensions that are candidates for password-protection scanning.
_TARGET_EXTENSIONS: frozenset[str] = frozenset({
    ".doc", ".xls", ".ppt",        # OLE legacy Office
    ".docx", ".xlsx", ".pptx",     # OOXML (ZIP-based)
    ".pdf",                        # PDF
    ".zip",                        # ZIP archive
})

#: OLE compound document magic bytes → file_type label.
_MAGIC_OLE   = b"\xd0\xcf\x11\xe0"
#: ZIP/OOXML magic bytes.
_MAGIC_ZIP   = b"\x50\x4b\x03\x04"
#: PDF magic bytes.
_MAGIC_PDF   = b"\x25\x50\x44\x46"

#: Maximum bytes to read for header/encryption checks (avoids loading huge files).
_HEADER_READ_LIMIT: int = 65536

#: Candidate paths for office2john.py on Kali Linux.
_OFFICE2JOHN_CANDIDATES: list[str] = [
    "/usr/share/john/office2john.py",
    "/usr/lib/john/office2john.py",
    "/opt/john/run/office2john.py",
]

#: Candidate paths for pdf2john.pl on Kali Linux.
_PDF2JOHN_CANDIDATES: list[str] = [
    "/usr/share/john/pdf2john.pl",
    "/usr/lib/john/pdf2john.pl",
    "/opt/john/run/pdf2john.pl",
]

#: OOXML extensions (ZIP-based Office Open XML).
_OOXML_EXTENSIONS: frozenset[str] = frozenset({".docx", ".xlsx", ".pptx"})

# ---------------------------------------------------------------------------
# Internal helpers — extractor location
# ---------------------------------------------------------------------------


def _find_office2john() -> Optional[str]:
    """Locate office2john.py on the system.

    Returns
    -------
    Absolute path string, or None if not found.
    """
    for candidate in _OFFICE2JOHN_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return shutil.which("office2john") or shutil.which("office2john.py")


def _find_pdf2john() -> Optional[str]:
    """Locate pdf2john.pl on the system.

    Returns
    -------
    Absolute path string, or None if not found.
    """
    for candidate in _PDF2JOHN_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return shutil.which("pdf2john") or shutil.which("pdf2john.pl")


def _find_zip2john() -> Optional[str]:
    """Locate zip2john on the system.

    Returns
    -------
    Absolute path string, or None if not found.
    """
    return shutil.which("zip2john")


# ---------------------------------------------------------------------------
# Internal helpers — password-protection detection
# ---------------------------------------------------------------------------


def _detect_file_type(header: bytes, ext: str) -> Optional[str]:
    """Determine file type from magic bytes and extension.

    Parameters
    ----------
    header : First bytes of the file (up to _HEADER_READ_LIMIT).
    ext    : Lowercase file extension including the leading dot.

    Returns
    -------
    "ole", "ooxml", "pdf", "zip", or None if unrecognised.
    """
    magic4 = header[:4] if len(header) >= 4 else b""
    if magic4 == _MAGIC_OLE:
        return "ole"
    if magic4 == _MAGIC_ZIP:
        if ext in _OOXML_EXTENSIONS:
            return "ooxml"
        return "zip"
    if magic4 == _MAGIC_PDF:
        return "pdf"
    return None


def _is_ole_encrypted(header: bytes) -> bool:
    """Return True if OLE compound document appears to be encrypted.

    Checks for the UTF-8 "EncryptionInfo" stream name or its UTF-16LE
    encoding inside the raw file bytes.

    Parameters
    ----------
    header : File bytes (up to _HEADER_READ_LIMIT).
    """
    if b"EncryptionInfo" in header:
        return True
    # UTF-16LE encoding of "Encrypt"
    if b"E\x00n\x00c\x00r\x00y\x00p\x00t" in header:
        return True
    return False


def _is_ooxml_encrypted(file_path: Path) -> bool:
    """Return True if an OOXML file (docx/xlsx/pptx) is encrypted.

    Encrypted OOXML files contain an "EncryptionInfo" entry in their ZIP.

    Parameters
    ----------
    file_path : Path to the OOXML file.
    """
    try:
        with zipfile.ZipFile(file_path) as zf:
            return any("EncryptionInfo" in name for name in zf.namelist())
    except Exception:
        # Cannot open as ZIP → treat as encrypted/corrupted
        return True


def _is_pdf_encrypted(header: bytes) -> bool:
    """Return True if a PDF file contains an /Encrypt dictionary.

    Parameters
    ----------
    header : First _HEADER_READ_LIMIT bytes of the file.
    """
    return b"/Encrypt" in header[:4096]


def _is_zip_encrypted(header: bytes) -> bool:
    """Return True if the first local file entry in a ZIP has the encrypt bit set.

    The ZIP local file header starts at offset 0:
      - Bytes 0-3   : signature (0x04034b50)
      - Bytes 4-5   : version needed
      - Bytes 6-7   : general purpose bit flag  (bit 0 = encryption)

    Parameters
    ----------
    header : First bytes of the file (must be at least 8 bytes).
    """
    if len(header) < 8:
        return False
    flags = struct.unpack_from("<H", header, 6)[0]
    return bool(flags & 0x0001)


def _check_password_protected(
    file_path: Path,
    header: bytes,
    file_type: str,
    logger: logging.Logger,
) -> bool:
    """Dispatch to the correct encryption check for *file_type*.

    Parameters
    ----------
    file_path : Path to the file on disk (used only for OOXML zip-open).
    header    : First _HEADER_READ_LIMIT bytes of the file.
    file_type : One of "ole", "ooxml", "pdf", "zip".
    logger    : Logger for debug messages.

    Returns
    -------
    True if the file appears to be password-protected.
    """
    try:
        if file_type == "ole":
            return _is_ole_encrypted(header)
        if file_type == "ooxml":
            return _is_ooxml_encrypted(file_path)
        if file_type == "pdf":
            return _is_pdf_encrypted(header)
        if file_type == "zip":
            return _is_zip_encrypted(header)
    except Exception as exc:
        logger.debug("Encryption check failed for %s: %s", file_path, exc)
    return False


# ---------------------------------------------------------------------------
# Internal helpers — hash extraction via subprocess
# ---------------------------------------------------------------------------


def _build_extractor_cmd(
    file_type: str,
    file_path: Path,
    logger: logging.Logger,
) -> Optional[list[str]]:
    """Build the subprocess command list for the appropriate extractor.

    Parameters
    ----------
    file_type : "ole", "ooxml", "pdf", or "zip".
    file_path : Absolute path to the target file.
    logger    : Logger for warning messages when a tool is missing.

    Returns
    -------
    Command list (suitable for subprocess.run), or None if tool not found.
    """
    if file_type in ("ole", "ooxml"):
        tool = _find_office2john()
        if tool is None:
            logger.warning(
                "[hash_extractor] office2john not found — skipping %s", file_path.name
            )
            return None
        return [sys.executable, tool, str(file_path)]

    if file_type == "pdf":
        tool = _find_pdf2john()
        if tool is None:
            logger.warning(
                "[hash_extractor] pdf2john not found — skipping %s", file_path.name
            )
            return None
        return ["perl", tool, str(file_path)]

    if file_type == "zip":
        tool = _find_zip2john()
        if tool is None:
            logger.warning(
                "[hash_extractor] zip2john not found — skipping %s", file_path.name
            )
            return None
        return [tool, str(file_path)]

    return None


def _run_extractor(
    cmd: list[str],
    file_path: Path,
    logger: logging.Logger,
) -> Optional[str]:
    """Run an extractor command and parse the hash from its stdout.

    Extractor tools emit lines of the form:
        <filename>:<hash_string>[:<extra fields>]

    We take everything after the first colon as the hash.

    Parameters
    ----------
    cmd       : Command list (no shell=True).
    file_path : Original file path (for logging only).
    logger    : Logger.

    Returns
    -------
    Hash string (everything after the first colon), or None on failure.
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            timeout=60,
            shell=False,
        )
        stdout = result.stdout.decode("utf-8", errors="replace").strip()
        if not stdout:
            logger.debug(
                "[hash_extractor] extractor produced no output for %s (rc=%d)",
                file_path.name, result.returncode,
            )
            return None
        # Take the first non-empty line
        for line in stdout.splitlines():
            line = line.strip()
            if ":" in line:
                hash_str = line.split(":", 1)[1].strip()
                if hash_str:
                    return hash_str
        logger.debug(
            "[hash_extractor] could not parse hash from extractor output for %s",
            file_path.name,
        )
    except subprocess.TimeoutExpired:
        logger.debug("[hash_extractor] extractor timed out for %s", file_path.name)
    except FileNotFoundError as exc:
        logger.debug("[hash_extractor] extractor binary not found: %s", exc)
    except Exception as exc:
        logger.debug("[hash_extractor] extractor error for %s: %s", file_path.name, exc)
    return None


def _safe_name(name: str) -> str:
    """Return a filesystem-safe version of *name*.

    Replaces any character that is not alphanumeric, dot, hyphen, or
    underscore with an underscore.

    Parameters
    ----------
    name : Original file name.
    """
    return re.sub(r"[^\w.\-]", "_", name)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_hashes(
    scan_root: Path,
    hashes_dir: Path,
    logger: logging.Logger,
) -> list[dict]:
    """Walk *scan_root* for password-protected documents and extract their hashes.

    Supported formats: .doc .xls .ppt .docx .xlsx .pptx .pdf .zip

    For each password-protected file the appropriate john-compatible extractor
    (office2john / pdf2john / zip2john) is invoked and the resulting hash is
    written to *hashes_dir*.

    Parameters
    ----------
    scan_root  : Root directory to walk recursively.
    hashes_dir : Directory where individual ``<safe_name>.hash`` files are written.
    logger     : Standard Python logger.

    Returns
    -------
    List of dicts, one per successfully extracted hash, each containing:
      - ``file_path``  (str)  — absolute path to the source file.
      - ``file_type``  (str)  — "ole", "ooxml", "pdf", or "zip".
      - ``hash_file``  (str)  — path of the written .hash file.
      - ``hash_str``   (str)  — the extracted hash string.
    """
    hashes_dir = Path(hashes_dir)
    hashes_dir.mkdir(parents=True, exist_ok=True)
    scan_root = Path(scan_root)

    results: list[dict] = []

    for file_path in scan_root.rglob("*"):
        if not file_path.is_file():
            continue
        ext = file_path.suffix.lower()
        if ext not in _TARGET_EXTENSIONS:
            continue

        # Read only what we need for the header checks
        try:
            header = file_path.read_bytes()[:_HEADER_READ_LIMIT]
        except OSError as exc:
            logger.debug("[hash_extractor] cannot read %s: %s", file_path, exc)
            continue

        file_type = _detect_file_type(header, ext)
        if file_type is None:
            logger.debug(
                "[hash_extractor] unrecognised magic for %s, skipping", file_path.name
            )
            continue

        if not _check_password_protected(file_path, header, file_type, logger):
            continue

        logger.info(
            "[hash_extractor] password-protected %s file: %s", file_type.upper(), file_path
        )

        cmd = _build_extractor_cmd(file_type, file_path, logger)
        if cmd is None:
            continue

        hash_str = _run_extractor(cmd, file_path, logger)
        if not hash_str:
            continue

        safe = _safe_name(file_path.name)
        hash_file = hashes_dir / f"{len(results)}_{safe}.hash"
        try:
            hash_file.write_text(hash_str + "\n", encoding="utf-8")
        except OSError as exc:
            logger.debug("[hash_extractor] cannot write hash file %s: %s", hash_file, exc)
            continue

        results.append({
            "file_path": str(file_path),
            "file_type": file_type,
            "hash_file": str(hash_file),
            "hash_str":  hash_str,
        })

    logger.info(
        "[hash_extractor] extract_hashes: found %d protected file(s) with extractable hashes",
        len(results),
    )
    return results


def extract_hashes_from_image(
    analysis_path: Path,
    partition_offset: int,
    fls_entries: list[dict],
    hashes_dir: Path,
    logger: logging.Logger,
) -> list[dict]:
    """Extract hashes from password-protected files inside a forensic image.

    Uses optional ``icat`` without privilege escalation to pull each candidate file out of
    the image, checks for password protection, runs the appropriate extractor,
    and writes the hash to *hashes_dir*.

    Parameters
    ----------
    analysis_path     : Path to the forensic disk image.
    partition_offset  : Partition offset in sectors (passed to icat -o).  Use 0
                        if the image has no partition table.
    fls_entries       : List of dicts from an ``fls`` scan, each with keys:
                        - "path"  (str) — file path within the image.
                        - "inode" (str) — inode number.
    hashes_dir        : Directory where ``<inode>_<safe_name>.hash`` files are written.
    logger            : Standard Python logger.

    Returns
    -------
    List of dicts, one per successfully extracted hash, each containing:
      - ``file_path``  (str) — path within the image.
      - ``inode``      (str) — inode number.
      - ``file_type``  (str) — "ole", "ooxml", "pdf", or "zip".
      - ``hash_file``  (str) — path of the written .hash file.
      - ``hash_str``   (str) — the extracted hash string.
    """
    hashes_dir = Path(hashes_dir)
    hashes_dir.mkdir(parents=True, exist_ok=True)
    analysis_path = Path(analysis_path)

    # External tools run as the current user; never elevate privileges
    sudo_prefix: list[str] = []

    # icat -o <offset> only when offset > 0
    offset_args: list[str] = ["-o", str(partition_offset)] if partition_offset > 0 else []

    # Filter fls_entries to target extensions only
    candidates = [
        e for e in fls_entries
        if Path(e.get("path", "")).suffix.lower() in _TARGET_EXTENSIONS
    ]

    results: list[dict] = []

    with tempfile.TemporaryDirectory(prefix="hashext_") as tmpdir:
        tmp_path = Path(tmpdir)

        for entry in candidates:  # exhaustive candidate processing
            inode: str = str(entry.get("inode", ""))
            file_path_str: str = str(entry.get("path", ""))
            ext = Path(file_path_str).suffix.lower()

            if not inode:
                logger.debug("[hash_extractor] fls entry missing inode: %s", entry)
                continue

            # Extract bytes from image via icat
            icat_cmd = (
                sudo_prefix
                + ["icat"]
                + offset_args
                + [str(analysis_path), inode]
            )
            try:
                icat_result = subprocess.run(
                    icat_cmd,
                    capture_output=True,
                    timeout=120,
                    shell=False,
                )
            except subprocess.TimeoutExpired:
                logger.debug(
                    "[hash_extractor] icat timed out for inode %s (%s)", inode, file_path_str
                )
                continue
            except FileNotFoundError:
                logger.warning("[HASHEXT] icat binary not found — aborting image scan")
                break
            except Exception as exc:
                logger.debug(
                    "[hash_extractor] icat failed for inode %s: %s", inode, exc
                )
                continue

            if icat_result.returncode != 0 or not icat_result.stdout:
                logger.debug(
                    "[hash_extractor] icat produced no data for inode %s", inode
                )
                continue

            raw_bytes: bytes = icat_result.stdout

            # Write to a temp file so extractors can operate on a real path
            safe = _safe_name(Path(file_path_str).name)
            tmp_file = tmp_path / f"{inode}_{safe}"
            try:
                tmp_file.write_bytes(raw_bytes)
            except OSError as exc:
                logger.debug(
                    "[hash_extractor] cannot write temp file for inode %s: %s", inode, exc
                )
                continue

            # Use the header for magic/encryption checks
            header = raw_bytes[:_HEADER_READ_LIMIT]

            file_type = _detect_file_type(header, ext)
            if file_type is None:
                logger.debug(
                    "[hash_extractor] unrecognised magic for inode %s (%s)", inode, file_path_str
                )
                continue

            if not _check_password_protected(tmp_file, header, file_type, logger):
                continue

            logger.info(
                "[hash_extractor] password-protected %s in image: inode=%s path=%s",
                file_type.upper(), inode, file_path_str,
            )

            cmd = _build_extractor_cmd(file_type, tmp_file, logger)
            if cmd is None:
                continue

            hash_str = _run_extractor(cmd, tmp_file, logger)
            if not hash_str:
                continue

            hash_file = hashes_dir / f"{inode}_{safe}.hash"
            try:
                hash_file.write_text(hash_str + "\n", encoding="utf-8")
            except OSError as exc:
                logger.debug(
                    "[hash_extractor] cannot write hash file %s: %s", hash_file, exc
                )
                continue

            results.append({
                "file_path": file_path_str,
                "inode":     inode,
                "file_type": file_type,
                "hash_file": str(hash_file),
                "hash_str":  hash_str,
            })

    logger.info(
        "[hash_extractor] extract_hashes_from_image: found %d protected file(s) with "
        "extractable hashes (from %d candidates)",
        len(results), len(candidates),
    )
    return results
