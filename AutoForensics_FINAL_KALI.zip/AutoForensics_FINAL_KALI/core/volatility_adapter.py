"""Case-neutral Volatility 3 launcher discovery and execution.

The adapter accepts no expected evidence values.  It discovers a compatible
launcher dynamically, executes one named plugin with an argument list (never a
shell), records the exact command, return code and version, and leaves all
forensic interpretation to the calling module.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Optional
import os
import shutil
import subprocess
import sys


class VolatilityUnavailable(FileNotFoundError):
    pass


@dataclass(frozen=True)
class VolatilityLauncher:
    command_prefix: tuple[str, ...]
    resolved_path: str
    source: str
    version: str


@dataclass
class VolatilityExecution:
    plugin: str
    evidence_path: str
    command: list[str]
    returncode: int
    stdout: str
    stderr: str
    launcher: dict[str, Any]


def _version(prefix: list[str]) -> str:
    for args in (prefix + ["--version"], prefix + ["-h"]):
        try:
            cp = subprocess.run(args, capture_output=True, text=True, timeout=20, check=False)
        except (OSError, subprocess.SubprocessError):
            continue
        text = (cp.stdout or cp.stderr or "").strip()
        if text:
            return text.splitlines()[0][:300]
    return "version unavailable"


def _candidate(value: str, source: str) -> Optional[VolatilityLauncher]:
    value = (value or "").strip()
    if not value:
        return None
    path = Path(value).expanduser()
    resolved = shutil.which(value) or (str(path.resolve()) if path.exists() else "")
    if not resolved:
        return None
    rp = Path(resolved)
    prefix = [sys.executable, resolved] if rp.suffix.lower() == ".py" else [resolved]
    return VolatilityLauncher(tuple(prefix), resolved, source, _version(prefix))


def resolve_volatility_launcher(config: Optional[dict[str, Any]] = None) -> VolatilityLauncher:
    cfg = config or {}
    configured = str(cfg.get("vol_path") or cfg.get("volatility_path") or "")
    env = os.environ.get("VOLATILITY3_PATH") or os.environ.get("AUTOFORENSICS_VOLATILITY_BIN") or ""
    candidates = [
        (configured, "module configuration"),
        (env, "environment"),
        ("vol", "PATH"),
        ("vol.py", "PATH"),
        ("/opt/volatility3/vol.py", "standard installation"),
        ("/usr/local/bin/vol", "standard installation"),
    ]
    for value, source in candidates:
        launcher = _candidate(value, source)
        if launcher:
            return launcher
    raise VolatilityUnavailable(
        "No compatible Volatility 3 launcher found. Install the Kali volatility3 "
        "package or set VOLATILITY3_PATH to vol/vol.py."
    )


def run_volatility_plugin(
    *, evidence_path: Path, plugin: str, config: Optional[dict[str, Any]] = None,
    timeout: int = 3600,
) -> VolatilityExecution:
    launcher = resolve_volatility_launcher(config)
    command = [*launcher.command_prefix, "-f", str(Path(evidence_path).resolve()), plugin]
    cp = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
    return VolatilityExecution(
        plugin=plugin,
        evidence_path=str(Path(evidence_path).resolve()),
        command=command,
        returncode=cp.returncode,
        stdout=cp.stdout or "",
        stderr=cp.stderr or "",
        launcher=asdict(launcher),
    )
