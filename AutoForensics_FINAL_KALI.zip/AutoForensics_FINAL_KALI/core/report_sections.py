"""
core/report_sections.py

Dataclasses and section-builder functions for the AutoForensics digital
forensics report generator.

Each build_* function accepts structured investigation data and returns a
SectionContent object whose ContentBlock list is ready for direct consumption
by the PDF renderer.  No file I/O, no subprocesses, and no network calls are
performed in this module.

Design principles
-----------------
* Pure functions — side-effect free; deterministic given the same input.
* Renderer-agnostic — the content-block vocabulary is expressed in
  ContentBlock.block_type so the renderer (not this module) decides how
  each block maps to PDF primitives.
* Typed throughout — all public symbols carry full PEP 484 annotations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Any, Optional


# ===========================================================================
# Enumerations
# ===========================================================================


class FindingSeverity(Enum):
    """
    Risk/impact rating for an investigative finding.

    Severity levels align with common forensic reporting practice:

    CRITICAL  Evidence of active compromise, data exfiltration in progress,
              or a finding that directly answers the investigative hypothesis
              with high confidence.
    HIGH      Significant indicators that strongly support the hypothesis but
              fall short of the certainty required for CRITICAL classification.
    MEDIUM    Supporting evidence or policy violations that are relevant to the
              case but do not independently establish the hypothesis.
    LOW       Informational observations with limited direct investigative
              impact; recorded for completeness.
    """

    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


# ===========================================================================
# Core report dataclasses
# ===========================================================================


@dataclass
class ReportMetadata:
    """
    Top-level metadata that identifies the report and its custodians.

    This information appears on the cover page, in page headers/footers,
    and in the Investigator Details section.

    Attributes
    ----------
    case_number:
        Official case reference assigned by the client or law enforcement.
    report_title:
        Descriptive title for the report document.
    examiner_name:
        Full name of the lead examiner producing the report.
    examiner_organisation:
        Organisation to which the lead examiner belongs.
    report_date:
        Date the report was finalised (not when the examination began).
    report_version:
        Semantic version string; increment for each issued revision.
    classification:
        Document handling caveat applied to every page, e.g.
        'CONFIDENTIAL', 'RESTRICTED', 'UNCLASSIFIED'.
    client_name:
        Full name of the commissioning client.
    client_organisation:
        Client's employing organisation or law firm.
    report_reference:
        Internal reference number used by the examiner's organisation.
    logo_path:
        Optional absolute path to a logo image file rendered on the cover
        page.  If None the renderer omits the image element.
    """

    case_number: str
    report_title: str
    examiner_name: str
    examiner_organisation: str
    report_date: date
    report_version: str = "1.0"
    classification: str = "CONFIDENTIAL"
    client_name: str = ""
    client_organisation: str = ""
    report_reference: str = ""
    logo_path: Optional[str] = None


@dataclass
class CaseInfo:
    """
    Detailed administrative information about the case.

    All dates are stdlib ``date`` objects so the renderer can apply
    whatever locale formatting it requires.

    Attributes
    ----------
    case_number:
        Unique identifier for the case within the examiner's case
        management system.
    case_title:
        Human-readable short title for the matter.
    client_name:
        Full name of the instructing client contact.
    client_organisation:
        Client's organisation or law firm.
    client_contact:
        Phone number or other direct contact detail for the client.
    client_email:
        Primary email address for the client contact.
    date_received:
        Date on which the instruction to examine was received.
    date_commenced:
        Date on which active examination work began.
    date_completed:
        Date on which the examination was concluded; None if ongoing.
    incident_date:
        Date of the alleged incident under investigation; None if unknown.
    jurisdiction:
        Applicable legal jurisdiction (e.g. 'England and Wales').
    case_type:
        Classification of the matter type (e.g. 'Criminal', 'Civil
        Litigation', 'Internal HR').
    priority:
        Agreed priority level (e.g. 'P1 – Critical', 'P3 – Standard').
    related_cases:
        List of case numbers for related matters.
    notes:
        Free-text notes relevant to the case administration.
    """

    case_number: str
    case_title: str
    client_name: str
    client_organisation: str
    client_contact: str
    client_email: str
    date_received: date
    date_commenced: date
    date_completed: Optional[date] = None
    incident_date: Optional[date] = None
    jurisdiction: str = ""
    case_type: str = ""
    priority: str = ""
    related_cases: list[str] = field(default_factory=list)
    notes: str = ""


@dataclass
class EvidenceAcquisition:
    """
    Record describing the acquisition of a single piece of digital evidence.

    Hash values are stored as lowercase hex strings without any prefix.
    Size fields carry raw byte counts; helpers convert them for display.

    Attributes
    ----------
    exhibit_number:
        Unique exhibit identifier (e.g. 'EX-001').
    description:
        Textual description of the physical item (e.g. 'Samsung 1TB SSD,
        serial number ABC123').
    acquisition_date:
        Date on which the forensic image was created.
    acquisition_method:
        Description of the acquisition technique (e.g. 'Physical DD image
        via write-blocker', 'Logical acquisition via ADB', 'Live RAM
        capture').
    tool_used:
        Name of the forensic acquisition tool.
    tool_version:
        Version string of the acquisition tool.
    md5_hash:
        MD5 hash of the acquired image as a lowercase hex string.
    sha256_hash:
        SHA-256 hash of the acquired image as a lowercase hex string.
    source_size_bytes:
        Size of the source device or file in bytes.
    image_size_bytes:
        Size of the resulting forensic image in bytes.
    acquired_by:
        Full name of the examiner who performed the acquisition.
    verified:
        True once hash re-verification has been performed and passed.
    notes:
        Any additional notes about the acquisition (irregularities,
        bad sectors, etc.).
    """

    exhibit_number: Optional[str]
    description: str
    acquisition_date: date
    acquisition_method: str
    tool_used: str
    tool_version: str
    md5_hash: str
    sha256_hash: str
    source_size_bytes: int
    image_size_bytes: int
    acquired_by: str
    verified: bool = False
    notes: str = ""
    # Embedded acquisition-hash references read from the image (e.g. E01
    # metadata).  A MATCH/MISMATCH may only be asserted against these; they are
    # shown alongside the computed value so "VERIFIED" never appears bare.
    md5_reference: str = ""
    sha256_reference: str = ""
    # EWF1 commonly embeds MD5 and SHA-1, not SHA-256.  Keep SHA-1 as a
    # first-class comparison so a report cannot omit the actual embedded
    # reference while presenting a computed SHA-256 as verified.
    sha1_hash: str = ""
    sha1_reference: str = ""
    # Explicit physical-container fields.  The legacy md5_hash/sha1_hash/
    # sha256_hash fields above represent the reconstructed logical-media
    # stream for backward compatibility.  Embedded EWF references are compared
    # only with those logical-media fields, never with these container hashes.
    source_container_path: str = ""
    source_container_md5: str = ""
    source_container_sha1: str = ""
    source_container_sha256: str = ""
    source_container_size_bytes: int = 0
    source_container_hash_basis: str = "source-file-bytes"
    logical_media_size_bytes: int = 0
    # Attached-device acquisition integrity stages. Empty for pre-existing images.
    write_protection_method: str = ""
    source_pre_acquisition_sha256: str = ""
    source_post_acquisition_sha256: str = ""
    source_pre_hash_basis: str = ""
    source_post_hash_basis: str = ""
    acquired_content_sha256: str = ""
    source_pre_vs_acquired: str = ""
    source_pre_vs_source_post: str = ""
    container_set_sha256_pre_analysis: str = ""
    container_set_sha256_post_analysis: str = ""
    logical_media_sha256_pre_analysis: str = ""
    logical_media_sha256_post_analysis: str = ""
    pre_vs_post_container_set: str = ""
    pre_vs_post_logical_media: str = ""

    @property
    def exhibit_ref(self) -> str:
        """Return the exhibit id, or raise if this record was never given one.

        ``exhibit_number`` must be supplied from real case data (config /
        evidence manifest) — there is no placeholder default.  Rendering an
        unidentified exhibit is refused rather than silently mislabelling it as
        the first exhibit.
        """
        if not self.exhibit_number:
            raise ValueError(
                "EvidenceAcquisition has no exhibit_number — the record was "
                "never given a real exhibit id from case data. Refusing to "
                "render it with a placeholder that would mislabel it as EX-001."
            )
        return self.exhibit_number


@dataclass
class FindingItem:
    """
    A discrete, evidence-backed investigative finding.

    Each finding is assigned a unique ID within the report so that
    cross-references from the executive summary remain stable if the
    list is later reordered.

    Attributes
    ----------
    finding_id:
        Unique identifier for the finding within this report
        (e.g. 'F-001').
    title:
        Short descriptive title (suitable for table display).
    description:
        Full narrative description of what was found, how it was
        identified, and why it is significant.
    severity:
        FindingSeverity rating.
    category:
        Classification of the finding type (e.g. 'Malware', 'Data
        Exfiltration', 'Policy Violation', 'Anti-Forensics').
    artefact_location:
        Where the artefact resides — a file path, registry key, URL,
        memory address, or other location indicator.
    timestamp:
        Datetime associated with the artefact (creation, modification,
        etc.); None if not determinable.
    evidence_reference:
        Exhibit number from which this finding was extracted.
    raw_data:
        Representative raw artefact data or an excerpt; kept short
        enough for inline display in the report.
    recommendation:
        Remediation or follow-up action recommended as a result of this
        finding.
    """

    finding_id: str
    title: str
    description: str
    severity: FindingSeverity
    category: str
    artefact_location: str
    timestamp: Optional[datetime] = None
    evidence_reference: Any = ""
    raw_data: str = ""
    recommendation: str = ""
    finding_type: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TimelineEntry:
    """
    A single chronological event reconstructed during the investigation.

    Timeline entries are collected from all analysis modules and merged
    into a unified timeline in the final report.

    Attributes
    ----------
    timestamp:
        UTC datetime of the event.
    event_description:
        Plain-language description of what happened.
    source:
        The module or artefact type that produced this entry
        (e.g. 'Browser History', 'Windows Event Log', 'Registry').
    exhibit_number:
        Exhibit from which the event was extracted.
    significance:
        Explanation of why this event is relevant to the case.
    analyst_note:
        Additional interpretive note added by the examiner.
    """

    timestamp: datetime
    event_description: str
    source: str
    exhibit_number: Optional[str] = None
    significance: str = ""
    analyst_note: str = ""

    @property
    def exhibit_ref(self) -> str:
        """Return the stamped exhibit id, or raise if never stamped.

        Timeline entries are created without an exhibit id and stamped by the
        evidence-attribution pass (:func:`report_loader._stamp_exhibit`).  An
        entry that reaches this accessor unstamped is a bug — refuse it loudly
        rather than defaulting to the first exhibit.
        """
        if not self.exhibit_number:
            raise ValueError(
                "TimelineEntry has no exhibit_number — the entry was never "
                "stamped by the evidence-attribution pass. Refusing to render "
                "it with a placeholder that would mislabel it as EX-001."
            )
        return self.exhibit_number


@dataclass
class ModuleResult:
    """
    Container for the complete normalised output of a single analysis module.

    A module is a discrete analysis component (e.g. browser parser, registry
    analyser, memory analyser).  All modules produce output in this standard
    form so that section builders can consume any module result uniformly.

    The ``raw_data`` dict carries module-specific artefact tables, parsed
    records, and statistics that do not fit the normalised ``findings`` list.
    Each section builder documents its expected ``raw_data`` keys.

    Attributes
    ----------
    module_name:
        Human-readable name of the analysis module.
    module_version:
        Version string of the module.
    run_timestamp:
        UTC datetime at which the module completed its run.
    status:
        Run outcome: 'success', 'partial' (completed with errors), or
        'failed'.
    findings:
        List of FindingItem objects produced by this module.
    timeline_entries:
        Chronological events identified by this module.
    raw_data:
        Module-specific structured data used by the corresponding section
        builder (see each builder's docstring for key definitions).
    error_message:
        Error or warning text when status is 'partial' or 'failed'.
    artefacts_examined:
        Total number of artefacts the module processed.
    artefacts_relevant:
        Number of artefacts the module classified as relevant to the case.
    """

    module_name: str
    module_version: str
    run_timestamp: datetime
    status: str  # 'success' | 'partial' | 'failed' | 'skipped' | 'degraded' | 'indeterminate'
    findings: list[FindingItem] = field(default_factory=list)
    timeline_entries: list[TimelineEntry] = field(default_factory=list)
    raw_data: dict[str, Any] = field(default_factory=dict)
    error_message: str = ""
    artefacts_examined: int = 0
    artefacts_relevant: int = 0
    terminal_output: str = ""
    class_results: list = field(default_factory=list)
    # Honest execution state carried from the orchestrator.  This is separate
    # from the coarse status because COMPLETED can mean either "ran and found
    # nothing" or "ran and found X".
    execution_outcome: str = ""  # ran_found_x | ran_found_nothing | did_not_run | ran_with_caveat
    summary: str = ""


@dataclass
class KeyFinding:
    """
    A high-level finding distilled for the executive summary.

    Key findings are a curated subset of FindingItem objects translated
    into language appropriate for a non-technical reader (senior management,
    legal counsel, judiciary).

    Attributes
    ----------
    title:
        Short title for display in the executive summary table.
    description:
        Plain-language explanation of the finding and its significance.
    severity:
        FindingSeverity rating mirroring the underlying FindingItem.
    supporting_evidence:
        List of exhibit numbers or finding IDs that support this key
        finding.
    recommendation:
        High-level remediation or action recommended to the client.
    """

    title: str
    description: str
    severity: FindingSeverity
    supporting_evidence: list[str] = field(default_factory=list)
    recommendation: str = ""


# ===========================================================================
# Supplementary dataclasses used by specific section builders
# ===========================================================================


@dataclass
class InvestigatorDetails:
    """
    Professional details for an individual examiner or analyst.

    Used by ``build_investigator_details`` to build the Section 9 table.

    Attributes
    ----------
    name:
        Full legal name of the individual.
    title:
        Job title (e.g. 'Senior Digital Forensic Examiner').
    organisation:
        Employing organisation.
    certifications:
        List of professional certifications held (e.g. 'EnCE', 'GCFE').
    experience_years:
        Years of relevant forensic experience.
    contact_email:
        Professional email address.
    role_in_case:
        Role played in this specific examination (e.g. 'Lead Examiner',
        'Peer Reviewer', 'Exhibit Custodian').
    """

    name: str
    title: str
    organisation: str
    certifications: list[str] = field(default_factory=list)
    experience_years: int = 0
    contact_email: str = ""
    role_in_case: str = ""
    badge_number: str = ""
    supervisor_name: str = ""
    supervisor_email: str = ""


@dataclass
class ToolEntry:
    """
    A single entry in the tools and software inventory (Section 12).

    Each entry documents one piece of software used during the examination
    to satisfy chain-of-custody and reproducibility requirements.

    Attributes
    ----------
    name:
        Tool name (e.g. 'The Sleuth Kit', 'FTK Imager', 'Volatility 3').
    version:
        Exact version string.
    vendor:
        Vendor or project name.
    purpose:
        Brief description of how the tool was used in this examination.
    licence:
        Licence type (e.g. 'Commercial', 'Open Source – Apache 2.0').
    validation_reference:
        Reference to tool validation evidence (e.g. NIST CFTT test
        report number, internal validation ID).
    """

    name: str
    version: str
    vendor: str
    purpose: str
    licence: str = ""
    validation_reference: str = ""


# ===========================================================================
# Content block primitives consumed by the PDF renderer
# ===========================================================================


@dataclass
class ContentBlock:
    """
    A single renderable unit consumed by the PDF rendering layer.

    Separating content structure from visual presentation means the
    renderer can apply styles (fonts, colours, table widths) independently
    of the data-preparation logic in this module.

    Recognised block_type values
    ----------------------------
    heading1          Top-level section heading (H1 style).
    heading2          Subsection heading (H2 style).
    heading3          Sub-subsection heading (H3 style).
    paragraph         Body text paragraph; data dict key: 'text' (str).
    table             Tabular data; data dict keys: 'headers' (list[str]),
                      'rows' (list[list[str]]).
    bullet_list       Unordered list; data dict key: 'items' (list[str]).
    numbered_list     Ordered list; data dict key: 'items' (list[str]).
    key_value         Two-column label/value pairs; data dict key:
                      'pairs' (list[tuple[str, str]]).
    spacer            Vertical whitespace; data dict key:
                      'height_mm' (int).
    page_break        Explicit page break; no data.
    image             Inline image; data dict keys: 'path' (str),
                      'width_mm' (int), 'align' (str).
    signature_block   Examiner signature area; data dict keys: 'name',
                      'title', 'date' (all str).
    hash_block        Monospaced hash/digest display; data dict keys:
                      'label' (str), 'value' (str).
    status_badge      Coloured severity badge; data dict keys: 'label'
                      (str), 'severity' (FindingSeverity.value string).
    """

    block_type: str
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class SectionContent:
    """
    The complete rendered content for one numbered report section.

    The PDF renderer iterates over ``blocks`` in order and draws each
    ContentBlock according to its block_type.

    Attributes
    ----------
    section_number:
        Integer section number in the range 1–20.
    section_title:
        Human-readable section heading used in the table of contents
        and as the first heading in the rendered output.
    blocks:
        Ordered list of ContentBlock instances.
    """

    section_number: int
    section_title: str
    blocks: list[ContentBlock] = field(default_factory=list)


# ===========================================================================
# Private helper functions — not part of the public API
# ===========================================================================


def _h1(text: str) -> ContentBlock:
    """Return a heading1 block for the given text."""
    return ContentBlock(block_type="heading1", data={"text": text})


def _h2(text: str) -> ContentBlock:
    """Return a heading2 block for the given text."""
    return ContentBlock(block_type="heading2", data={"text": text})


def _h3(text: str) -> ContentBlock:
    """Return a heading3 block for the given text."""
    return ContentBlock(block_type="heading3", data={"text": text})


def _para(text: str) -> ContentBlock:
    """Return a paragraph block for the given text."""
    return ContentBlock(block_type="paragraph", data={"text": text})


def _kv(pairs: list[tuple[str, str]]) -> ContentBlock:
    """Return a key-value pair block."""
    return ContentBlock(block_type="key_value", data={"pairs": pairs})


def _table(headers: list[str], rows: list[list[str]]) -> ContentBlock:
    """Return a table block with the given headers and row data."""
    return ContentBlock(block_type="table", data={"headers": headers, "rows": rows})


def _bullets(items: list[str]) -> ContentBlock:
    """Return an unordered bullet list block."""
    return ContentBlock(block_type="bullet_list", data={"items": items})


def _numbered(items: list[str]) -> ContentBlock:
    """Return a numbered list block."""
    return ContentBlock(block_type="numbered_list", data={"items": items})


def _spacer(height_mm: int = 6) -> ContentBlock:
    """Return a vertical spacer block of the requested height in millimetres."""
    return ContentBlock(block_type="spacer", data={"height_mm": height_mm})


def _page_break() -> ContentBlock:
    """Return an explicit page-break block."""
    return ContentBlock(block_type="page_break", data={})


def _hash_block(label: str, value: str) -> ContentBlock:
    """Return a monospaced hash display block."""
    return ContentBlock(block_type="hash_block", data={"label": label, "value": value})


def _status_badge(severity: FindingSeverity) -> ContentBlock:
    """Return a coloured severity badge block for the given severity."""
    return ContentBlock(
        block_type="status_badge",
        data={"label": severity.value, "severity": severity.value},
    )


def _format_date(d: Optional[date]) -> str:
    """Format a date for display; return 'N/A' when the argument is None."""
    if d is None:
        return "N/A"
    return d.strftime("%d %B %Y")


def _format_dual_timezone(
    dt: Optional[datetime],
    tz_name: str = "UTC",
    tz_offset_hours: int = 0,
) -> str:
    """
    Format a UTC datetime showing both UTC and local time.

    Example output: '2003-12-01 01:54:22 UTC (2003-11-30 20:54:22 EST)'

    Parameters
    ----------
    dt : datetime | None
        UTC datetime to format. Returns 'N/A' if None.
    tz_name : str
        Short timezone name for the local time (e.g. 'EST', 'BST').
    tz_offset_hours : int
        Offset from UTC in whole hours (negative = west of UTC).
    """
    if dt is None:
        return "N/A"
    from datetime import timedelta
    utc_str = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    if tz_offset_hours == 0:
        return utc_str
    local_dt = dt + timedelta(hours=tz_offset_hours)
    local_str = local_dt.strftime(f"%Y-%m-%d %H:%M:%S {tz_name}")
    return f"{utc_str} ({local_str})"


def _format_datetime(
    dt: Optional[datetime],
    tz_name: str = "UTC",
    tz_offset_hours: int = 0,
) -> str:
    """
    Format a datetime for display.

    With the default arguments (tz_offset_hours=0) the output is in plain
    UTC format.  When a non-zero offset is supplied, the local time is
    appended in parentheses via _format_dual_timezone().

    Parameters
    ----------
    dt : datetime | None
        UTC datetime. Returns 'N/A' if None.
    tz_name : str
        Short timezone abbreviation for local time (default 'UTC').
    tz_offset_hours : int
        Whole-hour offset from UTC (default 0 = UTC only).

    Returns
    -------
    str
        Formatted datetime string such as
        '2026-05-12 09:00:00 UTC' (offset=0) or
        '2026-05-12 10:00:00 UTC (2026-05-12 05:00:00 EST)' (offset=-5).
    """
    if dt is None:
        return "N/A"
    if tz_offset_hours == 0:
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    return _format_dual_timezone(dt, tz_name=tz_name, tz_offset_hours=tz_offset_hours)


def _bytes_to_human(n: int) -> str:
    """Convert a raw byte count to a human-readable string (e.g. '1.45 GB')."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.2f} {unit}"
        n /= 1024
    return f"{n:.2f} PB"


def _count_by_severity(findings: list[FindingItem]) -> dict[str, int]:
    """
    Tally a list of FindingItem objects by severity.

    Returns a dict keyed by FindingSeverity.value strings, guaranteed
    to include every severity level (with a count of zero if absent).
    """
    counts: dict[str, int] = {s.value: 0 for s in FindingSeverity}
    for item in findings:
        counts[item.severity.value] += 1
    return counts


def _findings_table_rows(findings: list[FindingItem]) -> list[list[str]]:
    """
    Convert a list of FindingItem objects into table rows for the renderer.

    Columns: ID, Title, Severity, Category, Timestamp, Artefact Location.
    """
    return [
        [
            f.finding_id,
            f.title,
            f.severity.value,
            f.category,
            _format_datetime(f.timestamp),
            f.artefact_location,
        ]
        for f in findings
    ]


def _module_status_note(result: ModuleResult) -> ContentBlock:
    """
    Return a paragraph describing the run status and coverage of a module.

    For partial or failed runs the note surfaces the error message so
    readers are aware of any limitations on the completeness of results.
    """
    status = str(result.status or "").strip().lower()
    outcome = str(result.execution_outcome or "").strip().lower()
    examined = int(result.artefacts_examined or 0)
    relevant = int(result.artefacts_relevant or 0)
    examined_label = "artefact" if examined == 1 else "artefacts"
    relevant_label = "artefact" if relevant == 1 else "artefacts"
    when = _format_datetime(result.run_timestamp)
    reason = str(result.error_message or result.summary or "No reason was recorded.").strip()
    candidate_count = int((result.raw_data or {}).get("candidate_observation_count", 0) or 0)
    candidate_note = ""
    if candidate_count:
        samples = (result.raw_data or {}).get("candidate_observations", []) or []
        types = []
        for item in samples:
            value = str((item or {}).get("finding_type") or "candidate").replace("_", " ").title()
            if value not in types:
                types.append(value)
        sample_text = ", ".join(types[:4])
        candidate_note = (
            f" {candidate_count} candidate observation(s) were retained for examiner review"
            + (f" ({sample_text})" if sample_text else "")
            + "; they are not counted as canonical evidentiary findings."
        )

    if status == "not_applicable":
        text = (f"{result.module_name} v{result.module_version} was NOT APPLICABLE on {when}. "
                f"Reason: {reason} This is not scored as a failure and no absence conclusion is drawn.")
    elif status == "verify_later":
        text = (f"{result.module_name} v{result.module_version} requires separate validation evidence. "
                f"Reason: {reason}")
    elif outcome == "did_not_run" or status in {"skipped", "failed_isolated"}:
        text = (
            f"{result.module_name} v{result.module_version} did not complete on {when}. "
            f"Reason: {reason} The failure was isolated; later modules remain independently valid. "
            "No conclusion about absence is drawn from this module."
        )
    elif status == "success":
        text = (
            f"{result.module_name} v{result.module_version} completed its declared evidence technique on {when}. "
            f"{examined} {examined_label} examined; "
            f"{relevant} relevant {relevant_label} identified."
        )
    elif status == "completed_with_fallback":
        # Legacy result compatibility. Fallback output is retained, but the named
        # module is reported as incomplete rather than complete.
        text = (
            f"{result.module_name} v{result.module_version} is INCOMPLETE on {when}. "
            f"A separately identified fallback produced retained results, but it did not complete the named specialist capability. "
            f"Caveat: {reason} {examined} {examined_label} examined; "
            f"{relevant} relevant {relevant_label} identified."
        )
    elif status in {"partial", "degraded", "indeterminate"} or outcome == "ran_with_caveat":
        text = (
            f"{result.module_name} v{result.module_version} ran with a caveat on {when}. "
            f"Caveat: {reason} "
            f"{examined} {examined_label} examined; "
            f"{relevant} relevant {relevant_label} identified."
        )
    else:
        text = (
            f"{result.module_name} v{result.module_version} failed during execution on {when}. "
            f"Error: {reason} Results for this module are incomplete or absent; "
            "the report must not interpret this as a clean result."
        )
    text += candidate_note
    return _para(text)


def _build_findings_subsection(
    module_name: str,
    findings: list["FindingItem"],
) -> list["ContentBlock"]:
    """Build findings blocks: highlighted boxes for high/critical, full table for all."""
    blocks: list[ContentBlock] = [_h3(f"{module_name} — Findings")]
    if not findings:
        blocks.append(_para(
            f"No canonical evidentiary findings were accepted for {module_name}. "
            "This statement does not imply that no candidate output was generated or that the artefact class is absent; "
            "candidate and coverage details are reported in the module status and assurance sections."
        ))
        return blocks

    # Severity-boxed highlights for critical/high/medium. For a small
    # foundational module, also show Low findings so substantive metadata and
    # integrity details are not reduced to a title/path-only table.
    show_all_details = len(findings) <= 5
    for f in findings:
        sev = f.severity.value.lower() if hasattr(f.severity, "value") else str(f.severity).lower()
        if sev in ("critical", "high", "medium") or show_all_details:
            blocks.append(ContentBlock("finding_box", {
                "severity": sev,
                "title": f.title,
                "body": f.description,
                "ref_id": f.finding_id or "",
            }))

    # Full findings table
    rows = []
    for f in findings:
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        ts  = str(f.timestamp)[:19] if f.timestamp else ""
        title = f.title or ""
        rows.append([
            f.finding_id or "",
            sev,
            (title[:47] + "…") if len(title) > 50 else title,
            (f.artefact_location or "")[:50],
            ts,
        ])
    blocks.append(_table(["REF", "SEVERITY", "TITLE", "ARTEFACT / LOCATION", "TIMESTAMP"], rows))

    return blocks


# ===========================================================================
# Section builder functions — Sections 1 through 20
# ===========================================================================


def build_cover_page(
    metadata: ReportMetadata,
    case_info: "CaseInfo" = None,
    investigator: Optional["InvestigatorDetails"] = None,
    case_config: Any = None,
    tool_versions: Optional[dict] = None,
) -> SectionContent:
    """
    Builds the cover page section. Uses case_config fields when available.
    Layout: org name/address, report title, teal subtitle, teal dividers,
    metadata table (dark navy left column), confidentiality footer.
    """
    cc = case_config  # shorthand
    blocks: list[ContentBlock] = []

    # ── Organisation header ──────────────────────────────────────────────
    org_name    = (cc.org_name if cc else None) or metadata.examiner_organisation or "Digital Forensics"
    org_address = (cc.org_address if cc else "") or ""
    blocks.append(ContentBlock("cover_org_header", {
        "org_name": org_name,
        "org_address": org_address,
    }))

    # ── Teal divider line ────────────────────────────────────────────────
    blocks.append(ContentBlock("teal_rule", {}))

    # ── Report title ─────────────────────────────────────────────────────
    blocks.append(ContentBlock("cover_title", {
        "title": "DIGITAL FORENSIC INVESTIGATION REPORT",
    }))

    # ── Subtitle (evidence labels) ───────────────────────────────────────
    if cc and cc.evidence_items:
        subtitle = "  ·  ".join(e.label for e in cc.evidence_items[:4])
    else:
        subtitle = metadata.case_number
    blocks.append(ContentBlock("cover_subtitle", {"subtitle": subtitle}))

    # ── Teal divider line ────────────────────────────────────────────────
    blocks.append(ContentBlock("teal_rule", {}))

    # ── 9-row metadata table ─────────────────────────────────────────────
    def _v(val: str, fallback: str = "Not applicable") -> str:
        return val.strip() if val and val.strip() else fallback

    case_num    = _v(cc.case_number if cc else "") or _v(metadata.case_number)
    auth_by     = "Not applicable"
    sup_exam    = _v(investigator.supervisor_name if investigator else "") if investigator else "Not applicable"
    _inv_badge  = getattr(investigator, "badge_number", "") if investigator else ""
    forensic_ex = (
        f"{investigator.name} ({_inv_badge})" if investigator and _inv_badge
        else (investigator.name if investigator else _v(metadata.examiner_name))
    )
    client_rep  = "Not applicable"
    ev_items    = "Not configured"
    # Primary tools are rendered from the runtime-detected version map — never a
    # static list.  When detection produced nothing, point to the tools section
    # rather than inventing versions.
    if tool_versions:
        _tv_parts = [
            f"{name} {ver}".strip()
            for name, ver in sorted(tool_versions.items())
            if ver and str(ver).lower() not in ("", "unknown", "not installed", "not found")
        ]
        tools_str = " · ".join(_tv_parts[:6]) or "See §2.4 Tools and Software"
    else:
        tools_str = "See §2.4 Tools and Software"
    classification  = "CONFIDENTIAL"
    # Single source of truth for the report date: the runtime ReportMetadata
    # (set to the generation date), so the cover, declaration and body agree.
    _md_date = getattr(metadata, "report_date", None)
    if hasattr(_md_date, "isoformat"):
        report_date_str = _md_date.isoformat()
    elif _md_date:
        report_date_str = str(_md_date)
    else:
        from datetime import datetime as _datetime, timezone as _tz
        report_date_str = _datetime.now(_tz.utc).strftime("%Y-%m-%d")

    if cc:
        if cc.authorising_officer and cc.authorising_officer.name:
            ao = cc.authorising_officer
            auth_by = f"{ao.name} — {ao.title}, {ao.organisation}".strip(" —,")
        if cc.supervising_examiner and cc.supervising_examiner.name:
            sup_exam = cc.supervising_examiner.name
        if cc.examiner and cc.examiner.name:
            forensic_ex = (
                f"{cc.examiner.name} ({cc.examiner.email})"
                if cc.examiner.email else cc.examiner.name
            )
        if cc.client_representative and cc.client_representative.name:
            client_rep = cc.client_representative.name
        if cc.evidence_items:
            ev_items = "\n".join(
                f"{getattr(ev, 'label', '')} — {getattr(ev, 'description', '') or getattr(ev, 'path', '')}"
                for ev in cc.evidence_items
            ) or "— not configured —"
        classification = cc.classification or "CONFIDENTIAL"

    meta_rows = [
        ["CASE NUMBER",           case_num],
        ["AUTHORISED BY",         auth_by],
        ["SUPERVISING EXAMINER",  sup_exam],
        ["FORENSIC EXAMINER",     forensic_ex],
        ["CLIENT REPRESENTATIVE", client_rep],
        ["EVIDENCE ITEMS",        ev_items],
        ["RUNTIME TOOLS DETECTED", tools_str],
        ["CLASSIFICATION",        classification],
        ["DATE",                  report_date_str],
    ]
    blocks.append(ContentBlock("metadata_table", {"rows": meta_rows}))

    # ── Confidentiality notice ───────────────────────────────────────────
    blocks.append(ContentBlock("cover_confidential", {
        "text": "CONFIDENTIAL — FOR AUTHORISED PERSONNEL ONLY"
    }))

    # ── Copyright / teal accent bar ──────────────────────────────────────
    year = metadata.report_date.year if hasattr(metadata.report_date, "year") else ""
    client_org = ""
    if case_info is not None:
        client_org = case_info.client_organisation or ""
    blocks.append(ContentBlock("cover_copyright", {
        "text": (
            f"© {year} {org_name}. This report is produced for the sole use of "
            f"{client_org or 'the commissioning authority'}. "
            "Unauthorised reproduction or distribution is prohibited."
        )
    }))

    return SectionContent(section_number=0, section_title="Cover Page", blocks=blocks)


def build_table_of_contents() -> SectionContent:
    """Returns a section that triggers a real two-pass ReportLab TOC."""
    return SectionContent(
        section_number=0,
        section_title="Table of Contents",
        blocks=[
            _h1("TABLE OF CONTENTS"),
            ContentBlock("real_toc", {}),
            ContentBlock("page_break", {}),
        ],
    )


def build_executive_summary(
    metadata: ReportMetadata,
    key_findings: list[KeyFinding],
    all_findings: list[FindingItem],
) -> SectionContent:
    """
    Build Section 3: Executive Summary.

    Provides a non-technical overview intended for senior management or
    legal counsel who may not read the full technical analysis sections.
    Severity counts give an at-a-glance risk picture; key findings provide
    narrative context; a limitations paragraph sets the scope of reliance.

    Parameters
    ----------
    metadata:
        Report metadata used to bind the summary to the specific case.
    key_findings:
        Curated list of KeyFinding objects (typically 3–8) representing
        the most significant conclusions of the examination.
    all_findings:
        The complete list of FindingItem objects across all analysis
        modules, used only for computing the severity count table.

    Returns
    -------
    SectionContent
        Framing narrative, severity count table, per-key-finding
        sub-sections, and a limitations paragraph.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Executive Summary"))
    blocks.append(_spacer())

    # Framing paragraph — ties the summary to the case and examiner
    blocks.append(_para(
        f"This report presents the findings of a digital forensic examination "
        f"conducted by {metadata.examiner_name} of {metadata.examiner_organisation} "
        f"in relation to case {metadata.case_number}.  The examination was "
        f"completed on {_format_date(metadata.report_date)} and covers the "
        "digital evidence items described in Section 13 (Evidence Acquisition)."
    ))
    blocks.append(_spacer())

    # Severity count overview table
    counts = _count_by_severity(all_findings)
    total = sum(counts.values())

    blocks.append(_h2("Finding Summary"))
    blocks.append(_para(
        f"A total of {total} finding(s) were identified across all analysis "
        "modules.  The table below summarises findings by severity rating."
    ))
    severity_rows: list[list[str]] = [
        [sev, str(cnt)] for sev, cnt in counts.items() if cnt > 0
    ]
    severity_rows.append(["TOTAL", str(total)])
    blocks.append(_table(["Severity", "Count"], severity_rows))
    blocks.append(_spacer())

    # Key findings — one sub-section per KeyFinding
    blocks.append(_h2("Key Findings"))
    if key_findings:
        blocks.append(_para(
            "The following key findings are considered most significant to "
            "the objectives of this investigation.  Full technical detail "
            "for each finding is provided in the relevant analysis sections."
        ))
        blocks.append(_spacer(4))

        for idx, kf in enumerate(key_findings, start=1):
            blocks.append(_h3(f"KF-{idx:02d}: {kf.title}"))
            blocks.append(_status_badge(kf.severity))
            blocks.append(_para(kf.description))

            if kf.supporting_evidence:
                blocks.append(_para("Supporting evidence:"))
                blocks.append(_bullets(kf.supporting_evidence))

            if kf.recommendation:
                blocks.append(_para(f"Recommendation: {kf.recommendation}"))

            blocks.append(_spacer(4))
    else:
        blocks.append(_para(
            "No key findings have been recorded for this examination."
        ))

    # Limitations and reliance caveat
    blocks.append(_spacer())
    blocks.append(_h2("Limitations and Caveats"))
    blocks.append(_para(
        "The findings in this report are based solely on the supplied digital "
        "evidence and the module outcomes recorded in this report. The report does "
        "not infer acquisition conditions, tool validation status, criminal intent, "
        "or legal liability unless those matters are explicitly supported by the "
        "case record. This report does not constitute legal advice; the "
        "instructing party should seek appropriate legal counsel regarding "
        "the implications of these findings."
    ))

    return SectionContent(
        section_number=3,
        section_title="Executive Summary",
        blocks=blocks,
    )


def _build_section_1_1(cc: Any) -> list:
    """1.1 Investigation Background — generated from CaseConfig."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading2", {"text": "1.1 Investigation Background"}))

    org  = cc.org_name if cc else "the examining agency"
    auth = cc.authorising_officer.name if cc and cc.authorising_officer and cc.authorising_officer.name else "the authorising officer"
    sup  = cc.supervising_examiner.name if cc and cc.supervising_examiner and cc.supervising_examiner.name else "the supervising examiner"
    ex   = cc.examiner.name if cc and cc.examiner and cc.examiner.name else "the forensic examiner"
    cn   = cc.case_number if cc else "the referenced case number"

    para1 = (
        f"This digital forensic investigation was conducted under Case Number {cn}, "
        f"authorised by {auth} of {org}, and supervised by {sup}. "
        f"The forensic examination was carried out by {ex} using the evidence sources "
        "and processing records identified in this report. The report does not infer "
        "physical handling, write-blocker use, source-device access, imaging conditions, "
        "or compliance with a standard unless the corresponding event is recorded."
    )
    blocks.append(ContentBlock("paragraph", {"text": para1}))

    if cc and cc.evidence_items:
        ev_descs = []
        for ev in cc.evidence_items:
            desc = ev.label
            parts = []
            if getattr(ev, "hostname", ""): parts.append(f"hostname {ev.hostname}")
            if getattr(ev, "os", ""):       parts.append(ev.os)
            if getattr(ev, "owner", ""):    parts.append(f"primary user {ev.owner}")
            if parts:                        desc += f" ({', '.join(parts)})"
            ev_descs.append(desc)
        para2 = "Forensic images submitted for examination: " + "; and ".join(ev_descs) + ". "
        if cc.investigation_background:
            para2 += cc.investigation_background
        else:
            para2 += (
                "No investigation background or allegation was supplied. The examination "
                "therefore reports technical observations without inferring an offence, "
                "actor, motive, or investigative hypothesis."
            )
        blocks.append(ContentBlock("paragraph", {"text": para2}))
    elif cc and cc.investigation_background:
        blocks.append(ContentBlock("paragraph", {"text": cc.investigation_background}))

    return blocks


def _build_section_1_2(cc: Any) -> list:
    """1.2 Investigation Objectives — numbered list from CaseConfig."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading2", {"text": "1.2 Investigation Objectives"}))
    default_objectives = [
        "Validate the supplied evidence stream and record the algorithms and reference values used.",
        "Identify supported media, partition and filesystem structures without altering the evidence.",
        "Examine configured artefact classes and record findings, zero-result outcomes, skipped modules and caveats.",
        "Recover deleted or protected content only where the method and result can be recorded and independently reviewed.",
        "Develop a bounded chronology and answer the six forensic questions only to the level supported by the evidence.",
    ]
    objectives = (cc.objectives if cc and cc.objectives else default_objectives)
    blocks.append(ContentBlock("numbered_list", {"items": objectives}))
    return blocks


def _build_section_1_3(cc: Any) -> list:
    """1.3 Communication Line & Authorisation Hierarchy — table from CaseConfig."""
    blocks: list[ContentBlock] = []
    blocks.append(ContentBlock("heading2", {"text": "1.3 Communication Line & Authorisation Hierarchy"}))
    client_str  = cc.client_representative.name if cc and cc.client_representative and cc.client_representative.name else "—"
    auth_str    = "—"
    sup_str     = "—"
    ex_str      = "—"
    if cc:
        if cc.authorising_officer and cc.authorising_officer.name:
            ao = cc.authorising_officer
            auth_str = f"{ao.name} — {ao.title}, {ao.organisation}".strip(" —,")
        if cc.supervising_examiner and cc.supervising_examiner.name:
            sup_str = cc.supervising_examiner.name
        if cc.examiner and cc.examiner.name:
            ex_str = cc.examiner.name
    rows = [
        ["ROLE", "PERSON"],
        ["Client Representative",  client_str],
        ["Authorising Officer",     auth_str],
        ["Supervising Examiner",    sup_str],
        ["Forensic Examiner",       ex_str],
        ["Report Flow", "Examiner → Sarah Johnson → Technical Team → Client"],
    ]
    blocks.append(ContentBlock("table", {"headers": rows[0], "rows": rows[1:]}))
    return blocks


def build_section_one(
    case_info: "CaseInfo",
    investigator: "InvestigatorDetails",
    case_config: Any = None,
) -> "SectionContent":
    """
    Section 1 — Case Information.
    1.1 Investigation Background (prose paragraphs)
    1.2 Investigation Objectives (bullet list)
    1.3 Communication Line and Authorisation Hierarchy (table)
    """
    blocks: list[ContentBlock] = []
    blocks.append(_h1("1. CASE INFORMATION"))

    # ── 1.1 Investigation Background ─────────────────────────────────────
    blocks.append(_h2("1.1  Investigation Background"))
    cc = case_config

    if cc and cc.investigation_background:
        for para in cc.investigation_background.split("\n\n"):
            if para.strip():
                blocks.append(_para(para.strip()))
    else:
        case_ref = case_info.case_title or case_info.case_number or "this investigation"
        bg = (
            f"This report documents the findings of a digital forensic examination "
            f"carried out in the matter of {case_ref}. "
        )
        if cc and cc.authorising_officer.name:
            ao = cc.authorising_officer
            bg += (
                f"The examination was authorised by {ao.name}"
                + (f", {ao.title}" if ao.title else "")
                + (f" of {ao.organisation}. " if ao.organisation else ". ")
            )
        if cc and cc.supervising_examiner.name:
            bg += f"The investigation was conducted under the supervision of {cc.supervising_examiner.name}. "
        if investigator.name:
            bg += (
                f"The forensic examination was performed by {investigator.name}"
                + (f" ({investigator.badge_number})" if investigator.badge_number else "")
                + (f" of {investigator.organisation}. " if investigator.organisation else ". ")
            )
        if cc and cc.evidence_items:
            ev_list = "; ".join(
                f"{e.label} — {e.description}" if e.description else e.label
                for e in cc.evidence_items
            )
            bg += f"The following exhibits were submitted for examination: {ev_list}. "
        if cc and cc.offence_types:
            bg += (
                "The investigation relates to the following suspected offences: "
                + ", ".join(cc.offence_types) + ". "
            )
        bg += (
            "All examination work was carried out in accordance with ISO/IEC 27037, "
            "ISO/IEC 27042, the ACPO Good Practice Guide for Digital Evidence v5, "
            "and NIST SP 800-86."
        )
        blocks.append(_para(bg))

    blocks.append(_para(
        "This examination was governed by the standards and best-practice guides "
        "listed in Section 2 (Methodology and Standards). All findings are reported "
        "to the civil standard of the balance of probabilities, with critical and "
        "high-severity findings corroborated by two or more independent artefacts "
        "where possible."
    ))

    # ── 1.2 Investigation Objectives ─────────────────────────────────────
    blocks.append(_h2("1.2  Investigation Objectives"))
    objectives = (cc.objectives if cc and cc.objectives else []) or [
        "Determine the nature and extent of any data stored on the submitted exhibits.",
        "Identify any files or artefacts relevant to the alleged offences.",
        "Establish a chronological timeline of device usage.",
        "Recover any deleted or concealed data relevant to the investigation.",
        "Provide a structured draft report suitable for examiner verification and approval.",
    ]
    blocks.append(_bullets(objectives))

    # ── 1.3 Authorisation Hierarchy ───────────────────────────────────────
    blocks.append(_h2("1.3  Communication Line and Authorisation Hierarchy"))

    rows = [["ROLE", "NAME", "ORGANISATION"]]
    if cc:
        rows.append(["Client Representative",
                     cc.client_representative.name,
                     cc.client_representative.organisation])
        ao = cc.authorising_officer
        rows.append(["Authorising Officer",
                     ao.name,
                     " — ".join(filter(None, [ao.title, ao.organisation]))])
        rows.append(["Supervising Examiner",
                     cc.supervising_examiner.name,
                     cc.supervising_examiner.organisation])
        ex = cc.examiner
        examiner_badge = (f"Badge: {ex.badge}" if ex and ex.badge else "")
        rows.append(["Forensic Examiner",
                     ex.name if ex else "",
                     " — ".join(filter(None, [ex.institution if ex else "", examiner_badge]))])
    else:
        rows.append(["Client",               case_info.client_name, case_info.client_organisation])
        rows.append(["Authorising Officer",   "", ""])
        rows.append(["Supervising Examiner",  investigator.supervisor_name or "", ""])
        rows.append(["Forensic Examiner",     investigator.name, investigator.organisation])

    rows.append(["Report Flow", "Examiner → Supervisor → Authorising Officer → Client", ""])
    blocks.append(_table(rows[0], rows[1:]))

    return SectionContent(section_number=1, section_title="Case Information", blocks=blocks)


def build_investigation_background(
    background: str,
    incident_summary: str,
    referral_source: str,
    hypothesis: str,
) -> SectionContent:
    """
    Build Section 5: Investigation Background.

    Provides the narrative context in which the investigation arose, a
    factual account of the reported incident, the referral pathway, and
    the overarching investigative hypothesis.

    Parameters
    ----------
    background:
        Narrative describing the organisational or operational context
        in which the incident occurred (business background, prior events,
        relevant relationships).
    incident_summary:
        Factual summary of the reported incident that prompted the
        examination, written in neutral language without pre-judging the
        outcome.
    referral_source:
        Who or what body referred the matter for forensic examination
        (e.g. 'Internal Security Team', 'Solicitor – Smith & Jones LLP',
        'Detective Constable A. Jones, Metropolitan Police').
    hypothesis:
        The primary investigative hypothesis or question that the
        examination is designed to test.

    Returns
    -------
    SectionContent
        Four sub-sections: Background, Incident Summary, Referral Source,
        and Investigative Hypothesis.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Investigation Background"))
    blocks.append(_spacer())

    blocks.append(_h2("Background"))
    blocks.append(_para(background))
    blocks.append(_spacer())

    blocks.append(_h2("Incident Summary"))
    blocks.append(_para(incident_summary))
    blocks.append(_spacer())

    blocks.append(_h2("Referral Source"))
    blocks.append(_para(referral_source))
    blocks.append(_spacer())

    blocks.append(_h2("Investigative Hypothesis"))
    blocks.append(_para(hypothesis))

    return SectionContent(
        section_number=5,
        section_title="Investigation Background",
        blocks=blocks,
    )


def build_objectives(
    objectives: list[str],
    scope: str,
    out_of_scope: list[str],
) -> SectionContent:
    """
    Build Section 6: Objectives.

    Documents the agreed objectives of the examination, the scope of
    evidence and systems covered, and any explicit out-of-scope
    exclusions.  Explicit scope boundaries reduce the risk of over-reliance
    by parties who receive the report.

    Parameters
    ----------
    objectives:
        Ordered list of specific investigation objectives.  Each item
        should be a complete sentence (e.g. 'Determine whether the device
        was used to access Company X network shares after 01 January 2025').
    scope:
        Narrative description of what the examination covers — which
        devices, time periods, data types, and analytical techniques are
        in scope.
    out_of_scope:
        Explicit list of items excluded from this examination.  Each item
        should be a short phrase sufficient to avoid ambiguity.

    Returns
    -------
    SectionContent
        Numbered objectives list with Scope and Out of Scope sub-sections.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Objectives"))
    blocks.append(_spacer())

    blocks.append(_h2("Investigation Objectives"))
    blocks.append(_para(
        "The following objectives were agreed with the instructing party "
        "prior to commencement of the examination:"
    ))
    blocks.append(_numbered(objectives))
    blocks.append(_spacer())

    blocks.append(_h2("Scope of Examination"))
    blocks.append(_para(scope))
    blocks.append(_spacer())

    if out_of_scope:
        blocks.append(_h2("Out of Scope"))
        blocks.append(_para(
            "The following items were explicitly excluded from this "
            "examination:"
        ))
        blocks.append(_bullets(out_of_scope))

    return SectionContent(
        section_number=6,
        section_title="Objectives",
        blocks=blocks,
    )


def build_legal_authorisation(
    authority_description: str,
    authorising_officer: str,
    authorising_organisation: str,
    reference_number: str,
    date_of_authority: date,
    scope_of_authority: str,
    additional_notes: str = "",
) -> SectionContent:
    """
    Build Section 7: Legal Authorisation.

    Documents the legal basis under which the examination was conducted.
    This section is critical to demonstrating that the examination was
    lawfully authorised, which is a prerequisite for the admissibility of
    findings in legal proceedings.

    Parameters
    ----------
    authority_description:
        Description of the authorising legal instrument (e.g. 'Search
        and Seizure Warrant issued under Section 8 PACE 1984', 'Civil
        Court Order – Case No. HC-2025-001234', 'Written Consent – Device
        Owner').
    authorising_officer:
        Full name and title of the person who granted the authority.
    authorising_organisation:
        Organisation or court that issued the authorising instrument.
    reference_number:
        Official reference number of the warrant, order, or consent form.
    date_of_authority:
        Date on which the authority was granted or signed.
    scope_of_authority:
        Plain-language description of what the authority permits the
        examiner to do (e.g. 'Search and seize digital devices belonging
        to the subject located at the premises').
    additional_notes:
        Any conditions, caveats, or supplementary notes associated with
        the authority (e.g. 'Subject to UK-GDPR Article 9 restrictions').

    Returns
    -------
    SectionContent
        Administrative details table, scope narrative, and optional
        additional notes.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Legal Authorisation"))
    blocks.append(_spacer())

    blocks.append(_para(
        "This examination was conducted under lawful authority.  The "
        "authorising instrument is detailed below."
    ))
    blocks.append(_spacer())

    blocks.append(_kv([
        ("Authority Type",           authority_description),
        ("Reference Number",         reference_number),
        ("Authorising Officer",      authorising_officer),
        ("Authorising Organisation", authorising_organisation),
        ("Date of Authority",        _format_date(date_of_authority)),
    ]))

    blocks.append(_spacer())
    blocks.append(_h2("Scope of Authority"))
    blocks.append(_para(scope_of_authority))

    if additional_notes:
        blocks.append(_spacer())
        blocks.append(_h2("Additional Notes"))
        blocks.append(_para(additional_notes))

    return SectionContent(
        section_number=7,
        section_title="Legal Authorisation",
        blocks=blocks,
    )


def build_chain_of_custody_summary(
    evidence_items: list[EvidenceAcquisition],
    custody_events: Optional[list[dict[str, str]]] = None,
) -> SectionContent:
    """
    Build Section 8: Chain of Custody Summary.

    Demonstrates continuous and unbroken accountability for every
    evidence item from initial receipt to return or disposal.  The hash
    verification sub-section enables a reviewer to confirm that the
    images examined are identical to those acquired.

    Parameters
    ----------
    evidence_items:
        List of EvidenceAcquisition records, one per exhibit.
    custody_events:
        Optional ordered list of custody transfer events.  Each dict
        should contain the keys: 'date', 'exhibit', 'from_party',
        'to_party', 'purpose', 'signature'.

    Returns
    -------
    SectionContent
        Exhibit summary table, per-exhibit hash verification blocks,
        and an optional custody transfer log.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Chain of Custody Summary"))
    blocks.append(_spacer())

    blocks.append(_para(
        "The following table summarises all digital evidence items received "
        "for examination.  Each exhibit has been handled in accordance with "
        "the forensic principles described in Section 10 to ensure the "
        "integrity and continuity of evidence throughout the examination."
    ))
    blocks.append(_spacer())

    if evidence_items:
        # High-level exhibit summary
        headers = [
            "Exhibit No.", "Description", "Acquired By",
            "Date Acquired", "Verified",
        ]
        rows = [
            [
                item.exhibit_ref,
                item.description,
                item.acquired_by,
                _format_date(item.acquisition_date),
                "Yes" if item.verified else "No",
            ]
            for item in evidence_items
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

        # Per-exhibit hash verification sub-section
        blocks.append(_h2("Hash Verification"))
        blocks.append(_para(
            "The integrity of each forensic image was verified by comparing "
            "cryptographic hash values computed immediately after acquisition "
            "with those computed at the start of the examination."
        ))
        blocks.append(_spacer(4))

        for item in evidence_items:
            blocks.append(_h3(
                f"Exhibit {item.exhibit_ref} – {item.description}"
            ))
            blocks.append(_kv([
                ("Acquisition Method",  item.acquisition_method),
                ("Tool",               f"{item.tool_used} v{item.tool_version}"),
                ("Source Size",         _bytes_to_human(item.source_size_bytes)),
                ("Image Size",          _bytes_to_human(item.image_size_bytes)),
                ("Integrity Verified",  "Yes" if item.verified else "No"),
            ]))
            blocks.append(_hash_block("MD5",     item.md5_hash))
            blocks.append(_hash_block("SHA-256", item.sha256_hash))

            if item.notes:
                blocks.append(_para(item.notes))

            blocks.append(_spacer(4))
    else:
        blocks.append(_para("No evidence acquisition records were provided."))

    # Optional custody transfer log
    if custody_events:
        blocks.append(_spacer())
        blocks.append(_h2("Custody Transfer Log"))
        headers = ["Date", "Exhibit", "From", "To", "Purpose", "Signature"]
        rows = [
            [
                ev.get("date", ""),
                ev.get("exhibit", ""),
                ev.get("from_party", ""),
                ev.get("to_party", ""),
                ev.get("purpose", ""),
                ev.get("signature", ""),
            ]
            for ev in custody_events
        ]
        blocks.append(_table(headers, rows))

    return SectionContent(
        section_number=8,
        section_title="Chain of Custody Summary",
        blocks=blocks,
    )


def build_investigator_details(
    investigators: list[InvestigatorDetails],
    laboratory_name: str = "",
    laboratory_accreditation: str = "",
) -> SectionContent:
    """
    Build Section 9: Investigator Details.

    Documents the professional qualifications, certifications, and roles
    of all personnel involved in the examination.  This section supports
    the weight assigned to findings by demonstrating that the examiners
    are competent to perform the work.

    Parameters
    ----------
    investigators:
        List of InvestigatorDetails objects, one per named examiner or
        analyst.
    laboratory_name:
        Name of the forensic laboratory where the examination was
        conducted.
    laboratory_accreditation:
        Accreditation body and certificate number if applicable
        (e.g. 'ISO/IEC 17025:2017 – UKAS Certificate No. 1234').

    Returns
    -------
    SectionContent
        Laboratory overview block (if provided) and per-investigator
        detail sub-sections.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Investigator Details"))
    blocks.append(_spacer())

    if laboratory_name:
        blocks.append(_h2("Forensic Laboratory"))
        lab_pairs: list[tuple[str, str]] = [("Laboratory Name", laboratory_name)]
        if laboratory_accreditation:
            lab_pairs.append(("Accreditation", laboratory_accreditation))
        blocks.append(_kv(lab_pairs))
        blocks.append(_spacer())

    if investigators:
        blocks.append(_h2("Examination Personnel"))
        for person in investigators:
            heading = (
                f"{person.name}"
                f"{' – ' + person.role_in_case if person.role_in_case else ''}"
            )
            blocks.append(_h3(heading))
            pairs: list[tuple[str, str]] = [
                ("Full Name",     person.name),
                ("Title",         person.title),
                ("Organisation",  person.organisation),
                ("Role in Case",  person.role_in_case or "N/A"),
                ("Contact Email", person.contact_email or "N/A"),
                (
                    "Experience",
                    f"{person.experience_years} year(s)"
                    if person.experience_years
                    else "N/A",
                ),
            ]
            blocks.append(_kv(pairs))

            if person.certifications:
                blocks.append(_para("Professional certifications:"))
                blocks.append(_bullets(person.certifications))

            blocks.append(_spacer(4))
    else:
        blocks.append(_para("No investigator details were provided."))

    return SectionContent(
        section_number=9,
        section_title="Investigator Details",
        blocks=blocks,
    )


def build_forensic_standards(
    standards: list[str],
    principles: Optional[list[str]] = None,
    accreditations: Optional[list[str]] = None,
) -> SectionContent:
    """
    Build Section 10: Forensic Standards.

    Describes the professional standards, guidelines, and governing
    principles referenced by the examination workflow. Listing a standard does
    not claim laboratory accreditation or certify legal admissibility.

    Parameters
    ----------
    standards:
        List of standard or guideline names applied to the examination
        (e.g. 'ISO/IEC 27037:2012', 'ACPO Good Practice Guide for
        Digital Evidence v5', 'NIST SP 800-86').
    principles:
        Ordered list of guiding principles followed during the examination.
        When None, a set of four principles aligned with the ACPO Good
        Practice Guide is inserted automatically.
    accreditations:
        Laboratory or personal accreditations relevant to the scope of
        the examination (e.g. 'UKAS ISO/IEC 17025 – Cert. 4321').

    Returns
    -------
    SectionContent
        Standards list, numbered principles, and optional accreditations.
    """
    # Default ACPO-aligned principles when none are supplied by the caller
    _default_principles = [
        (
            "No action taken by law enforcement agencies, or their agents, "
            "should change data held on a digital device or storage medium "
            "which may subsequently be relied upon in court."
        ),
        (
            "In exceptional circumstances, where a person finds it necessary "
            "to access original data held on a digital device, that person "
            "must be competent to do so and be able to give evidence explaining "
            "the relevance and the implications of their actions."
        ),
        (
            "An audit trail or other record of all processes applied to "
            "digital evidence should be created and preserved.  An independent "
            "third party should be able to examine those processes and achieve "
            "the same result."
        ),
        (
            "The person in charge of the investigation has overall "
            "responsibility for ensuring that the law and these principles are "
            "adhered to."
        ),
    ]

    blocks: list[ContentBlock] = []

    blocks.append(_h1("Forensic Standards"))
    blocks.append(_spacer())

    blocks.append(_para(
        "This examination was conducted in accordance with recognised national "
        "and international forensic standards.  The standards and principles "
        "listed below were followed throughout the acquisition, processing, "
        "analysis, and reporting phases."
    ))
    blocks.append(_spacer())

    blocks.append(_h2("Standards and Guidelines Applied"))
    if standards:
        blocks.append(_bullets(standards))
    else:
        blocks.append(_para("No specific standards were recorded."))

    blocks.append(_spacer())
    blocks.append(_h2("Guiding Principles"))
    applied_principles = principles if principles is not None else _default_principles
    blocks.append(_numbered(applied_principles))

    if accreditations:
        blocks.append(_spacer())
        blocks.append(_h2("Accreditations"))
        blocks.append(_bullets(accreditations))

    return SectionContent(
        section_number=10,
        section_title="Forensic Standards",
        blocks=blocks,
    )


def build_methodology(
    methodology_steps: list[str],
    analysis_phases: Optional[list[tuple[str, str]]] = None,
    limitations: Optional[list[str]] = None,
) -> SectionContent:
    """
    Build Section 11: Methodology.

    Describes the step-by-step procedural approach taken during the
    examination in sufficient detail that another competent examiner could
    reproduce the process and verify the results.

    Parameters
    ----------
    methodology_steps:
        Ordered list of procedural steps followed during the examination.
        Each item should be a complete sentence describing one discrete
        action.
    analysis_phases:
        Optional list of (phase_name, phase_description) tuples grouping
        steps into higher-level phases such as 'Acquisition', 'Processing',
        and 'Analysis'.
    limitations:
        Any methodological limitations that may affect the completeness
        or reliability of findings (e.g. encryption preventing access to
        a container, time-zone uncertainty in a particular artefact set).

    Returns
    -------
    SectionContent
        Numbered steps list, optional phase narrative, and optional
        limitations list.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Methodology"))
    blocks.append(_spacer())

    blocks.append(_para(
        "The following methodology was applied during this examination.  "
        "All steps were performed using forensically sound techniques to "
        "preserve the integrity of the original evidence."
    ))
    blocks.append(_spacer())

    blocks.append(_h2("Examination Steps"))
    blocks.append(_numbered(methodology_steps))

    if analysis_phases:
        blocks.append(_spacer())
        blocks.append(_h2("Analysis Phases"))
        for phase_name, phase_description in analysis_phases:
            blocks.append(_h3(phase_name))
            blocks.append(_para(phase_description))
            blocks.append(_spacer(4))

    if limitations:
        blocks.append(_spacer())
        blocks.append(_h2("Methodological Limitations"))
        blocks.append(_bullets(limitations))

    return SectionContent(
        section_number=11,
        section_title="Methodology",
        blocks=blocks,
    )


def integrity_verdict(ev: Any) -> str:
    """Single source of truth for one evidence item's integrity verdict.

    Recomputed from the recorded hash / embedded-reference values (never from a
    stored flag) so every surface that renders integrity — §3.3 and the examiner
    declaration — agrees by construction.  A MATCH/MISMATCH is only ever
    returned when a reference value exists to compare against; an algorithm with
    no embedded reference is never treated as a mismatch and never fabricated
    into a comparison.

    Returns one of: ``VERIFIED`` | ``MISMATCH`` | ``COMPUTED_NO_REF`` |
    ``NOT_COMPUTED``.
    """
    comparisons = [
        ((getattr(ev, "md5_hash", "") or ""), (getattr(ev, "md5_reference", "") or "")),
        ((getattr(ev, "sha1_hash", "") or ""), (getattr(ev, "sha1_reference", "") or "")),
        ((getattr(ev, "sha256_hash", "") or ""), (getattr(ev, "sha256_reference", "") or "")),
    ]
    refs = [(computed, reference) for computed, reference in comparisons if reference]
    if refs:
        return "VERIFIED" if all(
            bool(computed) and computed.lower() == reference.lower()
            for computed, reference in refs
        ) else "MISMATCH"
    if any(computed for computed, _ in comparisons):
        return "COMPUTED_NO_REF"
    return "NOT_COMPUTED"


_INTEGRITY_STATUS_TEXT = {
    "VERIFIED":        "VERIFIED — referenced digest(s) match",
    "MISMATCH":        "MISMATCH — referenced digest(s) differ",
    "COMPUTED_NO_REF": "COMPUTED — no embedded reference",
    "NOT_COMPUTED":    "NOT COMPUTED",
}


def _integrity_status_summary(ev: Any) -> str:
    """Describe verification per algorithm without implying all were embedded."""
    parts: list[str] = []
    for label, computed_name, reference_name in (
        ("MD5", "md5_hash", "md5_reference"),
        ("SHA-1", "sha1_hash", "sha1_reference"),
        ("SHA-256", "sha256_hash", "sha256_reference"),
    ):
        computed = str(getattr(ev, computed_name, "") or "")
        reference = str(getattr(ev, reference_name, "") or "")
        if reference:
            parts.append(
                f"{label} MATCH" if computed and computed.lower() == reference.lower()
                else f"{label} MISMATCH"
            )
        elif computed:
            parts.append(f"{label} computed/no reference")
        else:
            parts.append(f"{label} not computed")
    overall = integrity_verdict(ev)
    prefix = {
        "VERIFIED": "VERIFIED",
        "MISMATCH": "MISMATCH",
        "COMPUTED_NO_REF": "COMPUTED",
        "NOT_COMPUTED": "NOT COMPUTED",
    }[overall]
    return prefix + " - " + "; ".join(parts)


def build_section_three(
    evidence_items: list["EvidenceAcquisition"],
    case_config: Any = None,
    all_module_results: list = None,
) -> "SectionContent":
    """
    Section 3 — Evidence Acquisition.
    3.1 Write Blocker and Evidence Handling
    3.2 Imaging Process and Format
    3.3 Integrity Verification Summary
    """
    blocks: list[ContentBlock] = []
    blocks.append(_h1("3. EVIDENCE ACQUISITION"))

    # ── 3.1 Evidence handling ───────────────────────────────────────────
    blocks.append(_h2("3.1  Evidence Handling and Acquisition Provenance"))
    _methods_for_handling = " ".join(
        str(getattr(ev, "acquisition_method", "") or "")
        for ev in (evidence_items or [])
    ).lower()
    _pre_existing = (not evidence_items) or any(
        marker in _methods_for_handling
        for marker in ("pre-existing", "received", "submitted", "already imaged")
    )
    if _pre_existing:
        blocks.append(_para(
            "The exhibit was supplied as a pre-existing forensic image. "
            "AutoForensics did not acquire the source device and therefore makes "
            "no claim that a hardware write blocker, controlled laboratory, or any "
            "particular acquisition procedure was used. Read-only file-stream "
            "analysis was performed on the supplied image; acquisition provenance "
            "must be established from the submitting authority's records."
        ))
    else:
        blocks.append(_para(
            "The acquisition method recorded for each exhibit is reproduced below. "
            "A hardware write blocker or controlled laboratory is asserted only when "
            "that fact is explicitly present in the case record; AutoForensics does "
            "not infer it from the existence of an image file."
        ))

    # ── 3.2 Imaging Process ───────────────────────────────────────────────
    blocks.append(_h2("3.2  Imaging Process and Format"))
    # Phrase acquisition vs receipt from the manifest: the platform must claim to
    # have acquired an image only when it actually did.  A "pre-existing"
    # acquisition method means the image was received already imaged.
    _methods = " ".join(
        str(getattr(ev, "acquisition_method", "") or "") for ev in (evidence_items or [])
    ).lower()
    if evidence_items and ("pre-existing" in _methods or "received" in _methods):
        _provenance = (
            "The forensic images were received already imaged in the Expert "
            "Witness Format (E01 / EnCase Image File Format); the platform did "
            "not perform the original acquisition."
        )
    elif evidence_items:
        _provenance = (
            "The forensic images were acquired by the platform in the Expert "
            "Witness Format (E01 / EnCase Image File Format)."
        )
    else:
        _provenance = (
            "Forensic images were handled in the Expert Witness Format (E01 / "
            "EnCase Image File Format)."
        )
    blocks.append(_para(
        _provenance + " E01 stores a logical media stream in compressed chunks and "
        "may contain acquisition metadata and embedded digest values. This report "
        "labels a digest as a match only where AutoForensics parsed an embedded "
        "reference and independently matched the reconstructed media stream. A "
        "computed digest with no embedded reference is labelled accordingly."
    ))

    # ── 3.3 Integrity Verification ────────────────────────────────────────
    blocks.append(_h2("3.3  Integrity Verification Summary"))

    if evidence_items:
        # Physical container hashes are examination hashes of the supplied file
        # bytes (or a canonical directory manifest for directory evidence). They
        # are never compared with EWF embedded media digests.
        container_rows = []
        for ev in evidence_items:
            container_rows.append([
                ev.exhibit_ref,
                ev.description[:40] if ev.description else "",
                str(getattr(ev, "source_container_path", "") or "—")[-50:],
                str(getattr(ev, "source_container_md5", "") or "—"),
                str(getattr(ev, "source_container_sha1", "") or "—"),
                str(getattr(ev, "source_container_sha256", "") or "—"),
                str(getattr(ev, "source_container_size_bytes", 0) or 0),
                str(getattr(ev, "source_container_hash_basis", "source-file-bytes") or "source-file-bytes"),
            ])
        blocks.append(_para(
            "Physical source-container examination hashes (computed over the "
            "supplied container bytes or the declared canonical source manifest):"
        ))
        blocks.append(_table(
            ["EXHIBIT", "DESCRIPTION", "SOURCE CONTAINER", "MD5", "SHA-1", "SHA-256", "BYTES", "HASH BASIS"],
            container_rows,
        ))

        # Logical-media hashes are computed over the reconstructed media stream.
        # Only these values are eligible for comparison with embedded EWF digest
        # references.
        media_rows = []
        for ev in evidence_items:
            md5 = ev.md5_hash or "—"
            sha1 = ev.sha1_hash or "—"
            sha = ev.sha256_hash or "—"
            status = _integrity_status_summary(ev)
            media_rows.append([
                ev.exhibit_ref,
                ev.description[:40] if ev.description else "",
                md5, sha1, sha,
                str(getattr(ev, "logical_media_size_bytes", 0) or getattr(ev, "image_size_bytes", 0) or 0),
                status,
                ev.tool_used or "AutoForensics",
            ])
        blocks.append(_spacer())
        blocks.append(_para(
            "Reconstructed logical-media hashes and embedded EWF digest comparison "
            "status. Embedded references apply to logical media, not to the "
            "compressed physical container file:"
        ))
        blocks.append(_table(
            ["EXHIBIT", "DESCRIPTION", "LOGICAL MD5", "LOGICAL SHA-1", "LOGICAL SHA-256", "MEDIA BYTES", "STATUS", "TOOL"],
            media_rows,
        ))

        ref_rows = []
        for ev in evidence_items:
            if not (ev.md5_reference or ev.sha1_reference or ev.sha256_reference):
                continue
            for algo, computed, reference in (
                ("MD5", ev.md5_hash, ev.md5_reference),
                ("SHA-1", ev.sha1_hash, ev.sha1_reference),
                ("SHA-256", ev.sha256_hash, ev.sha256_reference),
            ):
                if reference:
                    ref_rows.append([
                        ev.exhibit_ref, algo, computed or "—", reference,
                        "MATCH" if computed and computed.lower() == reference.lower() else "MISMATCH",
                        "reconstructed logical media",
                    ])
        if ref_rows:
            blocks.append(_spacer())
            blocks.append(_para(
                "Embedded EWF digest re-verification. Each comparison is between "
                "an independently computed logical-media digest and the embedded "
                "reference for the same algorithm:"
            ))
            blocks.append(_table(
                ["EXHIBIT", "ALGORITHM", "COMPUTED LOGICAL-MEDIA DIGEST", "EMBEDDED REFERENCE", "RESULT", "SCOPE"],
                ref_rows,
            ))

        acquisition_rows = []
        for ev in evidence_items:
            if not getattr(ev, "source_pre_acquisition_sha256", ""):
                continue
            _source_stage = (
                "Source acquisition stream"
                if "ewfacquire" in str(getattr(ev, "source_pre_hash_basis", "")).lower()
                else "Source pre-acquisition"
            )
            acquisition_rows.append([
                ev.exhibit_ref, _source_stage, "Attached evidence device", "SHA-256",
                ev.source_pre_acquisition_sha256, "Acquired content",
                ev.source_pre_vs_acquired or "NOT RECORDED"
            ])
            if getattr(ev, "source_post_acquisition_sha256", ""):
                acquisition_rows.append([
                    ev.exhibit_ref, "Source post-acquisition", "Attached evidence device", "SHA-256",
                    ev.source_post_acquisition_sha256, _source_stage,
                    ev.source_pre_vs_source_post or "NOT RECORDED"
                ])
            acquisition_rows.extend([
                [ev.exhibit_ref, "Acquisition verification", "Evidence byte stream", "SHA-256", ev.acquired_content_sha256, _source_stage, ev.source_pre_vs_acquired or "NOT RECORDED"],
                [ev.exhibit_ref, "Pre-analysis container set", "Ordered image segments", "SHA-256", ev.container_set_sha256_pre_analysis, "Post-analysis container set", ev.pre_vs_post_container_set or "NOT RECORDED"],
                [ev.exhibit_ref, "Post-analysis container set", "Ordered image segments", "SHA-256", ev.container_set_sha256_post_analysis, "Pre-analysis container set", ev.pre_vs_post_container_set or "NOT RECORDED"],
                [ev.exhibit_ref, "Pre-analysis logical media", "Evidence byte stream", "SHA-256", ev.logical_media_sha256_pre_analysis, "Post-analysis logical media", ev.pre_vs_post_logical_media or "NOT RECORDED"],
                [ev.exhibit_ref, "Post-analysis logical media", "Evidence byte stream", "SHA-256", ev.logical_media_sha256_post_analysis, "Pre-analysis logical media", ev.pre_vs_post_logical_media or "NOT RECORDED"],
            ])
        if acquisition_rows:
            blocks.append(_spacer())
            blocks.append(_h3("3.3.1  Attached-Device Acquisition Integrity Stages"))
            blocks.append(_para(
                "The table distinguishes source-device content, acquired evidence content, "
                "the ordered forensic-container segment set and the reconstructed logical-media stream. "
                "A compressed E01 container hash is not compared directly with the source-device content hash."
            ))
            blocks.append(_table(
                ["EXHIBIT", "STAGE", "OBJECT HASHED", "ALGORITHM", "HASH", "COMPARISON TARGET", "RESULT"],
                acquisition_rows,
            ))
            blocks.append(_para(
                "Hash agreement supports evidence integrity and acquisition fidelity. It does not prove that every forensic interpretation is correct or that the evidence is automatically admissible."
            ))
    elif case_config and case_config.evidence_items:
        rows = []
        for ev in case_config.evidence_items:
            rows.append([
                ev.label,
                ev.description[:40] if ev.description else "",
                ev.path[-40:] if len(ev.path) > 40 else ev.path,
                "Hash verification performed at analysis commencement",
            ])
        blocks.append(_table(["EXHIBIT", "DESCRIPTION", "PATH", "STATUS"], rows))
        blocks.append(_para(
            "SHA-256 hash values for each exhibit were computed at the commencement of "
            "the examination and are recorded in the Chain of Custody log (Appendix B). "
            "Any discrepancy between the hash recorded at submission and the hash computed "
            "at examination would be reported as a finding."
        ))
    else:
        blocks.append(_para(
            "No evidence acquisition records were pre-loaded for this case. "
            "Hash values computed during examination are recorded in the Chain of Custody log."
        ))

    return SectionContent(section_number=3, section_title="Evidence Acquisition", blocks=blocks)


def build_file_system_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 14: File System Analysis.

    Presents findings from the file system analysis module, covering
    volume/partition information, file statistics, deleted and recovered
    files, timestamp evidence, and any files identified as significant
    to the investigation.

    Parameters
    ----------
    result:
        ModuleResult from the file system analysis module.

        Expected raw_data keys (all optional):

        'volume_info'   list[dict]  Each dict has 'label' (str) and
                                    'value' (str) for rendering as a
                                    key-value table (e.g. volume label,
                                    file system type, sector size).
        'file_stats'    dict        Keys: 'total_files' (int),
                                    'allocated' (int), 'deleted' (int),
                                    'recovered' (int).
        'notable_files' list[dict]  Each dict has 'path', 'size',
                                    'created', 'modified', 'accessed',
                                    'hash' (all str).

    Returns
    -------
    SectionContent
        Module status note, volume information, file statistics, findings
        sub-section, and notable files table.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("File System Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Volume and partition information
    volume_info: list[dict[str, str]] = result.raw_data.get("volume_info", [])
    if volume_info:
        blocks.append(_h2("Volume Information"))
        blocks.append(_kv([(item["label"], item["value"]) for item in volume_info]))
        blocks.append(_spacer())

    # File count statistics
    file_stats: dict[str, Any] = result.raw_data.get("file_stats", {})
    if file_stats:
        blocks.append(_h2("File Statistics"))
        blocks.append(_kv([
            ("Total Files Identified", str(file_stats.get("total_files", "N/A"))),
            ("Allocated Files",        str(file_stats.get("allocated",    "N/A"))),
            ("Deleted Files",          str(file_stats.get("deleted",      "N/A"))),
            ("Recovered Files",        str(file_stats.get("recovered",    "N/A"))),
        ]))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "File System Analysis", result.findings
    ))
    blocks.append(_spacer())

    # Notable files table
    notable_files: list[dict[str, str]] = result.raw_data.get("notable_files", [])
    if notable_files:
        blocks.append(_h2("Notable Files"))
        headers = ["Path", "Size", "Created", "Modified", "Accessed", "Hash"]
        rows = [
            [
                f.get("path",     ""),
                f.get("size",     ""),
                f.get("created",  ""),
                f.get("modified", ""),
                f.get("accessed", ""),
                f.get("hash",     ""),
            ]
            for f in notable_files
        ]
        blocks.append(_table(headers, rows))

    return SectionContent(
        section_number=14,
        section_title="File System Analysis",
        blocks=blocks,
    )


def build_registry_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 15: Registry Analysis.

    Presents findings from the Windows registry analysis module.  The
    registry is a primary source of evidence for user account activity,
    installed software, USB device connection history, network history,
    MRU (most recently used) lists, and persistence mechanisms.

    Parameters
    ----------
    result:
        ModuleResult from the registry analysis module.

        Expected raw_data keys (all optional):

        'hives_examined'  list[str]   Paths of registry hive files
                                      that were parsed.
        'user_accounts'   list[dict]  Keys: 'username', 'sid',
                                      'last_login' (all str).
        'run_keys'        list[dict]  Keys: 'hive', 'key_path',
                                      'value_name', 'value_data'
                                      (all str).
        'usb_devices'     list[dict]  Keys: 'device_name', 'serial',
                                      'last_connected', 'drive_letter'
                                      (all str).
        'network_history' list[dict]  Keys: 'ssid', 'interface',
                                      'last_connected' (all str).

    Returns
    -------
    SectionContent
        Module status note, hive coverage, user account table, run key
        table, USB device history, network history, and findings.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Registry Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Hives examined
    hives: list[str] = result.raw_data.get("hives_examined", [])
    if hives:
        blocks.append(_h2("Registry Hives Examined"))
        blocks.append(_bullets(hives))
        blocks.append(_spacer())

    # User accounts — the labelled SAM account table rendered in the body (not
    # only as an appendix screenshot).  Columns name the fields actually parsed:
    # the SAM key last-write time (not account creation) and the last-login
    # time; recovered deleted records carry a DELETED state.
    user_accounts: list[dict[str, str]] = result.raw_data.get("user_accounts", [])
    if user_accounts:
        blocks.append(_h2("User Accounts (SAM Hive)"))
        headers = ["Username", "RID", "Account Created",
                   "SAM Key Last-Write", "Last Login", "State"]
        rows = [
            [
                str(u.get("username", "") or ""),
                str(u.get("rid", u.get("sid", "")) or ""),
                str(u.get("creation_time", "") or "N/A")[:19],
                str(u.get("last_write", "") or "N/A")[:19],
                str(u.get("last_login", "") or "N/A")[:19],
                str(u.get("state", "") or ("DELETED" if u.get("deleted") else "ACTIVE")),
            ]
            for u in user_accounts
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Autorun / persistence keys
    run_keys: list[dict[str, str]] = result.raw_data.get("run_keys", [])
    if run_keys:
        blocks.append(_h2("Autorun / Run Keys"))
        headers = ["Hive", "Key Path", "Value Name", "Value Data"]
        rows = [
            [
                r.get("hive",       ""),
                r.get("key_path",   ""),
                r.get("value_name", ""),
                r.get("value_data", ""),
            ]
            for r in run_keys
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # USB device history
    usb_devices: list[dict[str, str]] = result.raw_data.get("usb_devices", [])
    if usb_devices:
        blocks.append(_h2("USB Device History"))
        headers = ["Device Name", "Serial Number", "Last Connected", "Drive Letter"]
        rows = [
            [
                d.get("device_name",    ""),
                d.get("serial",         ""),
                d.get("last_connected", ""),
                d.get("drive_letter",   ""),
            ]
            for d in usb_devices
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Wireless network history
    network_history: list[dict[str, str]] = result.raw_data.get("network_history", [])
    if network_history:
        blocks.append(_h2("Wireless Network History"))
        headers = ["SSID / Network Name", "Interface", "Last Connected"]
        rows = [
            [
                n.get("ssid",           ""),
                n.get("interface",      ""),
                n.get("last_connected", ""),
            ]
            for n in network_history
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Registry Analysis", result.findings
    ))

    return SectionContent(
        section_number=15,
        section_title="Registry Analysis",
        blocks=blocks,
    )


def build_browser_activity(result: ModuleResult) -> SectionContent:
    """
    Build Section 16: Browser Activity.

    Presents findings from the browser artefact analysis module, covering
    browsing history, search terms, file downloads, and saved bookmarks
    for all browsers identified on the device.

    Parameters
    ----------
    result:
        ModuleResult from the browser analysis module.

        Expected raw_data keys (all optional):

        'browsers_found'  list[str]   Browser application names found
                                      on the device.
        'history_entries' list[dict]  Keys: 'browser', 'url', 'title',
                                      'visit_count', 'last_visited'.
        'search_terms'    list[dict]  Keys: 'browser', 'term',
                                      'timestamp'.
        'downloads'       list[dict]  Keys: 'browser', 'filename',
                                      'url', 'start_time', 'saved_path'.
        'bookmarks'       list[dict]  Keys: 'browser', 'title', 'url',
                                      'date_added'.

    Returns
    -------
    SectionContent
        Module status, browser inventory, history table, search terms,
        downloads, bookmarks, and findings sub-section.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Browser Activity"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Browsers identified on the device
    browsers_found: list[str] = result.raw_data.get("browsers_found", [])
    if browsers_found:
        blocks.append(_h2("Browsers Identified"))
        blocks.append(_bullets(browsers_found))
        blocks.append(_spacer())

    # Browsing history
    history: list[dict[str, str]] = result.raw_data.get("history_entries", [])
    if history:
        blocks.append(_h2("Browsing History"))
        blocks.append(_para(
            f"{len(history)} history record(s) were identified.  Entries of "
            "direct investigative significance are documented in the findings "
            "sub-section below."
        ))
        headers = ["Browser", "URL", "Title", "Visit Count", "Last Visited"]
        rows = [
            [
                h.get("browser",     ""),
                h.get("url",         ""),
                h.get("title",       ""),
                h.get("visit_count", ""),
                h.get("last_visited",""),
            ]
            for h in history
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Search terms
    search_terms: list[dict[str, str]] = result.raw_data.get("search_terms", [])
    if search_terms:
        blocks.append(_h2("Search Terms"))
        headers = ["Browser", "Search Term", "Timestamp"]
        rows = [
            [
                t.get("browser",   ""),
                t.get("term",      ""),
                t.get("timestamp", ""),
            ]
            for t in search_terms
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Downloads
    downloads: list[dict[str, str]] = result.raw_data.get("downloads", [])
    if downloads:
        blocks.append(_h2("Downloads"))
        headers = ["Browser", "Filename", "Source URL", "Start Time", "Saved Path"]
        rows = [
            [
                d.get("browser",    ""),
                d.get("filename",   ""),
                d.get("url",        ""),
                d.get("start_time", ""),
                d.get("saved_path", ""),
            ]
            for d in downloads
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Bookmarks
    bookmarks: list[dict[str, str]] = result.raw_data.get("bookmarks", [])
    if bookmarks:
        blocks.append(_h2("Bookmarks"))
        headers = ["Browser", "Title", "URL", "Date Added"]
        rows = [
            [
                b.get("browser",    ""),
                b.get("title",      ""),
                b.get("url",        ""),
                b.get("date_added", ""),
            ]
            for b in bookmarks
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Browser Activity", result.findings
    ))

    return SectionContent(
        section_number=16,
        section_title="Browser Activity",
        blocks=blocks,
    )


def build_email_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 17: Email Analysis.

    Presents findings from the email artefact analysis module, covering
    email client applications, configured accounts, message volume
    statistics, notable messages, and attachment inventory.

    Parameters
    ----------
    result:
        ModuleResult from the email analysis module.

        Expected raw_data keys (all optional):

        'email_clients'    list[str]   Email client application names.
        'accounts'         list[dict]  Keys: 'client', 'email_address',
                                       'display_name', 'server'.
        'message_stats'    dict        Keys: 'total_messages', 'sent',
                                       'received', 'deleted', 'unread'
                                       (all int).
        'notable_messages' list[dict]  Keys: 'direction', 'from_addr',
                                       'to_addr', 'subject', 'date',
                                       'has_attachment' (bool),
                                       'attachment_names' (list[str]).
        'attachments'      list[dict]  Keys: 'filename', 'size',
                                       'content_type', 'email_date',
                                       'hash'.

    Returns
    -------
    SectionContent
        Module status, client inventory, account table, message
        statistics, notable messages, attachment inventory, and findings.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Email Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Email client applications
    email_clients: list[str] = result.raw_data.get("email_clients", [])
    if email_clients:
        blocks.append(_h2("Email Clients Identified"))
        blocks.append(_bullets(email_clients))
        blocks.append(_spacer())

    # Configured account table
    accounts: list[dict[str, str]] = result.raw_data.get("accounts", [])
    if accounts:
        blocks.append(_h2("Email Accounts"))
        headers = ["Client", "Email Address", "Display Name", "Server"]
        rows = [
            [
                a.get("client",        ""),
                a.get("email_address", ""),
                a.get("display_name",  ""),
                a.get("server",        ""),
            ]
            for a in accounts
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Message volume statistics
    msg_stats: dict[str, Any] = result.raw_data.get("message_stats", {})
    if msg_stats:
        blocks.append(_h2("Message Statistics"))
        blocks.append(_kv([
            ("Total Messages",   str(msg_stats.get("total_messages", "N/A"))),
            ("Sent",             str(msg_stats.get("sent",           "N/A"))),
            ("Received",         str(msg_stats.get("received",       "N/A"))),
            ("Deleted / Purged", str(msg_stats.get("deleted",        "N/A"))),
            ("Unread",           str(msg_stats.get("unread",         "N/A"))),
        ]))
        blocks.append(_spacer())

    # Notable messages (significant to the investigation)
    notable: list[dict[str, Any]] = result.raw_data.get("notable_messages", [])
    if notable:
        blocks.append(_h2("Notable Messages"))
        headers = [
            "Direction", "From", "To", "Subject",
            "Date", "Has Attachment", "Attachments",
        ]
        rows = [
            [
                m.get("direction",        ""),
                m.get("from_addr",        ""),
                m.get("to_addr",          ""),
                m.get("subject",          ""),
                m.get("date",             ""),
                "Yes" if m.get("has_attachment") else "No",
                ", ".join(m.get("attachment_names", [])),
            ]
            for m in notable
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Attachment inventory
    attachments: list[dict[str, str]] = result.raw_data.get("attachments", [])
    if attachments:
        blocks.append(_h2("Attachments Inventory"))
        headers = ["Filename", "Size", "Content Type", "Email Date", "SHA-256"]
        rows = [
            [
                a.get("filename",     ""),
                a.get("size",         ""),
                a.get("content_type", ""),
                a.get("email_date",   ""),
                a.get("hash",         ""),
            ]
            for a in attachments
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Email Analysis", result.findings
    ))

    return SectionContent(
        section_number=17,
        section_title="Email Analysis",
        blocks=blocks,
    )


def build_communication_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 18: Communication Analysis.

    Covers instant messaging, SMS, social media applications, and other
    communication artefacts beyond email.  Includes application inventory,
    account details, message volume, significant contacts, and notable
    individual messages.

    Parameters
    ----------
    result:
        ModuleResult from the communications analysis module.

        Expected raw_data keys (all optional):

        'apps_found'       list[str]   Messaging application names found
                                       on the device.
        'accounts'         list[dict]  Keys: 'app', 'username',
                                       'account_id', 'registration_date'.
        'message_stats'    dict        Keys: 'total_messages', 'sent',
                                       'received', 'deleted' (all int).
        'contacts'         list[dict]  Keys: 'app', 'display_name',
                                       'identifier', 'message_count'.
        'notable_messages' list[dict]  Keys: 'app', 'direction',
                                       'from_id', 'to_id', 'content'
                                       (str), 'timestamp', 'has_media'
                                       (bool).

    Returns
    -------
    SectionContent
        Module status, application inventory, account details, message
        volume, contact summary, notable messages, and findings.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Communication Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Messaging applications found on the device
    apps: list[str] = result.raw_data.get("apps_found", [])
    if apps:
        blocks.append(_h2("Messaging Applications Identified"))
        blocks.append(_bullets(apps))
        blocks.append(_spacer())

    # Application accounts
    accounts: list[dict[str, str]] = result.raw_data.get("accounts", [])
    if accounts:
        blocks.append(_h2("Application Accounts"))
        headers = ["Application", "Username / Handle", "Account ID", "Registered"]
        rows = [
            [
                a.get("app",               ""),
                a.get("username",          ""),
                a.get("account_id",        ""),
                a.get("registration_date", ""),
            ]
            for a in accounts
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Message volume statistics
    msg_stats: dict[str, Any] = result.raw_data.get("message_stats", {})
    if msg_stats:
        blocks.append(_h2("Message Volume"))
        blocks.append(_kv([
            ("Total Messages", str(msg_stats.get("total_messages", "N/A"))),
            ("Sent",           str(msg_stats.get("sent",           "N/A"))),
            ("Received",       str(msg_stats.get("received",       "N/A"))),
            ("Deleted",        str(msg_stats.get("deleted",        "N/A"))),
        ]))
        blocks.append(_spacer())

    # Top contacts by message volume
    contacts: list[dict[str, str]] = result.raw_data.get("contacts", [])
    if contacts:
        blocks.append(_h2("Contact Summary"))
        headers = ["Application", "Display Name", "Identifier", "Message Count"]
        rows = [
            [
                c.get("app",           ""),
                c.get("display_name",  ""),
                c.get("identifier",    ""),
                c.get("message_count", ""),
            ]
            for c in contacts
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Notable individual messages
    notable: list[dict[str, Any]] = result.raw_data.get("notable_messages", [])
    if notable:
        blocks.append(_h2("Notable Messages"))
        headers = [
            "Application", "Direction", "From", "To",
            "Content (Excerpt)", "Timestamp", "Media",
        ]
        rows = [
            [
                m.get("app",       ""),
                m.get("direction", ""),
                m.get("from_id",   ""),
                m.get("to_id",     ""),
                # Truncate the content to 120 chars to keep the table readable
                str(m.get("content", ""))[:120],
                m.get("timestamp", ""),
                "Yes" if m.get("has_media") else "No",
            ]
            for m in notable
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Communication Analysis", result.findings
    ))

    return SectionContent(
        section_number=18,
        section_title="Communication Analysis",
        blocks=blocks,
    )


def build_network_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 19: Network Analysis.

    Presents findings from network artefact analysis, covering network
    interface configuration, DNS cache entries, recorded connections,
    firewall rules, and any hosts or IP addresses flagged as suspicious
    through threat intelligence correlation.

    Parameters
    ----------
    result:
        ModuleResult from the network analysis module.

        Expected raw_data keys (all optional):

        'interfaces'       list[dict]  Keys: 'name', 'mac', 'ip',
                                       'subnet', 'gateway'.
        'dns_cache'        list[dict]  Keys: 'hostname', 'resolved_ip',
                                       'ttl', 'timestamp'.
        'connections'      list[dict]  Keys: 'protocol', 'local_address',
                                       'remote_address', 'state',
                                       'process', 'pid'.
        'firewall_rules'   list[dict]  Keys: 'direction', 'action',
                                       'protocol', 'port', 'description'.
        'suspicious_hosts' list[str]   Suspicious hostnames or IP
                                       addresses identified via threat
                                       intelligence.

    Returns
    -------
    SectionContent
        Module status, interface details, DNS cache, connections table,
        firewall rules, suspicious hosts, and findings.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Network Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Network interfaces
    interfaces: list[dict[str, str]] = result.raw_data.get("interfaces", [])
    if interfaces:
        blocks.append(_h2("Network Interfaces"))
        headers = [
            "Interface", "MAC Address", "IP Address",
            "Subnet", "Default Gateway",
        ]
        rows = [
            [
                i.get("name",    ""),
                i.get("mac",     ""),
                i.get("ip",      ""),
                i.get("subnet",  ""),
                i.get("gateway", ""),
            ]
            for i in interfaces
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # DNS cache entries
    dns_cache: list[dict[str, str]] = result.raw_data.get("dns_cache", [])
    if dns_cache:
        blocks.append(_h2("DNS Cache Entries"))
        blocks.append(_para(
            f"{len(dns_cache)} DNS cache record(s) were identified.  Entries "
            "of investigative significance are documented in the findings "
            "sub-section below."
        ))
        headers = ["Hostname", "Resolved IP", "TTL", "Timestamp"]
        rows = [
            [
                d.get("hostname",    ""),
                d.get("resolved_ip", ""),
                d.get("ttl",         ""),
                d.get("timestamp",   ""),
            ]
            for d in dns_cache
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Recorded network connections
    connections: list[dict[str, str]] = result.raw_data.get("connections", [])
    if connections:
        blocks.append(_h2("Network Connections"))
        headers = [
            "Protocol", "Local Address", "Remote Address",
            "State", "Process", "PID",
        ]
        rows = [
            [
                c.get("protocol",       ""),
                c.get("local_address",  ""),
                c.get("remote_address", ""),
                c.get("state",          ""),
                c.get("process",        ""),
                c.get("pid",            ""),
            ]
            for c in connections
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Relevant firewall rules
    firewall_rules: list[dict[str, str]] = result.raw_data.get("firewall_rules", [])
    if firewall_rules:
        blocks.append(_h2("Firewall Rules (Relevant)"))
        headers = ["Direction", "Action", "Protocol", "Port", "Description"]
        rows = [
            [
                r.get("direction",   ""),
                r.get("action",      ""),
                r.get("protocol",    ""),
                r.get("port",        ""),
                r.get("description", ""),
            ]
            for r in firewall_rules
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Suspicious hosts / IPs flagged by threat intelligence
    suspicious_hosts: list[str] = result.raw_data.get("suspicious_hosts", [])
    if suspicious_hosts:
        blocks.append(_h2("Suspicious Hosts / IP Addresses"))
        blocks.append(_para(
            "The following hosts or IP addresses were flagged as potentially "
            "malicious based on threat intelligence correlation:"
        ))
        blocks.append(_bullets(suspicious_hosts))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Network Analysis", result.findings
    ))

    return SectionContent(
        section_number=19,
        section_title="Network Analysis",
        blocks=blocks,
    )


def build_memory_analysis(result: ModuleResult) -> SectionContent:
    """
    Build Section 20: Memory Analysis.

    Presents findings from volatile memory (RAM) analysis.  Memory
    analysis can reveal running processes not visible to the file system,
    loaded kernel modules, active network connections at the time of
    capture, injected or anomalous memory regions, and plaintext strings
    (including passwords, URLs, and command-line arguments) that would
    not survive a shutdown.

    Parameters
    ----------
    result:
        ModuleResult from the memory analysis module.

        Expected raw_data keys (all optional):

        'capture_info'        dict        Keys: 'capture_time' (str),
                                          'system' (str), 'architecture'
                                          (str), 'total_ram_bytes' (int),
                                          'capture_tool' (str),
                                          'capture_tool_version' (str).
        'processes'           list[dict]  Keys: 'pid', 'ppid', 'name',
                                          'path', 'start_time', 'cmdline',
                                          'user', 'suspicious' (bool).
        'loaded_modules'      list[dict]  Keys: 'pid', 'process_name',
                                          'module_name', 'base_address',
                                          'size'.
        'network_connections' list[dict]  Keys: 'pid', 'process',
                                          'protocol', 'local_addr',
                                          'foreign_addr', 'state'.
        'injected_regions'    list[dict]  Keys: 'pid', 'process',
                                          'address', 'size', 'protection',
                                          'description'.
        'strings_of_interest' list[str]   Notable strings extracted from
                                          the memory image.

    Returns
    -------
    SectionContent
        Module status, capture metadata, process list, injected regions,
        network connections at capture time, strings of interest, and
        findings sub-section.
    """
    blocks: list[ContentBlock] = []

    blocks.append(_h1("Memory Analysis"))
    blocks.append(_spacer())
    blocks.append(_module_status_note(result))
    blocks.append(_spacer())

    # Memory capture metadata
    capture_info: dict[str, Any] = result.raw_data.get("capture_info", {})
    if capture_info:
        blocks.append(_h2("Memory Capture Information"))
        blocks.append(_kv([
            ("Capture Time",          capture_info.get("capture_time",         "N/A")),
            ("System",                capture_info.get("system",               "N/A")),
            ("Architecture",          capture_info.get("architecture",         "N/A")),
            (
                "Total RAM",
                _bytes_to_human(int(capture_info.get("total_ram_bytes", 0))),
            ),
            ("Capture Tool",          capture_info.get("capture_tool",         "N/A")),
            ("Capture Tool Version",  capture_info.get("capture_tool_version", "N/A")),
        ]))
        blocks.append(_spacer())

    # Process list
    processes: list[dict[str, Any]] = result.raw_data.get("processes", [])
    if processes:
        blocks.append(_h2("Process List"))
        blocks.append(_para(
            f"{len(processes)} process(es) were identified in the memory "
            "image.  Processes flagged as suspicious are documented in the "
            "findings sub-section."
        ))
        headers = ["PID", "PPID", "Name", "User", "Start Time", "Command Line"]
        rows = [
            [
                str(p.get("pid",        "")),
                str(p.get("ppid",       "")),
                p.get("name",           ""),
                p.get("user",           ""),
                p.get("start_time",     ""),
                p.get("cmdline",        ""),
            ]
            for p in processes
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Injected / anomalous memory regions
    injected: list[dict[str, Any]] = result.raw_data.get("injected_regions", [])
    if injected:
        blocks.append(_h2("Injected / Anomalous Memory Regions"))
        blocks.append(_para(
            "The following memory regions were identified as potentially "
            "injected or anomalous based on protection flags and content "
            "analysis.  These regions warrant detailed examination for "
            "malicious code."
        ))
        headers = [
            "PID", "Process", "Base Address",
            "Size", "Protection", "Description",
        ]
        rows = [
            [
                str(r.get("pid",         "")),
                r.get("process",         ""),
                r.get("address",         ""),
                r.get("size",            ""),
                r.get("protection",      ""),
                r.get("description",     ""),
            ]
            for r in injected
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Network connections present at time of capture
    mem_connections: list[dict[str, str]] = result.raw_data.get(
        "network_connections", []
    )
    if mem_connections:
        blocks.append(_h2("Network Connections at Time of Capture"))
        headers = [
            "PID", "Process", "Protocol",
            "Local Address", "Foreign Address", "State",
        ]
        rows = [
            [
                str(c.get("pid",          "")),
                c.get("process",          ""),
                c.get("protocol",         ""),
                c.get("local_addr",       ""),
                c.get("foreign_addr",     ""),
                c.get("state",            ""),
            ]
            for c in mem_connections
        ]
        blocks.append(_table(headers, rows))
        blocks.append(_spacer())

    # Strings of investigative interest extracted from the image
    strings_of_interest: list[str] = result.raw_data.get("strings_of_interest", [])
    if strings_of_interest:
        blocks.append(_h2("Strings of Interest"))
        blocks.append(_para(
            "The following strings were extracted from the memory image and "
            "are considered relevant to the investigation:"
        ))
        blocks.append(_bullets(strings_of_interest))
        blocks.append(_spacer())

    # Normalised findings
    blocks.extend(_build_findings_subsection(
        "Memory Analysis", result.findings
    ))

    return SectionContent(
        section_number=20,
        section_title="Memory Analysis",
        blocks=blocks,
    )


_STANDARD_REFERENCES = [
    "Kent, K. et al. (2006). NIST SP 800-86 — Guide to Integrating Forensic Techniques into Incident Response. NIST.",
    "ACPO (2012). Good Practice Guide for Digital Evidence v5. ACPO.",
    "NPCC (2015). Good Practice Guide for Digital Forensics. NPCC.",
    "Casey, E. (2011). Digital Evidence and Computer Crime (3rd ed.). Academic Press.",
    "Carrier, B. (2005). File System Forensic Analysis. Addison-Wesley.",
    "Luttgens, J. et al. (2014). Incident Response & Computer Forensics (3rd ed.). McGraw-Hill.",
    "Computer Misuse Act 1990 (c.18). Her Majesty's Stationery Office.",
    "Fraud Act 2006 (c.35). Her Majesty's Stationery Office.",
    "Forgery and Counterfeiting Act 1981 (c.45). Her Majesty's Stationery Office.",
    "Regulation of Investigatory Powers Act 2000 (c.23) (RIPA). HMSO.",
    "Police and Criminal Evidence Act 1984 (c.60) (PACE). HMSO.",
    "18 U.S. Code §1028 — Fraud and related activity in connection with identification documents. US Code.",
    "NISPOM Federal Register (2020). National Industrial Security Program. US Government.",
]


def _detected_tool_citations(tool_versions: Optional[dict]) -> list[str]:
    """Build tool-version reference citations from the runtime metadata map.

    Uses the exact same detection filter as §2.4 (the cover / tools table) so
    the References section and §2.4 agree on which tools were present and at what
    version.  Only tools actually detected at runtime are cited; no static
    version string is ever emitted.  Returns an empty list when nothing was
    detected.
    """
    if not tool_versions:
        return []
    citations: list[str] = []
    for name, ver in sorted(tool_versions.items()):
        if ver and str(ver).lower() not in ("", "unknown", "not installed", "not found"):
            citations.append(
                f"{name} {ver} — tool detected in the runtime environment. "
                "The relevant module record states whether the tool was invoked."
            )
    return citations


def build_references_section(
    extra_refs: Optional[list[str]] = None,
    tool_versions: Optional[dict] = None,
) -> SectionContent:
    """Build Section 9 — References from the standard reference list plus any extras.

    Tool-version citations are NOT static.  When tool_versions is supplied (the
    runtime metadata map produced by populate_tool_versions() and consumed by
    §2.4), each tool actually detected at runtime is cited with its detected
    version.  Undetected tools are omitted entirely — the report never claims a
    tool/version it did not observe.
    """
    blocks: list[ContentBlock] = []
    blocks.append(_h1("Section 9 — References"))
    blocks.append(_spacer())
    refs = list(_STANDARD_REFERENCES)
    if extra_refs:
        seen = set(refs)
        for r in extra_refs:
            if r not in seen:
                refs.append(r)
                seen.add(r)
    # Tool citations are driven from the same runtime map §2.4 uses — only tools
    # detected at runtime are cited, and never with a hardcoded version.
    for citation in _detected_tool_citations(tool_versions):
        if citation not in refs:
            refs.append(citation)
    blocks.append(ContentBlock("numbered_list", {"items": refs}))

    return SectionContent(section_number=9, section_title="References", blocks=blocks)


def _get_module_section_builders() -> list:
    """
    Return the list of per-module section builder functions defined in this
    module.  Currently returns an empty list because the existing builders
    (build_file_system_analysis, build_registry_analysis, etc.) each accept a
    single ModuleResult object rather than a generic list, so they cannot be
    called generically here.  The heading produced by build_evidence_section is
    still valuable as a structural marker in the report.
    """
    return []


def build_evidence_section(
    section_number: int,
    evidence_path: str,
    evidence_index: int,
    module_results: list,
    case_config=None,
) -> list:
    """Build one full analysis section for a single evidence image."""
    from pathlib import Path as _P
    ev_label = _P(evidence_path).name if evidence_path else f"Evidence {evidence_index + 1}"
    blocks: list[ContentBlock] = []

    # Section heading
    try:
        heading_block = _h1(f"SECTION {section_number} — ANALYSIS: {ev_label}")
        blocks.append(heading_block)
    except Exception:
        pass

    # After the heading block, add a narrative paragraph per module
    from core.report_templates import render_module_narrative
    module_names = {
        getattr(r, "module_name", "") if not isinstance(r, dict)
        else (r.get("module_name") or r.get("module") or "")
        for r in (module_results or [])
    }
    for mod_name in sorted(module_names):
        if not mod_name:
            continue
        mod_findings: list[dict] = []
        for r in (module_results or []):
            if isinstance(r, dict):
                r_name = r.get("module_name") or r.get("module") or ""
                if r_name == mod_name:
                    mod_findings.extend(r.get("findings", []))
            else:
                if getattr(r, "module_name", "") == mod_name:
                    raw_findings = getattr(r, "findings", [])
                    for f in raw_findings:
                        if isinstance(f, dict):
                            mod_findings.append(f)
                        else:
                            mod_findings.append({
                                "finding_type": getattr(f, "finding_type", ""),
                                "finding_id":   getattr(f, "finding_id", ""),
                                "title":        getattr(f, "title", ""),
                                "description":  getattr(f, "description", ""),
                                "severity":     getattr(f, "severity", "Info"),
                                "metadata":     getattr(f, "metadata", {}),
                            })
        narrative = render_module_narrative(mod_name, mod_findings)
        try:
            blocks.append(_para(narrative))
        except Exception:
            pass

    # Delegate to per-module section builders, filtered to this evidence's results
    for builder in _get_module_section_builders():
        try:
            section_blocks = builder(module_results, case_config)
            if section_blocks:
                blocks.extend(section_blocks if isinstance(section_blocks, list) else [section_blocks])
        except Exception as exc:
            try:
                err_block = _para(f"[Section builder {getattr(builder, '__name__', '?')} raised: {exc}]")
                blocks.append(err_block)
            except Exception:
                pass

    return blocks


# ===========================================================================
# Recommendations section — findings-driven, no hardcoded case text
# ===========================================================================

_RECOMMENDATION_RULES: list = [
    ("EXTENSION_MISMATCH",    "Validate the underlying header and file structure for {title}; record whether the object is functional content, a decoy, or a container with a misleading name.", "Medium"),
    ("PROTECTED_DOCUMENT",    "Attempt further password recovery on {title}; if uncracked, seek legal authority for disclosure.", "High"),
    ("ANTI_FORENSIC_TOOL",    "Investigate use of {title}; determine scope of potential data wiping.", "High"),
    ("USB_DEVICE",            "Trace USB device {title} to physical media; examine for exfiltrated data.", "Medium"),
    ("BITCOIN_ADDRESS",       "Initiate financial intelligence enquiry for Bitcoin address {title}.", "Medium"),
    ("EMAIL_PARTICIPANT",     "Obtain ISP/service-provider records for email address {title}.", "Medium"),
    ("DELETED_FILE",          "Recover and examine deleted file {title} for evidentiary content.", "Medium"),
    ("MALWARE_DETECTED",      "Submit {title} for further malware analysis; determine execution history.", "High"),
    ("ALTERNATE_DATA_STREAM", "Examine ADS {title} for hidden data exfiltration or persistence mechanism.", "Medium"),
]


def build_section_recommendations(all_findings, api_log=None, **kwargs) -> SectionContent:
    """
    Build the Recommendations section driven purely by finding types.

    Each recommendation is derived from a matching _RECOMMENDATION_RULES entry;
    no hardcoded case-specific text is included. Results are de-duplicated and
    sorted High -> Medium -> Low.

    Parameters
    ----------
    all_findings:
        List of finding dicts (keys: finding_type, title, finding_id).
    api_log:
        Unused; accepted for interface compatibility.
    **kwargs:
        Absorbed for forward compatibility.

    Returns
    -------
    SectionContent
        Section containing a heading, introductory paragraph, and a
        recommendations table.
    """
    blocks: list[ContentBlock] = []
    blocks.append(_h1("RECOMMENDATIONS"))
    blocks.append(_spacer())

    recs: list[tuple[str, str, str]] = []
    for f in (all_findings or []):
        ftype = f.get("finding_type", "")
        title = f.get("title", "")[:80]
        fid   = f.get("finding_id", "")
        for type_substr, tmpl, priority in _RECOMMENDATION_RULES:
            if type_substr in ftype:
                recs.append((priority, tmpl.format(title=title), fid))

    # Deduplicate and sort High -> Medium -> Low
    seen: set[str] = set()
    rows: list[list[str]] = []
    priority_order = {"High": 0, "Medium": 1, "Low": 2}
    for priority, text, fid in sorted(recs, key=lambda x: priority_order.get(x[0], 3)):
        key = text[:60]
        if key not in seen:
            seen.add(key)
            rows.append([priority, text, fid])

    if rows:
        blocks.append(_para(
            f"{len(rows)} recommendation(s) have been identified based on the "
            "findings of this examination. Each recommendation is linked to the "
            "finding that generated it."
        ))
        blocks.append(_spacer(4))
        blocks.append(_table(["Priority", "Recommendation", "Finding Ref"], rows))
    else:
        blocks.append(_para(
            "No specific recommendations were generated from the findings of "
            "this examination."
        ))

    return SectionContent(
        section_number=0,
        section_title="Recommendations",
        blocks=blocks,
    )
