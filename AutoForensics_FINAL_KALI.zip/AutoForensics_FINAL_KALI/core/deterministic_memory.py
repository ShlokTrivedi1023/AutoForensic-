"""Deterministic fallback parsing for marker-oriented memory corpora.

This parser is deliberately conservative. It recognises explicit structured
records embedded in a byte stream and reports only that those records exist.
It never converts marker strings into genuine operating-system process, socket,
malware, or rootkit semantics.
"""
from __future__ import annotations

import hashlib
import ipaddress
import mmap
import re
from pathlib import Path
from typing import Any, Iterable

_PROCESS_RE = re.compile(
    r"^PROCESS\s+pid=(?P<pid>\d+)\s+ppid=(?P<ppid>\d+)\s+name=(?P<name>[^\s]+)\s+state=(?P<state>[^\r\n]+)$",
    re.IGNORECASE,
)
_NET_RE = re.compile(
    r"^NETCONN\s+pid=(?P<pid>\d+)\s+(?P<protocol>TCP|UDP)\s+"
    r"(?P<src_ip>[0-9a-fA-F:.]+):(?P<src_port>\d+)\s+"
    r"(?P<dst_ip>[0-9a-fA-F:.]+):(?P<dst_port>\d+)"
    r"(?:\s+(?P<state>[^\r\n]+))?$",
    re.IGNORECASE,
)
_HIDDEN_RE = re.compile(
    r"^HIDDEN_PROCESS_CANDIDATE\s+pid=(?P<pid>\d+)\s+name=(?P<name>[^\s]+)\s+"
    r"list_state=(?P<list_state>[^\s]+)\s+scan_state=(?P<scan_state>[^\s]+)$",
    re.IGNORECASE,
)
_ROOTKIT_RE = re.compile(r"^ROOTKIT_TEST_MARKER=(?P<value>[^\r\n]+)$", re.IGNORECASE)
_DNS_RE = re.compile(r"^DNS\s+(?P<domain>[^\s]+)\s+(?P<rtype>[A-Z0-9]+)\s+(?P<answer>[^\s]+)$", re.IGNORECASE)
_URL_RE = re.compile(r"^URL\s+(?P<url>https?://[^\s]+)$", re.IGNORECASE)
_EMAIL_RE = re.compile(r"^EMAIL\s+(?P<email>[^\s]+@[^\s]+)$", re.IGNORECASE)
_CRED_RE = re.compile(r"^CREDENTIAL\s+username=(?P<username>[^\s]+)\s+password=(?P<password>[^\s]+)$", re.IGNORECASE)
_API_RE = re.compile(r"^API_KEY\s+(?P<value>[^\s]+)$", re.IGNORECASE)
_KEYWORD_RE = re.compile(r"^KEYWORD\s+(?P<value>.+)$", re.IGNORECASE)
_MALWARE_TEST_RE = re.compile(r"^MALWARE_TEST=(?P<value>.+)$", re.IGNORECASE)

# A line must look intentionally structured; random printable strings are not
# elevated into marker records.
_PREFIXES = (
    "PROCESS ", "NETCONN ", "HIDDEN_PROCESS_CANDIDATE ", "ROOTKIT_TEST_MARKER=",
    "DNS ", "URL ", "EMAIL ", "CREDENTIAL ", "API_KEY ", "KEYWORD ",
    "MALWARE_TEST=", "KDBG ", "AF_", "SYNTHETIC_", "Microsoft Windows ",
    "Linux version ",
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _ascii_strings_with_offsets(data: bytes, min_len: int = 8) -> list[tuple[int, str, str]]:
    out: list[tuple[int, str, str]] = []
    for match in re.finditer(rb"[\x20-\x7e\t]{%d,}" % min_len, data):
        text = match.group(0).decode("ascii", errors="strict").strip()
        if text:
            out.append((match.start(), text, "ascii"))
    return out


def _utf16le_strings_with_offsets(data: bytes, min_chars: int = 8) -> list[tuple[int, str, str]]:
    # Exact alternating printable-byte/NUL sequences.
    pat = re.compile(rb"(?:[\x20-\x7e]\x00){%d,}" % min_chars)
    out: list[tuple[int, str, str]] = []
    for match in pat.finditer(data):
        text = match.group(0).decode("utf-16le", errors="strict").strip()
        if text:
            out.append((match.start(), text, "utf-16-le"))
    return out


def extract_structured_memory_markers(path: Path, *, max_bytes: int = 0) -> dict[str, Any]:
    """Parse exact marker grammar from a memory-like byte stream.

    The complete source is scanned by default using a read-only memory map so
    large memory images do not need to be copied into RAM. ``max_bytes > 0`` is
    an explicit caller safety cap and is recorded as incomplete coverage when
    it truncates the source.
    """
    try:
        size = path.stat().st_size
        scan_bytes = min(size, max_bytes) if max_bytes > 0 else size
        strings: list[tuple[int, str, str]] = []
        if size > 0 and scan_bytes > 0:
            with path.open("rb") as fh:
                with mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                    ascii_pat = re.compile(rb"[\x20-\x7e\t]{8,}")
                    utf16_pat = re.compile(rb"(?:[\x20-\x7e]\x00){8,}")
                    for match in ascii_pat.finditer(mm, 0, scan_bytes):
                        text = match.group(0).decode("ascii", errors="strict").strip()
                        if text:
                            strings.append((match.start(), text, "ascii"))
                    # A UTF-16LE match may legally start at either byte parity;
                    # the explicit byte pattern is independent of global alignment.
                    for match in utf16_pat.finditer(mm, 0, scan_bytes):
                        text = match.group(0).decode("utf-16le", errors="strict").strip()
                        if text:
                            strings.append((match.start(), text, "utf-16-le"))
        scan_limit_reached = bool(max_bytes > 0 and scan_bytes < size)
    except (OSError, ValueError) as exc:
        return {"path": str(path), "error": str(exc), "records": [], "coverage_complete": False}

    # One semantic marker record may occur in several encodings/wrappers.  Keep
    # every physical occurrence while counting the semantic record once.
    records_by_semantic_key: dict[str, dict[str, Any]] = {}
    structured_lines: list[str] = []

    for offset, raw_text, encoding in sorted(strings, key=lambda item: (item[0], item[1], item[2])):
        # A strings run can contain line breaks only when extracted externally;
        # our exact byte regex does not. Still split defensively.
        for line in raw_text.splitlines():
            line = line.strip()
            if not line or not line.startswith(_PREFIXES):
                continue
            rec: dict[str, Any] | None = None
            match = _PROCESS_RE.fullmatch(line)
            if match:
                rec = {"record_type": "process_marker", **match.groupdict()}
                rec["pid"] = int(rec["pid"]); rec["ppid"] = int(rec["ppid"])
            else:
                match = _NET_RE.fullmatch(line)
                if match:
                    gd = match.groupdict()
                    try:
                        gd["src_ip"] = str(ipaddress.ip_address(gd["src_ip"]))
                        gd["dst_ip"] = str(ipaddress.ip_address(gd["dst_ip"]))
                    except ValueError:
                        continue
                    rec = {"record_type": "network_marker", **gd}
                    rec["pid"] = int(rec["pid"]); rec["src_port"] = int(rec["src_port"]); rec["dst_port"] = int(rec["dst_port"])
                else:
                    match = _HIDDEN_RE.fullmatch(line)
                    if match:
                        rec = {"record_type": "hidden_process_marker", **match.groupdict()}
                        rec["pid"] = int(rec["pid"])
                    else:
                        match = _ROOTKIT_RE.fullmatch(line)
                        if match:
                            rec = {"record_type": "rootkit_marker", **match.groupdict()}
                        else:
                            match = _DNS_RE.fullmatch(line)
                            if match:
                                rec = {"record_type": "dns_marker", **match.groupdict()}
                            else:
                                match = _URL_RE.fullmatch(line)
                                if match:
                                    rec = {"record_type": "url_marker", **match.groupdict()}
                                else:
                                    match = _EMAIL_RE.fullmatch(line)
                                    if match:
                                        rec = {"record_type": "email_marker", **match.groupdict()}
                                    else:
                                        match = _CRED_RE.fullmatch(line)
                                        if match:
                                            rec = {"record_type": "credential_marker", **match.groupdict()}
                                        else:
                                            match = _API_RE.fullmatch(line)
                                            if match:
                                                rec = {"record_type": "api_key_marker", **match.groupdict()}
                                            else:
                                                match = _KEYWORD_RE.fullmatch(line)
                                                if match:
                                                    rec = {"record_type": "keyword_marker", **match.groupdict()}
                                                else:
                                                    match = _MALWARE_TEST_RE.fullmatch(line)
                                                    if match:
                                                        rec = {"record_type": "malware_test_marker", **match.groupdict()}
                                                    elif line.startswith("KDBG "):
                                                        rec = {"record_type": "kernel_debugger_marker", "value": line[5:]}
                                                    elif line.startswith(("AF_", "SYNTHETIC_")):
                                                        rec = {"record_type": "validation_marker", "value": line}
                                                    elif line.startswith(("Microsoft Windows ", "Linux version ")):
                                                        rec = {"record_type": "os_banner_marker", "value": line}
            if rec is None:
                continue
            occurrence = {
                "source_file": str(path),
                "byte_offset": offset,
                "byte_length": len(line.encode(encoding, errors="replace")),
                "encoding": encoding,
                "raw_text": line,
            }
            semantic_payload = {k: v for k, v in rec.items() if k not in {"source_file", "byte_offset", "byte_length", "raw_text", "encoding"}}
            semantic_key = hashlib.sha256(
                repr(sorted(semantic_payload.items())).encode("utf-8", errors="replace")
            ).hexdigest()
            existing = records_by_semantic_key.get(semantic_key)
            if existing is None:
                rec.update({
                    "semantic_record_id": f"mem-{semantic_key[:24]}",
                    "source_file": str(path),
                    "byte_offset": offset,
                    "byte_length": occurrence["byte_length"],
                    "raw_text": line,
                    "encoding": encoding,
                    "physical_occurrences": [occurrence],
                    "physical_occurrence_count": 1,
                    "encodings": [encoding],
                })
                records_by_semantic_key[semantic_key] = rec
            else:
                occurrences = existing.setdefault("physical_occurrences", [])
                occurrence_key = (str(path), offset, encoding)
                if occurrence_key not in {
                    (str(item.get("source_file")), int(item.get("byte_offset") or 0), str(item.get("encoding") or ""))
                    for item in occurrences
                }:
                    occurrences.append(occurrence)
                existing["physical_occurrence_count"] = len(occurrences)
                existing["encodings"] = sorted({str(item.get("encoding") or "") for item in occurrences})
            structured_lines.append(line)

    records = list(records_by_semantic_key.values())
    normalised = "\n".join(sorted(set(structured_lines))).encode("utf-8")
    return {
        "path": str(path),
        "size_bytes": size,
        "file_sha256": sha256_file(path),
        "records": records,
        "record_count": len(records),
        "record_types": sorted({r["record_type"] for r in records}),
        "marker_fingerprint": hashlib.sha256(normalised).hexdigest() if normalised else "",
        "bytes_scanned": scan_bytes,
        "scan_limit_configured": max_bytes,
        "scan_limit_reached": scan_limit_reached,
        "coverage_complete": not scan_limit_reached,
        "semantic_limit": "Structured marker presence only; no operating-system object provenance is established.",
    }


def canonical_marker_sources(paths: Iterable[Path]) -> list[dict[str, Any]]:
    """Return one canonical source per exact normalised marker set."""
    groups: dict[str, dict[str, Any]] = {}
    for path in paths:
        parsed = extract_structured_memory_markers(Path(path))
        fingerprint = str(parsed.get("marker_fingerprint") or "")
        if not fingerprint:
            continue
        if fingerprint not in groups:
            parsed["aliases"] = []
            groups[fingerprint] = parsed
        else:
            groups[fingerprint].setdefault("aliases", []).append({
                "path": str(path),
                "file_sha256": parsed.get("file_sha256"),
                "size_bytes": parsed.get("size_bytes"),
            })
    return list(groups.values())
