"""Privacy gate for language-model narrative synthesis.

Raw evidence is never transmitted by AutoForensics.  This module additionally
prevents structured, case-derived summaries from being sent to a cloud provider
unless the case configuration contains an explicit, auditable opt-in.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class AIPolicyError(RuntimeError):
    """Raised when the configured LLM provider violates the case privacy policy."""


_CLOUD = {"openai"}
_LOCAL = {"none", "deterministic"}


def configured_provider() -> str:
    """Choose cloud synthesis only when explicitly configured or credentialled.

    A report-only run without a cloud credential must remain deterministic by
    default rather than failing a privacy gate for a provider that cannot run.
    """
    explicit = os.environ.get("LLM_PROVIDER")
    if explicit is not None and explicit.strip():
        return explicit.strip().lower()
    return "openai" if os.environ.get("OPENAI_API_KEY", "").strip() else "deterministic"


def enforce_ai_policy(case_config: Any, *, require_llm: bool = False) -> dict[str, Any]:
    provider = configured_provider()
    policy = getattr(case_config, "ai_policy", None) if case_config is not None else None
    mode = str(getattr(policy, "mode", "local_only") or "local_only").lower()
    allow_cloud = bool(getattr(policy, "allow_cloud_case_data", False))
    consent = str(getattr(policy, "consent_reference", "") or "").strip()
    permitted = {
        str(x).strip().lower()
        for x in (getattr(policy, "permitted_providers", None) or ["openai"])
        if str(x).strip()
    }

    if provider not in _CLOUD | _LOCAL:
        raise AIPolicyError(f"Unsupported LLM provider for policy enforcement: {provider!r}")

    if provider in _CLOUD:
        if mode != "cloud_opt_in" or not allow_cloud:
            raise AIPolicyError(
                f"Cloud LLM provider {provider!r} is blocked by ai_policy. "
                "Use deterministic reporting without an API key, or explicitly set "
                "ai_policy.mode='cloud_opt_in' and allow_cloud_case_data=true."
            )
        if not consent:
            raise AIPolicyError(
                "Cloud LLM use requires a non-empty ai_policy.consent_reference "
                "so the disclosure/approval is auditable."
            )
        if any(token in consent.lower() for token in ("replace-with", "todo", "tbd", "placeholder")):
            raise AIPolicyError(
                "Cloud LLM use is blocked because ai_policy.consent_reference still "
                "contains a template placeholder. Record the real authorisation/reference first."
            )
        if provider not in permitted:
            raise AIPolicyError(
                f"Cloud provider {provider!r} is not listed in ai_policy.permitted_providers."
            )
    else:
        # Deterministic reporting is always permitted because no case-derived
        # content leaves the host and no language-model service is called.
        pass

    return {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "provider": provider,
        "provider_scope": "cloud" if provider in _CLOUD else "disabled/deterministic",
        "policy_mode": mode,
        "cloud_case_data_allowed": allow_cloud,
        "consent_reference": consent,
        "raw_evidence_transmitted": False,
        "structured_case_summary_used": provider in _CLOUD,
        "strict_llm_required": bool(require_llm),
        "decision": "ALLOWED",
    }


def write_ai_policy_record(output_dir: str | Path, case_id: str, record: dict[str, Any]) -> Path:
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in case_id)
    path = Path(output_dir).resolve() / f"{safe}_ai_policy.json"
    path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return path
