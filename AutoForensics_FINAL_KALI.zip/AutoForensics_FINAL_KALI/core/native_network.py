"""Read-only deterministic PCAP/PCAPNG packet and HTTP parsing.

The parser intentionally supports a conservative protocol subset used by the
platform's baseline network modules: Ethernet, IPv4, UDP, TCP, DNS and HTTP/1.x.
Every decoded value is tied to a frame number and byte offsets in the capture.
Unsupported link types or malformed packets are skipped rather than guessed.
"""
from __future__ import annotations

import hashlib
import ipaddress
import re
import struct
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def _iso(seconds: float) -> str:
    return datetime.fromtimestamp(seconds, tz=timezone.utc).isoformat()


def _pcap_packets(data: bytes) -> list[dict[str, Any]]:
    if len(data) < 24:
        return []
    magic = data[:4]
    if magic not in {b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\xc3\xd4", b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d"}:
        return []
    little = magic in {b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"}
    nano = magic in {b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d"}
    endian = "<" if little else ">"
    try:
        _major, _minor, _zone, _sig, _snap, linktype = struct.unpack_from(endian + "HHIIII", data, 4)
    except struct.error:
        return []
    out: list[dict[str, Any]] = []
    pos = 24; frame = 0
    while pos + 16 <= len(data):
        record_offset = pos
        try:
            sec, fraction, incl, orig = struct.unpack_from(endian + "IIII", data, pos)
        except struct.error:
            break
        pos += 16
        if incl > len(data) - pos:
            break
        packet = data[pos:pos + incl]; pos += incl; frame += 1
        divisor = 1_000_000_000 if nano else 1_000_000
        out.append({
            "frame_number": frame, "timestamp": _iso(sec + fraction / divisor),
            "capture_offset": record_offset, "packet_offset": record_offset + 16,
            "captured_length": incl, "original_length": orig,
            "linktype": linktype, "packet_bytes": packet,
        })
    return out


def _pcapng_packets(data: bytes) -> list[dict[str, Any]]:
    if not data.startswith(b"\x0a\x0d\x0d\x0a"):
        return []
    out: list[dict[str, Any]] = []
    pos = 0; endian = "<"; frame = 0
    interfaces: dict[int, dict[str, Any]] = {}
    while pos + 12 <= len(data):
        block_offset = pos
        raw_type = data[pos:pos + 4]
        # Section Header Block type is byte-order independent.
        if raw_type == b"\x0a\x0d\x0d\x0a":
            if pos + 12 > len(data): break
            bom = data[pos + 8:pos + 12]
            endian = "<" if bom == b"\x4d\x3c\x2b\x1a" else ">" if bom == b"\x1a\x2b\x3c\x4d" else endian
        try:
            btype, blen = struct.unpack_from(endian + "II", data, pos)
        except struct.error:
            break
        if blen < 12 or pos + blen > len(data):
            break
        body = data[pos + 8:pos + blen - 4]
        if btype == 1 and len(body) >= 8:  # IDB
            linktype = struct.unpack_from(endian + "H", body, 0)[0]
            interfaces[len(interfaces)] = {"linktype": linktype, "ts_divisor": 1_000_000}
            # Parse if_tsresol option (code 9).
            opt = 8
            while opt + 4 <= len(body):
                code, length = struct.unpack_from(endian + "HH", body, opt); opt += 4
                value = body[opt:opt + length]; opt += (length + 3) & ~3
                if code == 0: break
                if code == 9 and value:
                    v = value[0]
                    interfaces[len(interfaces)-1]["ts_divisor"] = (2 ** (v & 0x7F)) if v & 0x80 else (10 ** v)
        elif btype == 6 and len(body) >= 20:  # EPB
            iid, high, low, caplen, origlen = struct.unpack_from(endian + "IIIII", body, 0)
            packet = body[20:20 + caplen]
            iface = interfaces.get(iid, {"linktype": 1, "ts_divisor": 1_000_000})
            timestamp = ((high << 32) | low) / float(iface.get("ts_divisor") or 1_000_000)
            frame += 1
            out.append({
                "frame_number": frame, "timestamp": _iso(timestamp),
                "capture_offset": block_offset, "packet_offset": block_offset + 28,
                "captured_length": caplen, "original_length": origlen,
                "linktype": int(iface.get("linktype") or 1), "packet_bytes": packet,
            })
        elif btype == 3 and len(body) >= 4:  # SPB, no timestamp
            origlen = struct.unpack_from(endian + "I", body, 0)[0]
            packet = body[4:][:origlen]
            frame += 1
            out.append({
                "frame_number": frame, "timestamp": "", "capture_offset": block_offset,
                "packet_offset": block_offset + 12, "captured_length": len(packet),
                "original_length": origlen, "linktype": 1, "packet_bytes": packet,
            })
        pos += blen
    return out


def read_packets(path: Path) -> list[dict[str, Any]]:
    try: data = path.read_bytes()
    except OSError: return []
    packets = _pcap_packets(data) or _pcapng_packets(data)
    for record in packets:
        record["capture_path"] = str(path)
        record["capture_sha256"] = hashlib.sha256(data).hexdigest()
    return packets


def decode_packets(path: Path) -> list[dict[str, Any]]:
    decoded: list[dict[str, Any]] = []
    for record in read_packets(path):
        packet = record.pop("packet_bytes")
        item = dict(record)
        item["protocols"] = []
        if item.get("linktype") != 1 or len(packet) < 14:
            item["decode_status"] = "unsupported_linktype_or_truncated"
            decoded.append(item); continue
        item["protocols"].append("Ethernet")
        item["eth_dst"] = ":".join(f"{b:02x}" for b in packet[0:6])
        item["eth_src"] = ":".join(f"{b:02x}" for b in packet[6:12])
        ethertype = struct.unpack_from("!H", packet, 12)[0]
        item["ethertype"] = f"0x{ethertype:04x}"
        if ethertype != 0x0800 or len(packet) < 34:
            item["decode_status"] = "non_ipv4_or_truncated"
            decoded.append(item); continue
        ip = packet[14:]
        ihl = (ip[0] & 0x0F) * 4
        if len(ip) < ihl or ihl < 20:
            item["decode_status"] = "invalid_ipv4_header"; decoded.append(item); continue
        total_len = struct.unpack_from("!H", ip, 2)[0]
        flags_frag = struct.unpack_from("!H", ip, 6)[0]
        proto = ip[9]
        item.update({
            "protocols": item["protocols"] + ["IPv4"],
            "ip_src": str(ipaddress.ip_address(ip[12:16])),
            "ip_dst": str(ipaddress.ip_address(ip[16:20])),
            "ip_ttl": ip[8], "ip_id": struct.unpack_from("!H", ip, 4)[0],
            "ip_protocol": proto, "ip_total_length": total_len,
            "ip_fragment_offset": flags_frag & 0x1FFF,
        })
        transport = ip[ihl:min(len(ip), total_len or len(ip))]
        if proto == 17 and len(transport) >= 8:
            sport, dport, length, checksum = struct.unpack_from("!HHHH", transport, 0)
            payload = transport[8:min(len(transport), length)]
            item.update({"protocols": item["protocols"] + ["UDP"], "src_port": sport,
                         "dst_port": dport, "udp_length": length, "transport_payload": payload})
            if sport == 53 or dport == 53: item["protocols"].append("DNS")
        elif proto == 6 and len(transport) >= 20:
            sport, dport, seq, ack, off_flags, window = struct.unpack_from("!HHIIHH", transport, 0)
            hlen = ((off_flags >> 12) & 0xF) * 4
            if hlen < 20 or len(transport) < hlen:
                item["decode_status"] = "invalid_tcp_header"; decoded.append(item); continue
            flags = off_flags & 0x1FF
            payload = transport[hlen:]
            item.update({
                "protocols": item["protocols"] + ["TCP"], "src_port": sport,
                "dst_port": dport, "tcp_seq": seq, "tcp_ack": ack,
                "tcp_flags": flags, "tcp_header_length": hlen,
                "tcp_window": window, "transport_payload": payload,
            })
            if payload.startswith((b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ", b"OPTIONS ", b"PATCH ", b"HTTP/")):
                item["protocols"].append("HTTP")
        item["decode_status"] = "decoded"
        decoded.append(item)
    return decoded


def _stream_bytes(records: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, int, str, int], list[dict[str, Any]]] = {}
    for rec in records:
        payload = rec.get("transport_payload") or b""
        if "TCP" not in rec.get("protocols", []) or not payload:
            continue
        key = (str(rec["ip_src"]), int(rec["src_port"]), str(rec["ip_dst"]), int(rec["dst_port"]))
        groups.setdefault(key, []).append(rec)
    streams: list[dict[str, Any]] = []
    for key, segments in groups.items():
        segments.sort(key=lambda r: (int(r.get("tcp_seq") or 0), int(r.get("frame_number") or 0)))
        base = min(int(r.get("tcp_seq") or 0) for r in segments)
        assembled = bytearray(); maps: list[tuple[int, int, dict[str, Any]]] = []
        for rec in segments:
            seq = int(rec.get("tcp_seq") or 0); payload = bytes(rec.get("transport_payload") or b"")
            start = seq - base
            if start < 0: continue
            if start > len(assembled):
                # Gap: do not guess missing bytes; start a separate logical range.
                assembled.extend(b"\x00" * (start - len(assembled)))
            overlap = max(0, len(assembled) - start)
            new = payload[overlap:]
            if new: assembled.extend(new)
            maps.append((start, start + len(payload), rec))
        streams.append({"flow": key, "bytes": bytes(assembled), "segments": maps})
    return streams


_HTTP_START = re.compile(rb"(?m)^(?:(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|CONNECT|TRACE) ([^\r\n ]+) HTTP/(1\.[01])|HTTP/(1\.[01]) ([0-9]{3})[^\r\n]*)\r?$")


def parse_http(path: Path) -> list[dict[str, Any]]:
    records = decode_packets(path)
    messages: list[dict[str, Any]] = []
    for stream in _stream_bytes(records):
        data = stream["bytes"]
        starts = [m.start() for m in re.finditer(rb"(?m)^(?:GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|CONNECT|TRACE) [^\r\n]+ HTTP/1\.[01]\r?$|^HTTP/1\.[01] [0-9]{3}[^\r\n]*\r?$", data)]
        for start in starts:
            header_end = data.find(b"\r\n\r\n", start)
            separator = 4
            if header_end < 0:
                header_end = data.find(b"\n\n", start); separator = 2
            if header_end < 0: continue
            head = data[start:header_end].replace(b"\r\n", b"\n")
            lines = head.split(b"\n")
            if not lines: continue
            first = lines[0].decode("iso-8859-1", errors="replace")
            headers: dict[str, str] = {}
            for line in lines[1:]:
                if b":" not in line: continue
                k, v = line.split(b":", 1)
                headers[k.decode("iso-8859-1", errors="replace").strip().lower()] = v.decode("iso-8859-1", errors="replace").strip()
            try: content_length = int(headers.get("content-length", "0") or 0)
            except ValueError: content_length = 0
            body_start = header_end + separator
            body = data[body_start:body_start + max(0, content_length)]
            source_record = next((rec for a, b, rec in stream["segments"] if a <= start < b), stream["segments"][0][2] if stream["segments"] else {})
            item: dict[str, Any] = {
                "timestamp": source_record.get("timestamp", ""), "frame_number": source_record.get("frame_number"),
                "capture_path": str(path), "capture_offset": source_record.get("capture_offset"),
                "src_ip": stream["flow"][0], "src_port": stream["flow"][1],
                "dst_ip": stream["flow"][2], "dst_port": stream["flow"][3],
                "start_line": first, "headers": headers, "content_length": content_length,
                "body_bytes": body, "body_sha256": hashlib.sha256(body).hexdigest() if body else "",
                "stream_offset": start,
            }
            if first.startswith("HTTP/"):
                parts = first.split(" ", 2); item.update({"direction": "response", "status_code": parts[1] if len(parts)>1 else ""})
            else:
                parts = first.split(" ", 2); item.update({"direction": "request", "method": parts[0], "uri": parts[1] if len(parts)>1 else "", "host": headers.get("host", "")})
            try: item["body_text"] = body.decode("utf-8", errors="strict")
            except UnicodeDecodeError: item["body_text"] = ""
            messages.append(item)
    return messages


def public_record(record: dict[str, Any]) -> dict[str, Any]:
    """Remove raw bytes while preserving exact hashes and decoded fields."""
    out = dict(record)
    out.pop("transport_payload", None); out.pop("body_bytes", None)
    return out
