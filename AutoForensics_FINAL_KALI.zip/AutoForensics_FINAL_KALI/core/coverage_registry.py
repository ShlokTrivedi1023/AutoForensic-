"""Assurance coverage aggregation for every configured module outcome."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Any

from modules._base import AssuranceVerdict, ClassResult, Locus, ModuleResult, SkipReason


@dataclass
class CoverageEntry:
    """A single row in the coverage table."""
    module_name: str
    locus: Locus
    artefact_class: str
    verdict: AssuranceVerdict
    skip_reason: Optional[SkipReason]
    count: int
    notes: str
    summarised: bool = False


_MODULE_DEFAULTS: dict[str, tuple[Locus, str]] = {
    "evidence_validator": (Locus.HASH_VERIFY, "Evidence Integrity"),
    "ewf_metadata": (Locus.METADATA, "EWF Metadata and Container Structure"),
    "image_mounter": (Locus.OTHER, "Native Evidence Access"),
    "filesystem_analyzer": (Locus.FILE_SYSTEM, "Filesystem Identification"),
    "timeline_builder": (Locus.TIMELINE, "Forensic Timeline"),
    "deleted_file_recovery": (Locus.DELETED_FILES, "Deleted File Recovery"),
    "native_signature_carver": (Locus.DELETED_FILES, "Native Signature-Carving Candidates"),
    "file_signature_analyzer": (Locus.FILE_SYSTEM, "File-Signature Mismatches"),
    "artifact_extractor": (Locus.FILE_SYSTEM, "Operating-System Artefacts"),
    "keyword_search": (Locus.FILE_SYSTEM, "Keyword Matches"),
    "hash_database_match": (Locus.HASH_VERIFY, "Hash-Database Matches"),
    "string_extractor": (Locus.FILE_SYSTEM, "Extracted Strings"),
    "memory_process_list": (Locus.MEMORY, "Memory Process Artefacts"),
    "memory_network_connections": (Locus.MEMORY, "Memory Network Connections"),
    "memory_artifact_extractor": (Locus.MEMORY, "Memory Artefacts"),
    "memory_malware_scanner": (Locus.MEMORY, "Memory Malware Indicators"),
    "memory_string_analyzer": (Locus.MEMORY, "Memory Strings"),
    "pcap_analyzer": (Locus.NETWORK, "PCAP Traffic Artefacts"),
    "network_protocol_decoder": (Locus.NETWORK, "Decoded Network Protocol Artefacts"),
    "dns_analyzer": (Locus.NETWORK, "DNS Artefacts"),
    "http_reconstructor": (Locus.NETWORK, "HTTP Artefacts"),
    "yara_scanner": (Locus.MALWARE, "YARA Matches"),
    "native_malware_scanner": (Locus.MALWARE, "Native Malware/Test Signatures"),
    "clamav_scanner": (Locus.MALWARE, "ClamAV Detections"),
    "suspicious_file_detector": (Locus.MALWARE, "Suspicious Files"),
    "ioc_matcher": (Locus.MALWARE, "IOC Matches"),
    "rootkit_detector": (Locus.MEMORY, "Rootkit Indicators"),
    "foremost_carver": (Locus.DELETED_FILES, "Foremost Carving Candidates"),
    "scalpel_carver": (Locus.DELETED_FILES, "Scalpel Carving Candidates"),
    "bulk_extractor_scan": (Locus.FILE_SYSTEM, "Bulk Extractor Artefacts"),
    "exiftool_metadata": (Locus.METADATA, "File Metadata"),
    "ocr_text_extractor": (Locus.IMAGES, "OCR Text"),
    "document_analyzer": (Locus.METADATA, "Document Active Content"),
    "geolocation_extractor": (Locus.METADATA, "Geolocation Metadata"),
    "hashcat_recovery": (Locus.PASSWORDS, "Hashcat Password Recovery"),
    "john_recovery": (Locus.PASSWORDS, "John Password Recovery"),
    "steganography_detector": (Locus.IMAGES, "Steganography Indicators"),
    "windows_registry_analyzer": (Locus.REGISTRY, "Windows Registry Artefacts"),
    "filesystem_deep_analyzer": (Locus.FILE_SYSTEM, "Deep Filesystem Artefacts"),
    "email_communications_analyzer": (Locus.EMAIL, "Email and Communication Artefacts"),
    "browser_history_analyzer": (Locus.BROWSER, "Browser Artefacts"),
    "criminal_network_mapper": (Locus.OTHER, "Identifier Correlation"),
    "image_content_analyzer": (Locus.IMAGES, "Image Content Artefacts"),
    "anti_forensic_detector": (Locus.ANTI_FORENSICS, "Anti-Forensic Indicators"),
    "mobile_analyzer": (Locus.OTHER, "Mobile Artefacts"),
}


def _canonical(name: str) -> str:
    return str(name or "").strip().lower().replace(" ", "_").replace("-", "_")


def _fallback_reason(text: str, status: str, outcome: str) -> SkipReason:
    blob = " ".join((text or "").lower().split())
    if any(token in blob for token in (
        "no memory", "no pcap", "no corpus", "no registry", "no extracted files",
        "mobile platform could not be identified", "required evidence type", "not applicable",
    )):
        return SkipReason.NO_CORPUS
    if "dependency" in blob or "not installed" in blob or "database unavailable" in blob:
        return SkipReason.DEPENDENCY_MISSING
    if "timeout" in blob or "timed out" in blob:
        return SkipReason.TIMEOUT
    if outcome == "did_not_run" and status in {"skipped", "degraded", "indeterminate"}:
        return SkipReason.SKIPPED
    return SkipReason.PARTIAL_FAILURE


def fallback_entry(module_result: Any) -> CoverageEntry:
    """Create one honest assurance row when a module omitted ClassResult data."""
    name = str(getattr(module_result, "module_name", "Unknown") or "Unknown")
    key = _canonical(name)
    locus, label = _MODULE_DEFAULTS.get(key, (Locus.OTHER, name.replace("_", " ").title()))
    status = str(getattr(module_result, "status", "") or "").lower()
    outcome = str(getattr(module_result, "execution_outcome", "") or "").lower()
    findings = list(getattr(module_result, "findings", []) or [])
    summary = str(getattr(module_result, "summary", "") or "")
    error = str(getattr(module_result, "error_message", "") or "")
    examined = int(getattr(module_result, "artefacts_examined", 0) or 0)
    notes = " | ".join(x for x in (summary, error) if x).strip() or "Module omitted a ClassResult assurance record."

    if findings:
        verdict = AssuranceVerdict.PRESENT
        skip = None
        count = len(findings)
    elif outcome == "ran_found_nothing" and status in {"success", "completed"} and examined > 0:
        verdict = AssuranceVerdict.VERIFIED_ABSENT
        skip = None
        count = 0
    else:
        verdict = AssuranceVerdict.INDETERMINATE
        skip = _fallback_reason(notes, status, outcome)
        count = 0
        notes = (notes + " | Coverage fallback used because the module did not emit a ClassResult.").strip(" |")

    return CoverageEntry(
        module_name=name,
        locus=locus,
        artefact_class=label,
        verdict=verdict,
        skip_reason=skip,
        count=count,
        notes=notes,
        summarised=False,
    )


class CoverageRegistry:
    """Collect per-class verdicts and guarantee representation of every module."""

    def __init__(self) -> None:
        self._entries: list[CoverageEntry] = []

    def ingest(self, module_result: ModuleResult) -> None:
        class_results = list(getattr(module_result, "class_results", []) or [])
        if not class_results:
            self._entries.append(fallback_entry(module_result))
            return
        for cr in class_results:
            self._entries.append(CoverageEntry(
                module_name=module_result.module_name,
                locus=cr.locus,
                artefact_class=cr.artefact_class,
                verdict=cr.verdict,
                skip_reason=cr.skip_reason,
                count=cr.count,
                notes=cr.notes,
                summarised=getattr(cr, "summarised", False),
            ))

    def ingest_all(self, module_results: list[ModuleResult]) -> None:
        for mr in module_results:
            self.ingest(mr)

    def all_entries(self) -> list[CoverageEntry]:
        return list(self._entries)

    def entries_by_verdict(self, verdict: AssuranceVerdict) -> list[CoverageEntry]:
        return [e for e in self._entries if e.verdict == verdict]

    def entries_by_locus(self, locus: Locus) -> list[CoverageEntry]:
        return [e for e in self._entries if e.locus == locus]

    def global_limitations(self) -> list[CoverageEntry]:
        return self.entries_by_verdict(AssuranceVerdict.INDETERMINATE)

    def verdict_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {v.value: 0 for v in AssuranceVerdict}
        for e in self._entries:
            counts[e.verdict.value] += 1
        return counts

    def represented_modules(self) -> set[str]:
        return {entry.module_name for entry in self._entries}

    def is_empty(self) -> bool:
        return len(self._entries) == 0
