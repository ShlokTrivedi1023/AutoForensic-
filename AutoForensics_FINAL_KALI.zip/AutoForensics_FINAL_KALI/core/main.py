"""
core/main.py — ForensicOrchestrator for Auto Forensics

Central engine for the Auto Forensics platform. Drives every investigation
from investigator authentication through evidence acquisition, module pipeline
execution, report generation, and chain of custody sealing.

Design principles enforced throughout this file:
  - All investigation state lives on the orchestrator instance (never globals).
  - The CoC logger is injected after case intake, not hardcoded.
  - Every external tool is called via subprocess argument lists — never
    shell=True, never string interpolation into a command.
  - Every user-supplied value is sanitized and validated before it touches
    the filesystem, a subprocess argument, or the CoC log.
  - All file paths are resolved (Path.resolve()) and validated before use
    to prevent path traversal vulnerabilities.
  - No silent failures — every error is logged, CoC-recorded, and surfaced
    to the investigator with a clear message.

Execution lifecycle
-------------------
  1. authenticate      — verify identity against investigators registry
  2. intake_case       — collect case metadata via CLI args + interactive fallback
  3. verify_write_block — confirm write blocker is active (live device only)
  4. acquire_evidence  — image device to E01 or accept existing image
  5. verify_evidence_integrity — SHA-256 hash the evidence image
  6. load_modules      — config-driven registry + auto-discovery fallback
  7. execute_pipeline  — run modules in order; log failures, never crash
  8. generate_report   — compile outputs into JSON + plain-text report
  9. seal_custody_log  — hash-verify and cryptographically seal the CoC ledger
"""

import argparse
from dataclasses import asdict
import getpass
import hashlib
import hmac
import importlib.util
import json
import logging
import logging.handlers
import os
import platform as _platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

import yaml  # PyYAML — install: pip install pyyaml

# CustodyLogger and EventType live in their own module so they can be
# independently tested and reused outside the orchestrator.
from core.case_config import exhibit_id_for, stamp_result_exhibit
from core.custody_log import CustodyLogger, EventType
from core.finding_assurance import assure_module_result
from core.deterministic_reconciler import reconcile_module_result
from core.canonical_result import finalise_canonical_result
from core.module_completion import certify_module_result
from core.memory_marker_modules import marker_capable_modules, run_marker_scope, augment_with_marker_scope
from core.fact_classification import annotate_findings
from core.llm_provider import LLMUnavailable

# ModuleStatus is imported lazily-safe here so execute_pipeline() can record
# IMPORT_FAILED synthetic entries in the banner counts without a circular import.
from modules._base import ModuleResult, ModuleStatus
from core.module_isolation import ModuleTimeoutError, module_timeout, atomic_write_json, atomic_write_text

# ──────────────────────────────────────────────────────────────────────────────
# Platform constants
# ──────────────────────────────────────────────────────────────────────────────

from core.version import VERSION

# Resolved at import time so every path check is relative to the project root,
# not the current working directory (which may differ when run via symlinks).
_PROJECT_ROOT = Path(__file__).parent.parent.resolve()

def _registry_path() -> Path:
    """Return a writable per-user registry unless explicitly overridden.

    A system-wide /etc registry caused first-run permission and stale-role
    failures on Kali.  Operators that intentionally manage a shared registry
    can still set AUTOFORENSICS_INVESTIGATORS_REGISTRY to an absolute path.
    """
    configured = os.environ.get("AUTOFORENSICS_INVESTIGATORS_REGISTRY", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    if _platform.system() == "Windows":
        base = Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming"))
        return (base / "AutoForensics" / "investigators.json").resolve()
    return (Path.home() / ".config" / "autoforensics" / "investigators.json").resolve()

INVESTIGATORS_REGISTRY_PATH = _registry_path()
MODULE_CONFIG_PATH           = _PROJECT_ROOT / "config" / "modules.yaml"
MODULES_DIR                  = _PROJECT_ROOT / "modules"
DEFAULT_OUTPUT_DIR           = _PROJECT_ROOT / "output"


def _json_default(value: Any) -> Any:
    """Serialise supported non-JSON runtime values without hiding bugs.

    Module results may legitimately contain sets, paths, datetimes, enums or
    byte strings.  These are converted deterministically.  Unknown object
    types still raise TypeError so report generation cannot silently invent a
    string representation for an unsupported structure.
    """
    if isinstance(value, (set, frozenset)):
        return sorted(value, key=lambda item: str(item))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, bytes):
        return {"encoding": "hex", "value": value.hex()}
    raise TypeError(
        f"Object of type {value.__class__.__name__} is not JSON serializable"
    )


def _ensure_investigators_registry() -> None:
    """Create the resolved per-user/explicit investigator registry when missing."""
    if INVESTIGATORS_REGISTRY_PATH.exists():
        return
    project_template = _PROJECT_ROOT / "config" / "investigators.json"
    legacy_system = Path("/etc/autoforensics/investigators.json")
    try:
        INVESTIGATORS_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        migration_source = (
            legacy_system if legacy_system.is_file() and os.access(legacy_system, os.R_OK)
            else project_template
        )
        if migration_source.exists():
            shutil.copy2(migration_source, INVESTIGATORS_REGISTRY_PATH)
        else:
            INVESTIGATORS_REGISTRY_PATH.write_text(
                '{"_password_hashing":{"algorithm":"pbkdf2_hmac_sha256",'
                '"iterations":260000,"salt_bytes":32,"dk_len":32},'
                '"investigators":{"admin":{"investigator_id":"admin",'
                '"name":"Platform Administrator","badge":"ADMIN-001",'
                '"role":"Platform Administrator",'
                '"department":"IT / Forensics Platform Operations",'
                '"password_hash":"PLACEHOLDER_RUN_tools/admin.py_set-admin-password_TO_REPLACE_THIS",'
                '"password_salt":"PLACEHOLDER_RUN_tools/admin.py_set-admin-password_TO_REPLACE_THIS",'
                '"account_created":"YYYY-MM-DD","last_login":null,"active":true,'
                '"must_change_password":true,'
                '"permissions":["conduct_investigation","view_reports",'
                '"manage_investigators","manage_modules","export_evidence",'
                '"change_any_password"],'
                '"certifications":[],'
                '"notes":"Default bootstrap administrator. Disable after creating named administrator accounts."}}}',
                encoding="utf-8",
            )
        try:
            os.chmod(INVESTIGATORS_REGISTRY_PATH, 0o600)
        except OSError:
            pass  # Windows or permission denied — non-fatal
    except OSError:
        pass  # Will fail gracefully at login if still missing


def _check_investigators_json() -> None:
    """Verify the resolved investigator registry without switching paths.

    The same ``INVESTIGATORS_REGISTRY_PATH`` is used by startup, admin tools
    and authentication.  This prevents a user-owned setup from being silently
    replaced by a stale or differently shaped /etc registry.
    """
    import json as _json

    _ensure_investigators_registry()
    config_path = INVESTIGATORS_REGISTRY_PATH
    if not config_path.exists():
        raise RuntimeError(
            f"Investigators registry could not be created at {config_path}. "
            "Set AUTOFORENSICS_INVESTIGATORS_REGISTRY to a writable path."
        )
    try:
        data = _json.loads(config_path.read_text(encoding="utf-8"))
        investigators = data.get("investigators") if isinstance(data, dict) else None
        if not isinstance(investigators, dict):
            raise ValueError("registry must contain an 'investigators' object")
        os.chmod(config_path, 0o600)
    except Exception as exc:
        raise RuntimeError(f"Invalid investigators registry at {config_path}: {exc}") from exc


# Narrow allowlist for case IDs: prevents path traversal, shell injection,
# log injection (no slashes, quotes, newlines, or control characters).
_CASE_ID_RE = re.compile(r"^[A-Za-z0-9\-_]{1,64}$")

# Maximum length for any single user-supplied string field.
_MAX_INPUT_LEN = 256

# Evidence inputs accepted by the platform. Concrete evidence_type values such
# as "e01", "vmem", and "pcap" are accepted as aliases so generated case
# templates match the investigator-facing terminology.
_DISK_IMAGE_EXTS = frozenset({".e01", ".ex01", ".dd", ".img"})
_MEMORY_EXTS = frozenset({".vmem", ".mem", ".dmp", ".lime"})
_NETWORK_EXTS = frozenset({".pcap", ".pcapng", ".cap"})
_MOBILE_ARCHIVE_EXTS = frozenset({".tar", ".tgz", ".gz", ".zip", ".ab", ".ufdr"})
_AMBIGUOUS_EXTS = frozenset({".raw", ".bin"})
_SUPPORTED_IMAGE_EXTS = frozenset().union(
    _DISK_IMAGE_EXTS,
    _MEMORY_EXTS,
    _NETWORK_EXTS,
    _MOBILE_ARCHIVE_EXTS,
    _AMBIGUOUS_EXTS,
)


def _classify_evidence_path(
    path: Path,
    configured_type: str = "",
    profile: str = "",
) -> str:
    """Classify an evidence source without inspecting or changing its content."""
    declared = str(configured_type or "").strip().lower().replace("_", "-")
    aliases = {
        "image": "disk",
        "disk-image": "disk",
        "filesystem": "disk",
        "e01": "disk",
        "ex01": "disk",
        "dd": "disk",
        "img": "disk",
        "raw": "disk",
        "bin": "disk",
        "ram": "memory",
        "memory-image": "memory",
        "vmem": "memory",
        "mem": "memory",
        "dmp": "memory",
        "lime": "memory",
        "pcap": "network",
        "pcapng": "network",
        "cap": "network",
        "network-capture": "network",
        "android": "mobile",
        "ios": "mobile",
        "mobile-extraction": "mobile",
        "ufdr": "mobile",
        "ab": "mobile",
        "tar": "mobile",
        "zip": "mobile",
        "auto": "",
        "": "",
    }
    declared = aliases.get(declared, declared)
    if declared:
        if declared not in {"disk", "memory", "network", "mobile"}:
            raise ValueError(f"Unsupported evidence_type '{configured_type}'")
        return declared
    if path.is_dir():
        return "mobile"
    suffix = path.suffix.lower()
    if suffix in _DISK_IMAGE_EXTS:
        return "disk"
    if suffix in _MEMORY_EXTS:
        return "memory"
    if suffix in _NETWORK_EXTS:
        return "network"
    if suffix in _MOBILE_ARCHIVE_EXTS:
        return "mobile"
    if suffix in _AMBIGUOUS_EXTS:
        return "memory" if str(profile or "").lower() == "memory" else "disk"
    raise ValueError(
        f"Unsupported evidence source '{path}'. Supported disk, memory, PCAP, "
        "and mobile extraction inputs are required."
    )


def _case_config_complete(cfg: Any) -> bool:
    """Return True when a loaded case config has the minimum intake fields.

    This is deliberately advisory.  It checks structure only and does not test
    whether evidence paths exist, because those paths may only exist on the
    investigation workstation.
    """
    if not getattr(cfg, "case_number", ""):
        return False
    examiner = getattr(cfg, "examiner", None)
    if not examiner or not getattr(examiner, "name", ""):
        return False
    evidence = getattr(cfg, "evidence_items", [])
    if not evidence:
        return False
    return any(getattr(item, "path", "") for item in evidence)


# ------------------------------------------------------------------------------
# Input sanitisation and validation
# ------------------------------------------------------------------------------

def _sanitize(value: str, label: str, max_len: int = _MAX_INPUT_LEN) -> str:
    """Strip surrounding whitespace and enforce a bounded non-empty string."""
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a string, got {type(value).__name__}")
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{label} cannot be empty")
    if len(cleaned) > max_len:
        raise ValueError(
            f"{label} is too long ({len(cleaned)} chars). Maximum is {max_len}."
        )
    return cleaned


def _validate_case_id(raw: str) -> str:
    """Validate a case identifier before it is used in paths or logs."""
    cleaned = _sanitize(raw, "Case ID", max_len=64)
    if not _CASE_ID_RE.fullmatch(cleaned):
        raise ValueError(
            f"Case ID '{cleaned}' is invalid. Use only letters, digits, "
            "hyphens, and underscores (max 64 characters)."
        )
    return cleaned


def _validate_path(
    raw: str,
    label: str,
    must_exist: bool = True,
    must_be_file: bool = False,
    must_be_block_device: bool = False,
) -> Path:
    """Resolve and validate a user-supplied filesystem path."""
    cleaned = _sanitize(raw, label)
    try:
        resolved = Path(cleaned).expanduser().resolve()
    except (OSError, RuntimeError, ValueError) as exc:
        raise ValueError(f"Cannot resolve path for {label}: {exc}") from exc

    if must_exist and not resolved.exists():
        raise ValueError(f"{label} does not exist: {resolved}")
    if must_be_file and not resolved.is_file():
        raise ValueError(f"{label} is not a regular file: {resolved}")
    if must_be_block_device and not resolved.is_block_device():
        raise ValueError(f"{label} is not a block device: {resolved}")
    return resolved


# Maximum time (seconds) ewfacquire may run before acquisition is aborted.
_ACQUISITION_TIMEOUT_S = 7200


def _hash_password(password: str, salt: bytes) -> str:
    """
    Derive a key from a password using PBKDF2-HMAC-SHA256.

    PBKDF2 with 260,000 iterations meets NIST SP 800-132 (2023) minimum
    recommendations for PBKDF2-SHA256. We use the stdlib implementation
    to avoid adding a bcrypt/argon2 C-extension dependency that may not
    be present on all Kali Linux installations.

    The salt must be unique per investigator — callers are responsible for
    generating it with os.urandom(32) when registering a new investigator.
    """
    dk = hashlib.pbkdf2_hmac(
        hash_name  = "sha256",
        password   = password.encode("utf-8"),
        salt       = salt,
        iterations = 260_000,
    )
    return dk.hex()


# ──────────────────────────────────────────────────────────────────────────────
# Logging setup
# ──────────────────────────────────────────────────────────────────────────────

def _setup_platform_logger(output_dir: Path, case_id: str) -> logging.Logger:
    """
    Configure structured logging for the platform (separate from CoC logging).

    Two handlers:
    - Console: INFO and above — operational status visible to the investigator.
    - Rotating file: DEBUG and above — full detail for incident response and
      platform maintenance. Rotates at 50 MB with 5 backups (250 MB total).

    The platform log is NOT the chain of custody — it is an operational
    debug log for the platform engineers. CoC entries go through CustodyLogger.
    """
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    # 0o700 — log directory should not be world-readable
    os.chmod(log_dir, 0o700)

    # Sanitize case_id before using it in a filename
    safe_id  = re.sub(r"[^\w\-]", "_", case_id)
    log_file = log_dir / f"{safe_id}_platform.log"

    fmt = logging.Formatter(
        fmt     = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt = "%Y-%m-%dT%H:%M:%S%z",
    )

    logger = logging.getLogger("autoforensics")
    logger.setLevel(logging.DEBUG)
    # The root logger is configured by run.py.  Prevent each record from being
    # emitted once by this logger and again by the root logger.
    logger.propagate = False
    # Prevent duplicate handlers if this function is somehow called twice.
    logger.handlers.clear()

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(fmt)

    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=50 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger


# ──────────────────────────────────────────────────────────────────────────────
# Banner
# ──────────────────────────────────────────────────────────────────────────────

def _print_banner() -> None:
    """
    Display the Auto Forensics banner.

    Called once at startup, before authentication. The legal notice is not
    decorative — it establishes that the user was warned this system is for
    authorized use only, which matters if unauthorized access is prosecuted.
    """
    print(f"""
+==================================================================+
|                         AUTOFORENSICS                          |
|              Digital Investigation Platform                       |
+==================================================================+
|  NOTICE: This system is for authorized law enforcement and       |
|  forensic investigation use ONLY. All actions are recorded in    |
|  a cryptographically sealed chain of custody log. Unauthorized   |
|  access or use is a criminal offence.                            |
+==================================================================+
""")


# ──────────────────────────────────────────────────────────────────────────────
# Tool version detection helpers
# ──────────────────────────────────────────────────────────────────────────────

def _detect_tool_version(binary: str, version_flag: str = "--version") -> str:
    """Run binary --version and extract the first version-like string."""
    if not shutil.which(binary):
        return "not installed"
    try:
        r = subprocess.run([binary, version_flag], capture_output=True, text=True, timeout=10)
        output = (r.stdout + r.stderr).strip()
        m = re.search(r'(\d+\.\d+[\.\d]*)', output)
        return m.group(1) if m else (output.splitlines()[0][:40] if output else "unknown")
    except Exception:
        return "unknown"


def _detect_john_version() -> str:
    """Detect John the Ripper version by parsing the banner (first stderr line)."""
    if not shutil.which("john"):
        return "not installed"
    try:
        r = subprocess.run(
            ["john"],
            capture_output=True, text=True, timeout=5,
        )
        # john prints banner to stderr when invoked with no args
        first_line = (r.stderr or r.stdout).splitlines()[0] if (r.stderr or r.stdout) else ""
        # Use the john-specific parser from modules/john_recovery.py
        from modules.john_recovery import _parse_john_version
        return _parse_john_version(first_line) or "unknown"
    except Exception:
        return "unknown"


def populate_tool_versions() -> dict:
    """Probe each forensic binary once and return a name→version mapping."""
    return {
        "hashcat":        _detect_tool_version("hashcat"),
        "john":           _detect_john_version(),
        "exiftool":       _detect_tool_version("exiftool", "-ver"),
        "fls":            _detect_tool_version("fls", "-V"),
        "bulk_extractor": _detect_tool_version("bulk_extractor", "-V"),
        "ewfmount":       _detect_tool_version("ewfmount", "--version"),
        "clamscan":       _detect_tool_version("clamscan", "--version"),
        "tesseract":      _detect_tool_version("tesseract", "--version"),
        "volatility":     _detect_tool_version("vol", "--version"),
    }


def _norm_status(raw: object) -> str:
    """Return a canonical UPPER-CASE status string regardless of enum import path.

    Handles three cases:
      • Enum member with .value  → use the value directly (e.g. ModuleStatus.COMPLETED)
      • "ClassName.MEMBER" string → strip the class prefix (Python 3.12 str(StrEnum))
      • Any other string or None  → uppercase as-is, default to "UNKNOWN"
    """
    if hasattr(raw, "value"):
        return str(raw.value).upper()
    s = str(raw).strip() if raw is not None else "UNKNOWN"
    # e.g. "ModuleStatus.COMPLETED" → "COMPLETED"
    return s.rsplit(".", 1)[-1].upper()


_STRICT_EXECUTED_STATES = {
    "PASS_COMPLETE", "INCOMPLETE", "NOT_APPLICABLE", "OUT_OF_SCOPE", "FAILED_ISOLATED",
}

def _strict_status_counts(results: list[dict[str, Any]]) -> dict[str, int | bool]:
    statuses = [_norm_status(item.get("status")) for item in results]
    executed = sum(status in _STRICT_EXECUTED_STATES for status in statuses)
    return {
        "executed": executed,
        "completed": statuses.count("PASS_COMPLETE"),
        "incomplete": statuses.count("INCOMPLETE"),
        "not_applicable": statuses.count("NOT_APPLICABLE"),
        "out_of_scope": statuses.count("OUT_OF_SCOPE"),
        "failed": statuses.count("FAILED_ISOLATED") + sum(
            status in {"FAILED", "ERROR", "FAILED_OFFSET", "IMPORT_FAILED"} for status in statuses
        ),
        "zero_modules_executed": executed == 0,
    }


# ──────────────────────────────────────────────────────────────────────────────
# ForensicOrchestrator
# ──────────────────────────────────────────────────────────────────────────────

class ForensicOrchestrator:
    """
    Central engine for automated forensic investigations.

    All investigation state is stored as instance attributes. There is no
    global or module-level state — this makes the orchestrator testable
    (instantiate, call methods, inspect state) and safe for multiple
    investigations in a single process.

    The nine investigation phases are implemented as public methods.
    Call run() to execute the full lifecycle in order, or call individual
    methods for fine-grained control (e.g., in tests).
    """

    def __init__(
        self,
        output_dir: Path,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        """
        Parameters
        ----------
        output_dir   Base directory for all output. Case-specific subdirectories
                     are created under this path. Must be writable.
        logger       Inject a pre-configured logger (useful in tests). If None,
                     a minimal logger is set up using the root configuration;
                     a full logger is configured inside intake_case() once the
                     case_id is known.
        """
        _ensure_investigators_registry()
        self._output_dir = output_dir.resolve()

        # All attributes are initialized to None here and populated progressively
        # as each investigation phase completes. This makes it easy to detect if
        # a phase was skipped (the attribute is still None).
        self._investigator: Optional[dict[str, str]] = None
        self._case_id:      Optional[str]  = None
        self._profile_name: Optional[str]  = None

        # Set to "live_device" or "existing_image" during intake_case()
        self._evidence_source: Optional[str] = None

        # Device path — only set when evidence_source == "live_device"
        self._device_path: Optional[Path]  = None
        # Attached-device acquisition state (v2.8.0).
        self._selected_device_info: Optional[Any] = None
        self._write_protection_record: Optional[Any] = None
        self._acquisition_record: Optional[Any] = None
        # Raw image path supplied by the investigator (existing image scenario)
        self._image_path:  Optional[Path]  = None
        # All evidence paths when loaded from CaseConfig — empty for single-item / live-device
        self._config_evidence_paths: list[Path] = []
        self._config_evidence_options: dict[str, dict[str, str]] = {}
        self._evidence_kind: str = "disk"
        self._evidence_device_type: str = ""
        # The single authoritative evidence path — set after acquire_evidence()
        # and never modified afterward. All modules read from this path.
        self._evidence_path: Optional[Path] = None
        # SHA-256 and MD5 hex digests of the evidence image — both set by
        # verify_evidence_integrity().  MD5 is retained alongside SHA-256 so the
        # report can show a dual-hash integrity record and re-verify against the
        # E01's embedded acquisition hashes.
        # Logical-media hashes are distinct from the original source-container
        # hashes.  Keeping both prevents an E01 path from being labelled with the
        # reconstructed-media digest in finding-level evidence references.
        self._evidence_hash: Optional[str]  = None
        self._evidence_md5:  Optional[str]  = None
        self._evidence_sha1: Optional[str]  = None
        self._source_container_sha256: Optional[str] = None
        self._source_container_md5: Optional[str] = None
        self._source_container_sha1: Optional[str] = None
        self._source_container_size_bytes: int = 0
        self._source_container_hash_basis: str = ""
        self._logical_media_size_bytes: int = 0
        # Embedded acquisition hashes read from the E01 metadata and the
        # per-algorithm match verdicts, populated by verify_evidence_integrity().
        self._evidence_embedded_hashes: dict[str, str] = {}
        self._evidence_hash_matches: dict[str, str] = {}

        # Per-case output directory — set in intake_case()
        self._case_output_dir: Optional[Path] = None

        # Loaded module descriptors — set by load_modules()
        self._modules: list[dict[str, Any]] = []
        # Synthetic result entries for modules that failed to import — merged into
        # execute_pipeline() results so the banner counts them accurately.
        self._import_failed_results: list[dict[str, Any]] = []
        # Whether the run may block on console prompts.  Resolved for real in
        # run(); defaulted here so intake helpers are safe if called directly.
        self._non_interactive: bool = False
        # Results from execute_pipeline() — one dict per module
        self._module_results: list[dict[str, Any]] = []
        # Accumulated per-evidence results — one entry per evidence image processed
        self._all_evidence_results: list[dict[str, Any]] = []

        # CustodyLogger — initialized in intake_case() once case_id is known
        self._coc: Optional[CustodyLogger] = None

        self._pdf_path:       Optional[str]  = None
        self._pdf_page_count: Optional[int]  = None
        self._pdf_sha256:     Optional[str]  = None
        self._report_json_path: Optional[str] = None
        self._signature_path: Optional[str] = None
        self._completion_manifest_path: Optional[str] = None

        # ewfmount lifecycle — set by _mount_evidence(), cleared by _unmount_evidence()
        self._analysis_path:    Optional[Path] = None  # ewf1 or raw device or image
        self._partition_offset: int            = 0
        self._ewf_mount_point:  Optional[Path] = None  # /mnt/ewf_<label> if we mounted
        # Filesystem mount lifecycle — set by _mount_filesystem(), cleared by
        # _unmount_filesystem().  This is the single WALKABLE mounted filesystem
        # root (the acquired partition) that every file-consuming module scans.
        self._fs_mount_root:    Optional[Path] = None  # /mnt/fs_<label> directory
        # Native path state: no FUSE/loop mount and no sudo required.
        self._native_media_path: Optional[Path] = None
        self._native_fs_result: Optional[Any] = None
        self._fs_mount_is_native: bool = False
        self._evidence_access_method: str = "unresolved"

        # Working-set dict — canonical paths injected into every module's config
        self._working_set: dict = {}
        # Corpus roots produced by recovery/carving modules for the evidence
        # item currently being processed; reset per item, filled at runtime.
        self._corpus_roots: list[str] = []

        self._sealed = False
        self._logger = logger or logging.getLogger("autoforensics")

        # Canonical per-case findings store — populated by execute_pipeline()
        self._findings_store: Optional[Any] = None

        # EWF embedded-hash comparison note — set by verify_evidence_integrity()
        self._ewf_hash_note: str = ""

        # Tool version map — populated by load_modules() via populate_tool_versions()
        self._tool_versions: dict = {}

        # CaseConfig — loaded from AUTOFORENSICS_CASE_CONFIG env var if set
        self._case_config = None
        _cfg_path = os.environ.get("AUTOFORENSICS_CASE_CONFIG", "")
        if _cfg_path:
            try:
                from core.case_config import load_case_config
                self._case_config = load_case_config(_cfg_path)
                if self._case_config and not self._case_config.investigation_profile:
                    self._case_config.investigation_profile = "full"
            except Exception as _e:
                self._logger.warning("Could not load CaseConfig from env: %s", _e)

    # ──────────────────────────────────────────────────────────────────────
    # Phase 1 — Authentication
    # ──────────────────────────────────────────────────────────────────────

    def authenticate(self, investigator_id: str, password: str) -> bool:
        """
        Verify the investigator's credentials against the local investigators registry.

        Authentication occurs before any case data is loaded so that the CoC log's
        first entry is always a verified identity. An unauthenticated caller cannot
        reach any subsequent phase.

        The registry is a JSON file at config/investigators.json. It must be
        owner-readable only (0o600 or stricter) — we warn if permissions are
        too permissive, because the file contains derived password hashes.

        Password comparison uses hmac.compare_digest() for constant-time equality
        to prevent timing-oracle attacks that could reveal whether the hash prefix
        matched before the comparison terminated.

        Parameters
        ----------
        investigator_id   Login ID of the investigator (e.g. "jsmith").
        password          Plaintext password — never stored, only compared.

        Returns
        -------
        True on success. False on failure (bad credentials, deactivated account).

        Raises
        ------
        RuntimeError   If the registry file is missing or cannot be parsed.
                       These are platform configuration errors, not auth errors.
        """
        self._logger.debug("Authentication attempt for investigator_id=%s", investigator_id)

        # Platform misconfiguration — fail hard and immediately
        if not INVESTIGATORS_REGISTRY_PATH.exists():
            raise RuntimeError(
                f"Investigators registry not found at {INVESTIGATORS_REGISTRY_PATH}. "
                "Run:  python tools/admin.py register-investigator"
            )

        # Warn if the registry is world-readable — it contains password hashes
        stat = INVESTIGATORS_REGISTRY_PATH.stat()
        if stat.st_mode & 0o077:
            self._logger.warning(
                "Investigators registry has permissive permissions (%o). "
                "Fix with: chmod 600 %s",
                stat.st_mode & 0o777, INVESTIGATORS_REGISTRY_PATH,
            )

        try:
            with open(INVESTIGATORS_REGISTRY_PATH, "r", encoding="utf-8") as f:
                registry: dict = json.load(f)
        except (json.JSONDecodeError, OSError) as exc:
            raise RuntimeError(f"Cannot read investigators registry: {exc}") from exc

        investigators: dict = registry.get("investigators", {})
        profile: Optional[dict] = investigators.get(investigator_id)

        if profile is None:
            # Do not reveal whether the ID exists — log generically
            self._log_auth_failure(investigator_id, "credential check failed")
            return False

        if not profile.get("active", True):
            self._log_auth_failure(investigator_id, "account is deactivated")
            return False

        stored_hash: str = profile.get("password_hash", "")
        stored_salt: bytes = bytes.fromhex(profile.get("password_salt", ""))
        candidate_hash = _hash_password(password, stored_salt)

        # Constant-time comparison — length-independent, prevents timing attacks
        if not hmac.compare_digest(candidate_hash, stored_hash):
            self._log_auth_failure(investigator_id, "credential check failed")
            return False

        # Authentication passed — record the verified profile
        self._investigator = {
            "id":    investigator_id,
            "name":  profile.get("name", investigator_id),
            "badge": profile.get("badge", "N/A"),
            "role":  profile.get("role", "Investigator"),
        }

        self._logger.info(
            "Authentication successful: %s (%s)",
            self._investigator["name"], self._investigator["badge"],
        )
        return True

    def _log_auth_failure(self, investigator_id: str, reason: str) -> None:
        """
        Write a failed authentication attempt to the platform-level auth audit log.

        This runs before a CustodyLogger exists (no case_id yet), so it writes
        to a dedicated auth_audit.jsonl in the base output directory. This file
        is how administrators detect brute-force attempts against the platform.
        """
        self._output_dir.mkdir(parents=True, exist_ok=True)
        audit_path = self._output_dir / "auth_audit.jsonl"

        entry = {
            "timestamp":        datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "event":            "AUTH_FAILURE",
            "investigator_id":  investigator_id,
            "reason":           reason,
        }
        try:
            with open(audit_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=True) + "\n")
        except OSError as exc:
            # Non-fatal — log to stderr if the file can't be written
            self._logger.error("Could not write auth audit entry: %s", exc)

        self._logger.warning(
            "Authentication failed for investigator_id=%s reason=%s",
            investigator_id, reason,
        )

    # ──────────────────────────────────────────────────────────────────────
    # Phase 2 — Case Intake
    # ──────────────────────────────────────────────────────────────────────

    def _prompt_or_fail(self, prompt: str, field: str) -> str:
        """Read an intake field from the console, or fail closed in
        non-interactive mode where no prompt may block (Phase 1f).

        The RuntimeError propagates to run()'s handler, which emergency-seals the
        CoC and exits non-zero — a missing field never hangs a batch run.
        """
        if getattr(self, "_non_interactive", False):
            raise RuntimeError(
                f"non-interactive run is missing required field '{field}' and "
                f"cannot prompt for it; supply it via --case-file, the matching "
                f"CLI flag, or environment."
            )
        return input(prompt).strip()

    def intake_case(self, args: argparse.Namespace) -> None:
        """
        Collect and validate all case metadata before any evidence is touched.

        Uses CLI arguments where provided; falls back to interactive prompts
        for any missing required field. This hybrid approach supports both
        scripted batch investigations (all args supplied) and guided interactive
        use (field-by-field prompting for new investigators).

        After collecting all fields, prints a full summary and requires the
        investigator to type 'YES' (exact, case-sensitive) before proceeding.
        This confirmation gate is recorded in the CoC log.

        The CustodyLogger is initialized here — it requires case_id and
        output_dir, which are only known after this method completes.

        Raises
        ------
        RuntimeError   If authenticate() has not been called first.
        ValueError     If any field fails validation.
        SystemExit     If the investigator declines the confirmation gate.
        """
        if self._investigator is None:
            raise RuntimeError("Authentication must complete before case intake.")

        print(f"\nAuthenticated: {self._investigator['name']} ({self._investigator['badge']})")
        print("=" * 62)
        print("CASE INTAKE\n")

        # Case ID — prefer CaseConfig, then CLI, then interactive
        raw_case_id = getattr(args, "case_id", None)
        if not raw_case_id and self._case_config:
            raw_case_id = self._case_config.case_number
        if not raw_case_id:
            raw_case_id = self._prompt_or_fail("Case ID (e.g. CASE-2026-001): ", "case_id")
        self._case_id = _validate_case_id(raw_case_id)

        # Profile — prefer CLI, then CaseConfig, then interactive menu
        raw_profile = getattr(args, "profile", None)
        if not raw_profile and self._case_config:
            raw_profile = self._case_config.investigation_profile or ""
        if not raw_profile:
            raw_profile = self._prompt_profile_selection()
        self._profile_name = _sanitize(raw_profile, "Profile")

        # Evidence source — prefer explicit CLI selection, then CaseConfig.
        # --prompt-evidence-source deliberately ignores evidence paths declared in
        # the case JSON for this run and shows the normal live/existing source menu.
        # This lets a reusable administrative case file avoid re-entering names,
        # dates and attachments while still requiring the examiner to choose the
        # actual source interactively after authentication.
        raw_device     = getattr(args, "device", None)
        raw_image_path = getattr(args, "image_path", None)
        prompt_evidence_source = bool(getattr(args, "prompt_evidence_source", False))

        if prompt_evidence_source and (raw_device or raw_image_path):
            raise ValueError(
                "--prompt-evidence-source cannot be combined with --device or --image-path"
            )

        if (
            not prompt_evidence_source
            and not raw_device
            and not raw_image_path
            and self._case_config
        ):
            valid_items = [e for e in self._case_config.evidence_items if e.path]
            if valid_items:
                print(f"\n  [AUTO  ] Loading {len(valid_items)} evidence item(s) from case config:")
                for item in valid_items:
                    candidate = _validate_path(
                        item.path, f"Evidence '{item.label}'", must_exist=True, must_be_file=False
                    )
                    evidence_kind = _classify_evidence_path(
                        candidate,
                        getattr(item, "evidence_type", ""),
                        self._profile_name or "",
                    )
                    self._config_evidence_paths.append(candidate)
                    self._config_evidence_options[str(candidate.resolve())] = {
                        "evidence_type": evidence_kind,
                        "device_type": str(getattr(item, "device_type", "") or "").lower(),
                    }
                    print(f"            [{item.label}] {candidate} ({evidence_kind})")
                # _image_path is set per-evidence inside _run_single_evidence();
                # setting it to [0] here would prevent images 1..N from running.
                self._evidence_source = "existing_image"

        if prompt_evidence_source:
            # Never silently reuse a path from the JSON when an examiner asked
            # for the source-selection menu. Clear any residual state first.
            self._config_evidence_paths = []
            self._config_evidence_options = {}
            raw_device, raw_image_path = self._prompt_evidence_source()
        elif not raw_device and not raw_image_path and not self._config_evidence_paths:
            raw_device, raw_image_path = self._prompt_evidence_source()

        if raw_device:
            self._device_path    = _validate_path(
                raw_device, "Device path", must_exist=True
            )
            self._evidence_source = "live_device"
        elif raw_image_path:
            candidate = _validate_path(
                raw_image_path, "Evidence source", must_exist=True, must_be_file=False
            )
            declared_type = str(getattr(args, "evidence_type", "") or "")
            self._evidence_kind = _classify_evidence_path(
                candidate, declared_type, self._profile_name or ""
            )
            self._image_path      = candidate
            self._evidence_source = "existing_image"

        # Output directory — from CLI or default <output_dir>/<case_id>
        raw_output = getattr(args, "output_dir", None)
        if raw_output:
            self._case_output_dir = _validate_path(
                raw_output, "Output directory", must_exist=False
            )
        else:
            self._case_output_dir = (self._output_dir / self._case_id).resolve()

        self._case_output_dir.mkdir(parents=True, exist_ok=True)
        # 0o700 — case output must not be readable by other users on the system
        os.chmod(self._case_output_dir, 0o700)

        # Now that we have case_id, configure the full platform logger
        self._logger = _setup_platform_logger(self._case_output_dir, self._case_id)

        # Initialize the CoC logger — first entries are written immediately below
        self._coc = CustodyLogger(
            output_dir      = self._case_output_dir,
            case_id         = self._case_id,
            investigator_id = self._investigator["id"],
        )

        # Record the full investigation context in the first CoC entries
        self._coc.log(
            event_type  = EventType.INVESTIGATION_STARTED,
            description = (
                f"Investigation started by {self._investigator['name']} "
                f"({self._investigator['badge']}) using profile '{self._profile_name}'"
            ),
            metadata = {
                "investigator_name":  self._investigator["name"],
                "investigator_badge": self._investigator["badge"],
                "investigator_role":  self._investigator["role"],
                "profile":            self._profile_name,
                "platform_version":   VERSION,
            },
        )

        self._coc.log(
            event_type  = EventType.AUTH_SUCCESS,
            description = (
                f"Investigator '{self._investigator['id']}' authenticated successfully"
            ),
            metadata = {"investigator_id": self._investigator["id"]},
        )

        self._coc.log(
            event_type  = EventType.CASE_REGISTERED,
            description = (
                f"Case '{self._case_id}' registered with profile '{self._profile_name}'"
            ),
            metadata = {
                "case_id":         self._case_id,
                "profile":         self._profile_name,
                "evidence_source": self._evidence_source,
                "output_dir":      str(self._case_output_dir),
            },
        )

        # Administrative files are separate from forensic findings.  When
        # supplied, retain immutable hashed copies inside the case output and
        # update the report configuration to those copies. Missing records remain
        # explicit placeholders and never become synthetic documents/signatures.
        try:
            from core.administrative_attachments import ingest_administrative_attachments
            self._administrative_attachments = ingest_administrative_attachments(
                self._case_config, self._case_output_dir, self._coc
            )
            if self._administrative_attachments.get("errors"):
                self._logger.warning(
                    "Administrative attachment intake reported %d error(s)",
                    len(self._administrative_attachments["errors"]),
                )
        except Exception as exc:
            self._administrative_attachments = {
                "administratively_complete": False,
                "errors": [{"error": str(exc)}],
                "missing": ["administrative attachment intake failed"],
            }
            self._logger.warning("Administrative attachment intake failed: %s", exc)

        self._print_case_summary()
        self._require_confirmation()

    def _prompt_profile_selection(self) -> str:
        """
        Interactively prompt the investigator to select an investigation profile.

        Reads available profiles from the module config so the menu always
        reflects what is actually configured — it never shows stale hardcoded names.
        Falls back to a hardcoded default list if the config cannot be read.
        """
        try:
            config   = self._load_module_config()
            profiles = list(config.get("profiles", {}).keys())
        except Exception:
            # Graceful fallback — config read errors are reported in load_modules()
            profiles = ["usb", "image", "memory", "mobile", "full"]

        print("\nAvailable investigation profiles:")
        for i, name in enumerate(profiles, start=1):
            print(f"  [{i}] {name}")

        raw = self._prompt_or_fail("Select profile number or name: ", "profile").lower()

        # Accept text name directly (case-insensitive)
        for name in profiles:
            if raw == name.lower():
                return name

        # Accept integer index
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(profiles):
                return profiles[idx]
        except ValueError:
            pass

        raise ValueError(
            f"Invalid profile selection '{raw}'. "
            f"Enter a number 1-{len(profiles)} or one of: {', '.join(profiles)}"
        )

    def _prompt_evidence_source(self) -> tuple[Optional[str], Optional[str]]:
        """
        Interactively ask whether the investigator has a live device or an existing image.

        Returns (device_path_str, None) for live device, or (None, None) for existing
        images — the image case calls _collect_image_paths() which fully validates and
        stores every path, so nothing is left for the caller to handle.
        """
        print(
            "\nEvidence source:\n"
            "  [1] Live device  (USB / SSD / HDD — will be imaged first)\n"
            "  [2] Existing evidence source  (disk image / memory / PCAP / mobile extraction)"
        )
        choice = self._prompt_or_fail("Choice: ", "evidence_source")
        if choice == "1":
            return str(self._prompt_live_device_selection()), None
        elif choice == "2":
            paths = self._collect_image_paths()
            self._config_evidence_paths = paths
            self._image_path            = paths[0]
            self._evidence_source       = "existing_image"
            return None, None
        else:
            raise ValueError(f"Invalid evidence source selection: '{choice}'")

    def _prompt_live_device_selection(self) -> Path:
        """List attached disks safely and require explicit whole-device selection.

        The system, project and output disks are visibly excluded.  The first
        detected disk is never selected automatically.
        """
        from core.acquisition import discover_devices
        devices = discover_devices(output_dir=self._output_dir, project_root=_PROJECT_ROOT)
        print("\nAttached storage devices:")
        selectable = []
        for idx, dev in enumerate(devices, 1):
            reasons = list(dev.exclusion_reasons)
            if dev.mountpoints:
                reasons.append("mounted: " + ", ".join(dev.mountpoints))
            status = "EXCLUDED — " + "; ".join(reasons) if reasons else "AVAILABLE FOR EXPLICIT SELECTION"
            size_gb = dev.size_bytes / 1_000_000_000 if dev.size_bytes else 0
            print(
                f"  [{idx}] {dev.path} | {size_gb:.2f} GB | "
                f"{dev.vendor} {dev.model} | serial={dev.serial or 'unknown'} | "
                f"transport={dev.transport or 'unknown'} | {status}"
            )
            selectable.append(dev)
        if not selectable:
            raise RuntimeError("No whole-disk devices were returned by lsblk.")
        raw = self._prompt_or_fail("Select the exact device number or /dev path: ", "device")
        chosen = None
        if raw.isdigit() and 1 <= int(raw) <= len(selectable):
            chosen = selectable[int(raw) - 1]
        else:
            chosen = next((d for d in selectable if d.path == raw), None)
        if chosen is None:
            raise ValueError(f"Unknown device selection: {raw}")
        if chosen.exclusion_reasons:
            raise RuntimeError(f"Refusing {chosen.path}: {', '.join(chosen.exclusion_reasons)}")
        print("\nSELECTED EVIDENCE DEVICE — REVIEW CAREFULLY")
        print(f"  Path:       {chosen.path}")
        print(f"  Vendor:     {chosen.vendor or 'unknown'}")
        print(f"  Model:      {chosen.model or 'unknown'}")
        print(f"  Serial:     {chosen.serial or 'unknown'}")
        print(f"  Size:       {chosen.size_bytes} bytes")
        print(f"  Transport:  {chosen.transport or 'unknown'}")
        confirm = self._prompt_or_fail(
            f"Type ACQUIRE-{Path(chosen.path).name} to confirm this source: ",
            "device_confirmation",
        )
        if confirm != f"ACQUIRE-{Path(chosen.path).name}":
            raise RuntimeError("Evidence-device selection was not confirmed.")
        self._selected_device_info = chosen
        return Path(chosen.path)

    def _collect_image_paths(self) -> list[Path]:
        """
        Prompt the investigator for one or more evidence image paths, one per line.

        Each path is validated immediately: it must exist on disk and carry a
        supported image extension.  Invalid entries are rejected with an error
        message and the same path number is re-shown.  The loop ends when the
        investigator submits a blank line (at least one path must be accepted
        first).

        Returns a non-empty list of resolved, validated Path objects.
        """
        print("\nEvidence image paths (one per line, blank line to finish):")
        collected: list[Path] = []
        n = 1
        while True:
            raw = self._prompt_or_fail(f"  Path {n}: ", "evidence_path")
            if not raw:
                if not collected:
                    print("    At least one evidence path is required.")
                    continue
                break
            try:
                candidate = _validate_path(
                    raw, f"Path {n}", must_exist=True, must_be_file=False
                )
                kind = _classify_evidence_path(candidate, "", self._profile_name or "")
                self._config_evidence_options[str(candidate.resolve())] = {
                    "evidence_type": kind,
                    "device_type": "",
                }
            except ValueError as exc:
                print(f"    [ERROR] {exc}")
                continue
            collected.append(candidate)
            print(f"    [OK] {candidate.name} accepted ({kind})")
            n += 1
        return collected

    def _print_case_summary(self) -> None:
        """Print a full, human-readable investigation summary before the confirmation gate."""
        if self._config_evidence_paths:
            lines = "\n".join(
                f"  [{i + 1}] {p}" for i, p in enumerate(self._config_evidence_paths)
            )
            evidence_block = (
                f"Evidence Items:   {len(self._config_evidence_paths)}\n{lines}"
            )
        else:
            path_str = (
                str(self._device_path)
                if self._evidence_source == "live_device"
                else str(self._image_path)
            )
            evidence_block = f"Evidence Path:    {path_str}"
        print(f"""
{'=' * 62}
INVESTIGATION SUMMARY — REVIEW CAREFULLY BEFORE CONFIRMING
{'=' * 62}
Case ID:          {self._case_id}
Investigator:     {self._investigator['name']} ({self._investigator['badge']})
Role:             {self._investigator['role']}
Profile:          {self._profile_name}
Evidence Source:  {self._evidence_source.replace('_', ' ').title()}
{evidence_block}
Output Directory: {self._case_output_dir}
Timestamp (UTC):  {datetime.now(timezone.utc).isoformat(timespec='milliseconds')}
{'=' * 62}

The chain of custody log is now ACTIVE. Every action from this point
forward is permanently recorded. Once imaging begins, it cannot be undone.
""")

    @staticmethod
    def _resolve_non_interactive(args: argparse.Namespace) -> bool:
        """True when the run must never block on a console prompt (Phase 1f).

        Non-interactive is asserted by an explicit --non-interactive flag
        (forwarded by run.py as the AUTOFORENSICS_NON_INTERACTIVE env var, since
        run.py consumes the flag before core.main parses its own args), by that
        env var set directly, or by the absence of an attached TTY on stdin.
        """
        if getattr(args, "non_interactive", False):
            return True
        if os.environ.get("AUTOFORENSICS_NON_INTERACTIVE", "").strip().lower() in (
            "1", "true", "yes", "on"
        ):
            return True
        try:
            return not sys.stdin.isatty()
        except Exception:
            return False

    def _acquire_credentials(
        self, args: argparse.Namespace
    ) -> tuple[Optional[str], Optional[str]]:
        """Resolve (investigator_id, password) for authentication.

        In non-interactive mode BOTH must arrive without a prompt — the id from
        --investigator-id or AUTOFORENSICS_INVESTIGATOR_ID, the password from
        AUTOFORENSICS_PASSWORD.  When either is missing the run fails closed
        (returns (None, None)) instead of blocking on input()/getpass().  In
        interactive mode the prompts are used as before.
        """
        investigator_id = (
            getattr(args, "investigator_id", None)
            or os.environ.get("AUTOFORENSICS_INVESTIGATOR_ID")
        )
        if self._non_interactive:
            password = os.environ.pop("AUTOFORENSICS_PASSWORD", None)
            if not investigator_id or password is None:
                missing = []
                if not investigator_id:
                    missing.append("--investigator-id / AUTOFORENSICS_INVESTIGATOR_ID")
                if password is None:
                    missing.append("AUTOFORENSICS_PASSWORD")
                print(
                    "\nFATAL: running non-interactively but authentication "
                    "credentials were not supplied: " + ", ".join(missing) + ".\n"
                    "Remove --non-interactive to type the investigator password manually, "
                    "or set AUTOFORENSICS_PASSWORD for an unattended authorised run.",
                    file=sys.stderr,
                )
                return (None, None)
            return (investigator_id.strip(), password)

        # Interactive: prompt for anything not already supplied. run.py may have
        # already verified the credential in its investigator-account gate; consume
        # the in-process password once and immediately remove it from the environment.
        if not investigator_id:
            investigator_id = input("Investigator ID: ").strip()
        password = os.environ.pop("AUTOFORENSICS_PASSWORD", None)
        if password is None:
            # getpass.getpass() reads the password without echoing it to the terminal.
            password = getpass.getpass("Password: ")
        return (investigator_id, password)

    def _require_confirmation(self) -> None:
        """
        Require the investigator to type 'YES' exactly before any evidence is touched.

        Accepting only the exact string 'YES' (case-sensitive, no leading/trailing
        spaces, no variations) ensures the confirmation is deliberate. A reflex
        'y' or 'yes' is rejected. This protects against accidental investigation
        starts and creates a human decision point in the CoC log.

        In non-interactive mode (Phase 1f) there is no operator at the console:
        the confirmation gate is auto-accepted and recorded as such in the CoC,
        because the operator already authorised the batch run explicitly via
        --non-interactive together with a case configuration.
        """
        if getattr(self, "_non_interactive", False):
            self._logger.info(
                "Confirmation gate auto-accepted (running non-interactively)."
            )
            if self._coc:
                self._coc.log(
                    event_type  = EventType.CASE_REGISTERED,
                    description = (
                        "Confirmation gate auto-accepted under --non-interactive; "
                        "investigation is now active"
                    ),
                )
            return

        response = input("Type YES (exactly, in capitals) to begin: ").strip()

        if response != "YES":
            self._logger.warning("Investigation cancelled at confirmation gate.")
            if self._coc:
                self._coc.log(
                    event_type  = EventType.ERROR,
                    description = "Investigation cancelled by investigator at confirmation gate",
                )
            raise SystemExit("Investigation cancelled. No evidence was touched.")

        self._coc.log(
            event_type  = EventType.CASE_REGISTERED,
            description = "Investigator confirmed the displayed case configuration and started the investigation",
        )

    # ──────────────────────────────────────────────────────────────────────
    # Phase 3 — Write Block Verification
    # ──────────────────────────────────────────────────────────────────────

    def verify_write_block(self) -> bool:
        """Apply and verify forensic write protection for an attached device.

        Hardware blockers are supported when their details are supplied in the
        environment.  When no hardware blocker is available, the platform uses
        an explicitly labelled software read-only fallback: mounted partitions
        are unmounted, the kernel read-only flag is set on the whole device and
        every child, and both ioctl/sysfs state and mount state are verified.
        No write attempt is made against real evidence.
        """
        if self._evidence_source != "live_device":
            return True
        if self._device_path is None or self._case_output_dir is None:
            raise RuntimeError("Live device and output directory must be selected before write protection.")
        from core.acquisition import select_device, prepare_write_protection, AcquisitionError
        method = os.environ.get("AUTOFORENSICS_WRITE_BLOCK_METHOD", "software").strip().lower()
        hardware = {
            "manufacturer": os.environ.get("AUTOFORENSICS_BLOCKER_MANUFACTURER", ""),
            "model": os.environ.get("AUTOFORENSICS_BLOCKER_MODEL", ""),
            "serial_number": os.environ.get("AUTOFORENSICS_BLOCKER_SERIAL", ""),
            "firmware_version": os.environ.get("AUTOFORENSICS_BLOCKER_FIRMWARE", ""),
            "connection_type": os.environ.get("AUTOFORENSICS_BLOCKER_CONNECTION", ""),
        }
        try:
            info = select_device(
                self._device_path,
                output_dir=self._case_output_dir,
                project_root=_PROJECT_ROOT,
                allow_regular_file_test=False,
            )
            protection = prepare_write_protection(
                info, requested_method=method, hardware_blocker=hardware,
            )
        except AcquisitionError as exc:
            if self._coc:
                self._coc.log(
                    event_type=EventType.WRITE_BLOCK_UNVERIFIED,
                    description=f"Attached-device acquisition stopped: {exc}",
                    evidence_path=str(self._device_path),
                )
            raise RuntimeError(str(exc)) from exc
        self._selected_device_info = info
        self._write_protection_record = protection
        if self._coc:
            self._coc.log(
                event_type=EventType.DEVICE_DETECTED,
                description=f"Evidence device explicitly selected: {info.path}",
                evidence_path=info.path,
                metadata={
                    "vendor": info.vendor, "model": info.model, "serial": info.serial,
                    "firmware": info.firmware_revision, "transport": info.transport,
                    "size_bytes": info.size_bytes, "logical_sector_size": info.logical_sector_size,
                    "physical_sector_size": info.physical_sector_size,
                    "partition_table": info.partition_table,
                },
            )
            self._coc.log(
                event_type=EventType.WRITE_BLOCK_VERIFIED,
                description=(
                    f"Write protection verified for {info.path} using "
                    f"{protection.effective_method}"
                ),
                evidence_path=info.path,
                metadata={
                    "requested_method": protection.requested_method,
                    "effective_method": protection.effective_method,
                    "verification_method": protection.verification_method,
                    "hardware_blocker": protection.hardware_blocker,
                    "limitations": protection.limitations,
                },
            )
        self._logger.info(
            "Write protection VERIFIED for %s using %s",
            info.path, protection.effective_method,
        )
        return True

    # ──────────────────────────────────────────────────────────────────────
    # Phase 4 — Evidence Acquisition
    # ──────────────────────────────────────────────────────────────────────

    def acquire_evidence(self) -> Path:
        """Accept a supplied evidence source or acquire an attached device safely."""
        if self._evidence_source == "existing_image":
            self._evidence_path = self._image_path
            self._logger.info("Using pre-existing evidence image: %s", self._evidence_path)
            self._coc.log(
                event_type=EventType.EVIDENCE_ACCEPTED,
                description=f"Pre-existing image accepted as evidence: {self._evidence_path}",
                evidence_path=str(self._evidence_path),
                metadata={
                    "file_size_bytes": self._evidence_path.stat().st_size,
                    "format": self._evidence_path.suffix.lower(),
                    "acquisition_performed_by_platform": False,
                },
            )
            return self._evidence_path

        if self._selected_device_info is None or self._write_protection_record is None:
            raise RuntimeError("Write protection must be verified before attached-device acquisition.")
        from core.acquisition import acquire_device, AcquisitionError
        acquisition_format = os.environ.get("AUTOFORENSICS_ACQUISITION_FORMAT", "e01").strip().lower()
        evidence_id = os.environ.get("AUTOFORENSICS_EVIDENCE_ID", "EX-001").strip() or "EX-001"
        investigator = str((self._investigator or {}).get("name") or (self._investigator or {}).get("id") or "Examiner")
        images_dir = self._case_output_dir / "acquisition"
        try:
            if self._coc:
                self._coc.log(
                    event_type=EventType.IMAGE_STARTED,
                    description=f"Physical attached-device acquisition started from {self._device_path}",
                    evidence_path=str(self._device_path),
                    metadata={
                        "format": acquisition_format,
                        "write_protection": self._write_protection_record.effective_method,
                    },
                )
            record = acquire_device(
                source=self._selected_device_info,
                output_dir=images_dir,
                case_id=self._case_id,
                evidence_id=evidence_id,
                investigator=investigator,
                acquisition_format=acquisition_format,
                write_protection=self._write_protection_record,
                description=f"Attached-device acquisition of {self._device_path}",
                notes="AutoForensics acquisition before analysis",
            )
        except AcquisitionError as exc:
            if self._coc:
                self._coc.log(
                    event_type=EventType.ERROR,
                    description=f"Attached-device acquisition failed: {exc}",
                    evidence_path=str(self._device_path),
                )
            raise RuntimeError(str(exc)) from exc
        self._acquisition_record = record
        self._evidence_path = Path(record.image_path)
        if self._coc:
            self._coc.log(
                event_type=EventType.IMAGE_CREATED,
                description=f"Forensic image created and acquisition content verified: {record.image_path}",
                evidence_path=record.image_path,
                metadata={
                    "source_device": record.source.path,
                    "acquisition_format": record.acquisition_format,
                    "acquisition_tool": record.acquisition_tool,
                    "source_pre_sha256": record.source_pre_acquisition_sha256,
                    "source_post_sha256": record.source_post_acquisition_sha256,
                    "source_pre_hash_basis": record.source_pre_hash_basis,
                    "source_post_hash_basis": record.source_post_hash_basis,
                    "acquisition_log": record.acquisition_log_path,
                    "verification_log": record.verification_log_path,
                    "acquired_content_sha256": record.acquired_content_sha256,
                    "source_pre_vs_acquired": record.source_pre_vs_acquired,
                    "source_pre_vs_source_post": record.source_pre_vs_source_post,
                    "container_set_sha256_pre_analysis": record.container_set_sha256_pre_analysis,
                    "logical_media_sha256_pre_analysis": record.logical_media_sha256_pre_analysis,
                    "manifest": record.manifest_path,
                },
            )
        self._logger.info("Acquisition complete and verified: %s", self._evidence_path)
        return self._evidence_path

    def _verify_live_post_analysis_integrity(self) -> None:
        """Re-hash the acquired image after analysis and fail on any change."""
        if self._acquisition_record is None:
            return
        from core.acquisition import verify_post_analysis, AcquisitionError
        try:
            record = verify_post_analysis(self._acquisition_record)
        except AcquisitionError as exc:
            if self._coc:
                self._coc.log(
                    event_type=EventType.HASH_MISMATCH,
                    description=f"Post-analysis acquired-image integrity failure: {exc}",
                    evidence_path=str(self._evidence_path or ""),
                )
            raise RuntimeError(str(exc)) from exc
        self._acquisition_record = record
        if self._coc:
            self._coc.log(
                event_type=EventType.HASH_VERIFIED,
                description="Pre-analysis and post-analysis acquired-image hashes match",
                evidence_path=record.image_path,
                metadata={
                    "container_set_pre": record.container_set_sha256_pre_analysis,
                    "container_set_post": record.container_set_sha256_post_analysis,
                    "container_result": record.pre_vs_post_container_set,
                    "logical_media_pre": record.logical_media_sha256_pre_analysis,
                    "logical_media_post": record.logical_media_sha256_post_analysis,
                    "logical_media_result": record.pre_vs_post_logical_media,
                    "manifest": record.manifest_path,
                },
            )

    # ──────────────────────────────────────────────────────────────────────
    # Phase 5 — Evidence Integrity Verification
    # ──────────────────────────────────────────────────────────────────────

    def _read_ewf_embedded_hashes(self, image_path) -> "dict[str, str]":
        """Read embedded EWF digests without re-hashing the full logical stream."""
        try:
            from core.native_evidence import parse_ewf
            return dict(parse_ewf(image_path).embedded_hashes or {})
        except Exception as exc:
            self._logger.debug("Native EWF digest parsing unavailable: %s", exc)
            return {}

    def _hash_media_stream(self, media_path) -> "tuple[str, str, int]":
        """Hash logical media bytes without sudo, mount, or container-byte confusion."""
        from core.native_evidence import hash_media_stream
        result = hash_media_stream(media_path)
        return str(result["sha256"]), str(result["md5"]), int(result["size_bytes"])

    def verify_evidence_integrity(
        self, expected_hash: Optional[str] = None
    ) -> str:
        """Hash reconstructed media, compare embedded digests, and self-test the claim."""
        if self._evidence_path is None:
            raise RuntimeError("Evidence path is not set. Call acquire_evidence() first.")

        from core.native_evidence import hash_media_stream, independent_sha256

        # Hash the original supplied container separately from the logical media.
        # For raw images the two values are naturally identical; for E01/Ex01 they
        # intentionally differ and both are retained.
        try:
            _c_md5, _c_sha1, _c_sha256, _c_basis = self._hash_evidence_source(Path(self._evidence_path))
            self._source_container_md5 = _c_md5
            self._source_container_sha1 = _c_sha1
            self._source_container_sha256 = _c_sha256
            self._source_container_size_bytes = int(_c_basis.get("source_size_bytes") or 0)
            self._source_container_hash_basis = str(_c_basis.get("hash_basis") or "source-file-bytes")
        except Exception as _container_hash_exc:
            self._logger.warning("Could not hash source container separately: %s", _container_hash_exc)

        media_path = getattr(self, "_analysis_path", None) or self._evidence_path
        self._logger.info(
            "Computing native MD5/SHA-1/SHA-256 over logical media stream %s",
            media_path,
        )
        try:
            result = hash_media_stream(media_path)
        except Exception as exc:
            raise RuntimeError(f"Cannot reconstruct/hash evidence media: {exc}") from exc

        computed = str(result["sha256"])
        computed_md5 = str(result["md5"])
        file_size = int(result["size_bytes"])
        # For a platform-acquired image, libewf already produced an independent
        # logical-media SHA-256 during acquisition verification. Reuse that
        # cross-implementation reference instead of reading the entire media a
        # second time before analysis. Existing-image mode retains the historical
        # deliberately different second native pass.
        if self._acquisition_record is not None and self._acquisition_record.acquired_content_sha256:
            second = str(self._acquisition_record.acquired_content_sha256)
            self_test_basis = "libewf ewfverify acquisition reference"
        else:
            second = independent_sha256(media_path)
            self_test_basis = "independent native SHA-256 pass"
        if not hmac.compare_digest(computed, second):
            if self._coc:
                self._coc.log(
                    event_type=EventType.HASH_MISMATCH,
                    description="Independent evidence-hash self-test FAILED",
                    evidence_path=str(self._evidence_path),
                    metadata={"first_sha256": computed, "independent_sha256": second},
                )
            raise RuntimeError(
                "Evidence hash self-test failed: two independent media-stream passes "
                "produced different SHA-256 values. Top-line hash withheld."
            )

        if expected_hash and not hmac.compare_digest(computed.lower(), expected_hash.lower()):
            if self._coc:
                self._coc.log(
                    event_type=EventType.HASH_MISMATCH,
                    description="Evidence integrity check FAILED — expected hash mismatch",
                    evidence_path=str(self._evidence_path),
                    metadata={
                        "expected_sha256": expected_hash,
                        "computed_sha256": computed,
                        "file_size_bytes": file_size,
                    },
                )
            raise RuntimeError(
                f"Evidence integrity check FAILED. Expected {expected_hash}; computed {computed}."
            )

        # Embedded digests belong to the EWF container while computed hashes
        # belong to the reconstructed media stream. Parse the references from
        # the original evidence path and compare them explicitly.
        embedded = self._read_ewf_embedded_hashes(self._evidence_path)
        computed_by_algo = {
            "md5": computed_md5,
            "sha1": str(result.get("sha1") or ""),
            "sha256": computed,
        }
        bool_matches = {
            algo: hmac.compare_digest(computed_by_algo.get(algo, "").lower(), str(value).lower())
            for algo, value in embedded.items()
            if algo in computed_by_algo and value
        }
        self._evidence_embedded_hashes = embedded
        self._evidence_hash_matches = {
            algo: ("MATCH" if ok else "MISMATCH") for algo, ok in bool_matches.items()
        }
        if any(not ok for ok in bool_matches.values()):
            mismatched = ", ".join(a.upper() for a, ok in bool_matches.items() if not ok)
            self._ewf_hash_note = f"EMBEDDED MEDIA HASH MISMATCH: {mismatched}"
            if self._coc:
                self._coc.log(
                    event_type=EventType.HASH_MISMATCH,
                    description="Reconstructed media does not match embedded EWF digest",
                    evidence_path=str(self._evidence_path),
                    metadata={
                        "computed": {"sha256": computed, "md5": computed_md5, "sha1": result.get("sha1")},
                        "embedded": embedded,
                        "matches": bool_matches,
                    },
                )
            # Do not silently continue as clean, but preserve the run so the
            # mismatch and both comparison inputs are available in the report.
        elif bool_matches:
            self._ewf_hash_note = "; ".join(
                f"{algo.upper()} MATCH" for algo in sorted(bool_matches)
            )
        elif self._evidence_path.suffix.lower() in (".e01", ".ex01"):
            self._ewf_hash_note = "EMBEDDED HASH NOT AVAILABLE"
        else:
            self._ewf_hash_note = "RAW MEDIA — no embedded EWF digest expected"

        if self._coc:
            self._coc.log(
                event_type=EventType.HASH_VERIFIED,
                description=(
                    "Evidence logical-media SHA-256 verified against expected hash"
                    if expected_hash else
                    "Evidence logical-media SHA-256 computed and independently self-tested"
                ),
                evidence_path=str(self._evidence_path),
                metadata={
                    "sha256": computed,
                    "md5": computed_md5,
                    "sha1": result.get("sha1"),
                    "file_size_bytes": file_size,
                    "hash_scope": "logical_media_stream",
                    "independent_sha256": second,
                    "self_test_match": True,
                    "self_test_basis": self_test_basis,
                    "embedded_hashes": embedded,
                    "embedded_hash_matches": bool_matches,
                    "source_container_sha256": self._source_container_sha256,
                    "source_container_md5": self._source_container_md5,
                    "source_container_sha1": self._source_container_sha1,
                },
            )

        self._evidence_hash = computed
        self._evidence_md5 = computed_md5
        self._evidence_sha1 = str(result.get("sha1") or "")
        self._logical_media_size_bytes = file_size
        return computed

    # ──────────────────────────────────────────────────────────────────────
    # Phase 6 — Module Loading
    # ──────────────────────────────────────────────────────────────────────

    def load_modules(self) -> list[dict[str, Any]]:
        """
        Load forensic modules for this investigation from the config registry.

        Primary path (config-driven)
        ----------------------------
        Reads config/modules.yaml, selects the active profile's module list,
        and imports each module in the declared order. Only modules listed in
        the profile AND marked 'active: true' in the module definitions are loaded.
        The config-driven order is authoritative for the CoC log — the reviewing
        board can read exactly which modules ran, in what order.

        Fallback path (auto-discovery)
        -------------------------------
        If 'auto_discovery: true' is set in modules.yaml, the modules/ directory
        is scanned for .py files not already loaded. Any file that exposes a
        callable 'run' function is imported and appended to the pipeline. This
        enables drop-in deployment of new modules without editing the orchestrator.

        Path traversal protection
        --------------------------
        Module file paths from the config are resolved and verified to stay
        inside MODULES_DIR before import. A malicious or misconfigured modules.yaml
        cannot load files from outside the modules/ directory.

        Returns
        -------
        List of loaded module descriptor dicts (also stored as self._modules).
        """
        config = self._load_module_config()

        profiles = config.get("profiles", {})
        if self._profile_name not in profiles:
            raise ValueError(
                f"Profile '{self._profile_name}' not found in modules.yaml. "
                f"Available profiles: {list(profiles.keys())}"
            )

        profile_module_names: list[str] = profiles[self._profile_name].get("modules", [])
        all_module_defs: dict           = config.get("modules", {})
        auto_discover: bool             = config.get("auto_discovery", False)

        loaded: list[dict[str, Any]] = []

        # ── Config-driven loading in declared order ──────────────────────
        # FIX #6: track failed imports separately so the report can list them.
        failed_imports: list[str] = []

        for name in profile_module_names:
            module_def = all_module_defs.get(name)

            if module_def is None:
                self._logger.warning(
                    "Module '%s' is listed in profile '%s' but has no definition — skipped",
                    name, self._profile_name,
                )
                continue

            if not module_def.get("active", True):
                self._logger.info("Module '%s' is disabled (active: false) — skipped", name)
                self._coc.log(
                    event_type  = EventType.MODULE_SKIPPED,
                    description = f"Module '{name}' skipped — disabled in config",
                    metadata    = {"module": name, "reason": "active: false"},
                )
                continue

            mod_obj = self._import_module(name, module_def)
            if mod_obj is None:
                # _import_module already logged to self._logger and CoC
                failed_imports.append(name)
                # Synthetic result entry so the banner counter reflects the truth
                self._import_failed_results.append({
                    "module":           name,
                    "start_time":       None,
                    "end_time":         None,
                    "duration_seconds": 0.0,
                    "status":           ModuleStatus.IMPORT_FAILED.value,
                    "error":            f"Import failed — see platform log for traceback",
                    "output_dir":       None,
                    "findings":         [],
                })
                continue

            loaded.append({
                "name":   name,
                "module": mod_obj,
                "config": module_def,
                "source": "registry",
            })
            self._coc.log(
                event_type  = EventType.MODULE_LOADED,
                description = f"Module '{name}' loaded from registry",
                metadata    = {"module": name, "source": "registry"},
            )

        # ── Auto-discovery fallback ──────────────────────────────────────
        if auto_discover:
            already_loaded = {m["name"] for m in loaded}
            for discovered in self._discover_modules(already_loaded, all_module_defs):
                loaded.append(discovered)
                self._coc.log(
                    event_type  = EventType.MODULE_LOADED,
                    description = f"Module '{discovered['name']}' loaded via auto-discovery",
                    metadata    = {"module": discovered["name"], "source": "auto_discovery"},
                )

        self._modules = loaded
        self._logger.info(
            "Module loading complete: %d loaded, %d failed-to-import for profile '%s'",
            len(loaded), len(failed_imports), self._profile_name,
        )

        print(f"\n{'='*62}")
        print(f"  MODULES LOADED — {len(loaded)} for profile '{self._profile_name}'")
        for m in loaded:
            print(f"    [OK  {m['source']:12s}] {m['name']}")
        # FIX #6: show failed imports explicitly so they're visible in the terminal log
        for fname in failed_imports:
            print(f"    [FAIL import     ] {fname}")
        if failed_imports:
            print(f"  WARNING: {len(failed_imports)} module(s) failed to import — "
                  "check platform log for tracebacks")
        print(f"{'='*62}\n")

        # Quick binary dependency check at startup
        _deps_to_check = [
            ("ewfmount",       "binary"), ("fls",        "binary"),
            ("mmls",           "binary"), ("istat",       "binary"),
            ("tsk_recover",    "binary"),
            ("bulk_extractor", "binary"), ("clamscan",    "binary"),
            ("hashcat",        "binary"), ("john",        "binary"),
            ("exiftool",       "binary"), ("dbxconv",     "binary"),
        ]
        import shutil as _sh
        print("\n  Dependency check:")
        _missing: set[str] = set()
        for _dep, _type in _deps_to_check:
            _present = _sh.which(_dep) is not None
            print(f"    {'OK  ' if _present else 'MISS'} {_dep}")
            if not _present:
                _missing.add(_dep)
        # Volatility 3 may be installed as /opt/volatility3/vol.py, a wrapper,
        # or the Python module entry point. Treat all supported forms equally.
        try:
            from tools.capability_gate import _volatility_path as _af_volatility_path
            _vol_path = _af_volatility_path()
        except Exception:
            _vol_path = ""
        print(f"    {'OK  ' if _vol_path else 'MISS'} volatility3" + (f"  ({_vol_path})" if _vol_path else ""))
        if not _vol_path:
            _missing.add("volatility3")
        self._missing_tools: set[str] = _missing
        print()

        # Detect versions of all forensic tools once at startup
        self._tool_versions = populate_tool_versions()

        return loaded

    def _load_module_config(self) -> dict:
        """Load and parse modules.yaml. Raises RuntimeError on any failure."""
        if not MODULE_CONFIG_PATH.exists():
            raise RuntimeError(
                f"Module config not found at {MODULE_CONFIG_PATH}. "
                "Create config/modules.yaml before running an investigation."
            )
        try:
            with open(MODULE_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
        except (yaml.YAMLError, OSError) as exc:
            raise RuntimeError(f"Cannot parse modules.yaml: {exc}") from exc

        if not isinstance(config, dict):
            raise RuntimeError("modules.yaml must be a YAML mapping at the top level.")

        return config

    def _import_module(
        self, module_name: str, module_def: dict
    ) -> Optional[object]:
        """
        Dynamically import a forensic module and verify it exposes 'run'.

        The module file path is resolved relative to MODULES_DIR and then
        checked to confirm it stays inside MODULES_DIR (path traversal guard).
        If the resolved path escapes MODULES_DIR, the module is rejected.

        Returns the imported module object, or None if import fails.
        """
        relative = module_def.get("path", f"{module_name}.py")
        candidate = (MODULES_DIR / relative).resolve()

        # Path traversal guard — a crafted 'path' value like '../../etc/passwd'
        # would resolve outside MODULES_DIR; we reject it here.
        try:
            candidate.relative_to(MODULES_DIR.resolve())
        except ValueError:
            self._logger.error(
                "Module '%s' path '%s' is outside MODULES_DIR — rejected",
                module_name, candidate,
            )
            return None

        if not candidate.exists():
            self._logger.warning(
                "Module '%s' file not found at %s — skipped",
                module_name, candidate,
            )
            return None

        try:
            spec = importlib.util.spec_from_file_location(module_name, candidate)
            # FIX #6: spec can be None if the file has an unrecognised suffix or
            # the path is otherwise invalid — guard before calling loader.
            if spec is None or spec.loader is None:
                self._logger.error(
                    "Module '%s': importlib returned None spec/loader for %s",
                    module_name, candidate,
                )
                return None
            mod = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = mod        # register BEFORE exec so @dataclass can resolve annotations
            try:
                spec.loader.exec_module(mod)
            except Exception:
                sys.modules.pop(spec.name, None)  # don't leave a half-initialised module behind
                raise
        except Exception as exc:
            import traceback as _tb
            tb_str = _tb.format_exc()
            self._logger.error(
                "Failed to import module '%s' from %s: %s\n%s",
                module_name, candidate, exc, tb_str,
            )
            if self._coc:
                try:
                    self._coc.log(
                        event_type  = EventType.MODULE_FAILED,
                        description = f"Module '{module_name}' failed to import: {str(exc)[:500]}",
                        metadata    = {
                            "module":    module_name,
                            "path":      str(candidate),
                            "error":     str(exc)[:1000],
                            "traceback": tb_str[:2000],
                        },
                    )
                except Exception:
                    pass
            return None

        # Every forensic module must expose a callable 'run' — this is the
        # standard interface that allows the orchestrator to invoke any module
        # without knowing its internals.
        if not callable(getattr(mod, "run", None)):
            self._logger.error(
                "Module '%s' does not expose a callable 'run' function — skipped",
                module_name,
            )
            return None

        return mod

    def _discover_modules(
        self,
        already_loaded: set[str],
        registered: dict,
    ) -> list[dict[str, Any]]:
        """
        Scan MODULES_DIR for .py files not already loaded by the registry.

        Skips files starting with '_' (private/utility files) and files that
        are already loaded or defined in the registry (registry has priority).
        """
        discovered: list[dict[str, Any]] = []

        for py_file in sorted(MODULES_DIR.glob("*.py")):
            name = py_file.stem
            # Skip private/utility files and anything already handled
            if name.startswith("_") or name in already_loaded or name in registered:
                continue

            self._logger.info("Auto-discovering module: %s", name)
            module_def = {"path": py_file.name, "active": True, "auto_discovered": True}
            mod_obj    = self._import_module(name, module_def)

            if mod_obj is not None:
                discovered.append({
                    "name":   name,
                    "module": mod_obj,
                    "config": module_def,
                    "source": "auto_discovery",
                })

        return discovered

    # ──────────────────────────────────────────────────────────────────────
    # Evidence mounting helpers (E01 → ewfmount, block device, raw image)
    # ──────────────────────────────────────────────────────────────────────

    def _mount_evidence(self) -> None:
        """Resolve evidence to a readable raw-media path.

        Platform-acquired E01 images prefer libewf's read-only FUSE stream so a
        large image does not have to be materialised as a second full-size RAW
        file. Existing-image mode retains the native reconstruction path for
        compatibility and deterministic regression coverage.
        """
        if self._evidence_path is None:
            return

        self._ewf_mount_point = None
        self._native_media_path = None
        self._analysis_path = None
        self._evidence_access_method = "unresolved"

        import stat as _stat_mod
        try:
            st = os.stat(self._evidence_path)
            if _stat_mod.S_ISBLK(st.st_mode):
                self._analysis_path = self._evidence_path
                self._evidence_access_method = "native_block_stream"
                self._logger.info("[ACCESS] Read-only block stream: %s", self._analysis_path)
                return
        except OSError:
            pass

        suffix = self._evidence_path.suffix.lower()
        if suffix not in (".e01", ".ex01"):
            self._analysis_path = self._evidence_path
            self._evidence_access_method = "native_raw_stream"
            self._logger.info("[ACCESS] Raw media stream: %s", self._analysis_path)
            return

        if self._case_output_dir is None:
            raise RuntimeError("Case output directory is not set before E01 access")

        label = re.sub(r"[^\w.-]", "_", self._evidence_path.stem)[:64]

        # E01 evidence should be exposed through the mature libewf read-only
        # stream regardless of whether it was acquired by AutoForensics or
        # supplied as an existing forensic image.
        if shutil.which("ewfmount"):
            mount_dir = self._case_output_dir / "ewf_mount" / label
            mount_dir.mkdir(parents=True, exist_ok=True)
            cp = subprocess.run(
                ["ewfmount", str(self._evidence_path), str(mount_dir)],
                capture_output=True, text=True, check=False,
            )
            ewf_stream = mount_dir / "ewf1"
            if cp.returncode == 0 and ewf_stream.exists():
                self._ewf_mount_point = mount_dir
                self._analysis_path = ewf_stream
                self._evidence_access_method = "libewf_read_only_stream"
                self._logger.info(
                    "[ACCESS] E01 exposed read-only through libewf without RAW materialisation: %s",
                    ewf_stream,
                )
                if self._coc:
                    self._coc.log(
                        event_type=EventType.EVIDENCE_ACCEPTED,
                        description=(
                            f"E01 exposed as a read-only libewf logical-media stream: {ewf_stream}"
                        ),
                        evidence_path=str(self._evidence_path),
                        metadata={
                            "analysis_path": str(ewf_stream),
                            "access_method": self._evidence_access_method,
                            "raw_materialisation": False,
                            "libewf_mount_point": str(mount_dir),
                        },
                    )
                return
            self._logger.warning(
                "[ACCESS] ewfmount failed for E01 (rc=%s): %s; "
                "falling back to native reconstruction",
                cp.returncode, (cp.stderr or cp.stdout or "")[-1000:],
            )
            try:
                mount_dir.rmdir()
            except OSError:
                pass

        # Existing-image compatibility fallback.
        from core.native_evidence import materialize_media
        raw_path = self._case_output_dir / "native_media" / f"{label}.raw"
        try:
            reconstructed = materialize_media(self._evidence_path, raw_path)
        except Exception as exc:
            raise RuntimeError(
                f"[ACCESS] Native EWF reconstruction failed for {self._evidence_path.name}: {exc}"
            ) from exc

        self._native_media_path = reconstructed
        self._analysis_path = reconstructed
        self._evidence_access_method = "native_ewf_reconstruction"
        self._logger.info("[ACCESS] E01 reconstructed natively: %s", reconstructed)
        if self._coc:
            self._coc.log(
                event_type=EventType.EVIDENCE_ACCEPTED,
                description=f"E01 reconstructed natively as read-only analysis media: {reconstructed}",
                evidence_path=str(self._evidence_path),
                metadata={
                    "analysis_path": str(reconstructed),
                    "access_method": self._evidence_access_method,
                    "sudo_used": False,
                    "os_mount_used": False,
                },
            )

    def _detect_partition_offset_on_mount(self) -> None:
        if self._analysis_path is None:
            return
        from core.partition_offset import detect_partition_offset_mounted
        result = detect_partition_offset_mounted(
            str(self._analysis_path), self._logger
        )
        self._partition_offset = result  # may be -1 if no FS found
        if result >= 0:
            self._logger.info("Partition offset resolved: %d sectors", result)
        else:
            self._logger.warning(
                "Could not resolve partition offset for %s — preflight will fail",
                self._analysis_path,
            )

    def _unmount_evidence(self) -> None:
        """Release native state and any temporary read-only libewf FUSE mount."""
        mount_point = self._ewf_mount_point
        if mount_point is not None:
            unmounted = False
            for command in (
                ["fusermount3", "-u", str(mount_point)],
                ["fusermount", "-u", str(mount_point)],
                ["umount", str(mount_point)],
            ):
                if not shutil.which(command[0]):
                    continue
                cp = subprocess.run(command, capture_output=True, text=True, check=False)
                if cp.returncode == 0:
                    unmounted = True
                    break
            if not unmounted:
                self._logger.warning(
                    "[ACCESS] Could not confirm libewf unmount for %s", mount_point
                )
            try:
                Path(mount_point).rmdir()
                Path(mount_point).parent.rmdir()
            except OSError:
                pass
        self._ewf_mount_point = None
        self._analysis_path = None
        self._native_media_path = None
        self._evidence_access_method = "unresolved"

    def _mount_filesystem(self) -> None:
        """Parse and extract the filesystem natively into a walkable corpus.

        The historical method name is retained for API compatibility. Nothing is
        mounted at the OS level: FAT content and deleted entries are extracted,
        NTFS MFT metadata is parsed, and ext superblocks are recognised with an
        explicit capability caveat.
        """
        self._fs_mount_root = None
        self._native_fs_result = None
        self._fs_mount_is_native = False
        if self._analysis_path is None or self._case_output_dir is None:
            return

        from core.native_filesystem import analyze_and_extract
        label = re.sub(r"[^\w.-]", "_", self._evidence_path.stem)[:64] if self._evidence_path else "exhibit"
        output = self._case_output_dir / "native_filesystem" / label
        try:
            result = analyze_and_extract(self._analysis_path, output)
        except Exception as exc:
            self._logger.warning("[NATIVE-FS] Analysis failed: %s", exc)
            return

        self._native_fs_result = result
        self._fs_mount_is_native = True
        if result.candidate is not None:
            self._partition_offset = result.candidate.offset_sectors

        active_root = result.extracted_root
        if active_root is not None and active_root.is_dir():
            self._fs_mount_root = active_root
        self._logger.info(
            "[NATIVE-FS] %s — %s; active root=%s; deleted root=%s",
            result.status, result.reason, result.extracted_root, result.deleted_root,
        )
        if self._coc:
            self._coc.log(
                event_type=EventType.EVIDENCE_ACCEPTED,
                description=f"Native filesystem analysis: {result.status} — {result.reason}",
                evidence_path=str(self._evidence_path) if self._evidence_path else "",
                metadata=result.as_dict(),
            )

    def _unmount_filesystem(self) -> None:
        """Clear the native corpus reference; no OS unmount operation is needed."""
        self._fs_mount_root = None
        self._native_fs_result = None
        self._fs_mount_is_native = False

    def _run_preflight_self_test(self) -> bool:
        """Verify native filesystem recognition; TSK absence is never fatal."""
        if self._analysis_path is None:
            return True
        from core.native_filesystem import native_preflight
        try:
            ok, candidate, reason = native_preflight(self._analysis_path)
        except Exception as exc:
            self._logger.warning("Native preflight raised: %s", exc)
            return False
        if ok:
            if candidate is not None:
                self._partition_offset = candidate.offset_sectors
            self._logger.info("Preflight PASS (native): %s", reason)
            return True
        self._logger.warning(
            "Preflight FAIL: filesystem not recognised/readable by native path — %s", reason
        )
        return False

    # ──────────────────────────────────────────────────────────────────────
    # Phase 7 — Pipeline Execution
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _hash_evidence_source(path: Path) -> tuple[str, str, str, dict[str, Any]]:
        """Hash a file or a directory extraction without modifying it.

        Files are hashed byte-for-byte. Directories are represented by a
        deterministic manifest containing each relative path, size and content
        SHA-256; the top-level digests cover that canonical manifest.
        """
        if path.is_file():
            md5 = hashlib.md5()
            sha1 = hashlib.sha1()
            sha256 = hashlib.sha256()
            size = 0
            with path.open("rb") as fh:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    size += len(block)
                    md5.update(block)
                    sha1.update(block)
                    sha256.update(block)
            return md5.hexdigest(), sha1.hexdigest(), sha256.hexdigest(), {
                "hash_basis": "source-file-bytes",
                "source_size_bytes": size,
                "file_count": 1,
            }

        if not path.is_dir():
            raise ValueError(f"Evidence source is neither a file nor a directory: {path}")

        manifest: list[dict[str, Any]] = []
        total_size = 0
        for child in sorted((p for p in path.rglob("*") if p.is_file()), key=lambda p: p.relative_to(path).as_posix()):
            rel = child.relative_to(path).as_posix()
            file_hash = hashlib.sha256()
            size = 0
            with child.open("rb") as fh:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    size += len(block)
                    file_hash.update(block)
            total_size += size
            manifest.append({"path": rel, "size": size, "sha256": file_hash.hexdigest()})
        payload = json.dumps(manifest, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
        return (
            hashlib.md5(payload).hexdigest(),
            hashlib.sha1(payload).hexdigest(),
            hashlib.sha256(payload).hexdigest(),
            {
                "hash_basis": "canonical-directory-manifest",
                "source_size_bytes": total_size,
                "file_count": len(manifest),
            },
        )

    def _prepare_non_disk_evidence(self, path: Path, kind: str, device_type: str = "") -> None:
        """Register and hash memory, PCAP or mobile evidence for analysis."""
        self._evidence_path = path
        self._analysis_path = path
        self._evidence_access_method = f"read_only_{kind}_source"
        self._evidence_kind = kind
        self._evidence_device_type = device_type
        md5, sha1, sha256, basis = self._hash_evidence_source(path)
        self._evidence_md5 = md5
        self._evidence_sha1 = sha1
        self._evidence_hash = sha256
        self._source_container_md5 = md5
        self._source_container_sha1 = sha1
        self._source_container_sha256 = sha256
        self._source_container_size_bytes = int(basis.get("source_size_bytes") or 0)
        self._source_container_hash_basis = str(basis.get("hash_basis") or "source-file-bytes")
        self._logical_media_size_bytes = int(basis.get("source_size_bytes") or 0)
        self._evidence_embedded_hashes = {}
        self._evidence_hash_matches = {}
        self._partition_offset = 0
        self._corpus_roots = [str(path)] if path.is_dir() else []
        self._working_set = {
            "evidence_type": kind,
            "device_type": device_type,
            "mounted_fs_root": str(path) if path.is_dir() else None,
            "native_deleted_root": None,
            "offset_sectors": 0,
            "filesystem_type": None,
            "filesystem_execution_outcome": "not_applicable",
            "filesystem_caveats": [f"Filesystem mounting is not applicable to {kind} evidence."],
            "extracted_files_dir": str(path) if path.is_dir() else None,
            "carved_files_dir": None,
            "corpus_roots": list(self._corpus_roots),
            "image_set": [str(path)] if path.is_file() else [],
            "evidence_access_method": self._evidence_access_method,
            "integrity": {"md5": md5, "sha1": sha1, "sha256": sha256, **basis},
        }
        self._coc.log(
            event_type=EventType.EVIDENCE_ACCEPTED,
            description=f"Pre-existing {kind} evidence accepted and hashed read-only: {path}",
            evidence_path=str(path),
            metadata={"evidence_type": kind, "device_type": device_type, "md5": md5, "sha1": sha1, "sha256": sha256, **basis},
        )
        self._coc.log(
            event_type=EventType.HASH_VERIFIED,
            description=f"{kind.capitalize()} evidence integrity digests computed",
            evidence_path=str(path),
            metadata={"md5": md5, "sha1": sha1, "sha256": sha256, "reference_hash_present": False, **basis},
        )

    def _module_applicable(self, module_name: str, module_config: dict[str, Any]) -> tuple[bool, str]:
        """Return whether a module is relevant to the current evidence domain."""
        kind = self._evidence_kind or "disk"
        category = str(module_config.get("category") or "").lower()
        # A disk image that merely contains memory-marker files is not a RAM
        # acquisition.  Volatility/process/socket/malfind/rootkit modules are
        # therefore NOT APPLICABLE unless the evidence inventory classified at
        # least one nested source as structurally supported memory evidence.
        if kind == "disk":
            genuine_memory = bool((self._working_set or {}).get("nested_memory_sources"))
            marker_memory = bool((self._working_set or {}).get("nested_memory_marker_sources"))
            memory_structural = {
                "memory_process_list", "memory_network_connections",
                "memory_artifact_extractor", "memory_malware_scanner",
                "rootkit_detector",
            }
            if module_name in memory_structural and not (genuine_memory or marker_memory):
                return False, (
                    "NOT APPLICABLE — exhaustive inventory found neither a genuine supported RAM image "
                    "nor a structured memory-marker source for this module"
                )
            # Marker-only sources execute the module's deterministic literal-record
            # scope. They never impersonate Volatility or kernel-structure analysis.
            return True, ""
        common = {
            "evidence_validator", "string_extractor", "keyword_search",
            "yara_scanner", "native_malware_scanner", "clamav_scanner",
            "suspicious_file_detector", "ioc_matcher",
        }
        allowed: dict[str, set[str]] = {
            "memory": common | {
                "memory_process_list", "memory_network_connections",
                "memory_artifact_extractor", "memory_malware_scanner",
                "memory_string_analyzer", "rootkit_detector",
            },
            "network": common | {
                "pcap_analyzer", "network_protocol_decoder", "dns_analyzer",
                "http_reconstructor",
            },
            "mobile": common | {
                "mobile_analyzer", "artifact_extractor", "browser_history_analyzer",
                "email_communications_analyzer", "exiftool_metadata",
                "ocr_text_extractor", "document_analyzer", "geolocation_extractor",
                "image_content_analyzer", "steganography_detector",
                "file_signature_analyzer", "hash_database_match",
            },
        }
        if module_name in allowed.get(kind, set()):
            return True, ""
        # Category-level allowance supports future modules without hard-coding
        # case artefacts or filenames.
        category_allow = {
            "memory": {"memory_analysis"},
            "network": {"network_analysis"},
            "mobile": {"mobile_analysis", "metadata_analysis"},
        }
        if category in category_allow.get(kind, set()):
            return True, ""
        return False, f"Not applicable to {kind} evidence"

    def _run_single_evidence(
        self,
        ev_path: Path,
        ev_idx: int,
        expected_hash: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """
        Run the full acquire → verify → mount → pipeline → unmount cycle for one
        evidence image.  Called once per item in self._config_evidence_paths.

        Resets all per-evidence state before each run so nothing from image N
        can bleed into image N+1.  Appends one record to self._all_evidence_results
        regardless of success or failure so the report always sees every image.

        Per-image per-module isolation: a module failing on this image does not
        abort execution for other images — execute_pipeline() already wraps each
        module in its own try/except.  A preflight failure for this image is
        logged and skipped; the next image continues independently.

        # The evidence path is reconstructed/read natively.  External EWF/TSK
        # tools may verify results when present but are not required here.
        """
        total = len(self._config_evidence_paths)
        label = ev_path.name

        print(f"\n{'='*62}")
        print(f"  EVIDENCE {ev_idx + 1}/{total}: {label}")
        print(f"{'='*62}")
        self._logger.info(
            "[EVIDENCE %d/%d] Starting: %s", ev_idx + 1, total, label
        )

        # ── Reset per-evidence state ──────────────────────────────────────
        self._evidence_path    = None
        self._evidence_hash    = None
        self._evidence_md5     = None
        self._evidence_sha1    = None
        self._source_container_sha256 = None
        self._source_container_md5 = None
        self._source_container_sha1 = None
        self._source_container_size_bytes = 0
        self._source_container_hash_basis = ""
        self._logical_media_size_bytes = 0
        self._evidence_embedded_hashes = {}
        self._evidence_hash_matches    = {}
        self._analysis_path    = None
        self._ewf_mount_point  = None
        self._fs_mount_root    = None
        self._partition_offset = 0
        self._module_results   = []

        # Point this run at the current evidence source and classify it.
        self._image_path      = ev_path
        self._evidence_source = "existing_image"
        _options = self._config_evidence_options.get(str(ev_path.resolve()), {})
        self._evidence_kind = _classify_evidence_path(
            ev_path,
            _options.get("evidence_type", ""),
            self._profile_name or "",
        )
        self._evidence_device_type = str(_options.get("device_type", "") or "")

        # Memory images, PCAP files and mobile extractions are first-class
        # evidence sources. They are hashed directly and routed to the relevant
        # modules without pretending they contain a mountable disk filesystem.
        if self._evidence_kind != "disk":
            try:
                self._prepare_non_disk_evidence(
                    ev_path, self._evidence_kind, self._evidence_device_type
                )
                self.execute_pipeline(evidence_idx=ev_idx)
                ev_record = {
                    "evidence_idx": ev_idx,
                    "evidence_path": str(self._evidence_path),
                    "evidence_type": self._evidence_kind,
                    "device_type": self._evidence_device_type,
                    "evidence_hash": self._evidence_hash,
                    "md5": self._evidence_md5,
                    "sha1": self._evidence_sha1,
                    "sha256": self._evidence_hash,
                    "embedded_hashes": {},
                    "hash_matches": {},
                    "status": "completed",
                    "module_results": list(self._module_results),
                }
                self._all_evidence_results.append(ev_record)
                self._logger.info(
                    "[EVIDENCE %d/%d] Complete: %s (%s)",
                    ev_idx + 1, total, label, self._evidence_kind,
                )
                return list(self._module_results)
            except Exception as exc:
                self._logger.error(
                    "[EVIDENCE %d/%d] Error processing %s evidence %s: %s",
                    ev_idx + 1, total, self._evidence_kind, label, exc,
                    exc_info=True,
                )
                if self._coc:
                    self._coc.log(
                        event_type=EventType.ERROR,
                        description=(
                            f"[EVIDENCE {ev_idx + 1}/{total}] {self._evidence_kind} "
                            f"processing error: {str(exc)[:500]}"
                        ),
                        evidence_path=str(ev_path),
                    )
                self._all_evidence_results.append({
                    "evidence_idx": ev_idx,
                    "evidence_path": str(ev_path),
                    "evidence_type": self._evidence_kind,
                    "evidence_hash": self._evidence_hash,
                    "status": "error",
                    "error": str(exc),
                    "module_results": list(self._module_results),
                })
                return list(self._module_results)

        try:
            self.acquire_evidence()
            # Mount FIRST so integrity hashes the acquired media stream (ewf1),
            # not the .E01 container — the media is the byte range the embedded
            # acquisition hash covers.
            self._mount_evidence()
            self.verify_evidence_integrity(expected_hash=expected_hash)
            self._detect_partition_offset_on_mount()
            # Mount the partition read-only so every file-consuming module scans
            # the live filesystem (the single mounted filesystem root).
            self._mount_filesystem()

            if not self._run_preflight_self_test():
                self._unmount_filesystem()
                self._unmount_evidence()
                self._logger.error(
                    "[EVIDENCE %d/%d] Preflight FAILED for %s — skipping pipeline, "
                    "continuing to next image",
                    ev_idx + 1, total, label,
                )
                if self._coc:
                    self._coc.log(
                        event_type    = EventType.ERROR,
                        description   = (
                            f"[EVIDENCE {ev_idx + 1}/{total}] Preflight FAILED for "
                            f"{label} — pipeline skipped"
                        ),
                        evidence_path = str(ev_path),
                    )
                self._all_evidence_results.append({
                    "evidence_idx":    ev_idx,
                    "evidence_path":   str(ev_path),
                    "evidence_hash":   self._evidence_hash,
                    "sha256":          self._evidence_hash or "NOT_COMPUTED",
                    "hash_verified":   self._evidence_hash is not None,
                    "fs_analysed":     False,
                    "preflight_failed": True,
                    "status":          "preflight_failed",
                    "module_results":  [],
                })
                return []

            # Seed the content-scanner corpus from the native filesystem output.
            # Deleted files are a separate root so they remain visible and clearly
            # attributable rather than being silently mixed with active content.
            _native_active = getattr(self._native_fs_result, "extracted_root", None)
            _native_deleted = getattr(self._native_fs_result, "deleted_root", None)
            self._corpus_roots = [
                str(root) for root in (_native_active, _native_deleted)
                if root is not None and Path(root).is_dir()
            ]
            self._working_set = {
                "mounted_fs_root": str(_native_active) if _native_active else None,
                "native_deleted_root": str(_native_deleted) if _native_deleted else None,
                "offset_sectors": self._partition_offset,
                "filesystem_type": (
                    self._native_fs_result.candidate.fs_type
                    if self._native_fs_result and self._native_fs_result.candidate else None
                ),
                "filesystem_execution_outcome": (
                    self._native_fs_result.status if self._native_fs_result else "did_not_run"
                ),
                "filesystem_caveats": (
                    list(self._native_fs_result.caveats) if self._native_fs_result else []
                ),
                "native_filesystem_result": (
                    self._native_fs_result.as_dict() if self._native_fs_result else None
                ),
                "native_filesystem_manifest": (
                    str(Path(_native_active).parent / "native_filesystem_manifest.json")
                    if _native_active else None
                ),
                "os_mount_attempted": False,
                "os_mount_succeeded": False,
                "os_mount_path": None,
                "os_mount_cleanup_status": "NOT_APPLICABLE — native read-only parsing used",
                "extracted_files_dir": str(_native_active) if _native_active else None,
                "carved_files_dir": str(_native_deleted) if _native_deleted else None,
                "primary_evidence_roots": list(self._corpus_roots),
                "derived_corpus_roots": [],
                "corpus_roots": list(self._corpus_roots),
                "image_set": [str(p) for p in [self._evidence_path] if p and Path(p).is_file()],
                "evidence_access_method": self._evidence_access_method,
                "source_container_path": str(self._evidence_path),
                "source_container_sha256": self._source_container_sha256,
                "logical_media_sha256": self._evidence_hash,
            }

            # Recursively classify nested evidence and evidence-supplied
            # configuration using signatures and schemas, never planted values.
            try:
                from core.evidence_inventory import build_inventory
                _inventory_path = self._case_output_dir / "evidence_inventory" / f"ev{ev_idx:02d}_inventory.json"
                _inventory = build_inventory(
                    [Path(root) for root in self._corpus_roots if Path(root).is_dir()],
                    output_path=_inventory_path,
                )
                _sources = dict(_inventory.get("sources") or {})
                self._working_set.update({
                    "evidence_inventory": _inventory,
                    "evidence_inventory_path": str(_inventory_path),
                    "nested_memory_sources": list(_sources.get("memory_structural") or []),
                    "nested_memory_marker_sources": list(_sources.get("memory_markers") or []),
                    "nested_network_sources": list(_sources.get("network") or []),
                    "nested_mobile_sources": list(_sources.get("mobile_archives") or []),
                    "nested_mobile_roots": list(_sources.get("mobile_roots") or []),
                    "nested_mobile_root_records": list(_inventory.get("mobile_roots") or []),
                    "registry_hive_sources": list(_sources.get("registry_hives") or []),
                    "evidence_yara_rule_sources": list(_sources.get("yara_rules") or []),
                    "evidence_clamav_signature_sources": list(_sources.get("clamav_signatures") or []),
                    "evidence_hash_list_sources": list(_sources.get("hash_lists") or []),
                    "evidence_ioc_list_sources": list(_sources.get("ioc_lists") or []),
                    "evidence_wordlist_sources": list(_sources.get("wordlists") or []),
                    "evidence_keyword_list_sources": list(_sources.get("keyword_lists") or []),
                    "evidentiary_source_files": list(_sources.get("evidentiary_files") or []),
                    "case_context_source_files": list(_sources.get("case_context_files") or []),
                    "analysis_configuration_source_files": list(_sources.get("analysis_configuration_files") or []),
                    "validation_reference_source_files": list(_sources.get("validation_reference_files") or []),
                })
                self._logger.info(
                    "[INVENTORY] %d objects; memory=%d+%d network=%d mobile=%d roots=%d configs=%d",
                    int(_inventory.get("object_count") or 0),
                    len(self._working_set["nested_memory_sources"]),
                    len(self._working_set["nested_memory_marker_sources"]),
                    len(self._working_set["nested_network_sources"]),
                    len(self._working_set["nested_mobile_sources"]),
                    len(self._working_set["nested_mobile_roots"]),
                    sum(len(self._working_set[key]) for key in (
                        "evidence_yara_rule_sources", "evidence_clamav_signature_sources",
                        "evidence_hash_list_sources", "evidence_ioc_list_sources",
                        "evidence_wordlist_sources",
                    )),
                )
            except Exception as _inventory_exc:
                self._working_set["evidence_inventory_error"] = str(_inventory_exc)
                self._logger.warning("[INVENTORY] recursive evidence discovery failed: %s", _inventory_exc)

            try:
                self.execute_pipeline(evidence_idx=ev_idx)
            finally:
                self._unmount_filesystem()
                self._unmount_evidence()

        except Exception as exc:
            self._logger.error(
                "[EVIDENCE %d/%d] Error processing %s: %s",
                ev_idx + 1, total, label, exc, exc_info=True,
            )
            if self._coc:
                try:
                    self._coc.log(
                        event_type    = EventType.ERROR,
                        description   = (
                            f"[EVIDENCE {ev_idx + 1}/{total}] Error: {str(exc)[:500]}"
                        ),
                        evidence_path = str(ev_path),
                    )
                except Exception:
                    pass
            # Attempt unmount even on error
            try:
                self._unmount_filesystem()
            except Exception:
                pass
            try:
                self._unmount_evidence()
            except Exception:
                pass
            self._all_evidence_results.append({
                "evidence_idx":   ev_idx,
                "evidence_path":  str(ev_path),
                "evidence_hash":  self._evidence_hash,
                "status":         "error",
                "error":          str(exc),
                "module_results": list(self._module_results),
            })
            return list(self._module_results)

        ev_record = {
            "evidence_idx":   ev_idx,
            "evidence_path":  str(self._evidence_path),
            "evidence_type":  "disk",
            "evidence_hash":  self._evidence_hash,
            "md5":            self._evidence_md5,
            "sha1":           self._evidence_sha1,
            "sha256":         self._evidence_hash,
            "logical_media_md5": self._evidence_md5,
            "logical_media_sha1": self._evidence_sha1,
            "logical_media_sha256": self._evidence_hash,
            "logical_media_size_bytes": self._logical_media_size_bytes,
            "source_container_md5": self._source_container_md5,
            "source_container_sha1": self._source_container_sha1,
            "source_container_sha256": self._source_container_sha256,
            "source_container_size_bytes": self._source_container_size_bytes,
            "source_container_hash_basis": self._source_container_hash_basis,
            "embedded_hashes": dict(self._evidence_embedded_hashes),
            "hash_matches":   dict(self._evidence_hash_matches),
            "status":         "completed",
            "module_results": list(self._module_results),
        }
        self._all_evidence_results.append(ev_record)

        self._logger.info(
            "[EVIDENCE %d/%d] Complete: %s", ev_idx + 1, total, label
        )
        return list(self._module_results)

    def _reset_module_output(self) -> None:
        """Clear this case's module_output tree at the START of a run (Phase 1d).

        Every module writes to module_output/evNN/<mod>/.  If a prior run left
        evNN directories on disk — especially from a run with MORE exhibits than
        this one — the report loader would discover and render those stale
        exhibits, mixing another run's results into this one.  Removing the tree
        up front guarantees the report is assembled only from THIS run's output.

        Only the regenerable module_output tree is removed; acquired evidence,
        logs, chain-of-custody and prior reports are left untouched.  Called once
        per run, before the first exhibit is processed — never per exhibit (that
        would wipe earlier exhibits mid-run).
        """
        mo = self._case_output_dir / "module_output"
        if mo.exists():
            import shutil
            try:
                shutil.rmtree(mo)
                self._logger.info(
                    "[RESET] Cleared stale module_output at run start: %s", mo
                )
            except OSError as exc:
                self._logger.warning(
                    "[RESET] Could not clear module_output %s: %s", mo, exc
                )
        # Also drop stale per-exhibit pipeline manifests so their references to
        # now-deleted output dirs cannot resurrect a previous run's module list.
        for stale in self._case_output_dir.glob("pipeline_manifest_ev*.json"):
            try:
                stale.unlink()
            except OSError:
                pass
        mo.mkdir(parents=True, exist_ok=True)

    def _register_module_corpus(
        self,
        mod_result: Any,
        mod_output: Path,
        module_name: str,
        evidence_idx: int,
    ) -> None:
        """Fold a completed module's produced files into this item's corpus.

        The corpus is discovered, never assumed: candidate roots are derived
        from the directories the module itself reported writing to via
        ``artifact_paths``.  Any module that recovers or carves files therefore
        contributes automatically — no module names or folder names are matched.

        Only directories the module created *inside* its own output directory
        qualify, which excludes the bookkeeping files (manifests, logs) that
        modules write at their output root while keeping every recovered or
        carved file tree.
        """
        paths = list(getattr(mod_result, "artifact_paths", None) or [])
        if not paths:
            return

        try:
            out_root = Path(mod_output).resolve()
        except OSError:
            return

        candidates: dict[str, Path] = {}
        for raw in paths:
            try:
                parent = Path(str(raw)).resolve().parent
            except (OSError, ValueError):
                continue
            # Keep the shallowest directory under out_root, so a whole carved
            # tree registers as one root rather than one root per subfolder.
            try:
                rel = parent.relative_to(out_root)
            except ValueError:
                continue  # written outside this module's output dir
            if not rel.parts:
                continue  # bookkeeping file at the output root
            root = out_root / rel.parts[0]
            candidates.setdefault(str(root).lower(), root)

        # Files recovered directly from source evidence by tsk_recover/icat
        # remain evidentiary representations of the source filesystem.
        # Make that corpus available to downstream evidence scanners.
        if module_name == "deleted_file_recovery":
            primary = list(
                self._working_set.get("primary_evidence_roots")
                or self._corpus_roots
            )
            existing_primary = {
                str(Path(p).resolve()).lower()
                for p in primary if p
            }

            added_primary = 0

            for key, root in sorted(candidates.items()):
                if key in existing_primary or not root.is_dir():
                    continue

                primary.append(str(root))
                existing_primary.add(key)
                added_primary += 1

            if added_primary:
                self._working_set["primary_evidence_roots"] = primary

                if not self._working_set.get("tsk_recover_dir"):
                    self._working_set["tsk_recover_dir"] = str(
                        next(iter(candidates.values()))
                    )

                derived = list(
                    self._working_set.get("derived_corpus_roots") or []
                )

                self._working_set["corpus_roots"] = list(
                    dict.fromkeys(primary + derived)
                )

                self._logger.debug(
                    "[PRIMARY-CORPUS] evidence %d: %s contributed %d "
                    "direct evidence root(s); primary corpus now %d root(s).",
                    evidence_idx,
                    module_name,
                    added_primary,
                    len(primary),
                )

            return

        added = 0
        derived = list(self._working_set.get("derived_corpus_roots") or [])
        existing = {str(Path(p).resolve()).lower() for p in derived}
        for key, root in sorted(candidates.items()):
            if key in existing or not root.is_dir():
                continue
            derived.append(str(root))
            existing.add(key)
            added += 1

        if not added:
            return

        self._working_set["derived_corpus_roots"] = derived
        # Keep a compatibility union for tools that explicitly opt into
        # derivatives. Default corpus resolution uses primary roots only.
        primary = list(self._working_set.get("primary_evidence_roots") or self._corpus_roots)
        self._working_set["corpus_roots"] = list(dict.fromkeys(primary + derived))
        try:
            from modules._base import count_corpus_files
            n_files = count_corpus_files([Path(p) for p in derived])
        except Exception:
            n_files = -1
        self._logger.debug(
            "[DERIVED-CORPUS] evidence %d: %s contributed %d root(s); "
            "derived corpus now %d root(s), %d file(s). Derived roots are non-corroborating by default.",
            evidence_idx, module_name, added, len(derived), n_files,
        )

    def execute_pipeline(self, evidence_idx: int = 0) -> list[dict[str, Any]]:
        """
        Execute each loaded forensic module against the verified evidence image.

        Resilience contract
        -------------------
        If any module raises ANY exception, the failure is CoC-logged and the
        pipeline continues to the next module. A single broken module must never
        stop the investigation — the rest of the evidence may still be recoverable
        and the investigation must complete. The final report notes which modules
        failed.

        Module interface contract
        -------------------------
        Every module's run() must accept these keyword arguments:
          evidence_path (Path)        — the read-only forensic image
          case_id       (str)         — case identifier
          output_dir    (Path)        — per-module isolated output directory
          config        (dict)        — module's config dict from modules.yaml
          logger        (Logger)      — platform logger (NOT the CoC logger)

        Modules must not write outside their output_dir, must not modify
        evidence_path, and must not call sys.exit().

        Returns
        -------
        List of result dicts, one per module (also stored as self._module_results).
        """
        if not self._modules:
            raise RuntimeError("No modules loaded. Call load_modules() first.")
        if self._evidence_path is None:
            raise RuntimeError("Evidence path not set. Call acquire_evidence() first.")

        self._logger.info(
            "Starting pipeline: %d module(s) against %s",
            len(self._modules), self._evidence_path,
        )

        print(f"\n{'='*62}")
        print(f"  PIPELINE EXECUTION — {len(self._modules)} module(s)")
        print(f"  Evidence: {self._evidence_path}")
        print(f"  Modules : {', '.join(d['name'] for d in self._modules)}")
        print(f"{'='*62}")

        results: list[dict[str, Any]] = []

        for descriptor in self._modules:
            name       = descriptor["name"]
            mod        = descriptor["module"]
            mod_config = descriptor["config"]

            # Each module writes into a per-evidence subdirectory so outputs from
            # different images never overwrite each other.
            mod_output = self._case_output_dir / "module_output" / f"ev{evidence_idx:02d}" / name
            mod_output.mkdir(parents=True, exist_ok=True)

            timeout_s  = mod_config.get("timeout", 3600)   # Default: 1 hour
            start_dt   = datetime.now(timezone.utc)
            start_iso  = start_dt.isoformat(timespec="milliseconds")

            self._coc.log(
                event_type    = EventType.MODULE_STARTED,
                description   = f"Module '{name}' started",
                evidence_path = str(self._evidence_path),
                metadata      = {
                    "module":           name,
                    "start_time":       start_iso,
                    "timeout_seconds":  timeout_s,
                    "output_dir":       str(mod_output),
                },
            )
            self._logger.info("Running module: %s", name)

            result_entry: dict[str, Any] = {
                "module":           name,
                "start_time":       start_iso,
                "end_time":         None,
                "duration_seconds": None,
                "status":           "unknown",
                "error":            None,
                "output_dir":       str(mod_output),
            }

            _applicable, _not_applicable_reason = self._module_applicable(name, mod_config)
            if not _applicable:
                end_iso = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
                _na_config = {
                    "analysis_path": str(self._analysis_path or self._evidence_path),
                    "evidence_type": self._evidence_kind,
                    "_working_set": self._working_set,
                }
                _na_result = certify_module_result(
                    ModuleResult(
                        module_name=name,
                        case_id=self._case_id,
                        status=ModuleStatus.NOT_APPLICABLE,
                        start_time=start_iso,
                        end_time=end_iso,
                        statistics={
                            "evidence_type": self._evidence_kind,
                            "applicability_check_completed": True,
                            "applicability_reason": _not_applicable_reason,
                        },
                        summary=_not_applicable_reason,
                    ),
                    module_name=name,
                    config=_na_config,
                )
                result_entry.update({
                    "end_time": end_iso,
                    "duration_seconds": 0.0,
                    "status": "NOT_APPLICABLE",
                    "execution_outcome": "did_not_run",
                    "summary": _not_applicable_reason,
                    "finding_count": 0,
                    "findings": [],
                    "statistics": dict(_na_result.statistics or {}),
                    "errors": [],
                    "class_results": [{
                        "locus": "OTHER",
                        "artefact_class": str(mod_config.get("category") or name),
                        "verdict": "INDETERMINATE",
                        "skip_reason": "NOT_APPLICABLE",
                        "count": 0,
                        "notes": _not_applicable_reason,
                    }],
                    "terminal_output": (
                        f"Module: {name}\nStatus: NOT_APPLICABLE\n"
                        f"Evidence: {self._evidence_path}\nReason: {_not_applicable_reason}"
                    ),
                })
                self._coc.log(
                    event_type=EventType.MODULE_SKIPPED,
                    description=f"Module '{name}' skipped: {_not_applicable_reason}",
                    evidence_path=str(self._evidence_path),
                    metadata={"module": name, "evidence_type": self._evidence_kind, "reason": _not_applicable_reason},
                )
                try:
                    atomic_write_text(mod_output / "terminal_output.txt", result_entry["terminal_output"])
                    atomic_write_json(mod_output / "module_result.json", {"module_name": name, **result_entry})
                except OSError:
                    pass
                print(f"  [N/A ] [NOT_APPLICABLE] {name:<36s} 0.0s")
                results.append(result_entry)
                continue

            # Inject analysis_path and partition_offset so modules use the
            # mounted ewf1 path (or raw device) instead of the .E01 file directly.
            _effective_analysis = self._analysis_path or self._evidence_path

            # Publish the exact read-only logical-media stream for provenance
            # resolution only. Do NOT add it to primary_evidence_roots because
            # downstream content scanners should process extracted evidence
            # objects rather than scan the complete block image as one file.
            self._working_set["logical_media_stream"] = str(_effective_analysis)

            run_config = {
                **mod_config,
                "analysis_path":    str(_effective_analysis),
                "partition_offset": self._partition_offset,
                "evidence_type":    self._evidence_kind,
                "device_type":      self._evidence_device_type,
                "case_classification": str(getattr(self._case_config, "classification", "") or ""),
                "synthetic_validation": "synthetic" in str(getattr(self._case_config, "classification", "") or "").lower(),
            }
            # Recursive evidence inventory paths are passed explicitly to all
            # relevant modules.  This lets a disk image contain nested PCAP,
            # memory and mobile corpora without filename-specific hard-coding.
            _ws_sources = self._working_set
            run_config["memory_paths"] = list(_ws_sources.get("nested_memory_sources") or [])
            run_config["memory_marker_paths"] = list(_ws_sources.get("nested_memory_marker_sources") or [])
            run_config["pcap_paths"] = list(_ws_sources.get("nested_network_sources") or [])
            run_config["mobile_sources"] = list(_ws_sources.get("nested_mobile_sources") or [])
            run_config["mobile_roots"] = list(_ws_sources.get("nested_mobile_roots") or [])
            run_config["mobile_root_records"] = list(_ws_sources.get("nested_mobile_root_records") or [])
            run_config["registry_hive_paths"] = list(_ws_sources.get("registry_hive_sources") or [])
            run_config["evidence_yara_rule_sources"] = list(_ws_sources.get("evidence_yara_rule_sources") or [])
            run_config["evidence_clamav_signature_sources"] = list(_ws_sources.get("evidence_clamav_signature_sources") or [])
            run_config["evidence_hash_list_sources"] = list(_ws_sources.get("evidence_hash_list_sources") or [])
            run_config["evidence_ioc_list_sources"] = list(_ws_sources.get("evidence_ioc_list_sources") or [])
            run_config["evidence_wordlist_sources"] = list(_ws_sources.get("evidence_wordlist_sources") or [])
            run_config["evidence_keyword_list_sources"] = list(_ws_sources.get("evidence_keyword_list_sources") or [])

            # Domain-specific explicit source/configuration paths. Modules must
            # not rely on finding a copied file inside their output directory.
            if self._evidence_kind == "network":
                run_config["pcap_path"] = str(self._evidence_path)
                run_config["pcap_paths"] = [str(self._evidence_path)]
            elif self._evidence_kind == "memory":
                run_config["memory_path"] = str(self._evidence_path)
                run_config["memory_paths"] = [str(self._evidence_path)]
                if os.environ.get("VOLATILITY3_PATH"):
                    run_config["vol_path"] = os.environ["VOLATILITY3_PATH"]
            elif self._evidence_kind == "mobile":
                if os.environ.get("ALEAPP_PATH"):
                    run_config["aleapp_path"] = os.environ["ALEAPP_PATH"]
                if os.environ.get("ILEAPP_PATH"):
                    run_config["ileapp_path"] = os.environ["ILEAPP_PATH"]
                if os.environ.get("LEAPP_INPUT_TYPE"):
                    run_config["input_type"] = os.environ["LEAPP_INPUT_TYPE"]

            # Inject the ewf device into every module's config so modules can use it
            mod_config_with_device = dict(run_config)
            mod_config_with_device["_ewf_device"]    = str(self._analysis_path) if self._analysis_path else None
            mod_config_with_device["_offset_sectors"] = self._partition_offset
            mod_config_with_device["_working_set"]   = self._working_set
            # Optional investigator-supplied keyword list for real cases. The
            # synthetic flag is already derived explicitly from case metadata
            # in run_config above.
            _keyword_file = os.environ.get("AUTOFORENSICS_KEYWORD_FILE", "").strip()
            if _keyword_file:
                mod_config_with_device["keyword_list_path"] = _keyword_file
            mod_config_with_device["_missing_tools"] = getattr(self, "_missing_tools", set())

            import contextlib, io as _io
            _capture_buf = _io.StringIO()
            mod_result = None
            try:
                with module_timeout(timeout_s, name):
                    with contextlib.redirect_stdout(_capture_buf):
                        with contextlib.redirect_stderr(_capture_buf):
                            _marker_paths = list(mod_config_with_device.get("memory_marker_paths") or [])
                            _structural_memory_paths = list(mod_config_with_device.get("memory_paths") or [])
                            if name in marker_capable_modules() and _marker_paths and not _structural_memory_paths:
                                mod_result = run_marker_scope(
                                    module_name=name,
                                    case_id=self._case_id,
                                    marker_paths=_marker_paths,
                                )
                            else:
                                mod_result = mod.run(
                                    evidence_path = self._evidence_path,
                                    case_id       = self._case_id,
                                    output_dir    = mod_output,
                                    config        = mod_config_with_device,
                                    logger        = self._logger,
                                    coc_logger    = self._coc,
                                )
                                if name in marker_capable_modules() and _marker_paths and mod_result is not None:
                                    mod_result = augment_with_marker_scope(
                                        mod_result,
                                        module_name=name,
                                        case_id=self._case_id,
                                        marker_paths=_marker_paths,
                                    )

                end_dt   = datetime.now(timezone.utc)
                end_iso  = end_dt.isoformat(timespec="milliseconds")
                duration = (end_dt - start_dt).total_seconds()

                if mod_result is not None:
                    if not mod_result.start_time:
                        mod_result.start_time = start_iso
                    if not mod_result.end_time:
                        mod_result.end_time = end_iso
                    if not mod_result.duration_seconds:
                        mod_result.duration_seconds = duration

                    # Convert legacy module-returned error states into the
                    # platform's truthful isolated-failure state. A module may
                    # return ERROR instead of raising; it must still be isolated
                    # and must never be presented as a successful capability.
                    _returned_status = _norm_status(getattr(mod_result, "status", ""))
                    if _returned_status in {"ERROR", "FAILED", "FAILED_OFFSET", "IMPORT_FAILED"}:
                        mod_result.status = ModuleStatus.FAILED_ISOLATED
                        _stats = dict(getattr(mod_result, "statistics", {}) or {})
                        _stats["execution_outcome"] = "did_not_run"
                        _stats["failure_isolated"] = True
                        _stats["legacy_status"] = _returned_status
                        mod_result.statistics = _stats
                        if not str(getattr(mod_result, "summary", "") or "").strip():
                            mod_result.summary = (
                                "Module failed in isolation; later modules continued independently. "
                                "No absence conclusion is drawn from this module."
                            )

                # Stamp the exhibit id at the source, where the evidence identity
                # is unambiguous (this module just ran against evidence_idx).  Every
                # finding therefore carries its exhibit id before it ever reaches
                # the report, so the report's hard-fail attribution guard is
                # unreachable on a correct run and the loader's path-matching is
                # only a fallback for report-only mode.
                if mod_result is not None:
                    stamp_result_exhibit(
                        mod_result,
                        exhibit_id_for(evidence_idx, self._case_config),
                    )

                # Deterministic promotion gate. Pattern, threshold, OCR/ML and
                # co-occurrence engines remain available as candidate generators,
                # but only reproducibly validated claims are allowed to become
                # evidentiary findings. This gate is content/schema driven and
                # contains no fixture-specific values.
                if mod_result is not None:
                    mod_result = reconcile_module_result(
                        mod_result,
                        module_name=name,
                        evidence_path=self._evidence_path,
                        config=mod_config_with_device,
                        output_dir=mod_output,
                    )

                # H2 assurance gate: every PRESENT observation must have an
                # independently usable evidence reference before it can enter
                # the canonical findings database or the report. Unsupported
                # observations are retained only as rejected audit records and
                # cannot contribute to a PRESENT verdict.
                _accepted_findings = []
                _rejected_findings = []
                if mod_result is not None:
                    _accepted_findings, _rejected_findings = assure_module_result(
                        mod_result,
                        exhibit_id=exhibit_id_for(evidence_idx, self._case_config),
                        source_evidence_path=str(self._evidence_path),
                        source_evidence_sha256=str(self._source_container_sha256 or self._evidence_hash or ""),
                        logical_media_sha256=str(self._evidence_hash or ""),
                    )
                    mod_result.findings = annotate_findings(name, list(mod_result.findings or []))
                    mod_result = finalise_canonical_result(mod_result)
                    # Final execution status is issued only after strict, case-neutral
                    # source/record accounting and provenance certification. A normal
                    # return code or fallback cannot by itself produce PASS_COMPLETE.
                    mod_result = certify_module_result(
                        mod_result, module_name=name, config=mod_config_with_device,
                    )
                    _accepted_findings = list(mod_result.findings or [])
                    # Publish an immutable serialisable snapshot for downstream
                    # correlation/timeline/anti-forensic aggregation. Modules
                    # must consume these canonical records rather than recursively
                    # scanning generated JSON/CSV output.
                    _snapshot = []
                    for _finding in _accepted_findings:
                        try:
                            _snapshot.append({
                                "finding_id": str(getattr(_finding, "finding_id", "")),
                                "finding_type": str(getattr(_finding, "finding_type", "")),
                                "severity": str(getattr(getattr(_finding, "severity", ""), "value", getattr(_finding, "severity", ""))),
                                "description": str(getattr(_finding, "description", "")),
                                "evidence_path": str(getattr(_finding, "evidence_path", "")),
                                "artifact_path": str(getattr(_finding, "artifact_path", "") or ""),
                                "metadata": dict(getattr(_finding, "metadata", {}) or {}),
                                "timestamp": str(getattr(_finding, "timestamp", "")),
                            })
                        except Exception:
                            continue
                    self._working_set.setdefault("canonical_findings_by_module", {})[name] = _snapshot
                    self._working_set.setdefault("module_status_matrix", {})[name] = {
                        "status": str(getattr(getattr(mod_result, "status", ""), "value", getattr(mod_result, "status", ""))),
                        "accepted_findings": len(_snapshot),
                        "summary": str(getattr(mod_result, "summary", "")),
                    }
                    for _finding in _accepted_findings:
                        _raw_ref = getattr(_finding, "evidence_reference", {}) or {}
                        if isinstance(_raw_ref, dict):
                            _ref = dict(_raw_ref)
                        elif isinstance(_raw_ref, str):
                            # Legacy modules sometimes stored a path/string in
                            # evidence_reference. Preserve it without attempting
                            # dict(string), which raises and previously converted
                            # otherwise successful modules into FAILED_ISOLATED.
                            _ref = {"legacy_reference": _raw_ref}
                        else:
                            _ref = {"legacy_reference": str(_raw_ref)}
                        self._coc.log(
                            event_type=EventType.FINDING_RECORDED,
                            description=(
                                f"Evidence-referenced finding recorded by module '{name}': "
                                f"{getattr(_finding, 'finding_type', 'UNKNOWN')}"
                            ),
                            evidence_path=str(getattr(_finding, "evidence_path", "") or self._evidence_path),
                            metadata={
                                "module": name,
                                "finding_id": getattr(_finding, "finding_id", ""),
                                "finding_type": getattr(_finding, "finding_type", ""),
                                "severity": (getattr(getattr(_finding, "severity", ""), "value", None)
                                             or str(getattr(_finding, "severity", ""))),
                                "evidence_reference": _ref,
                                "discovery_timestamp": getattr(_finding, "timestamp", ""),
                                "module_start_time": getattr(mod_result, "start_time", ""),
                                "module_end_time": getattr(mod_result, "end_time", ""),
                            },
                        )
                    for _rejected in _rejected_findings:
                        self._coc.log(
                            event_type=EventType.FINDING_REJECTED,
                            description=(
                                f"Unsupported observation rejected by the H2 assurance gate "
                                f"for module '{name}'"
                            ),
                            evidence_path=str(self._evidence_path),
                            metadata={"module": name, **_rejected},
                        )

                # Fold whatever this module produced into the shared corpus so
                # every downstream content module sees it.  Registration is
                # additive and driven by the module's own result object.
                if mod_result is not None:
                    try:
                        self._register_module_corpus(
                            mod_result, mod_output, name, evidence_idx,
                        )
                    except Exception as corpus_exc:  # never fail a run on this
                        self._logger.warning(
                            "[CORPUS] could not register output of '%s': %s",
                            name, corpus_exc,
                        )

                # Append only evidence-referenced findings to the canonical store.
                if not hasattr(self, "_findings_store") or self._findings_store is None:
                    from core.findings_store import FindingsStore
                    _store_path = self._case_output_dir / f"{self._case_id}_findings.jsonl"
                    self._findings_store = FindingsStore(_store_path)
                if mod_result is not None:
                    self._findings_store.append_module_result(mod_result, evidence_idx)

                end_dt       = datetime.now(timezone.utc)
                end_iso      = end_dt.isoformat(timespec="milliseconds")
                duration     = (end_dt - start_dt).total_seconds()
                captured     = _capture_buf.getvalue()

                _actual_status = (
                    _norm_status(mod_result.status)
                    if mod_result is not None and hasattr(mod_result, "status")
                    else "COMPLETED"
                )
                terminal_lines = [f"Module: {name}",
                                   f"Status: {_actual_status} in {duration:.1f}s",
                                   f"Evidence: {self._evidence_path}"]
                if captured:
                    terminal_lines.append("")
                    terminal_lines.append(captured.rstrip())
                terminal_output = "\n".join(terminal_lines)

                _live_findings = list(getattr(mod_result, "findings", []) or []) if mod_result is not None else []
                _finding_count = len(_live_findings)
                _serialized_findings = []
                for _f in _live_findings:
                    try:
                        _serialized_findings.append({
                            "finding_id": getattr(_f, "finding_id", ""),
                            "finding_type": getattr(_f, "finding_type", ""),
                            "severity": (getattr(getattr(_f, "severity", ""), "value", None)
                                         or str(getattr(_f, "severity", ""))),
                            "description": getattr(_f, "description", ""),
                            "evidence_path": getattr(_f, "evidence_path", ""),
                            "artifact_path": getattr(_f, "artifact_path", None),
                            "metadata": dict(getattr(_f, "metadata", {}) or {}),
                            "timestamp": getattr(_f, "timestamp", ""),
                            "evidence_reference": getattr(_f, "evidence_reference", ""),
                        })
                    except Exception:
                        continue
                _statistics = dict(getattr(mod_result, "statistics", {}) or {}) if mod_result is not None else {}
                _declared_outcome = str(_statistics.get("execution_outcome") or "").strip()
                if not _declared_outcome:
                    if _actual_status in ("SKIPPED", "ERROR", "FAILED", "FAILED_OFFSET", "IMPORT_FAILED"):
                        _declared_outcome = "did_not_run"
                    elif _actual_status == "PARTIAL":
                        _declared_outcome = "ran_with_caveat"
                    elif _finding_count:
                        _declared_outcome = "ran_found_x"
                    else:
                        _declared_outcome = "ran_found_nothing"
                result_entry.update({
                    "end_time":         end_iso,
                    "duration_seconds": duration,
                    "status":           _actual_status,
                    "execution_outcome": _declared_outcome,
                    "summary":          str(getattr(mod_result, "summary", "") or ""),
                    "finding_count":    _finding_count,
                    "findings":         _serialized_findings,
                    "statistics":       _statistics,
                    "errors":           list(getattr(mod_result, "errors", []) or []),
                    "terminal_output":  terminal_output,
                })

                # Serialize class_results from the live module result
                _cr_data = []
                if mod_result is not None:
                    for _cr in getattr(mod_result, 'class_results', []):
                        try:
                            _cr_data.append({
                                'locus': _cr.locus.value if hasattr(_cr.locus, 'value') else str(_cr.locus),
                                'artefact_class': _cr.artefact_class,
                                'verdict': _cr.verdict.value if hasattr(_cr.verdict, 'value') else str(_cr.verdict),
                                'skip_reason': (_cr.skip_reason.value if _cr.skip_reason and hasattr(_cr.skip_reason, 'value')
                                               else str(_cr.skip_reason) if _cr.skip_reason else None),
                                'count': getattr(_cr, 'count', 0),
                                'notes': getattr(_cr, 'notes', '') or '',
                            })
                        except Exception:
                            pass
                result_entry['class_results'] = _cr_data

                if _actual_status == "PASS_COMPLETE":
                    _event_type = EventType.MODULE_COMPLETED
                elif _actual_status == "INCOMPLETE":
                    _event_type = EventType.MODULE_INCOMPLETE
                elif _actual_status in ("NOT_APPLICABLE", "OUT_OF_SCOPE"):
                    _event_type = EventType.MODULE_SKIPPED
                else:
                    _event_type = EventType.MODULE_FAILED
                self._coc.log(
                    event_type=_event_type,
                    description=(
                        f"Module '{name}' {_actual_status}: {_declared_outcome} "
                        f"in {duration:.1f}s"
                    ),
                    evidence_path=str(self._evidence_path),
                    metadata={
                        "module": name,
                        "start_time": start_iso,
                        "end_time": end_iso,
                        "duration_seconds": duration,
                        "status": _actual_status,
                        "execution_outcome": _declared_outcome,
                        "finding_count": _finding_count,
                        "summary": str(getattr(mod_result, "summary", "") or ""),
                    },
                )
                self._logger.info(
                    "Module '%s' %s (%s) in %.1fs",
                    name, _actual_status, _declared_outcome, duration,
                )

            except BaseException as exc:   # noqa: BLE001 — module boundary intentionally isolates SystemExit too
                if isinstance(exc, KeyboardInterrupt):
                    raise
                # Broad except is intentional: a module crashing the entire
                # investigation is worse than logging the failure and continuing.
                end_dt   = datetime.now(timezone.utc)
                end_iso  = end_dt.isoformat(timespec="milliseconds")
                duration = (end_dt - start_dt).total_seconds()
                error_s  = str(exc)
                captured = _capture_buf.getvalue()

                terminal_lines = [f"Module: {name}",
                                   f"Status: FAILED after {duration:.1f}s",
                                   f"Evidence: {self._evidence_path}",
                                   f"Error: {error_s}"]
                if captured:
                    terminal_lines.append("")
                    terminal_lines.append(captured.rstrip())
                terminal_output = "\n".join(terminal_lines)

                result_entry.update({
                    "end_time":         end_iso,
                    "duration_seconds": duration,
                    "status":           "FAILED_ISOLATED",
                    "execution_outcome": "did_not_run",
                    "summary":          (
                        f"FAILED ISOLATED — module timed out: {error_s}"
                        if isinstance(exc, ModuleTimeoutError) else
                        f"FAILED ISOLATED — module raised: {error_s}"
                    ),
                    "finding_count":    0,
                    "error":            error_s,
                    "terminal_output":  terminal_output,
                    "class_results": [{
                        "locus": "OTHER",
                        "artefact_class": str(mod_config.get("category") or name),
                        "verdict": "INDETERMINATE",
                        "skip_reason": ("TIMEOUT" if isinstance(exc, ModuleTimeoutError) else "PARTIAL_FAILURE"),
                        "count": 0,
                        "notes": f"Module raised an exception before a complete assurance verdict: {error_s[:700]}",
                    }],
                })

                self._coc.log(
                    event_type    = EventType.MODULE_FAILED,
                    description   = f"Module '{name}' ERROR: {error_s[:500]}",
                    evidence_path = str(self._evidence_path),
                    metadata      = {
                        "module":           name,
                        "start_time":       start_iso,
                        "end_time":         end_iso,
                        "duration_seconds": duration,
                        "error":            error_s[:2000],
                        "outcome":          "FAILED_ISOLATED",
                        "rc":               getattr(exc, "returncode", None),
                    },
                )
                self._logger.error(
                    "Module '%s' failed after %.1fs: %s",
                    name, duration, exc, exc_info=True,
                )

            # Write a standardized per-module JSON artefact for every outcome.
            # This fulfils the proposal deliverable without relying on each
            # specialist tool to invent its own serialization format.
            try:
                atomic_write_text(
                    mod_output / "terminal_output.txt",
                    result_entry.get("terminal_output", ""),
                )
                atomic_write_json(
                    mod_output / "module_result.json",
                    {"module_name": name, **result_entry},
                )
            except OSError:
                pass

            _dur = result_entry.get("duration_seconds") or 0
            _st  = _norm_status(result_entry.get("status") or "UNKNOWN")
            _sym = (
                "PASS" if _st == "PASS_COMPLETE" else
                "N/A"  if _st == "NOT_APPLICABLE" else
                "O/S"  if _st == "OUT_OF_SCOPE" else
                "INC"  if _st == "INCOMPLETE" else
                "FAIL"
            )
            print(f"  [{_sym}] [{_st:10s}] {name:<40s} {_dur:.1f}s")
            if result_entry.get("error"):
                print(f"         Error: {str(result_entry['error'])[:120]}")

            results.append(result_entry)

        # Merge any import-failure synthetic entries so the banner counts them.
        # These entries are accumulated in load_modules() and represent modules
        # that could not even be imported — they must not be silently omitted.
        results = results + self._import_failed_results

        self._module_results = results

        _status_counts: dict[str, int] = {}
        for r in results:
            s = _norm_status(r.get("status") or "unknown")
            _status_counts[s] = _status_counts.get(s, 0) + 1

        _complete = _status_counts.get("PASS_COMPLETE", 0)
        _not_applicable = _status_counts.get("NOT_APPLICABLE", 0)
        _out_of_scope = _status_counts.get("OUT_OF_SCOPE", 0)
        _incomplete = _status_counts.get("INCOMPLETE", 0)
        _failed = (
            _status_counts.get("FAILED_ISOLATED", 0)
            + _status_counts.get("ERROR", 0)
            + _status_counts.get("FAILED", 0)
            + _status_counts.get("FAILED_OFFSET", 0)
            + _status_counts.get("IMPORT_FAILED", 0)
        )
        # Any legacy state reaching this point is not a successful final state.
        _legacy_unresolved = sum(
            _status_counts.get(name, 0)
            for name in ("COMPLETED", "COMPLETED_WITH_FALLBACK", "PARTIAL", "SKIPPED", "VERIFY_LATER", "INDETERMINATE", "DEGRADED")
        )

        self._logger.info(
            "Pipeline strict result: %d PASS_COMPLETE, %d NOT_APPLICABLE, %d OUT_OF_SCOPE, %d INCOMPLETE, %d FAILED, %d unresolved legacy",
            _complete, _not_applicable, _out_of_scope, _incomplete, _failed, _legacy_unresolved,
        )

        print(f"\n{'='*62}")
        print(f"  PIPELINE COMPLETE  ({len(results)} module results)")
        print(f"    PASS_COMPLETE:  {_complete}")
        if _not_applicable: print(f"    NOT_APPLICABLE: {_not_applicable}")
        if _out_of_scope: print(f"    OUT_OF_SCOPE:   {_out_of_scope}")
        if _incomplete: print(f"    INCOMPLETE:     {_incomplete}")
        if _failed: print(f"    FAILED:         {_failed}")
        if _legacy_unresolved: print(f"    LEGACY/UNRESOLVED: {_legacy_unresolved}")
        print(f"{'='*62}\n")

        # Write pipeline_manifest.json so report_loader can surface module status
        try:
            pm_path = self._case_output_dir / f"pipeline_manifest_ev{evidence_idx:02d}.json"
            pm_data = [
                {
                    "module_name": r.get("module", "Unknown"),
                    "status": r.get("status", "unknown"),
                    "start_time": r.get("start_time", ""),
                    "end_time": r.get("end_time", ""),
                    "duration_seconds": r.get("duration_seconds", 0),
                    "error": r.get("error", ""),
                    "errors": r.get("errors", []),
                    "execution_outcome": r.get("execution_outcome", "did_not_run"),
                    "summary": r.get("summary", ""),
                    "finding_count": r.get("finding_count", 0),
                    "findings": r.get("findings", []),
                    "statistics": r.get("statistics", {}),
                    "terminal_output": r.get("terminal_output", ""),
                    "output_dir": r.get("output_dir", ""),
                    "class_results": r.get("class_results", []),
                }
                for r in results
            ]
            pm_path.write_text(
                json.dumps(pm_data, indent=2, default=str), encoding="utf-8"
            )
        except OSError:
            pass

        return results

    # ──────────────────────────────────────────────────────────────────────
    # Phase 8 — Report Generation
    # ──────────────────────────────────────────────────────────────────────

    def generate_report(self) -> Path:
        """
        Compile all module outputs and investigation metadata into a case report.

        Produces two report files:
          <case_id>_<timestamp>_report.json   Machine-readable; includes all metadata,
                                              evidence hashes, and per-module results.
          <case_id>_<timestamp>_report.txt    Human-readable summary for non-technical
                                              reviewers (judges, lawyers, board members).

        Both files are recorded in the CoC log. The JSON report is the authoritative
        record; the .txt is a convenience summary.

        Returns
        -------
        Path to the JSON report file.
        """
        report_dir = self._case_output_dir / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)

        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

        # Flatten all module results across every evidence item for aggregate stats
        _all_mod_results: list[dict[str, Any]] = []
        for _ev in self._all_evidence_results:
            _all_mod_results.extend(_ev.get("module_results", []))
        # Fall back to self._module_results if all_evidence_results is empty
        # (single-evidence runs that didn't go through _run_single_evidence)
        if not _all_mod_results:
            _all_mod_results = self._module_results

        report: dict[str, Any] = {
            "report_metadata": {
                "case_id":            self._case_id,
                "investigator_id":    self._investigator["id"],
                "investigator_name":  self._investigator["name"],
                "investigator_badge": self._investigator["badge"],
                "profile":            self._profile_name,
                "platform_version":   VERSION,
                "generated_at":       datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            },
            # Legacy single-evidence field — points to last image processed
            "evidence": {
                "path":       str(self._evidence_path),
                "sha256":     self._evidence_hash or "NOT COMPUTED",
                "source":     self._evidence_source,
                "size_bytes": self._evidence_path.stat().st_size
                              if self._evidence_path else None,
            },
            # FIX #1: per-evidence results so the report can build one section per image
            "all_evidence": [
                {
                    "evidence_idx":  ev.get("evidence_idx", 0),
                    "evidence_path": ev.get("evidence_path", ""),
                    "evidence_hash": ev.get("evidence_hash") or "NOT COMPUTED",
                    "status":        ev.get("status", "unknown"),
                    "module_count":  len(ev.get("module_results", [])),
                }
                for ev in self._all_evidence_results
            ],
            "pipeline": {
                "evidence_count": len(self._all_evidence_results) or 1,
                "total_modules": len(_all_mod_results),
                **_strict_status_counts(_all_mod_results),
                "partial": 0,
                "skipped": sum(
                    _norm_status(r.get("status")) in {"NOT_APPLICABLE", "OUT_OF_SCOPE"}
                    for r in _all_mod_results
                ),
                "results": _all_mod_results,
                "per_evidence": self._all_evidence_results,
            },
        }

        json_path = report_dir / f"{self._case_id}_{ts}_report.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=True, default=_json_default)
        # 0o640 — owner read/write, group read; world cannot read case reports
        os.chmod(json_path, 0o640)

        txt_path = report_dir / f"{self._case_id}_{ts}_report.txt"
        self._write_text_report(txt_path, report)
        os.chmod(txt_path, 0o640)

        self._coc.log(
            event_type    = EventType.REPORT_GENERATED,
            description   = f"Case report generated: {json_path.name}",
            evidence_path = str(self._evidence_path),
            metadata      = {
                "json_report":       str(json_path),
                "txt_report":        str(txt_path),
                "total_modules":     report["pipeline"]["total_modules"],
                "completed_modules": report["pipeline"]["completed"],
                "failed_modules":    report["pipeline"]["failed"],
            },
        )

        self._logger.info("Report written to: %s", json_path)
        return json_path

    def _write_text_report(self, path: Path, report: dict[str, Any]) -> None:
        """Write the human-readable .txt summary. Called only from generate_report()."""
        m = report["report_metadata"]
        e = report["evidence"]
        p = report["pipeline"]

        lines: list[str] = [
            "=" * 70,
            "AUTO FORENSICS — INVESTIGATION REPORT",
            "=" * 70,
            f"Case ID:          {m['case_id']}",
            f"Investigator:     {m['investigator_name']} ({m['investigator_badge']})",
            f"Profile:          {m['profile']}",
            "Platform:         AutoForensics",
            f"Report Generated: {m['generated_at']}",
            "",
            "EVIDENCE",
            "-" * 70,
            f"Path:             {e['path']}",
            f"SHA-256:          {e['sha256']}",
            f"Source:           {e['source'].replace('_', ' ').title()}",
            f"Size:             {e.get('size_bytes', 'N/A')} bytes",
            "",
            "ANALYSIS PIPELINE",
            "-" * 70,
            f"Total Registered: {p['total_modules']}",
            f"Actually Ran:     {p.get('executed', 0)}",
            f"PASS_COMPLETE:    {p['completed']}",
            f"INCOMPLETE:       {p.get('incomplete', 0)}",
            f"NOT_APPLICABLE:   {p.get('not_applicable', 0)}",
            f"OUT_OF_SCOPE:     {p.get('out_of_scope', 0)}",
            f"Failed isolated:  {p['failed']}",
            ("WARNING: ZERO MODULES EXECUTED" if p.get('zero_modules_executed') else ""),
            "",
            "MODULE RESULTS",
            "-" * 70,
        ]

        for result in p["results"]:
            status   = _norm_status(result.get("status") or "UNKNOWN")
            duration = result.get("duration_seconds") or 0
            outcome = result.get("execution_outcome", "did_not_run")
            lines.append(
                f"  [{status:10s}] {result['module']:<30s} ({duration:.1f}s) — {outcome}"
            )
            if result.get("summary"):
                lines.append(f"               {str(result['summary'])[:240]}")
            if result.get("error"):
                # Truncate error to 120 chars — full error is in the platform log
                lines.append(f"               Error: {result['error'][:120]}")

        lines += [
            "",
            "=" * 70,
            "END OF REPORT",
            "=" * 70,
        ]

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def _generate_pdf_report(self) -> None:
        """Auto-generate the PDF report. Called at the end of Phase 8."""
        try:
            from .report_loader import load_case_results
            from .report_generator import ReportGenerator
            from .report_sections import EvidenceAcquisition
            from datetime import date as _date

            self._logger.info("Auto-generating PDF report for case %s …", self._case_id)

            module_results = load_case_results(
                self._case_output_dir, logger=self._logger,
                case_config=self._case_config,
            )

            report_dir = self._case_output_dir / "reports"
            report_dir.mkdir(parents=True, exist_ok=True)

            investigator_name = (
                self._investigator.get("name", "Unknown Examiner")
                if self._investigator else "Unknown Examiner"
            )

            # ReportLab/PDF parsing can retain substantial state after all 45
            # modules have run. Generate the examiner report in a clean, bounded
            # report-only subprocess from the already persisted canonical output.
            # This does not rerun or reinterpret evidence and prevents process
            # memory/third-party library state from stalling case completion.
            _case_file = self._case_output_dir / ".autoforensics_state" / "case.json"
            _run_py = Path(__file__).resolve().parent.parent / "run.py"
            if _case_file.is_file() and _run_py.is_file():
                import subprocess as _subprocess, sys as _sys
                _report_env = os.environ.copy()
                _ai_policy = getattr(self._case_config, "ai_policy", None)
                _cloud_allowed = bool(getattr(_ai_policy, "allow_cloud_case_data", False))
                if not _cloud_allowed:
                    _report_env["LLM_PROVIDER"] = "none"
                    _report_env.pop("OPENAI_API_KEY", None)
                _cmd = [
                    _sys.executable, str(_run_py),
                    "--report-only", str(self._case_output_dir),
                    "--case-file", str(_case_file),
                ]
                if os.environ.get("REQUIRE_LLM", "").strip().lower() in ("1", "true", "yes", "on"):
                    _cmd.append("--require-llm")
                self._logger.info("Generating report in isolated report-only subprocess")
                _report_subprocess_log = report_dir / f"{self._case_id}_report_subprocess.log"
                # Write directly to a retained file rather than PIPE. Some PDF
                # helper descendants may briefly inherit standard descriptors;
                # direct-file redirection prevents communicate() from waiting on
                # an inherited pipe after the report process itself has exited.
                with _report_subprocess_log.open("w", encoding="utf-8") as _report_log_handle:
                    _completed = _subprocess.run(
                        _cmd, cwd=str(_run_py.parent), env=_report_env,
                        stdout=_report_log_handle, stderr=_subprocess.STDOUT,
                        text=True, timeout=600, check=False, start_new_session=True,
                    )
                if _completed.returncode != 0:
                    try:
                        _tail = _report_subprocess_log.read_text(encoding="utf-8", errors="replace")[-1600:]
                    except OSError:
                        _tail = "report subprocess log unavailable"
                    raise RuntimeError("Isolated report generation failed: " + _tail)
                _pdf = report_dir / f"{self._case_id}_report.pdf"
                _json = report_dir / f"{self._case_id}_report.json"
                _sig = report_dir / f"{self._case_id}_report_signature.json"
                if not _pdf.is_file() or not _json.is_file():
                    raise RuntimeError("Isolated report generator returned success without the required PDF/JSON files")
                self._pdf_path = str(_pdf)
                self._report_json_path = str(_json)
                self._signature_path = str(_sig) if _sig.is_file() else None
                self._pdf_page_count = ReportGenerator._count_pages(_pdf)
                self._pdf_sha256 = hashlib.sha256(_pdf.read_bytes()).hexdigest()
                if self._coc is not None and not self._sealed:
                    self._coc.log(
                        event_type=EventType.REPORT_GENERATED,
                        description=f"PDF report generated: {_pdf.name}",
                        evidence_path=str(self._evidence_path) if self._evidence_path else "",
                        metadata={
                            "pdf_path": self._pdf_path,
                            "page_count": self._pdf_page_count,
                            "sha256": self._pdf_sha256,
                            "generation_mode": "isolated_report_only_subprocess",
                            "subprocess_log": str(_report_subprocess_log),
                        },
                    )
                self._logger.info(
                    "PDF report written by isolated subprocess: %s (%d pages, SHA-256: %s…)",
                    self._pdf_path, self._pdf_page_count, self._pdf_sha256[:16],
                )
                return

            # FIX #11: build EvidenceAcquisition objects from per-evidence results
            # so Section 3.3 shows the actual SHA-256 computed during verification.
            _evidence_acq: list[EvidenceAcquisition] = []
            for ev in self._all_evidence_results:
                ev_path = ev.get("evidence_path", "")
                ev_hash = ev.get("evidence_hash") or ev.get("sha256") or ""
                ev_md5 = ev.get("md5") or ""
                ev_sha1 = ev.get("sha1") or (ev.get("computed_hashes") or {}).get("sha1", "")
                _embedded = ev.get("embedded_hashes") or {}
                _matches = ev.get("hash_matches") or {}
                # "verified" is only true when a computed digest was re-verified
                # against an embedded acquisition reference and matched — never
                # merely because a hash was computed.
                _has_reference = bool(_embedded)
                _all_match = _has_reference and all(
                    v == "MATCH" for v in _matches.values()
                )
                _mismatch = any(v == "MISMATCH" for v in _matches.values())
                if _mismatch:
                    _note = "Integrity: MISMATCH against embedded acquisition hash"
                elif _all_match:
                    _note = "Integrity: MATCH against embedded acquisition hash"
                elif ev_hash or ev_md5:
                    _note = "Integrity: hashes computed; no embedded reference to verify against"
                else:
                    _note = "Integrity: hashes not computed"
                _kind = str(ev.get("evidence_type") or "disk").lower()
                _acq = ev.get("acquisition") or {}
                _platform_acquired = bool(ev.get("acquisition_performed_by_platform") and _acq)
                _method_map = {
                    "disk": "Pre-existing disk image supplied for read-only analysis",
                    "memory": "Pre-existing memory image supplied for read-only analysis",
                    "network": "Pre-existing packet capture supplied for read-only analysis",
                    "mobile": "Pre-existing mobile extraction supplied for read-only analysis",
                }
                _tool_map = {
                    "disk": "AutoForensics evidence/media parser",
                    "memory": "AutoForensics + configured Volatility 3 modules",
                    "network": "AutoForensics + configured tshark modules",
                    "mobile": "AutoForensics + configured ALEAPP/iLEAPP modules",
                }
                _evidence_acq.append(EvidenceAcquisition(
                    exhibit_number   = exhibit_id_for(ev.get('evidence_idx', 0), self._case_config),
                    description      = Path(ev_path).name if ev_path else "Unknown",
                    acquisition_date = _date.today(),
                    acquisition_method = (
                        f"Physical attached-device acquisition; write protection: "
                        f"{((_acq.get('write_protection') or {}).get('effective_method') or 'UNRECORDED')}"
                        if _platform_acquired else
                        _method_map.get(_kind, "Pre-existing evidence supplied for read-only analysis")
                    ),
                    tool_used        = (_acq.get("acquisition_tool") if _platform_acquired else _tool_map.get(_kind, "AutoForensics")),
                    tool_version     = (_acq.get("acquisition_tool_version", "") if _platform_acquired else ""),
                    # Legacy hash fields intentionally carry logical-media
                    # hashes so embedded EWF references are compared only to the
                    # reconstructed media stream.
                    md5_hash         = ev.get("logical_media_md5") or ev_md5,
                    sha256_hash      = ev.get("logical_media_sha256") or ev_hash,
                    md5_reference    = _embedded.get("md5", ""),
                    sha1_hash        = ev.get("logical_media_sha1") or ev_sha1,
                    sha1_reference   = _embedded.get("sha1", ""),
                    sha256_reference = _embedded.get("sha256", ""),
                    source_container_path = ev_path,
                    source_container_md5 = ev.get("source_container_md5", ""),
                    source_container_sha1 = ev.get("source_container_sha1", ""),
                    source_container_sha256 = ev.get("source_container_sha256", ""),
                    source_container_size_bytes = int(ev.get("source_container_size_bytes") or 0),
                    source_container_hash_basis = ev.get("source_container_hash_basis", "source-file-bytes"),
                    logical_media_size_bytes = int(ev.get("logical_media_size_bytes") or 0),
                    source_size_bytes = int(ev.get("source_container_size_bytes") or 0),
                    image_size_bytes  = int(ev.get("logical_media_size_bytes") or 0),
                    acquired_by      = investigator_name,
                    verified         = (
                        bool(_acq.get("acquisition_verified") and _acq.get("analysis_integrity_verified"))
                        if _platform_acquired else _all_match
                    ),
                    notes            = (
                        "Status: " + str(ev.get('status', 'unknown')) + ". " +
                        (f"Source/acquired={_acq.get('source_pre_vs_acquired')}; "
                         f"source-pre/source-post={_acq.get('source_pre_vs_source_post')}; "
                         f"pre/post-container={_acq.get('pre_vs_post_container_set')}; "
                         f"pre/post-logical={_acq.get('pre_vs_post_logical_media')}. "
                         f"Write protection={((_acq.get('write_protection') or {}).get('effective_method') or 'UNRECORDED')}. "
                         + " ".join((_acq.get('limitations') or []))
                         if _platform_acquired else _note)
                    ),
                    write_protection_method = ((_acq.get("write_protection") or {}).get("effective_method", "") if _platform_acquired else ""),
                    source_pre_acquisition_sha256 = (_acq.get("source_pre_acquisition_sha256", "") if _platform_acquired else ""),
                    source_post_acquisition_sha256 = (_acq.get("source_post_acquisition_sha256", "") if _platform_acquired else ""),
                    source_pre_hash_basis = (_acq.get("source_pre_hash_basis", "") if _platform_acquired else ""),
                    source_post_hash_basis = (_acq.get("source_post_hash_basis", "") if _platform_acquired else ""),
                    acquired_content_sha256 = (_acq.get("acquired_content_sha256", "") if _platform_acquired else ""),
                    source_pre_vs_acquired = (_acq.get("source_pre_vs_acquired", "") if _platform_acquired else ""),
                    source_pre_vs_source_post = (_acq.get("source_pre_vs_source_post", "") if _platform_acquired else ""),
                    container_set_sha256_pre_analysis = (_acq.get("container_set_sha256_pre_analysis", "") if _platform_acquired else ""),
                    container_set_sha256_post_analysis = (_acq.get("container_set_sha256_post_analysis", "") if _platform_acquired else ""),
                    logical_media_sha256_pre_analysis = (_acq.get("logical_media_sha256_pre_analysis", "") if _platform_acquired else ""),
                    logical_media_sha256_post_analysis = (_acq.get("logical_media_sha256_post_analysis", "") if _platform_acquired else ""),
                    pre_vs_post_container_set = (_acq.get("pre_vs_post_container_set", "") if _platform_acquired else ""),
                    pre_vs_post_logical_media = (_acq.get("pre_vs_post_logical_media", "") if _platform_acquired else ""),
                ))

            # Strict LLM mode is normalised into REQUIRE_LLM by run.py (from the
            # --require-llm flag or the env), so the full-pipeline auto-report
            # honours it too — not just the --report-only path.
            _require_llm = os.environ.get("REQUIRE_LLM", "").strip().lower() in (
                "1", "true", "yes", "on")
            gen = ReportGenerator(
                case_id=self._case_id,
                investigator=investigator_name,
                all_module_results=module_results,
                coc_logger=self._coc,
                output_dir=report_dir,
                case_config=self._case_config,
                case_dir=self._case_output_dir,
                evidence_items=_evidence_acq if _evidence_acq else None,
                all_evidence_results=self._all_evidence_results or None,
                findings_store_path=str(self._case_output_dir / f"{self._case_id}_findings.jsonl"),
                tool_versions=self._tool_versions,
                require_llm=_require_llm,
            )

            result = gen.generate()

            self._pdf_path       = str(result.pdf_path)
            self._report_json_path = str(result.json_path)
            self._signature_path = str(result.signature_path) if result.signature_path else None
            self._pdf_page_count = result.page_count
            self._pdf_sha256     = result.sha256_hash

            # Apply consistent file permissions (matches JSON/TXT reports in generate_report())
            try:
                pdf_file = Path(self._pdf_path)
                if pdf_file.exists():
                    os.chmod(pdf_file, 0o640)
            except OSError:
                pass

            if self._coc is not None and not self._sealed:
                try:
                    self._coc.log(
                        event_type=EventType.REPORT_GENERATED,
                        description=f"PDF report generated: {Path(self._pdf_path).name}",
                        evidence_path=str(self._evidence_path) if self._evidence_path else "",
                        metadata={
                            "pdf_path":    self._pdf_path,
                            "page_count":  self._pdf_page_count,
                            "sha256":      self._pdf_sha256,
                        },
                    )
                except Exception:
                    pass  # Non-fatal — CoC will still be sealed

            self._logger.info(
                "PDF report written: %s (%d pages, SHA-256: %s…)",
                self._pdf_path, self._pdf_page_count, self._pdf_sha256[:16],
            )

        except LLMUnavailable as exc:
            # Strict mode (--require-llm / REQUIRE_LLM): abort the run cleanly.
            # SystemExit is a BaseException, so it is NOT swallowed by the broad
            # "non-fatal" handler below — the process exits non-zero, no traceback.
            self._logger.error(
                "Strict LLM mode: aborting — configured LLM synthesis unavailable: %s", exc)
            print(
                "\nFATAL: --require-llm/REQUIRE_LLM is set but the configured LLM "
                f"synthesis was unavailable:\n  {exc}\n"
                "Check LLM_PROVIDER and the matching provider credentials/model "
                "settings, or unset strict mode to allow the labelled deterministic "
                "fallback.\n",
                file=sys.stderr,
            )
            sys.exit(2)
        except Exception as exc:
            self._logger.error(
                "PDF report generation failed; investigation data is preserved but "
                "the case cannot complete as a distributable report: %s",
                exc, exc_info=True,
            )
            # The proposal defines the multi-part PDF as a required deliverable.
            # Fail closed so a run never prints INVESTIGATION COMPLETE after a
            # report-audit or signature failure. The outer lifecycle performs an
            # emergency custody seal and returns a non-zero exit status.
            raise RuntimeError(f"Required PDF report generation failed: {exc}") from exc

    # ──────────────────────────────────────────────────────────────────────
    # Phase 9 — Seal Chain of Custody
    # ──────────────────────────────────────────────────────────────────────

    def seal_custody_log(self) -> dict[str, Any]:
        """
        Finalize and cryptographically seal the chain of custody ledger.

        Steps:
          1. Write the final INVESTIGATION_SEALED CoC entry.
          2. Call CustodyLogger.seal() which:
             a. Verifies the full on-disk hash chain is intact.
             b. Computes the final seal hash over all entries.
             c. Signs the seal document with HMAC-SHA256.
             d. Makes all log files read-only (0o400).
          3. Print a closing summary to the terminal.

        After this method returns, no further CoC entries can be written.
        The seal document is the court-submittable closing record.

        Returns
        -------
        The seal document dict (also written to disk as custody_seal.json).

        Raises
        ------
        RuntimeError   If already sealed or if the CoC logger was never initialized.
        """
        if self._sealed:
            raise RuntimeError("Chain of custody has already been sealed.")
        if self._coc is None:
            raise RuntimeError(
                "Chain of custody logger was never initialized. "
                "Was intake_case() called?"
            )

        self._coc.log(
            event_type  = EventType.INVESTIGATION_SEALED,
            description = (
                f"Investigation '{self._case_id}' complete. "
                "Sealing the chain of custody ledger."
            ),
            metadata = {
                "total_modules_run":     len(self._module_results),
                "final_evidence_sha256": self._evidence_hash,
            },
        )

        seal = self._coc.seal()
        self._sealed = True

        chain_ok = seal.get("chain_integrity_verified", False)
        self._logger.info(
            "CoC sealed: case=%s entries=%d chain_ok=%s",
            self._case_id, seal.get("total_entries"), chain_ok,
        )

        print(f"\n{'=' * 72}")
        print("  INVESTIGATION SEALED — FINAL VERIFICATION PENDING")
        print(f"{'=' * 72}")
        print(f"  CASE ID                 : {self._case_id}")
        print(f"  REPORT PATH             : {self._pdf_path if self._pdf_path is not None else '(PDF generation failed)'}")
        print(f"  REPORT PAGES            : {self._pdf_page_count if self._pdf_page_count is not None else 'N/A'}")
        print(f"  REPORT SHA-256          : {self._pdf_sha256 if self._pdf_sha256 is not None else 'N/A'}")
        print(f"  CHAIN OF CUSTODY ENTRIES: {seal.get('total_entries', 0)}")
        print(f"  CHAIN INTEGRITY STATUS  : {'INTACT' if chain_ok else 'CHAIN BROKEN — ALERT'}")
        print(f"{'=' * 72}\n")

        return seal

    def _write_completion_manifest(self, seal: dict[str, Any]) -> Path:
        """Independently verify final report signing and custody sealing.

        This receipt is created only after the custody ledger is sealed.  It is
        not part of the sealed ledger and does not claim examiner approval; it
        records machine-verifiable completion of the required cryptographic
        deliverables.
        """
        from .report_signing import verify_report_signature
        from .custody_log import CustodyLogger

        case_dir = Path(self._case_output_dir).resolve()
        reports = case_dir / "reports"
        signing_cfg = getattr(self._case_config, "signing", None) if self._case_config else None
        public_key = Path(str(getattr(signing_cfg, "public_key_path", "") or "")).expanduser()
        signature_ok = False
        signature_error = ""
        if self._signature_path and public_key.is_file():
            try:
                verified = verify_report_signature(
                    self._signature_path, public_key.resolve(), base_dir=reports
                )
                signature_ok = bool(verified.get("valid"))
            except Exception as exc:
                signature_error = str(exc)
        else:
            signature_error = "detached signature or public key is missing"

        ledger = case_dir / f"{self._case_id}_custody.jsonl"
        seal_path = case_dir / f"{self._case_id}_custody_seal.json"
        key_path = self._coc.hmac_key_path if self._coc is not None else None
        custody_ok = False
        custody_error = ""
        if ledger.is_file() and seal_path.is_file() and key_path and Path(key_path).is_file():
            custody_ok, custody_error = CustodyLogger.verify_seal_files(
                ledger, seal_path, Path(key_path)
            )
        else:
            custody_error = "ledger, seal, or separately stored HMAC key is missing"

        required_signature = bool(getattr(signing_cfg, "require_signature", False))
        machine_complete = bool(custody_ok and (signature_ok or not required_signature))
        flat_module_results = [
            module
            for evidence in (self._all_evidence_results or [])
            for module in (evidence.get("module_results") or [])
        ] or list(self._module_results or [])
        module_counts = _strict_status_counts(flat_module_results)
        investigation_execution_complete = bool(
            module_counts.get("executed", 0) > 0 and module_counts.get("failed", 0) == 0
        )
        strict_release_accepted = bool(
            investigation_execution_complete and module_counts.get("incomplete", 0) == 0
        )
        receipt = {
            "schema": "autoforensics-case-completion-v1",
            "case_id": self._case_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "machine_complete": machine_complete,
            "investigation_execution_complete": investigation_execution_complete,
            "strict_release_accepted": strict_release_accepted,
            "module_status_counts": module_counts,
            "examiner_approval": "NOT_ASSERTED",
            "report": {
                "pdf": self._pdf_path,
                "json": self._report_json_path,
                "pdf_sha256": self._pdf_sha256,
                "detached_signature": self._signature_path,
                "signature_required": required_signature,
                "signature_verified": signature_ok,
                "signature_error": signature_error,
            },
            "custody": {
                "ledger": str(ledger),
                "seal": str(seal_path),
                "hmac_key_file": str(key_path) if key_path else "",
                "chain_integrity_verified": bool(seal.get("chain_integrity_verified")),
                "hmac_verified": custody_ok,
                "verification_error": custody_error,
                "total_entries": seal.get("total_entries", 0),
            },
            "statement": (
                "Machine completion confirms file-signature and custody-HMAC verification only. "
                "Investigation execution completion is recorded separately from strict forensic "
                "release acceptance. INCOMPLETE modules remain visible and prevent strict release "
                "acceptance without being misreported as an execution crash. This receipt does not "
                "establish forensic accuracy, ISO/IEC 17025 accreditation, legal admissibility, "
                "peer review or examiner approval."
            ),
        }
        out = case_dir / f"{self._case_id}_completion_manifest.json"
        out.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        os.chmod(out, 0o440)
        self._completion_manifest_path = str(out)
        if not machine_complete:
            raise RuntimeError(
                "Final cryptographic completion verification failed: "
                f"signature_ok={signature_ok}, custody_ok={custody_ok}; "
                f"signature_error={signature_error}; custody_error={custody_error}"
            )
        return out

    # ──────────────────────────────────────────────────────────────────────
    # Main lifecycle — run() and emergency seal
    # ──────────────────────────────────────────────────────────────────────

    def run(self, args: argparse.Namespace) -> int:
        """
        Execute the full nine-phase investigation lifecycle.

        This is the top-level entry point. It handles the investigator ID and
        password prompts (falling back to interactive input if not supplied via
        CLI), then calls each phase method in sequence.

        On any unhandled exception, _emergency_seal() is called to flush and
        close the CoC log files before the process exits, so partially-written
        logs remain readable.

        Returns
        -------
        0 on success, 1 on any failure. Used as the process exit code.
        """
        _check_investigators_json()
        _print_banner()

        # Resolve interactivity once, up front: every prompt below (auth, intake
        # fallbacks, the YES gate) honours this so --non-interactive suppresses
        # ALL console prompts and the run fails closed rather than blocking.
        self._non_interactive = self._resolve_non_interactive(args)

        # Phase 1 — Authenticate.  Credentials come from CLI/env in
        # non-interactive mode and from prompts otherwise; a non-interactive run
        # with missing credentials fails closed here instead of hanging.
        investigator_id, password = self._acquire_credentials(args)
        if investigator_id is None:
            return 1

        if not self.authenticate(investigator_id, password):
            print("\nAuthentication failed. Access denied.")
            return 1

        # Load --case-file before intake so self._case_config is populated and
        # intake_case() can skip interactive prompts when all required fields
        # are present.  The env-var path (set by run.py) is already loaded in
        # __init__(); --case-file overrides it when explicitly supplied here.
        # FIX #0: always store the loaded config — never gate on _case_config_complete().
        # _case_config_complete() is advisory (it decides whether to warn about gaps);
        # it must not silently discard a valid config because paths don't exist on a
        # dev machine.
        _case_file = getattr(args, "case_file", None)
        if _case_file:
            try:
                from core.case_config import load_case_config
                _cf = load_case_config(_case_file)
                if _cf:
                    if not _cf.investigation_profile:
                        _cf.investigation_profile = "full"
                    self._case_config = _cf
                    self._logger.info("Case config loaded from --case-file: %s", _case_file)
                    if not _case_config_complete(_cf):
                        self._logger.warning(
                            "--case-file '%s' loaded but some fields are incomplete; "
                            "interactive prompts will fill any gaps.", _case_file
                        )
            except Exception as _e:
                self._logger.warning("Could not load --case-file '%s': %s", _case_file, _e)

        try:
            self.intake_case(args)                # Phase 2
            self.verify_write_block()             # Phase 3
            self.load_modules()                   # Phase 6 — loaded once, reused per evidence

            # Phase 1d — clear this run's module_output before any module writes,
            # so no run can inherit stale per-exhibit results from a previous run.
            self._reset_module_output()

            expected = getattr(args, "expected_hash", None)

            if self._config_evidence_paths:
                # FIX #1: iterate ALL evidence images from the case config.
                # Each image gets its own acquire → verify → mount → pipeline → unmount
                # cycle.  A failure on image N is isolated and does not abort image N+1.
                # # LIVE-RUN-REQUIRED: per-evidence iteration confirmed only on Kali with
                # real E01 files.
                for ev_idx, ev_path in enumerate(self._config_evidence_paths):
                    self._run_single_evidence(ev_path, ev_idx, expected_hash=expected)
            elif self._evidence_source == "existing_image" and self._image_path is not None:
                # CLI single-source investigations use the same evidence router
                # as case-config inputs, including memory, PCAP and mobile sources.
                self._config_evidence_paths = [self._image_path]
                self._config_evidence_options[str(self._image_path.resolve())] = {
                    "evidence_type": self._evidence_kind,
                    "device_type": self._evidence_device_type,
                }
                self._run_single_evidence(self._image_path, 0, expected_hash=expected)
            else:
                # Live device acquisition path.
                self.acquire_evidence()           # Phase 4

                # Open/materialise the logical evidence stream natively.  This
                # occurs before integrity verification so hashes cover media
                # bytes, never the compressed E01 container bytes.
                self._mount_evidence()
                self.verify_evidence_integrity(   # Phase 5
                    expected_hash=expected
                )
                self._detect_partition_offset_on_mount()
                # Parse the filesystem natively and publish a read-only corpus.
                self._mount_filesystem()

                # Pre-pipeline self-test: native recognition first; optional
                # external verification is never a hard dependency.
                if not self._run_preflight_self_test():
                    self._unmount_filesystem()
                    self._unmount_evidence()
                    raise RuntimeError(
                        "[PREFLIGHT] No supported filesystem could be read from the "
                        "logical evidence stream. Native FAT/NTFS/ext detection failed; "
                        "the image may be unsupported, encrypted, or corrupted."
                    )

                # Publish native active/deleted corpus roots to every content module.
                _native_active = getattr(self._native_fs_result, "extracted_root", None)
                _native_deleted = getattr(self._native_fs_result, "deleted_root", None)
                self._corpus_roots = [
                    str(root) for root in (_native_active, _native_deleted)
                    if root is not None and Path(root).is_dir()
                ]
                self._working_set = {
                    "mounted_fs_root": str(_native_active) if _native_active else None,
                    "native_deleted_root": str(_native_deleted) if _native_deleted else None,
                    "offset_sectors": self._partition_offset,
                    "filesystem_type": (
                        self._native_fs_result.candidate.fs_type
                        if self._native_fs_result and self._native_fs_result.candidate else None
                    ),
                    "filesystem_execution_outcome": (
                        self._native_fs_result.status if self._native_fs_result else "did_not_run"
                    ),
                    "filesystem_caveats": (
                        list(self._native_fs_result.caveats) if self._native_fs_result else []
                    ),
                    "extracted_files_dir": str(_native_active) if _native_active else None,
                    "carved_files_dir": str(_native_deleted) if _native_deleted else None,
                    "primary_evidence_roots": list(self._corpus_roots),
                    "derived_corpus_roots": [],
                    "corpus_roots": list(self._corpus_roots),
                    "image_set": [str(p) for p in [self._evidence_path] if p and Path(p).is_file()],
                    "evidence_access_method": self._evidence_access_method,
                }

                try:
                    self.execute_pipeline()       # Phase 7
                finally:
                    self._unmount_filesystem()    # always unmount after pipeline
                    self._unmount_evidence()      # always unmount after pipeline

                self._verify_live_post_analysis_integrity()

                self._all_evidence_results.append({
                    "evidence_idx":   0,
                    "evidence_path":  str(self._evidence_path),
                    "evidence_hash":  self._evidence_hash,
                    "status":         "completed",
                    "acquisition_performed_by_platform": True,
                    "acquisition": asdict(self._acquisition_record) if self._acquisition_record else {},
                    "module_results": list(self._module_results),
                })

            self.generate_report()                # Phase 8 — JSON/TXT
            self._generate_pdf_report()           # Phase 8b — PDF

            _flat_results = [
                module
                for evidence in self._all_evidence_results
                for module in evidence.get("module_results", [])
            ] or list(self._module_results)
            _counts = _strict_status_counts(_flat_results)
            if _counts["zero_modules_executed"]:
                self._emergency_seal(
                    f"INVESTIGATION ABORTED: no module reached a terminal execution state across "
                    f"{len(self._all_evidence_results)} evidence item(s)"
                )
                print(f"\n{'='*72}")
                print("  *** INVESTIGATION ABORTED — NO MODULE EXECUTION RESULTS ***")
                print(f"{'='*72}")
                print(f"  CASE ID : {self._case_id}")
                print("  STATUS  : ABORTED — check import, evidence-access and platform logs")
                print(f"{'='*72}\n")
                return 1

            _seal = self.seal_custody_log()       # Phase 9
            _completion = self._write_completion_manifest(_seal)
            strict_release_ok = _counts["incomplete"] == 0 and _counts["failed"] == 0
            print(f"\n{'=' * 72}")
            print("  INVESTIGATION EXECUTION COMPLETE — CRYPTOGRAPHIC CHECKS PASSED")
            print(f"{'=' * 72}")
            print(f"  CASE ID                  : {self._case_id}")
            print(f"  MODULES EXECUTED         : {_counts['executed']}")
            print(f"  PASS_COMPLETE            : {_counts['completed']}")
            print(f"  INCOMPLETE               : {_counts['incomplete']}")
            print(f"  FAILED_ISOLATED          : {_counts['failed']}")
            print(f"  STRICT RELEASE STATUS    : {'PASSED' if strict_release_ok else 'NOT ACCEPTED'}")
            print(f"  REPORT PATH              : {self._pdf_path}")
            print(f"  DETACHED SIGNATURE       : {self._signature_path}")
            print(f"  COMPLETION MANIFEST      : {_completion}")
            print(f"{'=' * 72}\n")
            # A completed investigation with honestly INCOMPLETE specialist
            # scopes is an execution success but not an approved strict release.
            # Reserve a non-zero process result for actual failed execution so
            # wrappers do not mislabel partial assurance as an investigation crash.
            execution_ok = _counts["failed"] == 0
            return 0 if execution_ok else 2

        except KeyboardInterrupt:
            self._logger.warning("Investigation interrupted by operator (Ctrl+C).")
            try:
                self._unmount_evidence()
            except Exception:
                pass
            self._emergency_seal("Investigation interrupted by operator (KeyboardInterrupt)")
            return 1

        except SystemExit:
            # Raised by _require_confirmation() when the investigator cancels —
            # not an error condition, let it propagate naturally.
            raise

        except Exception as exc:
            self._logger.critical(
                "Unhandled exception during investigation: %s",
                exc, exc_info=True,
            )
            try:
                self._unmount_evidence()
            except Exception:
                pass
            self._emergency_seal(
                f"Investigation aborted due to unhandled error: {str(exc)[:500]}"
            )
            print(f"\nFATAL ERROR: {exc}")
            print("The chain of custody log has been flushed. Check platform logs.")
            return 1

    def _emergency_seal(self, reason: str) -> None:
        """
        Best-effort seal of the CoC on unexpected termination.

        Called from the exception handlers in run(). The investigation is in an
        error state, so we log the reason, attempt to seal, and if sealing itself
        fails we at least close the file handles so the partial log is readable.
        We never raise from this method — it must be safe to call from any context.
        """
        if self._coc is None or self._sealed:
            return
        try:
            self._coc.log(
                event_type  = EventType.ERROR,
                description = f"EMERGENCY SEAL: {reason}",
            )
            self._coc.seal()
            self._sealed = True
            self._logger.info("Emergency seal completed.")
        except Exception as seal_exc:
            self._logger.error("Emergency seal failed: %s", seal_exc)
            # Last resort: just close the file handles so the partial log is intact
            try:
                self._coc._close_file_handles()   # pylint: disable=protected-access
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ──────────────────────────────────────────────────────────────────────────────

def _build_parser() -> argparse.ArgumentParser:
    """
    Build the CLI argument parser for Auto Forensics.

    All arguments are optional at the CLI level — missing ones trigger
    interactive prompts inside ForensicOrchestrator.intake_case(). This
    supports both scripted batch use and guided interactive use.
    """
    parser = argparse.ArgumentParser(
        prog        = "autoforensics",
        description = "Auto Forensics — Automated Digital Forensic Investigation Platform",
        formatter_class = argparse.RawDescriptionHelpFormatter,
        epilog = (
            "Examples:\n"
            "  Interactive:  python -m core.main\n"
            "  Live device:  python -m core.main --case-id CASE-2026-001 "
            "--investigator-id jsmith --profile usb --device /dev/sdb\n"
            "  Existing img: python -m core.main --case-id CASE-2026-002 "
            "--investigator-id jsmith --profile image --image-path /evidence/disk.E01"
        ),
    )
    parser.add_argument(
        "--case-id", dest="case_id",
        help="Case identifier (letters, digits, hyphens, underscores; max 64 chars)",
    )
    parser.add_argument(
        "--investigator-id", dest="investigator_id",
        help="Investigator login ID",
    )
    parser.add_argument(
        "--profile",
        metavar="PROFILE",
        help="Investigation profile (e.g. usb, image, memory, mobile, full)",
    )
    parser.add_argument(
        "--device",
        metavar="PATH",
        help="Live device to image (e.g. /dev/sdb). Mutually exclusive with --image-path.",
    )
    parser.add_argument(
        "--prompt-evidence-source",
        action="store_true",
        help=(
            "After authentication, show the normal Live device / Existing evidence "
            "source menu even when --case-file contains an evidence path. Cannot be "
            "combined with --device or --image-path."
        ),
    )
    parser.add_argument(
        "--image-path", dest="image_path",
        metavar="PATH",
        help="Existing disk image, memory image, PCAP, or mobile extraction. Mutually exclusive with --device.",
    )
    parser.add_argument(
        "--evidence-type", dest="evidence_type",
        choices=("auto", "disk", "memory", "network", "mobile"),
        default="auto",
        help="Explicit evidence domain for ambiguous inputs such as .raw/.bin or extraction directories.",
    )
    parser.add_argument(
        "--output-dir", dest="output_dir",
        metavar="DIR",
        help=f"Base output directory (default: {DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "--expected-hash", dest="expected_hash",
        metavar="SHA256",
        help="Expected SHA-256 of the evidence image for integrity verification",
    )
    parser.add_argument(
        "--case-file", dest="case_file",
        metavar="PATH",
        help=(
            "Path to a case config JSON file. Skips interactive intake prompts when "
            "case_number, examiner.name, and at least one evidence item with a valid "
            "path are present. A missing profile defaults to 'full'."
        ),
    )
    return parser


if __name__ == "__main__":
    _parser = _build_parser()
    _args   = _parser.parse_args()

    # Determine output directory: CLI arg → default project output dir
    _raw_output = getattr(_args, "output_dir", None)
    _output_dir = Path(_raw_output).resolve() if _raw_output else DEFAULT_OUTPUT_DIR
    _output_dir.mkdir(parents=True, exist_ok=True)

    # Bootstrap a minimal logger before we have a case_id.
    # The full structured logger is set up in intake_case() once case_id is known.
    logging.basicConfig(
        level   = logging.INFO,
        format  = "%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt = "%Y-%m-%dT%H:%M:%S%z",
    )

    _orchestrator = ForensicOrchestrator(output_dir=_output_dir)
    sys.exit(_orchestrator.run(_args))
