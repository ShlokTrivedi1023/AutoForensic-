"""Dependency-free filesystem detection and basic extraction.

The native path is intentionally conservative: it recognises MBR, GPT and
unpartitioned volumes, validates filesystem signatures, fully walks FAT12/16/32
(including deleted directory entries), parses NTFS MFT metadata through the
bundled Python parser, and records ext2/3/4 superblock metadata.  Unsupported or
partially supported features are returned as explicit caveats rather than being
reported as a clean result.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import struct
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import BinaryIO, Iterator, Optional

SECTOR_SIZE = 512


@dataclass
class FilesystemCandidate:
    fs_type: str
    offset_bytes: int
    offset_sectors: int
    source: str
    metadata: dict[str, object] = field(default_factory=dict)
    confidence: str = "high"
    caveats: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, object]:
        return {
            "fs_type": self.fs_type,
            "offset_bytes": self.offset_bytes,
            "offset_sectors": self.offset_sectors,
            "source": self.source,
            "metadata": self.metadata,
            "confidence": self.confidence,
            "caveats": list(self.caveats),
        }


@dataclass
class NativeFile:
    path: str
    name: str
    is_directory: bool
    deleted: bool
    size_bytes: int
    first_cluster: int
    attributes: int
    created: Optional[str] = None
    modified: Optional[str] = None
    accessed: Optional[str] = None
    cluster_chain: list[int] = field(default_factory=list)
    recovery_status: str = "metadata_only"
    extracted_path: str = ""
    sha256: str = ""
    caveats: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, object]:
        return self.__dict__.copy()


@dataclass
class NativeFilesystemResult:
    candidate: Optional[FilesystemCandidate]
    files: list[NativeFile] = field(default_factory=list)
    extracted_root: Optional[Path] = None
    deleted_root: Optional[Path] = None
    ran: bool = False
    status: str = "did_not_run"
    reason: str = ""
    caveats: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, object]:
        return {
            "candidate": self.candidate.as_dict() if self.candidate else None,
            "files": [f.as_dict() for f in self.files],
            "extracted_root": str(self.extracted_root) if self.extracted_root else None,
            "deleted_root": str(self.deleted_root) if self.deleted_root else None,
            "ran": self.ran,
            "status": self.status,
            "reason": self.reason,
            "caveats": list(self.caveats),
        }


def detect_filesystems(path: str | Path, *, max_scan_bytes: int = 1024 * 1024 * 1024) -> list[FilesystemCandidate]:
    """Return recognised filesystems, preferring partition-table starts."""
    p = Path(path).resolve()
    size = p.stat().st_size
    starts: dict[int, str] = {0: "super-floppy/direct"}
    with open(p, "rb") as fh:
        sector0 = fh.read(512)
        for start, source in _mbr_starts(sector0):
            starts.setdefault(start * SECTOR_SIZE, source)
        for start, source in _gpt_starts(fh, sector0, size):
            starts.setdefault(start * SECTOR_SIZE, source)

        # Typical boundaries are a fallback, not the primary detector.
        common_sectors = (63, 64, 128, 2048, 4096, 8192, 32768, 65536, 131072)
        for sector in common_sectors:
            byte_off = sector * SECTOR_SIZE
            if byte_off < min(size, max_scan_bytes):
                starts.setdefault(byte_off, "signature scan")

        found: list[FilesystemCandidate] = []
        seen: set[tuple[str, int]] = set()
        for offset, source in sorted(starts.items()):
            candidate = _detect_at(fh, offset, source, size)
            if candidate and (candidate.fs_type, candidate.offset_bytes) not in seen:
                found.append(candidate)
                seen.add((candidate.fs_type, candidate.offset_bytes))
        return found


def best_filesystem(path: str | Path) -> Optional[FilesystemCandidate]:
    found = detect_filesystems(path)
    if not found:
        return None
    source_rank = {"MBR partition": 0, "GPT partition": 0, "super-floppy/direct": 1, "signature scan": 2}
    found.sort(key=lambda c: (source_rank.get(c.source, 3), c.offset_bytes))
    return found[0]


def native_preflight(path: str | Path) -> tuple[bool, Optional[FilesystemCandidate], str]:
    candidate = best_filesystem(path)
    if candidate is None:
        return False, None, "No FAT, NTFS, or ext2/3/4 signature was recognised natively"
    if candidate.fs_type.startswith("FAT"):
        try:
            parser = FatVolume(Path(path), candidate.offset_bytes)
            entries = parser.list_files(max_entries=10)
            return True, candidate, f"Native FAT parser read {len(entries)} directory entr{'y' if len(entries) == 1 else 'ies'}"
        except Exception as exc:
            return False, candidate, f"FAT signature found but directory parsing failed: {exc}"
    if candidate.fs_type == "NTFS":
        try:
            from tools.analyze_image import find_ntfs_partitions, parse_mbr, parse_mft
            volumes = find_ntfs_partitions(str(path), parse_mbr(str(path)))
            matching = next((v for v in volumes if v["partition_offset"] == candidate.offset_bytes), None)
            if not matching:
                return False, candidate, "NTFS VBR recognised but MFT geometry could not be resolved"
            entries = parse_mft(str(path), matching, max_entries=25)
            return True, candidate, f"Native NTFS parser read {len(entries)} MFT file record(s)"
        except Exception as exc:
            return False, candidate, f"NTFS signature found but MFT parsing failed: {exc}"
    # ext is recognised and its superblock parsed. Full inode traversal is not
    # yet implemented, therefore this is a caveated successful recognition.
    return True, candidate, "Native ext superblock parsed; inode traversal is not yet implemented"


def analyze_and_extract(
    path: str | Path,
    output_dir: str | Path,
    *,
    max_files: int = 0,
    max_extract_bytes: int = 0,
) -> NativeFilesystemResult:
    p = Path(path).resolve()
    out = Path(output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    candidate = best_filesystem(p)
    if candidate is None:
        return NativeFilesystemResult(
            candidate=None, ran=True, status="ran_found_nothing",
            reason="Filesystem not recognised by native FAT/NTFS/ext detectors",
        )

    if candidate.fs_type.startswith("FAT"):
        parser = FatVolume(p, candidate.offset_bytes)
        files = parser.list_files(max_entries=max_files)
        active_root = out / "extracted_files"
        deleted_root = out / "deleted_files"
        active_root.mkdir(parents=True, exist_ok=True)
        deleted_root.mkdir(parents=True, exist_ok=True)
        total_written = 0
        active_clusters = {
            cluster for entry in files if not entry.deleted
            for cluster in entry.cluster_chain
        }
        for entry in files:
            if entry.is_directory or entry.size_bytes <= 0:
                continue
            if max_extract_bytes > 0 and total_written >= max_extract_bytes:
                entry.caveats.append("Configured extraction budget exhausted; metadata retained and content unresolved")
                continue
            content, status, caveats = parser.read_file(entry, active_clusters=active_clusters)
            entry.recovery_status = status
            entry.caveats = list(dict.fromkeys(caveats))
            if status == "overwritten_or_reallocated":
                # The cluster now belongs to an active file.  Writing those
                # bytes out under the deleted filename would fabricate a
                # recovery and misattribute another file's content.
                entry.caveats.append(
                    "Content deliberately withheld because the deleted extent is reallocated"
                )
                continue
            if not content:
                continue
            if max_extract_bytes > 0 and total_written + len(content) > max_extract_bytes:
                content = content[: max_extract_bytes - total_written]
                entry.caveats.append("Content truncated by configured extraction budget; full content unresolved")
            root = deleted_root if entry.deleted else active_root
            safe_rel = _safe_relative_path(entry.path, deleted=entry.deleted)
            dest = root / safe_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
            total_written += len(content)
            entry.extracted_path = str(dest)
            entry.sha256 = hashlib.sha256(content).hexdigest()
        result = NativeFilesystemResult(
            candidate=candidate,
            files=files,
            extracted_root=active_root,
            deleted_root=deleted_root,
            ran=True,
            status="ran_found_x" if files else "ran_found_nothing",
            reason=f"Native {candidate.fs_type} parser completed",
        )
    elif candidate.fs_type == "NTFS":
        from tools.analyze_image import find_ntfs_partitions, parse_mbr, parse_mft
        volumes = find_ntfs_partitions(str(p), parse_mbr(str(p)))
        matching = next((v for v in volumes if v["partition_offset"] == candidate.offset_bytes), None)
        if not matching:
            return NativeFilesystemResult(
                candidate=candidate, ran=True, status="ran_with_caveat",
                reason="NTFS VBR parsed but MFT location could not be validated",
                caveats=["No file extraction performed"],
            )
        rows = parse_mft(str(p), matching, max_entries=max_files)
        files = [
            NativeFile(
                path=str(row.get("path") or row.get("name") or f"mft_{row.get('entry_no', 0)}"),
                name=Path(str(row.get("path") or row.get("name") or "")).name,
                is_directory=bool(row.get("is_directory", row.get("directory", False))),
                deleted=bool(row.get("deleted", row.get("is_deleted", False))),
                size_bytes=int(row.get("size_bytes") or 0),
                first_cluster=0,
                attributes=int(row.get("flags") or 0),
                created=row.get("created"), modified=row.get("modified"), accessed=row.get("accessed"),
                recovery_status="metadata_only",
                caveats=["NTFS non-resident data extraction is not implemented in the native path"],
            ) for row in rows
        ]
        result = NativeFilesystemResult(
            candidate=candidate, files=files, ran=True,
            status="ran_with_caveat",
            reason=f"Native NTFS MFT parser read {len(files)} file record(s)",
            caveats=["NTFS file content extraction is limited to metadata in this increment"],
        )
    else:
        result = NativeFilesystemResult(
            candidate=candidate, ran=True, status="ran_with_caveat",
            reason=f"Native {candidate.fs_type} superblock parsed",
            caveats=["ext inode and extent traversal is not implemented in this increment"],
        )

    manifest = out / "native_filesystem_manifest.json"
    manifest.write_text(json.dumps(result.as_dict(), indent=2, default=str), encoding="utf-8")
    return result


def _detect_at(fh: BinaryIO, offset: int, source: str, image_size: int) -> Optional[FilesystemCandidate]:
    if offset < 0 or offset + 512 > image_size:
        return None
    fh.seek(offset)
    vbr = fh.read(512)
    if len(vbr) < 512:
        return None
    fat = _fat_bpb(vbr)
    if fat:
        return FilesystemCandidate(
            fs_type=str(fat["fat_type"]), offset_bytes=offset,
            offset_sectors=offset // SECTOR_SIZE, source=source, metadata=fat,
        )
    if vbr[3:11] == b"NTFS    ":
        bps = struct.unpack_from("<H", vbr, 11)[0]
        spc = vbr[13]
        total = struct.unpack_from("<Q", vbr, 40)[0]
        if bps in (512, 1024, 2048, 4096) and spc and spc & (spc - 1) == 0:
            return FilesystemCandidate(
                fs_type="NTFS", offset_bytes=offset, offset_sectors=offset // SECTOR_SIZE,
                source=source,
                metadata={
                    "bytes_per_sector": bps,
                    "sectors_per_cluster": spc,
                    "cluster_size": bps * spc,
                    "total_sectors": total,
                    "mft_lcn": struct.unpack_from("<Q", vbr, 48)[0],
                    "volume_serial": f"{struct.unpack_from('<Q', vbr, 72)[0]:016X}",
                },
            )
    if offset + 2048 <= image_size:
        fh.seek(offset + 1024)
        sb = fh.read(1024)
        if len(sb) >= 160 and struct.unpack_from("<H", sb, 56)[0] == 0xEF53:
            compat = struct.unpack_from("<I", sb, 92)[0]
            incompat = struct.unpack_from("<I", sb, 96)[0]
            ro_compat = struct.unpack_from("<I", sb, 100)[0]
            fs_type = "ext4" if incompat & 0x40 else ("ext3" if compat & 0x4 else "ext2")
            block_size = 1024 << struct.unpack_from("<I", sb, 24)[0]
            return FilesystemCandidate(
                fs_type=fs_type, offset_bytes=offset, offset_sectors=offset // SECTOR_SIZE,
                source=source,
                metadata={
                    "inode_count": struct.unpack_from("<I", sb, 0)[0],
                    "block_count_lo": struct.unpack_from("<I", sb, 4)[0],
                    "block_size": block_size,
                    "blocks_per_group": struct.unpack_from("<I", sb, 32)[0],
                    "inodes_per_group": struct.unpack_from("<I", sb, 40)[0],
                    "volume_name": sb[120:136].split(b"\x00", 1)[0].decode("utf-8", errors="replace"),
                    "feature_compat": compat,
                    "feature_incompat": incompat,
                    "feature_ro_compat": ro_compat,
                },
                caveats=["Filesystem recognised from superblock; inode traversal not yet implemented"],
            )
    return None


def _mbr_starts(sector0: bytes) -> list[tuple[int, str]]:
    if len(sector0) < 512 or sector0[510:512] != b"\x55\xaa":
        return []
    starts = []
    for i in range(4):
        entry = sector0[446 + i * 16: 462 + i * 16]
        type_id = entry[4]
        lba = struct.unpack_from("<I", entry, 8)[0]
        count = struct.unpack_from("<I", entry, 12)[0]
        if type_id and lba and count:
            starts.append((lba, "MBR partition"))
    return starts


def _gpt_starts(fh: BinaryIO, sector0: bytes, image_size: int) -> list[tuple[int, str]]:
    if not any(entry[4] == 0xEE for entry in [sector0[446+i*16:462+i*16] for i in range(4)] if len(entry) == 16):
        return []
    fh.seek(SECTOR_SIZE)
    hdr = fh.read(SECTOR_SIZE)
    if len(hdr) < 92 or hdr[:8] != b"EFI PART":
        return []
    entries_lba = struct.unpack_from("<Q", hdr, 72)[0]
    count = min(struct.unpack_from("<I", hdr, 80)[0], 4096)
    entry_size = struct.unpack_from("<I", hdr, 84)[0]
    if entry_size < 128 or entries_lba * SECTOR_SIZE >= image_size:
        return []
    starts = []
    fh.seek(entries_lba * SECTOR_SIZE)
    for _ in range(count):
        entry = fh.read(entry_size)
        if len(entry) < entry_size:
            break
        if entry[:16] == b"\x00" * 16:
            continue
        first_lba = struct.unpack_from("<Q", entry, 32)[0]
        last_lba = struct.unpack_from("<Q", entry, 40)[0]
        if first_lba and last_lba >= first_lba:
            starts.append((first_lba, "GPT partition"))
    return starts


def _fat_bpb(vbr: bytes) -> Optional[dict[str, object]]:
    try:
        bps = struct.unpack_from("<H", vbr, 11)[0]
        spc = vbr[13]
        reserved = struct.unpack_from("<H", vbr, 14)[0]
        fats = vbr[16]
        root_entries = struct.unpack_from("<H", vbr, 17)[0]
        total16 = struct.unpack_from("<H", vbr, 19)[0]
        fat16 = struct.unpack_from("<H", vbr, 22)[0]
        total32 = struct.unpack_from("<I", vbr, 32)[0]
        fat32 = struct.unpack_from("<I", vbr, 36)[0]
    except struct.error:
        return None
    if bps not in (512, 1024, 2048, 4096) or spc == 0 or spc & (spc - 1) or fats not in (1, 2):
        return None
    total = total16 or total32
    fat_size = fat16 or fat32
    if not total or not fat_size or reserved == 0:
        return None
    root_dir_sectors = (root_entries * 32 + bps - 1) // bps
    data_start = reserved + fats * fat_size + root_dir_sectors
    if data_start >= total:
        return None
    clusters = (total - data_start) // spc
    fat_type = "FAT12" if clusters < 4085 else ("FAT16" if clusters < 65525 else "FAT32")
    root_cluster = struct.unpack_from("<I", vbr, 44)[0] if fat_type == "FAT32" else 0
    label_slice = vbr[71:82] if fat_type == "FAT32" else vbr[43:54]
    serial_offset = 67 if fat_type == "FAT32" else 39
    volume_serial_int = struct.unpack_from("<I", vbr, serial_offset)[0]
    volume_serial_hex = f"{volume_serial_int:08X}"
    volume_serial = f"{volume_serial_hex[:4]}-{volume_serial_hex[4:]}"
    return {
        "fat_type": fat_type,
        "oem_name": vbr[3:11].decode("ascii", errors="replace").strip(),
        "bytes_per_sector": bps,
        "sectors_per_cluster": spc,
        "reserved_sectors": reserved,
        "num_fats": fats,
        "root_entries": root_entries,
        "total_sectors": total,
        "fat_size_sectors": fat_size,
        "root_dir_sectors": root_dir_sectors,
        "data_start_sector": data_start,
        "cluster_count": clusters,
        "cluster_size": bps * spc,
        "root_cluster": root_cluster,
        "volume_label": label_slice.split(b"\x00", 1)[0].decode("ascii", errors="replace").strip(),
        "volume_serial": volume_serial,
        "volume_serial_raw": volume_serial_int,
    }


class FatVolume:
    def __init__(self, image_path: Path, offset_bytes: int):
        self.image_path = image_path
        self.offset = offset_bytes
        with open(image_path, "rb") as fh:
            fh.seek(offset_bytes)
            bpb = _fat_bpb(fh.read(512))
        if not bpb:
            raise ValueError("Not a valid FAT volume")
        self.bpb = bpb
        self.fat_type = str(bpb["fat_type"])
        self.bps = int(bpb["bytes_per_sector"])
        self.spc = int(bpb["sectors_per_cluster"])
        self.cluster_size = int(bpb["cluster_size"])
        self.fat_offset = self.offset + int(bpb["reserved_sectors"]) * self.bps
        self.root_offset = self.offset + (
            int(bpb["reserved_sectors"]) + int(bpb["num_fats"]) * int(bpb["fat_size_sectors"])
        ) * self.bps
        self.data_offset = self.offset + int(bpb["data_start_sector"]) * self.bps
        self.image_size = image_path.stat().st_size

    def cluster_offset(self, cluster: int) -> int:
        return self.data_offset + (cluster - 2) * self.cluster_size

    def next_cluster(self, fh: BinaryIO, cluster: int) -> int:
        if self.fat_type == "FAT12":
            off = self.fat_offset + cluster + cluster // 2
            fh.seek(off)
            pair = fh.read(2)
            if len(pair) < 2:
                return 0xFFF
            value = struct.unpack("<H", pair)[0]
            return (value >> 4) & 0xFFF if cluster & 1 else value & 0xFFF
        if self.fat_type == "FAT16":
            fh.seek(self.fat_offset + cluster * 2)
            data = fh.read(2)
            return struct.unpack("<H", data)[0] if len(data) == 2 else 0xFFFF
        fh.seek(self.fat_offset + cluster * 4)
        data = fh.read(4)
        return (struct.unpack("<I", data)[0] & 0x0FFFFFFF) if len(data) == 4 else 0x0FFFFFFF

    def is_eoc(self, value: int) -> bool:
        return value >= {"FAT12": 0xFF8, "FAT16": 0xFFF8, "FAT32": 0x0FFFFFF8}[self.fat_type]

    def chain(self, first: int, *, max_clusters: int = 0) -> tuple[list[int], list[str]]:
        if first < 2:
            return [], []
        chain: list[int] = []
        caveats: list[str] = []
        seen: set[int] = set()
        with open(self.image_path, "rb") as fh:
            current = first
            while current >= 2 and (max_clusters <= 0 or len(chain) < max_clusters):
                if current in seen:
                    caveats.append("FAT cluster-chain loop detected")
                    break
                if self.cluster_offset(current) >= self.image_size:
                    caveats.append("FAT cluster points outside evidence image")
                    break
                seen.add(current)
                chain.append(current)
                nxt = self.next_cluster(fh, current)
                if self.is_eoc(nxt):
                    break
                if nxt == 0:
                    break
                if nxt == 1 or nxt >= 0x0FFFFFF7:
                    caveats.append(f"Invalid/bad FAT cluster marker 0x{nxt:x}")
                    break
                current = nxt
        if max_clusters > 0 and len(chain) >= max_clusters:
            caveats.append(f"Configured FAT cluster-chain limit reached at {max_clusters}; chain may be incomplete")
        return chain, caveats

    def list_files(self, *, max_entries: int = 0) -> list[NativeFile]:
        entries: list[NativeFile] = []
        visited_dirs: set[int] = set()
        with open(self.image_path, "rb") as fh:
            if self.fat_type == "FAT32":
                root_cluster = int(self.bpb["root_cluster"])
                data = self._read_chain_bytes(fh, root_cluster)
                self._parse_directory(fh, data, "/", entries, visited_dirs, max_entries)
            else:
                root_size = int(self.bpb["root_entries"]) * 32
                fh.seek(self.root_offset)
                data = fh.read(root_size)
                self._parse_directory(fh, data, "/", entries, visited_dirs, max_entries)
        return entries if max_entries <= 0 else entries[:max_entries]

    def _read_chain_bytes(self, fh: BinaryIO, first: int, *, limit_clusters: int = 0) -> bytes:
        chain, _ = self.chain(first, max_clusters=limit_clusters)
        out = bytearray()
        for cluster in chain:
            fh.seek(self.cluster_offset(cluster))
            out += fh.read(self.cluster_size)
        return bytes(out)

    def _parse_directory(
        self, fh: BinaryIO, data: bytes, prefix: str, out: list[NativeFile],
        visited_dirs: set[int], max_entries: int,
    ) -> None:
        lfn_parts: list[str] = []
        lfn_deleted = False
        lfn_checksums: list[int] = []
        for pos in range(0, len(data), 32):
            if max_entries > 0 and len(out) >= max_entries:
                return
            entry = data[pos:pos + 32]
            if len(entry) < 32:
                return
            first = entry[0]
            if first == 0x00:
                return
            attrs = entry[11]
            deleted = first == 0xE5
            if attrs == 0x0F:
                chars = entry[1:11] + entry[14:26] + entry[28:32]
                part = chars.decode("utf-16-le", errors="replace").replace("\x00", "").replace("\uffff", "")
                lfn_parts.insert(0, part)
                lfn_deleted = lfn_deleted or deleted
                lfn_checksums.append(entry[13])
                continue
            if attrs & 0x08:  # volume label
                lfn_parts = []
                lfn_deleted = False
                lfn_checksums = []
                continue
            short = bytearray(entry[:8])
            if deleted:
                short[0] = ord("_")
            base = bytes(short).decode("ascii", errors="replace").rstrip()
            ext = entry[8:11].decode("ascii", errors="replace").rstrip()
            # FAT deletion erases the first byte of both the short entry and
            # each preceding LFN entry, but the UTF-16 name fragments remain.
            # Preserve the contiguous LFN fragments instead of falling back to
            # the damaged 8.3 alias.  This is evidence-derived recovery, not a
            # guessed first character.
            recovered_deleted_lfn = bool(deleted and lfn_parts and lfn_deleted)
            name = "".join(lfn_parts).strip() if lfn_parts else (f"{base}.{ext}" if ext else base)
            lfn_parts = []
            lfn_deleted = False
            lfn_checksums = []
            name = _clean_component(name)
            if not name or name in (".", ".."):
                continue
            first_cluster = (struct.unpack_from("<H", entry, 20)[0] << 16) | struct.unpack_from("<H", entry, 26)[0]
            size = struct.unpack_from("<I", entry, 28)[0]
            is_dir = bool(attrs & 0x10)
            path = str(PurePosixPath(prefix) / name)
            chain, caveats = self.chain(first_cluster)
            if recovered_deleted_lfn:
                caveats.append(
                    "Deleted long filename reconstructed from intact UTF-16 LFN fragments; "
                    "the erased ordinal/first-byte marker was not guessed"
                )
            if deleted and size:
                # FAT normally clears the deleted file's FAT entries.  chain()
                # therefore often returns only the first cluster before seeing
                # a zero marker.  If fewer clusters than the recorded file size
                # requires are available, retain a clearly caveated contiguous
                # extent. read_file() later refuses it if any cluster has been
                # reallocated to an active file.
                needed = math.ceil(size / self.cluster_size)
                if first_cluster >= 2 and len(chain) < needed:
                    chain = list(range(first_cluster, first_cluster + needed))
                    caveats.append(
                        "Deleted FAT chain was cleared/incomplete; contiguous allocation "
                        f"assumed for {needed} cluster(s) from the recorded first cluster"
                    )
            item = NativeFile(
                path=path, name=name, is_directory=is_dir, deleted=deleted,
                size_bytes=size, first_cluster=first_cluster, attributes=attrs,
                created=_fat_datetime(struct.unpack_from("<H", entry, 14)[0], struct.unpack_from("<H", entry, 16)[0]),
                modified=_fat_datetime(struct.unpack_from("<H", entry, 22)[0], struct.unpack_from("<H", entry, 24)[0]),
                accessed=_fat_date(struct.unpack_from("<H", entry, 18)[0]),
                cluster_chain=chain, caveats=caveats,
            )
            out.append(item)
            if is_dir and not deleted and first_cluster >= 2 and first_cluster not in visited_dirs:
                visited_dirs.add(first_cluster)
                sub = self._read_chain_bytes(fh, first_cluster)
                self._parse_directory(fh, sub, path, out, visited_dirs, max_entries)

    def read_file(self, entry: NativeFile, *, active_clusters: set[int]) -> tuple[bytes, str, list[str]]:
        caveats = list(entry.caveats)
        if not entry.cluster_chain or entry.size_bytes <= 0:
            return b"", "not_recoverable", caveats
        if entry.deleted and any(c in active_clusters for c in entry.cluster_chain):
            caveats.append("One or more deleted-file clusters are allocated to an active file")
            status = "overwritten_or_reallocated"
        else:
            status = "recovered" if entry.deleted else "extracted"
        out = bytearray()
        with open(self.image_path, "rb") as fh:
            for cluster in entry.cluster_chain:
                off = self.cluster_offset(cluster)
                if off < 0 or off >= self.image_size:
                    caveats.append("Cluster extent exceeds image boundary")
                    break
                fh.seek(off)
                out += fh.read(min(self.cluster_size, entry.size_bytes - len(out)))
                if len(out) >= entry.size_bytes:
                    break
        if len(out) < entry.size_bytes:
            caveats.append(f"Only {len(out)} of {entry.size_bytes} bytes were recovered")
            status = "partial_recovery"
        return bytes(out[:entry.size_bytes]), status, caveats


def _fat_date(value: int) -> Optional[str]:
    if not value:
        return None
    year, month, day = 1980 + ((value >> 9) & 0x7F), (value >> 5) & 0x0F, value & 0x1F
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return None
    return f"{year:04d}-{month:02d}-{day:02d}"


def _fat_datetime(time_value: int, date_value: int) -> Optional[str]:
    date = _fat_date(date_value)
    if not date:
        return None
    hour, minute, second = (time_value >> 11) & 0x1F, (time_value >> 5) & 0x3F, (time_value & 0x1F) * 2
    if hour > 23 or minute > 59 or second > 59:
        return date
    return f"{date}T{hour:02d}:{minute:02d}:{second:02d}"


def _clean_component(name: str) -> str:
    """Return a source-path-safe representation without truncating evidence names.

    FAT/NTFS source names may contain Unicode.  Preserve printable Unicode and
    replace only characters that cannot be represented safely as one path
    component.  Length reduction belongs solely to the derived-output path.
    """
    name = "".join(
        ch if ch.isprintable() and ch not in '<>:\"/\\|?*' else "_"
        for ch in str(name)
    )
    return name.replace("\x00", "_").strip(" .")


def _safe_output_component(name: str, max_bytes: int = 240) -> str:
    """Bound a derived output filename without truncating the source record."""
    cleaned = _clean_component(name) or "unnamed"
    encoded = cleaned.encode("utf-8", errors="replace")
    if len(encoded) <= max_bytes:
        return cleaned
    suffix = "_" + hashlib.sha256(encoded).hexdigest()[:12]
    budget = max(1, max_bytes - len(suffix.encode("ascii")))
    prefix = encoded[:budget]
    while prefix:
        try:
            return prefix.decode("utf-8") + suffix
        except UnicodeDecodeError:
            prefix = prefix[:-1]
    return "unnamed" + suffix


def _safe_relative_path(path: str, *, deleted: bool) -> Path:
    components = [
        _safe_output_component(p)
        for p in PurePosixPath(path).parts
        if p not in ("/", "", ".", "..")
    ]
    if not components:
        components = ["unnamed"]
    if deleted:
        components[-1] = _safe_output_component(f"DELETED_{components[-1]}")
    return Path(*components)
