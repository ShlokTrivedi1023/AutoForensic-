"""Deterministic FAT32 structural validation over a read-only media stream."""
from __future__ import annotations

import json
import struct
from pathlib import Path
from typing import Any


def _u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def _u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def validate_fat32(media_path: Path, offset_bytes: int = 0, manifest_path: str | Path | None = None) -> dict[str, Any]:
    """Return exact FAT32 geometry, copy comparison and allocation statistics.

    No filename, hash, expected count or case identifier is used. All values are
    derived from the BPB, FAT copies and the native filesystem manifest produced
    during the current investigation.
    """
    media_path = Path(media_path)
    with media_path.open("rb") as fh:
        fh.seek(offset_bytes)
        boot = fh.read(512)
        if len(boot) != 512 or boot[510:512] != b"\x55\xaa":
            raise ValueError("FAT boot sector signature is missing or truncated")
        bps = _u16(boot, 11)
        spc = boot[13]
        reserved = _u16(boot, 14)
        fats = boot[16]
        root_entries = _u16(boot, 17)
        total16 = _u16(boot, 19)
        fat16 = _u16(boot, 22)
        total32 = _u32(boot, 32)
        fat32 = _u32(boot, 36)
        root_cluster = _u32(boot, 44)
        backup_sector = _u16(boot, 50)
        total_sectors = total16 or total32
        fat_sectors = fat16 or fat32
        root_dir_sectors = ((root_entries * 32) + (bps - 1)) // bps
        data_start_sector = reserved + fats * fat_sectors + root_dir_sectors
        data_sectors = total_sectors - data_start_sector
        cluster_count = data_sectors // spc
        fat_offsets = [offset_bytes + (reserved + i * fat_sectors) * bps for i in range(fats)]
        fat_blobs: list[bytes] = []
        for fat_offset in fat_offsets:
            fh.seek(fat_offset)
            fat_blobs.append(fh.read(fat_sectors * bps))
        backup_equal = None
        backup_valid = False
        if backup_sector not in (0, 0xFFFF):
            fh.seek(offset_bytes + backup_sector * bps)
            backup = fh.read(512)
            backup_valid = len(backup) == 512 and backup[510:512] == b"\x55\xaa"
            backup_equal = backup == boot

    fat_copy_equal = len(fat_blobs) >= 2 and all(blob == fat_blobs[0] for blob in fat_blobs[1:])
    fat = fat_blobs[0] if fat_blobs else b""
    free = allocated = bad = reserved_entries = 0
    allocated_clusters: set[int] = set()
    for cluster in range(2, cluster_count + 2):
        pos = cluster * 4
        if pos + 4 > len(fat):
            break
        value = _u32(fat, pos) & 0x0FFFFFFF
        if value == 0:
            free += 1
        elif value == 0x0FFFFFF7:
            bad += 1
        elif 0x0FFFFFF0 <= value <= 0x0FFFFFF6:
            reserved_entries += 1
        else:
            allocated += 1
            allocated_clusters.add(cluster)

    records: list[dict[str, Any]] = []
    if manifest_path:
        mp = Path(manifest_path)
        if mp.is_file():
            try:
                payload = json.loads(mp.read_text(encoding="utf-8"))
                records = [x for x in payload.get("files", []) if isinstance(x, dict)]
            except (OSError, json.JSONDecodeError):
                records = []
    active_records = [r for r in records if not bool(r.get("deleted"))]
    deleted_records = [r for r in records if bool(r.get("deleted"))]
    active_files = sum(1 for r in active_records if not bool(r.get("is_directory")))
    active_dirs = sum(1 for r in active_records if bool(r.get("is_directory")))
    deleted_files = sum(1 for r in deleted_records if not bool(r.get("is_directory")))
    deleted_dirs = sum(1 for r in deleted_records if bool(r.get("is_directory")))
    referenced: set[int] = set()
    ownership: dict[int, list[str]] = {}
    chain_errors: list[dict[str, Any]] = []

    def own(cluster: int, owner: str) -> None:
        if cluster < 2:
            return
        referenced.add(cluster)
        ownership.setdefault(cluster, []).append(owner)

    # The FAT32 root directory is a filesystem object even though it has no
    # parent directory entry.  Follow its complete FAT chain before evaluating
    # orphan status.  This is generic and evidence-derived.
    try:
        from core.native_filesystem import FatVolume
        volume = FatVolume(media_path, offset_bytes)
        root_chain, root_caveats = volume.chain(root_cluster)
        for cluster in root_chain:
            own(cluster, 'FAT32 root directory')
        # Re-parse directory entries directly so directory-chain ownership does
        # not depend on whether a report manifest chose to include directories.
        for entry in volume.list_files(max_entries=0):
            if entry.deleted:
                continue
            owner = f"directory:{entry.path}" if entry.is_directory else f"file:{entry.path}"
            for cluster in entry.cluster_chain:
                own(int(cluster), owner)
    except Exception as exc:
        root_chain = [root_cluster] if root_cluster >= 2 else []
        root_caveats = [f'native ownership parse unavailable: {exc}']
        for cluster in root_chain:
            own(cluster, 'FAT32 root directory (BPB)')

    for record in active_records:
        chain = [int(c) for c in (record.get("cluster_chain") or []) if isinstance(c, int) or str(c).isdigit()]
        for c in chain:
            if c >= 2:
                own(c, f"manifest:{record.get('path') or 'unknown'}")
        if not bool(record.get("is_directory")):
            size = int(record.get("size_bytes") or 0)
            expected_min = (size + (bps * spc) - 1) // (bps * spc) if size else 0
            if len(chain) < expected_min:
                chain_errors.append({"path": record.get("path"), "reason": "chain shorter than declared file size",
                                     "chain_length": len(chain), "minimum_clusters": expected_min})
        for c in chain:
            if c not in allocated_clusters:
                chain_errors.append({"path": record.get("path"), "reason": "active chain references non-allocated FAT entry",
                                     "cluster": c})
    orphan_clusters = sorted(allocated_clusters - referenced)
    # Directory-chain clusters and system-reserved data clusters may be present in
    # the manifest; any residual is reported, never silently labelled an orphan
    # unless the manifest covered active files and directories.
    orphan_analysis_complete = bool(records)

    return {
        "filesystem": "FAT32",
        "offset_bytes": offset_bytes,
        "bytes_per_sector": bps,
        "sectors_per_cluster": spc,
        "cluster_size": bps * spc,
        "reserved_sectors": reserved,
        "number_of_fats": fats,
        "fat_size_sectors": fat_sectors,
        "total_sectors": total_sectors,
        "data_start_sector": data_start_sector,
        "data_cluster_count": cluster_count,
        "root_cluster": root_cluster,
        "backup_boot_sector": backup_sector,
        "backup_boot_sector_valid": backup_valid,
        "primary_backup_boot_sectors_equal": backup_equal,
        "fat_copies_equal": fat_copy_equal,
        "allocated_clusters": allocated,
        "free_clusters": free,
        "bad_clusters": bad,
        "reserved_fat_entries": reserved_entries,
        "native_manifest_records": len(records),
        "active_files": active_files,
        "active_directories": active_dirs,
        "deleted_files": deleted_files,
        "deleted_directories": deleted_dirs,
        "logical_file_total": active_files + deleted_files,
        "active_chain_validation_errors": chain_errors,
        "active_chains_valid": not chain_errors if records else None,
        "orphan_analysis_complete": orphan_analysis_complete,
        "allocated_orphan_clusters": orphan_clusters if orphan_analysis_complete else [],
        "allocated_orphan_cluster_count": len(orphan_clusters) if orphan_analysis_complete else None,
        "cluster_ownership": {str(k): sorted(set(v)) for k, v in sorted(ownership.items())},
        "root_directory_chain": root_chain,
        "root_directory_chain_caveats": root_caveats,
        "validation_basis": ["FAT32 BPB", "backup boot sector", "all FAT copies", "native directory traversal", "native manifest cluster chains"],
    }
