"""Synchronise module status, assurance, canonical ledger and report counts.

The platform previously allowed raw module summaries, candidate counts and
post-assurance findings to diverge.  This finaliser makes the accepted findings
list the single source of truth after deterministic reconciliation and H2
reference assurance.
"""
from __future__ import annotations

from typing import Any
import re

from core.fact_classification import FactClass, UNIQUE_EVIDENCE_CLASSES
from core.evidence_ledger import reconciliation_counts

from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    SkipReason,
)


def _ledger_counts(result: ModuleResult) -> dict[str, int]:
    return reconciliation_counts(dict(result.statistics or {}))


def finalise_canonical_result(result: ModuleResult) -> ModuleResult:
    """Make accepted findings authoritative for all machine-readable summaries."""
    findings = list(result.findings or [])
    accepted = len(findings)
    fact_counts: dict[str, int] = {}
    unique_ids: set[str] = set()
    for finding in findings:
        metadata = dict(getattr(finding, "metadata", {}) or {})
        fact_class = str(metadata.get("fact_class") or FactClass.PRIMARY_EVIDENCE.value)
        fact_counts[fact_class] = fact_counts.get(fact_class, 0) + 1
        if fact_class in UNIQUE_EVIDENCE_CLASSES and metadata.get("counts_toward_unique_evidence", True):
            unique_ids.add(str(metadata.get("evidence_object_id") or getattr(finding, "finding_id", "")))
    unique_evidence = len(unique_ids)
    ledger = _ledger_counts(result)
    candidates = int(ledger["candidate"])
    reconciler_rejected = int(ledger["rejected"])
    unresolved = int(ledger["unresolved"])
    stats = dict(result.statistics or {})
    assurance = stats.get("finding_assurance") or {}
    assurance_rejected = int(assurance.get("rejected") or 0)
    rejected = assurance_rejected + reconciler_rejected

    if result.status in {ModuleStatus.ERROR, ModuleStatus.FAILED, ModuleStatus.FAILED_OFFSET, ModuleStatus.IMPORT_FAILED, ModuleStatus.FAILED_ISOLATED}:
        outcome = "did_not_run" if accepted == 0 else "ran_with_caveat"
    elif result.status in {ModuleStatus.SKIPPED, ModuleStatus.NOT_APPLICABLE, ModuleStatus.VERIFY_LATER}:
        outcome = "did_not_run"
    elif accepted:
        outcome = "ran_with_caveat" if result.status in {ModuleStatus.PARTIAL, ModuleStatus.COMPLETED_WITH_FALLBACK} else "ran_found_x"
    elif candidates or unresolved or rejected or result.status in {ModuleStatus.PARTIAL, ModuleStatus.COMPLETED_WITH_FALLBACK}:
        outcome = "ran_with_caveat"
    else:
        outcome = "ran_found_nothing"

    stats["execution_outcome"] = outcome
    def _first_int(keys: tuple[str, ...], default: int = 0) -> int:
        for key in keys:
            value = stats.get(key)
            if value not in (None, ""):
                try:
                    return int(value)
                except (TypeError, ValueError):
                    continue
        return default

    derived_count = fact_counts.get(FactClass.DERIVED_FACT.value, 0) + fact_counts.get(FactClass.AGGREGATE_SUMMARY.value, 0)
    alternative_count = fact_counts.get(FactClass.ALTERNATIVE_REPRESENTATION.value, 0)
    duplicate_count = _first_int(("duplicate_representations", "duplicates", "duplicate_count"), 0)
    objects_examined = _first_int((
        "objects_examined", "files_processed", "files_examined", "documents_discovered",
        "files_scanned", "total_files", "records_examined", "hashes_attempted",
        "technical_event_count", "hives_found", "total_images", "packets_processed",
    ), accepted + candidates + unresolved + rejected)
    # A module-specific counter may legitimately be present as zero even while
    # canonical findings prove that objects were examined. Do not propagate a
    # contradictory zero into the examiner report.
    if objects_examined <= 0 and (accepted or candidates or rejected):
        objects_examined = accepted + candidates + unresolved + rejected
    stats["module_statistics"] = {
        "inputs_received": _first_int(("inputs_received", "input_count"), 1),
        "objects_examined": objects_examined,
        "raw_observations": _first_int(("raw_observations", "observations", "records_parsed"), accepted + candidates + unresolved + rejected),
        "accepted_records": accepted,
        "unique_evidence_objects": unique_evidence,
        "candidate_observations": candidates,
        "rejected_observations": rejected,
        "unresolved_observations": unresolved,
        "duplicate_representations": duplicate_count,
        "derived_facts": derived_count,
        "alternative_representations": alternative_count,
        "errors": len(result.errors or []),
        "skipped_objects": _first_int(("skipped_objects", "skipped", "invalid_candidates_skipped"), 0),
        "fallback_used": result.status == ModuleStatus.COMPLETED_WITH_FALLBACK,
    }
    stats["canonical_result"] = {
        "accepted_records": accepted,
        "accepted_findings": accepted,  # compatibility alias
        "unique_evidence_objects": unique_evidence,
        "fact_class_counts": dict(sorted(fact_counts.items())),
        "candidate_observations": candidates,
        "rejected_observations": rejected,
        "unresolved_observations": unresolved,
        "assurance_rejected": assurance_rejected,
        "authoritative": True,
        "counting_policy": (
            "Only PRIMARY_EVIDENCE and VERIFIED_DECODED_EVIDENCE increase unique evidence totals; "
            "derived facts, aggregate summaries and alternative representations remain separately retained."
        ),
        "policy": "Accepted records and unique evidence totals are reported separately; candidates cannot be promoted without deterministic validation.",
    }
    result.statistics = stats

    if not result.class_results:
        result.class_results = [ClassResult(
            locus=Locus.OTHER,
            artefact_class=result.module_name.replace("_", " ").title(),
            verdict=(AssuranceVerdict.PRESENT if accepted else
                     AssuranceVerdict.INDETERMINATE if outcome in {"did_not_run", "ran_with_caveat"} else
                     AssuranceVerdict.VERIFIED_ABSENT),
            count=accepted,
            skip_reason=(SkipReason.PARTIAL_FAILURE if not accepted and outcome == "ran_with_caveat" else
                         SkipReason.SKIPPED if outcome == "did_not_run" else None),
        )]
    else:
        present_classes = [cr for cr in result.class_results if cr.verdict == AssuranceVerdict.PRESENT]
        if accepted:
            if not present_classes:
                # Preserve existing artefact-class names but ensure at least one
                # class accurately represents the accepted finding set.
                first = result.class_results[0]
                first.verdict = AssuranceVerdict.PRESENT
                first.skip_reason = None
                first.count = accepted
                first.notes = (str(first.notes or "") + " Canonical count synchronised after H2 assurance.").strip()
            else:
                # Multiple classes may summarise different domains.  Their sum
                # must not silently exceed the accepted canonical findings.
                remaining = accepted
                for index, cr in enumerate(present_classes):
                    if index == len(present_classes) - 1:
                        cr.count = max(0, remaining)
                    else:
                        requested = max(0, int(cr.count or 0))
                        cr.count = min(requested, remaining)
                        remaining -= cr.count
        else:
            for cr in result.class_results:
                if cr.verdict == AssuranceVerdict.PRESENT:
                    cr.verdict = AssuranceVerdict.INDETERMINATE
                    cr.skip_reason = SkipReason.PARTIAL_FAILURE
                    cr.count = 0
                    cr.notes = (str(cr.notes or "") + " No canonical evidence-referenced finding remained after assurance.").strip()

    # Preserve domain-specific summary text, but append one stable canonical
    # accounting clause.  Remove older trailing count clauses to avoid conflict.
    base = str(result.summary or "").strip()
    if objects_examined > 0:
        base = re.sub(
            r"\b0\s+(artefacts?|artifacts?|objects?|files?)\s+examined\b",
            lambda match: f"{objects_examined} {match.group(1)} examined",
            base,
            flags=re.IGNORECASE,
        )
    accounting = (
        f"Canonical result: {accepted} accepted record(s), {unique_evidence} unique evidence object(s), "
        f"{candidates} candidate observation(s), {rejected} rejected observation(s), "
        f"{unresolved} unresolved observation(s); "
        f"execution_outcome={outcome}."
    )
    if "Canonical result:" in base:
        base = base.split("Canonical result:", 1)[0].rstrip(" ;.")
    result.summary = (base + (" " if base else "") + accounting).strip()
    return result
