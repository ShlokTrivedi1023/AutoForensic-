"""Stable forensic identities used to separate source artefacts from exported aliases."""
from __future__ import annotations
import hashlib
from pathlib import Path
from typing import Any

def _norm_path(value: Any) -> str:
    text=str(value or '').replace('\\','/').strip()
    while '//' in text: text=text.replace('//','/')
    return text.casefold()

def deleted_artifact_identity(*, original_path: Any, starting_cluster: Any=None, deleted_record_id: Any=None, content_hash: Any=None) -> str:
    """Return a stable identity for the original deleted directory record.

    Exported filenames and recovery locations are deliberately excluded, so a recovered
    copy cannot become a second evidential artefact.
    """
    parts=[_norm_path(original_path), str(starting_cluster or ''), str(deleted_record_id or ''), str(content_hash or '').lower()]
    return hashlib.sha256('|'.join(parts).encode('utf-8')).hexdigest()

def finding_deleted_identity(finding: Any) -> str:
    md=getattr(finding,'metadata',{}) or {}
    return deleted_artifact_identity(
        original_path=md.get('original_path') or getattr(finding,'evidence_path',''),
        starting_cluster=md.get('first_cluster') or md.get('starting_cluster') or md.get('cluster'),
        deleted_record_id=md.get('deleted_record_id') or md.get('inode') or md.get('record_id'),
        content_hash=md.get('sha256') or md.get('content_sha256'),
    )

def deduplicate_deleted_findings(findings: list[Any]) -> tuple[list[Any], list[dict[str,Any]]]:
    kept=[]; duplicates=[]; seen={}
    for finding in findings:
        if str(getattr(finding,'finding_type','')).startswith('DELETED_'):
            key=finding_deleted_identity(finding)
            if key in seen:
                duplicates.append({'identity':key,'primary_finding_id':getattr(seen[key],'finding_id',''),'duplicate_finding_id':getattr(finding,'finding_id',''),'evidence_path':getattr(finding,'evidence_path',''),'artifact_path':getattr(finding,'artifact_path',None)})
                continue
            seen[key]=finding
            try: finding.metadata['forensic_identity']=key
            except Exception: pass
        kept.append(finding)
    return kept,duplicates
