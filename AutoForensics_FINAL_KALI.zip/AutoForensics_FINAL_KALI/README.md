# AutoForensics — Kali release

AutoForensics is a case-neutral digital-forensics orchestration, acquisition and reporting platform for Kali Linux. Version 2.8.6 contains **45 active modules**. The non-functional Autopsy integration has been removed rather than simulated or counted.

The platform supports two intake paths:

1. **Existing evidence** — E01/Ex01, DD/IMG/RAW/BIN, supported memory images, PCAP/PCAPNG/CAP and supported mobile extraction structures.
2. **Attached storage acquisition** — an explicitly selected whole USB/HDD/SSD is placed read-only, acquired sector by sector to E01 or raw on a different destination disk, verified, then analysed by the same 45-module engine.

## Assurance boundary

- Accepted findings are generated from runtime evidence and must retain provenance. MASTER answer keys and expected values are used only by post-run validators.
- The primary AF-UNIFIED synthetic E01 smoke run detected 38/38 reference evidence items, 77/77 reference files and 27/27 reference timeline events with no mapped system-level false positives or false negatives.
- Randomised positive, negative, malformed and dependency-failure tests exercise the eight targeted-repair modules and acquisition integrity controls.
- A passing synthetic or generated corpus does not establish universal performance on every operating system, device, memory acquisition or mobile extraction.
- Software-enforced read-only acquisition is supported as an honestly labelled fallback. It is not equivalent to a certified hardware write blocker.
- Reports are suitable for qualified examiner review; they are not automatically court-admissible and are not a substitute for examiner verification.

## v2.8.6 engineering changes

- Preserves exactly **45 active modules**; the removed Autopsy integration remains absent rather than being simulated.
- Makes supported-corpus processing exhaustive by default: zero-valued limits mean unlimited processing, while any explicitly configured positive cap that is reached must be surfaced as partial/unresolved rather than silently completing.
- Repairs native ZIP carving with EOCD/central-directory geometry, payload/CRC validation, duplicate-member suppression and candidate-only accounting for plausible partial/orphaned ZIP structures.
- Uses the mature read-only libewf stream for existing E01 evidence, including segmented E01/E02 sets, without requiring RAW materialisation.
- Retains filesystem directory objects as well as files, removes silent first-N processing limits from browser, email, timeline, EVTX, document, OCR, registry and related parsers, and retains duplicate paths as explicit aliases rather than dropping them.
- Keeps report previews bounded only for presentation; complete parsed records and primary artefacts remain in machine-readable module output where supported.
- Rebaselines the 37-module source lock because the exhaustive-coverage hardening intentionally changes previously locked implementation files.
- Adds v2.8.6 regression tests for ZIP validity/partial recovery, unlimited document and keyword handling, duplicate-path inventory, filesystem directory retention, memory-marker coverage and mailboxes containing more than 500 messages.
- No evidence-specific filenames, hashes, offsets, expected counts, MASTER answers or validation-image identifiers are used by production detection logic.

## Install

```bash
cd "$HOME/Desktop"
sha256sum -c AutoForensics_v2.8.6_KALI.zip.sha256
unzip -t AutoForensics_v2.8.6_KALI.zip
rm -rf AutoForensics_v2.8.6_KALI
unzip -q AutoForensics_v2.8.6_KALI.zip
cd AutoForensics_v2.8.6_KALI
chmod +x install.sh run_final.sh verify_final.sh package_outputs.sh \
  verify_source_release.sh package_source.sh tools/acquire_devices.py
AUTOFORENSICS_INSTALL_OPTIONAL=1 AUTOFORENSICS_UPDATE_CLAMAV=1 bash install.sh
bash verify_source_release.sh
```

The optional installation enables Volatility 3 and ALEAPP/iLEAPP where their upstream repositories and requirements are available. A module must report a blocked/unsupported state rather than false success when a required dependency or compatible corpus is absent.

## Existing-image analysis

```bash
EVIDENCE="$HOME/Desktop/evidence.E01"
CASE_ID="CASE-$(date +%Y%m%d-%H%M%S)"
OUTPUT="$HOME/Desktop/${CASE_ID}_OUTPUT"

bash run_final.sh \
  --evidence "$EVIDENCE" \
  --case-id "$CASE_ID" \
  --output "$OUTPUT" \
  --evidence-domain auto \
  --profile full \
  --investigator-id "examiner-id" \
  --investigator-name "Authorised Examiner" \
  --institution "Organisation" \
  --jurisdiction "Applicable jurisdiction"
```

## Attached-SSD acquisition and analysis

Use a separate destination with enough free space. Do not place the output on the evidence SSD.

```bash
cd "$HOME/Desktop/AutoForensics_v2.8.6_KALI"
OUTPUT="$HOME/Desktop/AF-LIVE-$(date +%Y%m%d-%H%M%S)_OUTPUT"
python3 tools/acquire_devices.py --list --output-dir "$OUTPUT"
```

After identifying the exact evidence whole-disk path, run the integrated workflow as described in `KALI_COMMANDS.md`. The platform never selects the first disk automatically and refuses the system, project and output disks.

## Verification

```bash
bash verify_final.sh --output "$OUTPUT" --allow-incomplete
bash package_outputs.sh --output "$OUTPUT"
```

`--allow-incomplete` allows the remaining cryptographic and packaging checks to run; it never converts an incomplete or failed module to a pass.

## Detailed records

- `docs/ENGINEERING_CHANGELOG.md`
- `docs/EIGHT_MODULE_COMPLETION_MATRIX.md`
- `docs/AUTOPSY_REMOVAL_RECORD.md`
- `docs/ACQUISITION_IMPLEMENTATION_REPORT.md`
- `docs/CROSS_CORPUS_VALIDATION_REPORT.md`
- `docs/HARD_CODING_AUDIT.md`
- `docs/REGRESSION_REPORT.md`
- `docs/DEPENDENCY_COMPATIBILITY_MATRIX.md`
- `docs/PROPOSAL_ALIGNMENT.md`
- `KALI_COMMANDS.md`
- `REMAINING_LIMITATIONS.md`
