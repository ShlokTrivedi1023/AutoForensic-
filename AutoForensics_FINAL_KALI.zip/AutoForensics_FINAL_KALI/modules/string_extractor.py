"""Field-aware deterministic string and identifier extraction.

Opaque-binary ``strings`` output is retained as candidate data, but canonical
findings are created only from an exact structured record (SQLite row, JSON
path, CSV row, mail header/body, registry-export value, hosts entry or a
printable text line).  This prevents syntactically valid fragments from being
reported as forensic identities or network indicators.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.deterministic_validation import (
    deterministic_metadata, strict_emails, strict_ips, strict_urls,
    validated_bitcoin_addresses, validated_base64,
)
from core.structured_records import (
    StructuredRecord, extract_structured_records, record_context,
    record_locator_metadata, value_role,
)
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, _run_subprocess, make_finding,
    resolve_corpus_roots, iter_corpus_files, utc_now,
)

MODULE_NAME = "string_extractor"
MIN_STRING_LENGTH = 6
STRINGS_TIMEOUT = 300
_MAX_CANDIDATES_PER_FILE = 0  # retained compatibility constant; opaque candidate extraction is exhaustive

_REGISTRY_RE = re.compile(
    r"(?i)(?<![A-Za-z0-9_])(?:HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|"
    r"HKEY_USERS|HKEY_CURRENT_CONFIG|HKLM|HKCU|HKCR|HKU|HKCC)\\[^\r\n\t\"]{1,512}"
)
_BASE64_SHAPE_RE = re.compile(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{40,}={0,2}(?![A-Za-z0-9+/=])")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _is_browser_sqlite_db(path: Path) -> bool:
    """Backward-compatible structural browser-database check.

    The decision is schema-based, never filename-based. It is retained for
    callers and regressions that used the historical helper while the canonical
    string extractor now relies on ``core.structured_records``.
    """
    try:
        from core.evidence_inventory import classify_file
        obj = classify_file(Path(path))
        return obj.object_type == "browser_database"
    except (OSError, ValueError):
        return False


def _opaque_strings(path: Path, logger: logging.Logger) -> list[str]:
    """Return all printable ASCII and UTF-16LE strings with no external-tool dependency."""
    from modules.memory_string_analyzer import _iter_strings
    return [literal for _offset, _encoding, literal in _iter_strings(path)]


def _allow_role(role: str, kind: str) -> bool:
    if kind == "email":
        return role in {"email", "message_identifier", "free_text"}
    if kind == "url":
        return role in {"url", "free_text"}
    if kind == "ip":
        return role in {"ip", "free_text", "hostname"}
    if kind == "registry":
        return role in {"registry_key", "free_text"}
    if kind in {"bitcoin", "base64"}:
        return role in {"free_text", "unknown"}
    return False


def _base64_is_contextual(field_name: str, value: str, decoded: bytes) -> bool:
    name = re.sub(r"[^a-z0-9]+", "_", field_name.casefold())
    explicit = any(token in name for token in ("base64", "b64", "encoded", "payload", "blob"))
    magic = decoded.startswith((b"MZ", b"PK\x03\x04", b"%PDF", b"\x89PNG", b"GIF8", b"\xff\xd8\xff"))
    printable = bool(decoded) and sum(32 <= b < 127 or b in b"\r\n\t" for b in decoded) / len(decoded) >= 0.90
    # Exclude hexadecimal hashes and path-like strings which happen to use the
    # Base64 alphabet.  A round-trip alone is not semantic proof of encoding.
    hex_like = bool(re.fullmatch(r"[0-9A-Fa-f]{40,}", value))
    path_like = "/" in value or "\\" in value
    return not hex_like and not path_like and (explicit or magic or printable)



def _luhn_valid_digits(value: str) -> bool:
    digits = [int(ch) for ch in value if ch.isdigit()]
    if not digits:
        return False
    total = 0
    parity = len(digits) % 2
    for index, digit in enumerate(digits):
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def _labelled_identifiers(field_name: str, raw_value: str) -> list[tuple[str, str]]:
    """Return exact identifiers only when the structured field name supplies semantics."""
    name = re.sub(r"[^a-z0-9]+", "_", field_name.casefold()).strip("_")
    value = str(raw_value).strip()
    if not value or len(value) > 4096:
        return []
    out: list[tuple[str, str]] = []
    digits = re.sub(r"\D", "", value)
    if any(token in name for token in ("imei", "device_imei")) and 14 <= len(digits) <= 16 and _luhn_valid_digits(digits):
        out.append(("imei", digits))
    if any(token in name for token in ("phone", "telephone", "mobile", "msisdn")):
        for match in re.finditer(r"(?<!\d)\+?[0-9][0-9 ()-]{6,20}[0-9](?!\d)", value):
            number = re.sub(r"[^0-9+]", "", match.group(0))
            count = len(re.sub(r"\D", "", number))
            if 7 <= count <= 15:
                out.append(("phone", number))
    if name in {"username", "user_name", "login", "login_name", "account_name"} and len(value) <= 512:
        out.append(("username", value))
    if any(token in name for token in ("password", "passwd", "pwd")) and len(value) <= 2048:
        out.append(("password", value))
    if any(token in name for token in ("api_key", "apikey", "access_token", "auth_token")) and 8 <= len(value) <= 4096:
        out.append(("api_key", value))
    return out

def _finding(
    *, kind: str, value: str, record: StructuredRecord, field_name: str,
    role: str, description: str,
) -> Any:
    type_map = {
        "email": "MESSAGE_IDENTIFIER_LITERAL" if role == "message_identifier" else "EMAIL_ADDRESS_LITERAL",
        "url": "URL_LITERAL",
        "ip": "IP_ADDRESS_LITERAL",
        "registry": "REGISTRY_PATH_LITERAL",
        "bitcoin": "BITCOIN_ADDRESS_CHECKSUM_VALID",
        "base64": "BASE64_PAYLOAD_VALIDATED",
        "phone": "PHONE_NUMBER_LABELLED_FIELD",
        "imei": "IMEI_LABELLED_FIELD_CHECKSUM_VALID",
        "username": "USERNAME_LABELLED_FIELD",
        "password": "PASSWORD_LABELLED_FIELD",
        "api_key": "API_KEY_LABELLED_FIELD",
    }
    validators = {
        "email": ["structured record parser", "strict_emails"],
        "url": ["structured record parser", "strict_urls", "urlsplit"],
        "ip": ["structured record parser", "strict_ips", "ipaddress"],
        "registry": ["structured record parser", "registry-root grammar"],
        "bitcoin": ["structured record parser", "Base58Check/Bech32 checksum"],
        "base64": ["structured record parser", "canonical Base64 round-trip", "decoded-content validation"],
        "phone": ["structured record parser", "explicit phone-field name", "E.164 length bounds"],
        "imei": ["structured record parser", "explicit IMEI field name", "Luhn checksum"],
        "username": ["structured record parser", "explicit username-field name"],
        "password": ["structured record parser", "explicit password-field name"],
        "api_key": ["structured record parser", "explicit API-key/token field name"],
    }
    md = {
        **deterministic_metadata(
            "field-aware structured-record parsing and exact value validation",
            validators=validators[kind],
            semantic_limit="Literal presence in the cited record; ownership, intent and maliciousness are not inferred.",
        ),
        **record_locator_metadata(record, field_name),
        "field_role": role,
        "value": value,
        "value_sha256": hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest(),
    }
    return make_finding(
        type_map[kind], Severity.INFO, description,
        record.source_path, md, artifact_path=record.source_path,
    )


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict[str, Any],
        logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now()
    roots = resolve_corpus_roots(config.get("_working_set", {}), output_dir=output_dir)
    if not roots:
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(), summary="NOT APPLICABLE — no recovered corpus was available after applicability checking.",
            statistics={
                "applicability_check_completed": True,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "records_discovered": 0, "records_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
            },
            class_results=[ClassResult(Locus.FILE_SYSTEM, "Structured String Records", AssuranceVerdict.INDETERMINATE, SkipReason.NO_CORPUS)],
        )

    files = iter_corpus_files(
        config.get("_working_set", {}), output_dir=output_dir,
        include_case_context=False, include_derived=False,
        deduplicate_by_hash=False,
    )
    unique: list[Path] = []
    seen: set[str] = set()
    errors: list[str] = []
    source_paths_accounted = 0
    aliases: dict[str, list[str]] = {}
    for path in sorted(set(files), key=lambda p: p.as_posix()):
        try:
            digest = _sha256(path)
        except OSError as exc:
            errors.append(f"Cannot hash {path}: {exc}")
            continue
        source_paths_accounted += 1
        if digest in seen:
            aliases.setdefault(digest, []).append(str(path))
            continue
        seen.add(digest)
        unique.append(path)

    findings: list[Any] = []
    structured_report: list[dict[str, Any]] = []
    candidate_report: list[dict[str, Any]] = []
    global_values: dict[str, set[str]] = {k: set() for k in ("email", "url", "ip", "registry", "bitcoin", "base64", "phone", "imei", "username", "password", "api_key")}
    processed = 0
    records_examined = 0

    for path in unique:
        try:
            records = extract_structured_records(path)
        except Exception as exc:
            errors.append(f"Structured parser failed for {path}: {type(exc).__name__}: {exc}")
            records = []
        if records:
            processed += 1
            records_examined += len(records)
            file_values: dict[str, list[dict[str, Any]]] = {k: [] for k in global_values}
            for record in records:
                context = record_context(record)
                for field_name, raw_value in record.fields.items():
                    value = str(raw_value)
                    role = value_role(record, field_name)
                    for labelled_kind, literal in _labelled_identifiers(field_name, value):
                        file_values[labelled_kind].append({
                            "value": literal, "locator": record.locator,
                            "field": field_name, "role": "explicit_label",
                        })
                        global_values[labelled_kind].add(literal)
                        sensitive = labelled_kind in {"password", "api_key"}
                        shown = "[retained in restricted structured output]" if sensitive else literal
                        findings.append(_finding(
                            kind=labelled_kind, value=literal, record=record, field_name=field_name,
                            role="explicit_label",
                            description=(
                                f"An exact explicitly labelled {labelled_kind.replace('_', ' ')} value "
                                f"is present in the cited structured field: {shown}."
                            ),
                        ))
                    if _allow_role(role, "email"):
                        for literal in strict_emails(value):
                            key = ("email", literal.casefold(), record.source_sha256, json.dumps(record.locator, sort_keys=True), field_name)
                            file_values["email"].append({"value": literal, "locator": record.locator, "field": field_name, "role": role})
                            global_values["email"].add(literal.casefold())
                            findings.append(_finding(
                                kind="email", value=literal, record=record, field_name=field_name, role=role,
                                description=("A mailbox-shaped message identifier is present in the cited field." if role == "message_identifier" else "An email-address literal is present in the cited structured record."),
                            ))
                    if _allow_role(role, "url"):
                        for literal in strict_urls(value):
                            file_values["url"].append({"value": literal, "locator": record.locator, "field": field_name, "role": role})
                            global_values["url"].add(literal)
                            findings.append(_finding(kind="url", value=literal, record=record, field_name=field_name, role=role,
                                                     description="An absolute URL literal is present in the cited structured record."))
                    if _allow_role(role, "ip"):
                        for literal in strict_ips(value):
                            file_values["ip"].append({"value": literal, "locator": record.locator, "field": field_name, "role": role})
                            global_values["ip"].add(literal)
                            findings.append(_finding(kind="ip", value=literal, record=record, field_name=field_name, role=role,
                                                     description="An exact IP-address literal is present in the cited structured record."))
                    if _allow_role(role, "registry"):
                        for match in _REGISTRY_RE.finditer(value):
                            literal = match.group(0)
                            file_values["registry"].append({"value": literal, "locator": record.locator, "field": field_name, "role": role})
                            global_values["registry"].add(literal.casefold())
                            findings.append(_finding(kind="registry", value=literal, record=record, field_name=field_name, role=role,
                                                     description="A registry-rooted path literal is present in the cited structured record."))
                    if _allow_role(role, "bitcoin"):
                        for literal in validated_bitcoin_addresses(value):
                            file_values["bitcoin"].append({"value": literal, "locator": record.locator, "field": field_name, "role": role})
                            global_values["bitcoin"].add(literal)
                            findings.append(_finding(kind="bitcoin", value=literal, record=record, field_name=field_name, role=role,
                                                     description="A Bitcoin address literal passed its network checksum in the cited record."))
                    if _allow_role(role, "base64"):
                        for match in _BASE64_SHAPE_RE.finditer(value):
                            literal = match.group(0)
                            decoded = validated_base64(literal)
                            if decoded is None or not _base64_is_contextual(field_name, literal, decoded):
                                continue
                            file_values["base64"].append({"value_sha256": hashlib.sha256(literal.encode()).hexdigest(), "decoded_sha256": hashlib.sha256(decoded).hexdigest(), "locator": record.locator, "field": field_name, "role": role})
                            global_values["base64"].add(hashlib.sha256(decoded).hexdigest())
                            findings.append(_finding(kind="base64", value=literal, record=record, field_name=field_name, role=role,
                                                     description="A canonical Base64 value with independently validated decoded content is present in the cited record."))
            structured_report.append({
                "file_path": str(path), "file_sha256": records[0].source_sha256,
                "record_count": len(records), "values": file_values,
                "byte_identical_aliases": aliases.get(records[0].source_sha256, []),
            })
        else:
            # Retain the legacy capability without allowing it into canonical
            # findings.  These are explicitly opaque-binary candidates.
            try:
                lines = _opaque_strings(path, logger)
            except (OSError, ValueError) as exc:
                errors.append(f"Literal string extraction failed for {path}: {exc}")
                continue
            if not lines:
                continue
            combined = "\n".join(lines)
            proposed = {
                "emails": strict_emails(combined),
                "urls": strict_urls(combined),
                "ips": strict_ips(combined),
            }
            if any(proposed.values()):
                candidate_report.append({
                    "file_path": str(path), "file_sha256": _sha256(path),
                    "candidate_basis": "printable strings recovered from opaque binary bytes",
                    "promotion_status": "NOT_PROMOTED",
                    "reason": "No structured record/field boundary established provenance.",
                    **proposed,
                })

    # Stable de-duplication of identical literal + record + field findings.
    deduped: list[Any] = []
    seen_findings: set[tuple[str, str, str, str, str]] = set()
    for f in findings:
        md = f.metadata
        key = (
            f.finding_type, str(md.get("value") or md.get("value_sha256") or ""),
            str(md.get("file_sha256") or ""), json.dumps({k: md.get(k) for k in ("table", "rowid", "row", "line", "json_path", "message_index")}, sort_keys=True),
            str(md.get("field_name") or ""),
        )
        if key in seen_findings:
            continue
        seen_findings.add(key)
        deduped.append(f)
    findings = deduped

    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "structured_identifiers.json"
    report_path.write_text(json.dumps({
        "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
        "policy": "Only exact structured-record fields become canonical findings. Opaque-binary strings remain candidates.",
        "files_examined": len(unique), "structured_files": processed,
        "records_examined": records_examined,
        "unique_values": {key: len(value) for key, value in global_values.items()},
        "structured_results": structured_report,
        "candidate_observations": candidate_report,
    }, indent=2, ensure_ascii=True), encoding="utf-8")

    end = utc_now()
    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Examined {len(unique)} unique byte streams and {records_examined} exact structured records; "
        f"reported {len(findings)} field-bounded literal finding(s). "
        f"Opaque-binary candidates were quarantined: {len(candidate_report)} file(s)."
    )
    cr = ClassResult(
        Locus.FILE_SYSTEM, "Field-bounded Structured Identifiers",
        AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start, end_time=end, findings=findings,
        artifact_paths=[str(report_path)], errors=errors,
        statistics={
            "sources_discovered": len(files), "sources_processed": source_paths_accounted,
            "supported_objects_discovered": len(unique), "supported_objects_processed": len(unique) - len([e for e in errors if "failed for" in e]),
            "records_discovered": records_examined, "records_processed": records_examined,
            "unresolved_supported_objects": len(errors), "parser_errors": len(errors),
            "files_examined": len(unique), "structured_files": processed,
            "records_examined": records_examined, "candidate_files": len(candidate_report),
            "unique_values": {key: len(value) for key, value in global_values.items()},
            "execution_outcome": "ran_found_x" if findings else "ran_found_nothing",
        },
        summary=summary, class_results=[cr],
    )
