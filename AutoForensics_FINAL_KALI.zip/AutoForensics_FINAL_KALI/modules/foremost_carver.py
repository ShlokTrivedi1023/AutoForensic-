"""Foremost specialist carver with deterministic per-candidate reconciliation.

Foremost is treated as a candidate generator.  A zero exit code never by itself
makes the module complete: every retained output must have an exact source
interval, matching bytes, complete format structure and a final ledger state.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.carving_reconciliation import reconcile_candidates
from core.deterministic_validation import candidate_metadata, deterministic_metadata
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus, Severity,
    SkipReason, _run_subprocess, carving_volume_caveat, make_finding,
    source_image_size, utc_now,
)

MODULE_NAME = "foremost_carver"
FOREMOST_TIMEOUT = 14400


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event, " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _parse_audit(audit_path: Path) -> list[dict[str, Any]]:
    """Parse Foremost 1.5.x audit records without pretending rounded sizes are exact.

    Foremost's tabular ``Size`` column is human-readable and can be rounded to
    KB/MB.  It is retained as ``audit_reported_size_bytes`` only; the exact
    candidate length is always taken from the output file itself.
    """
    if not audit_path.is_file():
        return []
    text = audit_path.read_text(encoding="utf-8", errors="replace")
    records: list[dict[str, Any]] = []
    legacy = re.compile(r"File:\s+(\S+)\s+Start:\s+(\d+)\s+Length:\s+(\d+)", re.I)
    for match in legacy.finditer(text):
        exact = int(match.group(3))
        records.append({
            "file_name": Path(match.group(1)).name,
            "offset": int(match.group(2)),
            "size_bytes": exact,
            "audit_reported_size_bytes": exact,
            "audit_size_is_exact": True,
        })
    if records:
        return records
    units = {"B": 1, "KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3}
    row = re.compile(
        r"^\s*\d+:\s+(?P<name>\S+)\s+(?P<num>[0-9]+(?:\.[0-9]+)?)\s*(?P<unit>B|KB|MB|GB)\s+(?P<offset>\d+)\b",
        re.I,
    )
    for line in text.splitlines():
        match = row.match(line)
        if not match:
            continue
        reported = int(float(match.group("num")) * units[match.group("unit").upper()])
        records.append({
            "file_name": Path(match.group("name")).name,
            "offset": int(match.group("offset")),
            "size_bytes": reported,  # compatibility field; not used as exact length
            "audit_reported_size_bytes": reported,
            "audit_size_is_exact": match.group("unit").upper() == "B",
        })
    return records


def _find_file(carve_dir: Path, name: str) -> Path | None:
    direct = carve_dir / name
    if direct.is_file():
        return direct
    matches = sorted(path for path in carve_dir.rglob(Path(name).name) if path.is_file())
    return matches[0] if matches else None


def _filesystem_manifest(output_dir: Path, config: dict[str, Any]) -> Path | None:
    ws = config.get("_working_set") or {}
    values = [
        ws.get("native_filesystem_manifest"),
        ws.get("filesystem_manifest"),
        config.get("native_filesystem_manifest"),
    ]
    for value in values:
        if value and Path(str(value)).is_file():
            return Path(str(value))
    case_root = output_dir.parents[2] if len(output_dir.parents) >= 3 else output_dir.parent
    matches = sorted(case_root.glob("native_filesystem/*/native_filesystem_manifest.json"))
    return matches[0] if matches else None


def _native_manifests(output_dir: Path) -> list[Path]:
    sibling = output_dir.parent / "native_signature_carver" / "native_signature_carving_manifest.json"
    return [sibling] if sibling.is_file() else []


def _metadata_for(record: dict[str, Any], manifest_path: Path, analysis_source: Path) -> dict[str, Any]:
    state = str(record.get("final_state") or "UNRESOLVED")
    common = {
        **record,
        "source_offset": record.get("source_start"),
        "source_start": record.get("source_start"),
        "source_end": record.get("source_end"),
        "source_length": record.get("source_length"),
        "sha256": record.get("output_sha256"),
        "file_sha256": record.get("output_sha256"),
        "carved_path": record.get("output_path"),
        "hash_path": record.get("output_path"),
        "hash_scope": "retained_carver_output",
        "interval_sha256": record.get("source_interval_sha256"),
        "analysis_source": str(analysis_source),
        "report_file": str(manifest_path),
        "deletion_state_established": False,
        "counts_toward_unique_evidence": False,
    }
    if state == "ACCEPTED":
        common.update(deterministic_metadata(
            "exact source interval SHA-256 plus complete format-structure validation",
            validators=["Foremost audit offset", "source interval SHA-256", "format parser"],
            semantic_limit=(
                "The source bytes contain this structurally complete object. Carving does not establish deletion, "
                "intent, independent corroboration, or a new unique evidence object."
            ),
        ))
        common.update({"fact_class": "ALTERNATIVE_REPRESENTATION", "ledger_state": "ACCEPTED"})
    else:
        common.update(candidate_metadata(
            "Foremost deterministic reconciliation",
            reason=str(record.get("resolution_reason") or "candidate could not be completely reconciled"),
        ))
        common.update({
            "ledger_state": state,
            "fact_class": "REJECTED" if state == "REJECTED" else "CANDIDATE_ONLY",
            "rejected": state == "REJECTED",
        })
    return common


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})
    output_dir.mkdir(parents=True, exist_ok=True)
    carve_dir = output_dir / "foremost_output"
    carve_dir.mkdir(parents=True, exist_ok=True)
    analysis_source = Path(config.get("analysis_path") or evidence_path).resolve()
    if not analysis_source.is_file():
        analysis_source = evidence_path.resolve()

    file_types = config.get("file_types") or []
    cmd = ["foremost", "-t", ",".join(file_types) if file_types else "all", "-i", str(analysis_source), "-o", str(carve_dir), "-v"]
    custom = config.get("foremost_config")
    if custom and Path(str(custom)).is_file():
        cmd += ["-c", str(custom)]
    errors: list[str] = []
    artifact_paths: list[str] = []
    rc = -1
    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=FOREMOST_TIMEOUT, logger=logger)
        log_path = carve_dir / "foremost_stdout.txt"
        log_path.write_text((stdout or "") + "\n" + (stderr or ""), encoding="utf-8", errors="replace")
        artifact_paths.append(str(log_path))
        if rc != 0:
            errors.append(f"foremost exited with rc={rc}")
    except FileNotFoundError:
        end_time = utc_now()
        from datetime import datetime
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time,
            duration_seconds=(datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds(),
            errors=["foremost not found — install the foremost package"],
            summary="Foremost specialist analysis not executed because the binary is unavailable.",
            class_results=[ClassResult(
                locus=Locus.FILE_SYSTEM, artefact_class="Foremost Carved Files",
                verdict=AssuranceVerdict.INDETERMINATE, skip_reason=SkipReason.DEPENDENCY_MISSING,
                notes="Native carving remains a separate result and is not relabelled as Foremost.",
            )],
        )
    except subprocess.TimeoutExpired:
        errors.append(f"foremost timed out after {FOREMOST_TIMEOUT}s")

    audit_path = carve_dir / "audit.txt"
    audit = _parse_audit(audit_path)
    candidates: list[dict[str, Any]] = []
    for rec in audit:
        path = _find_file(carve_dir, str(rec["file_name"]))
        candidates.append({
            **rec,
            "file_type": Path(str(rec["file_name"])).suffix.lstrip(".").casefold(),
            "source_start": rec.get("offset"),
            "output_path": str(path) if path else "",
        })
    if not audit:
        # Without the audit offset, Foremost output is retained but remains
        # unresolved; never invent offset 0.
        ignored = {"audit.txt", "foremost_stdout.txt", "foremost_manifest.json"}
        for path in sorted(carve_dir.rglob("*")):
            if path.is_file() and path.name not in ignored:
                candidates.append({
                    "file_name": path.name, "file_type": path.suffix.lstrip(".").casefold(),
                    "source_start": None, "output_path": str(path),
                    "audit_reported_size_bytes": None,
                })

    reconciled, reconciliation = reconcile_candidates(
        tool_name="foremost", source_path=analysis_source, candidates=candidates,
        filesystem_manifest=_filesystem_manifest(output_dir, config),
        native_manifests=_native_manifests(output_dir),
    )
    by_type: dict[str, int] = {}
    findings = []
    manifest_path = output_dir / "foremost_manifest.json"
    for record in reconciled:
        claimed = str(record.get("claimed_type") or "unknown")
        by_type[claimed] = by_type.get(claimed, 0) + 1
        state = str(record.get("final_state") or "UNRESOLVED")
        if record.get("output_path"):
            artifact_paths.append(str(record["output_path"]))
        if state == "ACCEPTED":
            finding_type = "CARVER_CANDIDATE_RESOLVED"
            description = (
                f"Foremost output {record.get('output_name')} is a structurally complete {claimed.upper()} "
                f"object at source bytes {record.get('source_start')}–{record.get('source_end')}; "
                "the retained output matches that interval exactly."
            )
        else:
            finding_type = "CARVER_CANDIDATE_REJECTED" if state == "REJECTED" else "CARVER_CANDIDATE_UNRESOLVED"
            description = f"Foremost output {record.get('output_name')} was {state.lower()}: {record.get('resolution_reason')}."
        findings.append(make_finding(
            finding_type=finding_type,
            severity=Severity.INFO,
            description=description,
            evidence_path=str(evidence_path),
            artifact_path=str(record.get("output_path") or manifest_path),
            metadata=_metadata_for(record, manifest_path, analysis_source),
        ))

    source_size = source_image_size(analysis_source, config)
    total_bytes = int(reconciliation.get("total_candidate_output_bytes") or 0)
    volume_caveat = carving_volume_caveat(total_bytes, source_size)
    _ws = config.get("_working_set") or {}
    manifest_payload = {
        "schema": "autoforensics-carver-reconciliation-v2",
        "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
        "engine_return_code": rc, "analysis_source": str(analysis_source),
        # The logical stream may be an ephemeral read-only EWF mount.  Preserve
        # cryptographic anchors to the external source container and logical media
        # so a verification subset remains reproducible without bundling the full
        # source image.
        "analysis_source_sha256": str(_ws.get("logical_media_sha256") or ""),
        "logical_media_sha256": str(_ws.get("logical_media_sha256") or ""),
        "source_container_path": str(_ws.get("source_container_path") or evidence_path),
        "source_container_sha256": str(_ws.get("source_container_sha256") or ""),
        "source_retention_policy": "EXTERNAL_EVIDENCE_REQUIRED_FOR_INTERVAL_REPLAY",
        "source_image_bytes": source_size, "audit_file": str(audit_path),
        "audit_record_count": len(audit), "by_type": by_type,
        "reconciliation": reconciliation, "volume_caveat": volume_caveat or "",
        "files": reconciled,
    }
    try:
        manifest_path.write_text(json.dumps(manifest_payload, indent=2, ensure_ascii=True), encoding="utf-8")
        artifact_paths.append(str(manifest_path))
    except OSError as exc:
        errors.append(f"failed to write Foremost reconciliation manifest: {exc}")

    unresolved = int((reconciliation.get("state_counts") or {}).get("UNRESOLVED", 0))
    if rc != 0 or errors:
        status = ModuleStatus.PARTIAL if reconciled else ModuleStatus.FAILED
    elif unresolved:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.COMPLETED
    accepted = int((reconciliation.get("state_counts") or {}).get("ACCEPTED", 0))
    rejected = int((reconciliation.get("state_counts") or {}).get("REJECTED", 0))
    summary = (
        f"Foremost deterministically resolved {len(reconciled)} candidate(s): "
        f"{accepted} accepted byte-presence observation(s), {rejected} rejected output(s), "
        f"{unresolved} unresolved. Process return code alone was not used as completion evidence."
    )
    if volume_caveat:
        summary += " " + volume_caveat
    end_time = utc_now()
    from datetime import datetime
    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id, "candidates": len(reconciled)})
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time,
        duration_seconds=(datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds(),
        findings=findings, artifact_paths=list(dict.fromkeys(artifact_paths)), errors=errors,
        statistics={
            "sources_discovered": 1, "sources_processed": 1 if rc == 0 else 0,
            "supported_objects_discovered": len(reconciled), "supported_objects_processed": len(reconciled),
            "records_discovered": len(reconciled), "records_processed": len(reconciled),
            "unresolved_supported_objects": unresolved, "parser_errors": len(errors),
            "engine_completed": rc == 0, "by_type": by_type,
            "accepted_candidates": accepted, "rejected_candidates": rejected,
            "unresolved_candidates": unresolved, **reconciliation,
            "source_image_bytes": source_size, "volume_caveat": volume_caveat or "",
            "audit_file_path": str(audit_path), "execution_outcome": "ran_found_x" if reconciled else "ran_found_nothing",
        },
        summary=summary,
        class_results=[ClassResult(
            locus=Locus.FILE_SYSTEM, artefact_class="Foremost Carved Files",
            verdict=AssuranceVerdict.PRESENT if accepted else AssuranceVerdict.INDETERMINATE if unresolved else AssuranceVerdict.SCOPED_ABSENCE,
            count=accepted, summarised=True,
            notes="Accepted records establish source-byte presence only and do not inflate unique evidence counts.",
        )],
    )
