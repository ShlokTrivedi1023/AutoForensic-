"""Document and PDF active-content analysis.

The module has a dependency-free native path for OOXML and PDF files, and uses
oletools for legacy OLE/RTF macro analysis when available.  A missing optional
external command therefore no longer skips the whole document capability.
"""
from __future__ import annotations

import csv
import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata, sha256_file
from core.metadata_namespaces import native_metadata_records

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    resolve_absence_verdict,
    resolve_corpus_roots,
    iter_corpus_files,
    utc_now,
)

MODULE_NAME = "document_analyzer"
OLEVBA_TIMEOUT = 180
OLEOBJ_TIMEOUT = 180

_OFFICE_EXTENSIONS = frozenset({
    ".doc", ".docx", ".docm", ".xls", ".xlsx", ".xlsm",
    ".ppt", ".pptx", ".pptm", ".rtf", ".odt", ".ods",
})
_OOXML_EXTENSIONS = frozenset({".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"})
_LEGACY_OLE_EXTENSIONS = frozenset({".doc", ".xls", ".ppt", ".rtf"})
_PDF_EXTENSIONS = frozenset({".pdf"})
_DATA_DOCUMENT_EXTENSIONS = frozenset({".csv", ".tsv", ".json", ".mbox", ".eml", ".kdbx", ".zip"})

_SUSPICIOUS_VBA_KEYWORDS = frozenset({
    "Shell", "CreateObject", "WScript", "PowerShell", "cmd.exe",
    "AutoOpen", "AutoClose", "Document_Open", "Workbook_Open",
    "URLDownloadToFile", "XMLHTTP", "WinHttp", "Environ",
    "Chr(", "ChrW(", "CallByName", "StrReverse", "Base64",
    "Execute", "Eval", "RegWrite", "RegRead", "FileCopy", "Kill",
})
_PDF_RISKY_KEYWORDS = (
    b"/JS", b"/JavaScript", b"/AA", b"/OpenAction", b"/Launch",
    b"/EmbeddedFile", b"/RichMedia", b"/XFA", b"/AcroForm",
)


def _document_source_rank(path: Path) -> tuple[int, str]:
    text = str(path).replace("\\", "/").casefold()
    if "/native_filesystem/" in text and "/extracted_files/" in text:
        return (0, text)
    if "/native_filesystem/" in text and "/deleted_files/" in text:
        return (1, text)
    if "/native_signature_carver/" in text:
        return (2, text)
    if "/foremost_carver/" in text:
        return (3, text)
    if "/scalpel_carver/" in text:
        return (4, text)
    return (2, text)


def _find_files(scan_dirs: list[Path], extensions: frozenset[str], max_files: int) -> list[Path]:
    """Return one preferred path per exact document byte stream."""
    by_digest: dict[str, Path] = {}
    path_only: dict[str, Path] = {}
    for root in scan_dirs:
        if not root.is_dir():
            continue
        try:
            iterator = root.rglob("*")
        except OSError:
            continue
        for path in iterator:
            try:
                if not path.is_file() or path.suffix.lower() not in extensions:
                    continue
                digest = sha256_file(path)
            except OSError:
                try:
                    path_only[str(path.resolve())] = path
                except OSError:
                    continue
                continue
            prior = by_digest.get(digest)
            if prior is None or _document_source_rank(path) < _document_source_rank(prior):
                by_digest[digest] = path
    found = sorted([*by_digest.values(), *path_only.values()], key=_document_source_rank)
    return found if max_files <= 0 else found[:max_files]


def _find_files_from_candidates(candidates: list[Path], extensions: frozenset[str], max_files: int) -> list[Path]:
    """Return one preferred original-evidence path per document byte stream."""
    by_digest: dict[str, Path] = {}
    path_only: dict[str, Path] = {}
    for path in candidates:
        try:
            if not path.is_file() or path.suffix.lower() not in extensions:
                continue
            digest = sha256_file(path)
        except OSError:
            try:
                path_only[str(path.resolve())] = path
            except OSError:
                continue
            continue
        prior = by_digest.get(digest)
        if prior is None or _document_source_rank(path) < _document_source_rank(prior):
            by_digest[digest] = path
    found = sorted([*by_digest.values(), *path_only.values()], key=_document_source_rank)
    return found if max_files <= 0 else found[:max_files]


def _olevba_command(path: Path) -> list[str] | None:
    cli = shutil.which("olevba")
    if cli:
        return [cli, "--json", str(path)]
    try:
        import oletools.olevba  # noqa: F401
    except ImportError:
        return None
    return [sys.executable, "-m", "oletools.olevba", "--json", str(path)]


def _oleobj_command(path: Path) -> list[str] | None:
    cli = shutil.which("oleobj")
    if cli:
        return [cli, str(path)]
    try:
        import oletools.oleobj  # noqa: F401
    except ImportError:
        return None
    return [sys.executable, "-m", "oletools.oleobj", str(path)]


def _parse_olevba_json(output: str) -> dict[str, Any]:
    result: dict[str, Any] = {
        "has_macros": False,
        "vba_code": "",
        "suspicious_keywords": [],
        "iocs": [],
    }
    if not output.strip():
        return result
    try:
        data: Any = json.loads(output)
        if isinstance(data, list):
            # Some olevba releases emit an initial meta object followed by file objects.
            candidates = [x for x in data if isinstance(x, dict)]
            data = next((x for x in candidates if "macros" in x or "analysis" in x), candidates[0] if candidates else {})
        if not isinstance(data, dict):
            data = {}
        macros = data.get("macros") or []
        result["has_macros"] = bool(macros)
        code_parts = [str(x.get("code") or "") for x in macros if isinstance(x, dict)]
        result["vba_code"] = "\n".join(code_parts)
        analysis = data.get("analysis") or []
        for item in analysis:
            if isinstance(item, dict) and item.get("keyword"):
                result["suspicious_keywords"].append(str(item["keyword"]))
        iocs = data.get("iocs") or []
        result["iocs"] = iocs if isinstance(iocs, list) else []
    except (ValueError, TypeError, KeyError):
        # CLI formats vary; the raw text remains useful as a conservative fallback.
        low = output.lower()
        result["suspicious_keywords"] = [k for k in _SUSPICIOUS_VBA_KEYWORDS if k.lower() in low]
        result["has_macros"] = "vba macro" in low or bool(result["suspicious_keywords"])
        result["vba_code"] = output
    return result


def _analyse_ooxml(path: Path) -> dict[str, Any]:
    """Inspect OOXML ZIP structure without executing document content."""
    record: dict[str, Any] = {
        "file": str(path), "type": "ooxml", "valid_zip": False,
        "macro_parts": [], "embedded_objects": [], "external_relationships": [],
        "errors": [],
    }
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            record["valid_zip"] = True
            record["macro_parts"] = [n for n in names if n.lower().endswith("vbaproject.bin")]
            record["embedded_objects"] = [n for n in names if "/embeddings/" in n.lower()]
            external: list[dict[str, str]] = []
            for name in names:
                if not name.lower().endswith(".rels"):
                    continue
                try:
                    text = zf.read(name).decode("utf-8", "replace")
                except (KeyError, OSError, RuntimeError):
                    continue
                for match in re.finditer(
                    r"<Relationship\b[^>]*\bTarget=\"([^\"]+)\"[^>]*\bTargetMode=\"External\"[^>]*/?>",
                    text,
                    re.IGNORECASE,
                ):
                    external.append({"relationship_part": name, "target": match.group(1)})
                # Attribute order is not fixed.
                for tag in re.findall(r"<Relationship\b[^>]*/?>", text, re.IGNORECASE):
                    if "targetmode=\"external\"" not in tag.lower():
                        continue
                    target = re.search(r"\bTarget=\"([^\"]+)\"", tag, re.IGNORECASE)
                    item = {"relationship_part": name, "target": (target.group(1) if target else "")}
                    if item not in external:
                        external.append(item)
            record["external_relationships"] = external
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        record["errors"].append(str(exc))
    return record


def _analyse_pdf_native(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"file": str(path), "type": "pdf", "keyword_counts": {}, "read_error": ""}
    try:
        data = path.read_bytes()
    except OSError as exc:
        record["read_error"] = str(exc)
        return record
    # PDF names are case-sensitive in theory, but malformed/adversarial files often are not.
    upper = data.upper()
    counts: dict[str, int] = {}
    for token in _PDF_RISKY_KEYWORDS:
        counts[token.decode("ascii")] = upper.count(token.upper())
    counts["/Encrypt"] = upper.count(b"/ENCRYPT")
    record["keyword_counts"] = counts
    record["size_bytes"] = len(data)
    record["pdf_header"] = data.startswith(b"%PDF-")
    return record




def _extract_pdf_text(path: Path, output_dir: Path, logger: logging.Logger) -> tuple[str, str]:
    """Extract PDF text using pdftotext first, then pdfminer when available.

    Returns (text, method). Failure is non-fatal because native active-content
    inspection remains authoritative for risky-object detection.
    """
    cli = shutil.which("pdftotext")
    if cli:
        target = output_dir / (path.stem + "_pdftotext.txt")
        try:
            rc, stdout, stderr = _run_subprocess(
                [cli, "-layout", "-enc", "UTF-8", str(path), str(target)],
                timeout=180, logger=logger,
            )
            if rc == 0 and target.is_file():
                return target.read_text(encoding="utf-8", errors="replace"), "pdftotext"
        except Exception:
            pass
    try:
        from pdfminer.high_level import extract_text  # type: ignore
        return str(extract_text(str(path)) or ""), "pdfminer.six"
    except Exception:
        return "", "native-structure-only"



def _extract_case_identifiers(text: str) -> list[str]:
    """Extract identifiers only from explicit case-labelled contexts.

    Dates, digest algorithm names, CSV record IDs and arbitrary hyphenated
    tokens are deliberately excluded. Supported contexts include ``Case:``,
    ``Case ID=``, ``case_number`` and URL paths such as ``/case/<id>``.
    """
    upper = text.upper()
    patterns = [
        re.compile(r"(?i)\bCASE(?:[_ ]?(?:ID|NUMBER|NO))?\s*[:=#]\s*([A-Z0-9][A-Z0-9-]{4,127})"),
        re.compile(r"(?i)/(?:CASES?|CASE-ID)/([A-Z0-9][A-Z0-9-]{4,127})(?=[/?#\s]|$)"),
    ]
    values: set[str] = set()
    for pattern in patterns:
        for match in pattern.finditer(upper):
            value = match.group(1).strip("-._")
            if "-" in value and any(ch.isdigit() for ch in value):
                values.add(value)
    return sorted(values)


def _trusted_case_identifiers(output_dir: Path, runtime_case_id: str) -> list[str]:
    """Load acquisition/container case identifiers from retained EWF metadata."""
    trusted: list[str] = []
    manifest = output_dir.parent / "ewf_metadata" / "ewf_metadata_manifest.json"
    if manifest.is_file():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8", errors="replace"))
            value = str(((data.get("ewf_metadata") or {}).get("case_number") or "")).strip().upper()
            if value:
                trusted.append(value)
        except (OSError, json.JSONDecodeError):
            pass
    if not trusted and runtime_case_id:
        trusted.append(str(runtime_case_id).strip().upper())
    return list(dict.fromkeys(trusted))


def _analyse_csv(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"file": str(path), "type": "delimited_text", "rows": [], "columns": [], "errors": []}
    try:
        raw = path.read_text(encoding="utf-8-sig", errors="replace")
        dialect = csv.Sniffer().sniff(raw[:8192], delimiters=",\t;|") if raw.strip() else csv.excel
        reader = csv.DictReader(raw.splitlines(), dialect=dialect)
        record["columns"] = list(reader.fieldnames or [])
        for index, row in enumerate(reader, 1):
            record["rows"].append({"row_number": index + 1, "values": {str(k): str(v or "") for k, v in (row or {}).items()}})
    except (OSError, csv.Error) as exc:
        record["errors"].append(str(exc))
    return record


def _analyse_json_document(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"file": str(path), "type": "json", "valid": False, "top_level": "", "errors": []}
    try:
        value = json.loads(path.read_text(encoding="utf-8", errors="strict"))
        record["valid"] = True
        record["top_level"] = type(value).__name__
        if isinstance(value, dict):
            record["keys"] = sorted(str(k) for k in value)
        elif isinstance(value, list):
            record["item_count"] = len(value)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        record["errors"].append(str(exc))
    return record


def _analyse_kdbx(path: Path) -> dict[str, Any]:
    """Validate the KeePass KDBX container header; do not infer credentials from a filename."""
    record: dict[str, Any] = {"file": str(path), "type": "kdbx", "valid_kdbx": False, "errors": []}
    try:
        data = path.read_bytes()[:64]
        record["size_bytes"] = path.stat().st_size
        record["signature_1"] = data[:4].hex()
        record["signature_2"] = data[4:8].hex()
        # KDBX 2/3/4: 0x9AA2D903, then 0xB54BFB67 (KDBX) or legacy KDB.
        valid = len(data) >= 12 and data[:4] == bytes.fromhex("03d9a29a") and data[4:8] in {bytes.fromhex("67fb4bb5"), bytes.fromhex("b54bfb66")}
        record["valid_kdbx"] = bool(valid)
        if valid:
            record["version_minor"] = int.from_bytes(data[8:10], "little")
            record["version_major"] = int.from_bytes(data[10:12], "little")
        else:
            record["semantic_limit"] = "Filename/extension only; not a structurally valid KeePass database"
    except OSError as exc:
        record["errors"].append(str(exc))
    return record



def _analyse_archive(path: Path) -> dict[str, Any]:
    """Return exact ZIP structure, member and encryption information."""
    record: dict[str, Any] = {"file": str(path), "type": "archive", "format": "zip", "valid": False, "members": [], "errors": []}
    try:
        with zipfile.ZipFile(path) as archive:
            record["valid"] = True
            for info in archive.infolist():
                record["members"].append({
                    "name": info.filename,
                    "uncompressed_size": info.file_size,
                    "compressed_size": info.compress_size,
                    "compression_method": info.compress_type,
                    "encrypted": bool(info.flag_bits & 0x1),
                    "crc32": f"{info.CRC:08x}",
                    "timestamp": "-".join(map(str, info.date_time)),
                    "flag_bits": info.flag_bits,
                })
            try:
                bad = archive.testzip()
                record["crc_validation"] = "PASS" if bad is None else f"FAILED_MEMBER:{bad}"
            except RuntimeError as exc:
                # Encrypted members cannot be CRC-tested without a password.
                record["crc_validation"] = f"NOT_TESTED_ENCRYPTED:{exc}"
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        record["errors"].append(str(exc))
    return record


def _parse_mbox_records(path: Path) -> list[dict[str, Any]]:
    import mailbox
    records: list[dict[str, Any]] = []
    try:
        box = mailbox.mbox(str(path), create=False)
        for index, message in enumerate(box):
            payload = message.get_payload(decode=True)
            body = payload.decode(message.get_content_charset() or "utf-8", errors="replace") if isinstance(payload, bytes) else str(message.get_payload() or "")
            records.append({
                "message_index": index,
                "message_id": str(message.get("Message-ID") or ""),
                "from": str(message.get("From") or ""),
                "to": str(message.get("To") or ""),
                "subject": str(message.get("Subject") or ""),
                "date": str(message.get("Date") or ""),
                "body_sha256": hashlib.sha256(body.encode("utf-8", errors="replace")).hexdigest(),
                "body_preview": body[:500],
            })
    except (OSError, mailbox.Error):
        return []
    return records

def _document_text_and_metadata(path: Path, output_dir: Path, logger: logging.Logger) -> tuple[str, dict[str, Any], str]:
    """Extract exact text/metadata using format parsers without executing content."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        text, method = _extract_pdf_text(path, output_dir, logger)
        metadata: dict[str, Any] = {}
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path), strict=False)
            metadata = {str(k): str(v) for k, v in dict(reader.metadata or {}).items()}
            if not text:
                text = "\n".join(str(page.extract_text() or "") for page in reader.pages)
                method = "pypdf"
        except Exception:
            pass
        return text, metadata, method
    if ext in {".docx", ".docm"}:
        try:
            from docx import Document
            doc = Document(str(path))
            text = "\n".join(p.text for p in doc.paragraphs)
            cp = doc.core_properties
            meta = {name: str(getattr(cp, name, "") or "") for name in ("title", "subject", "author", "keywords", "comments", "created", "modified")}
            return text, meta, "python-docx"
        except Exception:
            return "", {}, "structure-only"
    if ext in {".csv", ".tsv", ".json", ".mbox", ".eml"}:
        try:
            return path.read_text(encoding="utf-8", errors="replace"), {}, "utf8-text"
        except OSError:
            return "", {}, "unreadable"
    return "", {}, "structure-only"


def _severity_for_pdf(counts: dict[str, int]) -> Severity:
    high = any(counts.get(k, 0) for k in ("/JS", "/JavaScript", "/OpenAction", "/Launch"))
    return Severity.HIGH if high else Severity.MEDIUM


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    output_dir.mkdir(parents=True, exist_ok=True)
    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []

    # Zero means exhaustive. Positive values are explicit caller safety caps
    # and, if reached, prevent a COMPLETE status.
    max_office = int(config.get("max_office_files", 0) or 0)
    max_pdf = int(config.get("max_pdf_files", 0) or 0)
    max_data = int(config.get("max_data_documents", 0) or 0)
    ws = config.get("_working_set", {})
    roots = resolve_corpus_roots(ws, output_dir=output_dir)
    candidates = iter_corpus_files(ws, output_dir=output_dir, deduplicate_by_hash=False)

    office_all = _find_files_from_candidates(candidates, _OFFICE_EXTENSIONS, 0)
    pdf_all = _find_files_from_candidates(candidates, _PDF_EXTENSIONS, 0)
    data_all = _find_files_from_candidates(candidates, _DATA_DOCUMENT_EXTENSIONS, 0)
    office_files = office_all if max_office <= 0 else office_all[:max_office]
    pdf_files = pdf_all if max_pdf <= 0 else pdf_all[:max_pdf]
    data_files = data_all if max_data <= 0 else data_all[:max_data]
    limit_reached = (
        (max_office > 0 and len(office_all) > len(office_files))
        or (max_pdf > 0 and len(pdf_all) > len(pdf_files))
        or (max_data > 0 and len(data_all) > len(data_files))
    )
    if limit_reached:
        errors.append(
            "A configured document processing limit prevented exhaustive supported-document analysis."
        )
    if not office_files and not pdf_files and not data_files:
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=utc_now(),
            summary="DID NOT RUN — no supported document corpus was identified.",
            class_results=[ClassResult(
                locus=Locus.FILE_SYSTEM, artefact_class="Document Active Content",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_CORPUS,
                notes="No Office, PDF, CSV/JSON, mail, or KDBX-like files were available to examine.",
            )],
        )

    stats: dict[str, int] = {
        "office_files_discovered": len(office_all),
        "office_files_analyzed": 0,
        "legacy_office_files": 0,
        "legacy_office_analyzed": 0,
        "ooxml_files_analyzed": 0,
        "pdfs_analyzed": 0,
        "macros_found": 0,
        "suspicious_macro_files": 0,
        "embedded_objects": 0,
        "external_relationships": 0,
        "risky_pdf_files": 0,
        "pdf_text_extracted": 0,
        "data_documents_discovered": len(data_all),
        "data_documents_analyzed": 0,
        "structured_rows": 0,
        "case_identifier_mismatches": 0,
        "invalid_kdbx_like_files": 0,
        "metadata_fields_reported": 0,
        "archives_analyzed": 0,
        "archive_members": 0,
        "mbox_messages": 0,
    }
    records: list[dict[str, Any]] = []
    legacy_incomplete = 0

    for doc in office_files:
        ext = doc.suffix.lower()
        if ext in _OOXML_EXTENSIONS:
            rec = _analyse_ooxml(doc)
            records.append(rec)
            if rec["valid_zip"]:
                stats["office_files_analyzed"] += 1
                stats["ooxml_files_analyzed"] += 1
            else:
                errors.append(f"OOXML container could not be parsed: {doc.name}: {'; '.join(rec['errors'])}")
                continue
            if rec["macro_parts"]:
                stats["macros_found"] += 1
                findings.append(make_finding(
                    "MACRO_DETECTED", Severity.HIGH,
                    f"OOXML macro project part(s) were present in {doc.name}: " + ", ".join(rec["macro_parts"][:5]) + ".",
                    str(doc), {"file_path": str(doc), "macro_parts": rec["macro_parts"], **deterministic_metadata("OOXML ZIP member enumeration", validators=["zipfile"])}, artifact_path=str(doc),
                ))
            if rec["embedded_objects"]:
                stats["embedded_objects"] += len(rec["embedded_objects"])
                findings.append(make_finding(
                    "EMBEDDED_OLE_OBJECT", Severity.MEDIUM,
                    f"{len(rec['embedded_objects'])} embedded object part(s) were present in {doc.name}.",
                    str(doc), {"file_path": str(doc), "embedded_objects": rec["embedded_objects"][:50], **deterministic_metadata("OOXML relationship/package member enumeration", validators=["zipfile"])}, artifact_path=str(doc),
                ))
            if rec["external_relationships"]:
                stats["external_relationships"] += len(rec["external_relationships"])
                findings.append(make_finding(
                    "EXTERNAL_DOCUMENT_RELATIONSHIP", Severity.MEDIUM,
                    f"{len(rec['external_relationships'])} external relationship(s) were present in {doc.name}; targets require examiner review.",
                    str(doc), {"file_path": str(doc), "relationships": rec["external_relationships"][:50], **deterministic_metadata("OOXML external TargetMode relationship parsing", validators=["zipfile", "XML attribute parser"])}, artifact_path=str(doc),
                ))

        if ext in _LEGACY_OLE_EXTENSIONS or ext in _OOXML_EXTENSIONS:
            # Olevba adds semantic VBA analysis to both legacy OLE and macro-enabled OOXML.
            if ext in _LEGACY_OLE_EXTENSIONS:
                stats["legacy_office_files"] += 1
            command = _olevba_command(doc)
            if command is None:
                if ext in _LEGACY_OLE_EXTENSIONS:
                    legacy_incomplete += 1
                    warnings.append("oletools/olevba unavailable; legacy OLE/RTF macro analysis was not complete")
                # Native ZIP/XML analysis is complete for ordinary OOXML when
                # no legacy OLE container is involved.
                continue
            try:
                rc, stdout, stderr = _run_subprocess(command, OLEVBA_TIMEOUT, logger)
            except subprocess.TimeoutExpired:
                errors.append(f"olevba timed out on {doc.name}")
                continue
            except (FileNotFoundError, OSError) as exc:
                if ext in _LEGACY_OLE_EXTENSIONS:
                    legacy_incomplete += 1
                warnings.append(f"olevba unavailable for {doc.name}: {exc}")
                continue
            # olevba uses non-zero returns for some malformed/non-OLE inputs; keep output if present.
            if rc != 0 and not stdout.strip():
                if ext in _LEGACY_OLE_EXTENSIONS:
                    legacy_incomplete += 1
                errors.append(f"olevba failed on {doc.name} (rc={rc}): {stderr[:300]}")
                continue
            if ext in _LEGACY_OLE_EXTENSIONS:
                stats["legacy_office_analyzed"] += 1
                stats["office_files_analyzed"] += 1
            parsed = _parse_olevba_json(stdout)
            code = str(parsed.get("vba_code") or "")
            vba_artifact = ""
            if code:
                digest_prefix = sha256_file(doc)[:12]
                vba_path = output_dir / f"{doc.stem}_{digest_prefix}_vba.txt"
                try:
                    vba_path.write_text(code, encoding="utf-8", errors="replace")
                    artifact_paths.append(str(vba_path))
                    vba_artifact = str(vba_path)
                except OSError as exc:
                    errors.append(f"Could not retain complete VBA text for {doc.name}: {exc}")
            records.append({
                "file": str(doc),
                "type": "vba_analysis",
                "has_macros": bool(parsed.get("has_macros")),
                "vba_code_length": len(code),
                "vba_code_artifact": vba_artifact,
                "suspicious_keywords": list(parsed.get("suspicious_keywords") or []),
                "iocs": list(parsed.get("iocs") or []),
            })
            keywords = sorted(set(parsed.get("suspicious_keywords") or []) | {
                k for k in _SUSPICIOUS_VBA_KEYWORDS if k.lower() in code.lower()
            })
            # Do not duplicate the structural OOXML macro finding.
            if parsed.get("has_macros") and not any(
                f.metadata.get("file_path") == str(doc) and f.finding_type == "MACRO_DETECTED" for f in findings
            ):
                stats["macros_found"] += 1
                findings.append(make_finding(
                    "MACRO_DETECTED", Severity.HIGH,
                    f"VBA macro content was detected in {doc.name}.",
                    str(doc), {"file_path": str(doc), "vba_code_length": len(code)}, artifact_path=str(doc),
                ))
            if keywords:
                stats["suspicious_macro_files"] += 1
                findings.append(make_finding(
                    "SUSPICIOUS_MACRO_KEYWORD", Severity.HIGH,
                    f"VBA analysis of {doc.name} identified suspicious keyword(s): {', '.join(keywords[:12])}.",
                    str(doc), {"file_path": str(doc), "keywords": keywords[:30], "iocs": (parsed.get("iocs") or [])[:20], **candidate_metadata("VBA keyword list", reason="Keyword presence is exact, but suspicious intent is not deterministic")}, artifact_path=str(doc),
                ))

            obj_command = _oleobj_command(doc)
            if obj_command:
                try:
                    obj_rc, obj_out, _ = _run_subprocess(obj_command, OLEOBJ_TIMEOUT, logger)
                    if obj_rc == 0 and ("extracting" in obj_out.lower() or "embedded" in obj_out.lower()):
                        # Avoid duplicate structural OOXML finding.
                        if not any(f.metadata.get("file_path") == str(doc) and f.finding_type == "EMBEDDED_OLE_OBJECT" for f in findings):
                            stats["embedded_objects"] += 1
                            findings.append(make_finding(
                                "EMBEDDED_OLE_OBJECT", Severity.MEDIUM,
                                f"oleobj reported embedded content in {doc.name}.",
                                str(doc), {"file_path": str(doc), "tool": "oleobj"}, artifact_path=str(doc),
                            ))
                except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
                    warnings.append(f"oleobj enrichment unavailable for {doc.name}")

    for pdf in pdf_files:
        rec = _analyse_pdf_native(pdf)
        records.append(rec)
        if rec.get("read_error"):
            errors.append(f"PDF could not be read: {pdf.name}: {rec['read_error']}")
            continue
        stats["pdfs_analyzed"] += 1
        text, text_method = _extract_pdf_text(pdf, output_dir, logger)
        rec["text_extraction_method"] = text_method
        rec["text_length"] = len(text)
        if text:
            stats["pdf_text_extracted"] += 1
            text_path = output_dir / f"{pdf.stem}_extracted_text.txt"
            try:
                text_path.write_text(text, encoding="utf-8", errors="replace")
                artifact_paths.append(str(text_path))
                rec["text_artifact"] = str(text_path)
            except OSError as exc:
                warnings.append(f"Could not retain extracted PDF text for {pdf.name}: {exc}")
        risky = {k: v for k, v in (rec.get("keyword_counts") or {}).items() if k != "/Encrypt" and int(v or 0) > 0}
        if risky:
            stats["risky_pdf_files"] += 1
            findings.append(make_finding(
                "SUSPICIOUS_PDF_ELEMENT", _severity_for_pdf(rec["keyword_counts"]),
                f"PDF active-content indicators were present in {pdf.name}: " + ", ".join(f"{k}={v}" for k, v in sorted(risky.items())) + ".",
                str(pdf), {"file_path": str(pdf), "keyword_counts": rec["keyword_counts"], "native_parser": True, **candidate_metadata("PDF name-token counting", reason="Active-content token presence requires object-graph validation before security interpretation")}, artifact_path=str(pdf),
            ))

    # Deterministic structured-document parsing and cross-document consistency.
    all_semantic_files = list(dict.fromkeys([*pdf_files, *office_files, *data_files]))
    trusted_case_ids = _trusted_case_identifiers(output_dir, case_id)
    case_mismatch_findings: dict[tuple[str, tuple[str, ...]], Any] = {}
    for path in all_semantic_files:
        ext = path.suffix.lower()
        if ext == ".csv" or ext == ".tsv":
            rec = _analyse_csv(path)
            records.append(rec)
            if not rec["errors"]:
                stats["data_documents_analyzed"] += 1
                stats["structured_rows"] += len(rec["rows"])
                findings.append(make_finding(
                    "STRUCTURED_DOCUMENT_ROWS", Severity.INFO,
                    f"{len(rec['rows'])} row(s) and {len(rec['columns'])} column(s) were deterministically parsed from {path.name}.",
                    str(path),
                    {"file_path": str(path), "columns": rec["columns"], "row_count": len(rec["rows"]), "rows": rec["rows"][:200],
                     "file_sha256": sha256_file(path), **deterministic_metadata("CSV/TSV dialect and row parser", validators=["csv.DictReader"])},
                    artifact_path=str(path),
                ))
        elif ext == ".json":
            rec = _analyse_json_document(path)
            records.append(rec)
            if rec["valid"]:
                stats["data_documents_analyzed"] += 1
                findings.append(make_finding(
                    "STRUCTURED_JSON_DOCUMENT", Severity.INFO,
                    f"{path.name} is valid JSON with top-level type {rec['top_level']}.",
                    str(path), {"file_path": str(path), **rec, "file_sha256": sha256_file(path),
                    **deterministic_metadata("JSON grammar parsing", validators=["json.loads"])}, artifact_path=str(path),
                ))
        elif ext == ".zip":
            rec = _analyse_archive(path)
            records.append(rec)
            stats["data_documents_analyzed"] += 1
            stats["archives_analyzed"] += 1
            stats["archive_members"] += len(rec.get("members") or [])
            if rec.get("valid"):
                findings.append(make_finding(
                    "ARCHIVE_STRUCTURE", Severity.INFO,
                    f"ZIP archive {path.name} was structurally parsed with {len(rec.get('members') or [])} member(s).",
                    str(path), {
                        "file_path": str(path), "file_sha256": sha256_file(path),
                        "archive_format": "ZIP", "structural_validation": True,
                        "members": rec.get("members") or [],
                        "crc_validation": rec.get("crc_validation"),
                        **deterministic_metadata("ZIP central-directory/member parsing", validators=["zipfile"]),
                    }, artifact_path=str(path),
                ))
                for member in rec.get("members") or []:
                    findings.append(make_finding(
                        "ARCHIVE_MEMBER_RECORD", Severity.INFO,
                        f"Archive member {member.get('name')} was recorded in {path.name}; encrypted={member.get('encrypted')}.",
                        str(path), {
                            "file_path": str(path), "file_sha256": sha256_file(path),
                            "archive_member": member.get("name"), **member,
                            **deterministic_metadata("ZIP central-directory record", validators=["zipfile.ZipInfo"]),
                        }, artifact_path=str(path),
                    ))
        elif ext in {".mbox", ".eml"}:
            mbox_records = _parse_mbox_records(path) if ext == ".mbox" else []
            stats["data_documents_analyzed"] += 1
            stats["mbox_messages"] += len(mbox_records)
            rec = {"file": str(path), "type": "mbox", "messages": mbox_records}
            records.append(rec)
            if mbox_records:
                findings.append(make_finding(
                    "MBOX_MESSAGE_SET", Severity.INFO,
                    f"{len(mbox_records)} RFC message record(s) were parsed from {path.name}.",
                    str(path), {
                        "file_path": str(path), "file_sha256": sha256_file(path),
                        "message_count": len(mbox_records), "messages": mbox_records,
                        "fact_class": "ALTERNATIVE_REPRESENTATION",
                        "alternative_representation": True,
                        **deterministic_metadata("RFC mailbox parser", validators=["mailbox.mbox", "message ordinal"]),
                    }, artifact_path=str(path),
                ))
        elif ext == ".kdbx":
            rec = _analyse_kdbx(path)
            records.append(rec)
            stats["data_documents_analyzed"] += 1
            if rec["valid_kdbx"]:
                findings.append(make_finding(
                    "KDBX_CONTAINER_VALID", Severity.INFO,
                    f"{path.name} has a structurally valid KeePass KDBX signature/version header.",
                    str(path), {"file_path": str(path), **rec, "file_sha256": sha256_file(path),
                    **deterministic_metadata("KDBX signature/version header validation", validators=["binary header parser"])}, artifact_path=str(path),
                ))
            else:
                stats["invalid_kdbx_like_files"] += 1
                findings.append(make_finding(
                    "KDBX_LIKE_MARKER", Severity.INFO,
                    f"{path.name} uses a KDBX-like filename but is not a structurally valid KeePass database.",
                    str(path), {"file_path": str(path), **rec, "file_sha256": sha256_file(path),
                    **deterministic_metadata("KDBX signature/version header validation", validators=["binary header parser"], semantic_limit="No credential database claim")}, artifact_path=str(path),
                ))

        text, embedded_meta, method = _document_text_and_metadata(path, output_dir, logger)
        metadata_records = native_metadata_records(path)
        # Prefer the namespace-aware native records. Keep parser-returned metadata
        # only as an application namespace when no exact format record exists.
        represented = {(str(r.get("namespace")), str(r.get("field")), str(r.get("value"))) for r in metadata_records}
        for field, value in embedded_meta.items():
            key = ("APPLICATION_METADATA", str(field).lstrip("/"), str(value))
            if key not in represented and value not in (None, ""):
                metadata_records.append({"namespace": "APPLICATION_METADATA", "field": str(field).lstrip("/"), "value": str(value), "parser": method, "source_path": str(path), "source_sha256": sha256_file(path)})
        for meta in metadata_records:
            namespace = str(meta.get("namespace") or "APPLICATION_METADATA")
            field = str(meta.get("field") or "")
            value = meta.get("value")
            if not field or value in (None, ""):
                continue
            findings.append(make_finding(
                "DOCUMENT_METADATA_FIELD", Severity.INFO,
                f"{namespace} field {field} was deterministically parsed from {path.name}.",
                str(path), {
                    "file_path": str(path), "file_sha256": sha256_file(path),
                    "metadata_namespace": namespace, "metadata_field": field,
                    "metadata_value": value, "parser": meta.get("parser") or method,
                    "raw_reference": meta.get("raw_reference") or meta.get("raw_offset") or "",
                    **deterministic_metadata("format-aware metadata parser", validators=[str(meta.get("parser") or method)]),
                }, artifact_path=str(path),
            ))
            stats["metadata_fields_reported"] += 1
        if ext in {".mbox", ".eml"} and method == "utf8-text" and not any(r.get("file") == str(path) and r.get("type") == "mbox" for r in records):
            stats["data_documents_analyzed"] += 1
        if text or embedded_meta:
            ids = _extract_case_identifiers(text + "\n" + "\n".join(f"{k}={v}" for k, v in embedded_meta.items()))
            rec2 = {"file": str(path), "type": "semantic_content", "text_method": method, "text_length": len(text), "metadata": embedded_meta, "case_identifiers": ids}
            records.append(rec2)
            mismatched = [value for value in ids if trusted_case_ids and value not in trusted_case_ids]
            if mismatched:
                semantic_text = re.sub(r"\s+", " ", text).strip()
                semantic_key = (hashlib.sha256(semantic_text.encode("utf-8", errors="replace")).hexdigest(), tuple(sorted(mismatched)))
                existing = case_mismatch_findings.get(semantic_key)
                alias_record = {"file_path": str(path), "file_sha256": sha256_file(path), "text_method": method}
                if existing is not None:
                    existing.metadata.setdefault("semantic_duplicate_aliases", []).append(alias_record)
                else:
                    finding = make_finding(
                        "DOCUMENT_CASE_IDENTIFIER_MISMATCH", Severity.MEDIUM,
                        f"{path.name} contains explicitly case-labelled identifier(s) that differ from acquisition metadata: {', '.join(mismatched[:10])}.",
                        str(path), {"file_path": str(path), "trusted_case_identifiers": trusted_case_ids, "observed_case_identifiers": ids,
                        "mismatched_identifiers": mismatched, "text_method": method, "file_sha256": alias_record["file_sha256"],
                        "semantic_text_sha256": semantic_key[0], "semantic_duplicate_aliases": [],
                        **deterministic_metadata("explicit case-labelled token comparison against retained acquisition metadata", validators=["format text parser", "EWF metadata manifest"])}, artifact_path=str(path),
                    )
                    case_mismatch_findings[semantic_key] = finding
                    findings.append(finding)
                    stats["case_identifier_mismatches"] += 1

    report_path = output_dir / "document_analysis.json"
    try:
        report_path.write_text(json.dumps({
            "module": MODULE_NAME,
            "case_id": case_id,
            "generated_at": utc_now(),
            **stats,
            "legacy_incomplete": legacy_incomplete,
            "warnings": sorted(set(warnings)),
            "errors": errors,
            "documents": records,
        }, indent=2, ensure_ascii=True), encoding="utf-8")
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write document_analysis.json: {exc}")

    total_examined = stats["office_files_analyzed"] + stats["pdfs_analyzed"]
    total_examined += stats["data_documents_analyzed"]
    complete_scope = (
        not errors and not limit_reached and legacy_incomplete == 0
        and total_examined >= len(office_all) + len(pdf_all) + len(data_all)
    )
    status = ModuleStatus.COMPLETED if complete_scope else ModuleStatus.PARTIAL
    verdict, skip_reason = resolve_absence_verdict(
        found=len(findings),
        examined=total_examined,
        technique_applied=complete_scope,
        status=status,
        reason_if_indeterminate=(SkipReason.DEPENDENCY_MISSING if legacy_incomplete else SkipReason.PARTIAL_FAILURE),
    )
    summary = (
        f"Document analysis examined {stats['office_files_analyzed']}/{len(office_all)} Office file(s) "
        f"and {stats['pdfs_analyzed']}/{len(pdf_all)} PDF file(s), "
        f"{stats['data_documents_analyzed']}/{len(data_all)} structured/archive document(s), "
        f"{stats['archives_analyzed']} archive(s) and {stats['metadata_fields_reported']} canonical metadata field(s); "
        f"{stats['macros_found']} macro-bearing file(s), {stats['embedded_objects']} embedded object(s), "
        f"{stats['external_relationships']} external relationship(s), and {stats['risky_pdf_files']} risky PDF file(s)."
    )
    if warnings:
        summary += " Warning: " + "; ".join(sorted(set(warnings))[:2]) + "."

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=(datetime.fromisoformat(utc_now()) - datetime.fromisoformat(start_time)).total_seconds(),
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={**stats, "warnings": sorted(set(warnings)), "documents_discovered": len(office_all) + len(pdf_all) + len(data_all), "documents_processed": total_examined, "limit_reached": limit_reached, "unresolved_supported_objects": max(0, len(office_all) + len(pdf_all) + len(data_all) - total_examined)},
        summary=summary,
        class_results=[ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Document Active Content",
            verdict=verdict,
            skip_reason=skip_reason,
            count=len(findings),
            notes="; ".join(sorted(set(warnings))),
        )],
    )
