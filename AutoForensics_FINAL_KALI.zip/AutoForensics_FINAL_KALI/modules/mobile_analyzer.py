"""Mobile extraction analysis using ALEAPP and iLEAPP.

The module accepts Android/iOS extraction directories and supported LEAPP
archive inputs (ZIP, TAR and GZIP). It never treats a disk image as a mobile
extraction merely because the mobile profile was selected. Tool paths are
configurable and every reported finding references the LEAPP output file from
which it was derived.
"""
from __future__ import annotations

import csv
import hashlib
import json
import logging
import shutil
import subprocess
import sys
import tarfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from modules.mobile_native import materialize_input as _native_materialize, parse as _native_parse
from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    resolve_absence_verdict,
    utc_now,
)

try:
    from core.custody_log import EventType
except ImportError:  # pragma: no cover
    EventType = None  # type: ignore

MODULE_NAME = "mobile_analyzer"
ALEAPP_TIMEOUT = 3600
ILEAPP_TIMEOUT = 3600

_ANDROID_MARKERS = (
    "data/data/", "data/user/", "android/", "com.android.",
    "system/users/", "misc/wifi/", "packages.xml",
)
_IOS_MARKERS = (
    "homedomain/", "appdomain", "private/var/", "library/sms/",
    "manifest.db", "info.plist", "status.plist",
)


def _log_coc(coc_logger: Any, event: Any, description: str, evidence_path: Path, metadata: dict[str, Any]) -> None:
    if coc_logger is None or EventType is None:
        return
    try:
        coc_logger.log(event, description, evidence_path=str(evidence_path), metadata=metadata)
    except Exception:
        pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _archive_names(path: Path, limit: int = 0) -> list[str]:
    names: list[str] = []
    try:
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as zf:
                names = [n.lower() for n in (zf.namelist()[:limit] if limit > 0 else zf.namelist())]
        elif tarfile.is_tarfile(path):
            with tarfile.open(path, "r:*") as tf:
                for index, member in enumerate(tf):
                    if limit > 0 and index >= limit:
                        break
                    names.append(member.name.lower())
    except Exception:
        return []
    return names


def _detect_device_type(evidence_path: Path, configured: str = "") -> Optional[str]:
    declared = str(configured or "").strip().lower()
    if declared in {"android", "ios"}:
        return declared

    candidates: list[str] = []
    if evidence_path.is_dir():
        for child in evidence_path.rglob("*"):
            try:
                candidates.append(child.relative_to(evidence_path).as_posix().lower())
            except ValueError:
                continue
    elif evidence_path.is_file():
        candidates = _archive_names(evidence_path)
        candidates.append(evidence_path.name.lower())

    corpus = "\n".join(candidates)
    android_score = sum(1 for marker in _ANDROID_MARKERS if marker in corpus)
    ios_score = sum(1 for marker in _IOS_MARKERS if marker in corpus)
    if android_score > ios_score and android_score > 0:
        return "android"
    if ios_score > android_score and ios_score > 0:
        return "ios"
    return None


def _input_type(path: Path, device_type: str, configured: str = "") -> str:
    explicit = str(configured or "").strip().lower()
    if explicit:
        allowed = {"fs", "tar", "zip", "gz", "file"}
        if device_type == "ios":
            allowed.add("itunes")
        if explicit not in allowed:
            raise ValueError(f"Unsupported LEAPP input type '{configured}'")
        return explicit
    if path.is_dir():
        # iTunes/Finder backups contain Manifest.db and hashed payload files.
        if device_type == "ios" and (path / "Manifest.db").is_file():
            return "itunes"
        return "fs"
    suffix = path.suffix.lower()
    if suffix == ".zip":
        return "zip"
    if suffix in {".tar", ".tgz"}:
        return "tar"
    if suffix == ".gz":
        return "gz"
    return "file" if device_type == "ios" else ""


def _resolve_tool(device_type: str, config: dict[str, Any]) -> list[str]:
    key = "aleapp_path" if device_type == "android" else "ileapp_path"
    binary_name = "aleapp" if device_type == "android" else "ileapp"
    script_name = "aleapp.py" if device_type == "android" else "ileapp.py"
    configured = str(config.get(key) or "").strip()
    candidates: list[Path] = []
    if configured:
        candidates.append(Path(configured).expanduser())
    found = shutil.which(binary_name)
    if found:
        candidates.append(Path(found))
    roots = (
        Path("/opt/ALEAPP"), Path("/opt/aleapp"),
        Path("/opt/iLEAPP"), Path("/opt/ileapp"),
    )
    candidates.extend(root / script_name for root in roots)

    for candidate in candidates:
        try:
            candidate = candidate.resolve()
        except OSError:
            continue
        if not candidate.is_file():
            continue
        if candidate.suffix.lower() == ".py":
            return [sys.executable, str(candidate)]
        return [str(candidate)]
    raise FileNotFoundError(
        f"{binary_name} not found. Configure '{key}' or install the LEAPP CLI."
    )


def _run_leapp(
    evidence_path: Path,
    output_dir: Path,
    device_type: str,
    config: dict[str, Any],
    logger: logging.Logger,
) -> tuple[int, str, str, list[str]]:
    prefix = _resolve_tool(device_type, config)
    input_type = _input_type(evidence_path, device_type, str(config.get("leapp_input_type") or config.get("input_type") or ""))
    if not input_type:
        raise ValueError(
            "Android ALEAPP requires an extraction directory or ZIP/TAR/GZIP package; "
            f"unsupported input: {evidence_path.name}"
        )
    command = prefix + ["-t", input_type, "-i", str(evidence_path), "-o", str(output_dir)]
    timeout = ALEAPP_TIMEOUT if device_type == "android" else ILEAPP_TIMEOUT
    rc, stdout, stderr = _run_subprocess(command, timeout=timeout, logger=logger)
    return rc, stdout, stderr, command


def _parse_table(path: Path, max_rows: int = 0) -> list[dict[str, Any]]:
    try:
        if path.suffix.lower() == ".json":
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
            if isinstance(data, list):
                return [x for x in (data[:max_rows] if max_rows > 0 else data) if isinstance(x, dict)]
            if isinstance(data, dict):
                for key in ("data", "rows", "records", "items"):
                    rows = data.get(key)
                    if isinstance(rows, list):
                        return [x for x in (rows[:max_rows] if max_rows > 0 else rows) if isinstance(x, dict)]
                return [data]
        delimiter = "\t" if path.suffix.lower() in {".tsv", ".txt"} else ","
        with path.open("r", encoding="utf-8", errors="replace", newline="") as fh:
            reader = csv.DictReader(fh, delimiter=delimiter)
            rows: list[dict[str, Any]] = []
            for index, row in enumerate(reader):
                if max_rows > 0 and index >= max_rows:
                    break
                if row:
                    rows.append(dict(row))
            return rows
    except Exception:
        return []


def _find_report(report_dir: Path, patterns: tuple[str, ...]) -> Optional[Path]:
    candidates: list[Path] = []
    for suffix in ("*.csv", "*.tsv", "*.json"):
        candidates.extend(report_dir.rglob(suffix))
    ordered = sorted(set(candidates))
    # Pattern priority matters: ``native_browser_history`` must win over a
    # lexicographically earlier ``native_browser_downloads`` file that also
    # contains the generic word "browser".
    for pattern in patterns:
        for path in ordered:
            if pattern in path.name.lower():
                return path
    return None


def _finding_from_report(
    *,
    finding_type: str,
    severity: Severity,
    label: str,
    report_path: Optional[Path],
    evidence_path: Path,
    device_type: str,
    count_key: str,
    stats: dict[str, int],
) -> Optional[Any]:
    if report_path is None:
        return None
    rows = _parse_table(report_path)
    stats[count_key] = len(rows)
    if not rows:
        return None
    source_paths: list[str] = []
    for row in rows:
        for key in ("_source_database", "source_database", "source_file", "source_path", "file_path"):
            value = row.get(key)
            if value and Path(str(value)).is_file() and str(value) not in source_paths:
                source_paths.append(str(value))
    retained_source = source_paths[0] if source_paths else str(evidence_path)
    return make_finding(
        finding_type=finding_type,
        severity=severity,
        description=(
            f"{label}: {len(rows)} exact structured record(s) parsed from the {device_type} "
            "extraction. Record provenance and the complete parser table are retained; "
            "duplicate wrappers are not treated as independent corroboration."
        ),
        evidence_path=retained_source,
        artifact_path=str(report_path),
        metadata={
            **deterministic_metadata(
                "read-only structured database/archive row parsing",
                validators=["SQLite/archive parser", "source row locator", "source/report SHA-256"],
                semantic_limit="Stored records only; authorship, device user and real-world attribution are not inferred.",
            ),
            "device_type": device_type,
            "record_count": len(rows),
            "source_report": str(report_path),
            "source_report_sha256": _sha256(report_path),
            "source_databases": source_paths,
            "source_records": rows,
            "sample": rows[:10],
        },
    )


def _run_single(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    output_dir.mkdir(parents=True, exist_ok=True)
    _log_coc(
        coc_logger,
        EventType.MODULE_STARTED if EventType else None,
        "Mobile extraction analysis started",
        evidence_path,
        {"module": MODULE_NAME, "case_id": case_id},
    )

    findings: list[Any] = []
    artifacts: list[str] = []
    errors: list[str] = []
    device_type = _detect_device_type(evidence_path, str(config.get("device_type") or ""))
    if not device_type:
        end_time = utc_now()
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            summary="DID NOT RUN — mobile platform could not be identified from the extraction; declare device_type as android or ios.",
            class_results=[ClassResult(
                locus=Locus.OTHER,
                artefact_class="Mobile Device Artifacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_CORPUS,
                notes="No Android or iOS extraction markers were confirmed.",
            )],
        )

    report_dir = output_dir / f"{device_type}_leapp_output"
    report_dir.mkdir(parents=True, exist_ok=True)
    native_input = _native_materialize(evidence_path, output_dir / "native_mobile_input")
    native_result = _native_parse(native_input, report_dir, device_type)
    # A native parser can complete successfully with zero artefacts.  Treating
    # an empty valid extraction as a failure would convert a verified negative
    # control into PARTIAL.  Completion is therefore tied to the generated
    # parser manifest, while findings remain independently countable.
    native_manifest = Path(str(native_result.get("manifest") or ""))
    native_completed = native_manifest.is_file()
    tool_completed = False
    command: list[str] = []
    # ALEAPP/iLEAPP are validators for suitable first-class mobile extraction
    # corpora. A disk image that contains controlled mobile-style artefacts is
    # parsed natively; fallback success must never be reported as LEAPP success.
    first_class_mobile = str(config.get("evidence_type") or "").lower() == "mobile"
    leapp_applicable = first_class_mobile and bool(config.get("run_leapp", True))
    leapp_status = "NOT_APPLICABLE — no first-class specialist mobile extraction source"
    leapp_exit_code = None
    if leapp_applicable:
        try:
            rc, stdout, stderr, command = _run_leapp(
                evidence_path, report_dir, device_type, config, logger
            )
            leapp_exit_code = rc
            log_path = report_dir / f"{device_type}_leapp_execution.txt"
            log_path.write_text(
                "COMMAND: " + json.dumps(command) + "\nRETURN_CODE: " + str(rc) +
                "\n\nSTDOUT\n" + stdout + "\n\nSTDERR\n" + stderr,
                encoding="utf-8", errors="replace",
            )
            artifacts.append(str(log_path))
            if rc != 0:
                leapp_status = f"FAILED_ISOLATED — external LEAPP returned {rc}"
                errors.append(f"LEAPP returned non-zero status {rc}: {stderr[:500]}")
            else:
                tool_completed = True
                leapp_status = "COMPLETED"
        except FileNotFoundError as exc:
            leapp_status = "FAILED_ISOLATED — dependency unavailable"
            errors.append(str(exc))
        except subprocess.TimeoutExpired as exc:
            leapp_status = "FAILED_ISOLATED — timeout"
            errors.append(str(exc))
        except (ValueError, OSError) as exc:
            leapp_status = "FAILED_ISOLATED — unsupported or invalid input"
            errors.append(str(exc))

    report_files = [
        path for path in report_dir.rglob("*")
        if path.is_file() and path.suffix.lower() in {".html", ".csv", ".tsv", ".json", ".txt", ".kml"}
    ]
    artifacts.extend(str(path) for path in report_files if str(path) not in artifacts)
    if native_result.get("manifest"):
        artifacts.append(str(native_result["manifest"]))

    stats = {
        "call_log_entries": 0,
        "sms_entries": 0,
        "contacts_found": 0,
        "apps_found": 0,
        "browser_history_entries": 0,
        "browser_download_entries": 0,
        "chat_entries": 0,
        "device_info_records": 0,
        "location_entries": 0,
        "report_files": len(report_files),
    }
    specs = (
        ("MOBILE_CALL_LOG", Severity.MEDIUM, "Mobile call log", ("call", "phone"), "call_log_entries"),
        ("MOBILE_SMS", Severity.MEDIUM, "Mobile SMS/MMS", ("sms", "message"), "sms_entries"),
        ("MOBILE_CONTACT", Severity.INFO, "Mobile contacts", ("contact", "addressbook"), "contacts_found"),
        ("MOBILE_APP_INSTALLED", Severity.INFO, "Installed mobile applications", ("installed_app", "package", "application"), "apps_found"),
        ("MOBILE_BROWSER_HISTORY", Severity.MEDIUM, "Mobile browser history", ("native_browser_history", "browser", "chrome", "safari", "history"), "browser_history_entries"),
        ("MOBILE_BROWSER_DOWNLOAD", Severity.INFO, "Mobile browser downloads", ("native_browser_downloads", "download"), "browser_download_entries"),
        ("MOBILE_CHAT", Severity.MEDIUM, "Mobile application chat", ("native_chat", "chat"), "chat_entries"),
        ("MOBILE_DEVICE_INFO", Severity.INFO, "Mobile device information", ("native_device_info", "device_info"), "device_info_records"),
        ("MOBILE_LOCATION_HISTORY", Severity.MEDIUM, "Mobile location history", ("location", "gps", "significant"), "location_entries"),
    )
    for finding_type, severity, label, patterns, count_key in specs:
        finding = _finding_from_report(
            finding_type=finding_type,
            severity=severity,
            label=label,
            report_path=_find_report(report_dir, patterns),
            evidence_path=evidence_path,
            device_type=device_type,
            count_key=count_key,
            stats=stats,
        )
        if finding is not None:
            findings.append(finding)

    leapp_errors = list(errors)
    if native_completed and errors:
        # Native parsing completed a real evidence technique. LEAPP unavailability
        # remains transparent in the manifest but does not turn the module into a
        # failed result or prevent evidence-backed native findings.
        errors = [e for e in errors if "not found" not in e.lower()]

    summary_path = output_dir / "mobile_analysis_summary.json"
    summary_path.write_text(json.dumps({
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "device_type": device_type,
        "tool_command": command,
        "tool_completed": tool_completed,
        "native_completed": native_completed,
        "native_mobile_artifact_parsing": "MET" if native_completed else "NOT MET",
        "mobile_device_acquisition": "OUT_OF_SCOPE — mobile-device acquisition is not part of disk-image analysis",
        "leapp_applicable": leapp_applicable,
        "leapp_status": leapp_status,
        "leapp_exit_code": leapp_exit_code,
        "native_result": native_result,
        **stats,
        "errors": errors,
        "leapp_errors": leapp_errors,
    }, indent=2, ensure_ascii=True), encoding="utf-8")
    artifacts.append(str(summary_path))

    end_time = utc_now()
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
    analysis_completed = tool_completed or native_completed
    if native_completed and leapp_applicable and not tool_completed:
        status = ModuleStatus.COMPLETED_WITH_FALLBACK
    elif analysis_completed:
        status = ModuleStatus.COMPLETED
    elif report_files or findings:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.FAILED_ISOLATED
    verdict, skip_reason = resolve_absence_verdict(
        found=len(findings),
        examined=len(report_files),
        technique_applied=analysis_completed and bool(report_files),
        status=status,
        reason_if_indeterminate=(
            SkipReason.DEPENDENCY_MISSING if any("not found" in e.lower() for e in errors)
            else SkipReason.PARTIAL_FAILURE
        ),
    )
    class_result = ClassResult(
        locus=Locus.OTHER,
        artefact_class="Mobile Device Artifacts",
        verdict=verdict,
        skip_reason=skip_reason,
        count=len(findings),
        notes=(
            "Native mobile artefact parsing completed for the supplied controlled corpus. "
            + ("The external LEAPP run completed independently." if tool_completed else leapp_status)
            + " Mobile-device acquisition is outside the current validation scope."
            if analysis_completed else "No suitable mobile parsing technique completed; absence is not asserted."
        ),
    )
    summary = (
        f"{device_type.upper()} native artefact parsing retained {len(findings)} "
        f"evidence-referenced finding group(s). External LEAPP status: {leapp_status}. "
        "This does not establish physical or logical mobile-device acquisition."
    )
    _log_coc(
        coc_logger,
        EventType.MODULE_COMPLETED if EventType and status != ModuleStatus.SKIPPED else EventType.MODULE_SKIPPED if EventType else None,
        summary,
        evidence_path,
        {"module": MODULE_NAME, "status": status.value, "device_type": device_type, **stats},
    )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifacts,
        errors=errors,
        statistics={**stats,
                    "native_mobile_artifact_parsing": "MET" if native_completed else "NOT MET",
                    "native_completed": native_completed,
                    "mobile_device_acquisition": "OUT_OF_SCOPE",
                    "specialist_applicable": leapp_applicable,
                    "leapp_completed": tool_completed,
                    "leapp_status": leapp_status,
                    "leapp_exit_code": leapp_exit_code},
        summary=summary,
        class_results=[class_result],
    )


def _source_key(path: Path) -> str:
    try:
        return _sha256(path) if path.is_file() else str(path.resolve())
    except OSError:
        return str(path)


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """Analyse first-class or recursively discovered mobile evidence sources.

    Android and iOS sources may coexist inside a disk image.  Each source is
    parsed independently, byte-identical archive aliases are collapsed, and the
    results are aggregated without treating copied wrappers as corroboration.
    """
    source_records: list[tuple[Path, str]] = []
    for record in config.get("mobile_root_records") or []:
        if isinstance(record, dict) and record.get("path"):
            source_records.append((Path(str(record["path"])), str(record.get("platform") or "")))
    for value in config.get("mobile_roots") or []:
        source_records.append((Path(str(value)), ""))
    for value in config.get("mobile_sources") or []:
        source_records.append((Path(str(value)), ""))
    ws = config.get("_working_set") or {}
    for record in ws.get("nested_mobile_root_records") or []:
        if isinstance(record, dict) and record.get("path"):
            source_records.append((Path(str(record["path"])), str(record.get("platform") or "")))
    for key in ("nested_mobile_roots", "nested_mobile_sources"):
        for value in ws.get(key) or []:
            source_records.append((Path(str(value)), ""))
    if not source_records:
        source_records = [(Path(evidence_path), str(config.get("device_type") or ""))]

    unique: list[tuple[Path, str]] = []
    seen: set[tuple[str, str]] = set()
    for source, platform in source_records:
        if not source.exists():
            continue
        detected = platform if platform in {"android", "ios"} else (_detect_device_type(source, "") or "")
        if not detected:
            continue
        key = (_source_key(source), detected)
        if key in seen:
            continue
        seen.add(key)
        unique.append((source, detected))

    if not unique:
        now = utc_now()
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=now,
            end_time=now,
            duration_seconds=0.0,
            summary="DID NOT RUN — no structurally identified Android or iOS extraction source was available.",
            findings=[],
            errors=[],
            statistics={
                "sources_examined": 0,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
                "applicability_check_completed": True,
            },
            class_results=[ClassResult(
                locus=Locus.OTHER,
                artefact_class="Mobile Device Artifacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_CORPUS,
                notes="No mobile database schema, extraction path structure or validated archive wrapper was identified.",
            )],
        )

    overall_start = utc_now()
    findings: list[Any] = []
    artifacts: list[str] = []
    errors: list[str] = []
    stats: dict[str, Any] = {
        "sources_examined": len(unique),
        "sources_discovered": len(unique),
        "sources_processed": 0,
        "supported_objects_discovered": len(unique),
        "supported_objects_processed": 0,
        "source_results": [],
        "call_log_entries": 0,
        "sms_entries": 0,
        "contacts_found": 0,
        "apps_found": 0,
        "browser_history_entries": 0,
        "browser_download_entries": 0,
        "chat_entries": 0,
        "device_info_records": 0,
        "location_entries": 0,
        "report_files": 0,
        "leapp_applicable_sources": 0,
        "leapp_completed_sources": 0,
        "specialist_applicable": False,
        "leapp_completed": False,
    }
    statuses: list[ModuleStatus] = []
    for index, (source, platform) in enumerate(unique):
        subdir = output_dir / f"source_{index:02d}_{platform}"
        subconfig = dict(config)
        subconfig["device_type"] = platform
        # Prevent recursive source aggregation inside the single-source worker.
        for key in ("mobile_root_records", "mobile_roots", "mobile_sources"):
            subconfig.pop(key, None)
        result = _run_single(source, case_id, subdir, subconfig, logger, coc_logger)
        stats["sources_processed"] += 1
        stats["supported_objects_processed"] += 1
        statuses.append(result.status)
        for finding in result.findings:
            metadata = dict(getattr(finding, "metadata", {}) or {})
            metadata.setdefault("mobile_source", str(source))
            metadata.setdefault("mobile_source_sha256", _source_key(source) if source.is_file() else None)
            metadata.setdefault("mobile_platform", platform)
            finding.metadata = metadata
            findings.append(finding)
        artifacts.extend(result.artifact_paths)
        errors.extend(result.errors)
        for key in ("call_log_entries", "sms_entries", "contacts_found", "apps_found", "browser_history_entries", "browser_download_entries", "chat_entries", "device_info_records", "location_entries", "report_files"):
            stats[key] += int((result.statistics or {}).get(key) or 0)
        result_stats = dict(result.statistics or {})
        specialist_applicable = bool(result_stats.get("specialist_applicable"))
        specialist_completed = bool(result_stats.get("leapp_completed"))
        if specialist_applicable:
            stats["leapp_applicable_sources"] += 1
            if specialist_completed:
                stats["leapp_completed_sources"] += 1
        stats["source_results"].append({
            "source": str(source),
            "platform": platform,
            "status": result.status.value,
            "finding_count": len(result.findings),
            "specialist_applicable": specialist_applicable,
            "leapp_completed": specialist_completed,
            "summary": result.summary,
        })

    overall_end = utc_now()
    duration = (datetime.fromisoformat(overall_end) - datetime.fromisoformat(overall_start)).total_seconds()
    if any(status in {ModuleStatus.ERROR, ModuleStatus.FAILED, ModuleStatus.FAILED_OFFSET, ModuleStatus.FAILED_ISOLATED} for status in statuses):
        status = ModuleStatus.PARTIAL if findings else ModuleStatus.FAILED_ISOLATED
    elif any(status == ModuleStatus.PARTIAL for status in statuses):
        status = ModuleStatus.PARTIAL
    elif any(status == ModuleStatus.COMPLETED_WITH_FALLBACK for status in statuses):
        status = ModuleStatus.COMPLETED_WITH_FALLBACK
    else:
        status = ModuleStatus.COMPLETED
    verdict = AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT
    summary = (
        f"Mobile analysis examined {len(unique)} canonical source(s) across "
        f"{len({platform for _, platform in unique})} platform type(s); "
        f"{len(findings)} evidence-referenced finding group(s)."
    )
    # Retain structurally identified mobile archive wrappers as format facts,
    # not as independent corroboration of the duplicated extraction content.
    inventory = (ws.get("evidence_inventory") or {}) if isinstance(ws, dict) else {}
    all_objects = list(inventory.get("objects") or [])
    objects_by_path = {str(o.get("path")): o for o in all_objects}
    aliases_by_canonical: dict[str, list[dict[str, Any]]] = {}
    for obj in all_objects:
        alias_of = str(obj.get("alias_of") or "")
        if alias_of and obj.get("object_type") == "mobile_archive":
            aliases_by_canonical.setdefault(alias_of, []).append({
                "path": obj.get("path"), "sha256": obj.get("sha256"),
                "subtype": obj.get("subtype"),
            })
    for value in ws.get("nested_mobile_sources") or config.get("mobile_sources") or []:
        source = Path(str(value))
        obj = objects_by_path.get(str(source), {})
        if not source.is_file() or obj.get("object_type") != "mobile_archive":
            continue
        findings.append(make_finding(
            finding_type="MOBILE_ARCHIVE_WRAPPER", severity=Severity.INFO,
            description=f"A structurally identified {obj.get('subtype') or 'mobile archive'} wrapper was retained: {source.name}.",
            evidence_path=str(source), artifact_path=str(source),
            metadata={
                "finding_basis":"deterministic", "deterministic_validation":True,
                "validation_method":"archive magic/member-path structure parsing",
                "file_sha256":obj.get("sha256"), "wrapper_subtype":obj.get("subtype"),
                "wrapper_metadata":obj.get("metadata"),
                "wrapper_aliases": aliases_by_canonical.get(str(source), []),
                "semantic_scope":"format wrapper only; duplicate wrappers are aliases and not independent corroboration",
            },
        ))

    # Canonicalise byte-identical mobile/database/media sources without losing
    # their physical paths.  Hash identity is evidence identity; platform and
    # wrapper paths are occurrences, not independent corroboration.
    semantic_groups: dict[str, dict[str, Any]] = {}
    for finding in findings:
        md = dict(getattr(finding, "metadata", {}) or {})
        candidate_path = md.get("source_path") or md.get("file_path") or md.get("database_path") or md.get("mobile_source") or getattr(finding, "evidence_path", "")
        path = Path(str(candidate_path)) if candidate_path else None
        digest = str(md.get("file_sha256") or md.get("sha256") or "")
        if not digest and path and path.is_file():
            digest = _sha256(path)
        if not digest or digest == "ERROR":
            continue
        group = semantic_groups.setdefault(digest, {"canonical_sha256":digest,"canonical_path":str(path) if path else "","physical_occurrences":[]})
        occurrence={"path":str(path) if path else str(candidate_path or ""),"platform":md.get("mobile_platform"),"source":md.get("mobile_source")}
        if occurrence not in group["physical_occurrences"]:
            group["physical_occurrences"].append(occurrence)
        md["canonical_semantic_object_id"] = "mobile-sha256-" + digest[:24]
        md["physical_occurrence_count"] = len(group["physical_occurrences"])
        finding.metadata = md
    duplicate_groups = [g for g in semantic_groups.values() if len(g["physical_occurrences"]) > 1]
    stats["canonical_semantic_objects"] = len(semantic_groups)
    stats["duplicate_representation_groups"] = len(duplicate_groups)
    stats["duplicate_physical_occurrences"] = sum(len(g["physical_occurrences"])-1 for g in duplicate_groups)
    stats["semantic_duplicate_groups"] = duplicate_groups

    aggregate_path = output_dir / "mobile_aggregate_manifest.json"
    stats["specialist_applicable"] = stats["leapp_applicable_sources"] > 0
    stats["leapp_completed"] = bool(
        stats["leapp_applicable_sources"] > 0
        and stats["leapp_completed_sources"] == stats["leapp_applicable_sources"]
    )
    stats["parser_errors"] = len(errors)
    stats["records_discovered"] = sum(
        int(stats.get(key) or 0) for key in (
            "call_log_entries", "sms_entries", "contacts_found", "apps_found",
            "browser_history_entries", "browser_download_entries", "chat_entries",
            "device_info_records", "location_entries"
        )
    )
    stats["records_processed"] = stats["records_discovered"]
    stats["unresolved_supported_objects"] = sum(
        1 for result in stats["source_results"]
        if str(result.get("status") or "") not in {ModuleStatus.COMPLETED.value, ModuleStatus.PASS_COMPLETE.value}
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    aggregate_path.write_text(json.dumps({"case_id": case_id, **stats}, indent=2, ensure_ascii=True), encoding="utf-8")
    artifacts.append(str(aggregate_path))
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=overall_start,
        end_time=overall_end,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=sorted(set(artifacts)),
        errors=errors,
        statistics={**stats, "execution_outcome": "ran_found_x" if findings else "ran_found_nothing"},
        summary=summary,
        class_results=[
            ClassResult(
                locus=Locus.OTHER,
                artefact_class="Mobile Artefact Parsing for Supplied Corpus",
                verdict=verdict,
                count=len(findings),
                notes="Native read-only SQLite/archive parsing; byte-identical wrapper aliases are not independent evidence.",
                summarised=True,
            ),
            ClassResult(
                locus=Locus.OTHER,
                artefact_class="Mobile-device Acquisition",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NOT_APPLICABLE,
                notes="OUT OF SCOPE — this module analyses supplied mobile extractions; it does not acquire data from a physical mobile device.",
            ),
            ClassResult(
                locus=Locus.OTHER,
                artefact_class="ALEAPP on Suitable Android Extraction",
                verdict=(
                    AssuranceVerdict.PRESENT
                    if any(r.get("platform") == "android" and r.get("leapp_completed") for r in stats["source_results"])
                    else AssuranceVerdict.INDETERMINATE
                ),
                skip_reason=(
                    None if any(r.get("platform") == "android" and r.get("leapp_completed") for r in stats["source_results"])
                    else SkipReason.NOT_APPLICABLE if not any(r.get("platform") == "android" and r.get("specialist_applicable") for r in stats["source_results"])
                    else SkipReason.PARTIAL_FAILURE
                ),
                notes=(
                    "ALEAPP completed on every applicable Android source."
                    if any(r.get("platform") == "android" and r.get("leapp_completed") for r in stats["source_results"])
                    else "No first-class Android specialist source was applicable."
                    if not any(r.get("platform") == "android" and r.get("specialist_applicable") for r in stats["source_results"])
                    else "ALEAPP did not complete on one or more applicable Android sources."
                ),
            ),
            ClassResult(
                locus=Locus.OTHER,
                artefact_class="iLEAPP on Suitable iOS Extraction",
                verdict=(
                    AssuranceVerdict.PRESENT
                    if any(r.get("platform") == "ios" and r.get("leapp_completed") for r in stats["source_results"])
                    else AssuranceVerdict.INDETERMINATE
                ),
                skip_reason=(
                    None if any(r.get("platform") == "ios" and r.get("leapp_completed") for r in stats["source_results"])
                    else SkipReason.NOT_APPLICABLE if not any(r.get("platform") == "ios" and r.get("specialist_applicable") for r in stats["source_results"])
                    else SkipReason.PARTIAL_FAILURE
                ),
                notes=(
                    "iLEAPP completed on every applicable iOS source."
                    if any(r.get("platform") == "ios" and r.get("leapp_completed") for r in stats["source_results"])
                    else "No first-class iOS specialist source was applicable."
                    if not any(r.get("platform") == "ios" and r.get("specialist_applicable") for r in stats["source_results"])
                    else "iLEAPP did not complete on one or more applicable iOS sources."
                ),
            ),
        ],
    )
