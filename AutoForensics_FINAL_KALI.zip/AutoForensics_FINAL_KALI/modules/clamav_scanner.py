"""
clamav_scanner.py — ClamAV Antivirus Scanner Module for AutoForensics.

Runs ``clamscan`` against all extracted files and parses detections by virus
family to assign forensic severity.  Also captures the ClamAV database version
and signature date for chain-of-custody documentation.

Severity classification by virus name family prefix:
  Trojan.*, Backdoor.*, Ransomware.*, Exploit.*  → HIGH
  PUA.* (Potentially Unwanted Application)        → MEDIUM
  Adware.*                                        → LOW
  Other FOUND                                     → MEDIUM

Target platform : Kali Linux, Python 3.11+
External tools  : clamscan (clamav package)
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
import time
import shutil
import hashlib
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots, iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "clamav_scanner"
CLAMSCAN_TIMEOUT: int = 7200   # 2 hours for large evidence trees

_HIGH_FAMILIES: tuple[str, ...] = (
    "Trojan", "Backdoor", "Ransomware", "Exploit", "Rootkit",
    "Worm", "Virus", "Spyware", "Keylogger",
)
_MEDIUM_FAMILIES: tuple[str, ...] = ("PUA", "Heuristics",)
_LOW_FAMILIES: tuple[str, ...] = ("Adware", "Joke",)


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _classify_virus(virus_name: str) -> Severity:
    """
    Classify a ClamAV virus name into a forensic severity level.

    Parameters
    ----------
    virus_name : ClamAV detection name (e.g. 'Trojan.Agent-CKZ').

    Returns
    -------
    Severity enum value.
    """
    for family in _HIGH_FAMILIES:
        if virus_name.startswith(family):
            return Severity.HIGH
    for family in _MEDIUM_FAMILIES:
        if virus_name.startswith(family):
            return Severity.MEDIUM
    for family in _LOW_FAMILIES:
        if virus_name.startswith(family):
            return Severity.LOW
    return Severity.MEDIUM  # default for any other FOUND


def _get_clamscan_version(logger: logging.Logger) -> dict[str, str]:
    """
    Run ``clamscan --version`` and parse version and database information.

    Parameters
    ----------
    logger : Module logger.

    Returns
    -------
    Dict with keys: version, db_version, db_date.
    """
    info: dict[str, str] = {"version": "unknown", "db_version": "unknown", "db_date": "unknown"}
    try:
        rc, stdout, _ = _run_subprocess(
            ["clamscan", "--version"], timeout=30, logger=logger
        )
        if rc == 0 and stdout:
            # ClamAV 1.0.3/26900/Mon Dec  4 09:15:35 2023
            line = stdout.strip().splitlines()[0]
            parts = line.split("/")
            if len(parts) >= 3:
                info["version"] = parts[0].strip()
                info["db_version"] = parts[1].strip()
                info["db_date"] = parts[2].strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return info


def _parse_clamscan_output(output: str) -> list[dict[str, str]]:
    """
    Parse clamscan --infected output into structured detection records.

    Each infected line has the format: ``<filepath>: <VirusName> FOUND``

    Parameters
    ----------
    output : Raw stdout from clamscan.

    Returns
    -------
    List of dicts with keys: file_path, virus_name.
    """
    detections: list[dict[str, str]] = []
    pattern = re.compile(r"^(.+): (.+) FOUND$")
    for line in output.splitlines():
        m = pattern.match(line.strip())
        if m:
            detections.append({
                "file_path": m.group(1).strip(),
                "virus_name": m.group(2).strip(),
            })
    return detections



def _clamav_database_files(db_path: str = "") -> list[Path]:
    """Return usable ClamAV database files from the configured/default directory."""
    roots = [Path(db_path).expanduser()] if db_path else [Path("/var/lib/clamav")]
    suffixes = {".cvd", ".cld", ".cud", ".hdb", ".hsb", ".mdb", ".msb", ".ndb", ".ldb", ".cbc", ".cdb"}
    files: list[Path] = []
    for root in roots:
        if root.is_file() and root.suffix.lower() in suffixes and root.stat().st_size > 0:
            files.append(root)
        elif root.is_dir():
            files.extend(p for p in root.iterdir() if p.is_file() and p.suffix.lower() in suffixes and p.stat().st_size > 0)
    return sorted(files)


def _eligible_scope_files(files: list[Path], max_file_size_mb: int) -> list[Path]:
    # Zero means no module-imposed file-size exclusion.
    ceiling = max_file_size_mb * 1024 * 1024 if max_file_size_mb > 0 else None
    eligible: list[Path] = []
    for path in files:
        try:
            if path.is_file() and (ceiling is None or path.stat().st_size <= ceiling):
                eligible.append(path)
        except OSError:
            continue
    return eligible


def _chunks(values: list[Path], size: int = 200):
    for index in range(0, len(values), size):
        yield values[index:index + size]

def _parse_clamscan_summary(output: str) -> dict[str, int]:
    """Parse stable numeric fields from the ClamAV scan summary."""
    result = {"known_viruses": 0, "scanned_directories": 0, "scanned_files": 0,
              "infected_files": 0, "data_scanned_mb": 0}
    mapping = {
        "Known viruses": "known_viruses",
        "Scanned directories": "scanned_directories",
        "Scanned files": "scanned_files",
        "Infected files": "infected_files",
    }
    for line in output.splitlines():
        stripped = line.strip()
        for label, key in mapping.items():
            if stripped.startswith(label + ":"):
                raw = stripped.split(":", 1)[1].strip().replace(",", "")
                match = re.search(r"\d+", raw)
                if match:
                    result[key] = int(match.group(0))
        if stripped.startswith("Data scanned:"):
            match = re.search(r"([0-9.]+)\s*MB", stripped, re.I)
            if match:
                result["data_scanned_mb"] = int(float(match.group(1)))
    return result

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Scan all extracted files with ClamAV and report detections.

    Parameters
    ----------
    evidence_path  : Forensic image path (recorded in findings).
    case_id        : Unique case identifier.
    output_dir     : Directory containing extracted files to scan.
    config         : Configuration dict; recognised keys:
                     - ``clamav_db_path`` (str): custom database directory.
                     - ``max_file_size_mb`` (int): optional safety cap; 0/default means exhaustive.
    logger         : Standard Python logger.
    coc_logger     : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with CLAMAV_DETECTION findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run.
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    scan_root = str(_corpus_roots[0]) if _corpus_roots else None
    if not _corpus_roots:
        cr = ClassResult(
            locus=Locus.MALWARE,
            artefact_class="ClamAV Signature Matches",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            notes="No extracted files directory to scan",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — no extracted files to scan",
            findings=[], errors=[], statistics={
                "applicability_check_completed": True,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
            },
            class_results=[cr],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    max_file_size_mb = int(config.get("max_file_size_mb", 0) or 0)
    db_path = str(config.get("clamav_db_path", "") or "")
    db_files = _clamav_database_files(db_path)
    official_db_files = list(db_files)
    evidence_signature_files = [
        Path(str(v)) for v in (config.get("evidence_clamav_signature_sources") or [])
        if v and Path(str(v)).is_file()
    ]
    database_scope = "official_or_configured" if db_files else "none"

    # Combine official/configured databases with evidence-contained custom NDB
    # signatures in a private read-only scan directory. This enables exact
    # validation signatures embedded in any evidence corpus without replacing
    # general antivirus coverage or relying on fixture names.
    if evidence_signature_files:
        combined_dir = output_dir / "clamav_combined_database"
        combined_dir.mkdir(parents=True, exist_ok=True)
        combined: list[Path] = []
        for idx, source in enumerate([*db_files, *evidence_signature_files]):
            try:
                target = combined_dir / f"{idx:03d}_{source.name}"
                if not target.exists():
                    shutil.copy2(source, target)
                combined.append(target)
            except OSError as exc:
                errors.append(f"Could not stage ClamAV signature {source}: {exc}")
        if combined:
            db_path = str(combined_dir)
            db_files = combined
            database_scope = (
                "official_plus_evidence_custom" if official_db_files
                else "evidence_custom_only"
            )

    # A controlled synthetic case may use the bundled EICAR-only signature when
    # the official database is unavailable. This makes the planted validation
    # test executable without pretending that general malware absence was
    # examined. Production/non-synthetic cases remain fail-closed.
    if not db_files and not evidence_signature_files and bool(config.get("synthetic_validation")):
        synthetic_db = Path(__file__).resolve().parents[1] / "config" / "clamav" / "synthetic_validation.ndb"
        if synthetic_db.is_file() and synthetic_db.stat().st_size > 0:
            db_path = str(synthetic_db)
            db_files = [synthetic_db]
            database_scope = "synthetic_eicar_only"
            logger.warning(
                "[%s] Official ClamAV database unavailable; using bundled EICAR-only synthetic validation signature.",
                MODULE_NAME,
            )

    scan_files = iter_corpus_files(
        ws, output_dir=output_dir, include_case_context=False,
        include_derived=False, deduplicate_by_hash=False,
    )
    eligible_paths = _eligible_scope_files(scan_files, max_file_size_mb)
    eligible_files = len(eligible_paths)
    size_excluded_files = max(0, len(scan_files) - eligible_files)
    if size_excluded_files:
        errors.append(
            f"Configured max_file_size_mb excluded {size_excluded_files} evidentiary file(s); full ClamAV scope was not completed."
        )
    if not db_files:
        readiness = output_dir / "clamav_readiness.json"
        readiness.write_text(json.dumps({
            "module": MODULE_NAME, "case_id": case_id, "ready": False,
            "database_path": str(db_path or "/var/lib/clamav"),
            "reason": "No supported ClamAV signature database files were found.",
            "eligible_files": eligible_files,
        }, indent=2), encoding="utf-8")
        cr = ClassResult(
            locus=Locus.MALWARE, artefact_class="ClamAV Signature Matches",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="ClamAV engine is installed but its signature database is unavailable. Run freshclam.",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=utc_now(), findings=[],
            artifact_paths=[str(readiness)], errors=["ClamAV signature database unavailable"],
            statistics={
                "sources_discovered": len(scan_files), "sources_processed": 0,
                "supported_objects_discovered": len(scan_files), "supported_objects_processed": 0,
                "unresolved_supported_objects": len(scan_files), "parser_errors": 1,
                "eligible_files": eligible_files, "size_excluded_files": size_excluded_files,
                "database_files": 0, "engine_completed": False, "execution_outcome": "failed",
            },
            summary="SKIPPED — ClamAV signature database unavailable; no clean/absence verdict was issued.",
            class_results=[cr],
        )

    # Get ClamAV version for chain of custody
    version_info = _get_clamscan_version(logger)
    logger.info("[%s] ClamAV version: %s, DB: %s (%s)",
                MODULE_NAME, version_info["version"],
                version_info["db_version"], version_info["db_date"])
    _log_coc(coc_logger, "TOOL_VERSION", {
        "tool": "clamscan",
        "version": version_info["version"],
        "db_version": version_info["db_version"],
        "db_date": version_info["db_date"],
    })

    raw_outputs: list[str] = []
    scan_rc: int | None = 0
    scan_complete = True
    scan_start = time.monotonic()
    try:
        # Scan exact provenance-filtered files in bounded batches. This avoids
        # recursively scanning analysis configuration, validation references or
        # module-generated derivatives that happen to share a parent directory.
        for batch in _chunks(eligible_paths, 200):
            cmd = ["clamscan", "--infected"]
            if max_file_size_mb > 0:
                cmd.append(f"--max-filesize={max_file_size_mb}M")
            if db_path:
                cmd += ["--database", db_path]
            cmd.extend(str(path) for path in batch)
            rc, stdout, stderr = _run_subprocess(cmd, timeout=CLAMSCAN_TIMEOUT, logger=logger)
            raw_outputs.append(stdout)
            if rc not in (0, 1):
                scan_rc = rc
                scan_complete = False
                errors.append(f"clamscan batch returned rc={rc}: {stderr[:500]}")
                break
            if rc == 1:
                scan_rc = 1
        raw_output = "\n".join(raw_outputs)
        scan_duration = time.monotonic() - scan_start
        logger.info("[%s] clamscan complete: rc=%s, duration=%.1fs, exact_files=%d",
                    MODULE_NAME, scan_rc, scan_duration, eligible_files)
    except FileNotFoundError:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MALWARE,
            artefact_class="ClamAV Signature Matches",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="clamscan not found — install clamav package",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["clamscan not found — install clamav package"],
            statistics={
                "sources_discovered": len(scan_files), "sources_processed": 0,
                "supported_objects_discovered": len(scan_files), "supported_objects_processed": 0,
                "unresolved_supported_objects": len(scan_files), "parser_errors": 1,
                "engine_completed": False, "execution_outcome": "failed",
            },
            summary="FAILED — clamscan was required for discovered evidence but was unavailable.",
            class_results=[cr],
        )
    except subprocess.TimeoutExpired:
        errors.append(f"clamscan timed out after {CLAMSCAN_TIMEOUT}s")
        scan_duration = CLAMSCAN_TIMEOUT

    # Write raw report
    raw_path = output_dir / "clamav_report.txt"
    try:
        raw_path.write_text(raw_output, encoding="utf-8", errors="replace")
        artifact_paths.append(str(raw_path))
    except OSError as exc:
        errors.append(f"Failed to write clamav_report.txt: {exc}")

    # Parse detections
    detections = _parse_clamscan_output(raw_output)
    scan_summary = _parse_clamscan_summary(raw_output)
    # Every eligible path was supplied explicitly. A 0/1 return for every batch
    # is the coverage proof; summary counters are informational because multiple
    # batch summaries may be concatenated.
    scan_complete = bool(
        scan_complete and scan_rc in (0, 1) and not size_excluded_files
        and eligible_files == len(scan_files)
    )
    by_severity: dict[str, int] = {"HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}

    detection_records: list[dict[str, Any]] = []
    for det in detections:
        sev = _classify_virus(det["virus_name"])
        by_severity[sev.value] += 1
        findings.append(make_finding(
            finding_type="CLAMAV_DETECTION",
            severity=sev,
            description=(
                f"ClamAV detected '{det['virus_name']}' in: {det['file_path']}"
            ),
            evidence_path=str(evidence_path),
            metadata={
                **deterministic_metadata(
                    "ClamAV engine exact signature match",
                    validators=["clamscan", "loaded signature database"],
                ),
                "infected_file": det["file_path"],
                "virus_name": det["virus_name"],
                "db_version": version_info["db_version"],
                "database_scope": database_scope,
                "signature_sources": [str(p) for p in evidence_signature_files],
                "file_path": det["file_path"],
                "file_sha256": (
                    hashlib.sha256(Path(det["file_path"]).read_bytes()).hexdigest()
                    if Path(det["file_path"]).is_file() else ""
                ),
            },
            artifact_path=(det["file_path"] if Path(det["file_path"]).is_file() else None),
        ))
        detection_records.append({**det, "severity": sev.value})
        logger.warning("[%s] DETECTION [%s] %s in %s",
                       MODULE_NAME, sev.value, det["virus_name"], det["file_path"])

    # Write JSON report
    json_path = output_dir / "clamav_detections.json"
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(),
                "clamscan_version": version_info,
                "total_detections": len(detections),
                "by_severity": by_severity,
                "scan_duration_seconds": round(scan_duration, 2) if "scan_duration" in dir() else None,
                "scan_exit_code": scan_rc,
                "scan_complete": scan_complete,
                "database_scope": database_scope,
                "scan_summary": scan_summary,
                "detections": detection_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(json_path))
    except OSError as exc:
        errors.append(f"Failed to write clamav_detections.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL

    scope_note = (
        " using the bundled EICAR-only synthetic validation signature"
        if database_scope == "synthetic_eicar_only" else ""
    )
    summary = (
        f"ClamAV scan{scope_note}: {len(detections)} detections "
        f"({by_severity['HIGH']} HIGH, {by_severity['MEDIUM']} MEDIUM)."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "detections": len(detections)})

    cr = ClassResult(
        locus=Locus.MALWARE,
        artefact_class="ClamAV Signature Matches",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT if scan_complete and database_scope in {
                "official_or_configured", "official_plus_evidence_custom", "evidence_custom_only"
            }
            else AssuranceVerdict.INDETERMINATE
        ),
        skip_reason=(
            None if findings or (scan_complete and database_scope in {
                "official_or_configured", "official_plus_evidence_custom", "evidence_custom_only"
            })
            else SkipReason.LAYER2_UNVERIFIED if database_scope == "synthetic_eicar_only"
            else SkipReason.PARTIAL_FAILURE
        ),
        count=len(findings),
        notes=(
            "Synthetic EICAR-only database was used; a general malware-absence conclusion is not available."
            if database_scope == "synthetic_eicar_only" and not findings
            else "Evidence-contained custom signatures were fully applied; absence is limited to those exact signatures."
            if database_scope == "evidence_custom_only" and not findings and scan_complete
            else "" if scan_complete else "; ".join(errors[:3])
        ),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            "files_scanned": eligible_files if scan_complete else scan_summary["scanned_files"],
            "sources_discovered": len(scan_files),
            "sources_processed": eligible_files if scan_complete else min(eligible_files, scan_summary["scanned_files"]),
            "supported_objects_discovered": len(scan_files),
            "supported_objects_processed": eligible_files if scan_complete else min(eligible_files, scan_summary["scanned_files"]),
            "records_discovered": len(scan_files),
            "records_processed": eligible_files if scan_complete else min(eligible_files, scan_summary["scanned_files"]),
            "unresolved_supported_objects": 0 if scan_complete else max(1, len(scan_files) - min(eligible_files, scan_summary["scanned_files"])),
            "parser_errors": len(errors),
            "size_excluded_files": size_excluded_files,
            "engine_completed": bool(scan_complete),
            "directories_scanned": scan_summary["scanned_directories"],
            "scan_complete": scan_complete,
            "scan_exit_code": scan_rc,
            "total_detections": len(detections),
            "by_severity": by_severity,
            "db_version": version_info["db_version"],
            "database_files": len(db_files),
            "database_scope": database_scope,
            "official_database_files": len(official_db_files),
            "evidence_signature_files": [str(p) for p in evidence_signature_files],
            "eligible_files": eligible_files,
            "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if scan_complete else "ran_with_caveat"),
        },
        summary=summary,
        class_results=[cr],
    )
