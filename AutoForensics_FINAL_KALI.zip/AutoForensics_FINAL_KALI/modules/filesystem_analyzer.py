"""Native filesystem/partition detection and capability reporting."""
from __future__ import annotations
import hashlib, json, logging, time
from pathlib import Path
from typing import Any
from core.native_filesystem import detect_filesystems
from core.fat32_validation import validate_fat32
from core.deterministic_validation import deterministic_metadata
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

MODULE_NAME = "filesystem_analyzer"


def _compact_fat32_validation(validation: dict | None, manifest_path: Path) -> dict:
    """Return report-safe structural facts while retaining the full map as an artefact.

    The full cluster-ownership map can contain one entry per allocated cluster.
    Embedding it in every finding/statistics record multiplied report JSON size and
    could prevent PDF generation.  The map remains in the signed module manifest;
    findings carry its count, digest and exact artefact path.
    """
    if not validation:
        return {}
    omitted = {"cluster_ownership"}
    compact = {key: value for key, value in validation.items() if key not in omitted}
    ownership = validation.get("cluster_ownership") or {}
    canonical = json.dumps(ownership, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    compact.update({
        "cluster_ownership_count": len(ownership),
        "cluster_ownership_sha256": hashlib.sha256(canonical).hexdigest(),
        "cluster_ownership_artifact": str(manifest_path),
        "cluster_ownership_embedded_in_finding": False,
    })
    return compact


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict,
        logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now(); t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    analysis_path = Path(config.get("analysis_path") or str(evidence_path)).resolve()
    if not analysis_path.is_file():
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
            summary="DID NOT RUN — readable raw/reconstructed media file unavailable.",
            class_results=[ClassResult(
                locus=Locus.FILE_SYSTEM, artefact_class="Filesystem Metadata",
                verdict=AssuranceVerdict.INDETERMINATE, skip_reason=SkipReason.NO_EVIDENCE,
            )],
        )
    try:
        candidates = detect_filesystems(analysis_path)
        errors = []
    except Exception as exc:
        candidates = []; errors = [str(exc)]
    findings = []
    manifest = output_dir / "filesystem_analyzer_manifest.json"
    fat32_validation = None
    for candidate in candidates:
        if str(candidate.fs_type).upper() == "FAT32":
            try:
                manifest_path = (config.get("_working_set") or {}).get("native_filesystem_manifest")
                fat32_validation = validate_fat32(
                    analysis_path,
                    offset_bytes=int(candidate.offset_bytes or 0),
                    manifest_path=manifest_path,
                )
            except Exception as exc:
                errors.append(f"FAT32 structural validation incomplete: {exc}")
        meta = candidate.metadata or {}
        geometry_parts = []
        for label, key in (
            ("bytes/sector", "bytes_per_sector"),
            ("total sectors", "total_sectors"),
            ("sectors/cluster", "sectors_per_cluster"),
            ("volume label", "volume_label"),
            ("volume serial", "volume_serial"),
            ("OEM", "oem_name"),
        ):
            value = meta.get(key)
            if value not in (None, ""):
                geometry_parts.append(f"{label}={value}")
        geometry = "; ".join(geometry_parts)
        description = (
            f"{candidate.fs_type} filesystem detected natively at sector "
            f"{candidate.offset_sectors} using {candidate.source}."
        )
        if candidate.offset_sectors == 0 and candidate.source == "super-floppy/direct":
            description += " No partition table offset was required (direct/super-floppy volume)."
        if geometry:
            description += f" Geometry: {geometry}."
        findings.append(make_finding(
            finding_type="FILESYSTEM_STRUCTURE_CONFIRMED", severity=Severity.INFO,
            description=description,
            evidence_path=str(evidence_path), metadata={**candidate.as_dict(), **meta,
                **({"fat32_validation": _compact_fat32_validation(fat32_validation, manifest)} if fat32_validation else {}),
                **deterministic_metadata("filesystem boot-sector/signature and geometry parsing", validators=["core.native_filesystem.detect_filesystems", "core.fat32_validation.validate_fat32"])},
            artifact_path=str(output_dir / "filesystem_analyzer_manifest.json"),
        ))
        if fat32_validation:
            findings.append(make_finding(
                finding_type="FAT32_STRUCTURAL_VALIDATION",
                severity=Severity.INFO,
                description=(
                    "FAT32 structural validation: primary/backup boot sectors "
                    f"{'match' if fat32_validation.get('primary_backup_boot_sectors_equal') else 'do not match or were unavailable'}; "
                    f"FAT copies {'match' if fat32_validation.get('fat_copies_equal') else 'do not match'}; "
                    f"allocated={fat32_validation.get('allocated_clusters')}, free={fat32_validation.get('free_clusters')}, "
                    f"bad={fat32_validation.get('bad_clusters')}; active files={fat32_validation.get('active_files')}, "
                    f"deleted files={fat32_validation.get('deleted_files')}; active cluster chains "
                    f"{'validate' if fat32_validation.get('active_chains_valid') else 'require review'}."
                ),
                evidence_path=str(evidence_path),
                metadata={**_compact_fat32_validation(fat32_validation, manifest), **deterministic_metadata(
                    "direct BPB/FAT/cluster-chain validation",
                    validators=["backup boot-sector byte comparison", "FAT copy byte comparison", "FAT entry enumeration", "native cluster-chain manifest"],
                )},
                artifact_path=str(output_dir / "filesystem_analyzer_manifest.json"),
            ))
    caveats = [c for candidate in candidates for c in candidate.caveats]
    outcome = "ran_found_x" if candidates else ("ran_with_caveat" if errors else "ran_found_nothing")
    manifest.write_text(json.dumps({
        "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
        "execution_outcome": outcome, "analysis_path": str(analysis_path),
        "filesystems": [c.as_dict() for c in candidates],
        "fat32_structural_validation": fat32_validation,
        "caveats": caveats,
        "errors": errors, "external_tools_required": False,
    }, indent=2), encoding="utf-8")
    if errors:
        status = ModuleStatus.PARTIAL
        verdict = AssuranceVerdict.INDETERMINATE
        reason = SkipReason.PARTIAL_FAILURE
    else:
        status = ModuleStatus.COMPLETED
        verdict = AssuranceVerdict.PRESENT if candidates else AssuranceVerdict.VERIFIED_ABSENT
        reason = None
    summary = (
        f"RAN AND FOUND {len(candidates)} filesystem candidate(s) natively."
        if candidates else "RAN AND FOUND NOTHING — no supported filesystem signature recognised."
    )
    if caveats:
        summary = f"RAN WITH CAVEAT — {summary} {'; '.join(caveats[:2])}"
        status = ModuleStatus.PARTIAL
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
        findings=findings, artifact_paths=[str(manifest)], errors=errors,
        statistics={"filesystem_count": len(candidates), "execution_outcome": outcome,
                    "objects_examined": len(candidates),
                    "raw_observations": len(candidates),
                    "fat32_structural_validation": _compact_fat32_validation(fat32_validation, manifest)},
        summary=summary,
        class_results=[ClassResult(
            locus=Locus.FILE_SYSTEM, artefact_class="Filesystem Metadata",
            verdict=verdict, skip_reason=reason, count=len(candidates), notes="; ".join(caveats),
        )],
    )
