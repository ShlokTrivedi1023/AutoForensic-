"""
bulk_extractor_scan.py — Bulk Extractor Scanner Module for AutoForensics.

Runs ``bulk_extractor`` to scan for structured data patterns across the entire
forensic image — regardless of filesystem structure.  bulk_extractor is a stream
processor that scans byte-by-byte for:

  emails, URLs, credit card numbers, phone numbers, domain names,
  Bitcoin addresses, EXIF GPS data, JSON fragments, and more.

Output files are written to ``bulk_extractor_output/`` and parsed to build
structured findings.  Credit card numbers are validated with the Luhn algorithm.

Target platform : Kali Linux, Python 3.11+
External tools  : bulk_extractor
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
import re
import subprocess
from pathlib import Path
from typing import Any

from core.deterministic_validation import (
    classify_luhn_identifier, deterministic_metadata, strict_emails, strict_urls,
    validated_bitcoin_addresses, candidate_metadata,
)

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    check_dependency,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "bulk_extractor_scan"
BULK_EXTRACTOR_TIMEOUT: int = 7200   # 2 hours

_RE_EMAIL = re.compile(r"\b[a-zA-Z0-9._%+\-]{1,64}@[a-zA-Z0-9.\-]{1,253}\.[a-zA-Z]{2,}\b")
_RE_CCN = re.compile(r"\b(?:\d[ -]?){13,16}\b")

# E.164 / NANP phone number validation
# E.164: +[1–15 digit country code][up to 15 digits total], e.g. +12025551234
# NANP : 10-digit North American numbers, various separators
_RE_PHONE_E164 = re.compile(r'^\+\d{7,15}$')
_RE_PHONE_NANP = re.compile(
    r'^(?:\+?1[-.\s]?)?'           # optional country code
    r'\(?\d{3}\)?'                  # area code
    r'[-.\s]?\d{3}'                 # exchange
    r'[-.\s]?\d{4}$'               # subscriber
)

def _is_valid_phone(raw: str) -> bool:
    """Return True if raw matches E.164 or NANP format."""
    s = raw.strip()
    if not s:
        return False
    # Strip common non-digit prefixes bulk_extractor adds (e.g. "tel:", whitespace)
    s = s.lstrip("tel:").strip()
    # Reject sequences of all same digits (noise like "0000000000" or "1111111111")
    digits_only = re.sub(r"[^\d]", "", s)
    if digits_only and len(set(digits_only)) == 1:
        return False
    return bool(_RE_PHONE_E164.match(s) or _RE_PHONE_NANP.match(s))


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _luhn_check(number: str) -> bool:
    """
    Validate a credit card number string using the Luhn algorithm.

    Parameters
    ----------
    number : Digit string (spaces/dashes stripped).

    Returns
    -------
    True if the number passes Luhn validation.
    """
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _parse_be_records(
    be_path: Path,
    max_entries: int = 0,
) -> list[dict[str, Any]]:
    """Parse bulk_extractor feature rows.

    Current bulk_extractor output is ``offset<TAB>feature<TAB>context``.  Older
    code treated the context column as the feature, which produced malformed
    URLs and missed valid telephone/email values.
    """
    records: list[dict[str, Any]] = []
    if not be_path.exists():
        return records
    try:
        with open(be_path, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if max_entries > 0 and len(records) >= max_entries:
                    break
                line = line.rstrip("\r\n")
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                offset_raw = parts[0].strip() if parts else ""
                feature = parts[1].strip() if len(parts) >= 2 else offset_raw
                context = "\t".join(parts[2:]).strip() if len(parts) >= 3 else ""
                try:
                    offset: int | str = int(offset_raw, 10)
                except ValueError:
                    offset = offset_raw
                if feature:
                    records.append({"offset": offset, "feature": feature, "context": context})
    except OSError:
        pass
    return records


def _parse_be_file(be_path: Path, max_entries: int = 0) -> list[str]:
    """Compatibility wrapper returning the feature column only."""
    return [str(row["feature"]) for row in _parse_be_records(be_path, max_entries)]


def _is_browser_sqlite(path: Path) -> bool:
    try:
        with open(path, "rb") as handle:
            if handle.read(16) != b"SQLite format 3\x00":
                return False
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            tables = {str(row[0]).lower() for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
        finally:
            conn.close()
        return "urls" in tables or "moz_places" in tables
    except (OSError, sqlite3.Error):
        return False


def _native_file_ranges(config: dict[str, Any]) -> list[dict[str, Any]]:
    """Return raw-media byte ranges for files in the native filesystem manifest."""
    ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
    root_value = ws.get("extracted_files_dir") or ws.get("mounted_fs_root")
    if not root_value:
        return []
    root = Path(root_value)
    manifest_path = root.parent / "native_filesystem_manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        candidate = manifest.get("candidate") or {}
        meta = candidate.get("metadata") or {}
        bps = int(meta.get("bytes_per_sector") or 512)
        cluster_size = int(meta.get("cluster_size") or bps * int(meta.get("sectors_per_cluster") or 1))
        data_start = int(candidate.get("offset_bytes") or 0) + int(meta.get("data_start_sector") or 0) * bps
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return []
    ranges: list[dict[str, Any]] = []
    for entry in manifest.get("files") or []:
        if entry.get("is_directory") or entry.get("deleted"):
            continue
        extracted = Path(str(entry.get("extracted_path") or ""))
        if not extracted.is_file():
            rel = str(entry.get("path") or "").lstrip("/")
            extracted = root / rel
        chain = [int(x) for x in entry.get("cluster_chain") or []]
        remaining = int(entry.get("size_bytes") or 0)
        logical_offset = 0
        for cluster in chain:
            if remaining <= 0:
                break
            length = min(cluster_size, remaining)
            start = data_start + (cluster - 2) * cluster_size
            ranges.append({
                "start": start, "end": start + length,
                "file_path": str(extracted), "logical_path": str(entry.get("path") or ""),
                "file_offset": logical_offset, "sha256": str(entry.get("sha256") or ""),
            })
            logical_offset += length
            remaining -= length
    return ranges


def _resolve_raw_offset(offset: int | str, ranges: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not isinstance(offset, int):
        return None
    for item in ranges:
        if int(item["start"]) <= offset < int(item["end"]):
            resolved = dict(item)
            resolved["offset_in_file"] = int(item["file_offset"]) + offset - int(item["start"])
            return resolved
    return None


def _mask_card(digits: str) -> str:
    return (digits[:4] + "*" * max(0, len(digits) - 8) + digits[-4:]) if len(digits) >= 8 else "*" * len(digits)


def _scan_luhn_candidates(config: dict[str, Any], max_file_bytes: int = 0) -> list[dict[str, Any]]:
    """Find Luhn-valid card-shaped values in extracted structured/text files.

    Only masked values are retained.  Each result carries a source path, byte
    offset and content hash for H2 traceability.
    """
    from modules._base import resolve_corpus_roots
    roots = resolve_corpus_roots(config.get("_working_set", {}), output_dir=None)
    allowed = {".csv", ".tsv", ".txt", ".log", ".json", ".xml", ".html", ".htm"}
    pattern = re.compile(rb"(?<!\d)(?:\d[ -]?){13,19}(?!\d)")
    found: dict[str, dict[str, Any]] = {}
    seen_files: set[str] = set()
    for root in roots:
        for path in root.rglob("*"):
            if not path.is_file() or path.is_symlink() or path.suffix.lower() not in allowed:
                continue
            try:
                file_key = str(path.resolve())
                if file_key in seen_files:
                    continue
                if max_file_bytes > 0 and path.stat().st_size > max_file_bytes:
                    continue
                seen_files.add(file_key)
                data = path.read_bytes()
                digest = hashlib.sha256(data).hexdigest()
            except OSError:
                continue
            for match in pattern.finditer(data):
                raw = match.group().decode("ascii", errors="ignore").strip()
                digits = re.sub(r"\D", "", raw)
                if not (13 <= len(digits) <= 19) or len(set(digits)) == 1 or not _luhn_check(digits):
                    continue
                context_start = max(0, match.start() - 96)
                context_end = min(len(data), match.end() + 96)
                context = data[context_start:context_end].decode("utf-8", errors="replace")
                # Never persist a full Luhn-valid identifier in context.
                context = re.sub(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)", lambda m: _mask_card(re.sub(r"\D", "", m.group(0))), context)
                found.setdefault(digits, {
                    "masked": _mask_card(digits), "last4": digits[-4:],
                    "length": len(digits), "file_path": str(path),
                    "byte_offset": match.start(), "content_sha256": digest,
                    "context": context,
                })
    return list(found.values())


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Run bulk_extractor against the forensic image.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Parent directory for bulk_extractor output.
    config        : Configuration dict; recognised keys:
                    - ``num_threads`` (int): parallel threads (default 4).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with EMAIL_EXTRACTED, CREDIT_CARD_NUMBER, PHONE_NUMBER_EXTRACTED,
    CRYPTO_ADDRESS_EXTRACTED, URL_EXTRACTED findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    if not check_dependency("binary", "bulk_extractor", MODULE_NAME, logger):
        end_time = utc_now()
        from datetime import datetime as _dt
        _dur = (_dt.fromisoformat(end_time) - _dt.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Bulk Extractor Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="bulk_extractor binary not installed",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=_dur,
            summary="FAILED — bulk_extractor is required for the discovered disk evidence but is not installed.",
            findings=[], errors=["bulk_extractor binary not installed"], statistics={
                "sources_discovered": 1, "sources_processed": 0,
                "supported_objects_discovered": 1, "supported_objects_processed": 0,
                "unresolved_supported_objects": 1, "parser_errors": 1,
                "engine_completed": False, "execution_outcome": "failed",
            },
            class_results=[cr],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []

    analysis_source = Path(
        config.get("analysis_path") or config.get("_ewf_device") or str(evidence_path)
    ).resolve()
    if not analysis_source.exists():
        analysis_source = evidence_path.resolve()

    be_dir = output_dir / "bulk_extractor_output"
    be_dir.mkdir(parents=True, exist_ok=True)

    num_threads = int(config.get("num_threads", 4))

    cmd = [
        "bulk_extractor",
        "-o", str(be_dir),
        "-j", str(num_threads),
        "-S", "ssn_mode=1",
        str(analysis_source),
    ]

    logger.info("[%s] Running: %s", MODULE_NAME, " ".join(cmd))

    rc: int | None = None
    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=BULK_EXTRACTOR_TIMEOUT, logger=logger)
        log_path = be_dir / "bulk_extractor_stdout.txt"
        log_path.write_text(stdout + "\n" + stderr, encoding="utf-8", errors="replace")
        artifact_paths.append(str(log_path))
        logger.info("[%s] bulk_extractor completed: rc=%d", MODULE_NAME, rc)
        if rc == 5:
            warnings.append(
                "bulk_extractor completed with scanner caveats (rc=5); feature files were parsed, "
                "but scoped absence cannot be asserted for scanners that did not complete."
            )
        elif rc != 0:
            errors.append(f"bulk_extractor failed with rc={rc}: {stderr[:500]}")
    except FileNotFoundError:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Bulk Extractor Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="bulk_extractor not found — install bulk-extractor package",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["bulk_extractor not found — install bulk-extractor package"],
            statistics={
                "sources_discovered": 1, "sources_processed": 0,
                "supported_objects_discovered": 1, "supported_objects_processed": 0,
                "unresolved_supported_objects": 1, "parser_errors": 1,
                "engine_completed": False, "execution_outcome": "failed",
            },
            summary="FAILED — bulk_extractor was required but could not be executed.",
            class_results=[cr],
        )
    except subprocess.TimeoutExpired:
        errors.append(f"bulk_extractor timed out after {BULK_EXTRACTOR_TIMEOUT}s")

    # Parse output files
    stats: dict[str, int] = {
        "emails_found": 0, "urls_found": 0, "credit_cards_found": 0,
        "phone_numbers_found": 0, "crypto_addresses_found": 0, "ssns_found": 0,
    }

    promote_bulk_iocs = bool(config.get("promote_bulk_iocs", False))

    # Emails
    email_records = _parse_be_records(be_dir / "email.txt")
    valid_emails = []
    for row in email_records:
        value = str(row["feature"]).strip()
        if strict_emails(value) == [value] and value not in valid_emails:
            valid_emails.append(value)
    stats["emails_found"] = len(valid_emails)
    if valid_emails and promote_bulk_iocs:
        findings.append(make_finding(
            finding_type="EMAIL_EXTRACTED",
            severity=Severity.MEDIUM,
            description=f"bulk_extractor found {len(valid_emails)} email addresses.",
            evidence_path=str(evidence_path),
            metadata={**deterministic_metadata("bounded email syntax validation", validators=["strict_emails"]),
                      "count": len(valid_emails), "samples": valid_emails[:20],
                      "feature_file": str(be_dir / "email.txt")},
            artifact_path=str(be_dir / "email.txt"),
        ))
        artifact_paths.append(str(be_dir / "email.txt"))

    # URLs — use the feature column and delegate browser-SQLite offsets to
    # the browser parser, which understands record boundaries and avoids
    # concatenating URL strings with adjacent SQLite titles.
    native_ranges = _native_file_ranges(config)
    url_records = _parse_be_records(be_dir / "url.txt")
    urls: list[str] = []
    delegated_browser_urls = 0
    for row in url_records:
        source = _resolve_raw_offset(row.get("offset", ""), native_ranges)
        if source and _is_browser_sqlite(Path(source["file_path"])):
            delegated_browser_urls += 1
            continue
        value = str(row.get("feature") or "").strip().rstrip(".,;:)")
        if re.fullmatch(r"(?:https?|ftp)://[^\s<>\"{}|\^`\[\]]+", value):
            urls.append(value)
    urls = list(dict.fromkeys(urls))
    stats["urls_found"] = len(urls)
    stats["browser_urls_delegated"] = delegated_browser_urls
    if urls and promote_bulk_iocs:
        findings.append(make_finding(
            finding_type="URL_EXTRACTED",
            severity=Severity.INFO,
            description=f"bulk_extractor found {len(urls)} non-browser-corpus URL(s).",
            evidence_path=str(evidence_path),
            metadata={**deterministic_metadata("absolute URL parsing with valid host", validators=["strict_urls"]),
                      "count": len(urls), "samples": urls[:20],
                      "browser_sqlite_records_delegated": delegated_browser_urls,
                      "feature_file": str(be_dir / "url.txt")},
            artifact_path=str(be_dir / "url.txt"),
        ))

    # Luhn-valid identifiers. Luhn is a checksum, not a semantic type.
    # Explicit nearby context is required before a value is promoted as a
    # payment card or IMEI; otherwise it remains a candidate observation.
    raw_luhn_records: dict[str, dict[str, Any]] = {}
    for row in _parse_be_records(be_dir / "ccn.txt"):
        digits = re.sub(r"[^0-9]", "", str(row.get("feature") or ""))
        context = str(row.get("context") or "")
        if 13 <= len(digits) <= 19 and len(set(digits)) > 1 and _luhn_check(digits):
            raw_luhn_records.setdefault(digits, {
                "masked": _mask_card(digits), "last4": digits[-4:], "length": len(digits),
                "raw_offset": row.get("offset"), "context": context, "source": "bulk_extractor_ccn",
            })
    for record in _scan_luhn_candidates(config):
        try:
            data = Path(record["file_path"]).read_bytes()
            window = data[int(record["byte_offset"]): int(record["byte_offset"]) + 64]
            match = re.search(rb"(?<!\d)(?:\d[ -]?){13,19}(?!\d)", window)
            digits = re.sub(r"\D", "", match.group().decode()) if match else ""
        except Exception:
            digits = ""
        if digits:
            raw_luhn_records.setdefault(digits, record)

    payment_cards: list[dict[str, Any]] = []
    imeis: list[dict[str, Any]] = []
    generic_luhn: list[dict[str, Any]] = []
    for digits, record in raw_luhn_records.items():
        classified = classify_luhn_identifier(digits, str(record.get("context") or ""))
        enriched = {**record, "classification": classified.kind, "classification_reason": classified.reason}
        if classified.kind == "payment_card" and classified.deterministic:
            payment_cards.append(enriched)
        elif classified.kind == "imei" and classified.deterministic:
            imeis.append(enriched)
        else:
            generic_luhn.append(enriched)

    stats["credit_cards_found"] = len(payment_cards)
    stats["imei_identifiers_found"] = len(imeis)
    stats["generic_luhn_candidates"] = len(generic_luhn)
    card_report_path = output_dir / "luhn_identifier_classification.json"
    card_report_path.write_text(json.dumps({
        "case_id": case_id, "payment_cards": payment_cards, "imeis": imeis,
        "unclassified_candidates": generic_luhn,
        "policy": "Luhn validity alone never creates a payment-card finding.",
    }, indent=2), encoding="utf-8")
    artifact_paths.append(str(card_report_path))

    for record in payment_cards:
        findings.append(make_finding(
            finding_type="PAYMENT_CARD_NUMBER", severity=Severity.MEDIUM,
            description=f"A masked Luhn-valid payment-card number was confirmed in explicit payment-card context (ending {record.get('last4', '????')}).",
            evidence_path=str(record.get("file_path") or evidence_path),
            metadata={**deterministic_metadata("Luhn checksum plus explicit payment-card context", validators=["classify_luhn_identifier"]),
                      **{k: v for k, v in record.items() if k != "context"}},
            artifact_path=str(card_report_path),
        ))
    for record in imeis:
        findings.append(make_finding(
            finding_type="IMEI_IDENTIFIER", severity=Severity.INFO,
            description=f"A 15-digit Luhn-valid IMEI was confirmed in explicit device/IMEI context (ending {record.get('last4', '????')}).",
            evidence_path=str(record.get("file_path") or evidence_path),
            metadata={**deterministic_metadata("Luhn checksum plus explicit IMEI/device context", validators=["classify_luhn_identifier"]),
                      **{k: v for k, v in record.items() if k != "context"}},
            artifact_path=str(card_report_path),
        ))

    # Phone numbers
    _raw_phones = [str(row["feature"]) for row in _parse_be_records(be_dir / "telephone.txt")]
    phones = list(dict.fromkeys(p for p in _raw_phones if _is_valid_phone(p)))
    stats["phone_numbers_found"] = len(phones)
    logger.debug("[%s] Phones raw=%d valid=%d", MODULE_NAME, len(_raw_phones), len(phones))
    if phones and promote_bulk_iocs:
        findings.append(make_finding(
            finding_type="PHONE_SHAPED_IDENTIFIER",
            severity=Severity.MEDIUM,
            description=f"bulk_extractor found {len(phones)} unique E.164/NANP-shaped identifier(s); ownership and use are not inferred.",
            evidence_path=str(evidence_path),
            metadata={**deterministic_metadata("exact E.164/NANP syntax and digit constraints", validators=["_is_valid_phone"]),
                      "count": len(phones), "samples": phones[:20], "raw_count": len(_raw_phones),
                      "feature_file": str(be_dir / "telephone.txt")},
            artifact_path=str(be_dir / "telephone.txt"),
        ))

    # Bitcoin addresses
    raw_bitcoins = _parse_be_file(be_dir / "bitcoin.txt")
    bitcoins = []
    for value in raw_bitcoins:
        if value in validated_bitcoin_addresses(value) and value not in bitcoins:
            bitcoins.append(value)
    stats["crypto_addresses_found"] = len(bitcoins)
    if bitcoins and promote_bulk_iocs:
        findings.append(make_finding(
            finding_type="CRYPTO_ADDRESS_EXTRACTED",
            severity=Severity.HIGH,
            description=f"bulk_extractor found {len(bitcoins)} Bitcoin addresses.",
            evidence_path=str(evidence_path),
            metadata={**deterministic_metadata("Bitcoin Base58Check/Bech32 checksum", validators=["validated_bitcoin_addresses"]),
                      "count": len(bitcoins), "samples": bitcoins[:10],
                      "feature_file": str(be_dir / "bitcoin.txt")},
            artifact_path=str(be_dir / "bitcoin.txt"),
        ))

    # SSNs (US Social Security Numbers)
    ssns = _parse_be_file(be_dir / "ssn.txt")
    stats["ssns_found"] = len(ssns)
    # SSN-shaped values are retained as candidates only. Shape has no checksum
    # or provenance and therefore cannot establish an SSN semantic deterministically.
    if ssns:
        ssn_candidate_path = output_dir / "ssn_shape_candidates.json"
        ssn_candidate_path.write_text(json.dumps({
            "count": len(ssns), "samples": ssns[:50],
            "metadata": candidate_metadata("SSN shape regex", reason="No deterministic checksum/provenance validator exists"),
        }, indent=2), encoding="utf-8")
        artifact_paths.append(str(ssn_candidate_path))

    # Add all be_dir files to artifacts
    for f in be_dir.iterdir():
        if f.is_file() and f.suffix in (".txt", ".json"):
            artifact_paths.append(str(f))

    # Write summary
    summary_path = output_dir / "bulk_extractor_summary.json"
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "output_dir": str(be_dir),
                "analysis_source": str(analysis_source),
                "exit_code": rc,
                "warnings": warnings,
                "errors": errors,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(summary_path))
    except OSError as exc:
        errors.append(f"Failed to write bulk_extractor_summary.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    scan_complete = (rc == 0 and not errors)
    status = ModuleStatus.COMPLETED if scan_complete else ModuleStatus.PARTIAL
    summary = (
        f"bulk_extractor: {stats['emails_found']} emails, {stats['urls_found']} URLs, "
        f"{stats['credit_cards_found']} payment cards, {stats.get('imei_identifiers_found', 0)} IMEIs, {stats['crypto_addresses_found']} checksum-valid Bitcoin values."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Bulk Extractor Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT if scan_complete
            else AssuranceVerdict.INDETERMINATE
        ),
        skip_reason=(None if findings or scan_complete else SkipReason.PARTIAL_FAILURE),
        count=len(findings),
        notes="; ".join((errors or warnings)[:3]),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={**stats,
                    "sources_discovered": 1,
                    "sources_processed": 1 if scan_complete else 0,
                    "supported_objects_discovered": 1,
                    "supported_objects_processed": 1 if scan_complete else 0,
                    "records_discovered": sum(int(v) for k, v in stats.items() if k.endswith("_found") and isinstance(v, int)),
                    "records_processed": sum(int(v) for k, v in stats.items() if k.endswith("_found") and isinstance(v, int)),
                    "unresolved_supported_objects": 0 if scan_complete else 1,
                    "parser_errors": len(errors),
                    "analysis_source": str(analysis_source),
                    "exit_code": rc, "scan_complete": scan_complete,
                    "engine_completed": bool(scan_complete),
                    "warnings": warnings,
                    "bulk_ioc_promotion_enabled": promote_bulk_iocs,
                    "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if scan_complete else "ran_with_caveat")}, summary=summary,
        class_results=[cr],
    )
