"""Deterministic IOC matching.

Only exact investigator-supplied or evidence-contained IOC lists are used.
Pattern-only/built-in reputation guesses are intentionally excluded from
PRESENT findings.  Reserved/test indicators are reported as configured matches,
not automatically as malicious infrastructure.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from core.deterministic_validation import deterministic_metadata, strict_emails, strict_ips, strict_urls
from core.structured_records import extract_structured_records, record_locator_metadata, value_role
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus, Severity,
    SkipReason, make_finding, resolve_corpus_roots, iter_corpus_files, utc_now,
)

MODULE_NAME = "ioc_matcher"
_HASH_RE = re.compile(r"(?i)^(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$")
_DOMAIN_RE = re.compile(r"(?i)^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event, " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _normalise_ioc(value: str) -> tuple[str, str] | None:
    value = value.strip().strip('"\'').rstrip(".,;)")
    if not value or value.startswith("#"):
        return None
    # optional type prefix: ip:, domain:, url:, email:, hash:, literal:
    if ":" in value and value.split(":", 1)[0].casefold() in {"ip", "domain", "url", "email", "literal", "hash", "sha256", "sha1", "md5"}:
        prefix, value = value.split(":", 1)
        value = value.strip()
        forced = prefix.casefold()
    else:
        forced = ""
    try:
        ip = str(ipaddress.ip_address(value))
        return "ip", ip
    except ValueError:
        pass
    if _HASH_RE.fullmatch(value):
        return "hash", value.casefold()
    emails = strict_emails(value)
    if emails == [value.casefold()] or emails == [value]:
        return "email", emails[0].casefold()
    urls = strict_urls(value)
    if urls == [value]:
        return "url", value
    lowered = value.casefold().rstrip(".")
    if _DOMAIN_RE.fullmatch(lowered):
        return "domain", lowered
    if forced == "literal" and len(value) >= 4 and value.isprintable():
        return "literal", value
    if forced:
        return None
    # Untyped values that do not parse as a standard IOC are retained as exact
    # configured literals.  They are never assigned reputation or maliciousness.
    if len(value) >= 4 and value.isprintable() and not any(ch.isspace() for ch in value):
        return "literal", value
    return None


def _load_sources(config: dict[str, Any], logger: logging.Logger) -> tuple[dict[str, set[str]], list[dict[str, Any]]]:
    sources: list[tuple[str, str, str]] = []
    for key, kind in (
        ("ioc_ip_file", "ip"), ("ioc_domain_file", "domain"),
        ("ioc_url_file", "url"), ("ioc_email_file", "email"),
        ("ioc_hash_file", "hash"), ("ioc_literal_file", "literal"),
    ):
        if config.get(key):
            sources.append((str(config[key]), "investigator_configured", kind))
    for value in config.get("evidence_ioc_list_sources") or []:
        sources.append((str(value), "evidence_contained", "auto"))

    lists: dict[str, set[str]] = {"ip": set(), "domain": set(), "url": set(), "email": set(), "hash": set(), "literal": set()}
    provenance: list[dict[str, Any]] = []
    seen: set[str] = set()
    for source, source_scope, forced_kind in sources:
        path = Path(source)
        if not path.is_file():
            logger.warning("[%s] IOC source unavailable: %s", MODULE_NAME, path)
            continue
        try:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            resolved = str(path.resolve())
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        counts = {k: 0 for k in lists}
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            item = _normalise_ioc(raw)
            if item is None and forced_kind != "auto":
                value = raw.strip().casefold()
                if forced_kind == "domain" and _DOMAIN_RE.fullmatch(value):
                    item = ("domain", value)
                elif forced_kind == "url" and strict_urls(raw.strip()) == [raw.strip()]:
                    item = ("url", raw.strip())
                elif forced_kind == "hash" and _HASH_RE.fullmatch(value):
                    item = ("hash", value)
                elif forced_kind == "email" and strict_emails(raw.strip()):
                    item = ("email", strict_emails(raw.strip())[0].casefold())
                elif forced_kind == "literal" and len(raw.strip()) >= 4:
                    item = ("literal", raw.strip())
                elif forced_kind == "ip" and strict_ips(raw.strip()):
                    item = ("ip", strict_ips(raw.strip())[0])
            if item:
                kind, value = item
                lists[kind].add(value)
                counts[kind] += 1
        provenance.append({
            "path": resolved, "sha256": digest, "scope": source_scope,
            "counts": counts,
        })
    return lists, provenance


def _bounded_ascii_offsets(raw: bytes, token: str, kind: str) -> list[int]:
    """Find exact configured IOC bytes with kind-specific token boundaries."""
    needle = token.encode("utf-8", errors="strict")
    if not needle:
        return []
    offsets: list[int] = []
    start = 0
    if kind == "ip":
        forbidden = b"0123456789."
    elif kind == "domain":
        forbidden = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-"
    elif kind == "url":
        forbidden = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=%"
    elif kind == "email":
        forbidden = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.!#$%&'*+/=?^_`{|}~-@"
    elif kind == "literal":
        forbidden = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
    else:
        forbidden = b"0123456789abcdefABCDEF"
    while True:
        pos = raw.find(needle, start)
        if pos < 0:
            break
        before = raw[pos - 1:pos] if pos else b""
        after = raw[pos + len(needle):pos + len(needle) + 1]
        if (not before or before not in [bytes([b]) for b in forbidden]) and (not after or after not in [bytes([b]) for b in forbidden]):
            offsets.append(pos)
        start = pos + 1
    return offsets


def _extract_occurrences(
    files: list[Path],
    configured: dict[str, set[str]],
) -> tuple[dict[str, dict[str, list[dict[str, Any]]]], int, list[str]]:
    """Match only configured values against every byte of every retained source.

    Structured fields are parsed first. Opaque sources receive exact bounded byte
    matching. Read failures are returned to the caller and prevent a completeness
    certificate; they are never silently converted into absence.
    """
    occurrences: dict[str, dict[str, list[dict[str, Any]]]] = {
        k: {} for k in ("ip", "domain", "url", "email", "hash", "literal")
    }
    processed = 0
    errors: list[str] = []
    for path in files:
        try:
            raw = path.read_bytes()
            hashes = {
                "md5": hashlib.md5(raw).hexdigest(),
                "sha1": hashlib.sha1(raw).hexdigest(),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        except OSError as exc:
            errors.append(f"Cannot read {path}: {exc}")
            continue
        processed += 1
        for value in hashes.values():
            if value in configured["hash"]:
                occurrences["hash"].setdefault(value, []).append({
                    "file_path": str(path), "source": "exact_file_hash",
                    "byte_offset": 0, "byte_length": len(raw),
                })

        try:
            records = extract_structured_records(path)
        except Exception as exc:
            # The exact opaque-byte fallback is still complete for configured
            # literal occurrences, but a structured-parser error remains visible.
            errors.append(f"Structured parsing failed for {path}: {type(exc).__name__}: {exc}")
            records = []
        seen_record_hits: set[tuple[str, str, str]] = set()
        for record in records:
            for field_name, field_value in record.fields.items():
                text = str(field_value)
                role = value_role(record, field_name)
                values_by_kind: dict[str, set[str]] = {
                    "ip": set(), "url": set(), "domain": set(), "email": set(), "literal": set()
                }
                if role in {"ip", "free_text", "hostname"}:
                    values_by_kind["ip"].update(strict_ips(text))
                if role in {"url", "free_text"}:
                    for url in strict_urls(text):
                        values_by_kind["url"].add(url)
                        host = (urlsplit(url).hostname or "").casefold()
                        if host:
                            values_by_kind["domain"].add(host)
                if role in {"email", "free_text", "sender", "recipient"}:
                    values_by_kind["email"].update(v.casefold() for v in strict_emails(text))
                if role in {"hostname", "free_text"}:
                    for match in re.finditer(r"(?<![A-Za-z0-9.-])(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}(?![A-Za-z0-9.-])", text):
                        values_by_kind["domain"].add(match.group(0).casefold().rstrip("."))
                for configured_literal in configured["literal"]:
                    if configured_literal in text:
                        values_by_kind["literal"].add(configured_literal)
                for kind in ("ip", "url", "domain", "email", "literal"):
                    for value in values_by_kind[kind]:
                        if kind == "domain":
                            matched = _domain_match(value, configured[kind])
                            if not matched:
                                continue
                            configured_value = matched
                        elif value not in configured[kind]:
                            continue
                        else:
                            configured_value = value
                        key = (kind, value, json.dumps(record.locator, sort_keys=True, default=str) + field_name)
                        if key in seen_record_hits:
                            continue
                        seen_record_hits.add(key)
                        occurrences[kind].setdefault(value, []).append({
                            **record_locator_metadata(record, field_name),
                            "source": "structured_field_exact_match",
                            "configured_ioc": configured_value,
                            "field_role": role,
                        })

        # Exact full-file byte search also covers values outside a supported
        # structured field. It proves byte occurrence only, not maliciousness.
        for kind in ("ip", "domain", "url", "email", "literal"):
            for value in configured[kind]:
                probe = value[2:] if kind == "domain" and value.startswith("*.") else value
                for offset in _bounded_ascii_offsets(raw, probe, kind):
                    locations = occurrences[kind].setdefault(probe, [])
                    location = {
                        "file_path": str(path), "source": "exact_bounded_byte_occurrence",
                        "byte_offset": offset, "byte_length": len(probe.encode("utf-8")),
                        "configured_ioc": value,
                    }
                    if location not in locations:
                        locations.append(location)
    return occurrences, processed, errors

def _domain_match(value: str, configured: set[str]) -> str | None:
    if value in configured:
        return value
    for pattern in configured:
        if pattern.startswith("*.") and value.endswith(pattern[1:]) and value != pattern[2:]:
            return pattern
    return None


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict[str, Any], logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now()
    output_dir.mkdir(parents=True, exist_ok=True)
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    configured, provenance = _load_sources(config, logger)
    configured_count = sum(len(v) for v in configured.values())
    if configured_count == 0:
        cr = ClassResult(Locus.MALWARE, "Configured IOC Matches", AssuranceVerdict.INDETERMINATE,
                         SkipReason.NO_EVIDENCE, notes="No investigator-supplied or evidence-contained IOC list was available.")
        return ModuleResult(MODULE_NAME, case_id, ModuleStatus.SKIPPED, start_time=start, end_time=utc_now(),
                            summary="NOT TESTED — no configured IOC list.", class_results=[cr],
                            statistics={"configured_iocs": 0, "execution_outcome": "did_not_run"})

    ws = config.get("_working_set") or {}
    roots = resolve_corpus_roots(ws, output_dir=output_dir)
    files = iter_corpus_files(
        ws, output_dir=output_dir, include_case_context=False,
        include_derived=False, deduplicate_by_hash=False,
    )
    occurrences, files_processed, scan_errors = _extract_occurrences(files, configured)
    findings = []
    records: list[dict[str, Any]] = []

    for kind, values in configured.items():
        for configured_value in sorted(values):
            actual_values: list[tuple[str, str]] = []
            if kind == "domain":
                for observed in occurrences[kind]:
                    match = _domain_match(observed, {configured_value})
                    if match:
                        actual_values.append((observed, match))
            elif kind == "url":
                # URL IOC matching is exact after RFC parsing. Substring matching is forbidden.
                if configured_value in occurrences[kind]:
                    actual_values.append((configured_value, configured_value))
            else:
                if configured_value in occurrences[kind]:
                    actual_values.append((configured_value, configured_value))
            for observed, matched in actual_values:
                locs = occurrences[kind][observed]
                source_scopes = sorted({p["scope"] for p in provenance})
                malicious_claim = "investigator_configured" in source_scopes and bool(config.get("ioc_lists_are_malicious", False))
                severity = Severity.HIGH if malicious_claim else Severity.INFO
                description = (
                    f"Exact {kind.upper()} value '{observed}' matched configured IOC '{matched}'. "
                    + ("The investigator classified this list as malicious." if malicious_claim else "This confirms configured co-occurrence only; maliciousness is not inferred.")
                )
                md = deterministic_metadata(
                    "exact configured-value equality after type-specific parsing",
                    validators=["ipaddress/urlsplit/email parser/hash equality/type-specific boundary parser"],
                    ioc_type=kind, observed_value=observed, matched_ioc=matched,
                    source_locations=locs, list_provenance=provenance,
                    semantic_scope="malicious" if malicious_claim else "configured_reference",
                    semantic_limit=(
                        "Exact configured-value co-occurrence only; no reputation, ownership, "
                        "intent, attribution or malicious behaviour is inferred."
                        if not malicious_claim else
                        "Exact configured-value match; malicious classification comes from the investigator-supplied list policy, not from the match alone."
                    ),
                )
                findings.append(make_finding("IOC_EXACT_MATCH", severity, description,
                                             str(locs[0]["file_path"]), md,
                                             artifact_path=locs[0]["file_path"] if Path(locs[0]["file_path"]).is_file() else None))
                records.append({"type": kind, "observed": observed, "matched": matched, "locations": locs})

    report = output_dir / "ioc_matches.json"
    report.write_text(json.dumps({
        "module": MODULE_NAME, "case_id": case_id, "configured": {k: sorted(v) for k, v in configured.items()},
        "list_provenance": provenance, "files_discovered": len(files),
        "files_examined": files_processed, "scan_errors": scan_errors, "matches": records,
        "policy": "Exact matching only; no built-in reputation, substring URL matching, or regex-based maliciousness claims.",
    }, indent=2, ensure_ascii=True), encoding="utf-8")

    verdict = AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT
    cr = ClassResult(Locus.MALWARE, "Configured IOC Matches", verdict, count=len(findings),
                     notes="Absence is limited to the exact loaded IOC lists and complete examined corpus.")
    unresolved = max(0, len(files) - files_processed)
    status = ModuleStatus.PARTIAL if scan_errors else ModuleStatus.COMPLETED
    summary = (
        f"Loaded {configured_count} exact configured IOC values; examined "
        f"{files_processed}/{len(files)} files; found {len(findings)} exact matches; "
        f"unresolved files: {unresolved}."
    )
    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id, "matches": len(findings)})
    return ModuleResult(MODULE_NAME, case_id, status, start_time=start, end_time=utc_now(),
                        findings=findings, artifact_paths=[str(report)], errors=scan_errors, statistics={
                            "configured_iocs": configured_count,
                            "sources_discovered": len(files), "sources_processed": files_processed,
                            "supported_objects_discovered": len(files), "supported_objects_processed": files_processed,
                            "records_discovered": len(files), "records_processed": files_processed,
                            "files_examined": files_processed,
                            "unresolved_supported_objects": unresolved,
                            "parser_errors": len(scan_errors),
                            "total_matches": len(findings), "list_sources": len(provenance),
                            "execution_outcome": ("ran_incomplete" if scan_errors else ("ran_found_x" if findings else "ran_found_nothing")),
                        }, summary=summary, class_results=[cr])
