"""
rootkit_detector.py — Rootkit Detection Module for AutoForensics.

Uses Volatility 3 to detect rootkit indicators in memory dumps:

  DKOM detection  : Compares PsList (linked-list walk) vs PsScan (pool-tag scan).
                    Processes in PsScan but not PsList are hidden via DKOM.
  SSDT hooks      : windows.ssdt.SSDT — detects hijacked system call table entries.
  IRP hooks       : windows.driverirp.DriverIrp — detects hooked IRP dispatch routines.

All three techniques are standard rootkit detection methods in memory forensics.

Target platform : Kali Linux, Python 3.11+
External tools  : python3 /opt/volatility3/vol.py (Volatility 3)
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.volatility_adapter import run_volatility_plugin

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    assert_subprocess_ok,
    find_memory_source,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "rootkit_detector"
VOL_TIMEOUT: int = 3600

# Modules that are allowed to have SSDT hooks
_LEGIT_SSDT_MODULES: frozenset[str] = frozenset({
    "ntoskrnl.exe", "ntkrnlpa.exe", "ntkrnlmp.exe", "ntkrpamp.exe",
    "win32k.sys", "ntdll.dll",
})


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _run_vol(vol_path: str, evidence_path: Path, plugin: str,
             logger: logging.Logger) -> tuple[int, str, str]:
    """
    Execute a Volatility 3 plugin.

    Parameters
    ----------
    vol_path      : Path to vol.py.
    evidence_path : Memory dump path.
    plugin        : Plugin identifier.
    logger        : Module logger.

    Returns
    -------
    (returncode, stdout, stderr).

    Raises
    ------
    FileNotFoundError       If python3 or vol.py is missing.
    subprocess.TimeoutExpired  If the plugin exceeds VOL_TIMEOUT.
    """
    execution = run_volatility_plugin(
        evidence_path=evidence_path, plugin=plugin,
        config={"vol_path": vol_path}, timeout=VOL_TIMEOUT,
    )
    logger.debug("Volatility command: %s", execution.command)
    return execution.returncode, execution.stdout, execution.stderr


def _parse_vol_tsv(output: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    headers: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("Volatility"):
            continue
        parts = stripped.split("\t")
        if not headers:
            headers = [h.strip() for h in parts]
            continue
        if len(parts) < len(headers):
            parts.extend([""] * (len(headers) - len(parts)))
        rows.append(dict(zip(headers, [p.strip() for p in parts])))
    return rows


def _is_legit_ssdt_module(module_name: str) -> bool:
    return module_name.lower() in _LEGIT_SSDT_MODULES


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Detect rootkit indicators in a memory dump using Volatility 3.

    Parameters
    ----------
    evidence_path : Absolute path to the memory dump.
    case_id       : Unique case identifier.
    output_dir    : Directory where reports are written.
    config        : Configuration dict; recognised key:
                    - ``vol_path`` (str): path to vol.py.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with HIDDEN_PROCESS_DKOM, SSDT_HOOK_DETECTED, IRP_HOOK_DETECTED
    findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    vol_path = config.get("vol_path", "/opt/volatility3/vol.py")

    mem_source = find_memory_source(evidence_path, output_dir, config)
    if mem_source is None:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MALWARE,
            artefact_class="Rootkit Indicators",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            notes="No memory image supplied",
        )
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            summary="SKIPPED — no memory image supplied for this evidence item (no .raw/.lime/.dmp/.vmem found; no hiberfil.sys/pagefile.sys carved)",
            findings=[],
            errors=[],
            statistics={},
            class_results=[cr],
        )
    # Use mem_source for all Volatility calls
    evidence_path = mem_source

    output_dir.mkdir(parents=True, exist_ok=True)

    stats = {
        "pslist_count": 0, "psscan_count": 0,
        "hidden_processes": 0, "ssdt_hooks": 0, "irp_hooks": 0,
    }

    # ------------------------------------------------------------------
    # DKOM Detection: PsList vs PsScan
    # ------------------------------------------------------------------
    pslist_rows: list[dict[str, str]] = []
    psscan_rows: list[dict[str, str]] = []

    for plugin, container in (("windows.pslist.PsList", "pslist"), ("windows.psscan.PsScan", "psscan")):
        txt_path = output_dir / f"rootkit_{plugin.split('.')[-1].lower()}.txt"
        try:
            rc, stdout, stderr = _run_vol(vol_path, evidence_path, plugin, logger)
            txt_path.write_text(stdout, encoding="utf-8", errors="replace")
            artifact_paths.append(str(txt_path))
            try:
                assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
            except RuntimeError as exc:
                errors.append(str(exc))
                end_time = utc_now()
                from datetime import datetime
                duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
                cr = ClassResult(
                    locus=Locus.MALWARE,
                    artefact_class="Rootkit Indicators",
                    verdict=AssuranceVerdict.INDETERMINATE,
                    skip_reason=SkipReason.PARTIAL_FAILURE,
                    notes=f"Volatility {plugin} returned rc={rc}",
                )
                return ModuleResult(
                    module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                    start_time=start_time, end_time=end_time, duration_seconds=duration,
                    errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                    findings=[], statistics={},
                    class_results=[cr],
                )
            rows = _parse_vol_tsv(stdout)
            if container == "pslist":
                pslist_rows = rows
                stats["pslist_count"] = len(rows)
            else:
                psscan_rows = rows
                stats["psscan_count"] = len(rows)
        except FileNotFoundError:
            errors.append(f"Volatility 3 not found at {vol_path}")
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MALWARE,
                artefact_class="Rootkit Indicators",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
                notes=f"Volatility 3 not found at {vol_path}",
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"Skipped: Volatility 3 not found at {vol_path}",
                class_results=[cr],
            )
        except subprocess.TimeoutExpired:
            errors.append(f"{plugin} timed out")

    pslist_pids = {r.get("PID", "") for r in pslist_rows}
    for row in psscan_rows:
        pid = row.get("PID", "")
        if pid and pid not in pslist_pids and pid != "0":
            stats["hidden_processes"] += 1
            proc_name = row.get("ImageFileName") or row.get("Name") or "unknown"
            exact = {**deterministic_metadata(
                "Volatility PsScan/PsList cross-view comparison",
                validators=["Volatility 3 PsScan", "Volatility 3 PsList"],
                semantic_limit="The cross-view discrepancy is established; DKOM or rootkit causation is not established."),
                "process_name": proc_name, "pid": pid, "offset": row.get("Offset(V)", ""),
                "ppid": row.get("PPID", ""), "present_in": ["PsScan"], "absent_from": ["PsList"]}
            findings.append(make_finding(
                finding_type="PROCESS_CROSS_VIEW_DISCREPANCY", severity=Severity.MEDIUM,
                description=f"Process '{proc_name}' (PID {pid}) was present in PsScan and absent from PsList.",
                evidence_path=str(evidence_path), metadata=exact))
            findings.append(make_finding(
                finding_type="ROOTKIT_DKOM_CANDIDATE", severity=Severity.MEDIUM,
                description=f"The cross-view discrepancy for '{proc_name}' is retained for DKOM/rootkit review.",
                evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                    "PsScan/PsList discrepancy",
                    reason="Process lifecycle, acquisition state, symbols and parser limitations can also cause cross-view differences.")}))
            logger.warning("[%s] DKOM hidden process: %s PID=%s", MODULE_NAME, proc_name, pid)

    # Ghost processes (in PsList but not PsScan)
    psscan_pids = {r.get("PID", "") for r in psscan_rows}
    for row in pslist_rows:
        pid = row.get("PID", "")
        proc_name = row.get("ImageFileName") or row.get("Name") or "unknown"
        if pid and pid not in psscan_pids and pid != "0" and proc_name not in ("System",):
            exact = {**deterministic_metadata(
                "Volatility PsList/PsScan cross-view comparison",
                validators=["Volatility 3 PsList", "Volatility 3 PsScan"],
                semantic_limit="The discrepancy is established; corruption or malicious manipulation is not established."),
                "process_name": proc_name, "pid": pid, "present_in": ["PsList"], "absent_from": ["PsScan"]}
            findings.append(make_finding(
                finding_type="PROCESS_CROSS_VIEW_DISCREPANCY", severity=Severity.INFO,
                description=f"Process '{proc_name}' (PID {pid}) was present in PsList and absent from PsScan.",
                evidence_path=str(evidence_path), metadata=exact))
            findings.append(make_finding(
                finding_type="GHOST_PROCESS_CANDIDATE", severity=Severity.LOW,
                description=f"The cross-view discrepancy for '{proc_name}' is retained for lifecycle/corruption review.",
                evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                    "PsList/PsScan discrepancy", reason="An ephemeral process, parser limitation or acquisition state can explain the difference.")}))

    # ------------------------------------------------------------------
    # SSDT Hook Detection
    # ------------------------------------------------------------------
    ssdt_txt = output_dir / "ssdt_output.txt"
    ssdt_plugin = "windows.ssdt.SSDT"
    try:
        rc, stdout, stderr = _run_vol(vol_path, evidence_path, ssdt_plugin, logger)
        ssdt_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(ssdt_txt))
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {ssdt_plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MALWARE,
                artefact_class="Rootkit Indicators",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.PARTIAL_FAILURE,
                notes=f"Volatility {ssdt_plugin} returned rc={rc}",
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {ssdt_plugin} returned rc={rc}",
                findings=findings, statistics=stats,
                class_results=[cr],
            )
        ssdt_rows = _parse_vol_tsv(stdout)
        for row in ssdt_rows:
            module = (row.get("Module") or row.get("Symbol") or "").lower()
            index = row.get("Index") or row.get("#") or ""
            func = row.get("Function") or row.get("Symbol") or ""
            if module and not _is_legit_ssdt_module(module):
                stats["ssdt_hooks"] += 1
                exact = {**deterministic_metadata(
                    "Volatility SSDT record and module ownership fields", validators=["Volatility 3 SSDT"],
                    semantic_limit="The table ownership discrepancy is established; a rootkit hook is not established without build/symbol and independent corroboration."),
                    "ssdt_index": index, "function": func, "observed_module": module}
                findings.append(make_finding(
                    finding_type="SSDT_MODULE_DISCREPANCY", severity=Severity.MEDIUM,
                    description=f"SSDT entry #{index} ({func}) resolved to module '{module}'.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="SSDT_HOOK_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"SSDT entry #{index} is retained for hook review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "expected SSDT owner allow-list", reason="Kernel build, symbols and legitimate drivers can affect ownership; independent validation is required.")}))
    except subprocess.TimeoutExpired:
        errors.append("SSDT plugin timed out")

    # ------------------------------------------------------------------
    # IRP Hook Detection
    # ------------------------------------------------------------------
    irp_txt = output_dir / "irp_hooks_output.txt"
    irp_plugin = "windows.driverirp.DriverIrp"
    try:
        rc, stdout, stderr = _run_vol(vol_path, evidence_path, irp_plugin, logger)
        irp_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(irp_txt))
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {irp_plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MALWARE,
                artefact_class="Rootkit Indicators",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.PARTIAL_FAILURE,
                notes=f"Volatility {irp_plugin} returned rc={rc}",
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {irp_plugin} returned rc={rc}",
                findings=findings, statistics=stats,
                class_results=[cr],
            )
        irp_rows = _parse_vol_tsv(stdout)
        for row in irp_rows:
            driver = (row.get("Driver") or "").lower()
            irp = row.get("IRP") or row.get("IRPMajor") or ""
            module = (row.get("Module") or "").lower()
            # If the IRP handler's module differs from the driver's own module
            if driver and module and driver not in module and not _is_legit_ssdt_module(module):
                stats["irp_hooks"] += 1
                exact = {**deterministic_metadata(
                    "Volatility DriverIrp handler/module fields", validators=["Volatility 3 DriverIrp"],
                    semantic_limit="The handler/module discrepancy is established; a rootkit hook is not established without build/symbol and independent corroboration."),
                    "driver": driver, "irp": irp, "observed_module": module}
                findings.append(make_finding(
                    finding_type="IRP_HANDLER_MODULE_DISCREPANCY", severity=Severity.MEDIUM,
                    description=f"Driver '{driver}' IRP {irp} handler resolved to module '{module}'.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="IRP_HOOK_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"Driver '{driver}' IRP {irp} is retained for hook review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "driver/module name mismatch", reason="Legitimate dispatch indirection and symbol/parser context can explain the mismatch.")}))
    except subprocess.TimeoutExpired:
        errors.append("DriverIrp plugin timed out")

    # Write JSON summary
    json_path = output_dir / "rootkit_analysis.json"
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(json_path))
    except OSError as exc:
        errors.append(f"Failed to write rootkit_analysis.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Rootkit scan: {stats['hidden_processes']} DKOM-hidden processes, "
        f"{stats['ssdt_hooks']} SSDT hooks, {stats['irp_hooks']} IRP hooks."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.MALWARE,
        artefact_class="Rootkit Indicators",
        verdict=(
            AssuranceVerdict.INDETERMINATE if any(bool((getattr(f, "metadata", {}) or {}).get("candidate_only")) for f in findings)
            else (AssuranceVerdict.VERIFIED_ABSENT if not findings else AssuranceVerdict.PRESENT)
        ),
        count=len([f for f in findings if not bool((getattr(f, "metadata", {}) or {}).get("candidate_only"))]),
        notes="Exact structural discrepancies are retained; rootkit attribution remains candidate unless independently corroborated.",
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
        class_results=[cr],
    )
