"""
timeline_builder.py — Forensic Timeline Reconstruction Module.

Workflow:
  1. Detect partition offset dynamically via mmls (never hardcode).
  2. Run fls -r -m "C:/" -o <offset_sectors> <image> -> body.txt
  3. Run mactime -b body.txt -d -> timeline.csv
  4. Ingest cross-module timestamps (UserAssist FILETIMEs from registry, email dates).
  5. Sort all events, group into sessions (< 4h gap), flag anti-forensic sessions.
  6. Emit structured Finding with sorted event table (Time GMT | Event | Source | Severity).
"""
from __future__ import annotations

import csv
import json
import logging
import re
import subprocess
import sys
import time
import hashlib
import zipfile
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

MODULE_NAME     = "timeline_builder"
FLS_TIMEOUT     = 3600
MACTIME_TIMEOUT = 1800
SESSION_GAP_H   = 4    # hours gap that starts a new session


def _detect_offset(analysis_path: Path, logger: logging.Logger) -> int:
    """Detect NTFS partition start sector via mmls, then fls probe. Never hardcode."""
    _sudo = []

    for table_type in ("dos", "gpt"):
        try:
            rc, out, _ = _run_subprocess(
                _sudo + ["mmls", "-t", table_type, str(analysis_path)],
                timeout=30, logger=logger,
            )
            if rc == 0 and out:
                for line in out.splitlines():
                    if re.search(r"NTFS|Basic data", line, re.IGNORECASE):
                        m = re.search(r"\b(\d{4,})\b", line)
                        if m:
                            logger.info("[TIMELINE] mmls %s offset: %s", table_type, m.group(1))
                            return int(m.group(1))
                for line in out.splitlines():
                    m = re.search(r"^\s*\d+:\s+\d+:\d+\s+(\d+)", line)
                    if m:
                        return int(m.group(1))
        except Exception as exc:
            logger.debug("[TIMELINE] mmls %s: %s", table_type, exc)

    for candidate in (2048, 63, 64, 0):
        try:
            off = ["-o", str(candidate)] if candidate > 0 else []
            rc, out, _ = _run_subprocess(
                _sudo + ["fls"] + off + [str(analysis_path)],
                timeout=10, logger=logger,
            )
            if rc == 0 and out.strip():
                logger.info("[TIMELINE] fls probe offset: %d", candidate)
                return candidate
        except Exception:
            pass

    logger.warning("[TIMELINE] Could not detect offset — defaulting to 0")
    return 0


def _ingest_registry_timestamps(output_root: Path) -> list[dict]:
    """Load UserAssist last_run times and SAM account creation times from registry module output."""
    events: list[dict] = []
    manifest_path = output_root / "windows_registry_analyzer" / "registry_manifest.json"
    if not manifest_path.exists():
        return events
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8", errors="replace"))
        results = data.get("results", {})

        for uname, ua_data in results.get("userassist", {}).items():
            if not isinstance(ua_data, dict):
                continue
            for decoded_name, info in ua_data.items():
                if not isinstance(info, dict):
                    continue
                lr = info.get("last_run")
                if lr:
                    events.append({
                        "timestamp": lr,
                        "event":     f"Program executed: {Path(decoded_name).name[:60]}",
                        "source":    f"Registry/UserAssist (user: {uname})",
                        "severity":  "INFO",
                        "run_count": info.get("run_count", 0),
                    })

        for acc in results.get("user_accounts", []):
            ct = acc.get("creation_time")
            if ct:
                events.append({
                    "timestamp": ct,
                    "event":     f"User account created: {acc.get('username','?')}",
                    "source":    "Registry/SAM",
                    "severity":  "INFO",
                })
    except Exception:
        pass
    return events


def _ingest_email_timestamps(output_root: Path) -> list[dict]:
    """Load email subjects from email module manifest (date headers not always parseable)."""
    events: list[dict] = []
    manifest_path = output_root / "email_communications_analyzer" / "email_manifest.json"
    if not manifest_path.exists():
        return events
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8", errors="replace"))
        for summary in data.get("emails_summary", []):
            for subj in summary.get("subjects", []):
                if subj:
                    events.append({
                        "timestamp": "",
                        "event":     f"Email: {subj[:80]}",
                        "source":    "Email archive",
                        "severity":  "INFO",
                    })
    except Exception:
        pass
    return events





def _ingest_archive_metadata_timestamps(config: dict) -> list[dict]:
    """Extract deterministic ZIP member timestamps from unique evidence byte streams.

    ZIP timestamps have DOS/local-time precision and no timezone.  Each archive is
    hashed and aliases are collapsed; a single semantic event is emitted for each
    unique archive/timestamp combination while preserving member and path aliases.
    This is generic evidence parsing and never relies on fixture names or expected
    values.
    """
    ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
    roots: list[Path] = []
    for key in ("extracted_files_dir", "deleted_files_dir", "mounted_fs_root"):
        value = ws.get(key)
        if value:
            candidate = Path(value)
            if candidate.is_dir() and candidate not in roots:
                roots.append(candidate)
    events_by_key: dict[tuple[str, str], dict] = {}
    seen_hash_paths: dict[str, list[str]] = {}
    for root in roots:
        for path in sorted(p for p in root.rglob("*") if p.is_file()):
            try:
                if path.stat().st_size < 22:
                    continue
                with path.open("rb") as handle:
                    if handle.read(4) not in {b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"}:
                        continue
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                seen_hash_paths.setdefault(digest, []).append(str(path))
                with zipfile.ZipFile(path) as archive:
                    by_time: dict[tuple[int, int, int, int, int, int], list[str]] = {}
                    for member in archive.infolist():
                        if member.date_time and member.date_time[0] >= 1980:
                            by_time.setdefault(tuple(member.date_time), []).append(member.filename)
                    for parts, members in by_time.items():
                        dt = datetime(*parts, tzinfo=timezone.utc)
                        timestamp = dt.isoformat().replace("+00:00", "Z")
                        key = (digest, timestamp)
                        row = events_by_key.get(key)
                        if row is None:
                            row = {
                                "timestamp": timestamp,
                                "event_type": "ARCHIVE_ENTRY_MODIFIED",
                                "event": "ARCHIVE_ENTRY_MODIFIED",
                                "timestamp_meaning": "ZIP member DOS/local timestamp; timezone not stored",
                                "source": "ZIP central-directory metadata",
                                "responsible_module": "timeline_builder",
                                "source_artifact": str(path),
                                "source_hash": digest,
                                "source_locator": "ZIP central directory",
                                "semantic_object": f"sha256:{digest}",
                                "details": f"Archive member metadata records {len(members)} member(s) at {timestamp}; timezone is not encoded by ZIP.",
                                "severity": "INFO",
                                "source_aliases": [],
                                "member_names": sorted(members),
                            }
                            events_by_key[key] = row
                        else:
                            row["member_names"] = sorted(set(row.get("member_names", [])) | set(members))
            except (OSError, zipfile.BadZipFile, RuntimeError, ValueError):
                continue
    for (digest, _), row in events_by_key.items():
        paths = sorted(set(seen_hash_paths.get(digest, [])))
        if paths:
            row["source_artifact"] = paths[0]
            row["source_aliases"] = paths[1:]
        row["details"] = (
            f"Archive central-directory metadata records {len(row.get('member_names', []))} unique member(s); "
            f"{len(paths)} physical path occurrence(s); ZIP timezone is not stored."
        )
    return list(events_by_key.values())


def _ingest_native_filesystem_timestamps(config: dict) -> list[dict]:
    """Load source filesystem timestamps from the native filesystem manifest.

    These values are parsed from the evidence filesystem metadata.  Host-copy
    timestamps of extracted files are never used.
    """
    ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
    root_value = ws.get("extracted_files_dir") or ws.get("mounted_fs_root")
    if not root_value:
        return []
    manifest = Path(root_value).parent / "native_filesystem_manifest.json"
    if not manifest.is_file():
        return []
    try:
        data = json.loads(manifest.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return []
    events: list[dict] = []
    for entry in data.get("files", []):
        if not isinstance(entry, dict):
            continue
        path = str(entry.get("path") or entry.get("name") or "")
        state = "deleted " if entry.get("deleted") else ""
        for key, label in (("created", "created"), ("modified", "modified"), ("accessed", "accessed")):
            value = entry.get(key)
            if not value:
                continue
            events.append({
                "timestamp": str(value),
                "event": f"Filesystem {label}: {state}{path}",
                "source": "native filesystem metadata",
                "severity": "INFO",
            })
    return events



_TIMESTAMP_KEYS = {
    "timestamp", "datetime", "date", "created", "modified", "accessed",
    "creation_time", "modification_time", "last_access", "last_visit_time",
    "visit_time", "start_time", "end_time", "download_start", "download_end",
    "gps_datetime", "message_time", "sent_time", "received_time",
    "frame.time", "date_sent", "timestamp_ms", "timestamp_ns",
    "last_access_time", "last_accessed", "created_at", "modified_at",
    "creation_date", "modification_date", "date_time_original",
    "acquisition_time", "acquired_at", "system_time",
    "zdate", "message_date", "message_timestamp", "capture_time",
    "media_create_date", "media_modify_date", "zip_entry_mtime",
}

_TIMESTAMP_KEY_COMPACT = {re.sub(r"[^a-z0-9]", "", key.casefold()) for key in _TIMESTAMP_KEYS}
_TIMESTAMP_KEY_COMPACT.update({
    "creationdate", "moddate", "datetimeoriginal", "lastvisittime", "datesent",
    "zdate", "messagedate", "messagetimestamp", "capturetime",
    "mediacreatedate", "mediamodifydate", "zipentrymtime",
})

def _is_timestamp_key(key: Any) -> bool:
    return re.sub(r"[^a-z0-9]", "", str(key).casefold()) in _TIMESTAMP_KEY_COMPACT

def _normalise_timestamp_value(key: str, value: Any, source_path: Path) -> str:
    """Convert an explicitly timestamp-labelled value to UTC ISO-8601.

    Numeric epochs are accepted only under timestamp-labelled keys and are
    selected by non-overlapping magnitude plus source/key context.  This avoids
    treating arbitrary large numbers as dates.
    """
    if isinstance(value, str):
        text = value.strip()
        # SQLite/JSON exports frequently serialise numeric epochs as strings.
        # Convert only an entirely numeric value under an explicitly timestamp-
        # labelled field, then apply the same context-bounded epoch rules below.
        if re.fullmatch(r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)", text):
            try:
                value = float(text)
            except ValueError:
                return ""
        else:
            pdf_match = re.fullmatch(
            r"D:(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(?:([+-])(\d{2})'?((?:\d{2})?)'?)?",
                text, re.IGNORECASE,
            )
            if pdf_match:
                year, month, day, hour, minute, second = map(int, pdf_match.groups()[:6])
                sign, off_h, off_m = pdf_match.group(7), pdf_match.group(8), pdf_match.group(9)
                offset = timedelta(0)
                if sign and off_h:
                    offset = timedelta(hours=int(off_h), minutes=int(off_m or 0))
                    if sign == "-":
                        offset = -offset
                try:
                    return datetime(year, month, day, hour, minute, second, tzinfo=timezone(offset)).astimezone(timezone.utc).isoformat()
                except ValueError:
                    return ""
            parsed = _parse_timestamp(text)
            if parsed > 0:
                try:
                    return datetime.fromtimestamp(parsed, tz=timezone.utc).isoformat()
                except (OverflowError, OSError, ValueError):
                    return text
            return ""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return ""
    number = float(value)
    key_l = key.casefold()
    source_l = str(source_path).replace("\\", "/").casefold()
    try:
        # Apple absolute nanoseconds since 2001-01-01.
        if 1e17 <= number <= 2e18 and ("ios" in source_l or key_l == "date"):
            epoch = number / 1e9 + 978307200.0
        # Chromium/WebKit microseconds since 1601-01-01.
        elif 1e15 <= number <= 3e16 and key_l in {
            "last_visit_time", "visit_time", "start_time", "end_time",
            "last_access_time", "download_start", "download_end",
        }:
            epoch = number / 1e6 - 11644473600.0
        # Unix microseconds.
        elif 1e14 <= number < 1e16:
            epoch = number / 1e6
        # Unix milliseconds.
        elif 1e11 <= number < 1e14:
            epoch = number / 1e3
        # Apple absolute seconds, limited to explicitly iOS records.
        elif 1e8 <= number < 1e9 and "ios" in source_l:
            epoch = number + 978307200.0
        # Unix seconds.
        elif 1e9 <= number <= 4.2e9:
            epoch = number
        else:
            return ""
        dt = datetime.fromtimestamp(epoch, tz=timezone.utc)
        if not (1990 <= dt.year <= 2200):
            return ""
        return dt.isoformat()
    except (OverflowError, OSError, ValueError):
        return ""


_SEMANTIC_TIMESTAMP_MODULES = {
    "pcap_analyzer", "network_protocol_decoder", "dns_analyzer", "http_reconstructor",
    "browser_history_analyzer", "email_communications_analyzer", "mobile_analyzer",
    "document_analyzer", "exiftool_metadata", "windows_registry_analyzer",
}


def _semantic_module_for_path(path: Path) -> str:
    return next((part for part in reversed(path.parts) if part in _SEMANTIC_TIMESTAMP_MODULES), "")


def _source_artifact(metadata: dict[str, Any], record: dict[str, Any]) -> str:
    return str(
        metadata.get("provenance_source_path") or metadata.get("file_path") or
        metadata.get("source_file") or metadata.get("database") or
        metadata.get("pcap_file") or record.get("evidence_path") or ""
    )


def _source_hash(metadata: dict[str, Any]) -> str:
    for key in (
        "source_hash", "file_sha256", "database_sha256", "store_sha256",
        "source_sha256", "pcap_sha256", "sha256",
    ):
        value = metadata.get(key)
        if value:
            return str(value)
    return ""


def _event_row(
    *, timestamp: Any, timestamp_key: str, event_type: str,
    module_name: str, finding_id: str, metadata: dict[str, Any],
    source_artifact: str, source_hash: str = "", source_locator: str = "",
    semantic_object: str = "", details: str = "", severity: str = "INFO",
) -> dict[str, Any] | None:
    timestamp_context = str(metadata.get("timestamp_platform") or "")
    normalised = _normalise_timestamp_value(
        timestamp_key, timestamp,
        Path((timestamp_context + ":" if timestamp_context else "") + (source_artifact or module_name)),
    )
    if not normalised:
        return None
    return {
        "timestamp": normalised,
        "original_timestamp": timestamp,
        "event_type": event_type,
        "event": event_type,
        "timestamp_meaning": timestamp_key,
        "source": module_name,
        "responsible_module": module_name,
        "source_artifact": source_artifact,
        "source_hash": source_hash,
        "source_locator": source_locator,
        "source_finding_id": finding_id,
        "primary_finding_reference": finding_id,
        "semantic_object": semantic_object,
        "details": details,
        "severity": severity,
    }


def _ingest_canonical_finding_timestamps(config: dict) -> list[dict]:
    """Create examiner-semantic events from accepted canonical findings only.

    This is intentionally schema-aware. It does not recursively turn every field
    named ``date`` or ``timestamp`` into an event. A timestamp contributes to the
    examiner chronology only when the responsible parser assigned it a defined
    forensic meaning (DNS request/response, HTTP request/response, browser visit,
    download lifecycle, message, or registry event). The complete parser output
    remains available in the technical ledger.
    """
    ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
    canonical = ws.get("canonical_findings_by_module") or {}
    events: list[dict] = []

    def add(row: dict[str, Any] | None) -> None:
        if row:
            events.append(row)

    for module_name, findings in canonical.items():
        module_name = str(module_name)
        if module_name not in _SEMANTIC_TIMESTAMP_MODULES:
            continue
        for record in findings or []:
            metadata = dict(record.get("metadata") or {})
            finding_id = str(record.get("finding_id") or "")
            finding_type = str(record.get("finding_type") or "")
            description = str(record.get("description") or finding_type)
            severity = str(record.get("severity") or "INFO")
            source_artifact = _source_artifact(metadata, record)
            source_hash = _source_hash(metadata)

            if module_name == "network_protocol_decoder" and finding_type == "NETWORK_PROTOCOL_RECORD":
                records = metadata.get("records") or []
                if isinstance(records, dict):
                    records = [row for values in records.values() if isinstance(values, list) for row in values]
                if not isinstance(records, list):
                    records = []
                for index, item in enumerate(records):
                    if not isinstance(item, dict):
                        continue
                    semantic = str(item.get("semantic_event") or item.get("event") or "NETWORK_FRAME").upper().replace(" ", "_").replace("-", "_")
                    if semantic not in {"TCP_SYN", "TCP_SYN_ACK", "TCP_ACK", "DNS_REQUEST", "DNS_RESPONSE", "HTTP_PACKET", "NETWORK_FRAME"}:
                        semantic = "NETWORK_FRAME"
                    timestamp = item.get("timestamp") or item.get("frame.time") or item.get("frame.time_epoch")
                    frame = item.get("frame_number") or item.get("frame.number") or index + 1
                    flow = f"{item.get('ip_src') or item.get('ip.src','')}:{item.get('src_port') or item.get('tcp.srcport') or item.get('udp.srcport','')}->{item.get('ip_dst') or item.get('ip.dst','')}:{item.get('dst_port') or item.get('tcp.dstport') or item.get('udp.dstport','')}"
                    item_source = str(item.get("capture_path") or metadata.get("pcap_file") or source_artifact)
                    add(_event_row(
                        timestamp=timestamp, timestamp_key="timestamp", event_type=semantic,
                        module_name=module_name, finding_id=finding_id, metadata=metadata,
                        source_artifact=item_source, source_hash=str(item.get("capture_sha256") or source_hash),
                        source_locator=f"frame={frame};offset={item.get('capture_offset','')}",
                        semantic_object=flow, details=f"{semantic.replace('_', ' ')} {flow}".strip(), severity=severity,
                    ))
                continue

            if module_name == "dns_analyzer" and finding_type in {"DNS_QUERY_RECORD", "DNS_RESPONSE_RECORD", "DNS_RECORD"}:
                response = str(metadata.get("record_type") or "").casefold() == "response" or str(metadata.get("dns.flags.response") or "0") in {"1", "true", "True"}
                event_type = "DNS_RESPONSE" if response else "DNS_QUERY"
                query = str(metadata.get("query_name") or metadata.get("dns.qry.name") or "")
                answers = metadata.get("answers") or []
                if not isinstance(answers, list):
                    answers = [answers]
                locator = f"packet={metadata.get('frame.number','')};txid={metadata.get('transaction_id') or metadata.get('dns.id','')}"
                detail = f"{query}" + (f" -> {', '.join(map(str, answers))}" if answers else "")
                add(_event_row(
                    timestamp=metadata.get("frame.time"), timestamp_key="frame.time",
                    event_type=event_type, module_name=module_name, finding_id=finding_id,
                    metadata=metadata, source_artifact=source_artifact, source_hash=source_hash,
                    source_locator=locator, semantic_object=query, details=detail, severity=severity,
                ))
                continue

            if module_name == "http_reconstructor" and finding_type == "HTTP_TRANSACTION":
                method = str(metadata.get("http.request.method") or "").upper()
                if str(metadata.get("direction") or "").casefold() == "response" or metadata.get("http.response.code"):
                    event_type = "HTTP_RESPONSE"
                    semantic = str(metadata.get("http.response.code") or "response")
                else:
                    event_type = f"HTTP_REQUEST_{method}" if method else "HTTP_REQUEST"
                    semantic = f"{metadata.get('http.host','')}{metadata.get('http.request.uri','')}"
                locator = f"packet={metadata.get('frame.number','')};offset={metadata.get('capture_offset','')}"
                add(_event_row(
                    timestamp=metadata.get("frame.time"), timestamp_key="frame.time",
                    event_type=event_type, module_name=module_name, finding_id=finding_id,
                    metadata=metadata, source_artifact=source_artifact, source_hash=source_hash,
                    source_locator=locator, semantic_object=semantic, details=description,
                    severity=severity,
                ))
                continue

            if module_name == "browser_history_analyzer":
                if finding_type == "BROWSER_VISIT_RECORD":
                    ts = metadata.get("visit_time") or metadata.get("last_visit_time")
                    add(_event_row(
                        timestamp=ts, timestamp_key="visit_time", event_type="BROWSER_VISIT",
                        module_name=module_name, finding_id=finding_id, metadata=metadata,
                        source_artifact=source_artifact, source_hash=source_hash,
                        source_locator=f"table={metadata.get('table','visits+urls')};rowid={metadata.get('rowid','')}",
                        semantic_object=str(metadata.get("url") or ""), details=description, severity=severity,
                    ))
                elif finding_type == "BROWSER_DOWNLOAD_RECORD":
                    locator = f"table={metadata.get('table','downloads')};rowid={metadata.get('rowid','')}"
                    semantic = str(metadata.get("url") or metadata.get("target_path") or metadata.get("current_path") or "")
                    for key, etype in (
                        ("start_time", "DOWNLOAD_STARTED"),
                        ("end_time", "DOWNLOAD_COMPLETED"),
                        ("last_access_time", "DOWNLOAD_LAST_ACCESSED"),
                    ):
                        add(_event_row(
                            timestamp=metadata.get(key), timestamp_key=key, event_type=etype,
                            module_name=module_name, finding_id=finding_id, metadata=metadata,
                            source_artifact=source_artifact, source_hash=source_hash,
                            source_locator=locator, semantic_object=semantic, details=description,
                            severity=severity,
                        ))
                continue

            if module_name == "email_communications_analyzer" and finding_type == "EMAIL_MESSAGE_RECORD":
                semantic = str(metadata.get("subject") or metadata.get("message_id") or metadata.get("message_index") or "")
                add(_event_row(
                    timestamp=metadata.get("date"), timestamp_key="date", event_type="EMAIL_MESSAGE",
                    module_name=module_name, finding_id=finding_id, metadata=metadata,
                    source_artifact=source_artifact, source_hash=source_hash,
                    source_locator=f"message_index={metadata.get('message_index','')}",
                    semantic_object=semantic, details=description, severity=severity,
                ))
                continue

            if module_name == "mobile_analyzer" and finding_type.startswith("MOBILE_"):
                records = metadata.get("source_records") or metadata.get("sample") or []
                if not isinstance(records, list):
                    records = []
                platform = str(metadata.get("device_type") or metadata.get("mobile_platform") or "mobile").upper()
                for index, item in enumerate(records):
                    if not isinstance(item, dict):
                        continue
                    item_source = str(item.get("_source_database") or item.get("source_file") or source_artifact)
                    locator_value = item.get("ROWID") or item.get("_id") or item.get("id") or item.get("rowid") or index
                    locator = f"table={item.get('_source_table','')};row={locator_value}"
                    if finding_type == "MOBILE_BROWSER_HISTORY":
                        add(_event_row(
                            timestamp=item.get("visit_time") or item.get("last_visit_time"), timestamp_key="last_visit_time",
                            event_type="BROWSER_VISIT", module_name=module_name, finding_id=finding_id,
                            metadata=metadata, source_artifact=item_source, source_hash=source_hash,
                            source_locator=locator, semantic_object=str(item.get("url") or ""),
                            details=f"{platform} browser visit: {item.get('url','')}", severity=severity,
                        ))
                    elif finding_type == "MOBILE_BROWSER_DOWNLOAD":
                        semantic = str(item.get("url") or item.get("target_path") or item.get("path") or "")
                        for key, etype in (("start_time", "DOWNLOAD_STARTED"), ("end_time", "DOWNLOAD_COMPLETED"), ("last_access_time", "DOWNLOAD_LAST_ACCESSED")):
                            add(_event_row(
                                timestamp=item.get(key), timestamp_key=key, event_type=etype,
                                module_name=module_name, finding_id=finding_id, metadata=metadata,
                                source_artifact=item_source, source_hash=source_hash, source_locator=locator,
                                semantic_object=semantic, details=f"{platform} download: {semantic}", severity=severity,
                            ))
                    elif finding_type in {"MOBILE_SMS", "MOBILE_CHAT"}:
                        event_type = "IOS_MESSAGE" if platform == "IOS" else ("ANDROID_SMS" if finding_type == "MOBILE_SMS" else "ANDROID_CHAT")
                        timestamp_key = next((key for key in (
                            "date", "ZDATE", "zdate", "timestamp", "message_timestamp",
                            "message_date", "date_sent", "sent_time", "created_at",
                        ) if item.get(key) not in (None, "")), "date_sent")
                        semantic = str(item.get("guid") or item.get("body") or item.get("text") or locator_value)
                        mobile_metadata = dict(metadata)
                        mobile_metadata["timestamp_platform"] = platform.casefold()
                        add(_event_row(
                            timestamp=item.get(timestamp_key), timestamp_key=timestamp_key,
                            event_type=event_type, module_name=module_name, finding_id=finding_id,
                            metadata=mobile_metadata, source_artifact=item_source, source_hash=source_hash,
                            source_locator=locator, semantic_object=semantic,
                            details=str(item.get("body") or item.get("text") or description), severity=severity,
                        ))
                continue

            if module_name == "windows_registry_analyzer":
                for key in ("last_run", "creation_time", "last_write_time"):
                    if metadata.get(key):
                        add(_event_row(
                            timestamp=metadata.get(key), timestamp_key=key, event_type="REGISTRY_EVENT",
                            module_name=module_name, finding_id=finding_id, metadata=metadata,
                            source_artifact=source_artifact, source_hash=source_hash,
                            source_locator=str(metadata.get("key_path") or metadata.get("source_offset") or ""),
                            semantic_object=str(metadata.get("value_name") or metadata.get("key_path") or finding_type),
                            details=description, severity=severity,
                        ))
                continue

            if module_name in {"document_analyzer", "exiftool_metadata"}:
                # Only parser-labelled semantic document/media times are used.
                metadata_field = str(metadata.get("metadata_field") or metadata.get("field") or "")
                metadata_value = metadata.get("metadata_value") if "metadata_value" in metadata else metadata.get("value")
                compact_field = re.sub(r"[^a-z0-9]", "", metadata_field.casefold())
                field_event = {
                    "creationdate": "FILE_CREATED", "createdate": "FILE_CREATED", "created": "FILE_CREATED",
                    "moddate": "FILE_MODIFIED", "modifydate": "FILE_MODIFIED", "modified": "FILE_MODIFIED",
                    "datetimeoriginal": "MEDIA_CAPTURED", "mediacreatedate": "MEDIA_CAPTURED",
                    "gpsdatetime": "MEDIA_CAPTURED", "zipentrymtime": "ARCHIVE_ENTRY_MODIFIED",
                }.get(compact_field)
                if field_event and metadata_value not in (None, ""):
                    add(_event_row(
                        timestamp=metadata_value, timestamp_key=metadata_field or "timestamp",
                        event_type=field_event, module_name=module_name, finding_id=finding_id,
                        metadata=metadata, source_artifact=source_artifact, source_hash=source_hash,
                        source_locator=f"metadata_field={metadata_field}", semantic_object=source_artifact,
                        details=description, severity=severity,
                    ))
                for key, event_type in (
                    ("creation_time", "FILE_CREATED"), ("created", "FILE_CREATED"),
                    ("modification_time", "FILE_MODIFIED"), ("modified", "FILE_MODIFIED"),
                    ("date_time_original", "MEDIA_CAPTURED"), ("gps_datetime", "MEDIA_CAPTURED"),
                ):
                    if metadata.get(key):
                        add(_event_row(
                            timestamp=metadata.get(key), timestamp_key=key, event_type=event_type,
                            module_name=module_name, finding_id=finding_id, metadata=metadata,
                            source_artifact=source_artifact, source_hash=source_hash,
                            source_locator=f"metadata_field={key}", semantic_object=source_artifact,
                            details=description, severity=severity,
                        ))
    return events

def _ingest_completed_module_timestamps(output_root: Path) -> list[dict]:
    """Collect exact timestamp-labelled fields from completed module JSON.

    The original value, JSON pointer and source module are retained. Duplicate
    wrapper copies collapse by normalised time, module, key and record hint.
    """
    events: list[dict] = []
    seen: set[tuple[str, str, str, str]] = set()
    for path in sorted(output_root.rglob("*.json")):
        if path.name == "module_result.json" or path.name == "timeline_manifest.json":
            continue
        module_name = _semantic_module_for_path(path)
        if not module_name:
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        def walk(value: Any, pointer: str = "$") -> None:
            if isinstance(value, dict):
                for key, child in value.items():
                    key_l = str(key).casefold()
                    child_pointer = f"{pointer}.{key}"
                    if _is_timestamp_key(key_l):
                        normalised = _normalise_timestamp_value(key_l, child, path)
                        if normalised:
                            record_hint = ""
                            for hint_key in (
                                "url", "http.request.uri", "http.host", "dns.qry.name",
                                "path", "file", "source_file", "subject", "event",
                                "message", "body", "text", "domain", "process", "name",
                                "title", "address", "sender", "recipient",
                            ):
                                if value.get(hint_key) not in (None, ""):
                                    record_hint = str(value.get(hint_key))[:300]
                                    break
                            identity = (normalised, module_name, key_l, record_hint)
                            if identity not in seen:
                                seen.add(identity)
                                original_source = ""
                                for source_key in (
                                    "_source_database", "source_database", "evidence_path",
                                    "provenance_source_path", "source_file", "file_path",
                                ):
                                    candidate = value.get(source_key)
                                    if candidate and Path(str(candidate)).is_file():
                                        original_source = str(candidate)
                                        break
                                events.append({
                                    "timestamp": normalised,
                                    "original_timestamp": child,
                                    "event": f"{key}: {record_hint or child_pointer}",
                                    "source": module_name,
                                    "source_artifact": original_source or str(path),
                                    "derived_artifact_path": str(path),
                                    "source_json_pointer": child_pointer,
                                    "severity": "INFO",
                                })
                    walk(child, child_pointer)
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    walk(child, f"{pointer}[{index}]")
        walk(data)
    return events


def _ingest_completed_module_table_timestamps(output_root: Path) -> list[dict]:
    """Read timestamp-labelled columns from retained CSV/TSV module output."""
    events: list[dict] = []
    seen: set[tuple[str, str, str]] = set()
    for path in sorted(list(output_root.rglob("*.csv")) + list(output_root.rglob("*.tsv"))):
        module_name = _semantic_module_for_path(path)
        if not module_name:
            continue
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        try:
            with path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
                reader = csv.DictReader(handle, delimiter=delimiter)
                for row_index, row in enumerate(reader):
                    if not row:
                        continue
                    record_hint = ""
                    for hint_key in (
                        "url", "http.request.uri", "http.host", "dns.qry.name",
                        "path", "file", "source_file", "subject", "event", "message",
                        "body", "text", "title", "address", "sender", "recipient",
                    ):
                        if row.get(hint_key) not in (None, ""):
                            record_hint = str(row.get(hint_key))[:300]
                            break
                    for key, value in row.items():
                        key_l = str(key).casefold()
                        if not _is_timestamp_key(key_l):
                            continue
                        # CSV readers return strings; parse numeric epochs before
                        # falling back to textual timestamps.
                        raw: Any = value
                        if isinstance(value, str) and re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value.strip()):
                            try:
                                raw = float(value) if "." in value else int(value)
                            except ValueError:
                                raw = value
                        normalised = _normalise_timestamp_value(key_l, raw, path)
                        if not normalised:
                            continue
                        identity = (normalised, key_l, record_hint)
                        if identity in seen:
                            continue
                        seen.add(identity)
                        original_source = ""
                        for source_key in (
                            "_source_database", "source_database", "evidence_path",
                            "provenance_source_path", "source_file", "file_path",
                        ):
                            candidate = row.get(source_key)
                            if candidate and Path(str(candidate)).is_file():
                                original_source = str(candidate)
                                break
                        events.append({
                            "timestamp": normalised,
                            "original_timestamp": value,
                            "event": f"{key}: {record_hint or f'row {row_index + 2}'}",
                            "source": module_name,
                            "source_artifact": original_source or str(path),
                            "derived_artifact_path": str(path),
                            "source_row": row_index + 2,
                            "severity": "INFO",
                        })
        except (OSError, csv.Error):
            continue
    return events


def _deduplicate_timeline_events(events: list[dict]) -> list[dict]:
    """Collapse exact semantic duplicates while retaining source aliases."""
    merged: dict[tuple[str, str, str], dict] = {}
    for event in events:
        timestamp = str(event.get("timestamp") or "")
        event_text = re.sub(r"\s+", " ", str(event.get("event") or "")).strip()
        # Native filesystem events are path-specific; module events are
        # de-duplicated by timestamp/key+record hint across copied wrappers.
        source = str(event.get("source") or "")
        domain = source if source in {"mactime/fls", "native filesystem metadata"} else "semantic"
        if domain == "semantic" and ":" in event_text:
            prefix, remainder = event_text.split(":", 1)
            if prefix.strip().casefold() in _TIMESTAMP_KEYS:
                # Different timestamp columns (for example Android ``date``
                # and ``date_sent``) can encode the same retained event time.
                # Collapse only when the normalised timestamp and record hint
                # are identical; preserve the alternate source as an alias.
                event_text = remainder.strip()
        key = (timestamp, event_text, domain)
        current = merged.get(key)
        if current is None:
            item = dict(event)
            item["source_aliases"] = []
            merged[key] = item
        else:
            alias = str(event.get("source_artifact") or source)
            if alias and alias != str(current.get("source_artifact") or current.get("source") or ""):
                current.setdefault("source_aliases", []).append(alias)
    for item in merged.values():
        item["source_aliases"] = sorted(set(item.get("source_aliases") or []))
    return list(merged.values())


def _find_acquisition_timestamp(output_root: Path) -> str:
    """Return the earliest explicit acquisition/system time from intake metadata."""
    candidates: list[str] = []
    for path in sorted(output_root.rglob("*.json")):
        if "ewf_metadata" not in str(path) and "evidence_validator" not in str(path):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        def walk(value: Any, key_hint: str = "", parent_hint: str = "") -> None:
            if isinstance(value, dict):
                for key, child in value.items():
                    walk(child, str(key).casefold(), key_hint)
            elif isinstance(value, list):
                for child in value:
                    walk(child, key_hint, parent_hint)
            else:
                explicit = any(token in key_hint for token in ("acquisition", "acquired", "system_date", "creation_date"))
                raw_epoch = parent_hint == "raw_values" and key_hint in {"m", "u"}
                if not (explicit or raw_epoch):
                    return
                raw: Any = value
                if isinstance(value, str) and re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value.strip()):
                    raw = float(value) if "." in value else int(value)
                normalised = _normalise_timestamp_value("timestamp", raw, path)
                if normalised:
                    candidates.append(normalised)
                elif isinstance(value, str) and _parse_timestamp(value) > 0:
                    candidates.append(datetime.fromtimestamp(_parse_timestamp(value), tz=timezone.utc).isoformat())
        walk(data)
    return min(candidates, key=_parse_timestamp) if candidates else ""


def _parse_mactime_csv(csv_text: str) -> list[dict]:
    """Parse mactime -d CSV output into event dicts."""
    events: list[dict] = []
    for line in csv_text.splitlines():
        line = line.strip()
        if not line or line.startswith("Date,") or line.startswith("Date "):
            continue
        # mactime -d CSV: Date,Size,Type,Mode,UID,GID,Meta,File Name (8 columns)
        # split on 7 commas maximum so File Name (col 8) is intact even with commas in path
        parts = line.split(",", 7)
        if len(parts) < 3:
            continue
        events.append({
            "timestamp": parts[0].strip(),
            "event":     parts[7].strip() if len(parts) > 7 else parts[-1].strip(),
            "size":      parts[1].strip() if len(parts) > 1 else "",
            "type":      parts[2].strip() if len(parts) > 2 else "",
            "source":    "mactime/fls",
            "severity":  "INFO",
        })
    return events


def _parse_timestamp(ts: str) -> float:
    """Parse retained timestamps to UTC epoch; return 0 for unsupported values."""
    if not ts:
        return 0.0
    text = str(ts).strip()
    # Common forensic-tool rendering.  Treat an explicit UTC suffix as UTC,
    # never as local time.
    text = re.sub(r"\s+UTC$", "+00:00", text, flags=re.IGNORECASE)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except Exception:
        pass
    try:
        parsed = parsedate_to_datetime(text)
        if parsed is not None:
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.timestamp()
    except Exception:
        pass
    for fmt in (
        "%a %b %d %H:%M:%S %Y", "%m/%d/%Y %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S",
        "%Y:%m:%d %H:%M:%S",
    ):
        try:
            return datetime.strptime(text[:24], fmt).replace(tzinfo=timezone.utc).timestamp()
        except Exception:
            pass
    return 0.0


def _is_date_after_acquisition(event_timestamp: str, acquisition_timestamp: str) -> bool:
    """Return whether an event UTC date is later than the acquisition UTC date.

    The comparison deliberately uses calendar dates when the evidence metadata
    supplies an acquisition start but no completion time.  Same-day ordering is
    retained in the timeline but is not promoted as a future-dated anomaly.
    """
    event_epoch = _parse_timestamp(event_timestamp)
    acquisition_epoch = _parse_timestamp(acquisition_timestamp)
    if event_epoch <= 0 or acquisition_epoch <= 0:
        return False
    event_dt = datetime.fromtimestamp(event_epoch, tz=timezone.utc)
    acquisition_dt = datetime.fromtimestamp(acquisition_epoch, tz=timezone.utc)
    return event_dt.date() > acquisition_dt.date()


def _group_sessions(events: list[dict]) -> list[list[dict]]:
    """Group events into sessions where adjacent events are < SESSION_GAP_H hours apart."""
    # Only group events with parseable timestamps; events with ts=0.0 are placed in their own group
    parseable = [e for e in events if _parse_timestamp(e["timestamp"]) > 0.0]
    if not parseable:
        return [[e] for e in events] if events else []
    gap = timedelta(hours=SESSION_GAP_H).total_seconds()
    sessions: list[list[dict]] = []
    current: list[dict] = [parseable[0]]
    for ev in parseable[1:]:
        prev_ts = _parse_timestamp(current[-1]["timestamp"])
        this_ts = _parse_timestamp(ev["timestamp"])
        if this_ts - prev_ts <= gap:
            current.append(ev)
        else:
            sessions.append(current)
            current = [ev]
    sessions.append(current)
    return sessions


_FORENSIC_TOOL_KW   = ["ftkimager", "encase", "wireshark", "autopsy", "dd.exe",
                        "secureclean", "ccleaner", "winhex"]
_FILE_DELETION_KW   = ["$recycle", "unalloc", "deleted", "recycled"]
_ARCHIVE_CREATION_KW = [".zip", ".7z", ".rar", ".tar", ".gz"]


def _is_antiforensic_session(session: list[dict]) -> bool:
    """Flag session as anti-forensic if it contains forensic tool + deletion + archive."""
    def _has_tool(session: list[dict]) -> bool:
        for ev in session:
            text = (ev.get("event", "") + " " + ev.get("source", "")).lower()
            for kw in _FORENSIC_TOOL_KW:
                if re.search(r'(?:^|[/\\ ])' + re.escape(kw) + r'(?:\.|[ ]|$)', text):
                    return True
        return False

    def _has_kw(kwlist: list[str]) -> bool:
        return any(
            any(kw in ev.get("event", "").lower() or kw in ev.get("source", "").lower()
                for kw in kwlist)
            for ev in session
        )

    return _has_tool(session) and _has_kw(_FILE_DELETION_KW) and _has_kw(_ARCHIVE_CREATION_KW)



def _semantic_label(event: dict) -> tuple[str, str]:
    """Return an examiner-facing event label and stable deduplication detail."""
    text = str(event.get("event") or "").strip()
    source = str(event.get("source") or "").strip()
    joined = f"{text} {source}".casefold()
    detail = text
    if "acquisition" in joined and ("header" in joined or "evidence" in joined):
        return "Evidence acquisition/header", detail
    if "dns" in joined:
        if any(token in joined for token in ("response", "answer", "resolved")):
            return "DNS response", detail
        return "DNS request", detail
    if "syn-ack" in joined or "syn ack" in joined:
        return "TCP SYN-ACK", detail
    if re.search(r"\btcp\b.*\bsyn\b", joined):
        return "TCP SYN", detail
    if re.search(r"\btcp\b.*\back\b", joined) or "three-way handshake" in joined:
        return "TCP ACK", detail
    if "http" in joined:
        if "post" in joined:
            return "HTTP POST", detail
        if "200" in joined or "response" in joined:
            return "HTTP 200 response", detail
        if "get" in joined:
            return "HTTP GET", detail
    if "browser" in joined or "history" in joined:
        if "download" in joined:
            if "end" in joined or "completed" in joined:
                return "Browser download completed", detail
            if "last access" in joined or "opened" in joined:
                return "Browser downloaded item accessed", detail
            return "Browser download started", detail
        if "visit" in joined or "url" in joined:
            return "Browser visit", detail
    if "email" in joined or "mailbox" in joined or "mbox" in joined:
        return "Email message", detail
    if "ios" in joined or ("sms.db" in joined and "android" not in joined):
        return "iOS-style message", detail
    if "android" in joined:
        if "sms" in joined:
            return "Android SMS", detail
        if "chat" in joined or "message" in joined:
            return "Android chat", detail
    if "sms" in joined:
        return "Mobile SMS", detail
    if "chat" in joined or "message" in joined:
        return "Mobile/chat message", detail
    if "pdf" in joined or "docx" in joined or "archive" in joined or "zip" in joined:
        return "Document/archive metadata", detail
    return text[:100] or "Evidence event", detail


def _event_object(event: dict, detail: str) -> str:
    for key in ("record_id", "message_id", "url", "query", "domain", "path", "source_artifact", "object", "filename"):
        value = event.get(key)
        if value not in (None, ""):
            return str(value).strip()
    # Preserve the most useful semantic object without module-specific counts.
    match = re.search(r"(?:https?://\S+|/[A-Za-z0-9_.%?=&/-]+|[A-Za-z0-9.-]+\.(?:invalid|test|example))", detail)
    return match.group(0).rstrip('.,;') if match else re.sub(r"\s+", " ", detail).strip()[:160]

def _build_examiner_timeline(events: list[dict]) -> list[dict]:
    """Build a concise semantic chronology without raw-field or wrapper rows.

    The deduplication identity deliberately excludes module name and extracted-copy
    path. The same evidence event may be represented by a native parser, a mobile
    wrapper and a copied database; those are aliases, not additional events.
    """
    filesystem = [e for e in events if str(e.get("source") or "") == "native filesystem metadata"]
    semantic = [e for e in events if e not in filesystem]
    concise: list[dict] = []
    if filesystem:
        precise = [e for e in filesystem if "T" in str(e.get("timestamp") or "")]
        selected = min(precise or filesystem, key=lambda e: _parse_timestamp(str(e.get("timestamp") or "")) or float("inf"))
        timestamps = {str(e.get("timestamp") or "") for e in filesystem}
        concise.append({
            "event_id": "filesystem-timestamp-summary",
            "timestamp": selected.get("timestamp", ""),
            "event_type": "FILESYSTEM_TIMESTAMP_SUMMARY",
            "event": "Filesystem timestamp summary",
            "timestamp_meaning": "filesystem directory-entry timestamps",
            "source": "filesystem_analyzer",
            "responsible_module": "filesystem_analyzer",
            "severity": "INFO",
            "details": f"{len(filesystem)} technical timestamp rows consolidated; {len(timestamps)} distinct stored values.",
            "source_artifact": "FAT32 directory records",
            "source_hash": "",
            "source_locator": "native_filesystem_manifest.json",
            "primary_finding_reference": "",
            "semantic_object": "FAT32 timestamp corpus",
            "duplicate_group_reference": "",
            "consolidated_event_count": len(filesystem),
            "source_aliases": [],
        })

    # Prefer the most specialised parser when the same timestamped occurrence
    # is also represented by a generic decoder or a byte-identical mobile copy.
    def _raw_family(item: dict) -> str:
        et = str(item.get("event_type") or "").upper()
        return {"DNS_QUERY": "DNS_REQUEST", "DNS_ANSWER": "DNS_RESPONSE"}.get(et, et)

    specialist_dns = {
        (str(item.get("timestamp") or "").replace("Z", "+00:00"), _raw_family(item))
        for item in semantic
        if str(item.get("responsible_module") or "").casefold() == "dns_analyzer"
    }
    specialist_http_times = {
        str(item.get("timestamp") or "").replace("Z", "+00:00")
        for item in semantic
        if str(item.get("responsible_module") or "").casefold() == "http_reconstructor"
    }
    specialist_browser = {
        (str(item.get("timestamp") or "").replace("Z", "+00:00"), _raw_family(item))
        for item in semantic
        if str(item.get("responsible_module") or "").casefold() == "browser_history_analyzer"
    }

    filtered_semantic: list[dict] = []
    for item in semantic:
        module = str(item.get("responsible_module") or item.get("source") or "").casefold()
        timestamp_key = str(item.get("timestamp") or "").replace("Z", "+00:00")
        family = _raw_family(item)
        if module == "network_protocol_decoder" and family in {"DNS_REQUEST", "DNS_RESPONSE"} and (timestamp_key, family) in specialist_dns:
            continue
        if module == "network_protocol_decoder" and family == "HTTP_PACKET" and timestamp_key in specialist_http_times:
            continue
        if module == "mobile_analyzer" and family in {"BROWSER_VISIT", "DOWNLOAD_STARTED", "DOWNLOAD_COMPLETED", "DOWNLOAD_LAST_ACCESSED"} and (timestamp_key, family) in specialist_browser:
            continue
        filtered_semantic.append(item)

    seen: dict[tuple[str, str, str], dict] = {}
    for event in filtered_semantic:
        timestamp = str(event.get("timestamp") or "").strip()
        explicit_type = str(event.get("event_type") or "").strip()
        legacy_label = ""
        if explicit_type:
            event_type = explicit_type.upper()
        else:
            legacy_label, _legacy_detail = _semantic_label(event)
            event_type = legacy_label.upper().replace(" ", "_")
        if not timestamp or not event_type:
            continue
        # Raw extraction field labels and generic wrapper rows are never examiner events.
        if event_type.rstrip(":") in {"TIMESTAMP", "DATE", "FRAME.TIME", "NETWORK_PROTOCOL_RECORD", "DNS_RECORD", "EVIDENCE_EVENT"}:
            continue
        semantic_object = re.sub(r"\s+", " ", str(event.get("semantic_object") or "")).strip()
        details = re.sub(r"\s+", " ", str(event.get("details") or event.get("event") or "")).strip()[:500]
        module = str(event.get("responsible_module") or event.get("source") or "").casefold()
        # Generic protocol-decoder rows are alternate representations when a
        # specialist DNS/HTTP parser emitted the same semantic occurrence.
        family_type = {
            "DNS_QUERY": "DNS_REQUEST",
            "DNS_REQUEST": "DNS_REQUEST",
            "DNS_RESPONSE": "DNS_RESPONSE",
            "DNS_ANSWER": "DNS_RESPONSE",
            "HTTP_PACKET": "HTTP_GENERIC",
        }.get(event_type, event_type)
        if family_type == "HTTP_GENERIC":
            lower = f"{semantic_object} {details}".casefold()
            family_type = "HTTP_POST" if "post" in lower else (
                "HTTP_200_RESPONSE" if "200" in lower or "response" in lower else (
                    "HTTP_GET" if "get" in lower else "HTTP_GENERIC"
                )
            )
        identity_object = semantic_object or details
        key = (timestamp.replace("Z", "+00:00"), family_type, identity_object.casefold())
        # family_type is used only for cross-parser deduplication.  Preserve the
        # specialist parser's exact semantic event type in the examiner output
        # (for example DNS_QUERY rather than rewriting it to DNS_REQUEST).
        current = seen.get(key)
        if current is not None:
            current["consolidated_event_count"] = int(current.get("consolidated_event_count", 1)) + 1
            alias = {
                "module": str(event.get("responsible_module") or event.get("source") or ""),
                "source_artifact": str(event.get("source_artifact") or ""),
                "source_locator": str(event.get("source_locator") or ""),
                "finding_id": str(event.get("source_finding_id") or event.get("primary_finding_reference") or ""),
            }
            if alias not in current.setdefault("source_aliases", []):
                current["source_aliases"].append(alias)
            continue

        severity = str(event.get("severity") or "INFO")
        displayed_type = event_type
        if _is_date_after_acquisition(timestamp, str(event.get("acquisition_timestamp") or "")):
            severity = "WARNING"
            displayed_type = "TIMESTAMP_ANOMALY"
            details = f"Stored {event_type} timestamp is after the acquisition date. {details}"
        stable_seed = "|".join(key)
        import hashlib
        event_id = "evt-" + hashlib.sha256(stable_seed.encode("utf-8", errors="replace")).hexdigest()[:16]
        row = {
            "event_id": event_id,
            "timestamp": timestamp,
            "event_type": displayed_type,
            "event": (legacy_label if legacy_label else displayed_type.replace("_", " ").title()),
            "timestamp_meaning": str(event.get("timestamp_meaning") or "event time"),
            "source": str(event.get("source") or "forensic parser"),
            "responsible_module": str(event.get("responsible_module") or event.get("source") or ""),
            "severity": severity,
            "details": details,
            "source_artifact": str(event.get("source_artifact") or ""),
            "source_hash": str(event.get("source_hash") or ""),
            "source_locator": str(event.get("source_locator") or ""),
            "primary_finding_reference": str(event.get("primary_finding_reference") or event.get("source_finding_id") or ""),
            "semantic_object": semantic_object,
            "duplicate_group_reference": "",
            "consolidated_event_count": 1,
            "source_aliases": [],
        }
        seen[key] = row
        concise.append(row)

    concise.sort(key=lambda e: (
        _parse_timestamp(str(e.get("timestamp") or "")),
        str(e.get("event_type") or ""),
        str(e.get("semantic_object") or ""),
    ))
    return concise

def _write_timeline_csv(path: Path, events: list[dict]) -> None:
    """Write a deterministic CSV when the native timestamp source is authoritative.

    This is a true fallback, not fabricated output: every row comes from timestamps
    parsed from the evidence filesystem metadata or another completed forensic module.
    """
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["event_id", "timestamp", "event_type", "event", "timestamp_meaning", "source", "responsible_module", "severity", "details", "source_artifact", "source_hash", "source_locator", "primary_finding_reference", "semantic_object", "duplicate_group_reference", "consolidated_event_count", "source_aliases"],
            extrasaction="ignore",
        )
        writer.writeheader()
        for event in events:
            writer.writerow(event)


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start = utc_now()
    t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    findings: list = []
    errors: list[str] = []
    warnings: list[str] = []

    evidence_path = evidence_path.resolve()
    analysis_path = Path(config.get("analysis_path") or str(evidence_path))

    # Detect partition offset dynamically.  Failure is not fatal when the native
    # evidence parser has already exposed authoritative filesystem metadata.
    partition_offset = int(config.get("partition_offset", 0))
    if partition_offset == 0:
        partition_offset = _detect_offset(analysis_path, logger)
    logger.info("[TIMELINE] Partition offset: %d sectors", partition_offset)

    off = ["-o", str(partition_offset)] if partition_offset > 0 else []
    bodyfile = output_dir / "body.txt"
    timeline_csv = output_dir / "timeline.csv"

    # TSK is retained as an independent corroborating path.  Its failure becomes
    # a warning, rather than a false PARTIAL result, when the native parser supplies
    # a complete evidence-derived timestamp corpus.
    cmd_fls = ["fls", "-r", "-m", "C:/"] + off + [str(analysis_path)]
    logger.info("[TIMELINE] Running: %s", " ".join(cmd_fls))
    try:
        rc, stdout, stderr = _run_subprocess(cmd_fls, FLS_TIMEOUT, logger)
        if rc == 0 and stdout.strip():
            bodyfile.write_text(stdout, encoding="utf-8", errors="replace")
            logger.info("[TIMELINE] body.txt: %d lines", stdout.count("\n"))
        else:
            warnings.append(f"Supplemental fls timeline path unavailable (rc={rc}): {stderr[:300]}")
    except FileNotFoundError:
        warnings.append("Supplemental fls path unavailable — install sleuthkit")
    except Exception as exc:
        warnings.append(f"Supplemental fls path error: {exc}")

    mac_events: list[dict] = []
    if bodyfile.exists() and bodyfile.stat().st_size > 0:
        try:
            rc2, out2, err2 = _run_subprocess(
                ["mactime", "-b", str(bodyfile), "-d"], MACTIME_TIMEOUT, logger
            )
            if rc2 == 0 and out2.strip():
                timeline_csv.write_text(out2, encoding="utf-8", errors="replace")
                mac_events = _parse_mactime_csv(out2)
                logger.info("[TIMELINE] mactime: %d events", len(mac_events))
            else:
                warnings.append(f"Supplemental mactime path unavailable (rc={rc2}): {err2[:200]}")
        except FileNotFoundError:
            warnings.append("Supplemental mactime path unavailable — install sleuthkit")
        except Exception as exc:
            warnings.append(f"Supplemental mactime path error: {exc}")

    output_root = output_dir.parent
    native_events = _ingest_native_filesystem_timestamps(config)
    canonical_events = _ingest_canonical_finding_timestamps(config)
    # Structured module records are a deterministic source of event timestamps
    # even when a reporting/promotion policy has not promoted the enclosing
    # record as a severity finding.  Only explicitly timestamp-labelled fields
    # from parser outputs of semantic modules are consumed; generated run times
    # and module_result/candidate files are excluded by the ingestors.
    structured_json_events = _ingest_completed_module_timestamps(output_root)
    structured_table_events = _ingest_completed_module_table_timestamps(output_root)
    archive_metadata_events = _ingest_archive_metadata_timestamps(config)
    # mactime is a supplemental independent view. When the native filesystem
    # manifest exists, merging both would double-count the same FAT timestamps.
    filesystem_events = native_events if native_events else mac_events

    acquisition_timestamp = _find_acquisition_timestamp(output_root)
    acquisition_events: list[dict] = []
    if acquisition_timestamp:
        acquisition_events.append({
            "timestamp": acquisition_timestamp,
            "event_type": "EVIDENCE_ACQUISITION",
            "event": "EVIDENCE_ACQUISITION",
            "timestamp_meaning": "EWF acquisition/header time",
            "source": "evidence_validator",
            "responsible_module": "evidence_validator",
            "source_artifact": str(evidence_path),
            "source_locator": "EWF header/intake metadata",
            "semantic_object": str(evidence_path.name),
            "details": "Evidence acquisition/header timestamp retained from intake metadata.",
            "severity": "INFO",
        })

    logger.info(
        "[TIMELINE] Authoritative sources: %d filesystem, %d canonical semantic, "
        "%d structured JSON, %d structured table, %d archive metadata, %d acquisition event(s)",
        len(filesystem_events), len(canonical_events), len(structured_json_events),
        len(structured_table_events), len(archive_metadata_events), len(acquisition_events),
    )

    # The technical ledger preserves every deterministic timestamp-labelled parser
    # output. The examiner chronology is built only from schema-aware canonical
    # semantic events plus the filesystem/acquisition summaries; this prevents raw
    # JSON/CSV wrappers from becoming duplicate or mislabelled examiner events.
    technical_merged_events = _deduplicate_timeline_events([
        e for e in (filesystem_events + canonical_events + structured_json_events +
                    structured_table_events + archive_metadata_events + acquisition_events)
        if e.get("timestamp")
    ])
    all_events = [e for e in technical_merged_events if _parse_timestamp(e["timestamp"]) > 0.0]
    unparseable_events = [e for e in technical_merged_events if _parse_timestamp(e["timestamp"]) <= 0.0]
    all_events.sort(key=lambda e: _parse_timestamp(e["timestamp"]))
    examiner_source_events = [
        e for e in (filesystem_events + canonical_events + archive_metadata_events + acquisition_events)
        if e.get("timestamp") and _parse_timestamp(str(e.get("timestamp") or "")) > 0.0
    ]

    # Detect evidence-resident timestamp normalisation without inferring intent.
    fs_timestamp_values = [str(e.get("timestamp") or "") for e in filesystem_events if e.get("timestamp")]
    if len(fs_timestamp_values) >= 10:
        from collections import Counter as _Counter
        most_common_value, most_common_count = _Counter(fs_timestamp_values).most_common(1)[0]
        if most_common_count / len(fs_timestamp_values) >= 0.80:
            findings.append(make_finding(
                "NORMALIZED_FILESYSTEM_TIMESTAMPS", Severity.INFO,
                f"{most_common_count} of {len(fs_timestamp_values)} parsed filesystem timestamp rows share the stored value {most_common_value}. "
                "This records timestamp normalisation only; clock manipulation or user intent is not inferred.",
                str(evidence_path),
                {
                    "stored_value": most_common_value,
                    "matching_rows": most_common_count,
                    "filesystem_timestamp_rows": len(fs_timestamp_values),
                    "ratio": round(most_common_count / len(fs_timestamp_values), 6),
                    **deterministic_metadata(
                        "exact frequency count over native filesystem timestamp fields",
                        validators=["native filesystem manifest", "exact timestamp equality"],
                        semantic_limit="Stored timestamp pattern only; no intent attribution.",
                    ),
                },
            ))

    future_events: list[dict] = []
    same_day_after_start_count = 0
    if acquisition_timestamp:
        acquisition_epoch = _parse_timestamp(acquisition_timestamp)
        acquisition_dt = datetime.fromtimestamp(acquisition_epoch, tz=timezone.utc)
        # EWF header acquisition/system fields commonly describe acquisition
        # start time and do not provide a trustworthy completion boundary.  A
        # same-day event can therefore be chronologically later without being a
        # defensible "future-dated" anomaly.  Fail closed: classify an event as
        # future-dated only when its UTC calendar date is later than the
        # acquisition date.  Exact same-day ordering remains in the timeline.
        for event in all_events:
            event_epoch = _parse_timestamp(event["timestamp"])
            if event_epoch <= acquisition_epoch:
                continue
            event_dt = datetime.fromtimestamp(event_epoch, tz=timezone.utc)
            if _is_date_after_acquisition(event["timestamp"], acquisition_timestamp):
                future_events.append(event)
            else:
                same_day_after_start_count += 1
        deduped_future_events = []
        seen_future_semantic = set()
        for event in future_events:
            semantic_key = str(event.get("semantic_event_id") or event.get("semantic_object_id") or event.get("event_id") or "")
            if not semantic_key:
                semantic_key = "|".join((str(event.get("timestamp") or ""), str(event.get("event_type") or event.get("event") or ""), str(event.get("details") or event.get("semantic_object") or "")))
            if semantic_key in seen_future_semantic:
                continue
            seen_future_semantic.add(semantic_key)
            deduped_future_events.append(event)
        future_events = deduped_future_events
        for event in future_events:
            retained_source = str(event.get("source_artifact") or "")
            artifact = retained_source if retained_source and Path(retained_source).is_file() else None
            findings.append(make_finding(
                "TIMESTAMP_DATE_AFTER_ACQUISITION", Severity.MEDIUM,
                f"A parsed evidence timestamp ({event['timestamp']}) is dated after the recorded acquisition date ({acquisition_dt.date().isoformat()}).",
                str(evidence_path),
                {
                    "acquisition_timestamp": acquisition_timestamp,
                    "event_timestamp": event.get("timestamp"),
                    "source_file": retained_source,
                    "derived_artifact_path": event.get("derived_artifact_path", ""),
                    "json_path": event.get("source_json_pointer", ""),
                    "csv_row": event.get("source_row", ""),
                    "event": event,
                    **deterministic_metadata(
                        "UTC calendar-date comparison where acquisition completion time is unavailable",
                        validators=["ISO timestamp parser", "UTC date ordering", "retained source locator"],
                    ),
                    "semantic_limit": (
                        "This establishes only that the stored event date is later than the acquisition date; "
                        "clock correctness, user action and intent are not inferred."
                    ),
                },
                artifact_path=artifact,
            ))

    technical_event_ledger_csv = output_dir / "technical_event_ledger.csv"
    examiner_events = _build_examiner_timeline(examiner_source_events)
    final_examiner_identities = [
        (
            str(e.get("timestamp") or "").replace("Z", "+00:00"),
            str(e.get("event_type") or ""),
            str(e.get("semantic_object") or e.get("details") or "").casefold(),
        )
        for e in examiner_events
        if str(e.get("event_type") or "") != "FILESYSTEM_TIMESTAMP_SUMMARY"
    ]
    duplicate_examiner_events = len(final_examiner_identities) - len(set(final_examiner_identities))
    unresolved_semantic_records = sum(
        1 for e in canonical_events
        if not e.get("timestamp") or _parse_timestamp(str(e.get("timestamp") or "")) <= 0.0
    )
    examiner_timeline_csv = output_dir / "examiner_timeline.csv"
    # semantic_timeline.csv is retained as a compatibility alias for the concise
    # examiner-facing chronology; the complete event set is never discarded.
    semantic_timeline_csv = output_dir / "semantic_timeline.csv"
    authoritative_source = (
        "canonical_findings_plus_native_filesystem" if canonical_events and native_events
        else "canonical_findings" if canonical_events
        else "native_filesystem_manifest" if native_events
        else "mactime/fls" if mac_events else "none"
    )
    coverage_sufficient = bool(filesystem_events or canonical_events or acquisition_events)
    try:
        _write_timeline_csv(technical_event_ledger_csv, all_events)
        _write_timeline_csv(examiner_timeline_csv, examiner_events)
        _write_timeline_csv(semantic_timeline_csv, examiner_events)
    except OSError as exc:
        errors.append(f"Could not write timeline output: {exc}")
    # Preserve mactime output as a supplemental body-file view.  The semantic
    # timeline is the authoritative cross-source chronology.
    if not timeline_csv.exists():
        try:
            _write_timeline_csv(timeline_csv, all_events)
        except OSError as exc:
            errors.append(f"Could not write compatibility timeline CSV: {exc}")
    if not coverage_sufficient:
        errors.extend(warnings)
        warnings = []
        errors.append(
            "No authoritative filesystem timestamp corpus was available; "
            "cross-module timestamps alone cannot establish a complete forensic timeline."
        )

    logger.info(
        "[TIMELINE] Valid events: %d; excluded unparseable timestamps: %d",
        len(all_events), len(unparseable_events),
    )

    sessions = _group_sessions(all_events)
    antiforensic_sessions = [s for s in sessions if _is_antiforensic_session(s)]

    for sess in antiforensic_sessions:
        start_ts = sess[0]["timestamp"] if sess else "unknown"
        end_ts = sess[-1]["timestamp"] if sess else "unknown"
        findings.append(make_finding(
            "POTENTIAL_ANTIFORENSIC_SESSION", Severity.MEDIUM,
            f"Potential anti-forensic pattern: the session from {start_ts} to {end_ts} "
            f"contains forensic-tool references, deletion-related entries and archive "
            f"activity. This correlation requires manual verification and does not "
            f"establish which user acted, whether the tools were executed, or intent.",
            str(evidence_path),
            {
                "session_start": start_ts,
                "session_end": end_ts,
                "event_count": len(sess),
                "events_sample": [e.get("event", "")[:80] for e in sess[:10]],
                "interpretation": "indicator_only",
                **candidate_metadata("multi-keyword temporal correlation", reason="Correlation does not deterministically establish anti-forensic action or intent"),
            },
        ))

    if all_events and coverage_sufficient:
        table_rows = [
            {
                "time_gmt": e.get("timestamp", "")[:19],
                "event": e.get("event", "")[:120],
                "evidence_source": e.get("source", "forensic timestamp source")[:60],
                "severity": e.get("severity", "INFO"),
            }
            for e in examiner_events
        ]
        findings.append(make_finding(
            "TIMELINE_CONSTRUCTED", Severity.INFO,
            f"Forensic timeline: {len(all_events)} technical event row(s) consolidated into {len(examiner_events)} examiner-facing event(s), spanning "
            f"{all_events[0].get('timestamp','?')[:19]} to "
            f"{all_events[-1].get('timestamp','?')[:19]}. "
            f"{len(unparseable_events)} unparseable timestamp value(s) were excluded; "
            f"{len(sessions)} timestamp cluster(s), {len(antiforensic_sessions)} potential "
            f"anti-forensic pattern cluster(s).",
            str(evidence_path),
            {
                "technical_event_count": len(all_events),
                "examiner_event_count": len(examiner_events),
                "sessions": len(sessions),
                "antiforensic_sessions": len(antiforensic_sessions),
                "unparseable_timestamps": len(unparseable_events),
                "authoritative_source": authoritative_source,
                "report_file": str(examiner_timeline_csv),
                "technical_ledger_file": str(technical_event_ledger_csv),
                "table": table_rows[:200],
                "future_event_count": len(future_events),
                "same_day_after_acquisition_start_count": same_day_after_start_count,
                "acquisition_timestamp": acquisition_timestamp,
                **deterministic_metadata("sorting of parser-normalised retained timestamps", validators=["timestamp parser", "source JSON pointers"]),
            },
            artifact_path=str(semantic_timeline_csv),
        ))

    mp = output_dir / "timeline_manifest.json"
    mp.write_text(json.dumps({
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "partition_offset": partition_offset,
        "authoritative_source": authoritative_source,
        "coverage_sufficient": coverage_sufficient,
        "fls_events": len(mac_events),
        "native_filesystem_events": len(native_events),
        "canonical_semantic_events": len(canonical_events),
        "structured_json_events": len(structured_json_events),
        "structured_table_events": len(structured_table_events),
        "acquisition_events": len(acquisition_events),
        "supplemental_mactime_events": len(mac_events),
        "acquisition_timestamp": acquisition_timestamp,
        "events_after_acquisition_date": len(future_events),
        "same_day_after_acquisition_start": same_day_after_start_count,
        "technical_event_count": len(all_events),
        "examiner_event_count": len(examiner_events),
        "semantic_records_discovered": len(canonical_events),
        "semantic_records_processed": len(canonical_events) - unresolved_semantic_records,
        "unresolved_semantic_records": unresolved_semantic_records,
        "duplicate_examiner_events": duplicate_examiner_events,
        "unparseable_timestamps": len(unparseable_events),
        "sessions": len(sessions),
        "antiforensic_sessions": len(antiforensic_sessions),
        "findings": len(findings),
        "warnings": warnings,
        "errors": errors,
    }, indent=2, default=str), encoding="utf-8")

    if coverage_sufficient and not errors:
        status = ModuleStatus.COMPLETED
    elif all_events:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.FAILED

    if findings:
        timeline_verdict = AssuranceVerdict.PRESENT
    elif coverage_sufficient and not errors:
        timeline_verdict = AssuranceVerdict.VERIFIED_ABSENT
    else:
        timeline_verdict = AssuranceVerdict.INDETERMINATE
    cr = ClassResult(
        locus=Locus.TIMELINE,
        artefact_class="Forensic Timeline Events",
        verdict=timeline_verdict,
        count=len(findings),
        skip_reason=(None if timeline_verdict != AssuranceVerdict.INDETERMINATE else SkipReason.PARTIAL_FAILURE),
        notes="; ".join((errors or warnings)[:3]),
    )
    artifact_paths = [str(mp)]
    for path in (bodyfile, timeline_csv, technical_event_ledger_csv, examiner_timeline_csv, semantic_timeline_csv):
        if path.exists():
            artifact_paths.append(str(path))
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start, end_time=utc_now(),
        duration_seconds=round(time.monotonic() - t0, 2),
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            "partition_offset": partition_offset,
            "authoritative_source": authoritative_source,
            "coverage_sufficient": coverage_sufficient,
            "fls_events": len(mac_events),
            "native_filesystem_events": len(native_events),
            "cross_module_events": len(canonical_events),
            "acquisition_events": len(acquisition_events),
            "supplemental_mactime_events": len(mac_events),
            "technical_event_count": len(all_events),
            "examiner_event_count": len(examiner_events),
            "semantic_records_discovered": len(canonical_events),
            "semantic_records_processed": len(canonical_events) - unresolved_semantic_records,
            "records_discovered": len(canonical_events),
            "records_processed": len(canonical_events) - unresolved_semantic_records,
            "unresolved_semantic_records": unresolved_semantic_records,
            "duplicate_examiner_events": duplicate_examiner_events,
            "antiforensic_sessions": len(antiforensic_sessions),
            "future_event_count": len(future_events),
            "same_day_after_acquisition_start_count": same_day_after_start_count,
            "acquisition_timestamp": acquisition_timestamp,
            "warnings": warnings,
            "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if coverage_sufficient and not errors else "ran_with_caveat"),
        },
        summary=(
            f"Timeline: {len(all_events)} technical evidence-derived row(s) and {len(examiner_events)} concise examiner-facing event(s), "
            f"{len(sessions)} timestamp cluster(s), "
            f"{len(antiforensic_sessions)} potential anti-forensic pattern cluster(s), {len(future_events)} event(s) after acquisition; "
            f"source={authoritative_source}. {len(findings)} finding(s)."
        ),
        class_results=[cr],
    )

