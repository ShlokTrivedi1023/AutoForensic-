"""
ocr_text_extractor.py — OCR Text Extraction Module for AutoForensics.

Uses ``tesseract`` to perform Optical Character Recognition on image files
recovered from the forensic image.  Post-processes extracted text with regex
patterns to identify forensically significant content:

  - IP addresses, URLs, email addresses
  - Credit card numbers (Luhn validated)
  - Social Security Numbers
  - Phone numbers
  - API keys / tokens (hex strings ≥ 32 chars)
  - Passwords adjacent to keyword labels

Supported input formats: JPEG, PNG, BMP, GIF, TIFF, WEBP.

Target platform : Kali Linux, Python 3.11+
External tools  : tesseract-ocr (tesseract-ocr package)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "ocr_text_extractor"
TESSERACT_TIMEOUT: int = 300   # 5 minutes per image

# Minimum substance an OCR result must have before it is reported as recovered
# text.  Tesseract emits stray glyphs for photographs that carry no writing at
# all; requiring a couple of real words keeps that noise out without making the
# capability conditional on WHAT the text says.
_MIN_OCR_WORDS: int = 2
_MIN_OCR_CHARS: int = 8
_OCR_PREVIEW_CHARS: int = 1000
_RE_OCR_WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9'\-]{1,}")

_IMAGE_EXTENSIONS: frozenset[str] = frozenset({
    ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tiff", ".tif", ".webp",
})

# Post-OCR extraction patterns
_RE_IPV4 = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
)
_RE_EMAIL = re.compile(
    r"\b[a-zA-Z0-9._%+\-]{1,64}@[a-zA-Z0-9.\-]{1,253}\.[a-zA-Z]{2,}\b"
)
_RE_URL = re.compile(
    r"\bhttps?://[^\s\"'<>]{4,200}\b", re.IGNORECASE
)
_RE_CCN = re.compile(r"\b(?:\d[ \-]?){13,16}\b")
_RE_SSN = re.compile(r"\b\d{3}[-\s]\d{2}[-\s]\d{4}\b")
# OCR field interpretation is label anchored.  A digit sequence inside another
# labelled value (for example an API key) is never reclassified as a phone or
# payment card merely because it has a familiar length/checksum.
_RE_LABELLED_FIELD = re.compile(
    r"(?im)^\s*(?P<label>USERNAME|USER|PASSWORD|PASSWD|PWD|API[ _-]?KEY|ACCESS[ _-]?TOKEN|"
    r"EMAIL|E-?MAIL|PHONE|TELEPHONE|MOBILE|IP(?: ADDRESS)?|URL|URI|SSN|CARD(?: NUMBER)?|PAN)"
    r"\s*(?::|=|\bis\b)\s*(?P<value>[^\r\n]{1,256}?)\s*$"
)


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _luhn_check(number: str) -> bool:
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _ocr_image(img_path: Path, logger: logging.Logger, psm: int = 3) -> str:
    """
    Run tesseract on a single image and return extracted text.

    Parameters
    ----------
    img_path : Path to the image file.
    logger   : Module logger.

    Returns
    -------
    Extracted text string, empty on failure.

    Raises
    ------
    FileNotFoundError       If tesseract is not installed.
    subprocess.TimeoutExpired  If OCR exceeds TESSERACT_TIMEOUT.
    """
    cmd = ["tesseract", str(img_path), "stdout", "--psm", str(psm), "-l", "eng"]
    rc, stdout, stderr = _run_subprocess(cmd, timeout=TESSERACT_TIMEOUT, logger=logger)
    if rc != 0:
        raise RuntimeError(
            f"tesseract rc={rc} for {img_path.name}: {stderr[:300]}"
        )
    return stdout


def _image_visual_digest(path: Path) -> str | None:
    """Return a digest of decoded visual pixels, or ``None`` when undecodable.

    Carvers can retain a valid image followed by unrelated trailing bytes.  Such
    a file has a different byte hash from the source image even though it renders
    identically.  Hashing the decoded pixel plane lets OCR collapse those aliases
    and avoids treating carving slack as a second evidential image.
    """
    try:
        from PIL import Image, ImageOps
        with Image.open(path) as image:
            width, height = image.size
            if width <= 0 or height <= 0 or width * height > 100_000_000:
                return None
            # load() forces full pixel decoding.  exif_transpose() makes visual
            # aliases stable when orientation is stored in metadata.
            image.load()
            rendered = ImageOps.exif_transpose(image).convert("RGBA")
            payload = rendered.tobytes()
            header = f"{rendered.width}x{rendered.height}:{rendered.mode}:".encode("ascii")
            return hashlib.sha256(header + payload).hexdigest()
    except Exception:
        return None


def _is_decodable_image(path: Path) -> bool:
    """Confirm image content before invoking Tesseract."""
    return _image_visual_digest(path) is not None


def _ocr_candidate_priority(path: Path) -> tuple[int, int, str]:
    """Prefer source/native files over generated carving aliases."""
    lowered = str(path).lower().replace("\\", "/")
    if "/native_filesystem/" in lowered and "/extracted_files/" in lowered:
        rank = 0
    elif "/native_filesystem/" in lowered and "/deleted_files/" in lowered:
        rank = 1
    elif "/foremost_carver/" in lowered:
        rank = 2
    elif "/scalpel_carver/" in lowered:
        rank = 3
    else:
        rank = 4
    return rank, len(path.parts), str(path)


def _collect_unique_images(
    candidate_paths: list[Path],
    *,
    max_images: int,
    logger: logging.Logger,
) -> tuple[list[Path], int, int, bool]:
    """Validate and visually deduplicate OCR candidates.

    Returns ``(images, invalid_skipped, duplicate_aliases, limit_reached)``.
    The limit applies to unique decoded images, not raw directory entries.
    """
    by_visual_digest: dict[str, Path] = {}
    invalid_candidates_skipped = 0
    duplicate_image_aliases = 0
    image_limit_reached = False

    candidates: list[Path] = []
    for candidate in candidate_paths:
        if candidate.is_file() and candidate.suffix.lower() in _IMAGE_EXTENSIONS:
            candidates.append(candidate)
        elif candidate.is_dir():
            try:
                candidates.extend(
                    path for path in candidate.rglob("*")
                    if path.is_file() and path.suffix.lower() in _IMAGE_EXTENSIONS
                )
            except OSError:
                continue

    # Evaluate higher-quality provenance first so a carved alias never displaces
    # the native filesystem object merely because its generated name sorts first.
    candidates.sort(key=_ocr_candidate_priority)
    for candidate in candidates:
        digest = _image_visual_digest(candidate)
        if digest is None:
            invalid_candidates_skipped += 1
            logger.info("[%s] Skipping corrupt/extension-only image candidate: %s", MODULE_NAME, candidate)
            continue
        if digest in by_visual_digest:
            duplicate_image_aliases += 1
            logger.debug(
                "[%s] Skipping visual duplicate %s (alias of %s)",
                MODULE_NAME, candidate, by_visual_digest[digest],
            )
            continue
        if max_images > 0 and len(by_visual_digest) >= max_images:
            image_limit_reached = True
            break
        by_visual_digest[digest] = candidate

    return list(by_visual_digest.values()), invalid_candidates_skipped, duplicate_image_aliases, image_limit_reached


def _ocr_quality_score(text: str) -> float:
    """Rank OCR candidates without inventing or correcting characters."""
    text = text or ""
    words = _RE_OCR_WORD.findall(text)
    printable = sum(ch.isprintable() or ch in "\r\n\t" for ch in text)
    ratio = printable / max(1, len(text))
    labels = sum(1 for label in ("credential", "vpn", "wifi", "admin", "password", "pw")
                 if label in text.lower())
    punctuation = sum(1 for ch in text if ch in "!@#$%&*_-:/")
    return len(words) * 2.0 + min(len(text), 500) / 100.0 + labels * 3.0 + min(punctuation, 20) * 0.1 + ratio


def _ocr_image_preprocessed(img_path: Path, logger: logging.Logger) -> str:
    """OCR a 2x greyscale/autocontrast derivative; source bytes remain unchanged."""
    try:
        from PIL import Image, ImageOps
    except ImportError:
        return ""
    temp_name = ""
    try:
        with Image.open(img_path) as image:
            gray = ImageOps.autocontrast(image.convert("L"))
            resampling = getattr(Image, "Resampling", Image).LANCZOS
            scaled = gray.resize((max(1, gray.width * 2), max(1, gray.height * 2)), resampling)
            with tempfile.NamedTemporaryFile(prefix="autoforensics_ocr_", suffix=".png", delete=False) as handle:
                temp_name = handle.name
            scaled.save(temp_name, format="PNG")
        return _ocr_image(Path(temp_name), logger, psm=6)
    except FileNotFoundError:
        raise
    except Exception as exc:
        logger.debug("[%s] Preprocessed OCR unavailable for %s: %s", MODULE_NAME, img_path.name, exc)
        return ""
    finally:
        if temp_name:
            try:
                Path(temp_name).unlink(missing_ok=True)
            except OSError:
                pass


def _recovered_text(text: str) -> str:
    """Return the OCR result if it is substantive enough to report, else "".

    Substance is judged structurally — a couple of word-shaped tokens — so the
    capability holds for any writing recovered from any image, whatever the
    words happen to be.
    """
    words = _RE_OCR_WORD.findall(text or "")
    if len(words) < _MIN_OCR_WORDS or sum(len(w) for w in words) < _MIN_OCR_CHARS:
        return ""
    # Collapse the whitespace tesseract inserts around layout boundaries so the
    # reported text reads as prose rather than as a column of fragments.
    return " ".join((text or "").split())


def _extract_iocs(text: str) -> dict[str, list[str]]:
    """Extract label-bounded OCR candidates without cross-field reclassification.

    OCR is probabilistic, so these remain candidate observations.  The parser
    makes only the deterministic statement that the OCR engine returned a value
    next to a specific label; it does not claim that the characters are correct.
    """
    iocs: dict[str, list[str]] = {
        "ips": [], "emails": [], "urls": [],
        "credit_cards": [], "ssns": [], "phones": [],
        "api_keys": [], "passwords": [], "usernames": [],
        "labelled_fields": [],
    }
    for match in _RE_LABELLED_FIELD.finditer(text or ""):
        label = re.sub(r"[^A-Z0-9]+", "_", match.group("label").upper()).strip("_")
        value = match.group("value").strip()
        if not value:
            continue
        iocs["labelled_fields"].append({"label": label, "value": value})
        if label in {"USERNAME", "USER"}:
            iocs["usernames"].append(value)
        elif label in {"PASSWORD", "PASSWD", "PWD"}:
            iocs["passwords"].append(value)
        elif label in {"API_KEY", "ACCESS_TOKEN"}:
            iocs["api_keys"].append(value)
        elif label in {"EMAIL", "E_MAIL"}:
            iocs["emails"].extend(_RE_EMAIL.findall(value))
        elif label in {"PHONE", "TELEPHONE", "MOBILE"}:
            digits = re.sub(r"[^0-9+]", "", value)
            if 8 <= len(re.sub(r"\D", "", digits)) <= 15:
                iocs["phones"].append(value)
        elif label in {"IP", "IP_ADDRESS"}:
            iocs["ips"].extend(_RE_IPV4.findall(value))
        elif label in {"URL", "URI"}:
            iocs["urls"].extend(_RE_URL.findall(value))
        elif label == "SSN":
            iocs["ssns"].extend(_RE_SSN.findall(value))
        elif label in {"CARD", "CARD_NUMBER", "PAN"}:
            for candidate in _RE_CCN.findall(value):
                digits = re.sub(r"\D", "", candidate)
                if _luhn_check(digits):
                    iocs["credit_cards"].append(candidate.strip())
    for key, values in list(iocs.items()):
        if key == "labelled_fields":
            seen = set()
            deduped = []
            for item in values:
                marker = (item["label"], item["value"])
                if marker not in seen:
                    seen.add(marker); deduped.append(item)
            iocs[key] = deduped
        else:
            iocs[key] = list(dict.fromkeys(values))
    return iocs



def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _decode_search_views(data: bytes) -> list[tuple[str, str]]:
    views: list[tuple[str, str]] = []
    for encoding in ("utf-8", "utf-16-le", "utf-16-be", "latin-1"):
        try:
            text = data.decode(encoding)
        except UnicodeDecodeError:
            continue
        if text:
            views.append((encoding, text.casefold()))
    return views


def _corroborate_labelled_fields(
    labelled_fields: list[dict[str, str]],
    corpus_paths: list[Path],
    source_image: Path,
) -> dict[str, Any]:
    """Find exact OCR field values in independent evidentiary byte streams.

    This is evidence-agnostic: no expected label or value is embedded in the
    implementation.  It simply requires multiple OCR-returned labelled values to
    occur exactly in at least one different retained file.
    """
    values = []
    for item in labelled_fields:
        label = str(item.get("label") or "").strip()
        value = str(item.get("value") or "").strip()
        if label and len(value) >= 4:
            values.append((label, value))
    if not values:
        return {"confirmed": False, "matched_fields": [], "supporting_sources": []}

    try:
        source_hash = _sha256_file(source_image)
    except OSError:
        source_hash = ""
    seen_hashes: set[str] = {source_hash} if source_hash else set()
    matched: dict[tuple[str, str], list[dict[str, str]]] = {}
    supporting_sources: dict[str, dict[str, str]] = {}
    for path in corpus_paths:
        if not path.is_file() or path == source_image:
            continue
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size <= 0 or size > 16 * 1024 * 1024:
            continue
        try:
            digest = _sha256_file(path)
        except OSError:
            continue
        if digest in seen_hashes:
            continue
        seen_hashes.add(digest)
        try:
            data = path.read_bytes()
        except OSError:
            continue
        views = _decode_search_views(data)
        if not views:
            continue
        source_matches = 0
        for label, value in values:
            needle = value.casefold()
            encodings = [enc for enc, text in views if needle in text]
            if not encodings:
                continue
            key = (label, value)
            matched.setdefault(key, []).append({
                "path": str(path), "sha256": digest,
                "encoding_views": ",".join(sorted(set(encodings))),
            })
            source_matches += 1
        if source_matches:
            supporting_sources[digest] = {"path": str(path), "sha256": digest}

    matched_fields = [
        {"label": label, "value": value, "matches": matches}
        for (label, value), matches in sorted(matched.items())
    ]
    # Two independent field values are required.  A single repeated token is not
    # enough to promote a probabilistic transcription.
    confirmed = len(matched_fields) >= 2 and bool(supporting_sources)
    return {
        "confirmed": confirmed,
        "matched_fields": matched_fields,
        "supporting_sources": list(supporting_sources.values()),
        "rule": "at least two exact labelled OCR values in an independent unique byte stream",
    }


def _ocr_tsv_details(img_path: Path, logger: logging.Logger, psm: int) -> dict[str, Any]:
    """Return word confidences/bounding boxes when Tesseract TSV is available."""
    cmd = ["tesseract", str(img_path), "stdout", "--psm", str(psm), "-l", "eng", "tsv"]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=TESSERACT_TIMEOUT, logger=logger)
    except Exception as exc:
        return {"available": False, "reason": str(exc), "words": []}
    if rc != 0:
        return {"available": False, "reason": (stderr or f"rc={rc}")[:300], "words": []}
    lines = stdout.splitlines()
    if not lines:
        return {"available": False, "reason": "empty TSV", "words": []}
    words = []
    for line in lines[1:]:
        parts = line.split("\t")
        if len(parts) < 12:
            continue
        text = parts[11].strip()
        if not text:
            continue
        try:
            conf = float(parts[10])
            left, top, width, height = map(int, parts[6:10])
        except (TypeError, ValueError):
            continue
        words.append({"text": text, "confidence": conf, "bbox": [left, top, width, height]})
    confidences = [w["confidence"] for w in words if w["confidence"] >= 0]
    return {
        "available": True,
        "words": words,
        "mean_word_confidence": (round(sum(confidences) / len(confidences), 3) if confidences else None),
    }


def _tesseract_version(logger: logging.Logger) -> str:
    try:
        rc, out, _ = _run_subprocess(["tesseract", "--version"], 30, logger)
        if rc == 0 and out.strip():
            return out.splitlines()[0].strip()
    except Exception:
        pass
    return "tesseract (version unavailable)"

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Run tesseract OCR on image files in output_dir and extract IOCs.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Directory containing image files to OCR.
    config        : Configuration dict; recognised keys:
                    - ``image_dirs`` (list[str]): extra directories to scan.
                    - ``max_images`` (int): optional cap on images to process; 0 (default) is exhaustive.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with IOC findings extracted from OCR text.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run.
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    target_dir = str(_corpus_roots[0]) if _corpus_roots else None
    if not _corpus_roots:
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="OCR Text Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            notes="no recovered/carved corpus was available to examine",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — no recovered/carved corpus was available to examine",
            findings=[], errors=[], statistics={
                "applicability_check_completed": True,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "records_discovered": 0, "records_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
            },
            class_results=[cr],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)
    transcript_dir = output_dir / "transcripts"
    transcript_dir.mkdir(parents=True, exist_ok=True)
    ocr_engine_version = _tesseract_version(logger)

    max_images = int(config.get("max_images", 0) or 0)

    # Collect only original evidentiary images. Explicit extra image paths are
    # accepted only when they are outside this case's derived-output tree; they
    # are never treated as corroborating evidence merely because another module
    # generated them.
    candidate_paths: list[Path] = iter_corpus_files(
        ws, output_dir=output_dir, deduplicate_by_hash=False
    )
    from core.source_provenance import SourceRole, source_role_for_path
    for extra in config.get("image_dirs", []):
        p = Path(extra)
        if p.is_file():
            extras = [p]
        elif p.is_dir():
            try:
                extras = [q for q in p.rglob("*") if q.is_file()]
            except OSError:
                extras = []
        else:
            extras = []
        for q in extras:
            role = source_role_for_path(q, ws, output_dir=output_dir)
            if role in {SourceRole.EVIDENTIARY_CONTENT, SourceRole.UNKNOWN}:
                candidate_paths.append(q)

    (
        image_files,
        invalid_candidates_skipped,
        duplicate_image_aliases,
        image_limit_reached,
    ) = _collect_unique_images(candidate_paths, max_images=max_images, logger=logger)
    if image_limit_reached:
        errors.append(
            f"OCR unique-image limit reached at {max_images}; increase max_images for full corpus coverage."
        )

    if not image_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="OCR Text Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            notes="No image files found",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="NOT APPLICABLE — no supported image files were found after applicability checking.",
            statistics={
                "applicability_check_completed": True,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "records_discovered": 0, "records_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
            },
            class_results=[cr],
        )

    logger.info("[%s] Found %d image files to OCR", MODULE_NAME, len(image_files))

    stats: dict[str, int] = {
        "sources_discovered": len(image_files),
        "sources_processed": 0,
        "supported_objects_discovered": len(image_files),
        "supported_objects_processed": 0,
        "records_discovered": len(image_files),
        "records_processed": 0,
        "unresolved_supported_objects": 0,
        "parser_errors": 0,
        "images_scheduled": len(image_files),
        "invalid_candidates_skipped": invalid_candidates_skipped,
        "duplicate_image_aliases": duplicate_image_aliases,
        "normalised_fallbacks_used": 0,
        "images_processed": 0, "images_failed": 0, "images_no_text": 0, "images_with_text": 0,
        "ips_found": 0, "emails_found": 0, "urls_found": 0,
        "credit_cards_found": 0, "ssns_found": 0,
        "phones_found": 0, "api_keys_found": 0, "passwords_found": 0,
        "ocr_candidate_transcripts": 0, "ocr_corroborated_transcripts": 0,
    }

    ocr_records: list[dict[str, Any]] = []
    tesseract_available = True

    for img in image_files:
        logger.debug("[%s] OCR: %s", MODULE_NAME, img.name)
        candidates: list[tuple[str, str]] = []
        attempt_failures: list[str] = []
        tesseract_missing = False
        for method, operation in (
            ("psm3", lambda: _ocr_image(img, logger, psm=3)),
            ("psm6", lambda: _ocr_image(img, logger, psm=6)),
            ("preprocessed_2x_psm6", lambda: _ocr_image_preprocessed(img, logger)),
        ):
            try:
                candidates.append((method, operation()))
            except FileNotFoundError:
                tesseract_missing = True
                break
            except (subprocess.TimeoutExpired, RuntimeError) as exc:
                attempt_failures.append(f"{method}: {exc}")
            except Exception as exc:
                attempt_failures.append(f"{method}: {type(exc).__name__}: {exc}")

        if tesseract_missing:
            tesseract_available = False
            break
        if not candidates:
            stats["images_failed"] += 1
            warnings.append(
                f"tesseract could not process {img.name} with any OCR variant: "
                + " | ".join(attempt_failures[:3])
            )
            continue

        ocr_method, text = max(candidates, key=lambda item: _ocr_quality_score(item[1]))
        if ocr_method == "preprocessed_2x_psm6" and attempt_failures:
            stats["normalised_fallbacks_used"] += 1
            warnings.append(
                f"OCR used a normalised PNG derivative for {img.name} after raw decoder rejection; "
                "source bytes were not modified."
            )

        # A successful OCR process with no characters is a valid negative result,
        # not a processing failure.
        stats["images_processed"] += 1
        stats["sources_processed"] += 1
        stats["supported_objects_processed"] += 1
        stats["records_processed"] += 1
        if not text.strip():
            stats["images_no_text"] += 1
        iocs = _extract_iocs(text)

        recovered = _recovered_text(text)
        corroboration = _corroborate_labelled_fields(
            list(iocs.get("labelled_fields") or []), candidate_paths, img
        ) if recovered else {"confirmed": False, "matched_fields": [], "supporting_sources": []}
        psm_value = 3 if ocr_method == "psm3" else 6
        tsv_details = (
            _ocr_tsv_details(img, logger, psm_value)
            if ocr_method in {"psm3", "psm6"} else
            {"available": False, "reason": "preprocessed derivative TSV not retained", "words": []}
        )
        record: dict[str, Any] = {
            "file": str(img),
            "image_sha256": _sha256_file(img),
            "ocr_engine": ocr_engine_version,
            "ocr_method": ocr_method,
            "ocr_configuration": {"language": "eng", "psm": psm_value, "preprocessing": ocr_method},
            "ocr_quality_score": round(_ocr_quality_score(text), 3),
            "text_length": len(text),
            "text_preview": recovered[:_OCR_PREVIEW_CHARS],
            "iocs": iocs,
            "word_details": tsv_details,
            "corroboration": corroboration,
        }
        ocr_records.append(record)

        # Update aggregate stats
        stats["ips_found"] += len(iocs["ips"])
        stats["emails_found"] += len(iocs["emails"])
        stats["urls_found"] += len(iocs["urls"])
        stats["credit_cards_found"] += len(iocs["credit_cards"])
        stats["ssns_found"] += len(iocs["ssns"])
        stats["phones_found"] += len(iocs["phones"])
        stats["api_keys_found"] += len(iocs["api_keys"])
        stats["passwords_found"] += len(iocs["passwords"])

        # Retain the exact machine output.  It is promoted to accepted evidence
        # only when multiple labelled values are independently corroborated in a
        # different unique byte stream; otherwise it remains candidate-only.
        if recovered:
            stats["images_with_text"] += 1
            image_sha256 = _sha256_file(img)
            transcript_bytes = recovered.encode("utf-8")
            transcript_sha256 = hashlib.sha256(transcript_bytes).hexdigest()
            transcript_path = transcript_dir / f"{image_sha256}_{ocr_method}.txt"
            transcript_path.write_bytes(transcript_bytes)
            artifact_paths.append(str(transcript_path))
            credential_sensitive = bool(iocs.get("passwords") or iocs.get("api_keys"))
            confirmed = bool(corroboration.get("confirmed"))
            if confirmed:
                stats["ocr_corroborated_transcripts"] += 1
                findings.append(make_finding(
                    finding_type="OCR_TRANSCRIPTION_CORROBORATED",
                    severity=Severity.INFO,
                    description=(
                        f"A {len(recovered)}-character OCR transcription from {img.name} "
                        "was independently corroborated by exact labelled values in retained evidence."
                    ),
                    evidence_path=str(img),
                    metadata={
                        **deterministic_metadata(
                            "OCR engine output with independent exact-value corroboration",
                            validators=["source image SHA-256", "transcript SHA-256", "exact independent value search"],
                            semantic_limit="Accepted transcription is limited to the retained OCR output and exact corroborated values; visual image remains primary evidence.",
                        ),
                        "image_file": str(img), "image_sha256": image_sha256,
                        "ocr_engine": ocr_engine_version, "ocr_method": ocr_method,
                        "ocr_configuration": {"language": "eng", "psm": psm_value, "preprocessing": ocr_method},
                        "transcript_path": str(transcript_path), "transcript_sha256": transcript_sha256,
                        "recognized_text": recovered, "text_length": len(recovered),
                        "word_details": tsv_details, "corroboration": corroboration,
                        "credential_sensitive": credential_sensitive,
                        "fact_class": "VERIFIED_DECODED_EVIDENCE",
                        "counts_toward_unique_evidence": True,
                        "examiner_confirmation_status": "INDEPENDENTLY_CORROBORATED",
                    },
                    artifact_path=str(transcript_path),
                ))
            else:
                stats["ocr_candidate_transcripts"] += 1
                findings.append(make_finding(
                    finding_type="OCR_ENGINE_TRANSCRIPTION",
                    severity=Severity.INFO,
                    description=(
                        "Machine transcription — requires visual or independent confirmation. "
                        f"{ocr_engine_version} produced a retained {len(recovered)}-character "
                        f"transcription from image {img.name} using {ocr_method}."
                    ),
                    evidence_path=str(img),
                    metadata={
                        **candidate_metadata(
                            "OCR engine transcription",
                            reason="OCR character recognition is probabilistic and independent corroboration was insufficient.",
                            threshold=f"quality_score={round(_ocr_quality_score(recovered), 3)}",
                        ),
                        "image_file": str(img), "image_sha256": image_sha256,
                        "ocr_engine": ocr_engine_version, "ocr_method": ocr_method,
                        "ocr_configuration": {"language": "eng", "psm": psm_value, "preprocessing": ocr_method},
                        "transcript_path": str(transcript_path), "transcript_sha256": transcript_sha256,
                        "machine_transcription_requires_visual_confirmation": recovered,
                        "word_details": tsv_details, "corroboration": corroboration,
                        "credential_sensitive": credential_sensitive,
                        "semantic_limit": "Machine transcription output only; textual accuracy requires independent confirmation.",
                        "fact_class": "CANDIDATE_ONLY", "candidate_only": True,
                        "examiner_confirmation_status": "NOT_CONFIRMED",
                    },
                    artifact_path=str(transcript_path),
                ))

        if not any(iocs.values()):
            continue

        # Findings per IOC type
        if iocs["credit_cards"]:
            findings.append(make_finding(
                finding_type="CREDIT_CARD_NUMBER",
                severity=Severity.HIGH,
                description=(
                    f"OCR extracted {len(iocs['credit_cards'])} Luhn-valid credit card "
                    f"number(s) from image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={
                    "finding_basis": "candidate",
                    "deterministic_validation": False,
                    "candidate_method": "OCR engine transcription with label-bounded field parsing",
                    "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                    "image_file": str(img),
                    "samples": [c[:4] + "****" for c in iocs["credit_cards"][:5]],
                },
                artifact_path=str(img),
            ))

        if iocs["ssns"]:
            findings.append(make_finding(
                finding_type="SSN_EXTRACTED",
                severity=Severity.HIGH,
                description=(
                    f"OCR extracted {len(iocs['ssns'])} potential SSN pattern(s) "
                    f"from image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={"finding_basis": "candidate", "deterministic_validation": False,
                          "candidate_only": True, "fact_class": "CANDIDATE_ONLY",
                          "counts_toward_unique_evidence": False,
                          "candidate_method": "OCR engine transcription with label-bounded field parsing",
                          "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                          "image_file": str(img), "count": len(iocs["ssns"])},
                artifact_path=str(img),
            ))

        if iocs["passwords"]:
            findings.append(make_finding(
                finding_type="CREDENTIAL_IN_IMAGE",
                severity=Severity.HIGH,
                description=(
                    f"OCR found {len(iocs['passwords'])} password/credential label(s) "
                    f"in image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={"finding_basis": "candidate", "deterministic_validation": False,
                          "candidate_only": True, "fact_class": "CANDIDATE_ONLY",
                          "counts_toward_unique_evidence": False,
                          "candidate_method": "OCR engine transcription with label-bounded field parsing",
                          "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                          "image_file": str(img), "count": len(iocs["passwords"])},
                artifact_path=str(img),
            ))

        if iocs["api_keys"]:
            findings.append(make_finding(
                finding_type="API_KEY_IN_IMAGE",
                severity=Severity.HIGH,
                description=(
                    f"OCR found {len(iocs['api_keys'])} potential API key/token(s) "
                    f"in image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={"finding_basis": "candidate", "deterministic_validation": False,
                          "candidate_only": True, "fact_class": "CANDIDATE_ONLY",
                          "counts_toward_unique_evidence": False,
                          "candidate_method": "OCR engine transcription with label-bounded field parsing",
                          "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                          "image_file": str(img), "samples": iocs["api_keys"][:3]},
                artifact_path=str(img),
            ))

        if iocs["emails"]:
            findings.append(make_finding(
                finding_type="EMAIL_EXTRACTED",
                severity=Severity.MEDIUM,
                description=(
                    f"OCR extracted {len(iocs['emails'])} email address(es) "
                    f"from image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={"finding_basis": "candidate", "deterministic_validation": False,
                          "candidate_only": True, "fact_class": "CANDIDATE_ONLY",
                          "counts_toward_unique_evidence": False,
                          "candidate_method": "OCR engine transcription with label-bounded field parsing",
                          "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                          "image_file": str(img), "samples": iocs["emails"][:10]},
                artifact_path=str(img),
            ))

        if iocs["ips"]:
            findings.append(make_finding(
                finding_type="IP_ADDRESS_IN_IMAGE",
                severity=Severity.MEDIUM,
                description=(
                    f"OCR extracted {len(iocs['ips'])} IP address(es) "
                    f"from image {img.name}."
                ),
                evidence_path=str(evidence_path),
                metadata={"finding_basis": "candidate", "deterministic_validation": False,
                          "candidate_only": True, "fact_class": "CANDIDATE_ONLY",
                          "counts_toward_unique_evidence": False,
                          "candidate_method": "OCR engine transcription with label-bounded field parsing",
                          "candidate_reason": "Character recognition is probabilistic and requires visual or independent exact-source confirmation.",
                          "image_file": str(img), "ips": iocs["ips"][:20]},
                artifact_path=str(img),
            ))

    if not tesseract_available:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="OCR Text Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="tesseract not found — install tesseract-ocr package",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["tesseract not found — install tesseract-ocr package"],
            summary="FAILED — tesseract was required for discovered image evidence but was unavailable.",
            statistics={
                **stats,
                "unresolved_supported_objects": len(image_files) - stats["images_processed"],
                "parser_errors": 1,
                "coverage_complete": False,
                "execution_outcome": "failed",
            },
            class_results=[cr],
        )

    # Write OCR report
    report_path = output_dir / "ocr_report.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "coverage_complete": not errors and stats["images_processed"] == stats["images_scheduled"],
                "warnings": warnings,
                "errors": errors,
                "records": ocr_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write ocr_report.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    stats["unresolved_supported_objects"] = max(0, stats["images_scheduled"] - stats["images_processed"])
    stats["parser_errors"] = len(errors) + stats["images_failed"]

    coverage_complete = (
        not errors
        and stats["images_failed"] == 0
        and stats["images_processed"] == stats["images_scheduled"]
    )
    status = ModuleStatus.COMPLETED if coverage_complete else ModuleStatus.PARTIAL
    summary = (
        f"OCR processed {stats['images_processed']} images; "
        f"{stats['images_with_text']} bearing recoverable text; "
        f"{stats['emails_found']} emails, {stats['credit_cards_found']} credit cards, "
        f"{stats['ssns_found']} SSN-shaped candidates and {stats['passwords_found']} credential-labelled OCR candidates. "
        "Exact machine transcription is retained with a visual-confirmation warning."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    accepted_count = sum(
        1 for finding in findings
        if not bool((finding.metadata or {}).get("candidate_only"))
        and str((finding.metadata or {}).get("finding_basis") or "").casefold() != "candidate"
    )
    candidate_count = len(findings) - accepted_count
    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="OCR Text Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if accepted_count
            else AssuranceVerdict.INDETERMINATE if candidate_count or not coverage_complete
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        skip_reason=(SkipReason.PARTIAL_FAILURE if not accepted_count and candidate_count else None),
        count=accepted_count,
        notes=(
            f"{candidate_count} machine-transcription candidate(s) retained; "
            f"{stats['ocr_corroborated_transcripts']} independently corroborated transcript(s). "
            + "; ".join((errors or warnings)[:3])
        ).strip(),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={**stats, "coverage_complete": coverage_complete,
                    "warnings": warnings,
                    "execution_outcome": (
                        "ran_found_x" if accepted_count and coverage_complete
                        else "ran_with_caveat" if candidate_count and coverage_complete
                        else "ran_found_nothing" if not findings and coverage_complete
                        else "ran_with_caveat"
                    )}, summary=summary,
        class_results=[cr],
    )
