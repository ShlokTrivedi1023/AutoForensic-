"""
filesystem_deep_analyzer.py — Deep File System Forensics Module.

Performs comprehensive file system analysis against a disk image:
  - fls -r full recursive file listing (allocated + deleted)
  - Extension mismatch detection (magic bytes vs declared extension)
  - NTFS Alternate Data Streams (ADS) detection via fls/istat
  - EFS encrypted file detection
  - Timeline reconstruction via mactime (top 50 most-active events)
  - Password-protected file detection (office2john/pdf2john output)

Auto-installs: sleuthkit (apt), python-magic (pip)

Target platform : Kali Linux, Python 3.11
External tools  : fls, mactime, istat (The Sleuth Kit), file, python-magic
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import logging
import re
import struct
import subprocess
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from modules._base import (
    AssuranceVerdict, ClassResult, Finding, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason,
    _run_subprocess, make_finding, utc_now,
)

from core.partition_offset import detect_partition_offset  # noqa: F401
from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.native_filesystem import FatVolume

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Optional: python-magic for magic-byte MIME detection
# ---------------------------------------------------------------------------
# Guard: only import magic if it can be imported without crashing.
# On Windows with a broken libmagic DLL the module import causes a C-level
# access violation that cannot be caught by a Python try/except.
# We use a subprocess probe so the host process is never put at risk.
_magic_lib = None  # type: ignore[assignment]
_MAGIC_AVAILABLE = False

try:
    _probe = subprocess.run(
        [sys.executable, "-c", "import magic"],
        capture_output=True, timeout=10,
    )
    if _probe.returncode == 0:
        try:
            import magic as _magic_lib  # type: ignore[assignment]
            _MAGIC_AVAILABLE = True
        except Exception:
            pass
except Exception:
    pass

_MAGIC_OK = _MAGIC_AVAILABLE

def _ensure_magic() -> bool:
    return _MAGIC_AVAILABLE

def _magic_type(file_path) -> "Optional[str]":
    if not _MAGIC_AVAILABLE or _magic_lib is None:
        return None
    try:
        from pathlib import Path as _Path
        p = _Path(file_path)
        if not p.is_file():
            return None
        return _magic_lib.from_file(str(p), mime=True)  # type: ignore[union-attr]
    except Exception:
        return None

# Pattern to detect mactime/bodyfile timestamp strings mis-parsed as paths.
# These begin with HH:MM:SS and must be excluded from extension mismatch analysis.
_TIMESTAMP_PATTERN = re.compile(r'^\d{1,2}:\d{2}:\d{2}')

MODULE_NAME = "filesystem_deep_analyzer"
FLS_TIMEOUT  = 3600
ICAT_TIMEOUT = 300
MACTIME_TIMEOUT = 1800

# Extension → expected MIME type prefix
_EXT_MIME_MAP: dict[str, list[str]] = {
    "jpg":  ["image/jpeg"],
    "jpeg": ["image/jpeg"],
    "png":  ["image/png"],
    "gif":  ["image/gif"],
    "bmp":  ["image/bmp", "image/x-bmp"],
    "tiff": ["image/tiff"],
    "pdf":  ["application/pdf"],
    "doc":  ["application/msword", "application/vnd.ms-office"],
    "docx": ["application/zip", "application/vnd.openxmlformats"],
    "xls":  ["application/vnd.ms-excel", "application/vnd.ms-office"],
    "xlsx": ["application/zip", "application/vnd.openxmlformats"],
    "ppt":  ["application/vnd.ms-powerpoint", "application/vnd.ms-office"],
    "pptx": ["application/zip", "application/vnd.openxmlformats"],
    "exe":  ["application/x-dosexec", "application/x-executable", "application/x-msdownload"],
    "scr":  ["application/x-dosexec", "application/x-executable", "application/x-msdownload"],
    "dll":  ["application/x-dosexec", "application/x-ms-ne-executable"],
    "mp3":  ["audio/mpeg", "audio/mp3"],
    "mp4":  ["video/mp4"],
    "avi":  ["video/x-msvideo", "video/avi"],
    "zip":  ["application/zip"],
    "rar":  ["application/x-rar"],
    "7z":   ["application/x-7z-compressed"],
    "gz":   ["application/gzip", "application/x-gzip"],
    "txt":  ["text/plain"],
    "html": ["text/html"],
    "xml":  ["text/xml", "application/xml"],
}

# Known file magic bytes for fallback detection
_MAGIC_BYTES: list[tuple[bytes, str, str]] = [
    (b"\xff\xd8\xff",       "image/jpeg", "jpg"),
    (b"\x89PNG\r\n\x1a\n",  "image/png",  "png"),
    (b"GIF87a",             "image/gif",  "gif"),
    (b"GIF89a",             "image/gif",  "gif"),
    (b"BM",                 "image/bmp",  "bmp"),
    (b"%PDF",               "application/pdf", "pdf"),
    (b"PK\x03\x04",         "application/zip", "zip"),
    (b"MZ",                 "application/x-dosexec", "exe"),
    (b"\x7fELF",            "application/x-elf", "elf"),
    (b"Rar!",               "application/x-rar", "rar"),
    (b"\xd0\xcf\x11\xe0",   "application/vnd.ms-office", "doc/xls"),
    (b"\x1f\x8b",           "application/gzip", "gz"),
    (b"7z\xbc\xaf'",        "application/x-7z-compressed", "7z"),
    (b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", None, None),  # null
    (b"<!DOCTYPE html",     "text/html", "html"),
    (b"<html",              "text/html", "html"),
    (b"<?xml",              "text/xml",  "xml"),
    (b"ID3",                "audio/mpeg", "mp3"),
    (b"\xff\xfb",           "audio/mpeg", "mp3"),
    (b"fLaC",               "audio/flac", "flac"),
    (b"OggS",               "audio/ogg", "ogg"),
    (b"\x49\x44\x33",       "audio/mpeg", "mp3"),
]




def _fat_exact_slack_and_free_space(
    analysis_path: Path, offset_bytes: int, *, max_scan_bytes: int
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Deterministically inspect FAT file slack and every free cluster in scope.

    Returns file-slack records, non-zero free-space runs, exact duplicate-object
    matches and caveats.  No signature/entropy heuristic is used.
    """
    slack_records: list[dict[str, Any]] = []
    free_runs: list[dict[str, Any]] = []
    duplicates: list[dict[str, Any]] = []
    caveats: list[str] = []
    volume = FatVolume(analysis_path, offset_bytes)
    files = volume.list_files(max_entries=0)
    active_files = [f for f in files if not f.deleted and not f.is_directory and f.size_bytes > 0 and f.cluster_chain]

    # Exact active-file bytes for free-space duplicate comparison.
    active_contents: list[tuple[Any, bytes, str]] = []
    active_clusters = {c for f in files if not f.deleted for c in f.cluster_chain}
    with analysis_path.open("rb") as fh:
        for entry in active_files:
            used_last = entry.size_bytes % volume.cluster_size
            if used_last:
                last = entry.cluster_chain[-1]
                slack_start = volume.cluster_offset(last) + used_last
                slack_len = volume.cluster_size - used_last
                fh.seek(slack_start)
                slack = fh.read(slack_len)
                if slack and any(slack):
                    slack_records.append({
                        "path": entry.path, "first_cluster": entry.first_cluster,
                        "last_cluster": last, "byte_offset": slack_start,
                        "slack_length": len(slack), "nonzero_bytes": sum(b != 0 for b in slack),
                        "sha256": hashlib.sha256(slack).hexdigest(), "preview_hex": slack[:128].hex(),
                        "preview_text": slack[:512].decode("utf-8", errors="replace"),
                    })
            # Read exact logical file bytes for byte-equality matching.
            content = bytearray()
            for cluster in entry.cluster_chain:
                fh.seek(volume.cluster_offset(cluster))
                content.extend(fh.read(volume.cluster_size))
                if len(content) >= entry.size_bytes:
                    break
            raw = bytes(content[:entry.size_bytes])
            if raw:
                active_contents.append((entry, raw, hashlib.sha256(raw).hexdigest()))

        cluster_count = int(volume.bpb.get("cluster_count") or 0)
        total_scan = cluster_count * volume.cluster_size
        scan_clusters = cluster_count
        if max_scan_bytes > 0 and total_scan > max_scan_bytes:
            scan_clusters = max_scan_bytes // volume.cluster_size
            caveats.append(
                f"Free-space scan limited to {scan_clusters} of {cluster_count} data clusters by max_scan_bytes={max_scan_bytes}; absence cannot be claimed outside the scanned range"
            )

        current_start: int | None = None
        current_data = bytearray()
        current_clusters: list[int] = []

        def flush_run() -> None:
            nonlocal current_start, current_data, current_clusters
            if current_start is None or not current_clusters:
                current_start, current_data, current_clusters = None, bytearray(), []
                return
            blob = bytes(current_data)
            record = {
                "start_cluster": current_clusters[0], "end_cluster": current_clusters[-1],
                "cluster_count": len(current_clusters),
                "byte_offset": volume.cluster_offset(current_clusters[0]),
                "extent_bytes": len(blob), "nonzero_bytes": sum(b != 0 for b in blob),
                "sha256_full_extent": hashlib.sha256(blob).hexdigest(),
                "preview_hex": blob[:128].hex(),
            }
            free_runs.append(record)
            for entry, content, digest in active_contents:
                if len(content) <= len(blob) and blob[:len(content)] == content:
                    duplicates.append({
                        "free_start_cluster": current_clusters[0],
                        "free_end_cluster": current_clusters[-1],
                        "free_byte_offset": volume.cluster_offset(current_clusters[0]),
                        "matched_file": entry.path, "matched_length": len(content),
                        "matched_sha256": digest, "match_method": "exact byte-for-byte prefix equality",
                    })
            current_start, current_data, current_clusters = None, bytearray(), []

        for cluster in range(2, 2 + scan_clusters):
            value = volume.next_cluster(fh, cluster)
            if value != 0:
                flush_run()
                continue
            fh.seek(volume.cluster_offset(cluster))
            data = fh.read(volume.cluster_size)
            if data and any(data):
                if current_start is None:
                    current_start = cluster
                current_clusters.append(cluster)
                current_data.extend(data)
            else:
                flush_run()
        flush_run()

    return slack_records, free_runs, duplicates, caveats


# ---------------------------------------------------------------------------
# LNK parsing helpers
# ---------------------------------------------------------------------------

def _parse_lnk_builtin(lnk_bytes: bytes) -> dict:
    """
    Parse Windows LNK (Shell Link) file minimally.
    Returns dict with target_path, creation_time, write_time, access_time.
    Spec: MS-SHLLINK (ShellLinkHeader at offset 0).
    """
    import struct as _struct
    from datetime import datetime, timezone

    if len(lnk_bytes) < 76:
        return {}
    magic = _struct.unpack_from("<I", lnk_bytes, 0)[0]
    if magic != 0x0000004C:
        return {}

    def _filetime_to_iso(ft_bytes):
        ft = _struct.unpack_from("<Q", ft_bytes)[0]
        if ft == 0:
            return ""
        EPOCH_DIFF = 116444736000000000
        ts = (ft - EPOCH_DIFF) / 10_000_000
        try:
            return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
        except (OSError, ValueError, OverflowError):
            return ""

    creation_time = _filetime_to_iso(lnk_bytes[28:36])
    access_time   = _filetime_to_iso(lnk_bytes[36:44])
    write_time    = _filetime_to_iso(lnk_bytes[44:52])

    link_flags  = _struct.unpack_from("<I", lnk_bytes, 20)[0]
    target_path = ""
    has_id_list   = bool(link_flags & 0x1)
    has_link_info = bool(link_flags & 0x4)
    offset = 0x4C
    if has_id_list and offset + 2 <= len(lnk_bytes):
        id_list_size = _struct.unpack_from("<H", lnk_bytes, offset)[0]
        offset += 2 + id_list_size
    if has_link_info and offset + 20 <= len(lnk_bytes):
        li_flags = _struct.unpack_from("<I", lnk_bytes, offset + 4)[0]
        if li_flags & 0x1 and offset + 20 <= len(lnk_bytes):
            lbp_off    = _struct.unpack_from("<I", lnk_bytes, offset + 16)[0]
            path_start = offset + lbp_off
            path_end   = lnk_bytes.find(b'\x00', path_start)
            if path_end > path_start:
                target_path = lnk_bytes[path_start:path_end].decode("latin-1", errors="replace")

    return {
        "target_path":   target_path,
        "creation_time": creation_time,
        "access_time":   access_time,
        "write_time":    write_time,
    }


def _parse_lnk_file(lnk_path, logger) -> dict:
    """Parse a .lnk file: try lnkparse3 first, fall back to built-in parser."""
    from pathlib import Path as _P
    lnk_path = _P(lnk_path)
    try:
        import lnkparse3
        lnk = lnkparse3.lnk_file(str(lnk_path))
        lnk_json = lnk.get_json()
        header = lnk_json.get("header", {})
        link_info = lnk_json.get("link_info", {})
        string_data = lnk_json.get("string_data", {})
        extra_data = lnk_json.get("extra_data", {})
        return {
            "target_path":   string_data.get("relative_path", ""),
            "working_dir":   string_data.get("working_directory", ""),
            "net_name":      link_info.get("location_info", {}).get("net_name", ""),
            "machine_id":    extra_data.get("machine_id", ""),
            "volume_serial": link_info.get("location_info", {}).get("volume_serial_number", ""),
            "creation_time": header.get("creation_time", ""),
            "access_time":   header.get("access_time", ""),
            "write_time":    header.get("write_time", ""),
        }
    except Exception:
        try:
            parsed = _parse_lnk_builtin(lnk_path.read_bytes())
            if parsed:
                return {
                    "target_path":   parsed.get("target_path", ""),
                    "working_dir":   "",
                    "net_name":      "",
                    "machine_id":    "",
                    "volume_serial": "",
                    "creation_time": parsed.get("creation_time", ""),
                    "access_time":   parsed.get("access_time", ""),
                    "write_time":    parsed.get("write_time", ""),
                }
            return {}
        except Exception as exc:
            if logger:
                logger.debug("LNK parse failed for %s: %s", lnk_path.name, exc)
            return {}


def _parse_ts_to_float(ts: str) -> float:
    if not ts:
        return 0.0
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


def _parse_lnk_files(
    fls_entries: list[dict],
    analysis_path: Path,
    partition_offset: int,
    output_dir: Path,
    logger: logging.Logger,
) -> list[dict]:
    """
    Parse every .lnk file found in fls_entries via icat + _parse_lnk_file.
    Returns list of dicts with: lnk_path, inode, target_path, working_dir,
    net_name, machine_id, volume_serial, creation_time, access_time, write_time.
    """
    _sudo = []
    off = ["-o", str(partition_offset)] if partition_offset > 0 else []

    lnk_entries = [e for e in fls_entries if e.get("ext", "").lower() == "lnk"]

    logger.info("[FSDEEP] LNK files found: %d", len(lnk_entries))

    lnk_dir = output_dir / "lnk_files"
    lnk_dir.mkdir(exist_ok=True)
    results = []

    for entry in lnk_entries:
        inode = entry.get("inode", "")
        if not inode:
            continue
        safe_name = re.sub(r"[^\w.\-]", "_", Path(entry["path"]).name)
        lnk_file = lnk_dir / f"{inode}_{safe_name}"

        try:
            result = subprocess.run(
                _sudo + ["icat"] + off + [str(analysis_path), inode],
                capture_output=True, timeout=30, shell=False,
            )
            if result.returncode != 0 or not result.stdout:
                continue
            lnk_file.write_bytes(result.stdout)
        except Exception as exc:
            logger.debug("[FSDEEP] icat lnk failed %s: %s", inode, exc)
            continue

        parsed = _parse_lnk_file(lnk_file, logger)
        if parsed:
            record = {
                "lnk_path":      entry["path"],
                "inode":         inode,
                "target_path":   parsed.get("target_path", ""),
                "working_dir":   parsed.get("working_dir", ""),
                "net_name":      parsed.get("net_name", ""),
                "machine_id":    parsed.get("machine_id", ""),
                "volume_serial": parsed.get("volume_serial", ""),
                "creation_time": parsed.get("creation_time", ""),
                "access_time":   parsed.get("access_time", ""),
                "write_time":    parsed.get("write_time", ""),
            }
            results.append(record)

    logger.info("[FSDEEP] LNK files parsed: %d", len(results))
    return results


def _detect_batch_transfer(lnk_records: list[dict]) -> list[dict]:
    """
    Flag groups of 5+ LNK files from the same remote host with access
    timestamps within 10 seconds of each other (batch network transfer).
    """
    by_host: dict[str, list[dict]] = defaultdict(list)
    for rec in lnk_records:
        host = rec.get("net_name", "").strip()
        if host:
            by_host[host].append(rec)

    flagged = []
    for host, records in by_host.items():
        if len(records) < 5:
            continue
        timed = []
        for r in records:
            ts = _parse_ts_to_float(r.get("access_time", ""))
            if ts > 0:
                timed.append((ts, r))
        if len(timed) < 5:
            continue
        timed.sort(key=lambda x: x[0])
        for i in range(len(timed) - 4):
            window = timed[i:i+5]
            span = window[-1][0] - window[0][0]
            if span <= 10.0:
                flagged.append({
                    "hostname":  host,
                    "count":     len(window),
                    "timestamp": window[0][1].get("access_time", ""),
                    "files":     [r.get("lnk_path", "")[-60:] for _, r in window],
                })
                break
    return flagged


# ---------------------------------------------------------------------------
# run()
# ---------------------------------------------------------------------------

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception:
            pass

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    findings: list[Finding] = []
    errors: list[str] = []
    warnings: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        return _fail(MODULE_NAME, case_id, start_time,
                     f"Evidence not found: {evidence_path}", coc_logger, logger)

    suffix = evidence_path.suffix.lower()
    # analysis_path: mounted ewf1 (raw) or block device; falls back to evidence_path
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset") if config.get("partition_offset") is not None else 0)
    if partition_offset == 0 and "partition_offset" not in config:
        from core.partition_offset import detect_partition_offset_mounted
        partition_offset = detect_partition_offset_mounted(analysis_path, logger)
    logger.info("[FSDEEP] Partition offset: %d sectors", partition_offset)
    tlog(f"[FSDEEP] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")
    tlog(f"[FSDEEP] python-magic: {_MAGIC_AVAILABLE}")

    # ── Filesystem detection (STEP 5c) ─────────────────────────────────────
    # Detect the FS once so fls uses the right `-f` (or auto-detect) instead of
    # assuming NTFS, and so NTFS-only classes are marked absent-by-design on FAT.
    _ws = config.get("_working_set") if isinstance(config.get("_working_set"), dict) else {}
    fs_type = str((_ws or {}).get("filesystem_type") or "").lower() or _detect_fs_type(analysis_path, partition_offset, logger)
    _fat_like = bool(fs_type and (str(fs_type).lower().startswith("fat") or str(fs_type).lower() == "exfat"))
    tlog(f"[FSDEEP] Filesystem type: {fs_type or 'auto-detect'}"
         + (" (NTFS-only classes absent by design)" if _fat_like else ""))
    slack_records: list[dict[str, Any]] = []
    nonzero_free_runs: list[dict[str, Any]] = []
    unallocated_duplicates: list[dict[str, Any]] = []
    deep_scan_caveats: list[str] = []
    if _fat_like and analysis_path.is_file():
        try:
            slack_records, nonzero_free_runs, unallocated_duplicates, deep_scan_caveats = _fat_exact_slack_and_free_space(
                analysis_path, partition_offset * 512,
                max_scan_bytes=int(config.get("max_deep_free_space_scan_bytes", 0) or 0),
            )
            tlog(f"[FSDEEP] FAT exact slack: {len(slack_records)} non-zero record(s); non-zero free-space runs: {len(nonzero_free_runs)}; exact allocated/unallocated duplicates: {len(unallocated_duplicates)}")
            warnings.extend(deep_scan_caveats)
            for record in slack_records:
                findings.append(make_finding(
                    "FILE_SLACK_DATA", Severity.MEDIUM,
                    f"{record['slack_length']} byte(s) of file slack after the logical end of {record['path']} contain {record['nonzero_bytes']} non-zero byte(s).",
                    str(evidence_path),
                    {**record, **deterministic_metadata("FAT cluster-chain and logical-size boundary comparison", validators=["FatVolume", "exact byte read"])},
                ))
            for record in nonzero_free_runs:
                findings.append(make_finding(
                    "NONZERO_UNALLOCATED_RUN", Severity.INFO,
                    f"A contiguous non-zero run exists in free FAT clusters {record['start_cluster']}-{record['end_cluster']} ({record['extent_bytes']} bytes).",
                    str(evidence_path),
                    {**record, **deterministic_metadata("FAT allocation-table zero-entry scan and exact extent hashing", validators=["FatVolume.next_cluster", "SHA-256"])},
                ))
            for record in unallocated_duplicates:
                findings.append(make_finding(
                    "UNALLOCATED_DUPLICATE_OBJECT", Severity.MEDIUM,
                    f"Free clusters {record['free_start_cluster']}-{record['free_end_cluster']} begin with a byte-identical copy of {record['matched_file']} ({record['matched_length']} bytes).",
                    str(evidence_path),
                    {**record, **deterministic_metadata("exact byte-for-byte equality and SHA-256", validators=["binary equality", "SHA-256"])},
                ))
        except Exception as exc:
            deep_scan_caveats.append(f"FAT exact slack/free-space analysis failed: {exc}")
            warnings.append(deep_scan_caveats[-1])

    # ── Step 1: fls -r full recursive listing ──────────────────────────────
    tlog("[FSDEEP] Running fls -r for complete file system listing...")
    fls_entries, fls_raw = _run_fls_full(analysis_path, logger, errors,
                                          offset=partition_offset, fs_type=fs_type)
    native_listing_used = False
    native_root_value = (_ws or {}).get("extracted_files_dir") or (_ws or {}).get("mounted_fs_root")
    native_root = Path(str(native_root_value)) if native_root_value else None
    if not fls_entries and native_root is not None and native_root.is_dir():
        native_entries: list[dict] = []
        raw_lines: list[str] = []
        native_manifest_path = native_root.parent / "native_filesystem_manifest.json"
        native_manifest_entries: list[dict] = []
        if native_manifest_path.is_file():
            try:
                native_manifest_entries = list(
                    (json.loads(native_manifest_path.read_text(encoding="utf-8", errors="replace")) or {}).get("files") or []
                )
            except Exception as exc:
                errors.append(f"native filesystem manifest could not be read: {exc}")
        if native_manifest_entries:
            for entry in native_manifest_entries:
                if not isinstance(entry, dict):
                    continue
                evidence_path_value = str(entry.get("path") or entry.get("name") or "").strip()
                relative = evidence_path_value.lstrip("/")
                is_directory = bool(entry.get("is_directory"))
                name = str(entry.get("name") or Path(relative).name)
                ext = Path(name).suffix.lower().lstrip(".") if not is_directory else ""
                record = {
                    "path": relative,
                    "name": name,
                    "inode": str(entry.get("first_cluster") or ""),
                    "deleted": bool(entry.get("deleted")),
                    "ext": ext,
                    "size": int(entry.get("size_bytes") or 0) if not is_directory else 0,
                    "mtime": str(entry.get("modified") or ""),
                    "atime": str(entry.get("accessed") or ""),
                    "ctime": str(entry.get("created") or ""),
                    "crtime": str(entry.get("created") or ""),
                    "type": "directory" if is_directory else "file",
                    "timestamp_source": "native filesystem metadata",
                }
                native_entries.append(record)
                marker = "*" if record["deleted"] else ""
                raw_lines.append(("d/d" if is_directory else "r/r") + f"{marker} {record['inode'] or '0'}: {relative}")
        else:
            # Last-resort corpus enumeration. Host-copy timestamps are omitted
            # because they describe extraction, not the source filesystem.
            for item in sorted(native_root.rglob("*")):
                try:
                    relative = item.relative_to(native_root).as_posix()
                    is_file = item.is_file()
                    size = item.stat().st_size if is_file else 0
                except (OSError, ValueError):
                    continue
                ext = item.suffix.lower().lstrip(".") if is_file else ""
                record = {
                    "path": relative, "name": item.name, "inode": "",
                    "deleted": False, "ext": ext, "size": size,
                    "mtime": "", "atime": "", "ctime": "", "crtime": "",
                    "type": "file" if is_file else "directory",
                    "timestamp_source": "host timestamps intentionally omitted",
                }
                native_entries.append(record)
                raw_lines.append(("r/r" if is_file else "d/d") + f" 0: {relative}")
        fls_entries = native_entries
        fls_raw = "\n".join(raw_lines)
        native_listing_used = True
        errors = [e for e in errors if "fls" not in str(e).lower()]
        tlog(f"[FSDEEP] Native filesystem enumeration used: {len(fls_entries)} evidence-derived entries")
    if not fls_entries and any("partition offset" in e for e in errors):
        from modules._base import ModuleStatus as _MS
        end_time = utc_now()
        from datetime import datetime as _dt
        dur = (_dt.fromisoformat(end_time) - _dt.fromisoformat(start_time)).total_seconds()
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=_MS.FAILED_OFFSET,
            start_time=start_time, end_time=end_time, duration_seconds=dur,
            errors=errors,
            summary="FAILED_OFFSET: TSK could not read filesystem — partition offset not detected. Manual intervention required.",
            class_results=[ClassResult(
                locus=Locus.FILE_SYSTEM,
                artefact_class="File System Artefacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.PARTIAL_FAILURE,
                count=0,
            )],
        )
    total_files  = len(fls_entries)
    directory_entries = [e for e in fls_entries if e.get("type") == "directory"]
    regular_file_entries = [e for e in fls_entries if e.get("type") != "directory"]
    deleted_files = [e for e in fls_entries if e.get("deleted")]
    tlog(
        f"[FSDEEP] fls: {total_files} total entries "
        f"({len(regular_file_entries)} files, {len(directory_entries)} directories), "
        f"{len(deleted_files)} deleted"
    )

    # Save full fls output
    fls_out_path = output_dir / "fls_output.txt"
    fls_out_path.write_text(fls_raw, encoding="utf-8", errors="replace")
    tlog(f"[FSDEEP] fls output saved: {fls_out_path}")

    # Extension statistics
    ext_counts: dict[str, int] = Counter(
        e.get("ext", "").lower() for e in fls_entries if e.get("ext")
    )  # type: ignore[assignment]

    findings.append(make_finding(
        "FILESYSTEM_LISTING_SUMMARY", Severity.INFO,
        f"Filesystem listing: {total_files} parser entries, "
        f"{len(deleted_files)} marked deleted/unallocated. "
        f"Top extensions: " + ", ".join(f"{e}({n})" for e, n in
            sorted(ext_counts.items(), key=lambda x: -x[1])[:10]),
        str(evidence_path),
        {
            "total_entries": total_files,
            "file_entries": len(regular_file_entries),
            "directory_entries": len(directory_entries),
            "deleted_entries": len(deleted_files),
            "ext_counts": dict(sorted(ext_counts.items(), key=lambda x: -x[1])[:20]),
            "listing_manifest": str(fls_out_path),
            "listing_source": "native evidence tree" if native_listing_used else "Sleuth Kit fls",
            **deterministic_metadata(
                "exact count of retained filesystem parser records",
                validators=["retained listing manifest", "integer count"],
                semantic_limit="Parser-entry count; unique logical-file count requires separate record reconciliation",
            ),
        },
        artifact_path=str(fls_out_path),
    ))

    # ── Step 1b: ADS enumeration via istat ──────────────────────────────────
    # Collected here but NOT turned into findings yet: the istat enumeration and
    # the fls listing (Step 3) both see the same streams, so they are merged
    # into one deduplicated list and emitted once — the ADS count in findings
    # and in the statistics then comes from a single computation.  ADS is
    # NTFS-only, so skip the istat sweep entirely on FAT/exFAT.
    _device = config.get("_ewf_device") or str(analysis_path)
    _offset = config.get("_offset_sectors") if config.get("_offset_sectors") is not None else partition_offset
    _ads_list = [] if _fat_like else _enumerate_ads(_device, _offset, fls_entries, output_dir, logger)
    tlog(f"[FSDEEP] istat ADS enumeration: {len(_ads_list)} named DATA streams found")

    # ── Step 2a: Double-extension filename detection ─────────────────────────
    # This is a filename heuristic (e.g. "invoice.pdf.exe"), a distinct signal
    # from magic-byte-vs-extension.  It keeps its own finding type and manifest
    # slot so it never masquerades as a magic-byte mismatch count.
    tlog("[FSDEEP] Detecting double-extension filenames...")
    double_extensions = _detect_extension_mismatches(fls_entries, logger)
    tlog(f"[FSDEEP] Double-extension filenames: {len(double_extensions)}")
    for mm in double_extensions:
        findings.append(make_finding(
            "DOUBLE_EXTENSION_FILENAME", Severity.INFO,
            f"File {mm['name']} has double extension. "
            f"Declared: {mm['declared_ext']}; inner: {mm['inner_ext']}. "
            "This is an observable filename-masquerading anomaly; the filename alone does not establish user intent, malware execution, or an anti-forensic act.",
            mm["path"],
            {
                "path":          mm["path"],
                "filename":      mm["name"],
                "declared_ext":  mm["declared_ext"],
                "inner_ext":     mm.get("inner_ext", ""),
                "detected_mime": mm.get("detected_mime", ""),
                "expected_ext":  mm.get("expected_ext", ""),
                "method":        mm.get("method", ""),
                "mtime":         mm.get("mtime", ""),
                "atime":         mm.get("atime", ""),
                "ctime":         mm.get("ctime", ""),
                "crtime":        mm.get("crtime", ""),
                "title":         mm["title"],
                **deterministic_metadata(
                    "exact filename suffix tokenisation",
                    validators=["pathlib.Path.suffixes"],
                    semantic_limit="Filename anomaly only; no intent, execution or maliciousness inferred",
                ),
            },
        ))

    # ── Step 2b: Magic-byte-vs-extension (consumed, single source of truth) ──
    # The authoritative magic-byte-vs-extension result is computed once (by
    # file_signature_analyzer) and published on the shared working-set; this
    # module consumes that exact result so the report never shows two different
    # counts.  When no publisher ran, resolve_signature_mismatches computes the
    # same result over the shared corpus as an order-independent fallback.
    from modules.signature_check import resolve_signature_mismatches
    from modules._base import resolve_corpus_roots
    _ws = config.get("_working_set", {})
    mismatches = resolve_signature_mismatches(
        _ws if isinstance(_ws, dict) else None,
        corpus_roots=resolve_corpus_roots(_ws, output_dir=output_dir),
        logger=logger,
    )
    tlog(f"[FSDEEP] Magic-byte-vs-extension mismatches (shared): {len(mismatches)}")

    # ── Step 3: NTFS ADS detection ──────────────────────────────────────────
    # ADS is an NTFS-only construct; on FAT/exFAT it cannot exist, so skip the
    # scan (it is recorded VERIFIED_ABSENT-by-design in the class results).
    tlog("[FSDEEP] Scanning for NTFS Alternate Data Streams (ADS)...")
    _fls_ads = [] if _fat_like else _detect_ads(fls_entries, logger)
    # Single source of truth: merge the istat and fls detections and dedupe, so
    # each physical stream is one entry — one finding, one count.
    ads_entries = _merge_ads(_ads_list, _fls_ads)
    tlog(f"[FSDEEP] NTFS ADS entries (merged, deduped): {len(ads_entries)}"
         + (" (skipped — non-NTFS filesystem)" if _fat_like else ""))

    ads_out_dir = output_dir / "ads"
    ads_out_dir.mkdir(exist_ok=True)
    _sudo_ads = []
    _off_ads = ["-o", str(partition_offset)] if partition_offset > 0 else []

    for ads in ads_entries:
        inode = ads.get("inode", "")
        stream_name = ads.get("stream_name", "stream")
        safe_name = re.sub(r"[^\w.\-]", "_", f"{inode}_{stream_name}")
        ads_file = ads_out_dir / safe_name

        if inode:
            try:
                result = subprocess.run(
                    _sudo_ads + ["icat"] + _off_ads + [str(analysis_path), inode],
                    capture_output=True, timeout=60, shell=False,
                )
                if result.returncode == 0 and result.stdout:
                    ads_file.write_bytes(result.stdout)
                    sha256 = hashlib.sha256(result.stdout).hexdigest()
                    ads["extracted_path"] = str(ads_file)
                    ads["sha256"] = sha256
                    ads["size_extracted"] = len(result.stdout)
            except Exception as exc:
                logger.debug("[FSDEEP] ADS icat failed %s: %s", inode, exc)

        size = ads.get("size_extracted", ads.get("size", "?"))
        # Single canonical ADS finding type — the report layer (5W1H, narrative,
        # recommendations) keys on ALTERNATE_DATA_STREAM.
        findings.append(make_finding(
            "ALTERNATE_DATA_STREAM", Severity.HIGH,
            f"NTFS ADS: {ads.get('host_file', ads.get('path', '?'))}:{ads.get('stream_name', '?')} "
            f"({size} bytes). "
            f"SHA-256: {ads.get('sha256', 'not extracted')}. "
            "Alternate Data Streams can conceal executable code or documents.",
            str(evidence_path),
            ads,
            artifact_path=ads.get("extracted_path"),
        ))

    # ── Step 3b: LNK shortcut parsing ───────────────────────────────────────
    tlog("[FSDEEP] Parsing .lnk shortcut files...")
    lnk_records = _parse_lnk_files(
        fls_entries, analysis_path, partition_offset, output_dir, logger
    )
    tlog(f"[FSDEEP] LNK files parsed: {len(lnk_records)}")

    batch_transfers = _detect_batch_transfer(lnk_records)
    for bt in batch_transfers:
        findings.append(make_finding(
            "BATCH_NETWORK_TRANSFER", Severity.HIGH,
            f"Batch network file transfer from '{bt['hostname']}': "
            f"{bt['count']} files accessed within 10 seconds at {str(bt['timestamp'])[:19]}. "
            "5+ LNK files from same host in rapid succession indicates automated bulk transfer.",
            str(evidence_path),
            bt,
        ))

    if lnk_records:
        findings.append(make_finding(
            "LNK_FILES_PARSED", Severity.INFO,
            f"{len(lnk_records)} Windows shortcut (.lnk) file(s) parsed. "
            f"{len(batch_transfers)} potential batch network transfer(s) detected.",
            str(evidence_path),
            {"lnk_count": len(lnk_records), "batch_transfers": len(batch_transfers),
             "sample": lnk_records[:5]},
            artifact_path=str(output_dir / "lnk_files"),
        ))

    # ── Step 4: EFS encrypted file detection ────────────────────────────────
    # EFS is NTFS-only; skip on FAT/exFAT (recorded VERIFIED_ABSENT-by-design).
    tlog("[FSDEEP] Detecting EFS encrypted files...")
    efs_files = _select_efs(fls_entries, _fat_like)
    tlog(f"[FSDEEP] EFS encrypted files: {len(efs_files)}"
         + (" (skipped — non-NTFS filesystem)" if _fat_like else ""))
    # One finding per encrypted item, so each EFS-encrypted file is surfaced
    # distinctly rather than collapsed into a single count.
    for efs in efs_files:
        findings.append(make_finding(
            "EFS_ENCRYPTED_FILE", Severity.HIGH,
            f"EFS (Encrypting File System) encrypted file: {efs.get('path', '')}. "
            "Accessible only to the file owner; recovery requires the user's "
            "EFS certificate private key.",
            str(evidence_path),
            {"path": efs.get("path", ""), "inode": efs.get("inode", ""),
             "flags": efs.get("flags", "")},
        ))

    # ── Step 5: Timeline reconstruction ─────────────────────────────────────
    tlog("[FSDEEP] Reconstructing timeline via mactime...")
    _timeline_error_start = len(errors)
    timeline_entries, mactime_raw = _run_mactime(analysis_path, logger, errors,
                                                  offset=partition_offset)
    timeline_source = "mactime/fls" if timeline_entries else "none"

    # Equivalent deterministic fallback: fls/native enumeration already contains
    # the source MACB values.  Build the event list directly from those metadata
    # records when the presentation utility (mactime) is unavailable.
    if not timeline_entries and fls_entries:
        _fallback_events: list[dict] = []
        for _entry in fls_entries:
            _path = str(_entry.get("path") or _entry.get("name") or "")
            for _field, _label in (("mtime", "modified"), ("atime", "accessed"),
                                   ("ctime", "changed"), ("crtime", "created")):
                _value = str(_entry.get(_field) or "").strip()
                if not _value or _value in {"0", "None", "-"}:
                    continue
                _fallback_events.append({
                    "timestamp": _value, "event": f"{_label}: {_path}",
                    "path": _path, "type": _label,
                    "deleted": bool(_entry.get("deleted")),
                    "source": str(_entry.get("timestamp_source") or "filesystem metadata"),
                })
        if _fallback_events:
            timeline_entries = sorted(_fallback_events, key=lambda item: str(item.get("timestamp", "")))
            timeline_source = ("native filesystem metadata" if native_listing_used
                               else "Sleuth Kit fls metadata")
            _new_timeline_errors = errors[_timeline_error_start:]
            if _new_timeline_errors:
                warnings.extend(_new_timeline_errors)
                del errors[_timeline_error_start:]
            mactime_raw = "\n".join(
                f"{e['timestamp']},{e['type']},{e['path']}" for e in timeline_entries
            )
            tlog(f"[FSDEEP] Direct metadata timeline fallback used: {len(timeline_entries)} events")

    tlog(f"[FSDEEP] Timeline: {len(timeline_entries)} events via {timeline_source}")

    if timeline_entries:
        # Save full mactime output
        mac_out = output_dir / "mactime_output.txt"
        mac_out.write_text(mactime_raw[:5_000_000], encoding="utf-8", errors="replace")
        tlog(f"[FSDEEP] mactime output saved: {mac_out}")

        top_50 = timeline_entries[:50]
        findings.append(make_finding(
            "FILESYSTEM_TIMESTAMP_RECORD_SUMMARY", Severity.INFO,
            f"MAC timeline reconstructed: {len(timeline_entries)} events. "
            f"Top 50 events span from "
            f"{top_50[0].get('timestamp','?')[:10]} to "
            f"{top_50[-1].get('timestamp','?')[:10]}. "
            "Timeline shows file creation, modification, and access times.",
            str(evidence_path),
            {
                "total_events": len(timeline_entries),
                "top_50": top_50,
                "timeline_manifest": str(mac_out),
                "timeline_source": timeline_source,
                **deterministic_metadata(
                    "exact count of retained filesystem timestamp parser records",
                    validators=["retained timeline output", "integer count"],
                    semantic_limit="Filesystem-only timestamp summary; cross-corpus chronology belongs to the dedicated timeline builder",
                ),
            },
            artifact_path=str(mac_out),
        ))

    # ── Step 6: Password-capable and structurally encrypted files ───────────
    tlog("[FSDEEP] Classifying password-capable files and verifying encryption flags...")
    from modules._base import iter_corpus_files
    corpus_files = iter_corpus_files(config.get("_working_set", {}), output_dir=output_dir, deduplicate_by_hash=True)
    pw_capable, pw_verified = _classify_password_protection(corpus_files)
    verified_paths = {str(item["path"]) for item in pw_verified}
    pw_unverified = [item for item in pw_capable if str(item["path"]) not in verified_paths]
    tlog(
        f"[FSDEEP] Password-capable unique files: {len(pw_capable)}; "
        f"structurally verified encrypted: {len(pw_verified)}; "
        f"unverified capability candidates: {len(pw_unverified)}"
    )
    for item in pw_verified:
        findings.append(make_finding(
            "PASSWORD_PROTECTED_ARCHIVE", Severity.INFO,
            f"Structurally verified password protection in {Path(item['path']).name}: {item['validation']}.",
            str(item["path"]),
            {
                "path": str(item["path"]),
                "format": item["format"],
                "validation": item["validation"],
                **deterministic_metadata(
                    "format-level encryption flag validation",
                    validators=item.get("validators") or ["container parser"],
                    semantic_limit="Protection state only; purpose and intent are not inferred",
                ),
            },
        ))
    if pw_unverified:
        findings.append(make_finding(
            "PASSWORD_CAPABLE_FILE_CANDIDATES", Severity.INFO,
            f"{len(pw_unverified)} unique file(s) use formats capable of password protection, "
            "but no structural encryption flag was verified for those files.",
            str(evidence_path),
            {
                "count": len(pw_unverified),
                "files": [str(item["path"]) for item in pw_unverified],
                **candidate_metadata(
                    "format capability triage",
                    reason="A password-capable format does not establish that the particular file is encrypted",
                ),
            },
        ))

    # ── Screenshots ─────────────────────────────────────────────────────────
    try:
        from modules.screenshot_capture import capture_terminal, capture_table, record_screenshot
        sc_dir = output_dir / "screenshots"
        sc_dir.mkdir(exist_ok=True)
        sc_idx = sc_dir / "screenshots_index.json"

        # Fig 3.1 — fls terminal output (first 80 lines)
        fls_preview = "\n".join(terminal_lines[:80])
        png = capture_terminal("fls recursive file listing", fls_preview,
                               sc_dir, "fig_3_1",
                               "Fig 3.1: fls -r output showing allocated and deleted files")
        if png:
            record_screenshot(sc_idx, "fig_3_1", png,
                              "Fig 3.1: fls -r output showing allocated and deleted files")

        # Fig 3.2 — extension mismatch table
        if mismatches:
            mm_rows = [[mm.get("path","?")[-50:], mm.get("declared_ext","?"),
                        mm.get("detected_mime","?")[:30], mm.get("expected_ext","?")]
                       for mm in mismatches[:25]]
            png = capture_table("Extension Mismatch Detection",
                                ["File Path", "Declared Ext", "Detected MIME", "Expected Ext"],
                                mm_rows, sc_dir, "fig_3_2",
                                "Fig 3.2: Files with mismatched extension vs magic bytes")
            if png:
                record_screenshot(sc_idx, "fig_3_2", png,
                                  "Fig 3.2: Files with mismatched extension vs magic bytes")

        # Fig 3.3 — NTFS ADS table
        if ads_entries:
            ads_rows = [[ads.get("path","?")[-50:], ads.get("stream_name","?"),
                         str(ads.get("size","?"))]
                        for ads in ads_entries[:25]]
            png = capture_table("NTFS Alternate Data Streams",
                                ["File Path", "Stream Name", "Size (bytes)"],
                                ads_rows, sc_dir, "fig_3_3",
                                "Fig 3.3: NTFS ADS — hidden data streams detected")
            if png:
                record_screenshot(sc_idx, "fig_3_3", png,
                                  "Fig 3.3: NTFS ADS — hidden data streams detected")

        # Fig 3.4 — MAC timeline
        if timeline_entries:
            tl_rows = [[e.get("timestamp","?")[:19], e.get("type","?")[:12],
                        e.get("path","?")[-60:]]
                       for e in timeline_entries[:30]]
            png = capture_table("MAC Timeline — Top Events",
                                ["Timestamp", "Event Type", "File Path"],
                                tl_rows, sc_dir, "fig_3_4",
                                "Fig 3.4: MAC timeline — most recently modified files")
            if png:
                record_screenshot(sc_idx, "fig_3_4", png,
                                  "Fig 3.4: MAC timeline — most recently modified files")

        # Fig 3.5 — file type distribution
        if ext_counts:
            top_ext = sorted(ext_counts.items(), key=lambda x: -x[1])[:20]
            ext_rows = [[f".{ext}" if ext else "(none)", str(cnt)]
                        for ext, cnt in top_ext]
            png = capture_table("File Type Distribution",
                                ["Extension", "Count"],
                                ext_rows, sc_dir, "fig_3_5",
                                "Fig 3.5: File type distribution by extension")
            if png:
                record_screenshot(sc_idx, "fig_3_5", png,
                                  "Fig 3.5: File type distribution by extension")

        tlog(f"[FSDEEP] Screenshots saved to {sc_dir}")
    except Exception as _sc_exc:
        logger.warning("[FSDEEP] Screenshot capture failed: %s", _sc_exc)

    # ── Write manifest ───────────────────────────────────────────────────────
    manifest = {
        "module":        MODULE_NAME,
        "case_id":       case_id,
        "generated_at":  utc_now(),
        "total_files":   sum(1 for e in fls_entries if e.get("type") == "file" and not e.get("deleted")),
        "listing_entries": total_files,
        "active_regular_files": sum(1 for e in fls_entries if e.get("type") == "file" and not e.get("deleted")),
        "directories": sum(1 for e in fls_entries if e.get("type") == "directory" and not e.get("deleted")),
        "deleted_files": len(deleted_files),
        "timestamp_source": "native filesystem metadata" if native_listing_used else "Sleuth Kit filesystem metadata",
        "ext_counts":    dict(sorted(ext_counts.items(), key=lambda x: -x[1])),
        # Magic-byte-vs-extension count is the shared/consumed result; the
        # double-extension count is the distinct filename signal.
        "extension_mismatches": len(mismatches),
        "double_extensions":    len(double_extensions),
        "ads_entries":   len(ads_entries),
        "efs_files":     len(efs_files),
        "timeline_events": len(timeline_entries),
        "timeline_source": timeline_source,
        "findings":      len(findings),
        "mismatches":    mismatches,
        "double_extension_list": double_extensions,
        "ads_list":      ads_entries,
        "efs_list":      [e["path"] for e in efs_files],
        "timeline_entries": timeline_entries,
        "password_capable_files": [str(f["path"]) for f in pw_capable],
        "password_verified_files": [str(f["path"]) for f in pw_verified],
        "file_slack_records": slack_records,
        "nonzero_free_space_runs": nonzero_free_runs,
        "unallocated_duplicate_objects": unallocated_duplicates,
        "deep_scan_caveats": deep_scan_caveats,
        "warnings":      warnings,
        "errors":        errors,
    }
    manifest_path = output_dir / "filesystem_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    for finding in findings:
        if not getattr(finding, "artifact_path", None):
            finding.artifact_path = str(manifest_path)
        finding.metadata.setdefault("report_file", str(manifest_path))

    terminal_output = "\n".join(terminal_lines)
    (output_dir / "terminal_output.txt").write_text(terminal_output, encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[FSDEEP] Completed in {wall_elapsed:.1f}s — {len(findings)} findings")

    status = (ModuleStatus.COMPLETED if not errors
              else ModuleStatus.PARTIAL if fls_entries
              else ModuleStatus.FAILED)

    summary = (
        f"File system analysis: {total_files} filesystem listing entries, {len(deleted_files)} deleted, "
        f"{len(mismatches)} extension mismatch(es), {len(ads_entries)} ADS, "
        f"{len(efs_files)} EFS encrypted, {len(timeline_entries)} timeline events, "
        f"{len(slack_records)} non-zero slack record(s), {len(nonzero_free_runs)} non-zero free-space run(s). "
        f"{len(findings)} findings."
    )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED
                else EventType.MODULE_FAILED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value,
                           "findings": len(findings), "duration_sec": round(wall_elapsed, 2)},
            )
        except Exception:
            pass

    _fls_not_found = any("fls not found" in e for e in errors) and not native_listing_used
    if _fls_not_found:
        _fs_verdict = AssuranceVerdict.INDETERMINATE
        _fs_skip    = SkipReason.DEPENDENCY_MISSING
    elif len(findings) > 0:
        _fs_verdict = AssuranceVerdict.PRESENT
        _fs_skip    = None
    elif fls_entries:
        _fs_verdict = AssuranceVerdict.VERIFIED_ABSENT
        _fs_skip    = None
    else:
        _fs_verdict = AssuranceVerdict.INDETERMINATE
        _fs_skip    = SkipReason.PARTIAL_FAILURE

    _fs_cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="File System Artefacts",
        verdict=_fs_verdict,
        skip_reason=_fs_skip,
        count=len(findings),
    )

    # On FAT/exFAT, record the NTFS-only classes (ADS/EFS/$MFT) as
    # VERIFIED_ABSENT-by-design so they appear in the coverage table with a
    # clear reason rather than silently disappearing.  Empty on NTFS/unknown.
    _class_results = [_fs_cr] + _ntfs_only_absent_by_design(fs_type)

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings,
        artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={
            "total_files":     len(regular_file_entries),
            "directory_entries": len(directory_entries),
            "filesystem_entries": total_files,
            "deleted_files":   len(deleted_files),
            "ext_mismatches":  len(mismatches),
            "ads_entries":     len(ads_entries),
            "efs_files":       len(efs_files),
            "timeline_events": len(timeline_entries),
            "timeline_source": timeline_source,
            "warnings":        warnings,
            "file_slack_records": len(slack_records),
            "nonzero_free_space_runs": len(nonzero_free_runs),
            "unallocated_duplicate_objects": len(unallocated_duplicates),
            "findings":        len(findings),
            "sources_discovered": len(fls_entries),
            "sources_processed": len(fls_entries),
            "supported_objects_discovered": len(fls_entries),
            "supported_objects_processed": len(fls_entries),
            "unresolved_supported_objects": len(errors),
            "coverage_complete": not errors,
            "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if not errors and bool(fls_entries) else "ran_with_caveat"),
        },
        summary=summary,
        class_results=_class_results,
    )


# ---------------------------------------------------------------------------
# NTFS ADS enumeration via istat
# ---------------------------------------------------------------------------

def _enumerate_ads(device, offset, fls_entries, output_dir, logger):
    """
    Enumerate NTFS Alternate Data Streams by running istat on each MFT entry.
    Returns list of {host_file, stream_name, size_bytes, inode}.
    LIVE-RUN-REQUIRED: requires istat from The Sleuth Kit on the mounted ewf1 device.
    """
    import re as _re, subprocess as _sp
    from pathlib import Path as _P
    _ADS_RE = _re.compile(r'^\$DATA\s+\((\S+)\)\s+size:\s+(\d+)', _re.IGNORECASE)
    ads_found = []
    for entry in (fls_entries or []):
        if entry.get("type") == "directory":
            continue
        inode = entry.get("inode", "")
        if not inode or ":" in inode:
            continue
        cmd = ["istat", "-o", str(offset), str(device), str(inode)]
        try:
            r = _sp.run(cmd, capture_output=True, text=True, timeout=10)
        except Exception:
            continue
        if r.returncode != 0:
            continue
        for line in r.stdout.splitlines():
            m = _ADS_RE.match(line.strip())
            if m:
                stream_name = m.group(1)
                size_bytes  = int(m.group(2))
                if stream_name not in ("$I30", ":$I30:$INDEX_ALLOCATION"):
                    ads_found.append({
                        "host_file":   entry.get("path", ""),
                        "inode":       inode,
                        "stream_name": stream_name,
                        "size_bytes":  size_bytes,
                    })
    return ads_found


# ---------------------------------------------------------------------------
# fls full listing
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Filesystem-type detection (STEP 5c)
# ---------------------------------------------------------------------------

def _parse_fsstat_type(stdout: str) -> "Optional[str]":
    """
    Parse the filesystem family from ``fsstat`` output.

    Returns a normalised TSK-compatible family: 'ntfs', 'fat', 'exfat', 'ext',
    or None when the type cannot be determined.
    """
    m = re.search(
        r"File System Type(?:\s+Label)?\s*:\s*(\S+)", stdout or "", re.IGNORECASE)
    if not m:
        return None
    raw = m.group(1).lower()
    if raw.startswith("ntfs"):
        return "ntfs"
    if raw.startswith("exfat"):
        return "exfat"
    if raw.startswith("fat"):
        return "fat"
    if raw.startswith("ext"):
        return "ext"
    return raw


def _detect_fs_type(analysis_path: Path, offset: int, logger: logging.Logger) -> "Optional[str]":
    """Detect the filesystem family via ``fsstat``; None if unavailable/unknown."""
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset and offset > 0 else []
    cmd = _sudo + ["fsstat"] + off + [str(analysis_path)]
    try:
        _rc, stdout, _stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except Exception as exc:  # noqa: BLE001 — tool absent / unreadable image
        logger.debug("[FSDEEP] fsstat unavailable: %s", exc)
        return None
    return _parse_fsstat_type(stdout)


# Filesystem families we are confident TSK accepts as a `-f` value.  Anything
# else (ext variants, unknown types, None) is left to TSK auto-detect so a bad
# `-f` can never make fls return zero entries.
_TSK_FLS_TYPES = ("ntfs", "fat", "exfat")


def _fls_type_flag(fs_type: "Optional[str]") -> list:
    """Return the ``-f <type>`` flag for a known FS, or [] for TSK auto-detect."""
    return ["-f", fs_type] if fs_type in _TSK_FLS_TYPES else []


def _ntfs_only_absent_by_design(fs_type: "Optional[str]") -> list:
    """
    On a FAT/exFAT filesystem the NTFS-only artefact classes (Alternate Data
    Streams, EFS-encrypted files, the $MFT) cannot exist, so they are
    VERIFIED_ABSENT by design — not merely "not found".  Returns those
    ClassResults with an explanatory note; empty on NTFS / unknown FS.
    """
    if not fs_type or fs_type not in ("fat", "exfat"):
        return []
    note = (
        f"NTFS-only artefact class; evidence filesystem is {fs_type.upper()} — "
        "absent by design (this class cannot exist on a non-NTFS filesystem)."
    )
    return [
        ClassResult(locus=Locus.FILE_SYSTEM,
                    artefact_class="NTFS Alternate Data Streams (ADS)",
                    verdict=AssuranceVerdict.VERIFIED_ABSENT, count=0, notes=note),
        ClassResult(locus=Locus.FILE_SYSTEM,
                    artefact_class="EFS Encrypted Files",
                    verdict=AssuranceVerdict.VERIFIED_ABSENT, count=0, notes=note),
        ClassResult(locus=Locus.FILE_SYSTEM,
                    artefact_class="$MFT Metadata",
                    verdict=AssuranceVerdict.VERIFIED_ABSENT, count=0, notes=note),
    ]


def _run_fls_full(
    analysis_path: Path,
    logger: logging.Logger, errors: list,
    offset: int = 0,
    fs_type: "Optional[str]" = None,
) -> tuple[list[dict], str]:
    """
    Run ``fls -r -a [-f <fs>] -l -p`` for a full recursive listing (incl. ADS).

    The filesystem type is passed through when detected (``fs_type``); when it
    is None the ``-f`` flag is omitted so TSK auto-detects.  Previously this was
    hardcoded to ``-f ntfs``, which returned zero entries on FAT/ext images.
    """
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset > 0 else []
    # -a includes ADS entries; -f is set from the detected FS (or omitted for
    # TSK auto-detect) rather than assuming NTFS.
    cmd = (_sudo + ["fls", "-r", "-a"] + _fls_type_flag(fs_type)
           + ["-l", "-p"] + off + [str(analysis_path)])
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found — install sleuthkit: sudo apt install sleuthkit")
        return [], ""
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return [], ""

    if rc == -11 or (rc != 0 and "partition" in (stderr or "").lower()):
        errors.append(
            f"TSK could not read filesystem (exit {rc}) — partition offset {offset} "
            "may be wrong. Run mmls manually to find correct offset."
        )

    # FIX #10: parse fls -l columns by position so each of the four MAC
    # timestamps (modify / access / change / create) is a distinct field.
    # fls -l field order: type deleted_flag inode: path size mtime atime ctime crtime
    # Timestamps are ISO-8601 strings when -l is used; size is an integer.
    # The path may contain spaces so we anchor on the trailing timestamp block.
    _TS_TAIL = re.compile(
        r"^(.*?)\s+(\d+)\s+"                         # path  size
        r"(\d{4}-\d\d-\d\dT[\d:.]+)\s+"             # mtime
        r"(\d{4}-\d\d-\d\dT[\d:.]+)\s+"             # atime
        r"(\d{4}-\d\d-\d\dT[\d:.]+)\s+"             # ctime
        r"(\d{4}-\d\d-\d\dT[\d:.]+)"                # crtime
    )
    _HEADER_RE = re.compile(
        r"^([a-zA-Z/\-]+)\s+(\*?)\s*(\d+(?:-\d+)*):\s+(.+)$"
    )
    _HEADER_ONLY_RE = re.compile(
        r"^([a-zA-Z/\-]+)\s+(\*?)\s*(\d+(?:-\d+)*):$"
    )

    entries: list[dict] = []
    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        # Current Sleuth Kit emits tab-delimited -l output, with timezone text
        # and size/uid/gid columns after the path. Parse that form first so a
        # filename is never polluted by timestamp columns. Retain the older
        # whitespace parser for compatibility with other TSK versions.
        tab_cols = raw_line.rstrip("\r\n").split("\t")
        header_text = tab_cols[0].strip() if tab_cols else line
        mh = (_HEADER_ONLY_RE.match(header_text) if len(tab_cols) > 1 else _HEADER_RE.match(line))
        if not mh:
            continue
        type_code = mh.group(1).strip().lower()
        inode = mh.group(3).split("-")[0]
        deleted = bool(mh.group(2).strip())

        if len(tab_cols) > 1:
            path_str = tab_cols[1].strip()
            mtime = tab_cols[2].strip() if len(tab_cols) > 2 else ""
            atime = tab_cols[3].strip() if len(tab_cols) > 3 else ""
            ctime = tab_cols[4].strip() if len(tab_cols) > 4 else ""
            crtime = tab_cols[5].strip() if len(tab_cols) > 5 else ""
        else:
            tail = mh.group(4)
            mt = _TS_TAIL.match(tail)
            if mt:
                path_str = mt.group(1).strip()
                mtime, atime, ctime, crtime = mt.group(3), mt.group(4), mt.group(5), mt.group(6)
            else:
                path_str = tail.strip()
                mtime = atime = ctime = crtime = ""

        if not path_str:
            continue
        is_directory = type_code.startswith("d")
        # Some fls versions append a slash to directory display paths. Retain
        # the directory object and normalise only that presentation suffix.
        normalized_path = path_str[:-1] if is_directory and path_str.endswith("/") else path_str
        path_obj = Path(normalized_path)
        entries.append({
            "inode": inode,
            "path": normalized_path,
            "ext": "" if is_directory else path_obj.suffix.lstrip(".").lower(),
            "deleted": deleted,
            "flags": "",
            "type": "directory" if is_directory else "file",
            "name": path_obj.name,
            "mtime": mtime,
            "atime": atime,
            "ctime": ctime,
            "crtime": crtime,
        })
    return entries, stdout


# ---------------------------------------------------------------------------
# Extension mismatch detection
# ---------------------------------------------------------------------------

def _detect_extension_mismatches(
    entries: list,
    logger=None,
) -> list:
    """
    Detect extension mismatches (double-extension pattern).

    Fast in-memory check: flag files whose stem contains an embedded extension
    that differs from the declared extension.
    Example: "invoice.pdf.exe" — declared ext is .exe, inner stem ext is .pdf.
    This is a common anti-forensic technique to hide executables.

    Rejects mactime timestamp strings mis-parsed as paths (they begin with HH:MM:SS).
    """
    import os as _os

    # Extensions worth flagging when used as the INNER extension
    _KNOWN_EXTS = frozenset({
        "jpg", "jpeg", "png", "gif", "pdf", "zip", "exe", "mp3", "rar",
        "7z", "gz", "doc", "xls", "ppt", "docx", "xlsx", "pptx", "txt",
        "bmp", "tiff", "mp4", "avi", "wmv", "mov", "lnk", "dll", "sys",
    })

    mismatches: list = []
    for entry in entries:
        if entry.get("type") == "directory":
            continue
        path = entry.get("path", "") or ""
        # Determine basename: if the path contains a separator use Path, otherwise
        # treat the whole string as a potential basename.
        if "/" in path or "\\" in path:
            basename = Path(path).name
        else:
            basename = path

        # Reject empty basenames and mactime timestamp strings
        if not basename or _TIMESTAMP_PATTERN.match(basename):
            continue

        # Must have a real extension
        stem, declared_ext = _os.path.splitext(basename)
        if not declared_ext or len(declared_ext) > 6:
            continue

        # Check for double extension: does the stem have its own known extension?
        _, inner_ext = _os.path.splitext(stem)
        if not inner_ext:
            continue
        inner_ext_clean = inner_ext.lstrip(".").lower()
        declared_ext_clean = declared_ext.lstrip(".").lower()

        if inner_ext_clean in _KNOWN_EXTS and inner_ext_clean != declared_ext_clean:
            mismatches.append({
                "path":          path,
                "name":          basename,
                "declared_ext":  declared_ext,
                "inner_ext":     inner_ext,
                "detected_mime": f"possible {inner_ext_clean} (double extension)",
                "expected_ext":  inner_ext_clean,
                "method":        "double_extension",
                "mtime":  entry.get("mtime", ""),
                "atime":  entry.get("atime", ""),
                "ctime":  entry.get("ctime", ""),
                "crtime": entry.get("crtime", ""),
                "title":  f"Extension Mismatch: {basename} (declared {declared_ext}, inner {inner_ext})",
            })

    return mismatches


# ---------------------------------------------------------------------------
# ADS detection
# ---------------------------------------------------------------------------

# NTFS system files — never flag as suspicious
_NTFS_SYSTEM_FILES = frozenset({
    "$attrdef", "$badclus", "$bitmap", "$boot", "$extend", "$logfile",
    "$mft", "$mftmirr", "$secure", "$upcase", "$volume", "$quota",
    "$objid", "$reparse", "$i30", "$txf_log",
})

# Standard Windows ADS streams — not suspicious
_STANDARD_ADS_STREAMS = frozenset({
    "zone.identifier", "summaryinformation", "documentsummaryinformation",
    "sezoneinformation", "com.apple.quarantine", "afp_afpinfo",
    "afp_resource", "favicon", "editflags",
})


def _merge_ads(*lists: list[dict]) -> list[dict]:
    """Merge ADS records from several detectors into one deduplicated list.

    A single physical stream may be reported by both the istat enumeration and
    the fls listing.  Keying on the host file's basename and the stream name
    collapses those to one entry, so the ADS count is a single computation
    shared by the findings and the statistics.  When the same stream is seen
    twice, the record carrying a concrete byte size (istat) is kept and given a
    normalised ``size`` field for rendering.
    """
    merged: dict[tuple, dict] = {}
    for lst in lists:
        for a in lst or []:
            host = Path(str(a.get("host_file", ""))).name.lower()
            stream = str(a.get("stream_name", "")).lower()
            key = (host, stream)
            rec = dict(a)
            if "size" not in rec and "size_bytes" in rec:
                rec["size"] = rec["size_bytes"]
            existing = merged.get(key)
            if existing is None:
                merged[key] = rec
            elif "size_bytes" in rec and "size_bytes" not in existing:
                merged[key] = rec  # prefer the richer record (concrete size)
    return list(merged.values())


def _select_efs(entries: list[dict], fat_like: bool) -> list[dict]:
    """Select EFS-encrypted files from fls entries (the 'E' attribute flag).

    EFS is an NTFS-only construct, so nothing is selected on FAT/exFAT.  Each
    selected entry becomes its own finding, so one encrypted item yields exactly
    one EFS finding.
    """
    if fat_like:
        return []
    return [e for e in entries
            if e.get("flags") and "E" in str(e.get("flags", ""))]


def _detect_ads(entries: list[dict], logger: logging.Logger) -> list[dict]:
    """Detect suspicious NTFS Alternate Data Streams from fls output.

    Excludes:
    - Standard NTFS metadata files ($MFT, $AttrDef, etc.)
    - Standard Windows ADS streams (Zone.Identifier, SummaryInformation)
    - Zero-size streams
    """
    ads_entries = []
    for e in entries:
        path  = e.get("path", "")
        inode = e.get("inode", "")
        name  = e.get("name", Path(path).name)

        host_file = name.split(":")[0] if ":" in name else name
        if host_file.lower() in _NTFS_SYSTEM_FILES:
            continue

        # Detect ADS from path (filename:stream_name pattern)
        if ":" in name:
            parts  = name.split(":", 1)
            host   = parts[0]
            stream = parts[1] if len(parts) > 1 else ""
            if host.lower() in _NTFS_SYSTEM_FILES:
                continue
            if stream.lower() in _STANDARD_ADS_STREAMS:
                continue
            size = e.get("size", "0")
            try:
                if int(size) == 0:
                    continue
            except (ValueError, TypeError):
                pass
            ads_entries.append({
                "path":        path,
                "host_file":   host,
                "stream_name": stream,
                "inode":       inode,
                "size":        size,
            })
            continue

        # Detect ADS from compound inode (nnnn-nn-nn format with 3+ segments)
        if inode and inode.count("-") >= 2:
            host_name = Path(path).name
            if host_name.lower() in _NTFS_SYSTEM_FILES:
                continue
            ads_entries.append({
                "path":        path,
                "host_file":   host_name,
                "stream_name": f"[inode stream {inode}]",
                "inode":       inode,
                "size":        e.get("size", "?"),
            })

    return ads_entries


# ---------------------------------------------------------------------------
# mactime timeline
# ---------------------------------------------------------------------------

def _run_mactime(
    analysis_path: Path,
    logger: logging.Logger, errors: list,
    offset: int = 0,
) -> tuple[list[dict], str]:
    """Run fls -m then mactime to build a MAC timeline."""
    import sys as _sys
    _sudo = []
    _off  = ["-o", str(offset)] if offset > 0 else []
    # First run fls -r -m / to get bodyfile; include partition offset for DOS-partitioned images
    cmd_body = _sudo + ["fls", "-r", "-m", "/"] + _off + [str(analysis_path)]
    try:
        rc, bodyfile, stderr = _run_subprocess(cmd_body, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found for mactime")
        return [], ""
    except Exception as exc:
        errors.append(f"fls mactime error: {exc}")
        return [], ""

    if not bodyfile.strip():
        return [], ""

    # mactime expects input on stdin or a file
    try:
        import tempfile, os
        with tempfile.NamedTemporaryFile(mode="w", suffix=".body",
                                        delete=False, encoding="utf-8") as tf:
            tf.write(bodyfile)
            tf_path = tf.name

        cmd_mac = ["mactime", "-b", tf_path, "-d"]
        try:
            rc2, mac_out, mac_err = _run_subprocess(cmd_mac, MACTIME_TIMEOUT, logger)
        finally:
            try:
                os.unlink(tf_path)
            except OSError:
                pass
    except Exception as exc:
        errors.append(f"mactime error: {exc}")
        return [], bodyfile

    events: list[dict] = []
    for line in mac_out.splitlines():
        if not line.strip() or line.startswith("Date"):
            continue
        parts = line.split(",", 5)
        if len(parts) >= 5:
            events.append({
                "timestamp":   parts[0].strip(),
                "size":        parts[1].strip(),
                "type":        parts[2].strip(),
                "mode":        parts[3].strip(),
                "uid_gid":     parts[4].strip(),
                "path":        parts[5].strip() if len(parts) > 5 else "",
            })

    events.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return events, mac_out


# ---------------------------------------------------------------------------
# Password-protected detection
# ---------------------------------------------------------------------------

def _classify_password_protection(paths: list[Path]) -> tuple[list[dict], list[dict]]:
    """Return password-capable files and those with structurally verified protection.

    Extension is used only for capability triage. Verification requires a
    format-level encryption indicator; no password or expected filename is used.
    """
    import zipfile
    capable_exts = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".zip", ".rar", ".7z", ".accdb", ".mdb"}
    capable: list[dict] = []
    verified: list[dict] = []
    seen: set[str] = set()
    for path in paths:
        try:
            if not path.is_file() or path.suffix.casefold() not in capable_exts:
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
        except OSError:
            continue
        if digest in seen:
            continue
        seen.add(digest)
        item = {"path": path, "format": path.suffix.casefold().lstrip("."), "sha256": digest}
        capable.append(item)
        suffix = path.suffix.casefold()
        if suffix in {".zip", ".docx", ".xlsx", ".pptx"}:
            try:
                with zipfile.ZipFile(path) as zf:
                    encrypted = [info.filename for info in zf.infolist() if info.flag_bits & 0x1]
                if encrypted:
                    verified.append({**item, "validation": f"ZIP general-purpose encryption flag set on {len(encrypted)} member(s)", "validators": ["ZIP central directory", "general-purpose bit 0"]})
            except (OSError, zipfile.BadZipFile):
                pass
        elif suffix == ".pdf":
            try:
                from pypdf import PdfReader
                if bool(PdfReader(str(path), strict=False).is_encrypted):
                    verified.append({**item, "validation": "PDF encryption dictionary present", "validators": ["pypdf is_encrypted"]})
            except Exception:
                pass
    return capable, verified


# ---------------------------------------------------------------------------
# _fail helper
# ---------------------------------------------------------------------------

def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_FAILED,
                           description=f"Module '{module_name}' failed: {reason}",
                           metadata={"module": module_name, "reason": reason})
        except Exception:
            pass
    logger.error("Module %s failed: %s", module_name, reason)
    return ModuleResult(
        module_name=module_name, case_id=case_id,
        status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=0.0, findings=[], artifact_paths=[],
        errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
        class_results=[ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="File System Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            count=0,
        )],
    )
