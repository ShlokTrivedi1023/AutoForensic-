"""Scalpel specialist carver with deterministic candidate reconciliation."""
from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.carving_reconciliation import reconcile_candidates
from core.deterministic_validation import candidate_metadata, deterministic_metadata
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus, Severity,
    SkipReason, _run_subprocess, carving_volume_caveat, make_finding,
    source_image_size, utc_now,
)

MODULE_NAME = "scalpel_carver"
SCALPEL_TIMEOUT = 14400

_DEFAULT_SCALPEL_CONF = """\
# AutoForensics deterministic Scalpel configuration
jpg  y  200000000  \\xff\\xd8\\xff\\xe0  \\xff\\xd9
jpg  y  200000000  \\xff\\xd8\\xff\\xe1  \\xff\\xd9
gif  y  5000000    \\x47\\x49\\x46\\x38\\x37\\x61  \\x00\\x3b
gif  y  5000000    \\x47\\x49\\x46\\x38\\x39\\x61  \\x00\\x3b
png  y  20000000   \\x89\\x50\\x4e\\x47\\x0d\\x0a\\x1a\\x0a  \\x49\\x45\\x4e\\x44\\xae\\x42\\x60\\x82
bmp  y  10000000   \\x42\\x4d
pdf  y  30000000   \\x25\\x50\\x44\\x46  \\x25\\x25\\x45\\x4f\\x46
exe  y  10000000   \\x4d\\x5a
zip  y  50000000   \\x50\\x4b\\x03\\x04  \\x50\\x4b\\x05\\x06
gz   y  50000000   \\x1f\\x8b\\x08
doc  y  10000000   \\xd0\\xcf\\x11\\xe0\\xa1\\xb1\\x1a\\xe1
mp3  y  10000000   \\x49\\x44\\x33
mp4  y  500000000  \\x00\\x00\\x00\\x18\\x66\\x74\\x79\\x70
"""

_TYPE_MAGIC: dict[str, tuple[bytes, ...]] = {
    "jpg": (b"\xff\xd8\xff",), "jpeg": (b"\xff\xd8\xff",),
    "gif": (b"GIF87a", b"GIF89a"), "png": (b"\x89PNG\r\n\x1a\n",),
    "bmp": (b"BM",), "pdf": (b"%PDF",), "exe": (b"MZ",), "dll": (b"MZ",),
    "zip": (b"PK\x03\x04",), "gz": (b"\x1f\x8b\x08",),
    "doc": (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1",), "mp3": (b"ID3",),
    "mp4": (b"\x00\x00\x00\x18ftyp",),
}


def _header_validates(header: bytes, file_type: str) -> bool:
    ft = (file_type or "").casefold()
    if ft in {"exe", "dll"}:
        if len(header) < 64 or not header.startswith(b"MZ"):
            return False
        pe_off = int.from_bytes(header[0x3C:0x40], "little")
        return 0 < pe_off <= len(header) - 4 and header[pe_off:pe_off + 4] == b"PE\x00\x00"
    return any(header.startswith(magic) for magic in _TYPE_MAGIC.get(ft, ()))


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event, " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _load_foremost_hashes(output_dir: Path) -> set[str]:
    candidates = [
        output_dir.parent / "foremost_carver" / "foremost_manifest.json",
        output_dir / "foremost_manifest.json",
    ]
    manifest = next((path for path in candidates if path.is_file()), candidates[0])
    if not manifest.is_file():
        return set()
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return set()
    hashes = set()
    for rec in data.get("files", []) or []:
        digest = str(rec.get("output_sha256") or rec.get("sha256") or "")
        if re.fullmatch(r"[0-9a-fA-F]{64}", digest):
            hashes.add(digest.casefold())
    return hashes


def _make_scalpel_output_dir(output_dir: Path, evidence_path: Path) -> Path:
    safe_stem = re.sub(r"[^A-Za-z0-9_.\-]", "_", evidence_path.stem)
    return output_dir / f"scalpel_{safe_stem}"


def _parse_audit_txt(audit_path: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not audit_path.is_file():
        return result
    row = re.compile(
        r"^\s*(?P<name>\S+)\s+(?P<start>\d+)\s+(?P<chop>YES|NO)\s+(?P<length>\d+)\s+(?P<source>.+?)\s*$",
        re.I,
    )
    for line in audit_path.read_text(encoding="utf-8", errors="replace").splitlines():
        match = row.match(line)
        if not match:
            continue
        start = int(match.group("start"))
        length = int(match.group("length"))
        result[Path(match.group("name")).name] = {
            "source_start": start, "source_length": length, "source_end": start + length,
            "chop": match.group("chop").upper() == "YES", "source": match.group("source").strip(),
            "audit_reported_size_bytes": length, "audit_size_is_exact": True,
        }
    return result


def _filesystem_manifest(output_dir: Path, config: dict[str, Any]) -> Path | None:
    ws = config.get("_working_set") or {}
    for value in (ws.get("native_filesystem_manifest"), ws.get("filesystem_manifest"), config.get("native_filesystem_manifest")):
        if value and Path(str(value)).is_file():
            return Path(str(value))
    case_root = output_dir.parents[2] if len(output_dir.parents) >= 3 else output_dir.parent
    matches = sorted(case_root.glob("native_filesystem/*/native_filesystem_manifest.json"))
    return matches[0] if matches else None


def _native_manifests(output_dir: Path) -> list[Path]:
    candidate = output_dir.parent / "native_signature_carver" / "native_signature_carving_manifest.json"
    return [candidate] if candidate.is_file() else []


def _metadata_for(record: dict[str, Any], manifest_path: Path, analysis_source: Path) -> dict[str, Any]:
    state = str(record.get("final_state") or "UNRESOLVED")
    common = {
        **record,
        "source_offset": record.get("source_start"),
        "sha256": record.get("output_sha256"),
        "file_sha256": record.get("output_sha256"),
        "carved_path": record.get("output_path"),
        "hash_path": record.get("output_path"),
        "hash_scope": "retained_carver_output",
        "interval_sha256": record.get("source_interval_sha256"),
        "analysis_source": str(analysis_source), "report_file": str(manifest_path),
        "deletion_state_established": False, "counts_toward_unique_evidence": False,
        "unique_to_scalpel": bool(record.get("unique_to_scalpel", False)),
        "matched_foremost_hashes": list(record.get("matched_foremost_hashes") or []),
    }
    if state == "ACCEPTED":
        common.update(deterministic_metadata(
            "exact source interval SHA-256 plus complete format-structure validation",
            validators=["Scalpel audit interval", "source interval SHA-256", "format parser"],
            semantic_limit=(
                "The source bytes contain this structurally complete object. The result does not establish deletion, "
                "intent, independent corroboration or a new unique evidence object."
            ),
        ))
        common.update({"fact_class": "ALTERNATIVE_REPRESENTATION", "ledger_state": "ACCEPTED"})
    else:
        common.update(candidate_metadata(
            "Scalpel deterministic reconciliation",
            reason=str(record.get("resolution_reason") or "candidate could not be completely reconciled"),
        ))
        common.update({
            "ledger_state": state,
            "fact_class": "REJECTED" if state == "REJECTED" else "CANDIDATE_ONLY",
            "rejected": state == "REJECTED",
        })
    return common



def _accepted_completion_counters(records: list[dict[str, Any]]) -> dict[str, int]:
    """Return fail-closed completion counters for accepted Scalpel outputs.

    ``invalid_accepted_carvings`` counts accepted rows that do not retain the
    exact interval/hash/structure proof required for acceptance.

    ``overlapping_accepted_carvings`` counts accepted rows involved in a
    positive byte-range overlap with another accepted row.  Duplicate hashes at
    different physical offsets are not overlaps.  The counter is deliberately
    record based (not byte based) because the strict contract only needs to know
    whether any accepted output still requires overlap resolution.
    """
    accepted = [record for record in records if str(record.get("final_state") or "").upper() == "ACCEPTED"]
    invalid = 0
    intervals: list[tuple[int, int, int]] = []
    for index, record in enumerate(accepted):
        structural = record.get("structural_validation") if isinstance(record.get("structural_validation"), dict) else {}
        digest = str(record.get("output_sha256") or "").lower()
        interval_digest = str(record.get("source_interval_sha256") or "").lower()
        try:
            start = int(record.get("source_start"))
            end = int(record.get("source_end"))
            length = int(record.get("source_length"))
            candidate_size = int(record.get("candidate_size_bytes"))
            structured_length = int(record.get("structured_length"))
        except (TypeError, ValueError):
            invalid += 1
            continue
        valid = (
            start >= 0
            and end == start + length
            and length > 0
            and candidate_size == length
            and structured_length == candidate_size
            and structural.get("valid") is True
            and record.get("source_bytes_match_output") is True
            and bool(re.fullmatch(r"[0-9a-f]{64}", digest))
            and digest == interval_digest
        )
        if not valid:
            invalid += 1
            continue
        intervals.append((index, start, end))

    overlapping_indices: set[int] = set()
    ordered = sorted(intervals, key=lambda item: (item[1], item[2], item[0]))
    for position, (index, start, end) in enumerate(ordered):
        for other_index, other_start, other_end in ordered[position + 1:]:
            if other_start >= end:
                break
            if min(end, other_end) > max(start, other_start):
                overlapping_indices.add(index)
                overlapping_indices.add(other_index)
    return {
        "invalid_accepted_carvings": invalid,
        "overlapping_accepted_carvings": len(overlapping_indices),
    }

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})
    output_dir.mkdir(parents=True, exist_ok=True)
    analysis_source = Path(config.get("analysis_path") or evidence_path).resolve()
    if not analysis_source.is_file():
        analysis_source = evidence_path.resolve()
    carve_dir = _make_scalpel_output_dir(output_dir, analysis_source)
    carve_dir.mkdir(parents=True, exist_ok=True)

    custom = config.get("scalpel_config")
    conf_path = Path(str(custom)).resolve() if custom and Path(str(custom)).is_file() else output_dir / "autoforensics_scalpel.conf"
    errors: list[str] = []
    if not (custom and Path(str(custom)).is_file()):
        try:
            conf_path.write_text(_DEFAULT_SCALPEL_CONF, encoding="utf-8")
        except OSError as exc:
            errors.append(f"could not write Scalpel configuration: {exc}")
    try:
        active_rules = [line for line in conf_path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip() and not line.lstrip().startswith("#")]
    except OSError as exc:
        active_rules = []
        errors.append(f"could not read Scalpel configuration: {exc}")
    if not active_rules:
        errors.append("Scalpel configuration has no active rules")

    cmd = ["scalpel", "-c", str(conf_path), "-o", str(carve_dir), str(analysis_source)]
    if config.get("overwrite", True):
        cmd.insert(1, "-O")
    rc: int | None = None
    artifact_paths: list[str] = [str(conf_path)] if conf_path.is_file() else []
    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=SCALPEL_TIMEOUT, logger=logger)
        log_path = carve_dir / "scalpel_stdout.txt"
        log_path.write_text((stdout or "") + "\n" + (stderr or ""), encoding="utf-8", errors="replace")
        artifact_paths.append(str(log_path))
        if rc != 0:
            errors.append(f"scalpel exited with rc={rc}")
    except FileNotFoundError:
        end_time = utc_now()
        from datetime import datetime
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time,
            duration_seconds=(datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds(),
            errors=["scalpel not found — install the scalpel package"],
            summary="Scalpel specialist analysis not executed because the binary is unavailable.",
            class_results=[ClassResult(
                locus=Locus.FILE_SYSTEM, artefact_class="Scalpel Carved Files",
                verdict=AssuranceVerdict.INDETERMINATE, skip_reason=SkipReason.DEPENDENCY_MISSING,
                notes="Native/Foremost carving remains separately reported and is not relabelled as Scalpel.",
            )],
        )
    except subprocess.TimeoutExpired:
        errors.append(f"scalpel timed out after {SCALPEL_TIMEOUT}s")

    audit_path = carve_dir / "audit.txt"
    audit = _parse_audit_txt(audit_path)
    candidates: list[dict[str, Any]] = []
    ignored = {"audit.txt", "scalpel_stdout.txt"}
    for path in sorted(carve_dir.rglob("*")):
        if not path.is_file() or path.name in ignored:
            continue
        rec = audit.get(path.name, {})
        candidates.append({
            **rec, "file_name": path.name, "file_type": path.suffix.lstrip(".").casefold(),
            "output_path": str(path),
        })
    # Audit rows with missing output files must remain unresolved rather than disappear.
    discovered_names = {str(rec.get("file_name")) for rec in candidates}
    for name, rec in audit.items():
        if name not in discovered_names:
            candidates.append({**rec, "file_name": name, "file_type": Path(name).suffix.lstrip(".").casefold(), "output_path": ""})

    foremost_hashes = _load_foremost_hashes(output_dir)
    reconciled, reconciliation = reconcile_candidates(
        tool_name="scalpel", source_path=analysis_source, candidates=candidates,
        filesystem_manifest=_filesystem_manifest(output_dir, config),
        native_manifests=_native_manifests(output_dir), peer_hashes=foremost_hashes,
    )
    by_type: dict[str, int] = {}
    for record in reconciled:
        claimed = str(record.get("claimed_type") or "unknown")
        by_type[claimed] = by_type.get(claimed, 0) + 1
    accepted = int((reconciliation.get("state_counts") or {}).get("ACCEPTED", 0))
    rejected = int((reconciliation.get("state_counts") or {}).get("REJECTED", 0))
    unresolved = int((reconciliation.get("state_counts") or {}).get("UNRESOLVED", 0))
    unique_to_scalpel = sum(1 for record in reconciled if record.get("final_state") == "ACCEPTED" and record.get("unique_to_scalpel") is True)
    completion_counters = _accepted_completion_counters(reconciled)

    manifest_path = output_dir / "scalpel_manifest.json"
    findings = []
    for record in reconciled:
        state = str(record.get("final_state") or "UNRESOLVED")
        claimed = str(record.get("claimed_type") or "unknown")
        if record.get("output_path"):
            artifact_paths.append(str(record["output_path"]))
        if state == "ACCEPTED":
            finding_type = "CARVER_CANDIDATE_RESOLVED"
            description = (
                f"Scalpel output {record.get('output_name')} is a structurally complete {claimed.upper()} "
                f"object at source bytes {record.get('source_start')}–{record.get('source_end')}; "
                "the retained output matches that interval exactly."
            )
        else:
            finding_type = "CARVER_CANDIDATE_REJECTED" if state == "REJECTED" else "CARVER_CANDIDATE_UNRESOLVED"
            description = f"Scalpel output {record.get('output_name')} was {state.lower()}: {record.get('resolution_reason')}."
        findings.append(make_finding(
            finding_type=finding_type, severity=Severity.INFO, description=description,
            evidence_path=str(evidence_path), artifact_path=str(record.get("output_path") or manifest_path),
            metadata=_metadata_for(record, manifest_path, analysis_source),
        ))

    source_size = source_image_size(analysis_source, config)
    total_bytes = int(reconciliation.get("total_candidate_output_bytes") or 0)
    volume_caveat = carving_volume_caveat(total_bytes, source_size)
    _ws = config.get("_working_set") or {}
    manifest_payload = {
        "schema": "autoforensics-carver-reconciliation-v2",
        "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
        "engine_return_code": rc, "analysis_source": str(analysis_source),
        # The logical stream may be an ephemeral read-only EWF mount.  Preserve
        # cryptographic anchors to the external source container and logical media
        # so a verification subset remains reproducible without bundling the full
        # source image.
        "analysis_source_sha256": str(_ws.get("logical_media_sha256") or ""),
        "logical_media_sha256": str(_ws.get("logical_media_sha256") or ""),
        "source_container_path": str(_ws.get("source_container_path") or evidence_path),
        "source_container_sha256": str(_ws.get("source_container_sha256") or ""),
        "source_retention_policy": "EXTERNAL_EVIDENCE_REQUIRED_FOR_INTERVAL_REPLAY",
        "source_image_bytes": source_size, "audit_file": str(audit_path),
        "audit_record_count": len(audit), "by_type": by_type,
        "unique_to_scalpel": unique_to_scalpel,
        "reconciliation": reconciliation, "volume_caveat": volume_caveat or "",
        "files": reconciled,
    }
    try:
        manifest_path.write_text(json.dumps(manifest_payload, indent=2, ensure_ascii=True), encoding="utf-8")
        artifact_paths.append(str(manifest_path))
    except OSError as exc:
        errors.append(f"failed to write Scalpel reconciliation manifest: {exc}")

    if rc != 0 or errors:
        status = ModuleStatus.PARTIAL if reconciled else ModuleStatus.FAILED
    elif unresolved:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.COMPLETED
    summary = (
        f"Scalpel deterministically resolved {len(reconciled)} candidate(s): {accepted} accepted byte-presence "
        f"observation(s), {rejected} rejected output(s), {unresolved} unresolved; {unique_to_scalpel} accepted "
        "hash(es) were not present in the Foremost manifest. Process return code alone was not used as completion evidence."
    )
    if volume_caveat:
        summary += " " + volume_caveat
    end_time = utc_now()
    from datetime import datetime
    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id, "candidates": len(reconciled)})
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time,
        duration_seconds=(datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds(),
        findings=findings, artifact_paths=list(dict.fromkeys(artifact_paths)), errors=errors,
        statistics={
            "sources_discovered": 1, "sources_processed": 1 if rc == 0 else 0,
            "supported_objects_discovered": len(reconciled), "supported_objects_processed": len(reconciled),
            "records_discovered": len(reconciled), "records_processed": len(reconciled),
            "unresolved_supported_objects": unresolved, "parser_errors": len(errors),
            "engine_completed": rc == 0, "by_type": by_type,
            "accepted_candidates": accepted, "rejected_candidates": rejected, "unresolved_candidates": unresolved,
            "unique_to_scalpel": unique_to_scalpel, **completion_counters, **reconciliation,
            "source_image_bytes": source_size, "volume_caveat": volume_caveat or "",
            "execution_outcome": "ran_found_x" if reconciled else "ran_found_nothing",
        },
        summary=summary,
        class_results=[ClassResult(
            locus=Locus.FILE_SYSTEM, artefact_class="Scalpel Carved Files",
            verdict=AssuranceVerdict.PRESENT if accepted else AssuranceVerdict.INDETERMINATE if unresolved else AssuranceVerdict.SCOPED_ABSENCE,
            count=accepted, summarised=True,
            notes="Accepted records establish source-byte presence only. Rejected overlapping/chopped outputs remain auditable and do not inflate unique evidence counts.",
        )],
    )
