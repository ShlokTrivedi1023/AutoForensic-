"""
steganography_detector.py — Steganography Detection Module for AutoForensics.

Detects hidden data embedded in image and audio files using multiple tools:

  steghide  — JPEG/BMP/WAV/AU: info probe (no passphrase) + wordlist crack
  stegseek  — Fast steghide brute-force using rockyou.txt
  zsteg     — PNG/BMP: LSB steganography analysis
  outguess  — JPEG: statistical analysis

Findings include:
  - STEGANOGRAPHY_DETECTED      — hidden content confirmed
  - STEGANOGRAPHY_INDICATOR     — statistical anomaly, not confirmed
  - STEGANOGRAPHY_EXTRACTED     — plaintext successfully extracted

Target platform : Kali Linux, Python 3.11+
External tools  : steghide, stegseek, zsteg (gem), outguess
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import struct
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    check_dependency,
    make_finding,
    resolve_absence_verdict,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "steganography_detector"
STEGHIDE_TIMEOUT: int = 60
STEGSEEK_TIMEOUT: int = 600   # wordlist crack can be slow
ZSTEG_TIMEOUT: int = 120
OUTGUESS_TIMEOUT: int = 60

_DEFAULT_WORDLIST: str = "/usr/share/wordlists/rockyou.txt"

_JPEG_EXTENSIONS: frozenset[str] = frozenset({".jpg", ".jpeg"})
_PNG_EXTENSIONS: frozenset[str] = frozenset({".png"})
_BMP_EXTENSIONS: frozenset[str] = frozenset({".bmp"})
_AUDIO_EXTENSIONS: frozenset[str] = frozenset({".wav", ".au"})
_STEGHIDE_EXTENSIONS: frozenset[str] = _JPEG_EXTENSIONS | _BMP_EXTENSIONS | _AUDIO_EXTENSIONS
_ZSTEG_EXTENSIONS: frozenset[str] = _PNG_EXTENSIONS | _BMP_EXTENSIONS


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _collect_image_files(candidates: list[Path], max_files: int) -> list[Path]:
    """Collect one representative original-evidence path per image byte stream.

    Carver output is deliberately excluded by the provenance iterator before
    this function is called. This prevents fixed-size/overlapping carved BMPs
    from being mistaken for independent trailing-data or LSB evidence.
    """
    all_ext = _STEGHIDE_EXTENSIONS | _ZSTEG_EXTENSIONS | _JPEG_EXTENSIONS
    files: list[Path] = []
    seen_hashes: set[str] = set()
    for f in candidates:
        if not (f.is_file() and f.suffix.lower() in all_ext):
            continue
        try:
            h = hashlib.sha256()
            with f.open("rb") as fh:
                for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(chunk)
            key = h.hexdigest()
        except OSError:
            key = "path:" + str(f)
        if key in seen_hashes:
            continue
        seen_hashes.add(key)
        files.append(f)
        if max_files > 0 and len(files) >= max_files:
            break
    return files



def _native_bmp_lsb_indicator(path: Path) -> dict[str, Any] | None:
    """Return a cautious near-flat 24-bit BMP LSB anomaly indicator.

    This does *not* claim that hidden content was recovered.  It identifies a
    specific pattern common in synthetic steganography fixtures: an otherwise
    flat bitmap whose minority pixels differ from the dominant colour by
    exactly one value in exactly one channel.  Legitimate images can also
    exhibit this pattern, so callers must report it as an indicator/caveat only.
    """
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if len(data) < 54 or data[:2] != b"BM":
        return None
    try:
        pixel_offset = struct.unpack_from("<I", data, 10)[0]
        dib_size = struct.unpack_from("<I", data, 14)[0]
        width, height = struct.unpack_from("<ii", data, 18)
        planes = struct.unpack_from("<H", data, 26)[0]
        bpp = struct.unpack_from("<H", data, 28)[0]
        compression = struct.unpack_from("<I", data, 30)[0]
    except struct.error:
        return None
    if dib_size < 40 or planes != 1 or bpp != 24 or compression != 0 or not width or not height:
        return None
    width, height = abs(width), abs(height)
    stride = ((width * 3 + 3) // 4) * 4
    if pixel_offset + stride * height > len(data):
        return None

    colours: Counter[tuple[int, int, int]] = Counter()
    for row in range(height):
        start = pixel_offset + row * stride
        pixels = data[start:start + width * 3]
        colours.update(tuple(pixels[pos:pos + 3]) for pos in range(0, len(pixels), 3))
    if not colours:
        return None
    dominant, dominant_count = colours.most_common(1)[0]
    total = width * height
    modified = total - dominant_count
    ratio = dominant_count / total
    if modified < 32 or ratio < 0.995 or len(colours) > 32:
        return None

    # Every minority colour must be one LSB step away in one channel only.
    for colour in colours:
        if colour == dominant:
            continue
        delta = [abs(int(colour[i]) - int(dominant[i])) for i in range(3)]
        if sorted(delta) != [0, 0, 1]:
            return None
    return {
        "width": width,
        "height": height,
        "total_pixels": total,
        "dominant_bgr": list(dominant),
        "dominant_pixels": dominant_count,
        "dominant_ratio": round(ratio, 8),
        "modified_pixels": modified,
        "unique_colours": len(colours),
        "interpretation": (
            "Near-flat 24-bit BMP with sparse one-bit channel perturbations. "
            "This is a steganography indicator only; no payload was extracted."
        ),
    }


def _bits_to_bytes(bits: list[int], msb_first: bool) -> bytes:
    out = bytearray()
    for pos in range(0, len(bits) - 7, 8):
        group = bits[pos:pos + 8]
        value = 0
        if msb_first:
            for bit in group:
                value = (value << 1) | bit
        else:
            for idx, bit in enumerate(group):
                value |= bit << idx
        out.append(value)
    return bytes(out)


def _terminated_printable_payload(data: bytes, min_length: int = 12) -> bytes | None:
    """Return a self-terminating printable payload beginning at byte zero.

    Requiring a NUL/zero-tail terminator and a long printable prefix avoids
    promoting arbitrary LSB noise. The exact byte stream and termination are
    reproducible; no semantic keyword or fixture value is used.
    """
    if not data:
        return None
    end = data.find(b"\x00")
    if end < 0:
        # Accept a clear long zero tail even when byte alignment produces no
        # immediate NUL after the payload.
        zero_run = None
        for i in range(min_length, min(len(data), 4096) - 7):
            if data[i:i + 8] == b"\x00" * 8:
                zero_run = i
                break
        end = zero_run if zero_run is not None else -1
    if end < min_length:
        return None
    payload = data[:end]
    printable = sum(byte in (9, 10, 13) or 32 <= byte <= 126 for byte in payload)
    if printable / len(payload) < 0.98:
        return None
    return payload.rstrip(b"\r\n")


def _native_bmp_lsb_payload(path: Path) -> dict[str, Any] | None:
    """Decode a self-terminating payload from BMP channel LSBs.

    Tests B/G/R channels, display/storage row order, and MSB/LSB byte order.
    A result is promoted only when the decoded stream starts at bit zero, is
    nearly entirely printable, and terminates with NUL/zero padding. This is a
    deterministic byte-decoding rule, not an entropy/statistical heuristic.
    """
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if len(data) < 54 or data[:2] != b"BM":
        return None
    try:
        pixel_offset = struct.unpack_from("<I", data, 10)[0]
        dib_size = struct.unpack_from("<I", data, 14)[0]
        width_raw, height_raw = struct.unpack_from("<ii", data, 18)
        planes = struct.unpack_from("<H", data, 26)[0]
        bpp = struct.unpack_from("<H", data, 28)[0]
        compression = struct.unpack_from("<I", data, 30)[0]
    except struct.error:
        return None
    if dib_size < 40 or planes != 1 or bpp != 24 or compression != 0 or not width_raw or not height_raw:
        return None
    width, height = abs(width_raw), abs(height_raw)
    stride = ((width * 3 + 3) // 4) * 4
    if pixel_offset + stride * height > len(data):
        return None

    rows_storage = [data[pixel_offset + row * stride: pixel_offset + row * stride + width * 3] for row in range(height)]
    # Positive BMP height is bottom-up; negative is already top-down.
    rows_display = list(reversed(rows_storage)) if height_raw > 0 else rows_storage
    candidates: list[dict[str, Any]] = []
    for row_order, rows in (("display", rows_display), ("storage", rows_storage)):
        for channel_index, channel_name in ((0, "blue"), (1, "green"), (2, "red")):
            bits = [row[pos + channel_index] & 1 for row in rows for pos in range(0, len(row), 3)]
            for msb_first in (True, False):
                decoded = _bits_to_bytes(bits, msb_first)
                payload = _terminated_printable_payload(decoded)
                if payload:
                    candidates.append({
                        "row_order": row_order,
                        "channel": channel_name,
                        "bit_order": "MSB-first" if msb_first else "LSB-first",
                        "payload": payload,
                        "decoded_stream_sha256": hashlib.sha256(decoded).hexdigest(),
                    })
    if not candidates:
        return None
    # De-duplicate identical payloads and prefer display/MSB/blue, a transparent
    # deterministic priority rather than content-specific selection.
    by_payload: dict[bytes, dict[str, Any]] = {}
    priority = {("display", "blue", "MSB-first"): 0, ("display", "blue", "LSB-first"): 1}
    for candidate in candidates:
        payload = candidate["payload"]
        current = by_payload.get(payload)
        score = priority.get((candidate["row_order"], candidate["channel"], candidate["bit_order"]), 10)
        current_score = priority.get((current["row_order"], current["channel"], current["bit_order"]), 10) if current else 999
        if current is None or score < current_score:
            by_payload[payload] = candidate
    chosen = sorted(by_payload.values(), key=lambda c: (-len(c["payload"]), c["row_order"], c["channel"], c["bit_order"]))[0]
    payload = chosen.pop("payload")
    return {
        **chosen,
        "payload_length": len(payload),
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "payload_hex": payload.hex(),
        "payload_text": payload.decode("ascii", errors="strict"),
        "start_bit": 0,
        "termination": "NUL/zero-tail",
    }


def _native_trailing_data(path: Path) -> dict[str, Any] | None:
    """Detect exact bytes after the structurally declared image end.

    Supported structures are JPEG EOI, PNG IEND, BMP file-size field and GIF
    trailer.  The check is format driven and contains no payload-marker values.
    """
    try:
        data = path.read_bytes()
    except OSError:
        return None
    end: int | None = None
    kind = ""
    end_basis = ""
    if data.startswith(b"\xff\xd8"):
        marker = data.rfind(b"\xff\xd9")
        if marker >= 0:
            end, kind, end_basis = marker + 2, "JPEG", "EOI marker"
    elif data.startswith(b"\x89PNG\r\n\x1a\n"):
        marker = data.rfind(b"IEND")
        if marker >= 4 and marker + 8 <= len(data):
            end, kind, end_basis = marker + 8, "PNG", "IEND chunk CRC end"
    elif len(data) >= 14 and data.startswith(b"BM"):
        declared_size = int.from_bytes(data[2:6], "little")
        if 14 <= declared_size <= len(data):
            end, kind, end_basis = declared_size, "BMP", "BITMAPFILEHEADER bfSize"
    elif data.startswith((b"GIF87a", b"GIF89a")):
        marker = data.rfind(b";")
        if marker >= 0:
            end, kind, end_basis = marker + 1, "GIF", "GIF trailer"
    if end is None or end >= len(data):
        return None
    trailing = data[end:]
    non_zero = sum(byte != 0 for byte in trailing)
    if non_zero == 0:
        return None
    preview = trailing[:256]
    return {
        "format": kind, "logical_end_offset": end, "logical_end_basis": end_basis,
        "trailing_bytes": len(trailing), "non_zero_trailing_bytes": non_zero,
        "trailing_sha256": hashlib.sha256(trailing).hexdigest(),
        "trailing_hex": preview.hex(),
        "trailing_text_preview": preview.decode("utf-8", errors="replace"),
        "interpretation": "Exact non-zero bytes exist after the format-defined image end.",
    }


def _run_steghide_info(img: Path, logger: logging.Logger) -> str:
    """
    Run ``steghide info`` on an image (no passphrase probe).

    Parameters
    ----------
    img    : Path to the image file.
    logger : Module logger.

    Returns
    -------
    stdout string from steghide.

    Raises
    ------
    FileNotFoundError       If steghide is not installed.
    subprocess.TimeoutExpired  If it exceeds STEGHIDE_TIMEOUT.
    """
    cmd = ["steghide", "info", str(img), "-p", ""]
    rc, stdout, stderr = _run_subprocess(cmd, timeout=STEGHIDE_TIMEOUT, logger=logger)
    return stdout + stderr


def _run_stegseek(img: Path, wordlist: str, output_dir: Path, logger: logging.Logger) -> tuple[bool, str]:
    """
    Run stegseek brute-force on an image.

    Parameters
    ----------
    img        : Path to the image.
    wordlist   : Path to the wordlist file.
    output_dir : Directory to write extracted content.
    logger     : Module logger.

    Returns
    -------
    Tuple of (cracked: bool, extracted_path: str).

    Raises
    ------
    FileNotFoundError       If stegseek is not installed.
    subprocess.TimeoutExpired  If it exceeds STEGSEEK_TIMEOUT.
    """
    out_path = output_dir / f"{img.stem}_stegseek_out"
    cmd = [
        "stegseek", str(img), wordlist,
        str(out_path), "--quiet",
    ]
    rc, stdout, stderr = _run_subprocess(cmd, timeout=STEGSEEK_TIMEOUT, logger=logger)
    combined = stdout + stderr
    cracked = rc == 0 and out_path.exists()
    return cracked, str(out_path) if cracked else ""


def _run_zsteg(img: Path, logger: logging.Logger) -> str:
    """
    Run zsteg LSB analysis on a PNG/BMP.

    Parameters
    ----------
    img    : Path to the image.
    logger : Module logger.

    Returns
    -------
    stdout from zsteg.

    Raises
    ------
    FileNotFoundError       If zsteg is not installed.
    subprocess.TimeoutExpired  If it exceeds ZSTEG_TIMEOUT.
    """
    cmd = ["zsteg", str(img), "-a"]
    rc, stdout, _ = _run_subprocess(cmd, timeout=ZSTEG_TIMEOUT, logger=logger)
    return stdout


def _run_outguess(img: Path, output_dir: Path, logger: logging.Logger) -> tuple[bool, str]:
    """
    Run outguess statistical analysis on a JPEG.

    Parameters
    ----------
    img        : Path to the image.
    output_dir : Directory to write extracted content.
    logger     : Module logger.

    Returns
    -------
    Tuple of (content_found: bool, output_path: str).

    Raises
    ------
    FileNotFoundError       If outguess is not installed.
    subprocess.TimeoutExpired  If it exceeds OUTGUESS_TIMEOUT.
    """
    out_path = output_dir / f"{img.stem}_outguess_out.txt"
    cmd = ["outguess", "-r", str(img), str(out_path)]
    rc, stdout, stderr = _run_subprocess(cmd, timeout=OUTGUESS_TIMEOUT, logger=logger)
    found = rc == 0 and out_path.exists() and out_path.stat().st_size > 0
    return found, str(out_path) if found else ""


def _has_zsteg_suspicious(output: str) -> bool:
    """Return True if zsteg output suggests hidden data beyond noise."""
    for line in output.splitlines():
        line = line.strip()
        if not line or "nothing found" in line.lower():
            continue
        # Skip short noise hits (single bytes)
        if re.search(r"\btext\b.*?\b\w{5,}", line, re.IGNORECASE):
            return True
        if "extradata" in line.lower():
            return True
    return False


def _steganography_verdict(
    findings: list,
    examined: int,
    status: "ModuleStatus",
    *,
    technique_applied: bool,
    notes: str = "",
) -> ClassResult:
    """Build the steganography class result under the strict absence gate.

    Native trailing-data and BMP heuristics are always applied.  VERIFIED_ABSENT
    is permitted only when every external layer required by the encountered file
    formats also ran successfully.
    """
    verdict, skip = resolve_absence_verdict(
        found=len(findings),
        examined=examined,
        technique_applied=technique_applied,
        status=status,
        reason_if_indeterminate=(None if technique_applied else SkipReason.LAYER2_UNVERIFIED),
    )
    return ClassResult(
        locus=Locus.IMAGES,
        artefact_class="Steganography Indicators",
        verdict=verdict,
        skip_reason=skip,
        count=len(findings),
        notes=notes,
    )


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Detect steganographic content in image/audio files.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Directory containing image/audio files to analyze.
    config        : Configuration dict; recognised keys:
                    - ``wordlist`` (str): wordlist for stegseek (default rockyou.txt).
                    - ``max_files`` (int): optional cap on files to analyze; 0 (default) is exhaustive.
                    - ``run_stegseek`` (bool): enable stegseek crack (default True).
                    - ``run_zsteg`` (bool): enable zsteg (default True).
                    - ``run_outguess`` (bool): enable outguess (default True).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with STEGANOGRAPHY_DETECTED, STEGANOGRAPHY_INDICATOR,
    STEGANOGRAPHY_EXTRACTED findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    _has_steghide = check_dependency("binary", "steghide", MODULE_NAME, logger)
    _has_stegseek = check_dependency("binary", "stegseek", MODULE_NAME, logger)
    _has_outguess = check_dependency("binary", "outguess", MODULE_NAME, logger)
    _has_zsteg = check_dependency("binary", "zsteg", MODULE_NAME, logger)
    # Native BMP/EOF heuristics always run. External tools broaden coverage but
    # their absence is a caveat, never a hard skip.

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    # Zero means exhaustive. A caller may impose a safety limit, but hitting
    # that limit is then reported as unresolved and prevents PASS_COMPLETE.
    max_files = int(config.get("max_files", 0) or 0)
    wordlist = config.get("wordlist", _DEFAULT_WORDLIST)
    do_stegseek = config.get("run_stegseek", True) and Path(wordlist).exists() and _has_stegseek
    do_zsteg = config.get("run_zsteg", True) and _has_zsteg
    do_outguess = config.get("run_outguess", True) and _has_outguess

    # Corpus roots come from what the recovery/carving modules actually
    # produced this run — never from assumed sibling directory names.
    _ws = config.get("_working_set", {})
    _corpus_roots = resolve_corpus_roots(_ws, output_dir=output_dir)
    original_files = iter_corpus_files(
        _ws, output_dir=output_dir, deduplicate_by_hash=False
    )
    all_image_files = _collect_image_files(original_files, 0)
    image_files = all_image_files[:max_files] if max_files > 0 else all_image_files
    limit_reached = bool(max_files > 0 and len(image_files) < len(all_image_files))
    if not image_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.IMAGES,
            artefact_class="Steganography Indicators",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NOT_APPLICABLE,
            notes="No image/audio files found to analyze",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no image/audio files found.",
        )
        result.class_results.append(cr)
        return result

    logger.info("[%s] Analyzing %d files for steganography", MODULE_NAME, len(image_files))

    stego_dir = output_dir / "stego_extracted"
    stego_dir.mkdir(parents=True, exist_ok=True)

    stats: dict[str, Any] = {
        "sources_discovered": len(image_files),
        "sources_processed": 0,
        "supported_objects_discovered": len(image_files),
        "supported_objects_processed": 0,
        "records_discovered": len(image_files),
        "records_processed": 0,
        "files_analyzed": 0,
        "steghide_positive": 0,
        "stegseek_cracked": 0,
        "zsteg_positive": 0,
        "outguess_positive": 0,
        "native_bmp_indicators": 0,
        "native_bmp_duplicate_aliases": 0,
        "native_trailing_data_indicators": 0,
    }

    seen_bmp_semantics: dict[tuple[Any, ...], str] = {}
    records: list[dict[str, Any]] = []
    steghide_available = _has_steghide
    stegseek_available = _has_stegseek
    zsteg_available = _has_zsteg
    outguess_available = _has_outguess

    for img in image_files:
        ext = img.suffix.lower()
        stats["files_analyzed"] += 1
        stats["sources_processed"] += 1
        stats["supported_objects_processed"] += 1
        stats["records_processed"] += 1
        rec: dict[str, Any] = {"file": str(img), "findings": []}

        # --- native checks (always available) ---
        if ext in _BMP_EXTENSIONS:
            decoded_payload = _native_bmp_lsb_payload(img)
            if decoded_payload:
                stats.setdefault("native_bmp_payloads_decoded", 0)
                stats["native_bmp_payloads_decoded"] += 1
                rec["findings"].append("native_bmp_lsb_payload_decoded")
                payload_file = stego_dir / f"{img.stem}_native_lsb_payload.bin"
                payload_file.write_bytes(bytes.fromhex(decoded_payload["payload_hex"]))
                artifact_paths.append(str(payload_file))
                findings.append(make_finding(
                    finding_type="STEGANOGRAPHIC_PAYLOAD_DECODED",
                    severity=Severity.MEDIUM,
                    description=(
                        f"A self-terminating {decoded_payload['channel']}-channel LSB payload "
                        f"was deterministically decoded from {img.name} ({decoded_payload['payload_length']} bytes)."
                    ),
                    evidence_path=str(img),
                    metadata={**deterministic_metadata(
                        "BMP pixel-channel LSB byte decoding with printable self-termination",
                        validators=["BMP structural parser", "NUL/zero-tail terminator", "payload SHA-256"],
                    ), "file_path": str(img), "file_sha256": hashlib.sha256(img.read_bytes()).hexdigest(), **decoded_payload},
                    artifact_path=str(payload_file),
                ))
            else:
                bmp_indicator = _native_bmp_lsb_indicator(img)
                if bmp_indicator:
                    semantic_key = (
                        bmp_indicator.get("width"), bmp_indicator.get("height"),
                        tuple(bmp_indicator.get("dominant_bgr") or []),
                        bmp_indicator.get("modified_pixels"), bmp_indicator.get("unique_colours"),
                    )
                    if semantic_key in seen_bmp_semantics:
                        stats["native_bmp_duplicate_aliases"] += 1
                        rec["findings"].append("native_bmp_duplicate_alias")
                        rec["semantic_alias_of"] = seen_bmp_semantics[semantic_key]
                    else:
                        seen_bmp_semantics[semantic_key] = str(img)
                        stats["native_bmp_indicators"] += 1
                        rec["findings"].append("native_bmp_lsb_candidate")
                        # Retain in the module report, not as a PRESENT finding.
                        rec["native_bmp_candidate"] = {
                            **candidate_metadata("BMP LSB distribution", reason="No self-terminating payload decoded"),
                            **bmp_indicator,
                        }
        trailing = _native_trailing_data(img)
        if trailing:
            stats["native_trailing_data_indicators"] += 1
            rec["findings"].append("native_trailing_data")
            findings.append(make_finding(
                finding_type="TRAILING_DATA_PRESENT",
                severity=Severity.INFO,
                description=(
                    f"Exactly {trailing['trailing_bytes']} non-container byte(s) occur after "
                    f"the normal {trailing['format']} end marker in {img.name}."
                ),
                evidence_path=str(img),
                metadata={**deterministic_metadata(
                    "format end-marker parsing and exact trailing-byte extraction",
                    validators=["JPEG/PNG/BMP/GIF structural end parser", "SHA-256"],
                ), "file_path": str(img), "file_sha256": hashlib.sha256(img.read_bytes()).hexdigest(), **trailing},
                artifact_path=str(img),
            ))

        # --- steghide info ---
        if ext in _STEGHIDE_EXTENSIONS and steghide_available:
            try:
                sh_out = _run_steghide_info(img, logger)
                if "steghide" in sh_out.lower() and "embedded" in sh_out.lower():
                    stats["steghide_positive"] += 1
                    rec["findings"].append("steghide_embedded")
                    findings.append(make_finding(
                        finding_type="STEGANOGRAPHY_DETECTED",
                        severity=Severity.HIGH,
                        description=(
                            f"steghide detected embedded content in {img.name}."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**deterministic_metadata("steghide engine reported embedded content", validators=["steghide"]), "file_path": str(img), "tool": "steghide"},
                        artifact_path=str(img),
                    ))
            except FileNotFoundError:
                steghide_available = False
                errors.append("steghide not found — install steghide package")
            except subprocess.TimeoutExpired:
                errors.append(f"steghide timed out on {img.name}")

        # --- stegseek brute-force ---
        if ext in _JPEG_EXTENSIONS and do_stegseek and stegseek_available:
            try:
                cracked, out_path = _run_stegseek(img, wordlist, stego_dir, logger)
                if cracked:
                    stats["stegseek_cracked"] += 1
                    rec["findings"].append("stegseek_cracked")
                    artifact_paths.append(out_path)
                    findings.append(make_finding(
                        finding_type="STEGANOGRAPHY_EXTRACTED",
                        severity=Severity.HIGH,
                        description=(
                            f"stegseek extracted hidden content from {img.name} "
                            f"(passphrase found via wordlist)."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**deterministic_metadata("stegseek extracted bytes with recovered passphrase", validators=["stegseek", "retained payload hash"]),
                            "file_path": str(img), "extracted_path": out_path, "tool": "stegseek"},
                        artifact_path=out_path,
                    ))
            except FileNotFoundError:
                stegseek_available = False
                errors.append("stegseek not found — install stegseek package")
            except subprocess.TimeoutExpired:
                errors.append(f"stegseek timed out on {img.name}")

        # --- zsteg LSB analysis ---
        if ext in _ZSTEG_EXTENSIONS and do_zsteg and zsteg_available:
            try:
                zs_out = _run_zsteg(img, logger)
                if _has_zsteg_suspicious(zs_out):
                    stats["zsteg_positive"] += 1
                    rec["findings"].append("zsteg_positive")
                    # Write zsteg output
                    zsteg_log = stego_dir / f"{img.stem}_zsteg.txt"
                    zsteg_log.write_text(zs_out, encoding="utf-8", errors="replace")
                    artifact_paths.append(str(zsteg_log))
                    findings.append(make_finding(
                        finding_type="STEGANOGRAPHY_INDICATOR",
                        severity=Severity.MEDIUM,
                        description=(
                            f"zsteg detected LSB steganography indicator in {img.name}."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**candidate_metadata(
                            "zsteg statistical/format indicator",
                            reason="No independently validated payload bytes",
                        ), "file_path": str(img), "zsteg_log": str(zsteg_log), "tool": "zsteg",
                           "candidate_only": True},
                        artifact_path=str(img),
                    ))
            except FileNotFoundError:
                zsteg_available = False
                errors.append("zsteg not found — install zsteg (gem install zsteg)")
            except subprocess.TimeoutExpired:
                errors.append(f"zsteg timed out on {img.name}")

        # --- outguess ---
        if ext in _JPEG_EXTENSIONS and do_outguess and outguess_available:
            try:
                found_content, out_path = _run_outguess(img, stego_dir, logger)
                if found_content:
                    stats["outguess_positive"] += 1
                    rec["findings"].append("outguess_positive")
                    artifact_paths.append(out_path)
                    findings.append(make_finding(
                        finding_type="STEGANOGRAPHY_EXTRACTED",
                        severity=Severity.HIGH,
                        description=(
                            f"outguess extracted hidden content from {img.name}."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**deterministic_metadata("outguess extracted retained payload bytes", validators=["outguess", "retained payload hash"]),
                            "file_path": str(img), "extracted_path": out_path, "tool": "outguess"},
                        artifact_path=out_path,
                    ))
            except FileNotFoundError:
                outguess_available = False
                errors.append("outguess not found — install outguess package")
            except subprocess.TimeoutExpired:
                errors.append(f"outguess timed out on {img.name}")

        if rec["findings"]:
            records.append(rec)

    # Write report
    report_path = output_dir / "steganography_report.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "tools_available": {
                    "steghide": steghide_available,
                    "stegseek": stegseek_available,
                    "zsteg": zsteg_available,
                    "outguess": outguess_available,
                    "native_bmp_lsb_candidate_screen": True,
                    "native_trailing_data": True,
                },
                "positive_files": records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write steganography_report.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Analyzed {stats['files_analyzed']} files: "
        f"{stats['steghide_positive']} steghide positives, "
        f"{stats['stegseek_cracked']} stegseek extractions, "
        f"{stats['zsteg_positive']} zsteg indicators, "
        f"{stats['outguess_positive']} outguess extractions, "
        f"{stats.get('native_bmp_payloads_decoded', 0)} deterministically decoded BMP LSB payload(s), "
        f"{stats['native_trailing_data_indicators']} validated appended-data finding(s), and "
        f"{stats['native_bmp_indicators']} statistical BMP candidate indicator(s)."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    encountered_exts = {p.suffix.lower() for p in image_files}
    required_tools: dict[str, bool] = {}
    if encountered_exts & _STEGHIDE_EXTENSIONS:
        required_tools["steghide"] = steghide_available
    if encountered_exts & _JPEG_EXTENSIONS and config.get("run_stegseek", True):
        required_tools["stegseek"] = stegseek_available and Path(wordlist).is_file()
    if encountered_exts & _ZSTEG_EXTENSIONS and config.get("run_zsteg", True):
        required_tools["zsteg"] = zsteg_available
    if encountered_exts & _JPEG_EXTENSIONS and config.get("run_outguess", True):
        required_tools["outguess"] = outguess_available
    missing_external = [name for name, available in required_tools.items() if not available]
    optional_warnings: list[str] = []
    require_external = bool(config.get("require_external_stego_tools", False))
    if missing_external:
        caveat = "Optional steganography enrichment layer(s) unavailable: " + ", ".join(missing_external)
        optional_warnings.append(caveat)
        if require_external:
            errors.append(caveat)
            status = ModuleStatus.PARTIAL
    else:
        caveat = "All format-applicable configured enrichment layers completed."

    if limit_reached:
        errors.append("The configured max_files limit prevented exhaustive supported-image analysis.")
        status = ModuleStatus.PARTIAL

    cr = _steganography_verdict(
        findings, stats["files_analyzed"], status,
        technique_applied=bool(findings) or (not missing_external and not errors),
        notes=caveat,
    )

    result = ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            **stats,
            "required_tools": required_tools,
            "missing_optional_tools": missing_external,
            "optional_tool_warnings": optional_warnings,
            "external_tools_required": require_external,
            "unresolved_supported_objects": (len(image_files) - int(stats["supported_objects_processed"])) + int(limit_reached),
            "parser_errors": len([error for error in errors if not str(error).startswith("Optional steganography enrichment")]),
            "declared_native_scope_completed": status == ModuleStatus.COMPLETED,
        }, summary=summary,
    )
    result.class_results.append(cr)
    return result
