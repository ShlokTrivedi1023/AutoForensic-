"""
file_signature_analyzer.py — File Signature vs Extension Mismatch Detector for AutoForensics.

Detects disguised files by comparing the actual file header (magic bytes) against the
declared file extension.  Attackers commonly rename executables as images or documents to
evade naive extension-based filters; this module catches those mismatches.

Detection strategy
------------------
1. Detect common file types with a dependency-free native signature/text classifier.
2. Use python-magic or ``file --mime-type`` only when the native classifier cannot
   identify the content; these are optional enrichment paths, not prerequisites.
3. Compare the detected MIME type against the expected MIME types for the file's extension.
4. Any mismatch is reported as a Finding; severity is HIGH when a binary (executable,
   script, archive) is disguised as a document or image.

Target platform : Kali Linux, Python 3.11+
External tools  : file (fallback only; part of base system)
Optional libs   : python-magic>=0.4.27
"""

from __future__ import annotations

import hashlib
import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    resolve_absence_verdict,
    utc_now,
)
from modules.signature_check import _mismatch_severity, publish_signature_mismatches

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# Guard: only import magic if it can be imported without crashing.  On Windows
# with a broken/incompatible libmagic DLL the import triggers a C-level access
# violation that a Python try/except cannot catch, so we probe in a subprocess
# first and only import in-process when that probe exits cleanly.
_magic_lib = None  # type: ignore[assignment]
_MAGIC_AVAILABLE = False

try:
    _probe = subprocess.run(
        [sys.executable, "-c", "import magic"],
        capture_output=True, timeout=10,
    )
    if _probe.returncode == 0:
        try:
            import magic as _magic_lib  # type: ignore[assignment]
            _MAGIC_AVAILABLE = True
        except Exception:
            _magic_lib = None  # type: ignore[assignment]
            _MAGIC_AVAILABLE = False
except Exception:
    _magic_lib = None  # type: ignore[assignment]
    _MAGIC_AVAILABLE = False

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "file_signature_analyzer"
FILE_CMD_TIMEOUT: int = 30   # seconds per ``file`` invocation

# ---------------------------------------------------------------------------
# Extension → expected MIME type mapping
# ---------------------------------------------------------------------------
# Each extension maps to a set of MIME types that are all legitimate for that
# extension.  Multiple MIME types are allowed to handle codec/subtype variation.

_EXT_TO_MIME: dict[str, set[str]] = {
    # Images
    ".jpg":  {"image/jpeg"},
    ".jpeg": {"image/jpeg"},
    ".png":  {"image/png"},
    ".gif":  {"image/gif"},
    ".bmp":  {"image/bmp", "image/x-bmp", "image/x-ms-bmp"},
    ".tif":  {"image/tiff"},
    ".tiff": {"image/tiff"},
    ".webp": {"image/webp"},
    ".ico":  {"image/x-icon", "image/vnd.microsoft.icon"},
    ".svg":  {"image/svg+xml", "text/html", "text/xml", "application/xml"},
    # Documents
    ".pdf":  {"application/pdf"},
    ".doc":  {"application/msword", "application/x-ole-storage"},
    ".docx": {"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              "application/zip"},
    ".xls":  {"application/vnd.ms-excel", "application/x-ole-storage"},
    ".xlsx": {"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              "application/zip"},
    ".ppt":  {"application/vnd.ms-powerpoint", "application/x-ole-storage"},
    ".pptx": {"application/vnd.openxmlformats-officedocument.presentationml.presentation",
              "application/zip"},
    ".odt":  {"application/vnd.oasis.opendocument.text", "application/zip"},
    ".ods":  {"application/vnd.oasis.opendocument.spreadsheet", "application/zip"},
    ".rtf":  {"text/rtf", "application/rtf"},
    # Archives
    ".zip":  {"application/zip"},
    ".rar":  {"application/x-rar-compressed", "application/vnd.rar"},
    ".7z":   {"application/x-7z-compressed"},
    ".gz":   {"application/gzip", "application/x-gzip"},
    ".tar":  {"application/x-tar"},
    ".bz2":  {"application/x-bzip2"},
    ".xz":   {"application/x-xz"},
    # Executables / scripts
    ".exe":  {"application/x-dosexec", "application/x-msdownload"},
    ".scr":  {"application/x-dosexec", "application/x-msdownload"},
    ".dll":  {"application/x-dosexec", "application/x-msdownload"},
    ".sys":  {"application/x-dosexec"},
    ".bat":  {"text/x-msdos-batch", "text/plain"},
    ".cmd":  {"text/x-msdos-batch", "text/plain"},
    ".ps1":  {"text/plain", "application/octet-stream"},
    ".sh":   {"text/x-shellscript", "text/plain", "application/x-sh"},
    ".py":   {"text/x-python", "text/plain"},
    ".js":   {"application/javascript", "text/javascript", "text/plain"},
    # Media
    ".mp3":  {"audio/mpeg"},
    ".mp4":  {"video/mp4"},
    ".avi":  {"video/x-msvideo"},
    ".mov":  {"video/quicktime"},
    ".mkv":  {"video/x-matroska"},
    ".wav":  {"audio/wav", "audio/x-wav"},
    # Data / text
    ".txt":  {"text/plain"},
    ".csv":  {"text/csv", "text/plain"},
    ".xml":  {"text/xml", "application/xml"},
    ".json": {"application/json", "text/plain"},
    ".html": {"text/html"},
    ".htm":  {"text/html"},
    ".sql":  {"text/plain", "application/sql"},
    # Certificates / keys
    ".pem":  {"text/plain"},
    ".p12":  {"application/x-pkcs12"},
    ".pfx":  {"application/x-pkcs12"},
    # Database
    ".db":   {"application/x-sqlite3"},
    ".sqlite": {"application/x-sqlite3"},
    ".mdb":  {"application/x-msaccess"},
}

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    """
    Write a chain-of-custody event silently; never propagate exceptions.

    Parameters
    ----------
    coc_logger : CustodyLogger or None.
    event      : Event name string.
    details    : Structured context dict.
    """
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass




def _detect_mime_native(file_path: Path) -> Optional[str]:
    """Return a MIME type from dependency-free signatures and text heuristics.

    The classifier intentionally covers the common types represented in
    ``_EXT_TO_MIME``. Optional libmagic/``file`` checks are used only when this
    function cannot decide, so absence of those dependencies never prevents the
    core mismatch check from running.
    """
    try:
        with open(file_path, "rb") as fh:
            data = fh.read(65536)
    except OSError:
        return None
    if not data:
        return "application/octet-stream"

    signatures = (
        (b"%PDF", "application/pdf"),
        (b"\x89PNG\r\n\x1a\n", "image/png"),
        (b"\xff\xd8\xff", "image/jpeg"),
        (b"GIF87a", "image/gif"),
        (b"GIF89a", "image/gif"),
        (b"BM", "image/bmp"),
        (b"PK\x03\x04", "application/zip"),
        (b"Rar!\x1a\x07", "application/vnd.rar"),
        (b"7z\xbc\xaf\x27\x1c", "application/x-7z-compressed"),
        (b"\x1f\x8b", "application/gzip"),
        (b"BZh", "application/x-bzip2"),
        (b"\xfd7zXZ\x00", "application/x-xz"),
        (b"SQLite format 3\x00", "application/x-sqlite3"),
        (b"\xd0\xcf\x11\xe0", "application/x-ole-storage"),
        (b"\x7fELF", "application/x-elf"),
        (b"RIFF", "application/octet-stream"),
    )
    for magic, mime in signatures:
        if data.startswith(magic):
            # Refine RIFF containers from their form type.
            if magic == b"RIFF" and len(data) >= 12:
                if data[8:12] == b"WAVE":
                    return "audio/wav"
                if data[8:12] == b"AVI ":
                    return "video/x-msvideo"
            return mime

    # A genuine PE carries an e_lfanew pointer at 0x3c and a PE signature at
    # that offset. Text beginning with the letters "MZ" is a common decoy and
    # must not be promoted to an executable solely from two printable bytes.
    if data.startswith(b"MZ"):
        if len(data) >= 64:
            pe_off = int.from_bytes(data[0x3C:0x40], "little", signed=False)
            if 0 < pe_off <= len(data) - 4 and data[pe_off:pe_off + 4] == b"PE\x00\x00":
                return "application/x-dosexec"
        sample = data[:4096]
        printable = sum(1 for b in sample if b in b"\t\n\r" or 32 <= b <= 126)
        if sample and printable / len(sample) >= 0.90:
            return "text/plain"
        return "application/x-dosexec"

    # Lightweight structured-text refinements before the generic text gate.
    stripped = data.lstrip()
    lower = stripped[:512].lower()
    if lower.startswith((b"<?xml", b"<svg", b"<html", b"<!doctype html")):
        if b"<svg" in lower:
            return "image/svg+xml"
        if b"<html" in lower or b"<!doctype html" in lower:
            return "text/html"
        return "application/xml"
    if stripped.startswith((b"{", b"[")):
        try:
            json.loads(stripped.decode("utf-8"))
            return "application/json"
        except (UnicodeDecodeError, json.JSONDecodeError):
            pass

    sample = data[:8192]
    if b"\x00" not in sample:
        printable = sum(1 for b in sample if b in b"\t\n\r\f\b" or 32 <= b <= 126)
        if sample and printable / len(sample) >= 0.85:
            return "text/plain"
    return None


def _detect_mime_magic(file_path: Path) -> Optional[str]:
    """
    Return MIME type using python-magic (libmagic).

    Parameters
    ----------
    file_path : Path to the file to inspect.

    Returns
    -------
    MIME type string, or None if detection fails.
    """
    if not _MAGIC_AVAILABLE:
        return None
    try:
        return _magic_lib.from_file(str(file_path), mime=True)  # type: ignore[union-attr]
    except Exception:
        return None


def _detect_mime_file_cmd(
    file_path: Path,
    logger: logging.Logger,
) -> Optional[str]:
    """
    Return MIME type using the ``file --mime-type`` command.

    Parameters
    ----------
    file_path : Path to the file.
    logger    : Module logger.

    Returns
    -------
    MIME type string, or None if the command fails.
    """
    try:
        rc, stdout, _ = _run_subprocess(
            ["file", "--mime-type", "-b", str(file_path)],
            timeout=FILE_CMD_TIMEOUT,
            logger=logger,
        )
        if rc == 0 and stdout.strip():
            return stdout.strip().lower()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _is_double_extension_decoy(file_path: Path, detected_mime: str) -> bool:
    """Return True for text-content files carrying a suspicious double suffix.

    Such names are anti-forensic filename indicators.  They are not also
    content-signature mismatches unless executable/binary magic is present.
    """
    suffixes = [suffix.lower() for suffix in file_path.suffixes]
    if len(suffixes) < 2:
        return False
    executable_suffixes = {".exe", ".scr", ".com", ".bat", ".cmd", ".ps1", ".js", ".vbs"}
    plausible_inner = set(_EXT_TO_MIME) - executable_suffixes
    return (suffixes[-1] in executable_suffixes and suffixes[-2] in plausible_inner
            and detected_mime in {"text/plain", "application/octet-stream"})


def _collect_files(scan_root: Path) -> list[Path]:
    """
    Recursively enumerate regular files under scan_root.

    Parameters
    ----------
    scan_root : Directory to walk.

    Returns
    -------
    List of Path objects for all regular files found.
    """
    files: list[Path] = []
    try:
        for item in scan_root.rglob("*"):
            if item.is_file() and not item.is_symlink():
                files.append(item)
    except PermissionError:
        pass
    return files


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Detect files whose content does not match their declared extension.

    The module scans ``output_dir`` (where other modules deposit extracted
    files) for extension/content mismatches.  If a ``scan_path`` key is
    present in ``config`` it is used as an additional scan root.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image (used for
                    evidence_path field in findings; not scanned directly).
    case_id       : Unique case identifier.
    output_dir    : Directory written by previous modules; scanned recursively.
    config        : Configuration dict; recognised keys:
                    - ``scan_path`` (str): additional directory to scan.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with one Finding per mismatch detected.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run.
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    scan_root_ws = str(_corpus_roots[0]) if _corpus_roots else None
    if not _corpus_roots:
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="File Signature Anomalies",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — no recovered/carved corpus was available to examine",
            findings=[], errors=[], statistics={},
            class_results=[cr],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    report_records: list[dict[str, Any]] = []

    detection_method = "native-signature-first"
    logger.info("[%s] Starting — detection method: %s", MODULE_NAME, detection_method)

    # Collect scan roots
    scan_roots: list[Path] = list(_corpus_roots)
    extra = config.get("scan_path")
    if extra:
        extra_path = Path(extra)
        if extra_path.is_dir():
            scan_roots.append(extra_path)
        else:
            logger.warning("[%s] scan_path does not exist: %s", MODULE_NAME, extra)

    all_files: list[Path] = []
    for root in scan_roots:
        all_files.extend(_collect_files(root))

    # Extension/signature analysis is path-specific. Byte-identical aliases must
    # not be collapsed before comparing each filename: the same bytes can be a
    # valid PNG at one path and a disguised .TXT at another. Aliases are retained
    # in metadata for correlation instead.
    unique_by_path: dict[str, Path] = {}
    hashes_by_path: dict[str, str] = {}
    aliases_by_hash: dict[str, list[str]] = {}
    for f in all_files:
        try:
            key = str(f.resolve())
            digest = hashlib.sha256(f.read_bytes()).hexdigest()
        except OSError:
            key = str(f)
            digest = ""
        unique_by_path.setdefault(key, f)
        hashes_by_path[key] = digest
        if digest:
            aliases_by_hash.setdefault(digest, []).append(key)
    unique_files = sorted(unique_by_path.values(), key=lambda p: str(p))

    logger.info("[%s] Scanning %d path-distinct files", MODULE_NAME, len(unique_files))

    total_scanned = 0
    mismatches_found = 0
    # Authoritative magic-byte-vs-extension records, published to the shared
    # working-set so downstream modules consume this exact result instead of
    # computing a second, contradicting count.
    shared_mismatch_records: list[dict] = []
    # checkable_count: files with a known extension that the ext-vs-signature
    # technique actually applies to.  detected_count: how many of those were
    # successfully classified by a working detector (magic or the file cmd).
    # If checkable_count > 0 but detected_count == 0 the detector was
    # unavailable, so absence cannot be confirmed.
    checkable_count = 0
    detected_count = 0
    severity_counts: dict[str, int] = {"HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}

    for file_path in unique_files:
        ext = file_path.suffix.lower()
        if ext not in _EXT_TO_MIME:
            # No known expected MIME for this extension — skip
            total_scanned += 1
            report_records.append({
                "path": str(file_path),
                "extension": ext,
                "detected_mime": None,
                "status": "SKIPPED_UNKNOWN_EXT",
            })
            continue

        # Known extension → the ext-vs-signature technique applies here.
        checkable_count += 1

        # Detect MIME type
        detected_mime: Optional[str] = _detect_mime_native(file_path)
        per_file_method = "native-signature"
        if detected_mime is None:
            detected_mime = _detect_mime_magic(file_path)
            per_file_method = "python-magic" if detected_mime is not None else per_file_method
        if detected_mime is None:
            detected_mime = _detect_mime_file_cmd(file_path, logger)
            per_file_method = "file-command" if detected_mime is not None else per_file_method
        if detected_mime is not None:
            detected_count += 1

        total_scanned += 1

        if detected_mime is None:
            errors.append(f"Could not determine MIME type for {file_path}")
            report_records.append({
                "path": str(file_path),
                "extension": ext,
                "detected_mime": None,
                "status": "DETECTION_FAILED",
            })
            continue

        expected_mimes = _EXT_TO_MIME[ext]
        # Normalise: strip parameters (e.g. "text/plain; charset=utf-8" → "text/plain")
        detected_base = detected_mime.split(";")[0].strip().lower()

        match = any(detected_base == exp or detected_base.startswith(exp.split("/")[0] + "/")
                    and detected_base == exp
                    for exp in expected_mimes)
        # Exact match check
        exact_match = detected_base in expected_mimes

        delegated_double_extension = _is_double_extension_decoy(file_path, detected_base)
        record: dict[str, Any] = {
            "path": str(file_path),
            "extension": ext,
            "detected_mime": detected_base,
            "expected_mimes": list(expected_mimes),
            "status": ("DOUBLE_EXTENSION_DELEGATED" if delegated_double_extension
                       else "OK" if exact_match else "MISMATCH"),
        }

        if not exact_match and not delegated_double_extension:
            # Category-derived severity from the single shared function, so this
            # module's finding and its published record carry the exact severity
            # the report render reads — no blanket HIGH, no second computation.
            severity = Severity(_mismatch_severity(detected_base, ext.lstrip(".")).upper())
            severity_counts[severity.value] += 1
            mismatches_found += 1

            finding = make_finding(
                finding_type="FILE_SIGNATURE_MISMATCH",
                severity=severity,
                description=(
                    f"File extension '{ext}' claims MIME types {expected_mimes} "
                    f"but content is detected as '{detected_base}'. "
                    f"File: {file_path.name}"
                ),
                evidence_path=str(file_path),
                artifact_path=str(file_path),
                metadata={
                    **deterministic_metadata(
                        "exact file-header/structure versus declared extension",
                        validators=[per_file_method],
                    ),
                    "file_path": str(file_path),
                    "file_sha256": hashes_by_path.get(str(file_path.resolve()), ""),
                    "byte_identical_aliases": aliases_by_hash.get(hashes_by_path.get(str(file_path.resolve()), ""), []),
                    "file_name": file_path.name,
                    "declared_extension": ext,
                    "detected_mime": detected_base,
                    "expected_mimes": list(expected_mimes),
                    "detection_method": per_file_method,
                },
            )
            findings.append(finding)
            record["severity"] = severity.value
            shared_mismatch_records.append({
                "path":          str(file_path),
                "name":          file_path.name,
                "declared_ext":  ext.lstrip("."),
                "detected_mime": detected_base,
                "detected_type": detected_base,
                "expected_ext":  ", ".join(expected_mimes),
                # Same category severity the finding uses, so the render reads it
                # rather than falling back to a blanket HIGH.
                "severity":      severity.value.lower(),
            })
            logger.warning(
                "[%s] MISMATCH [%s] %s — detected=%s expected=%s",
                MODULE_NAME, severity.value, file_path.name, detected_base, expected_mimes,
            )

        report_records.append(record)

    # Publish the authoritative result so filesystem_deep_analyzer (and any
    # later consumer) reports the identical magic-byte-vs-extension count.
    _ws = config.get("_working_set")
    if isinstance(_ws, dict):
        publish_signature_mismatches(_ws, shared_mismatch_records)

    # Write report
    report_path = output_dir / "file_signature_report.json"
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        report = {
            "module": MODULE_NAME,
            "case_id": case_id,
            "generated_at": utc_now(),
            "detection_method": detection_method,
            "total_files_scanned": total_scanned,
            "path_distinct_files": len(unique_files),
            "byte_identical_alias_groups": sum(1 for v in aliases_by_hash.values() if len(v) > 1),
            "mismatches_found": mismatches_found,
            "severity_counts": severity_counts,
            "files": report_records,
        }
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
        logger.info("[%s] Report written to %s", MODULE_NAME, report_path)
    except OSError as exc:
        errors.append(f"Failed to write report: {exc}")

    end_time = utc_now()
    from datetime import datetime, timezone
    start_dt = datetime.fromisoformat(start_time)
    end_dt = datetime.fromisoformat(end_time)
    duration = (end_dt - start_dt).total_seconds()

    status = ModuleStatus.COMPLETED if not errors or findings else ModuleStatus.PARTIAL
    if total_scanned == 0:
        status = ModuleStatus.SKIPPED

    summary = (
        f"Scanned {total_scanned} files; found {mismatches_found} signature mismatches "
        f"({severity_counts['HIGH']} HIGH, {severity_counts['MEDIUM']} MEDIUM)."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED" if status != ModuleStatus.FAILED else "MODULE_FAILED",
             {"module": MODULE_NAME, "case_id": case_id, "findings": len(findings),
              "mismatches": mismatches_found})

    if status == ModuleStatus.SKIPPED:
        _cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="File Signature Anomalies",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
    else:
        # Absence of signature anomalies is only "verified" if a working
        # detector actually classified the checkable files.  If there were
        # known-extension files but none could be classified, the detector
        # (magic / file) was unavailable — absence is unconfirmed.
        _detector_missing = checkable_count > 0 and detected_count == 0
        _verdict, _skip = resolve_absence_verdict(
            found=len(findings),
            examined=total_scanned,
            technique_applied=not _detector_missing,
            status=status,
            reason_if_indeterminate=(
                SkipReason.DEPENDENCY_MISSING if _detector_missing else None
            ),
        )
        _cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="File Signature Anomalies",
            verdict=_verdict,
            skip_reason=_skip,
            count=len(findings),
            notes=(
                "Content MIME detector (magic/file) unavailable — signature "
                "absence unverified." if _detector_missing else ""
            ),
        )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics={
            "total_files_scanned": total_scanned,
            "mismatches_found": mismatches_found,
            "by_severity": severity_counts,
            "detection_method": detection_method,
        },
        summary=summary,
        class_results=[_cr],
    )
