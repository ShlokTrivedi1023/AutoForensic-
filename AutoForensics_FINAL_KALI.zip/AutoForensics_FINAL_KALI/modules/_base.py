"""
_base.py — Shared data structures, utilities, and subprocess wrapper for AutoForensics.

This module provides the foundational types used by every analysis module in the platform:

  - ModuleStatus: describes the completion state of a module run.
  - Severity: classifies the forensic significance of a finding.
  - Finding: a single forensic observation (deleted file, mismatch, artefact, etc.).
  - ModuleResult: the complete output record for one module execution against one case.

It also provides three utility helpers:

  utc_now()         — a consistent, millisecond-precision UTC timestamp string.
  make_finding()    — a factory that auto-generates a UUID and current timestamp for
                      each Finding, reducing boilerplate in every module.
  _run_subprocess() — the single authorised way to execute external tools.  All tool
                      invocations in this codebase MUST go through this wrapper so that
                      security invariants (no shell=True, mandatory timeout, full
                      command logging) are enforced in exactly one place.

Design rationale
----------------
Every module produces a ModuleResult that is serialisable to JSON.  The platform
aggregates these results into a final case report.  Keeping the dataclasses here — rather
than in each module — means the aggregation layer can import one file and deserialise
results from any module without knowing module internals.

Python version: 3.11+
Target OS     : Kali Linux (subprocess environment is POSIX)
"""

from __future__ import annotations

import importlib as _importlib_dep
import logging
import shutil as _shutil_dep
import subprocess
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Memory source helpers
# ---------------------------------------------------------------------------

_MEMORY_EXTENSIONS = frozenset({
    ".raw", ".lime", ".dmp", ".vmem", ".mem", ".bin",
})
_MEMORY_FILENAMES = frozenset({
    "hiberfil.sys", "pagefile.sys", "swapfile.sys",
})


def find_memory_sources(
    evidence_path: "Path",
    output_dir: "Path",
    config: dict,
) -> "list[Path]":
    """Return ordered, de-duplicated memory sources.

    Explicit first-class and recursively discovered nested sources are checked
    before legacy sibling/output searches. Byte-identical aliases are collapsed
    so RAW/BIN/MEM/VMEM wrappers of the same bytes are not treated as separate
    corroboration.
    """
    candidates: list[Path] = []

    def _add(value: "Any") -> None:
        if not value:
            return
        p = Path(str(value))
        if p.is_file():
            candidates.append(p)

    _add(config.get("memory_image"))
    _add(config.get("memory_path"))
    for value in config.get("memory_paths") or []:
        _add(value)
    # Marker-only memory corpora are usable for deterministic string-marker
    # extraction, but modules must not claim kernel/process semantics from them.
    for value in config.get("memory_marker_paths") or []:
        _add(value)
    ws = config.get("_working_set") or {}
    for key in ("nested_memory_sources", "nested_memory_marker_sources"):
        for value in ws.get(key) or []:
            _add(value)

    parent = Path(evidence_path).parent if Path(evidence_path).is_file() else Path(evidence_path)
    try:
        children = list(parent.iterdir()) if parent.is_dir() else []
    except OSError:
        children = []
    for child in children:
        if child.is_file() and (child.suffix.lower() in _MEMORY_EXTENSIONS or child.name.lower() in _MEMORY_FILENAMES):
            candidates.append(child)

    carved_root = Path(output_dir).parent
    for name in _MEMORY_FILENAMES:
        candidate = carved_root / name
        if candidate.is_file():
            candidates.append(candidate)

    unique: list[Path] = []
    seen_paths: set[str] = set()
    seen_hashes: set[str] = set()
    import hashlib
    for candidate in candidates:
        try:
            resolved = str(candidate.resolve())
        except OSError:
            resolved = str(candidate)
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        try:
            h = hashlib.sha256()
            with candidate.open("rb") as fh:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(block)
            digest = h.hexdigest()
        except OSError:
            digest = "path:" + resolved
        if digest in seen_hashes:
            continue
        seen_hashes.add(digest)
        unique.append(candidate)
    return unique


def find_memory_source(
    evidence_path: "Path",
    output_dir: "Path",
    config: dict,
) -> "Optional[Path]":
    """Compatibility helper returning the first canonical memory source."""
    sources = find_memory_sources(evidence_path, output_dir, config)
    return sources[0] if sources else None


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class ModuleStatus(str, Enum):
    """
    Represents the overall completion state of a module run.

    COMPLETED     — every planned step ran successfully; results are fully reliable.
    PARTIAL       — at least one step failed but at least one succeeded; results are
                    present but may be incomplete.  Callers should inspect errors[].
    SKIPPED       — the module was not applicable to this evidence type or was disabled
                    by configuration; findings[] will be empty.
    ERROR         — subprocess returned rc!=0, crashed, or timed out; results are
                    unreliable or absent.
    IMPORT_FAILED — the module file could not be imported; no results are available.
    FAILED        — general unrecoverable failure; errors[] explains why.
    FAILED_OFFSET — TSK exit -11 / partition offset not detected.
    """

    # Final court-facing execution states. PASS_COMPLETE is issued only by
    # core.module_completion after coverage and provenance certification.
    PASS_COMPLETE           = "PASS_COMPLETE"
    INCOMPLETE              = "INCOMPLETE"
    OUT_OF_SCOPE            = "OUT_OF_SCOPE"

    # Internal/legacy module-return states retained for compatibility. The
    # orchestrator converts them to one of the final states above.
    COMPLETED               = "COMPLETED"
    COMPLETED_WITH_FALLBACK = "COMPLETED_WITH_FALLBACK"
    PARTIAL                 = "PARTIAL"
    FAILED_ISOLATED         = "FAILED_ISOLATED"
    NOT_APPLICABLE          = "NOT_APPLICABLE"
    VERIFY_LATER            = "VERIFY_LATER"
    SKIPPED                 = "SKIPPED"  # legacy compatibility; prefer NOT_APPLICABLE/VERIFY_LATER
    ERROR                   = "ERROR"    # legacy compatibility; orchestrator converts to FAILED_ISOLATED
    IMPORT_FAILED           = "IMPORT_FAILED"
    FAILED                  = "FAILED"
    FAILED_OFFSET           = "FAILED_OFFSET"   # TSK exit -11 / partition offset not detected


def assert_subprocess_ok(
    rc: int,
    stderr: str,
    context: str,
    logger: "logging.Logger",
) -> None:
    """Raise RuntimeError if rc != 0 so callers can catch and set ERROR status."""
    if rc != 0:
        msg = f"{context} returned rc={rc}. stderr: {(stderr or '').strip()[:300]}"
        logger.warning(msg)
        raise RuntimeError(msg)


class Severity(str, Enum):
    """
    Classifies the forensic significance of a Finding.

    HIGH   — strong indicator of malicious, suspicious, or illegal activity that
             requires immediate analyst attention.
    MEDIUM — potentially significant artefact; further investigation is warranted.
    LOW    — minor anomaly or housekeeping artefact; review if time permits.
    INFO   — purely informational; provides context for other findings.
    """

    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class AssuranceVerdict(str, Enum):
    """The evidential verdict for an artefact class within a module run."""
    PRESENT          = "PRESENT"           # artefact class found
    VERIFIED_ABSENT  = "VERIFIED_ABSENT"   # examined, confirmed not present
    INDETERMINATE    = "INDETERMINATE"     # could not determine (tool unavailable, timeout, etc.)


class SkipReason(str, Enum):
    """Why a ClassResult has INDETERMINATE verdict."""
    DEPENDENCY_MISSING = "DEPENDENCY_MISSING"   # tool or library not installed
    NO_EVIDENCE        = "NO_EVIDENCE"          # no evidence image/path to examine
    NO_CORPUS          = "NO_CORPUS"            # no extracted/carved file corpus to search
    TIMEOUT            = "TIMEOUT"              # tool timed out
    NOT_APPLICABLE     = "NOT_APPLICABLE"       # this artefact class cannot exist in this evidence type
    PARTIAL_FAILURE    = "PARTIAL_FAILURE"      # tool ran but produced partial/unreliable output
    LAYER2_UNVERIFIED  = "LAYER2_UNVERIFIED"    # VERIFIED_ABSENT requires Layer 2 confirmation; only Layer 1 done
    WRONG_FS           = "WRONG_FS"             # artefact class is specific to a filesystem this image is not
    SKIPPED            = "SKIPPED"              # module did not complete the examination step
    OTHER              = "OTHER"


class Locus(str, Enum):
    """The artefact domain or storage location examined by a module."""
    FILE_SYSTEM    = "FILE_SYSTEM"
    DELETED_FILES  = "DELETED_FILES"
    REGISTRY       = "REGISTRY"
    EMAIL          = "EMAIL"
    BROWSER        = "BROWSER"
    NETWORK        = "NETWORK"
    MEMORY         = "MEMORY"
    PASSWORDS      = "PASSWORDS"
    METADATA       = "METADATA"
    HASH_VERIFY    = "HASH_VERIFY"
    ANTI_FORENSICS = "ANTI_FORENSICS"
    MALWARE        = "MALWARE"
    IMAGES         = "IMAGES"
    TIMELINE       = "TIMELINE"
    OTHER          = "OTHER"


# ---------------------------------------------------------------------------
# Core dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ClassResult:
    """
    Per-artefact-class verdict for one module run.

    Records what class of artefacts a module examined, whether any were found,
    and — if applicable — why the verdict is INDETERMINATE.
    """
    locus:          Locus
    artefact_class: str              # human label, e.g. "Deleted Files", "USB Registry Keys"
    verdict:        AssuranceVerdict
    skip_reason:    Optional[SkipReason] = None
    count:          int = 0          # number of artefacts found (meaningful when verdict==PRESENT)
    notes:          str = ""
    # True when ``count`` is a raw artefact tally that a module deliberately
    # consolidates into far fewer rendered findings (e.g. a carver: thousands of
    # candidate files → one summary finding).  The coverage table then keeps the
    # artefact tally instead of reconciling it to the rendered-finding count.
    summarised:     bool = False


def resolve_absence_verdict(
    *,
    found: int,
    examined: int,
    technique_applied: bool,
    status: "ModuleStatus",
    reason_if_indeterminate: "Optional[SkipReason]" = None,
) -> "tuple[AssuranceVerdict, Optional[SkipReason]]":
    """
    Court-critical gate for the (verdict, skip_reason) of a ClassResult.

    A module may only report VERIFIED_ABSENT ("examined, confirmed not present")
    when ALL of the following hold:

      * the module actually COMPLETED its run,
      * it examined a non-empty corpus (``examined > 0``), and
      * it applied the technique appropriate to the artefact class
        (``technique_applied`` — e.g. the right tool ran, the right file class
        was checked, both detection layers were performed).

    Otherwise the honest verdict is INDETERMINATE with an explanatory
    SkipReason, because "we did not look properly" is not "we looked and it
    is not there".  A false VERIFIED_ABSENT is court-fatal.

    Parameters
    ----------
    found:
        Number of artefacts of this class discovered (>0 ⇒ PRESENT).
    examined:
        Number of items actually examined with the appropriate technique.
    technique_applied:
        True only when the technique adequate to *confirm absence* was applied
        (tool available AND the complete detection method performed).
    status:
        The module's overall ModuleStatus for this run.
    reason_if_indeterminate:
        Optional explicit SkipReason to record when the gate fails.  When None,
        a reason is derived: NO_CORPUS (nothing examined), LAYER2_UNVERIFIED
        (technique incomplete), or SKIPPED (run did not complete).

    Returns
    -------
    tuple[AssuranceVerdict, Optional[SkipReason]]
        The gated verdict and its skip_reason (None unless INDETERMINATE).
    """
    if found > 0:
        return AssuranceVerdict.PRESENT, None

    if (
        status == ModuleStatus.COMPLETED
        and examined > 0
        and technique_applied
    ):
        return AssuranceVerdict.VERIFIED_ABSENT, None

    if reason_if_indeterminate is not None:
        reason = reason_if_indeterminate
    elif examined <= 0:
        reason = SkipReason.NO_CORPUS
    elif not technique_applied:
        reason = SkipReason.LAYER2_UNVERIFIED
    else:
        reason = SkipReason.SKIPPED

    return AssuranceVerdict.INDETERMINATE, reason


@dataclass
class Finding:
    """
    A single forensic observation extracted from the evidence.

    Attributes
    ----------
    finding_id    : Globally unique identifier for this finding (UUID4 string).
                    Used to cross-reference findings across modules and in the
                    final report.
    finding_type  : Short machine-readable label, e.g. "DELETED_FILE",
                    "EXTENSION_MISMATCH", "ZERO_BYTE_FILE".  Upper-snake-case
                    convention.
    severity      : How significant this finding is; see Severity enum.
    description   : Human-readable narrative explaining what was found and
                    why it is significant.
    evidence_path : The path *within the image or on the mounted filesystem*
                    where this artefact was observed.  This is the forensically
                    significant path, not a path to any extracted copy.
    artifact_path : Optional absolute path to an extracted copy of the artefact
                    that was written into the case output directory.  None when
                    no file was extracted.
    metadata      : Free-form dict carrying structured attributes specific to
                    the finding type.  Examples: {"inode": 42, "mtime": "…"},
                    {"declared_mime": "image/png", "detected_mime": "application/x-elf"}.
    timestamp     : UTC ISO 8601 string (ms precision) recording when this
                    finding was created by the module.
    """

    finding_id: str
    finding_type: str
    severity: Severity
    description: str
    evidence_path: str
    artifact_path: Optional[str]
    metadata: dict[str, Any]
    timestamp: str
    evidence_reference: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModuleResult:
    """
    The complete output record produced by one module run against one case.

    A ModuleResult is designed to be fully serialisable to JSON via dataclasses.asdict()
    (Severity and ModuleStatus are str subclasses so they serialise as plain strings).
    The platform aggregation layer collects one ModuleResult per module and combines them
    into the final case report.

    Attributes
    ----------
    module_name      : Canonical name of the module, e.g. "filesystem_analyzer".
    case_id          : The case identifier provided to run().
    status           : Overall completion state; see ModuleStatus.
    start_time       : UTC ISO 8601 timestamp when run() was called.
    end_time         : UTC ISO 8601 timestamp when run() returned.
    duration_seconds : Wall-clock seconds between start_time and end_time.
    findings         : List of Finding objects produced during the run.
    artifact_paths   : Absolute paths of every file written to disk by this module.
                       Used by the platform to collect artefacts for chain-of-custody.
    errors           : Non-fatal error messages.  The presence of entries here does not
                       necessarily mean status==FAILED; it depends on what failed.
    statistics       : Module-specific numeric and string metrics, e.g.
                       {"total_files": 1234, "deleted_files": 7}.
    summary          : One-line human-readable sentence describing the overall result,
                       suitable for display in a dashboard or report header.
    """

    module_name: str
    case_id: str
    status: ModuleStatus
    start_time: str = ""
    end_time: str = ""
    duration_seconds: float = 0.0
    findings: list[Finding] = field(default_factory=list)
    artifact_paths: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    statistics: dict[str, Any] = field(default_factory=dict)
    summary: str = ""
    class_results: list[ClassResult] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def utc_now() -> str:
    """
    Return the current UTC time as an ISO 8601 string with millisecond precision.

    Example output: "2024-11-07T14:32:01.123000+00:00"

    Using timezone.utc ensures the string is always UTC regardless of the host's
    local timezone setting, which is important for forensic reproducibility — two
    analysts in different timezones must see the same timestamp.

    Returns
    -------
    str
        UTC ISO 8601 timestamp string including timezone offset (+00:00).
    """
    # datetime.now(timezone.utc) is preferred over datetime.utcnow() because
    # utcnow() returns a naive datetime that can be misinterpreted as local time.
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def make_finding(
    finding_type: str,
    severity: Severity,
    description: str,
    evidence_path: str,
    metadata: dict[str, Any],
    artifact_path: Optional[str] = None,
) -> Finding:
    """
    Factory function that constructs a Finding with auto-generated id and timestamp.

    Using a factory rather than direct dataclass construction ensures that every
    Finding gets a unique UUID and a consistent UTC timestamp without the caller
    having to remember to populate those fields.

    Parameters
    ----------
    finding_type  : Short machine-readable label (e.g. "DELETED_FILE").
    severity      : Forensic significance classification.
    description   : Human-readable narrative for this finding.
    evidence_path : Path within the image/mount where the artefact was observed.
    metadata      : Dict of structured attributes specific to this finding type.
    artifact_path : Optional path to an extracted copy of the artefact on disk.

    Returns
    -------
    Finding
        A fully populated Finding instance ready to be appended to ModuleResult.findings.
    """
    return Finding(
        # uuid4 gives a cryptographically random identifier; uuid1 would embed the MAC
        # address which is a privacy concern and adds no forensic value here.
        finding_id=str(uuid.uuid4()),
        finding_type=finding_type,
        severity=severity,
        description=description,
        evidence_path=evidence_path,
        artifact_path=artifact_path,
        metadata=dict(metadata),  # defensive copy — caller must not be able to mutate stored metadata
        timestamp=utc_now(),
        evidence_reference={},
    )


def _run_subprocess(
    cmd: list[str],
    timeout: int,
    logger: logging.Logger,
    cwd: Optional[str] = None,
) -> tuple[int, str, str]:
    """
    Execute an external command safely and return its exit code, stdout, and stderr.

    This is the ONLY authorised way to run external tools in AutoForensics.
    All callers must pass a list of arguments — never a shell command string — and must
    provide a reasonable timeout.  These invariants are enforced here in one place so
    that security audits only need to inspect this function.

    Security rationale — why shell=False (the default):
        shell=True passes the command to /bin/sh for interpretation.  If any element of
        ``cmd`` contains shell metacharacters (spaces, semicolons, backticks, $(), etc.),
        the shell may interpret them in ways the caller did not intend.  In a forensics
        context the paths derived from evidence images can contain arbitrary byte
        sequences; any one of them could break out of a shell command and execute
        arbitrary code on the analyst's workstation — a critical integrity violation.
        Passing an argument list bypasses the shell entirely: each element is delivered
        verbatim to execvp(2), so metacharacters have no special meaning.

    Timeout rationale:
        Some TSK operations on very large images (multi-terabyte) can run for hours.
        Without a timeout a hung process would block the entire pipeline indefinitely.
        The caller supplies the timeout so that each module can use a value appropriate
        to the expected duration of the specific tool (e.g. 2 h for carving, 1 h for fls).

    Parameters
    ----------
    cmd     : Argument list.  cmd[0] must be the full or PATH-resolvable binary name.
              Example: ["fls", "-r", "-m", "/", "/evidence/disk.img"]
    timeout : Maximum seconds to wait for the process to complete.  SubprocessError is
              raised if the process does not finish within this time.
    logger  : Module-level logger; the command line and result are logged at DEBUG.
    cwd     : Optional working directory for the child process.  If None the child
              inherits the parent's cwd.

    Returns
    -------
    tuple[int, str, str]
        (returncode, stdout_text, stderr_text)
        stdout and stderr are decoded from UTF-8 with errors='replace' so that binary
        output embedded in TSK output does not raise a UnicodeDecodeError.

    Raises
    ------
    subprocess.TimeoutExpired
        Re-raised after logging if the process exceeds ``timeout`` seconds.  The caller
        is responsible for killing the child and recording the error.
    FileNotFoundError
        Re-raised if cmd[0] cannot be found on PATH.  Callers interpret this as the
        tool being unavailable and may fall back to an alternative.
    """
    # Log the full command at DEBUG so that the analyst can reconstruct exactly what
    # was run.  Joining with spaces here is ONLY for human-readable logging; the actual
    # execution uses the list form (shell=False, default).
    logger.debug("Running command: %s (timeout=%ds, cwd=%s)", " ".join(cmd), timeout, cwd)

    try:
        result = subprocess.run(
            cmd,
            # shell=False is the default, but stated explicitly to make the intent
            # unambiguous to future readers and static analysis tools.
            shell=False,
            capture_output=True,
            timeout=timeout,
            cwd=cwd,
            # UTF-8 with 'replace' error handling: TSK tools occasionally emit binary
            # data (e.g. raw inode data) mixed with text.  'replace' ensures we always
            # get a str without raising, at the cost of replacing undecodable bytes with
            # the Unicode replacement character U+FFFD.
            encoding="utf-8",
            errors="replace",
        )
    except subprocess.TimeoutExpired:
        # Log the timeout before re-raising so the caller's except block knows which
        # command timed out without having to re-examine the exception args.
        logger.error("Command timed out after %ds: %s", timeout, " ".join(cmd))
        raise
    except FileNotFoundError:
        logger.error("Binary not found: %s", cmd[0])
        raise

    logger.debug(
        "Command finished: returncode=%d, stdout_bytes=%d, stderr_bytes=%d",
        result.returncode,
        len(result.stdout),
        len(result.stderr),
    )

    return result.returncode, result.stdout, result.stderr


def _validate_icat_call(inode: str, device: str, logger: "logging.Logger") -> bool:
    """Return False (and log warning) if the icat call should be rejected."""
    try:
        inode_int = int(str(inode).split("-")[0])
    except (ValueError, IndexError):
        logger.warning("Skipping icat: cannot parse inode %r", inode)
        return False
    if inode_int <= 0:
        logger.warning("Skipping icat: inode=%s is <= 0 (metadata inode)", inode)
        return False
    return True


def check_dependency(
    dep_type: str,
    name: str,
    module_name: str,
    logger: "logging.Logger",
) -> bool:
    """Return True if dependency is available. Log and return False if missing."""
    if dep_type == "binary":
        found = _shutil_dep.which(name) is not None
    elif dep_type == "python":
        try:
            _importlib_dep.import_module(name)
            found = True
        except ImportError:
            found = False
    else:
        raise ValueError(f"Unknown dep_type: {dep_type!r}")
    if not found:
        logger.warning("Dependency '%s' not found — module %s will SKIP", name, module_name)
    return found


# ---------------------------------------------------------------------------
# Shared recovered/carved corpus
# ---------------------------------------------------------------------------

# Working-set key holding the corpus roots resolved by the orchestrator from
# what the recovery/carving modules actually produced this run.
CORPUS_ROOTS_KEY = "corpus_roots"

# Working-set key holding the single mounted FILESYSTEM ROOT for the current
# exhibit — the walkable directory where the acquired partition is mounted.
# It is the primary evidence source every file-consuming module must scan, so it
# is resolved ahead of the recovered/carved corpus.  Resolved at runtime by the
# orchestrator (the mount point of the current exhibit); never a hardcoded path.
MOUNTED_FS_ROOT_KEY = "mounted_fs_root"

# Legacy working-set keys, kept as a fallback so a module still resolves a
# corpus when it runs outside the orchestrator (e.g. standalone invocation).
_LEGACY_CORPUS_KEYS = (
    "extracted_files_dir",
    "carved_files_dir",
    "tsk_recover_dir",
)


def resolve_corpus_roots(
    working_set: "Optional[dict[str, Any]]",
    *,
    output_dir: "Optional[Path]" = None,
    include_derived: bool = False,
) -> "list[Path]":
    """Return ordered evidence roots, excluding tool-generated derivatives by default.

    ``primary_evidence_roots`` contains active and recovered-deleted files
    materialised directly from the source evidence.  Module-created carving,
    export and report trees are stored separately under ``derived_corpus_roots``
    and are opt-in.  This prevents later scanners from treating their own output
    as independent case evidence.
    """
    roots: list[Path] = []
    seen: set[str] = set()

    def _add(value: "Any") -> None:
        if not value:
            return
        p = Path(str(value))
        try:
            if not p.is_dir():
                return
            key = str(p.resolve()).lower()
        except OSError:
            return
        if key not in seen:
            seen.add(key)
            roots.append(p)

    ws = working_set or {}
    primary = list(ws.get("primary_evidence_roots") or [])
    if primary:
        for value in primary:
            _add(value)
    else:
        _add(ws.get(MOUNTED_FS_ROOT_KEY))
        _add(ws.get("native_deleted_root"))
        # Backward-compatible standalone fallback: older callers only publish
        # corpus_roots.  They are accepted when no explicit primary set exists.
        for value in ws.get(CORPUS_ROOTS_KEY) or []:
            _add(value)
        for key in _LEGACY_CORPUS_KEYS:
            _add(ws.get(key))

    if include_derived:
        for value in ws.get("derived_corpus_roots") or []:
            _add(value)
        for value in ws.get(CORPUS_ROOTS_KEY) or []:
            _add(value)

    if output_dir is not None and not roots:
        # Standalone fallback only.  The normal orchestrated path always
        # publishes primary roots and therefore never scans sibling outputs.
        try:
            for sib in sorted(Path(output_dir).parent.iterdir()):
                if sib.is_dir() and sib != Path(output_dir):
                    _add(sib)
        except OSError:
            pass
    return roots


def iter_corpus_files(
    working_set: "Optional[dict[str, Any]]",
    *,
    output_dir: "Optional[Path]" = None,
    include_case_context: bool = False,
    include_derived: bool = False,
    deduplicate_by_hash: bool = False,
) -> "list[Path]":
    """Return provenance-filtered files from the current evidence corpus."""
    from core.source_provenance import SourceRole, iter_corpus_files as _iter
    roots = resolve_corpus_roots(working_set, output_dir=output_dir, include_derived=include_derived)
    allowed = {SourceRole.EVIDENTIARY_CONTENT}
    if include_case_context:
        allowed.add(SourceRole.CASE_CONTEXT)
    return list(_iter(
        roots, working_set, output_dir=output_dir, allowed_roles=allowed,
        deduplicate_by_hash=deduplicate_by_hash,
    ))

def count_corpus_files(roots: "list[Path]") -> int:
    """Count the regular files reachable under the given corpus roots."""
    total = 0
    for root in roots:
        try:
            for p in root.rglob("*"):
                if p.is_file():
                    total += 1
        except OSError:
            continue
    return total


# ---------------------------------------------------------------------------
# Hardened XML parsing
# ---------------------------------------------------------------------------

class UnsafeXMLError(ValueError):
    """Raised when untrusted XML carries a DTD/DOCTYPE (the XXE / entity vector)."""


def _reject_doctype(xml_data: "Any") -> None:
    """Raise UnsafeXMLError if the XML prolog declares a DOCTYPE.

    A DTD is the vector for both XXE (external entities) and billion-laughs
    (internal entity expansion).  A DOCTYPE is only legal in the prolog, before
    the root element, so we scan just the prolog tokens (XML declaration,
    comments, processing instructions, whitespace) and stop at the first
    element start — a "<!DOCTYPE" inside element text can never reach here.
    Legitimate OOXML/document parts carry no DOCTYPE, so this never false-rejects.
    """
    if isinstance(xml_data, (bytes, bytearray)):
        text = bytes(xml_data).decode("utf-8", errors="replace")
    else:
        text = str(xml_data)

    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if text.startswith("<?", i):                     # XML decl / PI
            end = text.find("?>", i)
            if end == -1:
                return
            i = end + 2
            continue
        if text.startswith("<!--", i):                   # comment
            end = text.find("-->", i)
            if end == -1:
                return
            i = end + 3
            continue
        if text[i:i + 9].upper() == "<!DOCTYPE":
            raise UnsafeXMLError("DTD/DOCTYPE is not permitted in untrusted XML")
        # First element start (or any other content) → prolog is over.
        return


def safe_xml_fromstring(xml_data: "Any"):
    """Parse untrusted XML with external entities and DTDs disabled.

    Document content parsed by the platform originates from evidence and is
    therefore untrusted: a crafted OOXML part could carry an XML External
    Entity (XXE) or a billion-laughs entity-expansion payload.  ``defusedxml``
    forbids both.  When it is unavailable we reject any DOCTYPE before parsing,
    so parsing is never performed with the default entity-resolving
    configuration on a document that could exploit it.

    Returns the parsed Element, or raises UnsafeXMLError / the underlying parser
    exception.
    """
    # ``defusedxml`` blocks entity expansion, but some versions permit a bare
    # DOCTYPE that declares no entity. Our invariant is stricter: untrusted
    # evidence XML may not contain any DTD at all, so reject it before either
    # parser is invoked.
    _reject_doctype(xml_data)
    try:
        from defusedxml.ElementTree import fromstring as _defused_fromstring
        return _defused_fromstring(xml_data)
    except ImportError:
        import xml.etree.ElementTree as _ET
        return _ET.fromstring(xml_data)


# ---------------------------------------------------------------------------
# Carving-volume fidelity
# ---------------------------------------------------------------------------

def source_image_size(evidence_path: "Any", config: "Optional[dict]" = None) -> int:
    """Best-effort logical size in bytes of the source image, discovered at runtime.

    Prefers the mounted analysis path from config, then the evidence path.
    Returns 0 when no size can be determined (never a hardcoded size).
    """
    config = config or {}
    for cand in (config.get("analysis_path"), str(evidence_path) if evidence_path else ""):
        if cand:
            try:
                p = Path(cand)
                if p.is_file():
                    return p.stat().st_size
            except OSError:
                pass
    return 0


def carving_volume_caveat(total_bytes: int, source_size: int) -> "Optional[str]":
    """Return a caveat when carved volume exceeds the source image size.

    A carved volume larger than the source image is physically impossible for
    genuinely recovered data: signature carvers emit overlapping candidate files
    from the same sectors, so the byte total double-counts.  Returns None when
    the volume is within bounds or the source size is unknown (0), so the caveat
    is driven entirely by the discovered sizes — never a hardcoded threshold.
    """
    if source_size and total_bytes > source_size:
        return (
            f"Carved volume ({total_bytes / 1024 / 1024:.1f} MB) EXCEEDS the "
            f"source image size ({source_size / 1024 / 1024:.1f} MB). This is an "
            "overlapping-candidate carving artefact (the carver emits overlapping "
            "candidate files from the same sectors); the figure is not a true "
            "recovered-data volume."
        )
    return None
