"""
keyword_search.py — Keyword Search Module for AutoForensics.

Searches all extracted content for configurable keyword lists.  Two search
strategies are applied:

  Text files   : ``grep`` with line-number and context output.
  Binary files : ``strings`` extracts printable sequences, then ``grep``
                 searches the strings output.

Keywords are loaded from config; if none are supplied, a built-in forensic
keyword list is used (credentials, crypto, commands, etc.).

Target platform : Kali Linux, Python 3.11+
External tools  : grep, strings (binutils)
"""

from __future__ import annotations

import hashlib
import json
import logging
import subprocess
import time
from pathlib import Path
from typing import Any

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots, iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

from core.deterministic_validation import deterministic_metadata

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "keyword_search"
GREP_TIMEOUT: int = 300    # 5 minutes per grep invocation
STRINGS_TIMEOUT: int = 120  # 2 minutes per strings invocation

# ---------------------------------------------------------------------------
# Default forensic keyword list
# ---------------------------------------------------------------------------

_DEFAULT_KEYWORDS: list[str] = [
    # Credentials
    "password", "passwd", "secret", "credential", "api_key", "apikey",
    "access_token", "auth_token", "private_key", "BEGIN RSA PRIVATE",
    "BEGIN OPENSSH PRIVATE", "BEGIN PGP PRIVATE", "ssh-rsa",
    # Cryptocurrency
    "bitcoin", "wallet", "mnemonic", "seed phrase", "private key",
    "0x", "monero", "ethereum",
    # Network / C2
    "cmd.exe", "powershell", "reverse shell", "netcat", "meterpreter",
    "beacon", "cobalt strike", "mimikatz", "procdump", "lsass",
    # Encoding
    "base64", "frombase64", "invoke-expression", "iex(",
    # Database / exfil
    "DROP TABLE", "SELECT * FROM", "INSERT INTO", "UNION SELECT",
    # Certificates
    "BEGIN CERTIFICATE", "BEGIN ENCRYPTED",
    # General sensitive
    "ssn", "social security", "credit card", "cvv", "pin number",
]

# Keyword categories for severity classification
_HIGH_KEYWORDS: frozenset[str] = frozenset({
    "BEGIN RSA PRIVATE", "BEGIN OPENSSH PRIVATE", "BEGIN PGP PRIVATE",
    "mimikatz", "meterpreter", "cobalt strike", "lsass", "procdump",
    "wallet", "mnemonic", "seed phrase",
})
_MEDIUM_KEYWORDS: frozenset[str] = frozenset({
    "password", "passwd", "secret", "credential", "api_key", "apikey",
    "access_token", "auth_token", "cmd.exe", "powershell", "reverse shell",
    "netcat", "beacon", "invoke-expression", "iex(",
    "DROP TABLE", "UNION SELECT",
})


def _load_keywords(config: dict[str, Any]) -> tuple[list[str], str]:
    """Load investigator/evidence-supplied keywords or neutral defaults.

    Case-specific validation phrases are never loaded from production paths.
    Controlled tests must provide an explicit keyword file through the same
    evidence/config interface used by ordinary investigations.
    """
    configured = config.get("keywords")
    if configured:
        return list(dict.fromkeys(str(x).strip() for x in configured if str(x).strip())), "configured"

    supplied_files: list[Path] = []
    keyword_file = str(config.get("keyword_list_path") or "").strip()
    if keyword_file:
        supplied_files.append(Path(keyword_file))
    for value in config.get("evidence_keyword_list_sources") or []:
        supplied_files.append(Path(str(value)))
    for value in (config.get("_working_set") or {}).get("evidence_keyword_list_sources") or []:
        supplied_files.append(Path(str(value)))
    supplied_terms: list[str] = []
    used_sources: list[str] = []
    seen_paths: set[str] = set()
    for path in supplied_files:
        try:
            key = str(path.resolve())
        except OSError:
            key = str(path)
        if key in seen_paths or not path.is_file():
            continue
        seen_paths.add(key)
        used_sources.append(str(path))
        supplied_terms.extend(
            line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    if supplied_terms:
        return list(dict.fromkeys(supplied_terms)), "evidence/investigator:" + ",".join(used_sources)

    return list(_DEFAULT_KEYWORDS), "built-in-defaults"


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _keyword_severity(keyword: str) -> Severity:
    kl = keyword.lower()
    for hk in _HIGH_KEYWORDS:
        if hk.lower() in kl or kl in hk.lower():
            return Severity.HIGH
    for mk in _MEDIUM_KEYWORDS:
        if mk.lower() in kl or kl in mk.lower():
            return Severity.MEDIUM
    return Severity.INFO


def _is_binary(file_path: Path) -> bool:
    """Return True if the file appears to be binary (non-UTF-8 readable)."""
    try:
        with open(file_path, "rb") as f:
            chunk = f.read(8192)
        chunk.decode("utf-8")
        return False
    except (UnicodeDecodeError, OSError):
        return True


def _grep_text_file(
    file_path: Path,
    keyword: str,
    case_sensitive: bool,
    context_lines: int,
    max_hits: int,
    logger: logging.Logger,
) -> list[dict[str, Any]]:
    """
    Run grep against a text file and return structured hit records.

    Parameters
    ----------
    file_path      : Path to the text file.
    keyword        : Keyword to search for.
    case_sensitive : If False, pass -i flag to grep.
    context_lines  : Lines of surrounding context to include.
    max_hits       : Maximum hits to return for this file.
    logger         : Module logger.

    Returns
    -------
    List of dicts with keys: line_number, line_text, context_before, context_after.
    """
    cmd = ["grep", "-n", f"-C{context_lines}"]
    if not case_sensitive:
        cmd.append("-i")
    cmd += [keyword, str(file_path)]

    hits: list[dict[str, Any]] = []
    try:
        rc, stdout, _ = _run_subprocess(cmd, timeout=GREP_TIMEOUT, logger=logger)
        if rc not in (0, 1):  # 0=found, 1=not found, >1=error
            return hits
        lines = stdout.splitlines()
        selected = lines if max_hits <= 0 else lines[:max_hits]
        for line in selected:
            parts = line.split(":", 2)
            if len(parts) >= 2 and parts[0].isdigit():
                hits.append({
                    "line_number": int(parts[0]),
                    "line_text": parts[2] if len(parts) > 2 else parts[1],
                })
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return hits


def _grep_binary_file(
    file_path: Path,
    keyword: str,
    case_sensitive: bool,
    max_hits: int,
    logger: logging.Logger,
) -> list[dict[str, Any]]:
    """
    Extract strings from a binary file then grep the strings output.

    Parameters
    ----------
    file_path      : Path to the binary file.
    keyword        : Keyword to search for.
    case_sensitive : Case sensitivity flag.
    max_hits       : Maximum hits to return.
    logger         : Module logger.

    Returns
    -------
    List of dicts with keys: offset, string_value.
    """
    hits: list[dict[str, Any]] = []
    try:
        rc, strings_out, _ = _run_subprocess(
            ["strings", "-a", "-n", "6", "-t", "d", str(file_path)],
            timeout=STRINGS_TIMEOUT,
            logger=logger,
        )
        if rc != 0 or not strings_out:
            return hits
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return hits

    search = keyword if case_sensitive else keyword.lower()
    for line in strings_out.splitlines():
        parts = line.split(None, 1)
        if len(parts) < 2:
            continue
        offset_str, string_val = parts[0], parts[1]
        compare_val = string_val if case_sensitive else string_val.lower()
        if search in compare_val:
            hits.append({"offset": offset_str, "string_value": string_val})
            if max_hits > 0 and len(hits) >= max_hits:
                # Keep scanning logic deterministic; the caller records that a
                # configured positive cap can prevent exhaustive hit retention.
                break
    return hits


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Search all extracted files for forensic keywords.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing files extracted by previous modules.
    config        : Configuration dict; recognised keys:
                    - ``keywords`` (list[str]): keywords to search.
                    - ``case_sensitive`` (bool): default False.
                    - ``context_lines`` (int): grep context lines, default 2.
                    - ``max_hits_per_file`` (int): optional cap per file; 0 (default) is exhaustive.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with one Finding per keyword-file combination that has hits.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run.
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    search_root = str(_corpus_roots[0]) if _corpus_roots else None
    if not _corpus_roots:
        _cr_skip = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Keyword Search Hits",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — no extracted corpus for keyword search",
            findings=[], errors=[], statistics={},
            class_results=[_cr_skip],
        )
    keyword_file = config.get("keyword_list_path", "")
    if keyword_file and not Path(keyword_file).is_file():
        _cr_skip2 = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Keyword Search Hits",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — keyword list not found at configured path",
            findings=[], errors=[], statistics={},
            class_results=[_cr_skip2],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    keywords, keyword_source = _load_keywords(config)
    case_sensitive: bool = config.get("case_sensitive", False)
    context_lines: int = int(config.get("context_lines", 2))
    max_hits_per_file: int = int(config.get("max_hits_per_file", 0) or 0)

    logger.info("[%s] Searching for %d keywords (case_sensitive=%s)",
                MODULE_NAME, len(keywords), case_sensitive)

    # Search only original evidentiary content. Analysis configuration,
    # validation/reference documents and module-generated files are excluded
    # so a keyword list or answer matrix cannot corroborate itself.
    try:
        all_files = iter_corpus_files(
            ws, output_dir=output_dir, include_case_context=False,
            include_derived=False, deduplicate_by_hash=True,
        )
    except PermissionError as exc:
        errors.append(f"Permission error scanning evidentiary corpus: {exc}")
        all_files = []

    files_searched = 0
    binary_files_searched = 0
    total_hits = 0
    hits_by_keyword: dict[str, int] = {kw: 0 for kw in keywords}
    all_hit_records: list[dict[str, Any]] = []
    configured_hit_cap_reached = False

    for file_path in all_files:
        binary = _is_binary(file_path)
        if binary:
            binary_files_searched += 1
        files_searched += 1

        for keyword in keywords:
            if binary:
                hits = _grep_binary_file(
                    file_path, keyword, case_sensitive, max_hits_per_file, logger)
            else:
                hits = _grep_text_file(
                    file_path, keyword, case_sensitive, context_lines, max_hits_per_file, logger)

            if not hits:
                continue

            if max_hits_per_file > 0 and len(hits) >= max_hits_per_file:
                configured_hit_cap_reached = True

            hits_by_keyword[keyword] = hits_by_keyword.get(keyword, 0) + len(hits)
            total_hits += len(hits)

            severity = _keyword_severity(keyword)
            finding = make_finding(
                finding_type="KEYWORD_HIT",
                severity=severity,
                description=(
                    f"Keyword '{keyword}' found {len(hits)} time(s) in "
                    f"{'binary' if binary else 'text'} file: {file_path.name}"
                ),
                evidence_path=str(evidence_path),
                metadata={
                    **deterministic_metadata(
                        "exact literal term occurrence in retained decoded text or printable byte sequence",
                        validators=["grep literal search", "strings byte-offset search"],
                    ),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "keyword": keyword,
                    "hit_count": len(hits),
                    "is_binary": binary,
                    "sample_hits": hits[:5],
                    "keyword_source": keyword_source,
                    "semantic_scope": "term occurrence only; no intent or attribution inferred",
                },
            )
            findings.append(finding)
            all_hit_records.append({
                "file_path": str(file_path),
                "keyword": keyword,
                "is_binary": binary,
                "hits": hits,
            })

    # Write results
    results_path = output_dir / "keyword_hits.json"
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        with open(results_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME,
                "case_id": case_id,
                "generated_at": utc_now(),
                "keywords_searched": keywords,
                "keyword_source": keyword_source,
                "files_searched": files_searched,
                "total_hits": total_hits,
                "hits": all_hit_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(results_path))
    except OSError as exc:
        errors.append(f"Failed to write keyword_hits.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    if configured_hit_cap_reached:
        errors.append(
            f"Configured max_hits_per_file={max_hits_per_file} may have truncated one or more keyword hit sets; exhaustive hit retention was not proven."
        )
    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    if files_searched == 0:
        status = ModuleStatus.SKIPPED

    summary = (
        f"Searched {files_searched} files ({binary_files_searched} binary) "
        f"for {len(keywords)} keywords; {total_hits} total hits."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "total_hits": total_hits})

    if status == ModuleStatus.SKIPPED:
        _cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Keyword Search Hits",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
    else:
        _cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Keyword Search Hits",
            verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
            count=len(findings),
        )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics={
            "files_searched": files_searched,
            "sources_discovered": files_searched,
            "sources_processed": files_searched,
            "supported_objects_discovered": files_searched,
            "supported_objects_processed": files_searched,
            "binary_files_searched": binary_files_searched,
            "total_hits": total_hits,
            "hits_by_keyword": hits_by_keyword,
            "duplicate_primary_records": 0,
            "unresolved_supported_objects": 0 if not errors else max(1, len(errors)),
            "hit_limit_configured": max_hits_per_file,
            "hit_limit_reached": configured_hit_cap_reached,
        },
        summary=summary,
        class_results=[_cr],
    )
