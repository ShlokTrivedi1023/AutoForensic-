"""
artifact_extractor.py - OS-Level Forensic Artifact Extractor for AutoForensics.

Extracts operating-system-level forensic artifacts from a disk image. For Windows
images: Windows Registry hives (SYSTEM, SAM, SOFTWARE, NTUSER.DAT), Event Log files
(.evtx), Prefetch files, LNK (shortcut) files, Jump Lists, Recycle Bin entries, and
Shellbag registry keys. For Linux images: bash/zsh history files, /var/log auth.log,
cron jobs, SSH known_hosts, and /etc/passwd & /etc/shadow.

Uses The Sleuth Kit fls/icat to extract files by path without mounting. All extractions
are performed non-destructively against a read-only evidence image.

Target platform : Kali Linux, Python 3.11
External tools  : fls, icat (The Sleuth Kit)
Optional libs   : python-registry (Registry), python-evtx (Evtx)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import struct
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Internal imports
# ---------------------------------------------------------------------------
from core.deterministic_validation import deterministic_metadata
from core.evidence_inventory import classify_file
from core.structured_records import extract_structured_records, record_locator_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Finding,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

# ---------------------------------------------------------------------------
# Optional dependency: chain-of-custody event logger
# Importing with try/except so the module is fully functional without it.
# ---------------------------------------------------------------------------
try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Optional dependency: python-registry
# If available, allows parsing Windows Registry hives directly in Python.
# ---------------------------------------------------------------------------
try:
    from Registry.Registry import Registry as _WinRegistry  # type: ignore[import]
    _REGISTRY_AVAILABLE = True
except ImportError:
    try:
        from Registry import Registry as _WinRegistry  # type: ignore[import]
        # Verify it's actually a class, not the module itself
        if not callable(_WinRegistry):
            raise ImportError("Registry is a module, not a class — wrong import path")
        _REGISTRY_AVAILABLE = True
    except (ImportError, TypeError):
        _WinRegistry = None
        _REGISTRY_AVAILABLE = False

# ---------------------------------------------------------------------------
# Optional dependency: python-evtx
# If available, allows parsing Windows Event Log (.evtx) files in Python.
# ---------------------------------------------------------------------------
try:
    import Evtx.Evtx as _evtx_lib  # type: ignore[import]
    _EVTX_AVAILABLE = True
except ImportError:
    _evtx_lib = None
    _EVTX_AVAILABLE = False

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME = "artifact_extractor"

# Subprocess timeouts (seconds)
FLS_TIMEOUT = 3600        # fls on a large image can take ~1 hour
ICAT_TIMEOUT = 300        # single icat extraction: 5 minutes max per file

# Maximum single-file extraction size: 500 MB.  Larger files (e.g., multi-GB
# Event Log) are extracted but not parsed in-memory - just noted in the manifest.
MAX_PARSE_BYTES = 0  # 0 = exhaustive; positive values are explicit safety caps

# ---------------------------------------------------------------------------
# Windows artifact path patterns (matched against fls full-path output)
# ---------------------------------------------------------------------------
# Each tuple is (category_name, regex_pattern).
# The patterns match the forward-slash-normalised paths that fls -r -p emits.
_WINDOWS_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("registry_hive", re.compile(r"Windows/System32/config/SAM$", re.IGNORECASE)),
    ("registry_hive", re.compile(r"Windows/System32/config/SYSTEM$", re.IGNORECASE)),
    ("registry_hive", re.compile(r"Windows/System32/config/SOFTWARE$", re.IGNORECASE)),
    ("registry_hive", re.compile(r"Windows/System32/config/SECURITY$", re.IGNORECASE)),
    ("registry_hive", re.compile(r"Users/[^/]+/NTUSER\.DAT$", re.IGNORECASE)),
    ("registry_export", re.compile(r"(?:^|/)NTUSER\.reg$|Users/[^/]+/[^/]+\.reg$", re.IGNORECASE)),
    ("registry_hive", re.compile(r"Users/[^/]+/AppData/Local/Microsoft/Windows/UsrClass\.dat$", re.IGNORECASE)),
    ("event_log",     re.compile(r"Windows/System32/winevt/Logs/[^/]+\.evtx$", re.IGNORECASE)),
    ("prefetch",      re.compile(r"Windows/Prefetch/[^/]+\.pf$", re.IGNORECASE)),
    ("lnk_file",      re.compile(r"Users/[^/]+/AppData/Roaming/Microsoft/Windows/Recent/[^/]+\.lnk$", re.IGNORECASE)),
    ("lnk_file",      re.compile(r"Users/[^/]+/Recent/[^/]+\.lnk$", re.IGNORECASE)),
    ("jump_list",     re.compile(r"Users/[^/]+/AppData/Roaming/Microsoft/Windows/Recent/AutomaticDestinations/[^/]+$", re.IGNORECASE)),
    ("jump_list",     re.compile(r"Users/[^/]+/AppData/Roaming/Microsoft/Windows/Recent/CustomDestinations/[^/]+$", re.IGNORECASE)),
    ("recycle_bin",   re.compile(r"\$Recycle\.Bin/[^/]*/\$I[^/]*$", re.IGNORECASE)),
    ("recycle_bin",   re.compile(r"\$Recycle\.Bin/[^/]*/\$R[^/]*$", re.IGNORECASE)),
    ("recycle_bin",   re.compile(r"RECYCLER/[^/]*/INFO2$", re.IGNORECASE)),
    ("shellbag",      re.compile(r"Users/[^/]+/NTUSER\.DAT$", re.IGNORECASE)),  # shellbags live in NTUSER.DAT
]

# ---------------------------------------------------------------------------
# Linux artifact path patterns
# ---------------------------------------------------------------------------
_LINUX_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("bash_history",  re.compile(r"(^|/)\.bash_history$", re.IGNORECASE)),
    ("zsh_history",   re.compile(r"(^|/)\.zsh_history$", re.IGNORECASE)),
    ("auth_log",      re.compile(r"var/log/auth\.log(\.[\d.gz]+)?$", re.IGNORECASE)),
    ("syslog",        re.compile(r"var/log/syslog(\.[\d.gz]+)?$", re.IGNORECASE)),
    ("cron",          re.compile(r"etc/cron\.(d|daily|hourly|monthly|weekly)/[^/]+$", re.IGNORECASE)),
    ("cron",          re.compile(r"etc/crontab$", re.IGNORECASE)),
    ("cron",          re.compile(r"var/spool/cron/crontabs/[^/]+$", re.IGNORECASE)),
    ("passwd",        re.compile(r"etc/passwd$", re.IGNORECASE)),
    ("shadow",        re.compile(r"etc/shadow$", re.IGNORECASE)),
    ("ssh_known",     re.compile(r"(^|/)\.ssh/known_hosts$", re.IGNORECASE)),
    ("ssh_known",     re.compile(r"etc/ssh/ssh_known_hosts$", re.IGNORECASE)),
    ("ssh_key",       re.compile(r"(^|/)\.ssh/(id_rsa|id_ecdsa|id_ed25519|id_dsa)$", re.IGNORECASE)),
    ("hosts",         re.compile(r"etc/hosts$", re.IGNORECASE)),
    ("sudoers",       re.compile(r"etc/sudoers$", re.IGNORECASE)),
]


# ---------------------------------------------------------------------------
# run() - module entry point
# ---------------------------------------------------------------------------

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Extract OS-level forensic artifacts from a disk image.

    Parameters
    ----------
    evidence_path : Absolute path to the disk image (.dd, .raw, .E01, .img).
    case_id       : Unique case identifier, used in log messages and output naming.
    output_dir    : Directory where all extracted artifacts and reports are written.
    config        : Configuration dict; recognised keys:
                    - 'image_type' : 'ewf' | 'raw' (default auto-detected from extension)
    logger        : Standard Python logger pre-configured by the orchestrator.
    coc_logger    : Optional CustodyLogger instance; MODULE_STARTED / MODULE_COMPLETED
                    / MODULE_FAILED events are written if provided.

    Returns
    -------
    ModuleResult
        Always returned, even on total failure.
    """
    start_time = utc_now()
    wall_start = time.monotonic()

    # -----------------------------------------------------------------------
    # CoC: module started
    # -----------------------------------------------------------------------
    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_STARTED,
                description=f"Module '{MODULE_NAME}' started for case {case_id}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "case_id": case_id},
            )
        except Exception as _coc_err:
            logger.warning("CoC log failed at start: %s", _coc_err)

    # Resolve paths once - never use unresolved paths after this point.
    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()

    findings: list[Finding] = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    # -----------------------------------------------------------------------
    # Validate evidence file existence
    # -----------------------------------------------------------------------
    if not evidence_path.exists():
        err = f"Evidence file not found: {evidence_path}"
        logger.error(err)
        return _fail(MODULE_NAME, case_id, start_time, err, coc_logger, logger)

    # analysis_path: mounted ewf1 (raw) or block device; falls back to evidence_path
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    image_type = config.get(
        "image_type",
        Path(str(evidence_path)).suffix.lower().lstrip(".") or "raw",
    )
    logger.info("Artifact extractor analysis_path=%s offset=%d", analysis_path, partition_offset)

    # -----------------------------------------------------------------------
    # Create output directory structure
    # -----------------------------------------------------------------------
    artifacts_root = output_dir / "artifacts"
    try:
        artifacts_root.mkdir(parents=True, exist_ok=True)
        for category in ("registry_hive", "event_log", "prefetch", "lnk_file",
                         "jump_list", "recycle_bin", "bash_history", "zsh_history",
                         "auth_log", "syslog", "cron", "passwd", "shadow", "registry_export",
                         "ssh_known", "ssh_key", "hosts", "sudoers", "shellbag", "other"):
            (artifacts_root / category).mkdir(exist_ok=True)
    except OSError as exc:
        err = f"Cannot create artifact output directories: {exc}"
        logger.error(err)
        return _fail(MODULE_NAME, case_id, start_time, err, coc_logger, logger)

    # -----------------------------------------------------------------------
    # Step 1: Run fls to enumerate all file paths in the image
    # -----------------------------------------------------------------------
    logger.info("Running fls to enumerate image file system...")
    fls_entries = _run_fls(analysis_path, logger, errors, offset=partition_offset)
    native_mode = False
    if not fls_entries:
        ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
        native_root_value = ws.get("extracted_files_dir") or ws.get("mounted_fs_root")
        native_root = Path(native_root_value) if native_root_value else None
        if native_root and native_root.is_dir():
            native_mode = True
            fls_entries = []
            for native_file in native_root.rglob("*"):
                if not native_file.is_file():
                    continue
                try:
                    rel = str(native_file.relative_to(native_root)).replace("\\", "/")
                except ValueError:
                    rel = native_file.name
                fls_entries.append({
                    "path": rel,
                    "inode": "",
                    "native_source": str(native_file),
                })
            # Replace the external-tool error with an explicit caveat; the native
            # corpus was still completely enumerated for the supported filesystem.
            errors[:] = [e for e in errors if "fls" not in e.lower() and "not found" not in e.lower()]
            logger.info("Native filesystem fallback enumerated %d file(s); Sleuth Kit was not required", len(fls_entries))
        else:
            err = "No filesystem entry source was available: fls produced no entries and no native extracted tree was published."
            logger.error(err)
            errors.append(err)
            _dep_missing = any("not found" in e.lower() for e in errors)
            _sr = SkipReason.DEPENDENCY_MISSING if _dep_missing else SkipReason.PARTIAL_FAILURE
            return _fail(MODULE_NAME, case_id, start_time, err, coc_logger, logger,
                         skip_reason=_sr)

    logger.info("Filesystem enumeration produced %d entries", len(fls_entries))

    # -----------------------------------------------------------------------
    # Step 2: Match entries against artifact patterns
    # -----------------------------------------------------------------------
    windows_matches: list[dict[str, Any]] = []
    linux_matches:   list[dict[str, Any]] = []

    for entry in fls_entries:
        path_str = entry["path"]
        inode    = entry["inode"]
        # Normalise backslashes to forward slashes for pattern matching
        normalised = path_str.replace("\\", "/")

        # Check Windows patterns
        for category, pattern in _WINDOWS_PATTERNS:
            if pattern.search(normalised):
                windows_matches.append({
                    "category": category,
                    "path": path_str,
                    "normalised_path": normalised,
                    "inode": inode,
                    "filename": Path(path_str).name,
                    "native_source": entry.get("native_source"),
                })
                break  # One category per file

        # Check Linux patterns
        for category, pattern in _LINUX_PATTERNS:
            if pattern.search(normalised):
                linux_matches.append({
                    "category": category,
                    "path": path_str,
                    "normalised_path": normalised,
                    "inode": inode,
                    "filename": Path(path_str).name,
                    "native_source": entry.get("native_source"),
                })
                break

    logger.info(
        "Pattern matches: %d Windows artifact(s), %d Linux artifact(s)",
        len(windows_matches), len(linux_matches),
    )

    # -----------------------------------------------------------------------
    # Step 3: Extract matched artifacts using icat
    # -----------------------------------------------------------------------
    manifest: list[dict[str, Any]] = []
    stats = {
        "windows_artifacts_found":   len(windows_matches),
        "linux_artifacts_found":     len(linux_matches),
        "registry_hives_extracted":  0,
        "event_logs_extracted":      0,
        "prefetch_files_extracted":  0,
        "total_extracted":           0,
        "total_failed":              0,
        "enumeration_method":        "native_filesystem_tree" if native_mode else "sleuthkit_fls",
    }

    all_matches = windows_matches + linux_matches
    for match in all_matches:
        if match.get("native_source"):
            source_file = Path(match["native_source"])
            dest_dir = artifacts_root / match["category"]
            dest_dir.mkdir(parents=True, exist_ok=True)
            extracted_path = dest_dir / match["filename"]
            if extracted_path.exists():
                extracted_path = dest_dir / f"{source_file.stem}_{hashlib.sha256(str(source_file).encode()).hexdigest()[:8]}{source_file.suffix}"
            try:
                shutil.copy2(source_file, extracted_path)
                extract_err = None
            except OSError as exc:
                extracted_path = None
                extract_err = str(exc)
        else:
            extracted_path, extract_err = _extract_with_icat(
                analysis_path=analysis_path,
                inode=match["inode"],
                output_dir=artifacts_root / match["category"],
                filename=match["filename"],
                logger=logger,
                offset=partition_offset,
            )

        manifest_entry: dict[str, Any] = {
            "category":     match["category"],
            "source_path":  match["path"],
            "inode":        match["inode"],
            "filename":     match["filename"],
            "extracted_to": str(extracted_path) if extracted_path else None,
            "status":       "OK" if extracted_path else "FAILED",
            "error":        extract_err,
        }

        if extracted_path:
            artifact_paths.append(str(extracted_path))
            stats["total_extracted"] += 1

            # Count by sub-category
            if match["category"] == "registry_hive":
                stats["registry_hives_extracted"] += 1
            elif match["category"] == "event_log":
                stats["event_logs_extracted"] += 1
            elif match["category"] == "prefetch":
                stats["prefetch_files_extracted"] += 1

            # ---------------------------------------------------------------
            # Step 4: Parse extracted artifacts where possible
            # ---------------------------------------------------------------
            parsed = _parse_artifact(
                category=match["category"],
                extracted_path=extracted_path,
                source_path=match["path"],
                logger=logger,
            )
            manifest_entry["parsed"] = parsed

            # ---------------------------------------------------------------
            # Step 5: Create Findings from parsed content
            # ---------------------------------------------------------------
            new_findings = _create_findings(
                category=match["category"],
                match=match,
                extracted_path=extracted_path,
                parsed=parsed,
                logger=logger,
            )
            findings.extend(new_findings)

        else:
            stats["total_failed"] += 1
            errors.append(f"Failed to extract {match['path']}: {extract_err}")

        manifest.append(manifest_entry)

    # Content-driven exact artefact facts.  Path-pattern extraction above is an
    # acquisition aid; these findings are promoted only after signature/schema
    # or line-record validation and therefore work for relocated artefacts too.
    exact_findings: list[Finding] = []
    seen_exact: set[tuple[str, str, str]] = set()
    for entry in manifest:
        retained = entry.get("extracted_to")
        if not retained or not Path(str(retained)).is_file():
            continue
        retained_path = Path(str(retained))
        logical_path = str(entry.get("source_path") or retained_path.name)
        try:
            obj = classify_file(retained_path)
        except Exception:
            obj = None
        records = extract_structured_records(retained_path)
        if records:
            for record in records:
                if record.source_kind == "hosts":
                    ip = record.fields.get("ip", "")
                    hostnames = record.fields.get("hostnames", "")
                    key = ("HOSTS_FILE_ENTRY", ip, hostnames)
                    if key in seen_exact:
                        continue
                    seen_exact.add(key)
                    exact_findings.append(make_finding(
                        "HOSTS_FILE_ENTRY", Severity.INFO,
                        f"A hosts-file record maps {ip} to {hostnames}.", logical_path,
                        {
                            **deterministic_metadata(
                                "hosts line grammar and exact field tokenisation",
                                validators=["structured hosts parser", "IP parser", "hostname token parser"],
                                semantic_limit="Static mapping stored in the file; actual DNS use or ownership is not inferred.",
                            ),
                            **record_locator_metadata(record),
                            "ip": ip, "hostnames": hostnames.split(), "logical_path": logical_path,
                        }, artifact_path=str(retained_path),
                    ))
                elif record.source_kind == "registry_export":
                    key_path = record.fields.get("registry_key", "")
                    name = record.fields.get("value_name", "")
                    data = record.fields.get("value_data", "")
                    key = ("REGISTRY_EXPORT_VALUE", key_path.casefold(), name.casefold())
                    if key in seen_exact:
                        continue
                    seen_exact.add(key)
                    exact_findings.append(make_finding(
                        "REGISTRY_EXPORT_VALUE", Severity.INFO,
                        f"A registry-export record contains value '{name}' under '{key_path}'.", logical_path,
                        {
                            **deterministic_metadata(
                                "Windows Registry export line parser",
                                validators=["registry key-section grammar", "quoted value parser"],
                                semantic_limit="Exported text value only; no claim that a live hive loaded or executed the value.",
                            ),
                            **record_locator_metadata(record),
                            "registry_key": key_path, "value_name": name, "value_data": data,
                            "logical_path": logical_path,
                        }, artifact_path=str(retained_path),
                    ))
        if obj is None:
            continue
        printable = []
        try:
            raw = retained_path.read_bytes()
            printable = re.findall(rb"[ -~]{4,}", raw)
            printable = [value.decode("ascii", errors="replace") for value in printable]
        except OSError:
            raw = b""
        if obj.object_type == "windows_event_log" and obj.subtype == "marker_only":
            exact_findings.append(make_finding(
                "EVTX_LIKE_MARKER", Severity.INFO,
                "An ElfFile-prefixed but structurally incomplete Windows Event Log marker was retained.", logical_path,
                {
                    **deterministic_metadata(
                        "EVTX signature and minimum-structure validation",
                        validators=["ElfFile signature", "minimum EVTX header/size invariants"],
                        semantic_limit="Marker/container presence only; no complete native event record is claimed.",
                    ),
                    "file_path": str(retained_path), "file_sha256": obj.sha256,
                    "file_size": obj.size_bytes, "structure": obj.metadata,
                    "embedded_printable_strings": printable, "logical_path": logical_path,
                }, artifact_path=str(retained_path),
            ))
        elif obj.object_type == "windows_shell_link" and obj.subtype == "marker_only":
            target_candidates = [v for v in printable if re.search(r"(?i)(?:[A-Z]:\\|/)[^\r\n]{2,}", v)]
            exact_findings.append(make_finding(
                "SHELL_LINK_LIKE_MARKER", Severity.INFO,
                "A short Shell-Link-like marker was retained; it is not a structurally valid Windows .LNK record.", logical_path,
                {
                    **deterministic_metadata(
                        "Shell Link header/CLSID/size validation",
                        validators=["0x4C header size", "Shell Link CLSID", "minimum record size"],
                        semantic_limit="Marker and literal path presence only; shortcut use or execution is not established.",
                    ),
                    "file_path": str(retained_path), "file_sha256": obj.sha256,
                    "file_size": obj.size_bytes, "structure": obj.metadata,
                    "target_path_literals": target_candidates, "logical_path": logical_path,
                }, artifact_path=str(retained_path),
            ))
        elif obj.object_type == "windows_prefetch" and obj.subtype == "marker_only":
            path_literals = [v for v in printable if re.search(r"(?i)[A-Z]:\\", v)]
            exact_findings.append(make_finding(
                "PREFETCH_LIKE_MARKER", Severity.INFO,
                "An SCCA-prefixed but structurally incomplete Prefetch-like marker was retained.", logical_path,
                {
                    **deterministic_metadata(
                        "Prefetch signature/version/declared-size invariants",
                        validators=["SCCA signature", "known version", "declared size"],
                        semantic_limit="Marker/path literal only; program execution is not established.",
                    ),
                    "file_path": str(retained_path), "file_sha256": obj.sha256,
                    "file_size": obj.size_bytes, "structure": obj.metadata,
                    "path_literals": path_literals, "logical_path": logical_path,
                }, artifact_path=str(retained_path),
            ))
    findings.extend(exact_findings)
    stats["exact_structured_findings"] = len(exact_findings)

    # Canonicalise byte-identical extracted representations inside this module.
    # Different paths remain retained as aliases, but only the first exact
    # finding/type/hash tuple contributes to the unique-evidence count.
    seen_primary: set[tuple[str, str]] = set()
    duplicate_primary_records = 0
    for finding in findings:
        artifact = Path(str(finding.artifact_path or ""))
        try:
            digest = hashlib.sha256(artifact.read_bytes()).hexdigest() if artifact.is_file() else ""
        except OSError:
            digest = ""
        if not digest:
            continue
        identity = (str(finding.finding_type), digest)
        finding.metadata.setdefault("file_sha256", digest)
        finding.metadata["duplicate_identity"] = f"{finding.finding_type}:{digest}"
        if identity in seen_primary:
            duplicate_primary_records += 1
            finding.metadata["counts_toward_unique_evidence"] = False
            finding.metadata["fact_class"] = "DUPLICATE_REPRESENTATION"
        else:
            seen_primary.add(identity)
            finding.metadata.setdefault("counts_toward_unique_evidence", True)
    stats.update({
        "sources_discovered": len(all_matches),
        "sources_processed": stats["total_extracted"] + stats["total_failed"],
        "supported_objects_discovered": len(all_matches),
        "supported_objects_processed": stats["total_extracted"] + stats["total_failed"],
        "unresolved_supported_objects": stats["total_failed"],
        "duplicate_primary_records": duplicate_primary_records,
    })

    # -----------------------------------------------------------------------
    # Step 6: Write artifacts_manifest.json
    # -----------------------------------------------------------------------
    manifest_path = output_dir / "artifacts_manifest.json"
    try:
        with open(manifest_path, "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "case_id":       case_id,
                    "evidence_path": str(evidence_path),
                    "image_type":    image_type,
                    "generated_at":  utc_now(),
                    "statistics":    stats,
                    "artifacts":     manifest,
                },
                fh,
                indent=2,
                default=str,
            )
        artifact_paths.append(str(manifest_path))
        logger.info("Manifest written to %s", manifest_path)
    except OSError as exc:
        err = f"Cannot write artifact manifest: {exc}"
        logger.error(err)
        errors.append(err)

    # -----------------------------------------------------------------------
    # Finalise result
    # -----------------------------------------------------------------------
    wall_elapsed = time.monotonic() - wall_start
    end_time = utc_now()

    status = ModuleStatus.COMPLETED if not errors else (
        ModuleStatus.PARTIAL if native_mode or stats["total_extracted"] > 0 else ModuleStatus.FAILED
    )
    summary = (
        f"Scanned filesystem entries using {stats['enumeration_method']}; "
        f"extracted {stats['total_extracted']} artifact(s) "
        f"({stats['registry_hives_extracted']} registry hives, "
        f"{stats['event_logs_extracted']} event logs, "
        f"{stats['prefetch_files_extracted']} prefetch); "
        f"{len(findings)} finding(s) generated."
    )

    logger.info(summary)

    # CoC: module completed or failed
    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_event = EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED else EventType.MODULE_FAILED
            coc_logger.log(
                coc_event,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={
                    "module":       MODULE_NAME,
                    "status":       status.value,
                    "findings":     len(findings),
                    "extracted":    stats["total_extracted"],
                    "duration_sec": round(wall_elapsed, 2),
                },
            )
        except Exception as _coc_err:
            logger.warning("CoC log failed at end: %s", _coc_err)

    _cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Extracted File Artefacts",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=round(wall_elapsed, 2),
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics=stats,
        summary=summary,
        class_results=[_cr],
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _fail(
    module_name: str,
    case_id: str,
    start_time: str,
    reason: str,
    coc_logger: Any,
    logger: logging.Logger,
    skip_reason: SkipReason = SkipReason.NO_EVIDENCE,
) -> ModuleResult:
    """
    Build and return a FAILED ModuleResult.

    Called whenever the module cannot proceed at all.  The coc_logger is
    notified with MODULE_FAILED if it is available.
    """
    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_FAILED,
                description=f"Module '{module_name}' failed: {reason}",
                metadata={"module": module_name, "reason": reason},
            )
        except Exception as _err:
            logger.warning("CoC log failed in _fail(): %s", _err)

    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Extracted File Artefacts",
        verdict=AssuranceVerdict.INDETERMINATE,
        skip_reason=skip_reason,
        notes=reason[:200],
    )
    return ModuleResult(
        module_name=module_name,
        case_id=case_id,
        status=ModuleStatus.FAILED,
        start_time=start_time,
        end_time=utc_now(),
        duration_seconds=0.0,
        findings=[],
        artifact_paths=[],
        errors=[reason],
        statistics={},
        summary=f"Module failed: {reason}",
        class_results=[cr],
    )


def _run_fls(
    analysis_path: Path,
    logger: logging.Logger,
    errors: list[str],
    offset: int = 0,
) -> list[dict[str, Any]]:
    """
    Run `fls -r -p <analysis_path>` and parse the output into a list of inode/path dicts.

    analysis_path is always a raw block-level file (ewf1 from ewfmount, block device,
    or a .dd image) - never an .E01 directly, so no -i ewf flag is needed.
    """
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]

    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=FLS_TIMEOUT, logger=logger)
    except FileNotFoundError:
        errors.append("fls not found - install The Sleuth Kit (apt install sleuthkit)")
        return []
    except Exception as exc:
        errors.append(f"fls execution error: {exc}")
        return []

    if rc != 0 and not stdout:
        errors.append(f"fls exited with code {rc}: {stderr[:500]}")
        return []

    entries: list[dict[str, Any]] = []
    # fls output lines look like:
    #   r/r 1234:	Windows/System32/config/SAM
    #   r/r * 5678:	$Recycle.Bin/S-1-5-21.../some_deleted_file
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        # Match the inode number and path - handle both regular and deleted (*)
        m = re.match(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", line)
        if m:
            inode = m.group(1).split("-")[0]  # Use base inode, discard data unit
            path  = m.group(2).strip()
            # Skip directory entries (they end with /)
            if not path.endswith("/"):
                entries.append({"inode": inode, "path": path})

    logger.debug("fls parsed %d file entries", len(entries))
    return entries


def _extract_with_icat(
    analysis_path: Path,
    inode: str,
    output_dir: Path,
    filename: str,
    logger: logging.Logger,
    offset: int = 0,
) -> tuple[Path | None, str | None]:
    """
    Extract one file from the image using `icat <analysis_path> <inode>`.

    analysis_path is always a raw file (ewf1 or block device) - no -i ewf flag.

    Returns
    -------
    (extracted_path, None) on success.
    (None, error_message) on failure.
    """
    # Sanitise the filename to prevent path traversal attacks.
    # Evidence filenames can contain anything - never trust them directly.
    safe_filename = re.sub(r"[^A-Za-z0-9_.\-]", "_", filename)
    if not safe_filename:
        safe_filename = f"artifact_{inode}"

    dest_path = (output_dir / safe_filename).resolve()

    # Collision avoidance: if the path exists, append inode to filename stem
    if dest_path.exists():
        stem   = dest_path.stem
        suffix = dest_path.suffix
        dest_path = (output_dir / f"{stem}_inode{inode}{suffix}").resolve()

    # Build icat command - no -i ewf since analysis_path is always raw
    import subprocess as _subprocess
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]

    try:
        result = _subprocess.run(
            cmd,
            capture_output=True,
            timeout=ICAT_TIMEOUT,
            shell=False,
        )
    except FileNotFoundError:
        return None, "icat not found - install The Sleuth Kit"
    except _subprocess.TimeoutExpired:
        return None, f"icat timed out after {ICAT_TIMEOUT}s for inode {inode}"
    except Exception as exc:
        return None, f"icat error: {exc}"

    if result.returncode != 0:
        stderr_s = result.stderr.decode("utf-8", errors="replace")
        return None, f"icat exit code {result.returncode}: {stderr_s[:300]}"

    if not result.stdout:
        logger.debug("icat produced empty output for inode %s (%s)", inode, filename)

    try:
        dest_path.write_bytes(result.stdout)
        logger.debug("Extracted inode %s → %s (%d bytes)", inode, dest_path, dest_path.stat().st_size)
        return dest_path, None
    except OSError as exc:
        return None, f"Write error: {exc}"


def _parse_artifact(
    category: str,
    extracted_path: Path,
    source_path: str,
    logger: logging.Logger,
) -> dict[str, Any]:
    """
    Attempt to parse the extracted artifact and return structured metadata.

    Each category has a dedicated parser.  All parsers are wrapped in try/except
    so a malformed file never crashes the module.

    Parameters
    ----------
    category       : Artifact category string (e.g. 'lnk_file', 'prefetch').
    extracted_path : Resolved path to the extracted file on disk.
    source_path    : Original path within the image (for log messages).
    logger         : Module logger.

    Returns
    -------
    Dict of parsed fields, or {'parse_status': 'skipped'} if no parser applies.
    """
    file_size = 0
    try:
        file_size = extracted_path.stat().st_size
    except OSError:
        pass

    # Don't attempt in-memory parsing of very large files
    if MAX_PARSE_BYTES > 0 and file_size > MAX_PARSE_BYTES:
        return {"parse_status": "skipped_too_large", "size_bytes": file_size}

    try:
        if category == "lnk_file":
            return _parse_lnk(extracted_path, logger)
        elif category == "prefetch":
            return _parse_prefetch(extracted_path, logger)
        elif category == "recycle_bin" and Path(source_path).name.startswith("$I"):
            return _parse_recycle_bin_i_file(extracted_path, logger)
        elif category in ("bash_history", "zsh_history"):
            return _parse_shell_history(extracted_path, logger)
        elif category == "passwd":
            return _parse_etc_passwd(extracted_path, logger)
        elif category == "shadow":
            return {"parse_status": "extracted_only", "note": "shadow file requires manual analysis"}
        elif category == "registry_hive":
            return _parse_registry_hive(extracted_path, logger)
        elif category == "event_log":
            return _parse_evtx(extracted_path, logger)
        elif category == "auth_log":
            return _parse_text_log(extracted_path, logger, max_lines=0)
        elif category in ("cron", "hosts", "sudoers"):
            return _parse_text_log(extracted_path, logger, max_lines=0)
        else:
            return {"parse_status": "no_parser_for_category", "category": category}
    except Exception as exc:
        logger.warning("Parse error for %s (%s): %s", source_path, category, exc)
        return {"parse_status": "error", "error": str(exc)}


def _parse_lnk(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse a Windows LNK (Shell Link) file.

    LNK Header layout (little-endian):
      Offset  0: HeaderSize      (4 bytes) - must be 0x4C
      Offset  4: LinkCLSID       (16 bytes)
      Offset 20: LinkFlags       (4 bytes)
      Offset 24: FileAttributes  (4 bytes)
      Offset 28: CreationTime    (8 bytes) - FILETIME
      Offset 36: AccessTime      (8 bytes) - FILETIME
      Offset 44: WriteTime       (8 bytes) - FILETIME
      Offset 52: FileSize        (4 bytes)
      Offset 56: IconIndex       (4 bytes)
      Offset 60: ShowCommand     (4 bytes)
      Offset 64: HotKey          (2 bytes)
      Offset 66: Reserved1       (2 bytes)
      Offset 68: Reserved2       (4 bytes)
      Offset 72: Reserved3       (4 bytes)
    Total header: 76 bytes

    Reference: [MS-SHLLINK] Shell Link Binary File Format
    """
    result: dict[str, Any] = {"parse_status": "ok", "format": "LNK"}

    try:
        with open(path, "rb") as fh:
            full_data = fh.read()
        data = full_data[:512]  # Header + start of StringData

        if len(full_data) < 76:
            return {"parse_status": "too_short", "bytes_read": len(data)}

        header_size = struct.unpack_from("<I", data, 0)[0]
        if header_size != 0x4C:
            return {"parse_status": "invalid_header", "header_size": header_size}

        # Verify the LNK CLSID signature: 00021401-0000-0000-C000-000000000046
        expected_clsid = bytes([
            0x01, 0x14, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00,
            0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46,
        ])
        clsid_bytes = data[4:20]
        result["valid_clsid"] = (clsid_bytes == expected_clsid)
        if not result["valid_clsid"]:
            return {"parse_status": "invalid_clsid", "header_size": header_size, "valid_clsid": False}

        link_flags       = struct.unpack_from("<I", data, 20)[0]
        file_attributes  = struct.unpack_from("<I", data, 24)[0]
        creation_time_ft = struct.unpack_from("<Q", data, 28)[0]
        access_time_ft   = struct.unpack_from("<Q", data, 36)[0]
        write_time_ft    = struct.unpack_from("<Q", data, 44)[0]
        file_size_val    = struct.unpack_from("<I", data, 52)[0]

        result["link_flags"]      = hex(link_flags)
        result["file_attributes"] = hex(file_attributes)
        result["target_file_size"] = file_size_val

        # Convert FILETIME (100ns intervals since 1601-01-01) to ISO timestamp
        for name, ft_val in [
            ("creation_time", creation_time_ft),
            ("access_time",   access_time_ft),
            ("write_time",    write_time_ft),
        ]:
            if ft_val > 0:
                # FILETIME epoch: Jan 1, 1601; Unix epoch: Jan 1, 1970
                # Difference in seconds: 11644473600
                unix_ts = (ft_val / 10_000_000) - 11_644_473_600
                try:
                    result[name] = datetime.fromtimestamp(unix_ts, tz=timezone.utc).isoformat()
                except (OSError, OverflowError, ValueError):
                    result[name] = f"raw_filetime_{ft_val}"
            else:
                result[name] = None

        # Check HasLinkTargetIDList flag (bit 0 of LinkFlags)
        has_idlist = bool(link_flags & 0x00000001)
        result["has_target_idlist"] = has_idlist

        # Validate every optional section boundary declared by LinkFlags.
        cursor = 76
        boundary_errors: list[str] = []
        if link_flags & 0x00000001:  # HasLinkTargetIDList
            if cursor + 2 > len(full_data):
                boundary_errors.append("missing IDListSize")
            else:
                id_size = struct.unpack_from("<H", full_data, cursor)[0]
                cursor += 2
                if cursor + id_size > len(full_data):
                    boundary_errors.append("IDList exceeds file boundary")
                else:
                    result["id_list_size"] = id_size
                    cursor += id_size
        if not boundary_errors and link_flags & 0x00000002:  # HasLinkInfo
            if cursor + 4 > len(full_data):
                boundary_errors.append("missing LinkInfoSize")
            else:
                link_info_size = struct.unpack_from("<I", full_data, cursor)[0]
                if link_info_size < 0x1C or cursor + link_info_size > len(full_data):
                    boundary_errors.append("invalid LinkInfo boundary")
                else:
                    result["link_info_size"] = link_info_size
                    cursor += link_info_size
        unicode_strings_flag = bool(link_flags & 0x00000080)
        string_flags = (
            (0x00000004, "name"), (0x00000008, "relative_path"),
            (0x00000010, "working_dir"), (0x00000020, "arguments"),
            (0x00000040, "icon_location"),
        )
        for bit, label in string_flags:
            if boundary_errors or not (link_flags & bit):
                continue
            if cursor + 2 > len(full_data):
                boundary_errors.append(f"missing {label} character count")
                break
            count = struct.unpack_from("<H", full_data, cursor)[0]
            cursor += 2
            byte_count = count * (2 if unicode_strings_flag else 1)
            if cursor + byte_count > len(full_data):
                boundary_errors.append(f"{label} exceeds file boundary")
                break
            raw = full_data[cursor:cursor + byte_count]
            cursor += byte_count
            try:
                result[label] = raw.decode("utf-16le" if unicode_strings_flag else "cp1252", errors="replace")
            except Exception:
                result[label] = ""
        extra_blocks = 0
        while not boundary_errors and cursor + 4 <= len(full_data):
            block_size = struct.unpack_from("<I", full_data, cursor)[0]
            if block_size == 0:
                cursor += 4
                break
            if block_size < 8 or cursor + block_size > len(full_data):
                boundary_errors.append("invalid ExtraData block boundary")
                break
            extra_blocks += 1
            cursor += block_size
        result["extra_data_blocks"] = extra_blocks
        result["validated_end_offset"] = cursor
        result["field_boundaries_valid"] = not boundary_errors
        if boundary_errors:
            return {
                **result,
                "parse_status": "invalid_boundaries",
                "boundary_errors": boundary_errors,
                "bytes_read": len(full_data),
            }

        # Look for readable Unicode strings in the file as a retained display aid.
        # Extract all null-terminated UTF-16LE strings of 4+ chars
        unicode_strings: list[str] = []
        i = 76
        while i < len(full_data) - 1:
            # Check for a printable ASCII/Latin char followed by null (UTF-16LE)
            if full_data[i] in range(32, 127) and full_data[i + 1] == 0:
                # Try to read a complete UTF-16LE string
                end = i
                while end + 1 < len(full_data):
                    if full_data[end] == 0 and full_data[end + 1] == 0:
                        break
                    end += 2
                try:
                    candidate = full_data[i:end].decode("utf-16-le", errors="ignore")
                    if len(candidate) >= 4 and all(c.isprintable() or c in ("\t", "\n") for c in candidate):
                        unicode_strings.append(candidate)
                except UnicodeDecodeError:
                    pass
                i = end + 2
            else:
                i += 1

        if unicode_strings:
            # The target path is typically one of the longer strings
            result["embedded_strings"] = unicode_strings

    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}

    return result


def _parse_prefetch(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse the header of a Windows Prefetch (.pf) file.

    Prefetch header layout (version-dependent):
    Version 17 (XP/2003):
      Offset  0: Version     (4 bytes)  - 0x0000000F = 17
      Offset  4: Signature   (4 bytes)  - 'SCCA' = 0x53434341
      Offset  8: Unknown     (4 bytes)
      Offset 12: FileSize    (4 bytes)
      Offset 16: ExeName     (60 bytes) - null-terminated UTF-16LE
      Offset 76: Hash        (4 bytes)
      Offset 84: RunCount    (4 bytes)  in v17/23; offset varies by version

    Version 23 (Vista/7), 26 (8/8.1), 30 (10):
      Offset  0: Version     (4 bytes)
      Offset  4: Signature   (4 bytes)  - 'SCCA'
      Offset 12: FileSize    (4 bytes)
      Offset 16: ExeName     (60 bytes)
      Offset 76: Hash        (4 bytes)

    Note: Windows 10 prefetch files may be compressed (MAM format).
    This parser handles uncompressed files only.
    """
    result: dict[str, Any] = {"parse_status": "ok", "format": "Prefetch"}

    try:
        with open(path, "rb") as fh:
            data = fh.read(512)

        if len(data) < 84:
            return {"parse_status": "too_short", "bytes_read": len(data)}

        version   = struct.unpack_from("<I", data, 0)[0]
        signature = data[4:8]

        # Check for MAM compressed prefetch (Windows 10)
        if data[0:3] == b"MAM":
            result["parse_status"] = "compressed_mam"
            result["note"] = "Windows 10 compressed prefetch; decompression not implemented"
            return result

        if signature != b"SCCA":
            return {"parse_status": "invalid_signature", "signature": signature.hex()}

        result["version"] = version

        # Extract executable name (UTF-16LE, null-terminated, 60 bytes = 30 chars max)
        exe_bytes = data[16:76]
        try:
            exe_name = exe_bytes.decode("utf-16-le", errors="replace").rstrip("\x00").rstrip("�")
            result["executable_name"] = exe_name
        except UnicodeDecodeError:
            result["executable_name"] = exe_bytes.hex()

        # Hash (used to distinguish multiple instances of the same executable)
        pf_hash = struct.unpack_from("<I", data, 76)[0]
        result["prefetch_hash"] = hex(pf_hash)

        # Run count location varies by version:
        #   v17 (XP)     : offset 84
        #   v23 (Vista/7): offset 84
        #   v26 (Win8)   : offset 84
        #   v30 (Win10)  : offset 84 (before MAM compression was introduced)
        if len(data) >= 88:
            run_count = struct.unpack_from("<I", data, 84)[0]
            result["run_count"] = run_count

        # File size from header
        file_size_in_header = struct.unpack_from("<I", data, 12)[0]
        result["header_file_size"] = file_size_in_header

    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}

    return result


def _parse_recycle_bin_i_file(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse a Windows Vista+ Recycle Bin $I metadata file.

    $I file format (Vista/7/8/10 - version 2):
      Offset  0: Header/Version  (8 bytes)  - 0x0000000000000002
      Offset  8: FileSize        (8 bytes)  - original file size in bytes
      Offset 16: DeletionTime    (8 bytes)  - FILETIME of deletion
      Offset 24: FileNameLength  (4 bytes)  - number of characters in filename
      Offset 28: FileName        (variable) - UTF-16LE original path

    Note: Windows 10 version 2 files have FileNameLength at offset 24.
    Earlier Vista/7 files (version 1) do not have the length field; the
    filename is simply null-terminated at offset 24.
    """
    result: dict[str, Any] = {"parse_status": "ok", "format": "RecycleBin_I"}

    try:
        with open(path, "rb") as fh:
            data = fh.read(4096)  # $I files are small; 4KB is more than enough

        if len(data) < 28:
            return {"parse_status": "too_short", "bytes_read": len(data)}

        version       = struct.unpack_from("<Q", data, 0)[0]
        file_size_val = struct.unpack_from("<Q", data, 8)[0]
        deletion_ft   = struct.unpack_from("<Q", data, 16)[0]

        result["version"]            = version
        result["original_file_size"] = file_size_val

        # Convert FILETIME to ISO timestamp
        if deletion_ft > 0:
            unix_ts = (deletion_ft / 10_000_000) - 11_644_473_600
            try:
                result["deletion_time"] = datetime.fromtimestamp(
                    unix_ts, tz=timezone.utc
                ).isoformat()
            except (OSError, OverflowError, ValueError):
                result["deletion_time"] = f"raw_filetime_{deletion_ft}"

        # Version 2 (Win10+): 4-byte name length field before the name
        if version == 2 and len(data) >= 32:
            name_len = struct.unpack_from("<I", data, 24)[0]
            name_offset = 28
            name_bytes = data[name_offset : name_offset + name_len * 2]
        else:
            # Version 1 (Vista/7): null-terminated at offset 24
            name_offset = 24
            name_end = data.find(b"\x00\x00", name_offset)
            if name_end == -1:
                name_end = len(data)
            name_bytes = data[name_offset:name_end]

        try:
            original_path = name_bytes.decode("utf-16-le", errors="replace").rstrip("\x00")
            result["original_path"] = original_path
        except UnicodeDecodeError:
            result["original_path_hex"] = name_bytes.hex()

    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}

    return result


def _parse_shell_history(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Read a bash or zsh history file and return its lines as a list.

    History files are plain text; the only complexity is encoding (they can
    contain arbitrary bytes from user commands).  We use errors='replace'.
    """
    result: dict[str, Any] = {"parse_status": "ok", "format": "shell_history"}

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = [line.rstrip("\n") for line in fh if line.strip()]

        result["line_count"] = len(lines)
        result["commands"] = lines

    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}

    return result


def _parse_etc_passwd(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse /etc/passwd into a list of user account records.

    /etc/passwd format (colon-delimited, 7 fields):
      username:password:UID:GID:GECOS:home_dir:shell
    """
    result: dict[str, Any] = {"parse_status": "ok", "format": "etc_passwd"}
    accounts: list[dict[str, Any]] = []

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                fields = line.split(":")
                if len(fields) >= 7:
                    try:
                        uid = int(fields[2])
                    except ValueError:
                        uid = -1
                    accounts.append({
                        "username": fields[0],
                        "uid":      uid,
                        "gid":      fields[3],
                        "gecos":    fields[4],
                        "home_dir": fields[5],
                        "shell":    fields[6],
                    })

    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}

    result["accounts"]     = accounts
    result["account_count"] = len(accounts)
    # Flag non-system accounts (UID >= 1000 on Linux) as interesting
    result["regular_users"] = [a for a in accounts if a["uid"] >= 1000]

    return result


def _parse_registry_hive(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse a Windows Registry hive using python-registry if available, or raw
    binary parsing as a fallback.

    Extracts user accounts (SAM), installed software (SOFTWARE), USB connection
    history (SYSTEM), and recently accessed files (NTUSER.DAT).
    """
    result: dict[str, Any] = {"format": "Windows_Registry_Hive"}

    if _REGISTRY_AVAILABLE:
        try:
            reg = _WinRegistry(str(path))  # type: ignore[misc]
            root = reg.root()
            result["parse_status"]  = "ok"
            result["root_key_name"] = root.name()
            result["subkey_count"]  = root.subkeys_number()
            result["value_count"]   = root.values_number()
            top_keys: list[str] = [sk.name() for sk in root.subkeys()]
            result["top_level_keys"] = top_keys
            result["parsed_by"] = "python-registry"
            return result
        except Exception as exc:
            logger.warning("python-registry failed on %s: %s - trying raw parser", path.name, exc)

    # ── Raw binary fallback (last resort) ─────────────────────────────────
    raw = _parse_registry_hive_raw(path, logger)
    raw["parsed_by"] = raw.get("parsed_by", "raw_binary_fallback")
    raw["parse_reliability"] = "INDETERMINATE"  # raw parser cannot verify completeness
    return raw


def _parse_registry_hive_raw(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse a Windows Registry hive file using raw binary parsing of REGF format.

    Implements minimal REGF/HBIN/NK/VK cell navigation to extract forensically
    significant key-value pairs from SAM, SOFTWARE, SYSTEM, and NTUSER.DAT.

    Reference: libregf (Joachim Metz), python-registry (William Ballenthin),
    and Windows Internals (Russinovich et al.).
    """
    hive_name = path.name.upper()
    result: dict[str, Any] = {
        "format":      "Windows_Registry_Hive",
        "parsed_by":   "raw_binary_fallback",
        "hive_file":   path.name,
    }

    try:
        data = path.read_bytes()
    except OSError as exc:
        result["parse_status"] = "io_error"
        result["error"] = str(exc)
        return result

    if len(data) < 4096 or data[:4] != b"regf":
        result["parse_status"] = "invalid_magic"
        result["note"] = f"File is {len(data)} bytes; expected REGF magic"
        return result

    try:
        parser = _RegfParser(data)
        result["parse_status"]    = "ok"
        result["root_key_name"]   = parser.root_name()
        result["hive_bins_size"]  = parser.hive_bins_size
        result["top_level_keys"]  = parser.list_top_keys()

        # Hive-specific extraction
        if "SAM" in hive_name:
            result["user_accounts"] = parser.extract_sam_users()
        elif "SOFTWARE" in hive_name:
            result["installed_software"] = parser.extract_installed_software()
        elif "SYSTEM" in hive_name:
            result["usb_devices"]   = parser.extract_usb_history()
            result["computername"]  = parser.extract_computer_name()
        elif "NTUSER" in hive_name:
            result["recent_docs"]   = parser.extract_recent_docs()
            result["typed_paths"]   = parser.extract_typed_paths()

    except Exception as exc:
        logger.warning("Raw registry parse failed for %s: %s", path.name, exc)
        result["parse_status"] = "error"
        result["error"]        = str(exc)

    return result


class _RegfParser:
    """
    Minimal REGF-format Windows Registry hive parser.

    Cell offsets throughout this class are relative to the start of the
    hive-bins data section (file offset 4096).  To get an absolute file
    offset add _HIVE_BINS_BASE to the cell offset.
    """

    _HIVE_BINS_BASE = 4096

    def __init__(self, data: bytes) -> None:
        self._data = data
        # Root cell offset stored at header offset 32 (relative to hive-bins start)
        self._root_off: int = struct.unpack_from("<I", data, 32)[0]
        self.hive_bins_size: int = struct.unpack_from("<I", data, 40)[0]
        # Hive filename at header offset 48 (64 bytes, UTF-16LE)
        try:
            self._hive_fname = data[48:112].decode("utf-16-le", errors="replace").rstrip("\x00").rstrip("\x00")
        except Exception:
            self._hive_fname = ""

    # ── Public helpers ────────────────────────────────────────────────────

    def root_name(self) -> str:
        nk = self._read_nk(self._root_off)
        return nk.get("name", "(root)")

    def list_top_keys(self) -> list[str]:
        root = self._read_nk(self._root_off)
        return [name for name, _ in self._iter_subkeys(root)]

    # ── SAM ───────────────────────────────────────────────────────────────

    def extract_sam_users(self) -> list[dict[str, Any]]:
        """Extract local user accounts from SAM\\Domains\\Account\\Users\\Names."""
        nk = self._navigate(["SAM", "Domains", "Account", "Users", "Names"])
        if nk is None:
            nk = self._navigate(["Domains", "Account", "Users", "Names"])
        if nk is None:
            return []
        users = []
        for name, sub_off in self._iter_subkeys(nk):
            users.append({"username": name, "rid_source": "SAM\\Names"})
        return users

    # ── SOFTWARE ──────────────────────────────────────────────────────────

    def extract_installed_software(self) -> list[dict[str, Any]]:
        """Extract installed programs from SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall."""
        paths_to_try = [
            ["Microsoft", "Windows", "CurrentVersion", "Uninstall"],
            ["Wow6432Node", "Microsoft", "Windows", "CurrentVersion", "Uninstall"],
        ]
        software = []
        for path in paths_to_try:
            nk = self._navigate(path)
            if nk is None:
                continue
            for prog_name, prog_off in self._iter_subkeys(nk):
                prog_nk   = self._read_nk(prog_off)
                prog_vals = self._read_values(prog_nk)
                entry: dict[str, Any] = {"key_name": prog_name}
                for field in ("DisplayName", "DisplayVersion", "Publisher",
                              "InstallDate", "InstallLocation"):
                    if field in prog_vals:
                        entry[field.lower()] = str(prog_vals[field])
                software.append(entry)
        return software

    # ── SYSTEM ────────────────────────────────────────────────────────────

    def extract_usb_history(self) -> list[dict[str, Any]]:
        """Extract USB device history from SYSTEM\\ControlSet001\\Enum\\USBSTOR."""
        usbstor: dict[str, Any] | None = None
        for cs in ("ControlSet001", "ControlSet002", "CurrentControlSet"):
            usbstor = self._navigate([cs, "Enum", "USBSTOR"])
            if usbstor is not None:
                break
        if usbstor is None:
            return []
        devices = []
        for device_class, class_off in self._iter_subkeys(usbstor):
            class_nk = self._read_nk(class_off)
            for instance, inst_off in self._iter_subkeys(class_nk):
                inst_nk   = self._read_nk(inst_off)
                inst_vals = self._read_values(inst_nk)
                devices.append({
                    "device_class": device_class,
                    "instance_id":  instance,
                    "friendly_name": str(inst_vals.get("FriendlyName", "")),
                    "hardware_id":   str(inst_vals.get("HardwareID", "")),
                    "mfg":           str(inst_vals.get("Mfg", "")),
                })
        return devices

    def extract_computer_name(self) -> str:
        """Extract computer name from SYSTEM\\ControlSet001\\Control\\ComputerName."""
        for cs in ("ControlSet001", "ControlSet002", "CurrentControlSet"):
            nk = self._navigate([cs, "Control", "ComputerName", "ComputerName"])
            if nk:
                vals = self._read_values(nk)
                if "ComputerName" in vals:
                    return str(vals["ComputerName"])
        return ""

    # ── NTUSER.DAT ────────────────────────────────────────────────────────

    def extract_recent_docs(self) -> dict[str, list[str]]:
        """Extract recently accessed files from RecentDocs MRU lists."""
        nk = self._navigate([
            "Software", "Microsoft", "Windows", "CurrentVersion",
            "Explorer", "RecentDocs"
        ])
        if nk is None:
            return {}
        docs: dict[str, list[str]] = {}
        vals = self._read_values(nk)
        mru = self._decode_mru_list(vals)
        if mru:
            docs["(root)"] = mru

        for ext, sub_off in self._iter_subkeys(nk):
            sub_nk   = self._read_nk(sub_off)
            sub_vals = self._read_values(sub_nk)
            mru_items = self._decode_mru_list(sub_vals)
            if mru_items:
                docs[ext] = mru_items

        return docs

    def extract_typed_paths(self) -> list[str]:
        """Extract paths the user manually typed into Explorer's address bar."""
        nk = self._navigate([
            "Software", "Microsoft", "Windows", "CurrentVersion",
            "Explorer", "TypedPaths"
        ])
        if nk is None:
            return []
        vals = self._read_values(nk)
        return [str(v) for v in vals.values() if isinstance(v, str)]

    # ── REGF navigation internals ─────────────────────────────────────────

    def _cell_data(self, offset: int) -> bytes:
        """Return the payload bytes of the cell at the given hive-bins offset."""
        abs_off = self._HIVE_BINS_BASE + offset
        if abs_off + 4 > len(self._data):
            return b""
        size = struct.unpack_from("<i", self._data, abs_off)[0]
        payload_size = abs(size) - 4
        if payload_size <= 0:
            return b""
        return self._data[abs_off + 4 : abs_off + 4 + payload_size]

    def _read_nk(self, offset: int) -> dict[str, Any]:
        """Read an NK (key node) cell. Returns empty dict if invalid."""
        cell = self._cell_data(offset)
        if len(cell) < 80 or cell[:2] != b"nk":
            return {}
        flags       = struct.unpack_from("<H", cell, 2)[0]
        num_sub     = struct.unpack_from("<I", cell, 20)[0]
        sub_off     = struct.unpack_from("<i", cell, 28)[0]
        num_vals    = struct.unpack_from("<I", cell, 36)[0]
        vals_off    = struct.unpack_from("<i", cell, 40)[0]
        name_len    = struct.unpack_from("<H", cell, 72)[0]
        is_ascii    = bool(flags & 0x0020)
        name_raw    = cell[76 : 76 + name_len]
        try:
            name = name_raw.decode("ascii" if is_ascii else "utf-16-le", errors="replace")
        except Exception:
            name = name_raw.hex()
        return {
            "name":      name,
            "num_sub":   num_sub,
            "sub_off":   sub_off,
            "num_vals":  num_vals,
            "vals_off":  vals_off,
        }

    def _iter_subkeys(self, nk: dict[str, Any]) -> list[tuple[str, int]]:
        """Return (name, offset) pairs for all direct subkeys of nk."""
        if not nk or nk.get("num_sub", 0) == 0 or nk.get("sub_off", -1) < 0:
            return []
        return self._expand_key_list(nk["sub_off"])

    def _expand_key_list(
        self,
        list_off: int,
        depth: int = 0,
        _seen_list_offsets: set[int] | None = None,
    ) -> list[tuple[str, int]]:
        """Recursively expand every reachable lf/lh/li/ri key-list node.

        No arbitrary RI-depth cap is used. Visited offsets prevent malformed
        registry structures from causing cycles.
        """
        if _seen_list_offsets is None:
            _seen_list_offsets = set()
        if list_off in _seen_list_offsets:
            return []
        _seen_list_offsets.add(list_off)
        cell = self._cell_data(list_off)
        if len(cell) < 4:
            return []
        sig   = cell[:2]
        count = struct.unpack_from("<H", cell, 2)[0]
        results: list[tuple[str, int]] = []

        if sig in (b"lf", b"lh"):
            for i in range(min(count, (len(cell) - 4) // 8)):
                off = struct.unpack_from("<i", cell, 4 + i * 8)[0]
                if off < 0:
                    continue
                sub_nk = self._read_nk(off)
                if sub_nk:
                    results.append((sub_nk["name"], off))
        elif sig == b"li":
            for i in range(min(count, (len(cell) - 4) // 4)):
                off = struct.unpack_from("<i", cell, 4 + i * 4)[0]
                if off < 0:
                    continue
                sub_nk = self._read_nk(off)
                if sub_nk:
                    results.append((sub_nk["name"], off))
        elif sig == b"ri":
            for i in range(min(count, (len(cell) - 4) // 4)):
                sub_list_off = struct.unpack_from("<i", cell, 4 + i * 4)[0]
                if sub_list_off >= 0:
                    results.extend(self._expand_key_list(sub_list_off, depth + 1, _seen_list_offsets))

        return results

    def _navigate(self, path: list[str], start: int | None = None) -> dict[str, Any] | None:
        """Navigate to a key by component path list. Returns the NK dict or None."""
        current_off = self._root_off if start is None else start
        for component in path:
            nk = self._read_nk(current_off)
            if not nk:
                return None
            found = False
            for name, sub_off in self._iter_subkeys(nk):
                if name.lower() == component.lower():
                    current_off = sub_off
                    found = True
                    break
            if not found:
                return None
        return self._read_nk(current_off)

    def _read_values(self, nk: dict[str, Any]) -> dict[str, Any]:
        """Read all values from an NK cell. Returns name→decoded-value mapping."""
        vals: dict[str, Any] = {}
        if not nk or nk.get("num_vals", 0) == 0 or nk.get("vals_off", -1) < 0:
            return vals
        vlist = self._cell_data(nk["vals_off"])
        for i in range(min(nk["num_vals"], len(vlist) // 4)):
            vk_off = struct.unpack_from("<i", vlist, i * 4)[0]
            if vk_off < 0:
                continue
            vk = self._cell_data(vk_off)
            if len(vk) < 20 or vk[:2] != b"vk":
                continue
            try:
                name_len  = struct.unpack_from("<H", vk, 2)[0]
                data_size = struct.unpack_from("<I", vk, 4)[0]
                data_off  = struct.unpack_from("<i", vk, 8)[0]
                data_type = struct.unpack_from("<I", vk, 12)[0]
                vk_flags  = struct.unpack_from("<H", vk, 16)[0]
                is_ascii  = bool(vk_flags & 0x0001)

                val_name = ("(Default)" if name_len == 0 else
                            vk[20:20+name_len].decode(
                                "ascii" if is_ascii else "utf-16-le", errors="replace"))

                inline    = bool(data_size & 0x80000000)
                act_size  = data_size & 0x7FFFFFFF
                raw       = (struct.pack("<I", data_off)[:act_size] if inline
                             else self._cell_data(data_off)[:act_size])

                if data_type == 1:    # REG_SZ
                    decoded: Any = raw.decode("utf-16-le", errors="replace").rstrip("\x00")
                elif data_type == 2:  # REG_EXPAND_SZ
                    decoded = raw.decode("utf-16-le", errors="replace").rstrip("\x00")
                elif data_type == 4:  # REG_DWORD
                    decoded = struct.unpack_from("<I", raw)[0] if len(raw) >= 4 else 0
                elif data_type == 7:  # REG_MULTI_SZ
                    decoded = [s for s in raw.decode("utf-16-le", errors="replace").split("\x00") if s]
                else:
                    decoded = raw.hex()
                vals[val_name] = decoded
            except Exception:
                continue
        return vals

    @staticmethod
    def _decode_mru_list(vals: dict[str, Any]) -> list[str]:
        """Decode MRUListEx or MRUList value into an ordered list of file names."""
        items: list[str] = []
        # Try MRUListEx (DWORD array of indexes)
        order_raw = vals.get("MRUListEx", b"")
        if isinstance(order_raw, str) and len(order_raw) > 0:
            try:
                order_raw = bytes.fromhex(order_raw)
            except Exception:
                order_raw = b""
        if isinstance(order_raw, bytes) and len(order_raw) >= 4:
            for i in range(0, len(order_raw) - 3, 4):
                idx = struct.unpack_from("<I", order_raw, i)[0]
                if idx == 0xFFFFFFFF:
                    break
                raw_entry = vals.get(str(idx), "")
                if isinstance(raw_entry, str) and raw_entry:
                    name = raw_entry.split("\x00")[0]
                    if name:
                        items.append(name)
        return items


def _parse_evtx(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """
    Parse a Windows Event Log (.evtx) file using python-evtx if available.

    If python-evtx is not installed, returns extracted_only status.
    When available, every readable event record is retained in the manifest.
    """
    result: dict[str, Any] = {"format": "Windows_Event_Log"}

    if not _EVTX_AVAILABLE:
        result["parse_status"] = "extracted_only"
        result["note"] = (
            "python-evtx not installed. "
            "Install with: pip install python-evtx. "
            "File extracted and available for manual analysis."
        )
        return result

    try:
        events: list[dict[str, Any]] = []
        with _evtx_lib.Evtx(str(path)) as log:  # type: ignore[misc]
            for record in log.records():
                try:
                    xml_str = record.xml()
                    # Extract a few key fields from the XML via simple regex
                    event_id_m   = re.search(r"<EventID[^>]*>(\d+)</EventID>", xml_str)
                    time_created = re.search(r"SystemTime=['\"]([^'\"]+)['\"]", xml_str)
                    channel      = re.search(r"<Channel>([^<]+)</Channel>", xml_str)
                    events.append({
                        "record_num":    record.record_num(),
                        "event_id":      event_id_m.group(1) if event_id_m else None,
                        "time_created":  time_created.group(1) if time_created else None,
                        "channel":       channel.group(1) if channel else None,
                    })
                except Exception:
                    continue

        result["parse_status"] = "ok"
        result["events"] = events
        result["event_count"] = len(events)
        result["coverage_complete"] = True

    except Exception as exc:
        result["parse_status"] = "error"
        result["error"]        = str(exc)
        result["note"]         = "File extracted; open manually with Event Viewer or evtxexport."

    return result


def _parse_text_log(path: Path, logger: logging.Logger, max_lines: int = 0) -> dict[str, Any]:
    """Read a plain-text log/config file; max_lines<=0 means exhaustive."""
    result: dict[str, Any] = {"parse_status": "ok", "format": "text"}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = []
            for i, line in enumerate(fh):
                if max_lines > 0 and i >= max_lines:
                    result["truncated"] = True
                    result["limit_reached"] = True
                    break
                lines.append(line.rstrip("\n"))
        result["lines"]      = lines
        result["line_count"] = len(lines)
    except OSError as exc:
        return {"parse_status": "io_error", "error": str(exc)}
    return result


def _create_findings(
    category: str,
    match: dict[str, Any],
    extracted_path: Path,
    parsed: dict[str, Any],
    logger: logging.Logger,
) -> list[Finding]:
    """
    Generate Finding objects based on the artifact category and parsed content.

    Severity mapping:
      HIGH   : SAM/shadow (credential stores), $Recycle.Bin entries (deleted evidence),
                prefetch for deleted executables
      MEDIUM : NTUSER.DAT, bash/zsh history, SSH keys and known_hosts
      INFO   : All other successfully extracted artifacts

    Parameters
    ----------
    category       : Artifact category string.
    match          : The fls match dict (has 'path', 'inode', 'filename', etc.).
    extracted_path : Path to the extracted file.
    parsed         : Output of _parse_artifact().
    logger         : Module logger.

    Returns
    -------
    List of Finding objects (may be empty).
    """
    findings: list[Finding] = []
    source_path = match["path"]
    filename    = match["filename"].lower()

    # -----------------------------------------------------------------------
    # HIGH severity findings
    # -----------------------------------------------------------------------
    if category == "registry_hive" and filename in ("sam", "shadow"):
        findings.append(make_finding(
            finding_type  = "CREDENTIAL_STORE_EXTRACTED",
            severity      = Severity.HIGH,
            description   = (
                f"Credential store '{filename.upper()}' extracted from image. "
                "This file contains password hashes for local user accounts. "
                "Its presence enables offline password cracking attacks."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "category":    category,
                "inode":       match["inode"],
                "parsed":      parsed.get("parse_status"),
                "file_size":   parsed.get("size_bytes"),
            },
        ))

    elif category == "shadow":
        findings.append(make_finding(
            finding_type  = "LINUX_SHADOW_FILE_EXTRACTED",
            severity      = Severity.HIGH,
            description   = (
                "Linux /etc/shadow file extracted. Contains hashed passwords for all "
                "local accounts. Immediate offline cracking is possible with hashcat/john."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {"category": category, "inode": match["inode"]},
        ))

    elif category == "recycle_bin" and match["filename"].startswith("$I"):
        # $I files indicate a file was deleted - this is evidentiary
        original_path = parsed.get("original_path", "unknown")
        deletion_time = parsed.get("deletion_time", "unknown")
        file_size_val = parsed.get("original_file_size", 0)
        findings.append(make_finding(
            finding_type  = "RECYCLE_BIN_DELETION_RECORD",
            severity      = Severity.MEDIUM,
            description   = (
                f"Recycle Bin deletion record found. Original file: '{original_path}'. "
                f"Deleted at: {deletion_time}. Original size: {file_size_val} bytes. "
                "Records Windows Recycle Bin deletion metadata. The artefact does not, by itself, identify the user, establish intent, or prove that the deletion was anti-forensic."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "original_path": original_path,
                "deletion_time": deletion_time,
                "file_size":     file_size_val,
                "inode":         match["inode"],
            },
        ))

    elif category == "prefetch" and parsed.get("parse_status") == "ok":
        exe_name  = parsed.get("executable_name", "unknown")
        run_count = parsed.get("run_count")
        pf_hash   = parsed.get("prefetch_hash", "")
        findings.append(make_finding(
            finding_type="PREFETCH_EXECUTION_RECORD",
            severity=Severity.MEDIUM,
            description=(
                f"A structurally valid Prefetch record references '{exe_name}' with stored run count {run_count}. "
                "This supports Prefetch-record presence; user identity and intent are not inferred."
            ),
            evidence_path=source_path,
            artifact_path=str(extracted_path),
            metadata={
                **deterministic_metadata(
                    "Prefetch structural parser",
                    validators=["SCCA signature", "supported version", "declared-size and field-boundary checks"],
                    semantic_limit="Valid Prefetch record only; user identity and intent are not established.",
                ),
                "executable_name": exe_name, "run_count": run_count,
                "prefetch_hash": pf_hash, "inode": match["inode"],
                "parse_status": parsed.get("parse_status"),
            },
        ))

    elif category == "prefetch":
        findings.append(make_finding(
            finding_type="PREFETCH_LIKE_MARKER",
            severity=Severity.INFO,
            description="An SCCA-prefixed or extension-matched Prefetch-like file was retained, but it is not a complete validated Prefetch record.",
            evidence_path=source_path,
            artifact_path=str(extracted_path),
            metadata={
                **deterministic_metadata(
                    "Prefetch minimum-structure validation",
                    validators=["signature", "version", "declared size", "field boundaries"],
                    semantic_limit="Marker/path literal only; program execution is not established.",
                ),
                "inode": match["inode"], "parse_status": parsed.get("parse_status"),
                "structure": parsed,
            },
        ))

    elif category == "lnk_file":
        valid = (
            parsed.get("parse_status") == "ok"
            and parsed.get("valid_clsid") is True
            and parsed.get("field_boundaries_valid") is True
        )
        if valid:
            findings.append(make_finding(
                finding_type="WINDOWS_SHELL_LINK_VALIDATED",
                severity=Severity.INFO,
                description="A structurally valid Windows Shell Link record was parsed.",
                evidence_path=source_path,
                artifact_path=str(extracted_path),
                metadata={
                    **deterministic_metadata(
                        "MS-SHLLINK structural parser",
                        validators=["0x4C header", "Shell Link CLSID", "LinkFlags", "declared field boundaries"],
                        semantic_limit="Stored link structure only; execution or user intent is not established.",
                    ),
                    "inode": match["inode"], "parse_status": parsed.get("parse_status"),
                    "parsed": parsed,
                },
            ))
        else:
            findings.append(make_finding(
                finding_type="SHELL_LINK_LIKE_MARKER",
                severity=Severity.INFO,
                description="LNK-like marker — incomplete or non-standard structure; no valid Windows Shell Link is claimed.",
                evidence_path=source_path,
                artifact_path=str(extracted_path),
                metadata={
                    **deterministic_metadata(
                        "Shell Link header/CLSID/size validation",
                        validators=["0x4C header size", "Shell Link CLSID", "LinkFlags", "field boundaries"],
                        semantic_limit="Marker and literal-path presence only; shortcut use or execution is not established.",
                    ),
                    "inode": match["inode"], "parse_status": parsed.get("parse_status"),
                    "structure": parsed,
                },
            ))

    elif category == "event_log":
        valid = parsed.get("parse_status") in {"ok", "parsed"} and int(parsed.get("record_count") or 0) >= 0
        if valid:
            findings.append(make_finding(
                finding_type="WINDOWS_EVENT_LOG_VALIDATED",
                severity=Severity.INFO,
                description="A structurally valid Windows Event Log container was parsed.",
                evidence_path=source_path,
                artifact_path=str(extracted_path),
                metadata={
                    **deterministic_metadata(
                        "EVTX structural parser",
                        validators=["ElfFile signature", "header/chunk boundaries", "record parser"],
                        semantic_limit="Parsed event-log records only; no intent or attribution is inferred.",
                    ),
                    "inode": match["inode"], "parse_status": parsed.get("parse_status"),
                    "parsed": parsed,
                },
            ))
        else:
            findings.append(make_finding(
                finding_type="EVTX_LIKE_MARKER",
                severity=Severity.INFO,
                description="An EVTX-like marker was retained, but the file is incomplete or non-standard and no native event record is claimed.",
                evidence_path=source_path,
                artifact_path=str(extracted_path),
                metadata={
                    **deterministic_metadata(
                        "EVTX signature and minimum-structure validation",
                        validators=["ElfFile signature", "minimum header and chunk invariants"],
                        semantic_limit="Marker/container presence only; no complete native event record is claimed.",
                    ),
                    "inode": match["inode"], "parse_status": parsed.get("parse_status"),
                    "structure": parsed,
                },
            ))

    # -----------------------------------------------------------------------
    # MEDIUM severity findings
    # -----------------------------------------------------------------------
    elif category == "registry_hive" and "ntuser" in filename.lower():
        findings.append(make_finding(
            finding_type  = "USER_REGISTRY_HIVE_FOUND",
            severity      = Severity.MEDIUM,
            description   = (
                f"User registry hive (NTUSER.DAT) found at '{source_path}'. "
                "Contains user activity history including MRU lists, typed paths, "
                "shellbags, and recently used programs. Highly valuable for timeline."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "parse_status":  parsed.get("parse_status"),
                "root_key_name": parsed.get("root_key_name"),
                "subkey_count":  parsed.get("subkey_count"),
                "inode":         match["inode"],
            },
        ))

    elif category in ("bash_history", "zsh_history"):
        command_count = parsed.get("line_count", 0)
        findings.append(make_finding(
            finding_type  = "SHELL_COMMAND_HISTORY_FOUND",
            severity      = Severity.MEDIUM,
            description   = (
                f"Shell command history found at '{source_path}'. "
                f"{command_count} command(s) recorded. "
                "May reveal investigative leads, data exfiltration attempts, "
                "or attacker TTPs."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "command_count": command_count,
                "sample_commands": parsed.get("commands", [])[:10],
                "inode":          match["inode"],
            },
        ))

    elif category in ("ssh_known", "ssh_key"):
        findings.append(make_finding(
            finding_type  = "SSH_ARTIFACT_FOUND",
            severity      = Severity.MEDIUM,
            description   = (
                f"SSH artifact found at '{source_path}'. "
                "SSH known_hosts and private keys reveal remote systems the "
                "user has accessed and may allow lateral movement."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {"category": category, "inode": match["inode"]},
        ))

    elif category == "passwd":
        regular_users = parsed.get("regular_users", [])
        findings.append(make_finding(
            finding_type  = "PASSWD_FILE_EXTRACTED",
            severity      = Severity.MEDIUM,
            description   = (
                f"/etc/passwd extracted. {parsed.get('account_count', 0)} account(s), "
                f"{len(regular_users)} regular user(s): "
                + ", ".join(u["username"] for u in regular_users[:5])
                + ("..." if len(regular_users) > 5 else "") + ". "
                "Provides user account inventory for this system."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "account_count":  parsed.get("account_count"),
                "regular_users":  [u["username"] for u in regular_users],
                "inode":          match["inode"],
            },
        ))

    # -----------------------------------------------------------------------
    # Exact hosts-file records
    # -----------------------------------------------------------------------
    elif category == "hosts":
        records = extract_structured_records(extracted_path)
        for record in records:
            ip_value = str(record.fields.get("ip") or "")
            host_value = str(record.fields.get("hostnames") or "")
            if not ip_value or not host_value:
                continue
            findings.append(make_finding(
                finding_type="HOSTS_FILE_ENTRY",
                severity=Severity.INFO,
                description=(
                    f"Hosts-file entry maps {ip_value} to {host_value}. "
                    "This reports the retained mapping only; DNS resolution or user intent is not inferred."
                ),
                evidence_path=source_path,
                artifact_path=str(extracted_path),
                metadata={
                    **deterministic_metadata(
                        "line-oriented hosts-file parser",
                        validators=["core.structured_records hosts parser", "IP literal parser"],
                        semantic_limit="Static hosts-file mapping only",
                    ),
                    **record_locator_metadata(record),
                    "inode": match.get("inode"),
                    "ip": ip_value,
                    "hostnames": host_value.split(),
                    "source_image_path": source_path,
                },
            ))

    # -----------------------------------------------------------------------
    # INFO severity findings - all other successfully extracted artifacts
    # -----------------------------------------------------------------------
    else:
        findings.append(make_finding(
            finding_type  = f"ARTIFACT_EXTRACTED_{category.upper()}",
            severity      = Severity.INFO,
            description   = (
                f"Artifact extracted: '{source_path}' (category: {category}). "
                f"Parse status: {parsed.get('parse_status', 'unknown')}."
            ),
            evidence_path = source_path,
            artifact_path = str(extracted_path),
            metadata      = {
                "category":     category,
                "inode":        match["inode"],
                "parse_status": parsed.get("parse_status"),
            },
        ))

    return findings
