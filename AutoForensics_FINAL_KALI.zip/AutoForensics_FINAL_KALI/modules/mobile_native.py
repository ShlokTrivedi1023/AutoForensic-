"""Dependency-free native fallback for common Android/iOS SQLite artefacts."""
from __future__ import annotations
import csv, hashlib, json, shutil, sqlite3, tarfile, zipfile
from pathlib import Path
from typing import Any

MAX_ROWS=0

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as fh:
        for block in iter(lambda:fh.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def _safe_member(name:str)->bool:
    p=Path(name)
    return not p.is_absolute() and '..' not in p.parts

def materialize_input(source:Path,dest:Path)->Path:
    if source.is_dir(): return source
    dest.mkdir(parents=True,exist_ok=True)
    if zipfile.is_zipfile(source):
        with zipfile.ZipFile(source) as zf:
            for info in zf.infolist():
                if not _safe_member(info.filename) or info.is_dir(): continue
                target=(dest/info.filename).resolve()
                if dest.resolve() not in target.parents: continue
                target.parent.mkdir(parents=True,exist_ok=True)
                with zf.open(info) as src, target.open('wb') as out:
                    shutil.copyfileobj(src, out, length=1024*1024)
        return dest
    if tarfile.is_tarfile(source):
        with tarfile.open(source,'r:*') as tf:
            for member in tf:
                if not member.isfile() or not _safe_member(member.name): continue
                target=(dest/member.name).resolve()
                if dest.resolve() not in target.parents: continue
                target.parent.mkdir(parents=True,exist_ok=True)
                src=tf.extractfile(member)
                if src:
                    with target.open('wb') as out: shutil.copyfileobj(src, out, length=1024*1024)
        return dest
    return source.parent

def _tables(conn:sqlite3.Connection)->set[str]:
    try: return {str(r[0]) for r in conn.execute("select name from sqlite_master where type='table'")}
    except sqlite3.DatabaseError: return set()

def _columns(conn:sqlite3.Connection,table:str)->list[str]:
    try: return [str(r[1]) for r in conn.execute(f'pragma table_info("{table}")')]
    except sqlite3.DatabaseError: return []

def _read(conn:sqlite3.Connection,table:str,wanted:list[str])->list[dict[str,Any]]:
    cols=_columns(conn,table); selected=[x for x in wanted if x in cols]
    if not selected: return []
    sql='select '+','.join('\"'+x+'\"' for x in selected)+f' from \"{table}\"' + (f' limit {MAX_ROWS}' if MAX_ROWS > 0 else '')
    try:
        cur=conn.execute(sql)
        return [dict(zip(selected,row)) for row in cur.fetchall()]
    except sqlite3.DatabaseError: return []

def _write_csv(path:Path,rows:list[dict[str,Any]])->None:
    if not rows:return
    fields=sorted({k for row in rows for k in row})
    with path.open('w',encoding='utf-8',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=fields);w.writeheader();w.writerows(rows)

def _is_sqlite(path:Path)->bool:
    try:
        return path.read_bytes()[:16] == b"SQLite format 3\x00"
    except OSError:
        return False


def _platform_path(path:Path,root:Path,device_type:str)->bool:
    """Return whether an extracted path belongs to the declared platform.

    Mixed extraction roots are common in validation corpora and commercial
    exports.  Schema alone is not enough to assign a copied browser database to
    both platforms, so explicit extraction-path structure is used when present.
    """
    try: rel=path.relative_to(root).as_posix().casefold()
    except ValueError: rel=path.as_posix().casefold()
    android_markers=('data/data/','data/user/','android/data/','system/users/')
    ios_markers=('private/var/','homedomain/','library/sms/','library/safari/')
    has_android=any(m in rel for m in android_markers)
    has_ios=any(m in rel for m in ios_markers)
    if device_type=='android' and has_ios: return False
    if device_type=='ios' and has_android: return False
    return True


def _read_text_records(root:Path,device_type:str)->tuple[list[dict[str,Any]],list[dict[str,Any]]]:
    device=[]; manifests=[]
    for path in root.rglob('*'):
        if not path.is_file() or not _platform_path(path,root,device_type): continue
        name=path.name.casefold()
        # Root-level device metadata in a mixed extraction describes the
        # Android fixture unless an iOS-specific path explicitly contains it.
        try: rel=path.relative_to(root).as_posix().casefold()
        except ValueError: rel=path.as_posix().casefold()
        root_level='/' not in rel
        if device_type=='ios' and root_level and name in {'device_info.txt','device-info.txt','manifest.json'}:
            continue
        if name in {'device_info.txt','device-info.txt'}:
            values={}
            for line in path.read_text(encoding='utf-8',errors='replace').splitlines():
                if '=' in line: k,v=line.split('=',1); values[k.strip()]=v.strip()
                elif ':' in line: k,v=line.split(':',1); values[k.strip()]=v.strip()
            device.append({'source_file':str(path),'source_sha256':sha256(path),**values})
        elif name=='manifest.json':
            try:
                value=json.loads(path.read_text(encoding='utf-8',errors='strict'))
                manifests.append({'source_file':str(path),'source_sha256':sha256(path),'manifest':value})
            except Exception: pass
    return device,manifests


def parse(root:Path,output_dir:Path,device_type:str)->dict[str,Any]:
    output_dir.mkdir(parents=True,exist_ok=True)
    groups={'sms':[],'calls':[],'contacts':[],'browser':[],'browser_downloads':[],
            'chat':[],'apps':[],'location':[],'device_info':[],'manifests':[]}
    sources=[]
    for db in root.rglob('*'):
        if not db.is_file() or not _is_sqlite(db) or not _platform_path(db,root,device_type): continue
        try: conn=sqlite3.connect(f'file:{db}?mode=ro',uri=True)
        except sqlite3.Error: continue
        try:
            tables=_tables(conn); low={t.lower():t for t in tables}
            if device_type=='android':
                candidates=[
                    ('sms',['_id','thread_id','address','date','date_sent','type','body','read'],'sms'),
                    ('calls',['number','date','duration','type','name'],'calls'),
                    ('contacts',['_id','display_name','name','phone_number','number','email','phone'],'contacts'),
                    ('messages',['id','sender','recipient','timestamp','body','text','date'],'chat'),
                    ('urls',['id','url','title','last_visit_time','visit_count'],'browser'),
                                        ('downloads',['id','current_path','target_path','start_time','end_time','received_bytes','total_bytes','state','opened','last_access_time','url','site_url'],'browser_downloads'),
                ]
            else:
                candidates=[
                    ('message',['ROWID','guid','text','date','handle_id','service','is_from_me'],'sms'),
                    ('zcallrecord',['ZADDRESS','ZDATE','ZDURATION','ZORIGINATED'],'calls'),
                    ('urls',['id','url','title','last_visit_time','visit_count'],'browser'),
                                        ('history_items',['url','title','visit_count','last_visited'],'browser'),
                    ('browser_history',['url','title','date'],'browser'),
                    ('downloads',['id','current_path','target_path','start_time','end_time','received_bytes','total_bytes','state','opened','last_access_time','url','site_url'],'browser_downloads'),
                ]
            for table_l,wanted,group in candidates:
                table=low.get(table_l)
                if table:
                    rows=_read(conn,table,wanted)
                    if rows:
                        for row in rows:
                            row['_source_database']=str(db); row['_source_table']=table
                        groups[group].extend(rows)
                        sources.append({'file':str(db),'sha256':sha256(db),'table':table,'rows':len(rows),'group':group})
        finally: conn.close()
    info_root = root.parent if device_type=='android' and root.name.casefold()=='data' else root
    device,manifests=_read_text_records(info_root,device_type)
    groups['device_info'].extend(device); groups['manifests'].extend(manifests)
    mapping={'sms':'native_sms.csv','calls':'native_calls.csv','contacts':'native_contacts.csv',
             'browser':'native_browser_history.csv','browser_downloads':'native_browser_downloads.csv',
             'chat':'native_chat.csv','apps':'native_installed_apps.csv','location':'native_location.csv',
             'device_info':'native_device_info.json','manifests':'native_extraction_manifests.json'}
    reports={}
    for group,rows in groups.items():
        if not rows: continue
        path=output_dir/mapping[group]
        if path.suffix=='.json': path.write_text(json.dumps(rows,indent=2,ensure_ascii=True),encoding='utf-8')
        else: _write_csv(path,rows)
        reports[group]=str(path)
    manifest=output_dir/'native_mobile_manifest.json'
    manifest.write_text(json.dumps({'device_type':device_type,'reports':reports,'counts':{k:len(v) for k,v in groups.items()},'sources':sources},indent=2),encoding='utf-8')
    return {'reports':reports,'counts':{k:len(v) for k,v in groups.items()},'manifest':str(manifest),'sources':sources}

