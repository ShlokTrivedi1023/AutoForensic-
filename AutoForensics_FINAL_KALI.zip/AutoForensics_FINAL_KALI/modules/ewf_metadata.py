"""Native EWF case/acquisition metadata extraction."""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from core.native_evidence import EvidenceFormatError, is_ewf, parse_ewf
from core.deterministic_validation import deterministic_metadata
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

MODULE_NAME = "ewf_metadata"


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start = utc_now()
    t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    evidence_path = Path(evidence_path).resolve()

    if not evidence_path.is_file():
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
            summary="DID NOT RUN — evidence file not found.",
            errors=[f"Evidence not found: {evidence_path}"],
            class_results=[ClassResult(
                locus=Locus.METADATA, artefact_class="EWF Acquisition Metadata",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE, count=0,
            )],
        )

    if not is_ewf(evidence_path):
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
            summary="DID NOT RUN — not an EWF/E01 evidence container.",
            class_results=[ClassResult(
                locus=Locus.METADATA, artefact_class="EWF Acquisition Metadata",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NOT_APPLICABLE, count=0,
                notes="Raw/non-EWF evidence has no EWF header/header2 metadata.",
            )],
        )

    try:
        info = parse_ewf(evidence_path)
    except EvidenceFormatError as exc:
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
            summary=f"DID NOT RUN — EWF metadata parser failed: {exc}",
            errors=[str(exc)],
            class_results=[ClassResult(
                locus=Locus.METADATA, artefact_class="EWF Acquisition Metadata",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.PARTIAL_FAILURE, count=0,
            )],
        )

    metadata = info.metadata.as_dict()
    populated = {k: v for k, v in metadata.items() if v and k != "raw_values"}
    descriptor_checksums = [
        {
            "segment_path": str(section.segment_path),
            "segment_number": section.segment_number,
            "section_type": section.section_type,
            "descriptor_offset": section.offset,
            "stored_adler32": section.descriptor_checksum_stored,
            "computed_adler32": section.descriptor_checksum_computed,
            "valid": section.descriptor_checksum_valid,
        }
        for section in info.sections
    ]
    descriptor_checksums_valid = sum(1 for item in descriptor_checksums if item["valid"] is True)
    descriptor_checksums_invalid = sum(1 for item in descriptor_checksums if item["valid"] is False)

    manifest_data = {
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "execution_outcome": "ran_found_x" if populated else "ran_found_nothing",
        "evidence_path": str(evidence_path),
        "metadata_source": "native EWF header/header2 parser",
        "ewf_metadata": metadata,
        "embedded_hashes": info.embedded_hashes,
        "descriptor_checksums": descriptor_checksums,
        "descriptor_checksum_summary": {
            "total": len(descriptor_checksums),
            "valid": descriptor_checksums_valid,
            "invalid": descriptor_checksums_invalid,
        },
        "media_geometry": {
            "chunk_count": info.chunk_count,
            "sectors_per_chunk": info.sectors_per_chunk,
            "bytes_per_sector": info.bytes_per_sector,
            "sector_count": info.sector_count,
            "media_size": info.media_size,
        },
        "warnings": info.warnings,
    }
    manifest = output_dir / "ewf_metadata_manifest.json"
    manifest.write_text(json.dumps(manifest_data, indent=2, default=str), encoding="utf-8")

    findings = []
    if populated:
        preferred_fields = (
            "case_number", "evidence_number", "description", "examiner", "notes",
            "acquisition_date", "system_date", "acquisition_platform",
            "password_state", "acquisition_version", "compression",
        )
        rendered = [
            f"{key}={metadata.get(key)}" for key in preferred_fields
            if metadata.get(key) not in (None, "")
        ]
        findings.append(make_finding(
            finding_type="EWF_CASE_METADATA",
            severity=Severity.INFO,
            description=(
                "Native EWF header/header2 metadata recovered separately from the "
                "externally supplied case configuration: " + "; ".join(rendered)
            ),
            evidence_path=str(evidence_path),
            metadata={
                "ewf_metadata": metadata,
                "embedded_hashes": info.embedded_hashes,
                "metadata_source": "header/header2",
                "manifest_path": str(manifest),
                **deterministic_metadata("native EWF header/header2 field parsing", validators=["core.native_evidence.parse_ewf", "retained metadata manifest"]),
            },
            artifact_path=str(manifest),
        ))

    section_chain = [section.section_type for section in info.sections]
    findings.append(make_finding(
        finding_type="EWF_CONTAINER_STRUCTURE",
        severity=Severity.INFO,
        description=(
            f"Classic EWF/E01 container parsed natively across {len(info.segment_paths)} "
            f"segment(s); {info.chunk_count} logical chunk(s), {info.media_size} media "
            f"bytes, {info.bytes_per_sector} bytes/sector, {info.sector_count} sectors. "
            f"Section chain: {' -> '.join(section_chain)}. Descriptor Adler-32 "
            f"checksums valid: {descriptor_checksums_valid}/{len(descriptor_checksums)}. "
            f"Embedded digests present: {', '.join(sorted(info.embedded_hashes)) or 'none'}."
        ),
        evidence_path=str(evidence_path),
        metadata={
            "segment_count": len(info.segment_paths),
            "segment_paths": [str(path) for path in info.segment_paths],
            "section_chain": section_chain,
            "chunk_count": info.chunk_count,
            "media_size": info.media_size,
            "bytes_per_sector": info.bytes_per_sector,
            "sector_count": info.sector_count,
            "embedded_hashes": info.embedded_hashes,
            "descriptor_checksum_summary": manifest_data["descriptor_checksum_summary"],
            "descriptor_checksums": descriptor_checksums,
            "manifest_path": str(manifest),
            **deterministic_metadata("native EWF descriptor/section/chunk structure parsing", validators=["core.native_evidence.parse_ewf", "retained section manifest"]),
        },
        artifact_path=str(manifest),
    ))

    caveat = bool(info.warnings)
    outcome = "RAN WITH CAVEAT" if caveat else (
        f"RAN AND FOUND {len(populated)} populated metadata field(s)" if populated
        else "RAN AND FOUND NOTHING populated in EWF case metadata"
    )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=ModuleStatus.PARTIAL if caveat else ModuleStatus.COMPLETED,
        start_time=start,
        end_time=utc_now(),
        duration_seconds=time.monotonic()-t0,
        findings=findings,
        artifact_paths=[str(manifest)],
        errors=list(info.warnings),
        statistics={
            "metadata_fields_populated": len(populated),
            "embedded_hashes": info.embedded_hashes,
            "descriptor_checksums_total": len(descriptor_checksums),
            "descriptor_checksums_valid": descriptor_checksums_valid,
            "descriptor_checksums_invalid": descriptor_checksums_invalid,
            "execution_outcome": manifest_data["execution_outcome"] if not caveat else "ran_with_caveat",
        },
        summary=f"{outcome}. Metadata is reported alongside, not instead of, case_config.json.",
        class_results=[ClassResult(
            locus=Locus.METADATA,
            artefact_class="EWF Acquisition Metadata",
            verdict=AssuranceVerdict.PRESENT if populated else AssuranceVerdict.VERIFIED_ABSENT,
            count=len(findings),
            notes="; ".join(info.warnings),
        )],
    )
