"""
memory_artifact_extractor.py — Memory Artifact Extraction Module for AutoForensics.

Uses Volatility 3 to extract three classes of in-memory artifacts:

  Registry hives     : windows.registry.hivelist.HiveList — lists loaded hives
  Command-line args  : windows.cmdline.CmdLine — process command lines
  Loaded DLLs        : windows.dlllist.DllList — per-process DLL lists

Suspicious indicators include hives at non-standard paths, encoded PowerShell
commands, and DLLs loaded from outside System32/Program Files.

Target platform : Kali Linux, Python 3.11+
External tools  : python3 /opt/volatility3/vol.py (Volatility 3)
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    assert_subprocess_ok,
    find_memory_source,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "memory_artifact_extractor"
VOL_TIMEOUT: int = 3600

# Standard hive locations — any hive outside these is suspicious
_STANDARD_HIVE_PATHS: tuple[str, ...] = (
    r"\registry\machine\system",
    r"\registry\machine\software",
    r"\registry\machine\sam",
    r"\registry\machine\security",
    r"\systemroot\system32\config",
    r"\registry\user",
    r"\device\harddiskvolume",
)

# Suspicious command-line keywords
_SUSPICIOUS_CMDLINE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"-enc(?:odedcommand)?", re.IGNORECASE),
    re.compile(r"-e\s+[A-Za-z0-9+/]{20,}", re.IGNORECASE),
    re.compile(r"net\s+user\s+", re.IGNORECASE),
    re.compile(r"reg\s+add\s+", re.IGNORECASE),
    re.compile(r"schtasks\s+/create", re.IGNORECASE),
    re.compile(r"wmic\s+", re.IGNORECASE),
    re.compile(r"certutil\s+-decode", re.IGNORECASE),
    re.compile(r"bitsadmin\s+/transfer", re.IGNORECASE),
    re.compile(r"powershell.*bypass", re.IGNORECASE),
    re.compile(r"invoke-expression", re.IGNORECASE),
    re.compile(r"iex\s*\(", re.IGNORECASE),
    re.compile(r"downloadstring", re.IGNORECASE),
    re.compile(r"webclient", re.IGNORECASE),
]

# Standard DLL load locations
_STANDARD_DLL_PATHS: tuple[str, ...] = (
    r"\windows\system32",
    r"\windows\syswow64",
    r"\program files",
    r"\program files (x86)",
    r"\windows\winsxs",
)


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _parse_vol_tsv(output: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    headers: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("Volatility"):
            continue
        parts = stripped.split("\t")
        if not headers:
            headers = [h.strip() for h in parts]
            continue
        if len(parts) < len(headers):
            parts.extend([""] * (len(headers) - len(parts)))
        rows.append(dict(zip(headers, [p.strip() for p in parts])))
    return rows


def _run_vol(vol_path: str, evidence_path: Path, plugin: str,
             logger: logging.Logger) -> tuple[int, str, str]:
    execution = run_volatility_plugin(
        evidence_path=evidence_path, plugin=plugin,
        config={"vol_path": vol_path}, timeout=VOL_TIMEOUT,
    )
    logger.debug("Volatility command: %s", execution.command)
    return execution.returncode, execution.stdout, execution.stderr


def _is_standard_hive(path: str) -> bool:
    pl = path.lower()
    return any(pl.startswith(std) for std in _STANDARD_HIVE_PATHS)


def _is_standard_dll_path(path: str) -> bool:
    pl = path.lower()
    return any(pl.startswith(std) for std in _STANDARD_DLL_PATHS)


def _check_cmdline_suspicious(cmdline: str) -> list[str]:
    """Return list of suspicious pattern descriptions found in cmdline."""
    triggers: list[str] = []
    for pat in _SUSPICIOUS_CMDLINE_PATTERNS:
        if pat.search(cmdline):
            triggers.append(pat.pattern)
    return triggers


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Extract registry hives, command lines, and DLL lists from a memory dump.

    Parameters
    ----------
    evidence_path : Absolute path to the memory dump.
    case_id       : Unique case identifier.
    output_dir    : Directory where reports are written.
    config        : Configuration dict; recognised key:
                    - ``vol_path`` (str): path to vol.py.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with SUSPICIOUS_REGISTRY_HIVE, MALICIOUS_CMDLINE_ARGUMENT,
    and SUSPICIOUS_DLL_LOAD findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    vol_path = config.get("vol_path", "/opt/volatility3/vol.py")

    mem_source = find_memory_source(evidence_path, output_dir, config)
    if mem_source is None:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Memory Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
        )
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            summary="SKIPPED — no memory image supplied for this evidence item (no .raw/.lime/.dmp/.vmem found; no hiberfil.sys/pagefile.sys carved)",
            findings=[],
            errors=[],
            statistics={},
            class_results=[cr],
        )
    # Use mem_source for all Volatility calls
    evidence_path = mem_source

    output_dir.mkdir(parents=True, exist_ok=True)

    stats = {
        "total_hives": 0, "suspicious_hives": 0,
        "total_processes_with_cmdline": 0, "flagged_cmdlines": 0,
        "total_dlls": 0, "suspicious_dlls": 0,
    }

    # ------------------------------------------------------------------
    # Plugin 1: HiveList
    # ------------------------------------------------------------------
    hive_rows: list[dict[str, str]] = []
    hive_txt = output_dir / "registry_hives.txt"
    plugin = "windows.registry.hivelist.HiveList"
    try:
        rc, stdout, stderr = _run_vol(vol_path, evidence_path, plugin, logger)
        hive_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(hive_txt))
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Artefacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                findings=[], statistics={},
                class_results=[cr],
            )
        hive_rows = _parse_vol_tsv(stdout)
        stats["total_hives"] = len(hive_rows)
        for row in hive_rows:
            hive_path = row.get("FileFullPath") or row.get("Name") or ""
            if hive_path and not _is_standard_hive(hive_path):
                stats["suspicious_hives"] += 1
                findings.append(make_finding(
                    finding_type="SUSPICIOUS_REGISTRY_HIVE",
                    severity=Severity.MEDIUM,
                    description=(
                        f"Registry hive loaded from non-standard path: {hive_path}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={"hive_path": hive_path,
                              "offset": row.get("Offset(V)", row.get("Offset", ""))},
                ))
    except FileNotFoundError:
        errors.append(f"Volatility 3 not found at {vol_path}")
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Memory Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=errors, summary=f"Skipped: Volatility 3 not found at {vol_path}",
            class_results=[cr],
        )
    except subprocess.TimeoutExpired:
        errors.append("HiveList timed out")

    # ------------------------------------------------------------------
    # Plugin 2: CmdLine
    # ------------------------------------------------------------------
    cmdline_txt = output_dir / "cmdline_output.txt"
    plugin = "windows.cmdline.CmdLine"
    try:
        rc, stdout, stderr = _run_vol(vol_path, evidence_path, plugin, logger)
        cmdline_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(cmdline_txt))
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Artefacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                findings=findings, statistics=stats,
                class_results=[cr],
            )
        cmdline_rows = _parse_vol_tsv(stdout)
        stats["total_processes_with_cmdline"] = len(cmdline_rows)
        for row in cmdline_rows:
            args = row.get("Args") or row.get("CommandLine") or ""
            proc = row.get("ImageFileName") or row.get("Process") or ""
            pid = row.get("PID") or ""
            if not args:
                continue
            triggers = _check_cmdline_suspicious(args)
            if triggers:
                stats["flagged_cmdlines"] += 1
                findings.append(make_finding(
                    finding_type="MALICIOUS_CMDLINE_ARGUMENT",
                    severity=Severity.HIGH,
                    description=(
                        f"Suspicious command-line argument in process '{proc}' "
                        f"(PID {pid}): matched pattern(s) {triggers}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={
                        "process": proc, "pid": pid,
                        "cmdline": args[:500],
                        "matched_patterns": triggers,
                    },
                ))
    except subprocess.TimeoutExpired:
        errors.append("CmdLine timed out")

    # ------------------------------------------------------------------
    # Plugin 3: DllList
    # ------------------------------------------------------------------
    dll_txt = output_dir / "dll_list.txt"
    plugin = "windows.dlllist.DllList"
    try:
        rc, stdout, stderr = _run_vol(vol_path, evidence_path, plugin, logger)
        dll_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(dll_txt))
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Artefacts",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                findings=findings, statistics=stats,
                class_results=[cr],
            )
        dll_rows = _parse_vol_tsv(stdout)
        stats["total_dlls"] = len(dll_rows)
        for row in dll_rows:
            dll_path = row.get("FullDllName") or row.get("Path") or ""
            proc = row.get("ImageFileName") or row.get("Process") or ""
            pid = row.get("PID") or ""
            if not dll_path:
                # DLL with no path — common with process hollowing
                stats["suspicious_dlls"] += 1
                findings.append(make_finding(
                    finding_type="SUSPICIOUS_DLL_LOAD",
                    severity=Severity.MEDIUM,
                    description=(
                        f"DLL with no path loaded in '{proc}' (PID {pid}) — "
                        f"possible process hollowing or reflective DLL injection."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={"process": proc, "pid": pid, "dll_path": ""},
                ))
                continue
            if not _is_standard_dll_path(dll_path):
                stats["suspicious_dlls"] += 1
                findings.append(make_finding(
                    finding_type="SUSPICIOUS_DLL_LOAD",
                    severity=Severity.MEDIUM,
                    description=(
                        f"DLL loaded from non-standard path in '{proc}' (PID {pid}): "
                        f"{dll_path}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={"process": proc, "pid": pid, "dll_path": dll_path},
                ))
    except subprocess.TimeoutExpired:
        errors.append("DllList timed out")

    # Write JSON summary
    summary_path = output_dir / "memory_artifacts.json"
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "hives": hive_rows,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(summary_path))
    except OSError as exc:
        errors.append(f"Failed to write memory_artifacts.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Extracted {stats['total_hives']} hives, {stats['total_processes_with_cmdline']} "
        f"cmdlines, {stats['total_dlls']} DLLs; {len(findings)} findings."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.MEMORY,
        artefact_class="Memory Artefacts",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
        class_results=[cr],
    )
