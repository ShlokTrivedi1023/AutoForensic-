"""
pcap_analyzer.py — PCAP Network Traffic Analyzer for AutoForensics.

Uses ``tshark`` to analyse packet capture files found in the output directory.
Produces conversation summaries, protocol hierarchy statistics, and suspicious
connection findings.

Target platform : Kali Linux, Python 3.11+
External tools  : tshark (wireshark-common package)
"""

from __future__ import annotations

import csv
import json
import logging
import re
import subprocess
from io import StringIO
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "pcap_analyzer"
TSHARK_TIMEOUT: int = 3600

# Known C2 and backdoor ports
_C2_PORTS: frozenset[int] = frozenset({
    4444, 4445, 4446, 1337, 31337,
    8888, 9999, 6666, 7777, 12345, 54321,
    1604, 65535, 65000, 6660, 6661, 6662, 6663,
})

# Cleartext protocols by port
_CLEARTEXT_PORTS: dict[int, str] = {
    21: "FTP", 23: "Telnet", 25: "SMTP",
    80: "HTTP", 110: "POP3", 143: "IMAP",
    69: "TFTP", 161: "SNMP",
}

# Exfil threshold: > 50 MB to a single external IP
EXFIL_BYTES_THRESHOLD: int = 50 * 1024 * 1024


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _find_pcap_files(output_dir: Path, config: dict[str, Any]) -> list[Path]:
    """
    Locate PCAP/PCAPNG files from output_dir or explicit config path.

    Parameters
    ----------
    output_dir : Directory to search recursively.
    config     : May contain 'pcap_path' key.

    Returns
    -------
    List of Path objects for all PCAP files found.
    """
    files: list[Path] = []
    for pat in ("*.pcap", "*.pcapng", "*.cap"):
        files.extend(output_dir.rglob(pat))
    explicit = config.get("pcap_path", "")
    if explicit:
        p = Path(explicit)
        if p.is_file() and p not in files:
            files.append(p)
    for value in config.get("pcap_paths") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    ws = config.get("_working_set") or {}
    for value in ws.get("nested_network_sources") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    # Canonicalise and de-duplicate without assuming filenames.
    unique: list[Path] = []
    seen: set[str] = set()
    for p in files:
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _tshark_fields(
    pcap: Path,
    fields: list[str],
    display_filter: str,
    logger: logging.Logger,
) -> list[dict[str, str]]:
    """
    Run tshark with -T fields to extract specific packet fields as CSV.

    Parameters
    ----------
    pcap           : Path to PCAP file.
    fields         : List of tshark field names.
    display_filter : Wireshark display filter string (may be empty).
    logger         : Module logger.

    Returns
    -------
    List of dicts, one per packet, keyed by field name.
    """
    cmd = ["tshark", "-r", str(pcap), "-T", "fields",
           "-E", "header=y", "-E", "separator=,", "-E", "quote=d",
           "-E", "occurrence=f"]
    for field in fields:
        cmd += ["-e", field]
    if display_filter:
        cmd += ["-Y", display_filter]

    try:
        rc, stdout, _ = _run_subprocess(cmd, timeout=TSHARK_TIMEOUT, logger=logger)
        if not stdout.strip():
            return []
        reader = csv.DictReader(StringIO(stdout))
        return [row for row in reader]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _tshark_stats(pcap: Path, stat: str, logger: logging.Logger) -> str:
    """
    Run tshark -q -z <stat> and return raw stdout.

    Parameters
    ----------
    pcap   : Path to PCAP file.
    stat   : Statistics expression (e.g. 'conv,tcp').
    logger : Module logger.

    Returns
    -------
    Raw stdout string from tshark.
    """
    try:
        _, stdout, _ = _run_subprocess(
            ["tshark", "-r", str(pcap), "-q", "-z", stat],
            timeout=TSHARK_TIMEOUT, logger=logger,
        )
        return stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def _parse_conv_bytes(conv_output: str) -> list[dict[str, Any]]:
    """
    Parse tshark conversation statistics output into structured records.

    Parameters
    ----------
    conv_output : Raw output from ``tshark -z conv,tcp`` or ``-z conv,udp``.

    Returns
    -------
    List of dicts with keys: src, dst, packets, bytes_total.
    """
    records: list[dict[str, Any]] = []
    # Table rows look like: "192.168.1.1:1234 <-> 10.0.0.1:80   50   100  ..."
    pattern = re.compile(
        r"([\d.]+):(\d+)\s+<->\s+([\d.]+):(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)"
    )
    for line in conv_output.splitlines():
        m = pattern.search(line)
        if m:
            records.append({
                "src_ip": m.group(1), "src_port": int(m.group(2)),
                "dst_ip": m.group(3), "dst_port": int(m.group(4)),
                "frames_src_dst": int(m.group(5)), "bytes_src_dst": int(m.group(6)),
                "frames_dst_src": int(m.group(7)), "bytes_dst_src": int(m.group(8)),
                "bytes_total": int(m.group(6)) + int(m.group(8)),
            })
    return records


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Analyse PCAP files found in output_dir for suspicious network activity.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory to search for .pcap/.pcapng files.
    config        : Configuration dict; recognised keys:
                    - ``pcap_path`` (str): explicit PCAP file path.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with network analysis findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    pcap_files = _find_pcap_files(output_dir, config)
    if not pcap_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.NETWORK,
            artefact_class="PCAP Network Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
            notes="No PCAP files found in output directory.",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no PCAP files found.",
            class_results=[cr],
        )

    logger.info("[%s] Found %d PCAP file(s)", MODULE_NAME, len(pcap_files))

    total_packets = 0
    total_bytes = 0
    unique_ips: set[str] = set()
    all_conversations: list[dict[str, Any]] = []
    pcap_summaries: list[dict[str, Any]] = []
    packet_audit_records: list[dict[str, Any]] = []

    for pcap in pcap_files:
        logger.info("[%s] Analysing: %s", MODULE_NAME, pcap.name)

        # Get packet fields
        packets = _tshark_fields(
            pcap,
            ["frame.number", "ip.src", "ip.dst", "tcp.srcport", "tcp.dstport",
             "udp.srcport", "udp.dstport", "frame.len"],
            "",
            logger,
        )
        pcap_sha256 = __import__("hashlib").sha256(pcap.read_bytes()).hexdigest() if packets else ""
        for pkt in packets:
            total_packets += 1
            packet_audit_records.append({"pcap_file": str(pcap), "pcap_sha256": pcap_sha256, **pkt})
            try:
                total_bytes += int(pkt.get("frame.len") or 0)
            except ValueError:
                pass
            for field in ("ip.src", "ip.dst"):
                ip = pkt.get(field, "")
                if ip:
                    unique_ips.add(ip)

        # Deterministic capture-level finding: exact packet records decoded by
        # tshark from this retained capture. This reports what is present without
        # inferring C2, exfiltration or maliciousness.
        if packets:
            findings.append(make_finding(
                finding_type="PCAP_CAPTURE", severity=Severity.INFO,
                description=f"Decoded {len(packets)} packet record(s) from retained capture {pcap.name}.",
                evidence_path=str(pcap), artifact_path=str(pcap),
                metadata={**deterministic_metadata(
                    "packet-capture magic plus tshark field decoding",
                    validators=["pcap/pcapng parser", "tshark"],
                ), "pcap_file": str(pcap), "pcap_sha256": pcap_sha256,
                   "packet_count": len(packets),
                   "packet_records_artifact": str(output_dir / "packet_records.jsonl"),
                   "packet_records_sample": packets[:200]},
            ))

        # TCP conversations
        tcp_conv_raw = _tshark_stats(pcap, "conv,tcp", logger)
        tcp_convs = _parse_conv_bytes(tcp_conv_raw)
        all_conversations.extend(tcp_convs)

        # UDP conversations
        udp_conv_raw = _tshark_stats(pcap, "conv,udp", logger)
        udp_convs = _parse_conv_bytes(udp_conv_raw)
        all_conversations.extend(udp_convs)

        # Check for suspicious conversations
        for conv in tcp_convs + udp_convs:
            dst_port = conv.get("dst_port", 0)
            src_port = conv.get("src_port", 0)
            dst_ip = conv.get("dst_ip", "")

            # C2 port
            for port in (dst_port, src_port):
                if port in _C2_PORTS:
                    findings.append(make_finding(
                        finding_type="C2_PORT_DETECTED",
                        severity=Severity.HIGH,
                        description=(
                            f"Traffic on known C2/backdoor port {port} in {pcap.name}: "
                            f"{conv['src_ip']}:{conv['src_port']} ↔ "
                            f"{conv['dst_ip']}:{conv['dst_port']}"
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**candidate_metadata("known-port list", reason="Port number alone does not prove C2"), **conv, "pcap_file": pcap.name, "suspicious_port": port},
                    ))

            # Cleartext protocol
            if dst_port in _CLEARTEXT_PORTS:
                findings.append(make_finding(
                    finding_type="CLEARTEXT_PROTOCOL",
                    severity=Severity.MEDIUM,
                    description=(
                        f"Cleartext {_CLEARTEXT_PORTS[dst_port]} traffic detected in {pcap.name}: "
                        f"{conv['src_ip']} → {dst_ip}:{dst_port}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={**candidate_metadata("port-to-protocol mapping", reason="Port use alone does not prove application protocol or credential exposure"), **conv, "pcap_file": pcap.name,
                               "protocol": _CLEARTEXT_PORTS[dst_port]},
                ))

            # Large data exfiltration
            if conv.get("bytes_total", 0) > EXFIL_BYTES_THRESHOLD:
                findings.append(make_finding(
                    finding_type="LARGE_DATA_EXFILTRATION",
                    severity=Severity.HIGH,
                    description=(
                        f"Large data transfer ({conv['bytes_total'] / 1024 / 1024:.1f} MB) "
                        f"to {dst_ip}:{dst_port} in {pcap.name}."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={**candidate_metadata("byte-volume threshold", reason="Large transfer size alone does not prove exfiltration"), **conv, "pcap_file": pcap.name},
                ))

        pcap_summaries.append({
            "file": pcap.name,
            "tcp_conversations": len(tcp_convs),
            "udp_conversations": len(udp_convs),
        })

    # Write the complete decoded packet ledger before the summary.
    packet_ledger_path = output_dir / "packet_records.jsonl"
    try:
        with packet_ledger_path.open("w", encoding="utf-8") as fh:
            for row in packet_audit_records:
                fh.write(json.dumps(row, ensure_ascii=True, sort_keys=True) + "\n")
        artifact_paths.append(str(packet_ledger_path))
    except OSError as exc:
        errors.append(f"Failed to write packet_records.jsonl: {exc}")

    # Write report
    report_path = output_dir / "pcap_summary.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(),
                "pcaps_analyzed": len(pcap_files),
                "total_packets": total_packets,
                "total_bytes": total_bytes,
                "unique_ips": len(unique_ips),
                "pcap_summaries": pcap_summaries,
                "conversations": all_conversations,
                "packet_records_artifact": str(packet_ledger_path),
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write pcap_summary.json: {exc}")

    # Write conversations CSV
    conv_path = output_dir / "conversations.csv"
    try:
        with open(conv_path, "w", newline="", encoding="utf-8") as f:
            if all_conversations:
                writer = csv.DictWriter(f, fieldnames=list(all_conversations[0].keys()))
                writer.writeheader()
                writer.writerows(all_conversations)
        artifact_paths.append(str(conv_path))
    except OSError as exc:
        errors.append(f"Failed to write conversations.csv: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Analysed {len(pcap_files)} PCAP file(s); {total_packets} packets, "
        f"{len(unique_ips)} unique IPs; {len(findings)} findings."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.NETWORK,
        artefact_class="PCAP Network Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            "total_pcaps_analyzed": len(pcap_files),
            "total_packets": total_packets,
            "total_bytes": total_bytes,
            "unique_ips": len(unique_ips),
            "suspicious_conversations": len(findings),
        },
        summary=summary,
        class_results=[cr],
    )
