"""
hash_database_match.py — Hash Database Matching Module for AutoForensics.

Computes SHA-256 of every file in the output directory and compares the digests
against two reference databases:

  NSRL (National Software Reference Library)
      Maintained by NIST, the NSRL contains hashes of known-good software files.
      A match in the NSRL means the file is a known legitimate software component,
      which helps analysts exclude noise and focus on novel or suspicious files.

  Custom IOC hash list
      A newline-separated list of SHA-256 hashes of known malicious files supplied
      by the analyst or threat-intelligence feed.  A match here is a HIGH-severity
      finding indicating known malware.

Both databases are optional.  When neither is configured the module still produces
a complete hash manifest of all files, which is valuable as a standalone artifact.

Target platform : Kali Linux, Python 3.11+
External tools  : none (pure Python via hashlib)
Optional deps   : sqlite3 (stdlib), csv (stdlib)
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    Severity,
    SkipReason,
    make_finding,
    utc_now,
)
from core.deterministic_validation import deterministic_metadata

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "hash_database_match"
HASH_CHUNK_SIZE: int = 65536   # 64 KB streaming read chunks
MAX_FILE_SIZE_BYTES: int = 0   # zero = exhaustive; positive values are explicit resource caps


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    """
    Emit a chain-of-custody event silently.

    Parameters
    ----------
    coc_logger : CustodyLogger or None.
    event      : Event name string.
    details    : Structured key-value context.
    """
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _sha256_file(file_path: Path) -> Optional[str]:
    """
    Compute the SHA-256 digest of a file using streaming reads.

    Streaming avoids loading large files entirely into memory.

    Parameters
    ----------
    file_path : Path to the file to hash.

    Returns
    -------
    Lowercase hex-encoded SHA-256 digest, or None if the file cannot be read.
    """
    h = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(HASH_CHUNK_SIZE)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _load_nsrl_sqlite(db_path: Path, logger: logging.Logger) -> Optional[sqlite3.Connection]:
    """
    Open the NSRL SQLite database in read-only mode.

    Parameters
    ----------
    db_path : Path to the NSRL SQLite file.
    logger  : Module logger.

    Returns
    -------
    sqlite3.Connection in read-only URI mode, or None on failure.
    """
    try:
        uri = f"file:{db_path}?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as exc:
        logger.error("[%s] Cannot open NSRL SQLite: %s", MODULE_NAME, exc)
        return None


def _load_nsrl_csv(db_path: Path, logger: logging.Logger) -> dict[str, dict[str, str]]:
    """
    Load NSRL CSV into an in-memory dict keyed by lowercase SHA-256.

    Parameters
    ----------
    db_path : Path to the NSRL CSV file.
    logger  : Module logger.

    Returns
    -------
    Dict mapping sha256 → {name, os, product}.
    """
    data: dict[str, dict[str, str]] = {}
    try:
        with open(db_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                sha = (row.get("SHA-256") or row.get("sha256") or "").strip().lower()
                if sha:
                    data[sha] = {
                        "name": row.get("FileName") or row.get("name") or "",
                        "os": row.get("OpSystemCode") or row.get("os") or "",
                        "product": row.get("ProductCode") or row.get("product") or "",
                    }
        logger.info("[%s] Loaded %d NSRL CSV entries", MODULE_NAME, len(data))
    except OSError as exc:
        logger.error("[%s] Cannot read NSRL CSV: %s", MODULE_NAME, exc)
    return data


def _lookup_nsrl_sqlite(
    conn: sqlite3.Connection,
    sha256: str,
) -> Optional[dict[str, str]]:
    """
    Look up a SHA-256 hash in the NSRL SQLite database.

    Parameters
    ----------
    conn   : Open SQLite connection.
    sha256 : Lowercase hex SHA-256 to look up.

    Returns
    -------
    Dict with name/os/product keys if found, else None.
    """
    for table in ("FILE", "NSRLFile", "file"):
        try:
            cur = conn.execute(
                f"SELECT FileName, OpSystemCode, ProductCode "  # noqa: S608
                f"FROM {table} WHERE SHA256=? LIMIT 1",
                (sha256.upper(),),
            )
            row = cur.fetchone()
            if row:
                return {"name": row[0] or "", "os": row[1] or "", "product": str(row[2] or "")}
        except sqlite3.Error:
            continue
    return None


def _load_reference_hashes(hash_path: Path, logger: logging.Logger) -> dict[str, dict[str, str]]:
    """Parse common MD5/SHA-1/SHA-256/SHA-512 reference-list formats.

    Accepted examples include ``HASH``, ``HASH  label``, ``HASH,label``,
    ``HASH:label`` and ``label:HASH``.  The parser is intentionally format
    tolerant but digest strict: only complete hexadecimal digests of a known
    length are accepted.
    """
    records: dict[str, dict[str, str]] = {}
    digest_re = re.compile(r"(?i)(?<![0-9a-f])([0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{64}|[0-9a-f]{128})(?![0-9a-f])")
    try:
        for line_no, raw in enumerate(hash_path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            match = digest_re.search(line)
            if not match:
                continue
            digest = match.group(1).lower()
            label = (line[:match.start()] + " " + line[match.end():]).strip(" 	,:;|-")
            algorithm = {32: "md5", 40: "sha1", 64: "sha256", 128: "sha512"}[len(digest)]
            records[digest] = {
                "algorithm": algorithm,
                "label": label,
                "source": str(hash_path),
                "line_number": str(line_no),
            }
        logger.info("[%s] Loaded %d reference hashes from %s", MODULE_NAME, len(records), hash_path)
    except OSError as exc:
        logger.error("[%s] Cannot read hash reference file: %s", MODULE_NAME, exc)
    return records


def _load_ioc_hashes(ioc_path: Path, logger: logging.Logger) -> set[str]:
    """Compatibility wrapper returning SHA-256 entries from a reference file."""
    return {
        digest for digest, meta in _load_reference_hashes(ioc_path, logger).items()
        if meta.get("algorithm") == "sha256"
    }


def _collect_files(scan_dir: Path) -> list[Path]:
    """
    Recursively enumerate all regular files under scan_dir.

    Parameters
    ----------
    scan_dir : Root directory to walk.

    Returns
    -------
    List of Path objects for all regular (non-symlink) files.
    """
    files: list[Path] = []
    try:
        for item in scan_dir.rglob("*"):
            if item.is_file() and not item.is_symlink():
                files.append(item)
    except PermissionError:
        pass
    return files


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Hash every file in output_dir and match against NSRL and IOC databases.

    Parameters
    ----------
    evidence_path  : Path to the forensic image (recorded in findings).
    case_id        : Unique case identifier.
    output_dir     : Directory to scan; typically contains files extracted by
                     earlier modules.
    config         : Configuration dict; recognised keys:
                     - ``nsrl_db_path`` (str): path to NSRL SQLite or CSV.
                     - ``ioc_hash_file`` (str): path to newline-separated SHA-256 list.
                     - ``hash_output_file`` (bool): write hash manifest (default True).
    logger         : Standard Python logger.
    coc_logger     : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult containing NSRL_MATCH and IOC_HASH_MATCH findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run.
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    hash_scan_dir = str(_corpus_roots[0]) if _corpus_roots else None
    if not _corpus_roots:
        _cr_skip = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Hash Database Matches",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id,
            status=ModuleStatus.SKIPPED,
            summary="SKIPPED — no recovered/carved corpus was available to examine",
            findings=[], errors=[], statistics={},
            class_results=[_cr_skip],
        )

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    # ------------------------------------------------------------------
    # Load reference databases
    # ------------------------------------------------------------------
    nsrl_conn: Optional[sqlite3.Connection] = None
    nsrl_csv_data: dict[str, dict[str, str]] = {}
    ioc_hashes: set[str] = set()
    configured_hashes: set[str] = set()
    configured_hash_records: dict[str, dict[str, str]] = {}
    configured_hash_sources: list[str] = []
    configured_hash_parse_failures: list[str] = []

    nsrl_path_str = config.get("nsrl_db_path", "")
    if nsrl_path_str:
        nsrl_path = Path(nsrl_path_str)
        if nsrl_path.exists():
            if nsrl_path.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
                nsrl_conn = _load_nsrl_sqlite(nsrl_path, logger)
                if nsrl_conn:
                    logger.info("[%s] NSRL SQLite loaded: %s", MODULE_NAME, nsrl_path)
            elif nsrl_path.suffix.lower() in (".csv", ".txt"):
                nsrl_csv_data = _load_nsrl_csv(nsrl_path, logger)
            else:
                logger.warning("[%s] Unrecognised NSRL format: %s", MODULE_NAME, nsrl_path)
        else:
            errors.append(f"NSRL database not found: {nsrl_path}")

    ioc_path_str = config.get("ioc_hash_file", "")
    if ioc_path_str:
        ioc_path = Path(ioc_path_str)
        if ioc_path.exists():
            ioc_hashes = _load_ioc_hashes(ioc_path, logger)
        else:
            errors.append(f"IOC hash file not found: {ioc_path}")

    # Evidence-contained or investigator-supplied validation hash lists are
    # semantically neutral. A match proves equality to a configured reference;
    # it does not prove malware unless the analyst explicitly supplied it as an
    # IOC list through ``ioc_hash_file``.
    _hash_sources = []
    for value in config.get("evidence_hash_list_sources") or []:
        _hash_sources.append(Path(str(value)))
    for value in (config.get("_working_set") or {}).get("evidence_hash_list_sources") or []:
        _hash_sources.append(Path(str(value)))
    _seen_source_paths: set[str] = set()
    for source in _hash_sources:
        try:
            key = str(source.resolve())
        except OSError:
            key = str(source)
        if key in _seen_source_paths or not source.is_file():
            continue
        _seen_source_paths.add(key)
        loaded_records = _load_reference_hashes(source, logger)
        loaded = {digest for digest, meta in loaded_records.items() if meta.get("algorithm") == "sha256"}
        if loaded:
            configured_hashes.update(loaded)
            configured_hash_records.update({digest: loaded_records[digest] for digest in loaded})
            configured_hash_sources.append(str(source))
        else:
            configured_hash_parse_failures.append(str(source))

    write_manifest = config.get("hash_output_file", True)

    # ------------------------------------------------------------------
    # Hash all files
    # ------------------------------------------------------------------
    files = [f for _r in _corpus_roots for f in _collect_files(_r)]
    logger.info("[%s] Hashing %d files", MODULE_NAME, len(files))
    max_file_size_bytes = int(
        config.get("hash_database_max_file_size_bytes", MAX_FILE_SIZE_BYTES) or 0
    )
    size_limit_reached = False

    total_bytes = 0
    nsrl_matches = 0
    ioc_matches = 0
    manifest_records: list[dict[str, Any]] = []

    for file_path in files:
        try:
            file_size = file_path.stat().st_size
        except OSError:
            file_size = 0

        if max_file_size_bytes > 0 and file_size > max_file_size_bytes:
            size_limit_reached = True
            logger.warning(
                "[%s] Explicit hash-size cap prevented hashing: %s (%d bytes)",
                MODULE_NAME, file_path, file_size,
            )
            errors.append(
                f"Explicit hash_database_max_file_size_bytes={max_file_size_bytes} "
                f"prevented hashing {file_path} ({file_size} bytes); coverage is partial."
            )
            manifest_records.append({
                "path": str(file_path),
                "size_bytes": file_size,
                "sha256": None,
                "hash_status": "UNRESOLVED_RESOURCE_LIMIT",
                "nsrl_match": None,
                "ioc_match": False,
                "configured_hash_match": False,
            })
            continue

        sha256 = _sha256_file(file_path)
        if sha256 is None:
            errors.append(f"Could not hash: {file_path}")
            continue

        total_bytes += file_size
        record: dict[str, Any] = {
            "path": str(file_path),
            "size_bytes": file_size,
            "sha256": sha256,
            "nsrl_match": None,
            "ioc_match": False,
            "configured_hash_match": False,
        }

        # NSRL lookup
        nsrl_info: Optional[dict[str, str]] = None
        if nsrl_conn:
            nsrl_info = _lookup_nsrl_sqlite(nsrl_conn, sha256)
        elif nsrl_csv_data:
            nsrl_info = nsrl_csv_data.get(sha256)

        if nsrl_info:
            nsrl_matches += 1
            record["nsrl_match"] = nsrl_info
            findings.append(make_finding(
                finding_type="NSRL_MATCH",
                severity=Severity.INFO,
                description=(
                    f"File is a known NSRL entry: {nsrl_info.get('name', 'unknown')} "
                    f"(product: {nsrl_info.get('product', 'unknown')}). "
                    f"SHA-256: {sha256[:16]}…"
                ),
                evidence_path=str(evidence_path),
                metadata={
                    **deterministic_metadata("exact SHA-256 equality against read-only NSRL reference"),
                    "file_path": str(file_path),
                    "sha256": sha256,
                    "nsrl_name": nsrl_info.get("name", ""),
                    "nsrl_os": nsrl_info.get("os", ""),
                    "nsrl_product": nsrl_info.get("product", ""),
                },
            ))

        # IOC match
        if sha256 in ioc_hashes:
            ioc_matches += 1
            record["ioc_match"] = True
            findings.append(make_finding(
                finding_type="IOC_HASH_MATCH",
                severity=Severity.HIGH,
                description=(
                    f"File matches known-malicious IOC hash list. "
                    f"File: {file_path.name} — SHA-256: {sha256}"
                ),
                evidence_path=str(evidence_path),
                metadata={
                    **deterministic_metadata("exact SHA-256 equality against investigator-supplied IOC list"),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "sha256": sha256,
                    "size_bytes": file_size,
                },
            ))
            logger.warning("[%s] IOC MATCH: %s (%s)", MODULE_NAME, file_path.name, sha256[:16])

        if sha256 in configured_hashes:
            record["configured_hash_match"] = True
            findings.append(make_finding(
                finding_type="CONFIGURED_HASH_MATCH",
                severity=Severity.INFO,
                description=(
                    f"File SHA-256 exactly matches a configured reference hash. "
                    f"File: {file_path.name} — SHA-256: {sha256}"
                ),
                evidence_path=str(file_path),
                metadata={
                    **deterministic_metadata("exact SHA-256 equality against evidence/investigator reference list"),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "sha256": sha256,
                    "size_bytes": file_size,
                    "reference_sources": configured_hash_sources,
                    "reference_record": configured_hash_records.get(sha256, {}),
                    "semantic_scope": "configured reference match; no malware attribution",
                },
            ))

        manifest_records.append(record)

    # Close NSRL connection
    if nsrl_conn:
        try:
            nsrl_conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Write hash manifest
    # ------------------------------------------------------------------
    if write_manifest:
        manifest_path = output_dir / "hash_manifest.json"
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            with open(manifest_path, "w", encoding="utf-8") as f:
                json.dump({
                    "module": MODULE_NAME,
                    "case_id": case_id,
                    "generated_at": utc_now(),
                    "files_discovered": len(files),
                    "files_accounted": len(manifest_records),
                    "files_hashed": sum(1 for record in manifest_records if record.get("sha256")),
                    "total_bytes_hashed": total_bytes,
                    "explicit_size_limit_bytes": max_file_size_bytes,
                    "size_limit_reached": size_limit_reached,
                    "nsrl_matches": nsrl_matches,
                    "ioc_matches": ioc_matches,
                    "files": manifest_records,
                }, f, indent=2, ensure_ascii=True)
            artifact_paths.append(str(manifest_path))
        except OSError as exc:
            errors.append(f"Failed to write hash manifest: {exc}")

    end_time = utc_now()
    from datetime import datetime, timezone
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED
    if errors and not manifest_records:
        status = ModuleStatus.FAILED
    elif errors:
        status = ModuleStatus.PARTIAL

    summary = (
        f"Hashed {sum(1 for record in manifest_records if record.get('sha256'))}/{len(files)} discovered files "
        f"({total_bytes / 1024 / 1024:.1f} MB); "
        f"{nsrl_matches} NSRL matches, {ioc_matches} IOC matches, "
        f"{sum(1 for r in manifest_records if r.get('configured_hash_match'))} configured-reference matches."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED" if status != ModuleStatus.FAILED else "MODULE_FAILED",
             {"module": MODULE_NAME, "case_id": case_id, "ioc_matches": ioc_matches,
              "nsrl_matches": nsrl_matches})

    _reference_applied = bool(nsrl_conn or nsrl_csv_data or ioc_hashes or configured_hashes)
    _cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Hash Database Matches",
        verdict=(
            AssuranceVerdict.PRESENT if findings else
            AssuranceVerdict.VERIFIED_ABSENT if _reference_applied and status == ModuleStatus.COMPLETED else
            AssuranceVerdict.INDETERMINATE
        ),
        skip_reason=(None if findings or (_reference_applied and status == ModuleStatus.COMPLETED) else SkipReason.NO_CORPUS),
        count=len(findings),
        notes=("Exact hash comparison applied." if _reference_applied else "No hash reference database/list was available; only the manifest was generated."),
    )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics={
            "files_discovered": len(files),
            "files_accounted": len(manifest_records),
            "files_hashed": sum(1 for record in manifest_records if record.get("sha256")),
            "unresolved_supported_objects": sum(1 for record in manifest_records if not record.get("sha256")),
            "explicit_size_limit_bytes": max_file_size_bytes,
            "size_limit_reached": size_limit_reached,
            "nsrl_matches": nsrl_matches,
            "ioc_matches": ioc_matches,
            "total_bytes_hashed": total_bytes,
            "configured_hashes_loaded": len(configured_hashes),
            "configured_hash_sources": configured_hash_sources,
            "configured_hash_matches": sum(1 for r in manifest_records if r.get("configured_hash_match")),
        },
        summary=summary,
        class_results=[_cr],
    )
