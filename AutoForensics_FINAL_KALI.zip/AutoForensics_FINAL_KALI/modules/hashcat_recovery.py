"""
hashcat_recovery.py — Hashcat Password Recovery Module for AutoForensics.

Scans all JSON output files in output_dir for extracted hash strings, then runs
``hashcat`` with a wordlist attack to recover plaintext passwords.

Hash type auto-detection:
  - 32 hex chars  → MD5 (mode 0)
  - 40 hex chars  → SHA-1 (mode 100)
  - 56 hex chars  → SHA-224 (mode 1300)
  - 64 hex chars  → SHA-256 (mode 1400)
  - 96 hex chars  → SHA-384 (mode 10800)
  - 128 hex chars → SHA-512 (mode 1700)
  - NTLM format   → mode 1000
  - bcrypt $2*$   → mode 3200
  - md5crypt $1$  → mode 500
  - sha512crypt $6$ → mode 1800

Results are parsed from the hashcat .potfile.  Cross-referenced with any
john_recovery potfile to avoid duplicate reporting.

Target platform : Kali Linux, Python 3.11+
External tools  : hashcat
"""

from __future__ import annotations

import json
import hashlib
import logging
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    safe_xml_fromstring,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False

try:
    from modules.john_recovery import _emit_document_content
except ImportError:
    def _emit_document_content(file_path, password, findings, logger):  # type: ignore[misc]
        pass
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "hashcat_recovery"
HASHCAT_TIMEOUT: int = 3600   # 1 hour per hash type batch

_DEFAULT_WORDLIST: str = "/usr/share/wordlists/rockyou.txt"

# Hash patterns for type detection
_RE_HEX_32 = re.compile(r"^[0-9a-fA-F]{32}$")
_RE_HEX_40 = re.compile(r"^[0-9a-fA-F]{40}$")
_RE_HEX_56 = re.compile(r"^[0-9a-fA-F]{56}$")
_RE_HEX_64 = re.compile(r"^[0-9a-fA-F]{64}$")
_RE_HEX_96 = re.compile(r"^[0-9a-fA-F]{96}$")
_RE_HEX_128 = re.compile(r"^[0-9a-fA-F]{128}$")
_RE_NTLM = re.compile(r"^[0-9a-fA-F]{32}$")   # same as MD5 — differentiated by source field
_RE_BCRYPT = re.compile(r"^\$2[abxy]\$\d{2}\$.{53}$")
_RE_MD5CRYPT = re.compile(r"^\$1\$.{1,8}\$.{22}$")
_RE_SHA512CRYPT = re.compile(r"^\$6\$.{1,16}\$.{86}$")

# Map hashcat mode → human name
_MODE_NAMES: dict[int, str] = {
    0: "MD5", 100: "SHA-1", 1300: "SHA-224", 1400: "SHA-256",
    10800: "SHA-384", 1700: "SHA-512", 1000: "NTLM",
    3200: "bcrypt", 500: "md5crypt", 1800: "sha512crypt",
}


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _detect_hash_mode(h: str) -> Optional[int]:
    """
    Detect hashcat mode from hash string format.

    Parameters
    ----------
    h : Hash string.

    Returns
    -------
    Hashcat mode integer, or None if unrecognised.
    """
    h = h.strip()
    if _RE_SHA512CRYPT.match(h):
        return 1800
    if _RE_MD5CRYPT.match(h):
        return 500
    if _RE_BCRYPT.match(h):
        return 3200
    if _RE_HEX_128.match(h):
        return 1700
    if _RE_HEX_96.match(h):
        return 10800
    if _RE_HEX_64.match(h):
        return 1400
    if _RE_HEX_56.match(h):
        return 1300
    if _RE_HEX_40.match(h):
        return 100
    if _RE_HEX_32.match(h):
        return 0
    return None


def _collect_hashes_from_json(scan_dirs: list[Path]) -> list[tuple[str, str]]:
    """
    Scan all JSON files in scan_dirs for hash-like strings.

    Parameters
    ----------
    scan_dirs : Directories to scan (module output dir + artifact/recovery dirs).

    Returns
    -------
    List of (source_file, hash_string) tuples.
    """
    found: list[tuple[str, str]] = []
    hash_re = re.compile(
        r"(?:"
        r"\$[126]\$[^\s'\"]{20,}"    # Unix crypt formats
        r"|\$2[abxy]\$\d{2}\$[^\s'\"]{53}"   # bcrypt
        r"|[0-9a-fA-F]{32,128}"      # hex hashes
        r")"
    )
    for scan_dir in scan_dirs:
        if not scan_dir.is_dir():
            continue
        for jf in scan_dir.rglob("*.json"):
            try:
                text = jf.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for m in hash_re.finditer(text):
                h = m.group()
                if _detect_hash_mode(h) is not None:
                    found.append((str(jf), h))
    # Deduplicate by hash value
    seen: set[str] = set()
    unique: list[tuple[str, str]] = []
    for src, h in found:
        if h not in seen:
            seen.add(h)
            unique.append((src, h))
    return unique


def _write_hash_file(hashes: list[str], path: Path) -> None:
    path.write_text("\n".join(hashes) + "\n", encoding="utf-8")


def _parse_potfile(potfile: Path) -> dict[str, str]:
    """
    Parse a hashcat .pot file into a hash→plaintext mapping.

    Parameters
    ----------
    potfile : Path to the .pot file.

    Returns
    -------
    Dict mapping hash string to recovered plaintext.
    """
    mapping: dict[str, str] = {}
    if not potfile.exists():
        return mapping
    try:
        for line in potfile.read_text(encoding="utf-8", errors="replace").splitlines():
            if ":" in line:
                hash_part, _, plain = line.partition(":")
                mapping[hash_part.strip()] = plain.strip()
    except OSError:
        pass
    return mapping


def _load_john_cracked(output_dir: Path) -> set[str]:
    """Load hashes already cracked by john_recovery to avoid duplicates."""
    john_path = output_dir / "john_cracked.json"
    cracked: set[str] = set()
    if john_path.exists():
        try:
            with open(john_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for rec in data.get("cracked", []):
                h = rec.get("hash", "")
                if h:
                    cracked.add(h)
        except (OSError, json.JSONDecodeError):
            pass
    return cracked


# ── Office/PDF document discovery helpers ────────────────────────────────────

# Office magic bytes
_OFFICE_MAGIC = {
    b"\xd0\xcf\x11\xe0": "ole",        # OLE compound: .doc .xls .ppt (legacy)
    b"\x50\x4b\x03\x04": "ooxml",      # ZIP/OOXML: .docx .xlsx .pptx
    b"\x25\x50\x44\x46": "pdf",        # PDF
}

_OFFICE_EXTENSIONS = frozenset({
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".odt", ".ods", ".odp", ".pdf", ".mdb", ".accdb",
})


def _is_password_protected(file_path: Path, logger: logging.Logger) -> bool:
    """Detect password protection via magic bytes and library open attempts."""
    try:
        data = file_path.read_bytes()
        magic4 = data[:4] if len(data) >= 4 else b""

        # OLE/legacy Office — check EncryptionInfo stream
        if magic4 == b"\xd0\xcf\x11\xe0":
            # If the file contains "EncryptionInfo" it is protected
            if b"EncryptionInfo" in data or b"E\x00n\x00c\x00r\x00y\x00p\x00t" in data:
                return True
            # Try python-docx / openpyxl — they raise BadZipFile or similar on encrypted OLE
            return False

        # OOXML (ZIP) — try to open as zip
        if magic4 == b"\x50\x4b\x03\x04":
            import zipfile
            try:
                with zipfile.ZipFile(file_path) as zf:
                    names = zf.namelist()
                    # Encrypted OOXML has "EncryptionInfo" entry
                    if any("EncryptionInfo" in n for n in names):
                        return True
                return False
            except Exception:
                return True  # Can't open as ZIP = likely encrypted

        # PDF
        if magic4 == b"\x25\x50\x44\x46":
            return b"/Encrypt" in data[:65536]

    except Exception as exc:
        logger.debug("Protection check failed for %s: %s", file_path, exc)
    return False


def _find_office2john() -> Optional[str]:
    """Locate office2john.py on the system."""
    import shutil
    # Common Kali Linux locations
    candidates = [
        "/usr/share/john/office2john.py",
        "/usr/lib/john/office2john.py",
        "/opt/john/run/office2john.py",
    ]
    for c in candidates:
        if Path(c).exists():
            return c
    # Fallback: which
    w = shutil.which("office2john") or shutil.which("office2john.py")
    return w


def _icat_binary(analysis_path: Path, inode: str, dest: Path,
                  offset: int, logger: logging.Logger) -> Optional[bytes]:
    """Extract file bytes via icat; returns None on failure."""
    import subprocess as _sp, sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    try:
        result = _sp.run(cmd, capture_output=True, timeout=120, shell=False)
        if result.returncode == 0 and result.stdout:
            return result.stdout
    except Exception as exc:
        logger.debug("icat failed for inode %s: %s", inode, exc)
    return None


def _discover_and_crack_office_docs(
    analysis_path: Path,
    partition_offset: int,
    work_dir: Path,
    wordlist: str,
    logger: logging.Logger,
) -> list[dict]:
    """
    Full pipeline: fls scan -> extract Office/PDF -> detect protection ->
    office2john hash -> crack with john/hashcat -> extract content.

    Returns list of dicts with keys:
      file_path, inode, file_type, hash_str, password, content_preview
    """
    import subprocess as _sp, sys as _sys
    results = []
    work_dir.mkdir(parents=True, exist_ok=True)
    docs_dir = work_dir / "protected_docs"
    docs_dir.mkdir(exist_ok=True)
    hashes_dir = work_dir / "doc_hashes"
    hashes_dir.mkdir(exist_ok=True)

    _sudo = []
    off = ["-o", str(partition_offset)] if partition_offset else []

    # Step 1: fls scan
    logger.info("[PWREC] fls scan for Office/PDF files...")
    try:
        cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
        result = _sp.run(cmd, capture_output=True, timeout=3600, shell=False)
        fls_out = result.stdout.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.warning("[PWREC] fls failed: %s", exc)
        return results

    import re as _re
    fls_pat = _re.compile(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", _re.MULTILINE)
    candidates = []
    for m in fls_pat.finditer(fls_out):
        inode = m.group(1).split("-")[0]
        path_str = m.group(2).strip()
        ext = Path(path_str).suffix.lower()
        if ext in _OFFICE_EXTENSIONS:
            candidates.append({"inode": inode, "path": path_str, "ext": ext})

    logger.info("[PWREC] Found %d Office/PDF candidates", len(candidates))

    # Step 2: Extract and check each
    o2j_path = _find_office2john()
    if not o2j_path:
        logger.warning("[PWREC] office2john not found — hash extraction limited")

    processed = 0
    for cand in candidates:  # exhaustive candidate processing
        inode = cand["inode"]
        safe_name = _re.sub(r"[^\w.\-]", "_", Path(cand["path"]).name)
        dest = docs_dir / f"{inode}_{safe_name}"

        if not dest.exists():
            data = _icat_binary(analysis_path, inode, dest, partition_offset, logger)
            if not data:
                continue
            dest.write_bytes(data)

        if dest.stat().st_size < 512:
            continue

        # Verify magic bytes
        raw = dest.read_bytes()
        magic4 = raw[:4] if len(raw) >= 4 else b""
        file_type = None
        for magic, ftype in _OFFICE_MAGIC.items():
            if magic4 == magic:
                file_type = ftype
                break
        if file_type is None:
            continue  # not an office/pdf by magic

        # Step 3: Check password protection
        if not _is_password_protected(dest, logger):
            continue

        logger.info("[PWREC] Password-protected: %s (%s)", cand["path"], file_type)
        processed += 1

        # Step 4: Extract hash with office2john
        hash_str = None
        if o2j_path:
            try:
                import sys as _sys
                hj = _sp.run(
                    [_sys.executable, o2j_path, str(dest)],
                    capture_output=True, timeout=30,
                )
                h_out = hj.stdout.decode("utf-8", errors="replace").strip()
                # office2john output: "filename:$hash..."
                if ":" in h_out:
                    hash_str = h_out.split(":", 1)[1].strip()
                    hash_file = hashes_dir / f"{inode}.hash"
                    hash_file.write_text(hash_str + "\n", encoding="utf-8")
            except Exception as exc:
                logger.debug("[PWREC] office2john failed for %s: %s", dest.name, exc)

        # Step 5: Crack hash
        password = None
        if hash_str and Path(wordlist).exists():
            pot_file = hashes_dir / f"{inode}.pot"
            try:
                # Try john first
                john_cmd = ["john", "--wordlist=" + wordlist,
                            "--pot=" + str(pot_file), str(hashes_dir / f"{inode}.hash")]
                _sp.run(john_cmd, capture_output=True, timeout=300)
                # Parse john pot
                if pot_file.exists():
                    for line in pot_file.read_text(encoding="utf-8", errors="replace").splitlines():
                        if ":" in line:
                            password = line.split(":", 1)[1].strip()
                            break
                if not password:
                    # Try hashcat with mode 9500 (Office 2007), 9600 (2013), 9700 (old)
                    for hc_mode in ["9400", "9500", "9600", "9700", "9800", "18400"]:
                        hc_cmd = ["hashcat", "-m", hc_mode, "-a", "0",
                                  "--potfile-path", str(pot_file),
                                  str(hashes_dir / f"{inode}.hash"),
                                  wordlist, "--quiet"]
                        _sp.run(hc_cmd, capture_output=True, timeout=300)
                    if pot_file.exists():
                        for line in pot_file.read_text("utf-8", errors="replace").splitlines():
                            if ":" in line:
                                password = line.split(":", 1)[1].strip()
                                break
            except Exception as exc:
                logger.debug("[PWREC] cracking failed: %s", exc)

        # Step 6: Extract content if cracked
        content_preview = ""
        if password:
            try:
                try:
                    import msoffcrypto
                except ImportError:
                    logger.warning("[PWREC] msoffcrypto not installed — skipping content extraction")
                    msoffcrypto = None  # type: ignore[assignment]
                if msoffcrypto is not None and file_type == "ooxml" and cand["ext"] in (".docx",):
                    import io
                    with open(dest, "rb") as f:
                        enc = msoffcrypto.OfficeFile(f)
                        enc.load_key(password=password)
                        dec_io = io.BytesIO()
                        enc.decrypt(dec_io)
                        dec_io.seek(0)
                        import zipfile
                        with zipfile.ZipFile(dec_io) as zf:
                            if "word/document.xml" in zf.namelist():
                                xml_data = zf.read("word/document.xml")
                                root = safe_xml_fromstring(xml_data)
                                texts = root.itertext()
                                content_preview = " ".join(t for t in texts if t.strip())[:500]
            except Exception:
                content_preview = f"[decrypted with password '{password}' — content extraction failed]"

        results.append({
            "file_path":       cand["path"],
            "inode":           inode,
            "file_type":       file_type,
            "hash_str":        hash_str or "",
            "password":        password or "",
            "content_preview": content_preview[:500],
        })

    logger.info("[PWREC] Discovered %d protected docs, cracked %d",
                processed, sum(1 for r in results if r["password"]))
    return results


import sys as _sys
import shutil as _shutil

_OFFICE2JOHN = _shutil.which("office2john") or _shutil.which("office2john.py")
_PDF2JOHN    = _shutil.which("pdf2john")    or _shutil.which("pdf2john.py")


def _extract_hash_hc(candidate, logger):
    """Run office2john or pdf2john; return hash string or None."""
    from pathlib import Path as _P
    candidate = _P(candidate)
    if candidate.suffix.lower() == ".pdf":
        tool = _PDF2JOHN
    elif candidate.suffix.lower() in (".doc", ".xls", ".ppt", ".docx", ".xlsx", ".pptx"):
        tool = _OFFICE2JOHN
    else:
        return None
    if not tool:
        if logger:
            logger.warning("Hash extraction tool not found for %s", candidate.suffix)
        return None
    rc, stdout, stderr = _run_subprocess(
        [_sys.executable, tool, str(candidate)],
        timeout=60,
        logger=logger,
    )
    if rc != 0 or not (stdout or "").strip():
        return None
    return stdout.strip()


def _detect_gpu() -> bool:
    """Return True if hashcat sees a GPU device (CUDA/OpenCL/ROCm/AMD/NVIDIA)."""
    import shutil
    if not shutil.which("hashcat"):
        return False
    try:
        result = subprocess.run(
            ["hashcat", "-I"],
            capture_output=True, timeout=30, shell=False,
        )
        out = result.stdout.decode("utf-8", errors="replace")
        return bool(re.search(r"(GPU|CUDA|OpenCL|ROCm|AMD|NVIDIA|Intel.*\bGPU\b)",
                               out, re.IGNORECASE))
    except Exception:
        return False


def _load_evidence_hash_lists(paths: list[str], max_hashes: int) -> list[tuple[str, str]]:
    """Parse common plain hash-list formats without relying on filenames."""
    hash_re = re.compile(r"(?i)(?<![a-f0-9])([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})(?![a-f0-9])")
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    for value in paths:
        path = Path(str(value))
        if not path.is_file():
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line_no, line in enumerate(lines, 1):
            if line.lstrip().startswith("#"):
                continue
            for match in hash_re.finditer(line):
                h = match.group(1).casefold()
                if h in seen:
                    continue
                seen.add(h)
                out.append((f"{path}#L{line_no}", h))
                if max_hashes > 0 and len(out) >= max_hashes:
                    return out
    return out


def _direct_dictionary_verify(
    hashes: list[tuple[str, str]], wordlist: Path, *, max_words: int = 0
) -> dict[str, str]:
    """Deterministically verify unsalted MD5/SHA1/SHA256 against a wordlist."""
    targets = {h.casefold() for _, h in hashes if len(h) in {32, 40, 64} and re.fullmatch(r"(?i)[a-f0-9]+", h)}
    if not targets or not wordlist.is_file():
        return {}
    found: dict[str, str] = {}
    try:
        with wordlist.open("r", encoding="utf-8", errors="replace") as handle:
            for idx, line in enumerate(handle):
                if (max_words > 0 and idx >= max_words) or len(found) == len(targets):
                    break
                plain = line.rstrip("\r\n")
                raw = plain.encode("utf-8")
                candidates = {
                    hashlib.md5(raw).hexdigest(),
                    hashlib.sha1(raw).hexdigest(),
                    hashlib.sha256(raw).hexdigest(),
                }
                for digest in candidates & targets:
                    found[digest] = plain
    except OSError:
        return {}
    return found


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Recover passwords from hashes found in output_dir using hashcat.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Directory containing JSON files with embedded hashes.
    config        : Configuration dict; recognised keys:
                    - ``wordlist`` (str): path to wordlist (default rockyou.txt).
                    - ``hashcat_rules`` (str): path to a hashcat rules file.
                    - ``max_hashes`` (int): optional safety cap; 0/default means exhaustive.
                    - ``extra_args`` (list[str]): additional hashcat arguments.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with PASSWORD_RECOVERED findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    # FIX #4: try the configured wordlist then several common Kali locations before
    # giving up.  rockyou.txt ships compressed on Kali — unzip it if needed.
    _WORDLIST_CANDIDATES = [
        *(config.get("evidence_wordlist_sources") or []),
        config.get("wordlist", _DEFAULT_WORDLIST),
        "/usr/share/wordlists/rockyou.txt",
        "/usr/share/wordlists/rockyou.txt.gz",
        "/usr/share/john/password.lst",
        "/usr/share/metasploit-framework/data/wordlists/common_passwords.txt",
    ]
    wordlist = ""
    for _wl_cand in _WORDLIST_CANDIDATES:
        if not _wl_cand:
            continue
        _wl_path = Path(_wl_cand)
        if _wl_path.exists():
            # Decompress .gz on the fly into output_dir
            if _wl_cand.endswith(".gz"):
                import gzip, shutil as _shutil
                _decompressed = output_dir / "rockyou.txt"
                if not _decompressed.exists():
                    try:
                        with gzip.open(_wl_path, "rb") as _gz_in:
                            with open(_decompressed, "wb") as _gz_out:
                                _shutil.copyfileobj(_gz_in, _gz_out)
                    except Exception as _gz_err:
                        logger.warning("[HASHCAT] Could not decompress %s: %s", _wl_cand, _gz_err)
                        continue
                wordlist = str(_decompressed)
            else:
                wordlist = _wl_cand
            break
    if not wordlist:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Hashcat Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="No wordlist found",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["No wordlist found; tried: " + ", ".join(_WORDLIST_CANDIDATES)],
            statistics={"specialist_applicable": True, "hashcat_completed": False,
                        "unresolved_supported_objects": 1, "parser_errors": 1,
                        "execution_outcome": "failed"},
            summary="FAILED — no authorised wordlist was available for password-recovery analysis.",
        )
        result.class_results.append(cr)
        return result
    logger.info("[HASHCAT] Using wordlist: %s", wordlist)

    max_hashes = int(config.get("max_hashes", 0) or 0)
    hashcat_rules = config.get("hashcat_rules", "")
    extra_args: list[str] = list(config.get("extra_args", []))

    # ── Corpus-based protected-document hash extraction ──────────────────────
    # Extract a crackable hash from every protected document discovered in the
    # shared corpus (the recovered/carved documents a live-filesystem scan never
    # sees), and feed those hashes into the cracking set below.
    ws = config.get("_working_set", {})
    _corpus_roots: list[Path] = resolve_corpus_roots(ws, output_dir=output_dir)
    _corpus_doc_hashes: list[tuple[str, str]] = []
    if _corpus_roots:
        logger.info("[HASHCAT] Scanning %d corpus root(s) for password-protected files",
                    len(_corpus_roots))
        _seen_docs: set[str] = set()
        corpus_candidates: list[Path] = []
        for _croot in _corpus_roots:
            for _c in _croot.rglob("*"):
                if not _c.is_file() or _c.suffix.lower() not in _OFFICE_EXTENSIONS:
                    continue
                try:
                    _key = str(_c.resolve()).lower()
                    if _c.stat().st_size == 0:
                        continue
                except OSError:
                    continue
                if _key not in _seen_docs:
                    _seen_docs.add(_key)
                    corpus_candidates.append(_c)
        logger.info("[HASHCAT] Corpus candidates: %d document(s)", len(corpus_candidates))
        corpus_hashes_dir = output_dir / "corpus_hashes"
        corpus_hashes_dir.mkdir(parents=True, exist_ok=True)
        _attempted = 0
        for cand in corpus_candidates:
            h_str = _extract_hash_hc(cand, logger)
            if not h_str:
                continue
            # office2john output is "filename:$hash..." — strip filename prefix if present
            if "\n" in h_str:
                h_str = h_str.splitlines()[0]
            if ":" in h_str and not h_str.startswith("$"):
                h_str = h_str.split(":", 1)[1].strip()
            if h_str:
                hash_file_out = corpus_hashes_dir / (cand.stem + ".hash")
                hash_file_out.write_text(h_str + "\n", encoding="utf-8")
                # Feed the extracted hash into the cracking set, sourced to its
                # own document so cracked passwords trace back to the file.
                _corpus_doc_hashes.append((str(cand), h_str))
                _attempted += 1
                logger.info("[HASHCAT] Extracted hash for corpus file: %s", cand.name)
        logger.info(
            "[HASHCAT] Corpus documents: %d discovered, %d hash(es) extracted/attempted",
            len(corpus_candidates), _attempted,
        )
    else:
        logger.info("[HASHCAT] No corpus available; skipping corpus protected-document scan")

    # ── Step 0: discover and crack password-protected Office/PDF documents ────
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    if partition_offset == 0:
        for table_type in ("dos", "gpt"):
            try:
                rc_mm, mm_out, _ = _run_subprocess(
                    ([]) + ["mmls", "-t", table_type, str(analysis_path)],
                    timeout=30, logger=logger,
                )
                if rc_mm == 0 and mm_out:
                    for mm_line in mm_out.splitlines():
                        if re.search(r"NTFS|Basic data", mm_line, re.IGNORECASE):
                            mm_m = re.search(r"\b(\d{4,})\b", mm_line)
                            if mm_m:
                                partition_offset = int(mm_m.group(1))
                                break
                if partition_offset > 0:
                    break
            except Exception:
                pass
        if partition_offset == 0:
            for cand in (2048, 63, 64):
                try:
                    off = ["-o", str(cand)]
                    rc_fl, fl_out, _ = _run_subprocess(
                        ([]) + ["fls"] + off + [str(analysis_path)],
                        timeout=10, logger=logger,
                    )
                    if rc_fl == 0 and fl_out.strip():
                        partition_offset = cand
                        break
                except Exception:
                    pass
    logger.info("[HASHCAT] Partition offset: %d sectors", partition_offset)
    doc_work_dir     = output_dir / "doc_recovery"
    doc_results      = _discover_and_crack_office_docs(
        analysis_path, partition_offset, doc_work_dir, wordlist, logger
    )
    for dr in doc_results:
        pw_str = f" Password recovered: '{dr['password']}'." if dr["password"] else " Password NOT cracked."
        desc = (
            f"Password-protected {dr['file_type'].upper()} document found: "
            f"'{dr['file_path']}'." + pw_str
        )
        if dr["content_preview"]:
            desc += f" Content preview: {dr['content_preview'][:200]}"
        findings.append(make_finding(
            "PROTECTED_DOCUMENT_FOUND",
            Severity.HIGH if dr["password"] else Severity.MEDIUM,
            desc,
            dr["file_path"],
            {k: v for k, v in dr.items() if k != "content_preview"},
            artifact_path=None,
        ))
    if doc_results:
        logger.info("[PWREC] Office doc pipeline: %d protected docs found", len(doc_results))
    for dr in doc_results:
        if dr["password"]:
            _emit_document_content(dr["file_path"], dr["password"], findings, logger)

    # --- Populate hashes from image if no .hash files exist yet ---
    hashes_dir = output_dir / "hashes"
    if not hashes_dir.exists() or not any(hashes_dir.glob("*.hash")):
        try:
            from core.hash_extractor import extract_hashes_from_image
            # Get fls entries from filesystem module output if available
            fls_entries: list[dict] = []
            fls_out_file = output_dir.parent / "filesystem_deep_analyzer" / "fls_output.txt"
            if fls_out_file.exists():
                fls_pat = re.compile(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$")
                for fls_line in fls_out_file.read_text(encoding="utf-8", errors="replace").splitlines():
                    fls_m = fls_pat.match(fls_line)
                    if fls_m:
                        fls_entries.append({
                            "inode": fls_m.group(1).split("-")[0],
                            "path": fls_m.group(2).strip(),
                        })
            extracted = extract_hashes_from_image(
                analysis_path, partition_offset, fls_entries, hashes_dir, logger
            )
            logger.info("[HASHCAT] hash_extractor: %d hashes extracted from image", len(extracted))
        except Exception as exc:
            logger.warning("[HASHCAT] hash_extractor failed: %s", exc)

    # Collect hashes from sibling module output dirs (registry hives contain NTLM hashes)
    _artifact_dir  = output_dir.parent / "artifact_extractor"
    _recovery_dir  = output_dir.parent / "deleted_file_recovery"
    _registry_dir  = output_dir.parent / "windows_registry_analyzer"
    _scan_dirs = [d for d in [output_dir, _artifact_dir, _recovery_dir, _registry_dir]
                  if d.is_dir()]
    # Corpus-document hashes join the JSON-sourced hashes; both are capped
    # together so the corpus contribution is never silently dropped.
    evidence_hashes = _load_evidence_hash_lists(
        [str(v) for v in (config.get("evidence_hash_list_sources") or [])],
        max_hashes=max_hashes,
    )
    discovered_hashes = _corpus_doc_hashes + evidence_hashes + _collect_hashes_from_json(_scan_dirs)
    all_hashes = discovered_hashes[:max_hashes] if max_hashes > 0 else discovered_hashes
    hashes_omitted_by_limit = max(0, len(discovered_hashes) - len(all_hashes))
    # De-duplicate exact hashes while preserving the first, most direct source.
    _seen_hashes: set[str] = set()
    all_hashes = [(src, h) for src, h in all_hashes if not (h.casefold() in _seen_hashes or _seen_hashes.add(h.casefold()))]
    if not all_hashes:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Hashcat Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NOT_APPLICABLE,
            notes="No recognisable hashes found in output_dir JSON files",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="NOT APPLICABLE — no recognisable supported password hashes were discovered.",
            statistics={
                "applicability_check_completed": True,
                "sources_discovered": 0, "sources_processed": 0,
                "supported_objects_discovered": 0, "supported_objects_processed": 0,
                "records_discovered": 0, "records_processed": 0,
                "unresolved_supported_objects": 0, "parser_errors": 0,
                "specialist_applicable": False, "hashcat_completed": False,
            },
        )
        result.class_results.append(cr)
        return result

    logger.info("[%s] Collected %d unique hashes", MODULE_NAME, len(all_hashes))

    # Direct recomputation is deterministic for unsalted MD5/SHA1/SHA256 and
    # avoids treating a hashcat runtime failure as evidence absence.
    direct_verified = _direct_dictionary_verify(all_hashes, Path(wordlist))
    logger.info("[%s] Directly verified %d unsalted hash/plaintext pair(s)", MODULE_NAME, len(direct_verified))

    # Load john results to skip duplicates
    john_cracked = _load_john_cracked(output_dir)

    # Group hashes by mode
    by_mode: dict[int, list[tuple[str, str]]] = {}
    for src, h in all_hashes:
        mode = _detect_hash_mode(h)
        if mode is not None:
            by_mode.setdefault(mode, []).append((src, h))

    hashcat_dir = output_dir / "hashcat_output"
    hashcat_dir.mkdir(parents=True, exist_ok=True)
    potfile = hashcat_dir / "hashcat.pot"

    stats: dict[str, Any] = {
        "scope": "STANDALONE_HASHES_AND_OFFICE_PDF",
        "archive_password_responsibility": "john_recovery",
        "hashes_discovered": len(all_hashes) + hashes_omitted_by_limit,
        "hashes_attempted": len(all_hashes),
        "hashes_omitted_by_limit": hashes_omitted_by_limit,
        "hashes_cracked": 0,
        "unique_plaintexts": 0,
        "evidence_hashes_loaded": len(evidence_hashes),
        "directly_verified": len(direct_verified),
        "specialist_applicable": bool(by_mode),
        "hashcat_runs": 0,
        "hashcat_successful_runs": 0,
        "hashcat_completed": False,
    }

    hashcat_available = True

    for mode, mode_hashes in by_mode.items():
        hash_strings = [h for _, h in mode_hashes]
        hash_file = hashcat_dir / f"hashes_mode{mode}.txt"
        _write_hash_file(hash_strings, hash_file)

        cmd = [
            "hashcat",
            "-m", str(mode),
            "-a", "0",                      # dictionary attack
            "--potfile-path", str(potfile),
            "--status", "--status-timer=30",
            "--quiet",
            str(hash_file),
            wordlist,
        ]
        if hashcat_rules and Path(hashcat_rules).exists():
            cmd += ["-r", hashcat_rules]
        cmd.extend(extra_args)

        logger.info("[%s] Running hashcat mode %d (%s) on %d hashes",
                    MODULE_NAME, mode, _MODE_NAMES.get(mode, "?"), len(hash_strings))

        try:
            rc, stdout, stderr = _run_subprocess(cmd, timeout=HASHCAT_TIMEOUT, logger=logger)
            stats["hashcat_runs"] += 1
            if rc in {0, 1}:
                stats["hashcat_successful_runs"] += 1
            log_path = hashcat_dir / f"hashcat_mode{mode}.log"
            log_path.write_text(stdout + "\n" + stderr, encoding="utf-8", errors="replace")
            artifact_paths.append(str(log_path))
            logger.info("[%s] hashcat mode %d completed: rc=%d", MODULE_NAME, mode, rc)
        except FileNotFoundError:
            hashcat_available = False
            errors.append("hashcat not found — install hashcat package")
            break
        except subprocess.TimeoutExpired:
            errors.append(f"hashcat mode {mode} timed out after {HASHCAT_TIMEOUT}s")

    if not hashcat_available and not direct_verified:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Hashcat Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="hashcat not installed and no exact direct dictionary verification succeeded",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=errors, statistics={**stats,
                "unresolved_supported_objects": len(all_hashes), "parser_errors": len(errors),
                "execution_outcome": "failed"},
            summary="FAILED — hashcat was required for discovered supported hashes but was unavailable.",
        )
        result.class_results.append(cr)
        return result
    # Exact hashlib recomputation is an independent deterministic technique.
    # Preserve those recovered plaintexts even when optional hashcat execution
    # is unavailable; the module becomes PARTIAL for only the unattempted modes.

    # GPU detection for Office/PDF specific modes
    gpu_available = _detect_gpu()
    if not gpu_available:
        logger.info("[HASHCAT] No GPU detected — skipping -m 9700 and -m 10400 modes")

    # Office 97-2003 (-m 9700) and PDF 1.1-1.3 (-m 10400) specific modes
    for spec_mode, spec_label, hash_marker in [
        ("9700", "MS Office ≤2003",  "$oldoffice$"),
        ("10400", "PDF 1.1-1.3",      "$pdf$"),
    ]:
        if not gpu_available:
            continue
        spec_hashes = [h for _, h in all_hashes if hash_marker in h]
        if not spec_hashes:
            continue
        spec_hash_file = hashcat_dir / f"hashes_mode{spec_mode}.txt"
        _write_hash_file(spec_hashes, spec_hash_file)
        spec_cmd = [
            "hashcat", "-m", spec_mode, "-a", "0",
            "--potfile-path", str(potfile), "--quiet",
            str(spec_hash_file), wordlist,
        ]
        logger.info("[HASHCAT] Mode %s (%s): %d hashes", spec_mode, spec_label, len(spec_hashes))
        try:
            spec_rc, _spec_out, _spec_err = _run_subprocess(spec_cmd, timeout=HASHCAT_TIMEOUT, logger=logger)
            stats["hashcat_runs"] += 1
            if spec_rc in {0, 1}:
                stats["hashcat_successful_runs"] += 1
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            errors.append(f"hashcat mode {spec_mode} failed: {exc}")

    # Parse potfile
    cracked_map = _parse_potfile(potfile)
    cracked_map.update(direct_verified)
    if potfile.exists():
        artifact_paths.append(str(potfile))

    cracked_records: list[dict[str, Any]] = []
    seen_plaintexts: set[str] = set()

    for src, h in all_hashes:
        plain = cracked_map.get(h)
        if not plain:
            continue
        if h in john_cracked:
            continue   # already reported by john_recovery
        stats["hashes_cracked"] += 1
        seen_plaintexts.add(plain)
        detected_mode = _detect_hash_mode(h)
        mode = detected_mode if detected_mode is not None else -1
        direct_method = h.casefold() in direct_verified
        cracked_records.append({
            "source_file": src,
            "file_path":   src,
            "password":    plain,
            "hash": h[:16] + "...",   # truncate for report
            "hash_type": _MODE_NAMES.get(mode, "unknown"),
            "plaintext_length": len(plain),
        })
        findings.append(make_finding(
            finding_type="PASSWORD_RECOVERED",
            severity=Severity.HIGH,
            description=(
                f"{'Direct dictionary verification' if direct_method else 'hashcat'} recovered plaintext for "
                f"{_MODE_NAMES.get(mode, 'unknown')} hash from {Path(src).name}: length={len(plain)} chars."
            ),
            evidence_path=str(src).split("#L", 1)[0] if Path(str(src).split("#L", 1)[0]).is_file() else str(evidence_path),
            metadata={
                **deterministic_metadata(
                    "exact hash recomputation against supplied wordlist" if direct_method else "hashcat exact hash/plaintext verification",
                    validators=["hashlib" if direct_method else "hashcat potfile"],
                ),
                "source_file": src,
                "hash": h,
                "hash_type": _MODE_NAMES.get(mode, "unknown"),
                "plaintext_length": len(plain),
                "recovery_method": "direct_recomputation" if direct_method else "hashcat",
            },
        ))

    stats["unique_plaintexts"] = len(seen_plaintexts)
    unsupported_hashes = sum(1 for _, h in all_hashes if _detect_hash_mode(h) is None and h.casefold() not in direct_verified)
    stats["unsupported_objects"] = unsupported_hashes
    stats["unresolved_supported_objects"] = hashes_omitted_by_limit + unsupported_hashes
    stats["parser_errors"] = len(errors)
    stats["sources_discovered"] = len(all_hashes) + hashes_omitted_by_limit
    stats["sources_processed"] = len(all_hashes)
    stats["supported_objects_discovered"] = len(all_hashes) + hashes_omitted_by_limit
    stats["supported_objects_processed"] = len(all_hashes) - unsupported_hashes
    stats["records_discovered"] = len(all_hashes) + hashes_omitted_by_limit
    stats["records_processed"] = len(all_hashes) - unsupported_hashes
    stats["hashcat_completed"] = bool(
        stats["hashcat_runs"] > 0
        and stats["hashcat_successful_runs"] == stats["hashcat_runs"]
    )

    for rec in cracked_records:
        _emit_document_content(rec.get("file_path", ""), rec.get("password", ""),
                               findings, logger)

    # Write cracked summary
    cracked_path = output_dir / "hashcat_cracked.json"
    try:
        with open(cracked_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "scope_note": "Hashcat does not claim ZIP archive recovery; John is the responsible archive-password module.",
                "cracked": cracked_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(cracked_path))
    except OSError as exc:
        errors.append(f"Failed to write hashcat_cracked.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors and stats["unresolved_supported_objects"] == 0 else ModuleStatus.PARTIAL
    summary = (
        f"hashcat attempted {stats['hashes_attempted']} hashes; "
        f"recovered {stats['hashes_cracked']} passwords "
        f"({stats['unique_plaintexts']} unique plaintexts). "
        "Scope: standalone hashes and supported Office/PDF hashes; encrypted ZIP archive recovery is assigned to john_recovery."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Hashcat Password Cracking",
        verdict=(AssuranceVerdict.PRESENT if findings else
                 AssuranceVerdict.VERIFIED_ABSENT if status == ModuleStatus.COMPLETED and bool(all_hashes)
                 else AssuranceVerdict.INDETERMINATE),
        skip_reason=(None if findings or (status == ModuleStatus.COMPLETED and bool(all_hashes)) else SkipReason.PARTIAL_FAILURE),
        count=len(findings),
    )

    result = ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
    )
    result.class_results.append(cr)
    return result
