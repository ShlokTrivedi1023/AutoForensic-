"""
geolocation_extractor.py — Geolocation Extractor Module for AutoForensics.

Reads GPS coordinates from the ``metadata_report.json`` produced by the
exiftool_metadata module and produces:

  - KML file (Google Earth compatible)
  - GeoJSON FeatureCollection (mapping tools)
  - Optional reverse geocoding via Nominatim (requires ``requests``)

GPS findings include the source file path and timestamp so investigators can
correlate locations with activity timelines.

Target platform : Kali Linux, Python 3.11+
External tools  : none (reads exiftool output; requests optional)
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import re
from pathlib import Path
from typing import Any, Optional
from xml.sax.saxutils import escape as xml_escape

from core.deterministic_validation import deterministic_metadata, sha256_file

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    make_finding,
    resolve_corpus_roots,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

try:
    import requests as _requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False

MODULE_NAME: str = "geolocation_extractor"
NOMINATIM_TIMEOUT: int = 10
NOMINATIM_URL: str = "https://nominatim.openstreetmap.org/reverse"

# exiftool's GPS group reports degrees/minutes/seconds WITHOUT a hemisphere —
# the direction lives in the separate GPSLatitudeRef / GPSLongitudeRef tag — while
# its Composite group appends the letter.  Both shapes must parse, so the
# direction is optional here and supplied from the ref tag when absent.
_RE_DMS = re.compile(
    r"(\d+(?:\.\d+)?)\s*deg\s*(\d+(?:\.\d+)?)'\s*([\d.]+)\"?\s*([NSEW])?",
    re.IGNORECASE,
)
# Decimal degrees, with or without a trailing hemisphere: "37.4219722", "37 N".
_RE_DECIMAL = re.compile(r"^([+-]?\d+(?:\.\d+)?)\s*([NSEW])?$", re.IGNORECASE)

# Hemispheres exiftool writes either as a letter or as the full word.
_NEGATIVE_HEMISPHERES: frozenset[str] = frozenset({"S", "W", "SOUTH", "WEST"})
_POSITIVE_HEMISPHERES: frozenset[str] = frozenset({"N", "E", "NORTH", "EAST"})


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _hemisphere_sign(*candidates: Any) -> Optional[int]:
    """Return -1 / +1 for the first recognisable hemisphere, else None.

    Accepts every form exiftool emits for a direction: the single letter from a
    composite coordinate and the spelled-out word from the ...Ref tag.
    """
    for cand in candidates:
        token = str(cand or "").strip().upper()
        if not token:
            continue
        if token in _NEGATIVE_HEMISPHERES:
            return -1
        if token in _POSITIVE_HEMISPHERES:
            return 1
    return None


def _dms_to_decimal(dms_str: Any, ref: Any = None) -> Optional[float]:
    """
    Convert an exiftool coordinate to signed decimal degrees.

    Handles every representation exiftool produces: degrees/minutes/seconds with
    the hemisphere inline (Composite group), the same value with the hemisphere
    in a separate ``...Ref`` tag (GPS group), and a plain signed number.

    Parameters
    ----------
    dms_str : Coordinate value as produced by exiftool (string or number).
    ref     : Optional ``GPSLatitudeRef`` / ``GPSLongitudeRef`` value.

    Returns
    -------
    Signed decimal float, or None if the value cannot be parsed.
    """
    # Numeric values are already signed decimal degrees; a ref tag may still
    # carry the hemisphere for an unsigned magnitude.
    if isinstance(dms_str, (int, float)) and not isinstance(dms_str, bool):
        value = float(dms_str)
        sign = _hemisphere_sign(ref)
        return round(abs(value) * sign if sign is not None else value, 8)

    s = str(dms_str or "").strip()
    if not s:
        return None

    m = _RE_DMS.search(s)
    if m:
        decimal = float(m.group(1)) + float(m.group(2)) / 60 + float(m.group(3)) / 3600
        sign = _hemisphere_sign(m.group(4), ref)
        return round(decimal * (sign if sign is not None else 1), 8)

    m = _RE_DECIMAL.match(s)
    if m:
        value = float(m.group(1))
        sign = _hemisphere_sign(m.group(2), ref)
        return round(abs(value) * sign if sign is not None else value, 8)
    return None


def _parse_gps_record(rec: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    Extract latitude and longitude from an exiftool file record.

    Parameters
    ----------
    rec : Single file dict from exiftool_metadata report.

    Returns
    -------
    Dict with lat, lon, alt, source_file, datetime keys, or None.
    """
    lat_str = str(rec.get("GPSLatitude") or rec.get("gps_latitude") or "").strip()
    lon_str = str(rec.get("GPSLongitude") or rec.get("gps_longitude") or "").strip()
    if not lat_str or not lon_str:
        return None

    lat = _dms_to_decimal(
        lat_str, rec.get("GPSLatitudeRef") or rec.get("gps_latitude_ref")
    )
    lon = _dms_to_decimal(
        lon_str, rec.get("GPSLongitudeRef") or rec.get("gps_longitude_ref")
    )
    if lat is None or lon is None:
        return None

    # Sanity check
    if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        return None

    return {
        "lat": lat,
        "lon": lon,
        "alt": str(rec.get("GPSAltitude") or rec.get("gps_altitude") or ""),
        "datetime": str(rec.get("GPSDateTime") or rec.get("gps_datetime") or ""),
        "source_file": str(rec.get("SourceFile") or rec.get("file_path") or ""),
        "coordinate_source": str(rec.get("metadata_source") or rec.get("GPSSource") or "metadata_record"),
    }




def _terminal_data_start(data: bytes) -> int:
    """Return the end of the declared/structured image stream where determinable."""
    if data.startswith(b"\xff\xd8\xff"):
        end = data.rfind(b"\xff\xd9")
        return end + 2 if end >= 0 else len(data)
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        pos = 8
        while pos + 12 <= len(data):
            length = int.from_bytes(data[pos:pos+4], "big")
            kind = data[pos+4:pos+8]
            end = pos + 12 + length
            if end > len(data):
                return len(data)
            pos = end
            if kind == b"IEND":
                return end
        return len(data)
    if data.startswith(b"BM") and len(data) >= 6:
        declared = int.from_bytes(data[2:6], "little")
        if 14 <= declared <= len(data):
            return declared
    return max(0, len(data) - min(len(data), 8192))


def _appended_coordinate_records(path: Path) -> list[dict[str, Any]]:
    """Parse labelled or unambiguous decimal coordinate pairs after image data.

    Exact labels such as ``LAT=...`` and ``LON=...`` are preferred. Generic
    pairs are accepted only when the nearby text explicitly identifies GPS or
    coordinates. This prevents arbitrary carved/compressed numbers from being
    promoted to locations.
    """
    try:
        data = path.read_bytes()
    except OSError:
        return []
    start = _terminal_data_start(data)
    tail = data[start:]
    if not tail:
        return []
    text = tail.decode("utf-8", errors="replace")
    out: list[dict[str, Any]] = []

    lat_re = re.compile(r"(?im)\b(?:[A-Z0-9_]*GPS_)?LAT(?:ITUDE)?\s*[:=]\s*([+-]?\d{1,2}(?:\.\d+)?)")
    lon_re = re.compile(r"(?im)\b(?:[A-Z0-9_]*GPS_)?LON(?:GITUDE)?\s*[:=]\s*([+-]?\d{1,3}(?:\.\d+)?)")
    lat_matches = list(lat_re.finditer(text))
    lon_matches = list(lon_re.finditer(text))
    for lat_match in lat_matches:
        later = [m for m in lon_matches if m.start() >= lat_match.end() and m.start() - lat_match.end() <= 256]
        if not later:
            continue
        lon_match = later[0]
        lat, lon = float(lat_match.group(1)), float(lon_match.group(1))
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        offset = start + len(text[:lat_match.start()].encode("utf-8", errors="replace"))
        out.append({
            "lat": lat, "lon": lon, "alt": "", "datetime": "",
            "source_file": str(path), "coordinate_source": "post_terminator_labelled_text",
            "raw_text": text[lat_match.start():lon_match.end()], "byte_offset": offset,
        })

    # Fallback for one-line explicitly-labelled pairs.
    pair_re = re.compile(
        r"(?i)\b(?:gps|coordinates?)\b[^\r\n]{0,80}?"
        r"([+-]?\d{1,2}(?:\.\d+)?)\s*[,;/| ]+\s*"
        r"([+-]?\d{1,3}(?:\.\d+)?)"
    )
    for match in pair_re.finditer(text):
        lat, lon = float(match.group(1)), float(match.group(2))
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        offset = start + len(text[:match.start()].encode("utf-8", errors="replace"))
        out.append({
            "lat": lat, "lon": lon, "alt": "", "datetime": "",
            "source_file": str(path), "coordinate_source": "post_terminator_labelled_text",
            "raw_text": match.group(0), "byte_offset": offset,
        })

    unique: dict[tuple[float, float, int], dict[str, Any]] = {}
    for rec in out:
        unique[(round(rec["lat"], 12), round(rec["lon"], 12), rec["byte_offset"])] = rec
    return list(unique.values())


def _source_rank(path: Path) -> tuple[int, int, str]:
    text = str(path).replace("\\", "/").casefold()
    if "/native_filesystem/" in text and "/extracted_files/" in text:
        return (0, len(text), text)
    if "/native_filesystem/" in text and "/deleted_files/" in text:
        return (1, len(text), text)
    if "/native_signature_carver/" in text:
        return (2, len(text), text)
    if "/foremost_carver/" in text:
        return (3, len(text), text)
    if "/scalpel_carver/" in text:
        return (4, len(text), text)
    return (2, len(text), text)


def _is_carver_path(path: Path) -> bool:
    text = str(path).replace("\\", "/").casefold()
    return any(token in text for token in (
        "/scalpel_carver/", "/foremost_carver/", "/native_signature_carver/",
        "/scalpel_", "/foremost_output/",
    ))


def _content_key(path: Path) -> str:
    try:
        return sha256_file(path)
    except Exception:
        return "path:" + str(path)


def _distance_metres(a: dict[str, Any], b: dict[str, Any]) -> float:
    """Haversine distance for reporting an exact source discrepancy."""
    radius = 6371008.8
    lat1, lat2 = math.radians(float(a["lat"])), math.radians(float(b["lat"]))
    dlat = lat2 - lat1
    dlon = math.radians(float(b["lon"]) - float(a["lon"]))
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2 * radius * math.asin(min(1.0, math.sqrt(h)))


def _build_kml(points: list[dict[str, Any]]) -> str:
    """
    Build a KML document from GPS point records.

    Parameters
    ----------
    points : List of dicts with lat, lon, alt, source_file, datetime.

    Returns
    -------
    KML XML string.
    """
    placemarks = []
    for p in points:
        name = xml_escape(Path(p["source_file"]).name or "unknown")
        desc = xml_escape(f"File: {p['source_file']}\\nTime: {p['datetime']}")
        alt = p["alt"] or "0"
        alt_val = re.sub(r"[^0-9.\-]", "", str(alt)) or "0"
        placemarks.append(
            f"  <Placemark>\n"
            f"    <name>{name}</name>\n"
            f"    <description>{desc}</description>\n"
            f"    <Point><coordinates>{p['lon']},{p['lat']},{alt_val}</coordinates></Point>\n"
            f"  </Placemark>"
        )
    body = "\n".join(placemarks)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
        '<Document>\n'
        '<name>AutoForensics GPS Points</name>\n'
        f"{body}\n"
        "</Document>\n</kml>\n"
    )


def _build_geojson(points: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Build a GeoJSON FeatureCollection from GPS point records.

    Parameters
    ----------
    points : List of dicts with lat, lon, alt, source_file, datetime.

    Returns
    -------
    GeoJSON FeatureCollection dict.
    """
    features = []
    for p in points:
        features.append({
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [p["lon"], p["lat"]],
            },
            "properties": {
                "source_file": p["source_file"],
                "datetime": p["datetime"],
                "altitude": p["alt"],
            },
        })
    return {
        "type": "FeatureCollection",
        "features": features,
    }


def _reverse_geocode(lat: float, lon: float, user_agent: str) -> Optional[str]:
    """
    Reverse geocode a coordinate pair via Nominatim.

    Parameters
    ----------
    lat        : Decimal latitude.
    lon        : Decimal longitude.
    user_agent : HTTP User-Agent header (required by Nominatim TOS).

    Returns
    -------
    Human-readable address string, or None on failure.
    """
    if not _REQUESTS_AVAILABLE:
        return None
    try:
        resp = _requests.get(
            NOMINATIM_URL,
            params={"lat": lat, "lon": lon, "format": "json"},
            headers={"User-Agent": user_agent},
            timeout=NOMINATIM_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("display_name")
    except Exception:
        return None




def _native_exif_records(corpus_roots: list[Path]) -> list[dict[str, Any]]:
    """Read GPS EXIF from recovered images with Pillow when available."""
    try:
        from PIL import Image
    except ImportError:
        return []
    records: list[dict[str, Any]] = []
    seen: set[str] = set()
    for root in corpus_roots:
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".jpg", ".jpeg", ".tif", ".tiff"}:
                continue
            try:
                key = str(path.resolve())
                if key in seen:
                    continue
                seen.add(key)
                with Image.open(path) as image:
                    exif = image.getexif()
                    gps = exif.get_ifd(34853) if 34853 in exif else {}
                    exif_ifd = exif.get_ifd(34665) if 34665 in exif else {}
                lat = gps.get(2)
                lon = gps.get(4)
                if not lat or not lon:
                    continue
                def dms(value: Any) -> str:
                    vals = tuple(float(v) for v in value)
                    return f"{vals[0]} deg {vals[1]}' {vals[2]}\""
                records.append({
                    "SourceFile": str(path),
                    "GPSLatitude": dms(lat),
                    "GPSLatitudeRef": gps.get(1, ""),
                    "GPSLongitude": dms(lon),
                    "GPSLongitudeRef": gps.get(3, ""),
                    "GPSAltitude": gps.get(6, ""),
                    "GPSDateTime": exif_ifd.get(36867, ""),
                    "metadata_source": "native_pillow_exif",
                })
            except Exception:
                continue
    return records


def _locate_metadata_report(output_dir: Path) -> Optional[Path]:
    """Find the exiftool ``metadata_report.json`` this module must consume.

    The exiftool_metadata module writes the report into its own module-output
    directory, a sibling of ``output_dir`` under ``module_output/evNN/``.  We
    therefore check ``output_dir`` itself first (standalone invocation), then the
    sibling module-output directories.  Directory names are discovered at
    runtime; nothing about the exhibit or the producing module is hardcoded.
    """
    own = output_dir / "metadata_report.json"
    if own.exists():
        return own
    try:
        siblings = sorted(output_dir.parent.iterdir())
    except OSError:
        return None
    for sib in siblings:
        if sib == output_dir or not sib.is_dir():
            continue
        candidate = sib / "metadata_report.json"
        if candidate.exists():
            return candidate
    return None


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Extract GPS coordinates from exiftool metadata and produce KML/GeoJSON.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Directory containing metadata_report.json.
    config        : Configuration dict; recognised keys:
                    - ``reverse_geocode`` (bool): enable Nominatim lookup (default False).
                    - ``nominatim_user_agent`` (str): User-Agent for Nominatim (required
                      if reverse_geocode is True).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with GPS_LOCATION_CLUSTER findings plus KML/GeoJSON artifacts.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load metadata_report.json produced by the exiftool_metadata module.
    # exiftool writes it into ITS OWN module-output directory, which is a sibling
    # of this module's output_dir (each module gets module_output/evNN/<name>/),
    # so look in this module's dir first (standalone/backward-compatible), then
    # scan sibling module-output directories for the report.  The sibling name is
    # discovered at runtime — never hardcoded — so this holds on any exhibit.
    metadata_report = _locate_metadata_report(output_dir)
    meta_data: dict[str, Any]
    metadata_source = "exiftool_report"
    if metadata_report is None or not metadata_report.exists():
        ws = config.get("_working_set", {})
        native_records = _native_exif_records(resolve_corpus_roots(ws, output_dir=output_dir))
        if native_records:
            meta_data = {"files": native_records}
            metadata_source = "native_pillow_exif"
        else:
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.METADATA,
                artefact_class="Geolocation Data",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE,
                notes="No metadata report and no deterministic XMP, EXIF, or appended-coordinate records found",
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                summary="Skipped: no deterministic coordinate records found by external or native parser.",
                class_results=[cr],
            )
    else:
        try:
            with open(metadata_report, "r", encoding="utf-8") as f:
                meta_data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.METADATA,
                artefact_class="Geolocation Data",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE,
                notes=f"Failed to load metadata_report.json: {exc}",
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.FAILED,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=[f"Failed to load metadata_report.json: {exc}"],
                summary="Failed: could not read metadata report.",
                class_results=[cr],
            )

    records = meta_data.get("files", []) if isinstance(meta_data, dict) else []
    if not records and isinstance(meta_data, dict):
        records = [meta_data]

    # Extract GPS points, choosing one canonical path for each exact byte stream.
    record_groups: dict[str, list[tuple[Path, dict[str, Any]]]] = {}
    for rec in records:
        source = Path(str(rec.get("SourceFile") or rec.get("file_path") or ""))
        if not source.is_file():
            continue
        # Carver output may intentionally extend past a valid image terminator.
        # Such trailing bytes have no reliable file provenance and cannot be a
        # deterministic coordinate source. Native allocated/deleted artefacts
        # remain eligible; carved coordinates require a separate validated
        # offset/provenance record and are excluded here by default.
        if _is_carver_path(source) and not config.get("allow_validated_carved_geolocation", False):
            continue
        record_groups.setdefault(_content_key(source), []).append((source, rec))

    points: list[dict[str, Any]] = []
    canonical_images: dict[str, dict[str, Any]] = {}
    for digest, group in record_groups.items():
        source, rec = min(group, key=lambda item: _source_rank(item[0]))
        aliases = sorted(str(item[0]) for item in group if item[0] != source)
        pt = _parse_gps_record(rec)
        if pt:
            pt["source_file"] = str(source)
            pt["content_sha256"] = digest
            pt["aliases"] = aliases
            points.append(pt)
        canonical_images[digest] = {"path": source, "aliases": aliases}

    # Independently inspect one preferred path per exact image byte stream.
    for root in resolve_corpus_roots(config.get("_working_set", {}), output_dir=output_dir):
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}:
                continue
            if _is_carver_path(path) and not config.get("allow_validated_carved_geolocation", False):
                continue
            digest = _content_key(path)
            existing = canonical_images.get(digest)
            if existing is None or _source_rank(path) < _source_rank(existing["path"]):
                aliases = list(existing.get("aliases") or []) if existing else []
                if existing and str(existing["path"]) != str(path):
                    aliases.append(str(existing["path"]))
                canonical_images[digest] = {"path": path, "aliases": sorted(set(aliases))}
            elif str(path) != str(existing["path"]):
                existing.setdefault("aliases", []).append(str(path))

    for digest, info in canonical_images.items():
        source = Path(info["path"])
        for pt in _appended_coordinate_records(source):
            pt["content_sha256"] = digest
            pt["aliases"] = sorted(set(info.get("aliases") or []))
            points.append(pt)

    stats: dict[str, int] = {
        "files_with_gps": len({p.get("source_file") for p in points}),
        "coordinate_records": len(points),
        "unique_locations": 0,
        "source_discrepancies": 0,
        "reverse_geocoded": 0,
    }

    if not points:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.METADATA,
            artefact_class="Geolocation Data",
            verdict=AssuranceVerdict.VERIFIED_ABSENT,
            count=0,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.COMPLETED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            statistics=stats,
            summary="No GPS coordinates found in metadata report.",
            class_results=[cr],
        )

    # Group coordinate representations by underlying image byte stream.  Near
    # values in one image are representations/discrepancies, not independent
    # physical-location corroboration.
    representation_map: dict[tuple[str, str, float, float, int], dict[str, Any]] = {}
    for point in points:
        digest = str(point.get("content_sha256") or point.get("source_file") or "")
        key = (
            digest, str(point.get("coordinate_source") or ""),
            round(float(point["lat"]), 10), round(float(point["lon"]), 10),
            int(point.get("byte_offset") or -1),
        )
        representation_map.setdefault(key, point)
    coordinate_representations = list(representation_map.values())
    by_artifact: dict[str, list[dict[str, Any]]] = {}
    for point in coordinate_representations:
        by_artifact.setdefault(str(point.get("content_sha256") or point.get("source_file") or ""), []).append(point)
    stats["unique_artifacts"] = len(by_artifact)
    stats["coordinate_representations"] = len(coordinate_representations)
    # Backward-compatible field: it now counts underlying artifacts, not
    # coordinate variants that differ within one artifact.
    stats["unique_locations"] = len(by_artifact)

    discrepancy_tolerance_m = float(config.get("coordinate_discrepancy_tolerance_metres", 1.0))
    for content_key, source_points in by_artifact.items():
        source_file = str(source_points[0].get("source_file") or "")
        for index, first in enumerate(source_points):
            for second in source_points[index + 1:]:
                if first.get("coordinate_source") == second.get("coordinate_source"):
                    continue
                distance = _distance_metres(first, second)
                if distance <= discrepancy_tolerance_m:
                    continue
                stats["source_discrepancies"] += 1
                findings.append(make_finding(
                    finding_type="GEOLOCATION_SOURCE_DISCREPANCY",
                    severity=Severity.MEDIUM,
                    description=(
                        f"Two coordinate representations in {Path(source_file).name} disagree by approximately {distance:.2f} metres. "
                        "They are retained as one artifact with an internal source discrepancy, not two independent locations."
                    ),
                    evidence_path=source_file or str(evidence_path),
                    metadata={
                        "source_file": source_file, "file_path": source_file,
                        "file_sha256": content_key if len(content_key) == 64 else "",
                        "source_a": first, "source_b": second,
                        "distance_metres": round(distance, 4), "tolerance_metres": discrepancy_tolerance_m,
                        **deterministic_metadata(
                            "independent coordinate-source parsing and Haversine comparison",
                            validators=["metadata parser", "post-terminator byte parser", "Haversine calculation"],
                            semantic_limit="Internal metadata discrepancy only; physical presence is not inferred.",
                        ),
                    },
                    artifact_path=(source_file if Path(source_file).is_file() else None),
                ))

    # Optional reverse geocoding remains non-evidentiary enrichment and is not
    # included in canonical findings unless an external response is separately
    # retained and authenticated.
    do_geocode = config.get("reverse_geocode", False)
    nominatim_ua = config.get("nominatim_user_agent", f"AutoForensics/{case_id}")
    if do_geocode and _REQUESTS_AVAILABLE:
        for point in coordinate_representations:
            addr = _reverse_geocode(point["lat"], point["lon"], nominatim_ua)
            if addr:
                point["address_candidate"] = addr
                stats["reverse_geocoded"] += 1

    for content_key, source_points in sorted(by_artifact.items()):
        primary = sorted(source_points, key=lambda item: (str(item.get("coordinate_source") or ""), float(item["lat"]), float(item["lon"])))[0]
        source_file = str(primary.get("source_file") or "")
        aliases = sorted(set(alias for point in source_points for alias in (point.get("aliases") or [])))
        findings.append(make_finding(
            finding_type="GEOLOCATION_ARTIFACT_COORDINATES", severity=Severity.INFO,
            description=(
                f"One image artifact contains {len(source_points)} exact coordinate representation(s). "
                "The stored values are reported without treating them as independent locations or proof of physical presence."
            ),
            evidence_path=source_file or str(evidence_path),
            metadata={
                **deterministic_metadata(
                    "coordinate syntax/range parsing grouped by exact source SHA-256",
                    validators=["DMS/decimal parser", "geographic range validation", "source SHA-256 grouping"],
                    semantic_limit="Stored coordinate representations only; device/user presence and attribution require corroboration.",
                ),
                "source_file": source_file, "file_path": source_file,
                "file_sha256": content_key if len(content_key) == 64 else "",
                "source_aliases": aliases,
                "coordinate_representation_count": len(source_points),
                "coordinate_representations": source_points,
                "source_discrepancy_count": sum(
                    1 for idx, first in enumerate(source_points) for second in source_points[idx + 1:]
                    if first.get("coordinate_source") != second.get("coordinate_source")
                    and _distance_metres(first, second) > discrepancy_tolerance_m
                ),
            },
            artifact_path=(source_file if Path(source_file).is_file() else None),
        ))

    unique_points = coordinate_representations
    logger.info(
        "[%s] %d coordinate representation(s) across %d unique artifact(s)",
        MODULE_NAME, len(coordinate_representations), len(by_artifact),
    )

    # Write KML
    kml_path = output_dir / "gps_locations.kml"
    try:
        kml_path.write_text(_build_kml(unique_points), encoding="utf-8")
        artifact_paths.append(str(kml_path))
        logger.info("[%s] Wrote KML: %s", MODULE_NAME, kml_path)
    except OSError as exc:
        errors.append(f"Failed to write KML: {exc}")

    # Write GeoJSON
    geojson_path = output_dir / "gps_locations.geojson"
    try:
        with open(geojson_path, "w", encoding="utf-8") as f:
            json.dump(_build_geojson(points), f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(geojson_path))
        logger.info("[%s] Wrote GeoJSON: %s", MODULE_NAME, geojson_path)
    except OSError as exc:
        errors.append(f"Failed to write GeoJSON: {exc}")

    # Write summary
    summary_path = output_dir / "geolocation_summary.json"
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), "metadata_source": metadata_source, **stats,
                "points": unique_points,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(summary_path))
    except OSError as exc:
        errors.append(f"Failed to write geolocation_summary.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Extracted {stats['files_with_gps']} GPS coordinates "
        f"({stats['unique_locations']} unique locations); "
        f"KML and GeoJSON written."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    cr = ClassResult(
        locus=Locus.METADATA,
        artefact_class="Geolocation Data",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
        class_results=[cr],
    )
