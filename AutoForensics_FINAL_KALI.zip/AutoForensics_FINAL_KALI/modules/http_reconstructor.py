"""
http_reconstructor.py — HTTP Session Reconstructor for AutoForensics.

Uses ``tshark`` to extract and reconstruct HTTP sessions from PCAP files,
including:

  - HTTP requests (method, URI, host, user-agent, content-length)
  - HTTP responses (status code, content-type)
  - Exported HTTP file objects (binaries, scripts, documents downloaded)
  - POST form data (potential credential exfiltration)

Suspicious indicators include PowerShell/Wget user agents, executable downloads,
HTTP basic auth, large POST uploads, and IP-only hosts.

Target platform : Kali Linux, Python 3.11+
External tools  : tshark (wireshark-common package)
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.native_network import parse_http, public_record

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "http_reconstructor"
TSHARK_TIMEOUT: int = 3600

# User agents that are suspicious in a forensic context
_SUSPICIOUS_UA_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"powershell", re.IGNORECASE),
    re.compile(r"^wget\b", re.IGNORECASE),
    re.compile(r"^curl\b", re.IGNORECASE),
    re.compile(r"python-requests", re.IGNORECASE),
    re.compile(r"go-http-client", re.IGNORECASE),
    re.compile(r"nikto", re.IGNORECASE),
    re.compile(r"sqlmap", re.IGNORECASE),
    re.compile(r"nmap", re.IGNORECASE),
    re.compile(r"^-$"),   # Empty/dash UA
    re.compile(r"^$"),     # Completely empty
]

# MIME types of downloaded files that are high-risk
_HIGH_RISK_MIMES: frozenset[str] = frozenset({
    "application/x-dosexec", "application/x-msdownload",
    "application/x-executable", "application/x-elf",
    "application/x-shellscript", "application/x-sh",
    "application/x-msdos-program",
    "text/x-shellscript",
})

# Exfil threshold for POST body
HTTP_POST_EXFIL_BYTES: int = 1024 * 1024  # 1 MB

_RE_IP_ONLY_HOST = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _find_pcap_files(output_dir: Path, config: dict[str, Any]) -> list[Path]:
    files: list[Path] = []
    for pat in ("*.pcap", "*.pcapng", "*.cap"):
        files.extend(output_dir.rglob(pat))
    explicit = config.get("pcap_path", "")
    if explicit:
        p = Path(explicit)
        if p.is_file() and p not in files:
            files.append(p)
    for value in config.get("pcap_paths") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    ws = config.get("_working_set") or {}
    for value in ws.get("nested_network_sources") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    # Canonicalise and de-duplicate without assuming filenames.
    unique: list[Path] = []
    seen: set[str] = set()
    for p in files:
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _tshark_extract(
    pcap: Path,
    display_filter: str,
    fields: list[str],
    logger: logging.Logger,
) -> list[dict[str, str]]:
    cmd = ["tshark", "-r", str(pcap), "-Y", display_filter,
           "-T", "fields", "-E", "header=y", "-E", "separator=|"]
    for f in fields:
        cmd += ["-e", f]
    try:
        rc, stdout, _ = _run_subprocess(cmd, timeout=TSHARK_TIMEOUT, logger=logger)
        if not stdout.strip():
            return []
        lines = stdout.splitlines()
        if len(lines) < 2:
            return []
        headers = [h.strip() for h in lines[0].split("|")]
        rows: list[dict[str, str]] = []
        for line in lines[1:]:
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < len(headers):
                parts.extend([""] * (len(headers) - len(parts)))
            rows.append(dict(zip(headers, parts)))
        return rows
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _is_suspicious_ua(ua: str) -> bool:
    return any(pat.search(ua) for pat in _SUSPICIOUS_UA_PATTERNS)


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Reconstruct HTTP sessions from PCAP files.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing PCAP files.
    config        : Configuration dict; recognised key: ``pcap_path``.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with HTTP session analysis findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    pcap_files = _find_pcap_files(output_dir, config)
    if not pcap_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.NETWORK,
            artefact_class="HTTP Session Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
            notes="No PCAP files found in output directory.",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no PCAP files found.",
            class_results=[cr],
        )

    stats = {
        "total_requests": 0, "total_responses": 0,
        "files_extracted": 0, "suspicious_requests": 0,
        "unique_hosts": set(),
    }
    all_sessions: list[dict[str, Any]] = []

    for pcap in pcap_files:
        logger.info("[%s] Reconstructing HTTP from: %s", MODULE_NAME, pcap.name)

        # Native stream reconstruction is the authoritative baseline. It
        # catches split or repeated HTTP messages even when a tshark display
        # filter omits a later request on an already-established connection.
        native_messages = parse_http(pcap)
        native_requests = [m for m in native_messages if m.get("direction") == "request"]
        native_responses = [m for m in native_messages if m.get("direction") == "response"]

        # HTTP requests
        req_rows = _tshark_extract(
            pcap, "http.request",
            ["frame.number", "frame.time", "tcp.stream", "ip.src", "ip.dst",
             "tcp.srcport", "tcp.dstport", "http.request.method", "http.request.uri",
             "http.host", "http.user_agent", "http.content_type",
             "http.content_length"],
            logger,
        )
        # Merge independent parser views into one physical transaction. Frame
        # number is authoritative when available; the semantic fallback is used
        # only for captures/parsers that do not expose it.
        def _request_key(row: dict[str, Any]) -> tuple[Any, ...]:
            frame = str(row.get("frame.number") or "").strip()
            if frame.isdigit() and int(frame) > 0:
                return ("frame", int(frame))
            return (
                "semantic", str(row.get("http.request.method") or "").upper(),
                str(row.get("http.request.uri") or ""), str(row.get("ip.src") or ""),
                str(row.get("ip.dst") or ""), str(row.get("tcp.stream") or ""),
            )

        req_by_key: dict[tuple[Any, ...], dict[str, Any]] = {}
        for row in req_rows:
            row["parser_sources"] = ["tshark"]
            req_by_key[_request_key(row)] = row
        for msg in native_requests:
            public = public_record(msg)
            row = {
                "frame.time": str(public.get("timestamp") or ""), "frame.number": str(public.get("frame_number") or ""),
                "ip.src": str(public.get("src_ip") or ""), "ip.dst": str(public.get("dst_ip") or ""),
                "tcp.srcport": str(public.get("src_port") or ""), "tcp.dstport": str(public.get("dst_port") or ""),
                "http.request.method": str(public.get("method") or ""), "http.request.uri": str(public.get("uri") or ""),
                "http.host": str(public.get("host") or ""), "http.user_agent": str((public.get("headers") or {}).get("user-agent") or ""),
                "http.content_length": str(public.get("content_length") or ""),
                "http.content_type": str((public.get("headers") or {}).get("content-type") or ""),
                "http.body_text": str(public.get("body_text") or ""), "http.body_sha256": str(public.get("body_sha256") or ""),
                "capture_offset": public.get("capture_offset"), "stream_offset": public.get("stream_offset"),
                "native_parser": True,
            }
            row["parser_sources"] = ["native_http_parser"]
            key = _request_key(row)
            prior = req_by_key.get(key)
            if prior is not None:
                merged = dict(prior)
                merged.update({k: v for k, v in row.items() if v not in (None, "", [], {})})
                merged["parser_sources"] = sorted(set((prior.get("parser_sources") or []) + row["parser_sources"]))
                req_by_key[key] = merged
            else:
                req_by_key[key] = row
        req_rows = list(req_by_key.values())
        stats["total_requests"] += len(req_rows)
        for row in req_rows:
            host = row.get("http.host", "")
            ua = row.get("http.user_agent", "")
            method = row.get("http.request.method", "")
            uri = row.get("http.request.uri", "")

            if host:
                stats["unique_hosts"].add(host)

            # Suspicious user agent
            if ua and _is_suspicious_ua(ua):
                stats["suspicious_requests"] += 1
                exact = {**deterministic_metadata(
                    "HTTP User-Agent field decoded from retained payload", validators=["native HTTP parser/tshark"],
                    semantic_limit="The exact User-Agent is established; suspiciousness is contextual."),
                    **row, "pcap_file": pcap.name, "user_agent": ua}
                findings.append(make_finding(
                    finding_type="HTTP_USER_AGENT_OBSERVED", severity=Severity.INFO,
                    description=f"HTTP User-Agent '{ua[:100]}' was decoded for a request to {host}.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="SUSPICIOUS_USER_AGENT_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"User-Agent '{ua[:100]}' matched a review pattern.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "configured User-Agent pattern", reason="A User-Agent string alone cannot establish malicious activity.")}))

            # IP-only host (no domain)
            if host and _RE_IP_ONLY_HOST.match(host):
                exact = {**deterministic_metadata(
                    "HTTP Host grammar and IP-literal validation", validators=["HTTP parser", "IPv4 literal parser"],
                    semantic_limit="An IP-literal Host is established; maliciousness is not implied."),
                    **row, "pcap_file": pcap.name, "host_kind": "ip_literal"}
                findings.append(make_finding(
                    finding_type="HTTP_IP_LITERAL_HOST_OBSERVED", severity=Severity.INFO,
                    description=f"HTTP request used IP-literal Host '{host}'.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="HTTP_IP_HOST_RISK_CANDIDATE", severity=Severity.LOW,
                    description=f"IP-literal Host '{host}' is retained for contextual review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "IP-literal Host rule", reason="IP-literal HTTP hosts can be legitimate and do not establish maliciousness.")}))

            # Large POST (data exfil)
            if method == "POST":
                try:
                    cl = int(row.get("http.content_length") or 0)
                except ValueError:
                    cl = 0
                if cl > HTTP_POST_EXFIL_BYTES:
                    exact = {**deterministic_metadata(
                        "HTTP Content-Length decoded as an integer", validators=["HTTP parser"],
                        semantic_limit="The POST size is established; exfiltration is not established by size alone."),
                        **row, "pcap_file": pcap.name, "post_length_bytes": cl}
                    findings.append(make_finding(
                        finding_type="HTTP_POST_SIZE_OBSERVED", severity=Severity.INFO,
                        description=f"HTTP POST to {host}{uri} declared {cl} bytes.",
                        evidence_path=str(evidence_path), metadata=exact))
                    findings.append(make_finding(
                        finding_type="HTTP_EXFILTRATION_CANDIDATE", severity=Severity.MEDIUM,
                        description=f"The {cl}-byte POST is retained for exfiltration review.",
                        evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                            "POST-size threshold", reason="Payload volume alone cannot establish exfiltration.")}))

            request_record = {**row, "pcap_file": pcap.name, "direction": "request"}
            all_sessions.append(request_record)
            findings.append(make_finding(
                finding_type="HTTP_TRANSACTION", severity=Severity.INFO,
                description=f"Decoded HTTP request {method or '?'} {host}{uri} from retained packet data.",
                evidence_path=str(pcap), artifact_path=str(pcap),
                metadata={**deterministic_metadata("HTTP request fields decoded from TCP payload", validators=[str(v) for v in (row.get("parser_sources") or ["native HTTP/1.x stream parser" if row.get("native_parser") else "tshark HTTP dissector"])]),
                          **request_record},
            ))

        # HTTP responses
        resp_rows = _tshark_extract(
            pcap, "http.response",
            ["frame.number", "frame.time", "tcp.stream", "ip.src", "ip.dst",
             "tcp.srcport", "tcp.dstport", "http.response.code",
             "http.content_type", "http.content_length", "http.www_authenticate"],
            logger,
        )
        def _response_key(row: dict[str, Any]) -> tuple[Any, ...]:
            frame = str(row.get("frame.number") or "").strip()
            if frame.isdigit() and int(frame) > 0:
                return ("frame", int(frame))
            return (
                "semantic", str(row.get("http.response.code") or ""),
                str(row.get("ip.src") or ""), str(row.get("ip.dst") or ""),
                str(row.get("tcp.stream") or ""),
            )

        resp_by_key: dict[tuple[Any, ...], dict[str, Any]] = {}
        for row in resp_rows:
            row["parser_sources"] = ["tshark"]
            resp_by_key[_response_key(row)] = row
        for msg in native_responses:
            public = public_record(msg)
            row = {
                "frame.time": str(public.get("timestamp") or ""), "frame.number": str(public.get("frame_number") or ""),
                "ip.src": str(public.get("src_ip") or ""), "ip.dst": str(public.get("dst_ip") or ""),
                "http.response.code": str(public.get("status_code") or ""),
                "http.content_type": str((public.get("headers") or {}).get("content-type") or ""),
                "http.content_length": str(public.get("content_length") or ""),
                "http.www_authenticate": str((public.get("headers") or {}).get("www-authenticate") or ""),
                "http.body_text": str(public.get("body_text") or ""), "http.body_sha256": str(public.get("body_sha256") or ""),
                "capture_offset": public.get("capture_offset"), "stream_offset": public.get("stream_offset"),
                "native_parser": True,
            }
            row["parser_sources"] = ["native_http_parser"]
            key = _response_key(row)
            prior = resp_by_key.get(key)
            if prior is not None:
                merged = dict(prior)
                merged.update({k: v for k, v in row.items() if v not in (None, "", [], {})})
                merged["parser_sources"] = sorted(set((prior.get("parser_sources") or []) + row["parser_sources"]))
                resp_by_key[key] = merged
            else:
                resp_by_key[key] = row
        resp_rows = list(resp_by_key.values())
        stats["total_responses"] += len(resp_rows)
        for row in resp_rows:
            ct = row.get("http.content_type", "").lower()
            auth = row.get("http.www_authenticate", "").lower()
            code = row.get("http.response.code", "")
            response_record = {**row, "pcap_file": pcap.name, "direction": "response"}
            all_sessions.append(response_record)
            findings.append(make_finding(
                finding_type="HTTP_TRANSACTION", severity=Severity.INFO,
                description=f"Decoded HTTP response status {code or '?'} from retained packet data.",
                evidence_path=str(pcap), artifact_path=str(pcap),
                metadata={**deterministic_metadata("HTTP response fields decoded from TCP payload", validators=[str(v) for v in (row.get("parser_sources") or ["native HTTP/1.x stream parser" if row.get("native_parser") else "tshark HTTP dissector"])]),
                          **response_record},
            ))

            # Executable content download
            if any(m in ct for m in ("x-dosexec", "x-msdownload", "x-executable", "x-sh",
                                      "octet-stream")):
                stats["suspicious_requests"] += 1
                exact = {**deterministic_metadata(
                    "HTTP Content-Type decoded from retained response", validators=["native HTTP parser/tshark"],
                    semantic_limit="The declared MIME type is established; actual file structure and maliciousness require separate validation."),
                    **row, "pcap_file": pcap.name, "declared_content_type": ct}
                findings.append(make_finding(
                    finding_type="HTTP_CONTENT_TYPE_OBSERVED", severity=Severity.INFO,
                    description=f"HTTP response declared Content-Type '{ct}'.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="HTTP_EXECUTABLE_CONTENT_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"Declared executable-like MIME type '{ct}' is retained for structural file review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "executable MIME lookup", reason="MIME declarations can be inaccurate or benign; body structure must be validated.")}))

            # HTTP basic auth
            if auth.startswith("basic") and code == "401":
                findings.append(make_finding(
                    finding_type="HTTP_CLEARTEXT_AUTH",
                    severity=Severity.MEDIUM,
                    description=(
                        f"HTTP Basic Authentication challenge from {row.get('ip.src', '?')} "
                        f"in {pcap.name} — credentials sent in cleartext if client complies."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={**row, "pcap_file": pcap.name},
                ))

        # Export HTTP objects
        obj_dir = output_dir / "http_objects" / pcap.stem
        obj_dir.mkdir(parents=True, exist_ok=True)
        try:
            rc, _, _ = _run_subprocess(
                ["tshark", "-r", str(pcap), "--export-objects", f"http,{obj_dir}"],
                timeout=TSHARK_TIMEOUT, logger=logger,
            )
            extracted = [f for f in obj_dir.iterdir() if f.is_file()]
            stats["files_extracted"] += len(extracted)
            artifact_paths.extend(str(f) for f in extracted)
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            # Object export is optional enrichment. Native deterministic HTTP
            # reconstruction remains complete when the retained TCP payloads
            # were parsed successfully.
            warnings.append(f"Optional tshark export-objects unavailable for {pcap.name}: {exc}")

    stats["unique_hosts"] = len(stats["unique_hosts"])  # type: ignore[assignment]

    # Write sessions report
    report_path = output_dir / "http_sessions.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "sessions": all_sessions,
                "warnings": warnings,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write http_sessions.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"HTTP analysis: {stats['total_requests']} requests, "
        f"{stats['files_extracted']} objects extracted, "
        f"{stats['suspicious_requests']} suspicious requests."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.NETWORK,
        artefact_class="HTTP Session Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={**stats, "warnings": warnings}, summary=summary,
        class_results=[cr],
    )
