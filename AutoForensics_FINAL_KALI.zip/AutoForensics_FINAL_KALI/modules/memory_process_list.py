"""
memory_process_list.py — Memory Process Listing Module for AutoForensics.

Uses Volatility 3 to enumerate all running processes from a memory dump.  Two
plugins are executed to cross-validate results:

  windows.pslist.PsList  — walks the EPROCESS doubly-linked list
  windows.psscan.PsScan  — pool-tag scan (finds DKOM-hidden processes)

Processes present in PsScan but absent from PsList are flagged as potentially
hidden via Direct Kernel Object Manipulation (DKOM), a common rootkit technique.
Additional heuristics identify singleton-process violations and suspicious parent
relationships.

Target platform : Kali Linux, Python 3.11+
External tools  : python3 /opt/volatility3/vol.py (Volatility 3)
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.volatility_adapter import run_volatility_plugin

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    assert_subprocess_ok,
    find_memory_source,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "memory_process_list"
VOL_TIMEOUT: int = 3600   # 1 hour per plugin

# Processes expected to be singletons (only one instance)
_SINGLETON_PROCESSES: frozenset[str] = frozenset({
    "lsass.exe", "lsm.exe", "wininit.exe", "services.exe",
    "smss.exe", "csrss.exe",
})

# Expected parent processes — key: child name → acceptable parent names
_EXPECTED_PARENTS: dict[str, frozenset[str]] = {
    "svchost.exe": frozenset({"services.exe"}),
    "lsass.exe":   frozenset({"wininit.exe"}),
    "services.exe": frozenset({"wininit.exe"}),
    "explorer.exe": frozenset({"userinit.exe", "winlogon.exe"}),
    "taskmgr.exe":  frozenset({"winlogon.exe", "explorer.exe"}),
}


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _run_vol_plugin(
    vol_path: str,
    evidence_path: Path,
    plugin: str,
    logger: logging.Logger,
) -> tuple[int, str, str]:
    """
    Execute a Volatility 3 plugin against the memory image.

    Parameters
    ----------
    vol_path      : Path to vol.py (e.g. /opt/volatility3/vol.py).
    evidence_path : Path to memory dump file.
    plugin        : Plugin name (e.g. windows.pslist.PsList).
    logger        : Module logger.

    Returns
    -------
    Tuple of (returncode, stdout, stderr).

    Raises
    ------
    FileNotFoundError    If python3 or vol.py cannot be found.
    subprocess.TimeoutExpired  If the plugin exceeds VOL_TIMEOUT.
    """
    execution = run_volatility_plugin(
        evidence_path=evidence_path, plugin=plugin,
        config={"vol_path": vol_path}, timeout=VOL_TIMEOUT,
    )
    logger.debug("Volatility command: %s", execution.command)
    return execution.returncode, execution.stdout, execution.stderr


def _parse_vol_tsv(output: str) -> list[dict[str, str]]:
    """
    Parse Volatility 3 tab-separated output into a list of dicts.

    Volatility 3 emits a header row followed by data rows, separated by tabs.
    Comment lines (starting with '#' or 'Volatility') are skipped.

    Parameters
    ----------
    output : Raw stdout from a Volatility 3 plugin.

    Returns
    -------
    List of dicts, one per data row, keyed by header column names.
    """
    rows: list[dict[str, str]] = []
    headers: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("Volatility"):
            continue
        parts = stripped.split("\t")
        if not headers:
            headers = [h.strip() for h in parts]
            continue
        if len(parts) < len(headers):
            parts.extend([""] * (len(headers) - len(parts)))
        rows.append(dict(zip(headers, [p.strip() for p in parts])))
    return rows


def _build_process_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    """
    Build a PID → process record map from parsed Volatility output.

    Parameters
    ----------
    rows : Parsed process list rows.

    Returns
    -------
    Dict mapping PID string → row dict.
    """
    return {r.get("PID", r.get("pid", "")): r for r in rows if r.get("PID") or r.get("pid")}


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    List and analyse processes from a memory dump using Volatility 3.

    Parameters
    ----------
    evidence_path : Absolute path to the memory dump (.raw, .mem, .vmem, .lime).
    case_id       : Unique case identifier.
    output_dir    : Directory where reports are written.
    config        : Configuration dict; recognised keys:
                    - ``vol_path`` (str): path to vol.py
                      (default: /opt/volatility3/vol.py).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with HIDDEN_PROCESS_DKOM and SUSPICIOUS_PROCESS_PARENT findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    vol_path = config.get("vol_path", "/opt/volatility3/vol.py")

    mem_source = find_memory_source(evidence_path, output_dir, config)
    if mem_source is None:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Memory Process List",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
        )
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            summary="SKIPPED — no memory image supplied for this evidence item (no .raw/.lime/.dmp/.vmem found; no hiberfil.sys/pagefile.sys carved)",
            findings=[],
            errors=[],
            statistics={},
            class_results=[cr],
        )
    # Use mem_source for all Volatility calls
    evidence_path = mem_source

    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Run PsList
    # ------------------------------------------------------------------
    pslist_rows: list[dict[str, str]] = []
    pslist_txt = output_dir / "process_list_pslist.txt"
    try:
        rc, stdout, stderr = _run_vol_plugin(
            vol_path, evidence_path, "windows.pslist.PsList", logger)
        pslist_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(pslist_txt))
        plugin = "windows.pslist.PsList"
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Process List",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                findings=[], statistics={},
                class_results=[cr],
            )
        if stdout.strip():
            pslist_rows = _parse_vol_tsv(stdout)
            logger.info("[%s] PsList: %d processes", MODULE_NAME, len(pslist_rows))
    except FileNotFoundError:
        errors.append(f"Volatility 3 not found at {vol_path}")
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Memory Process List",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=errors, summary=f"Skipped: Volatility 3 not found at {vol_path}",
            class_results=[cr],
        )
    except subprocess.TimeoutExpired:
        errors.append("PsList timed out")

    # ------------------------------------------------------------------
    # Run PsScan
    # ------------------------------------------------------------------
    psscan_rows: list[dict[str, str]] = []
    psscan_txt = output_dir / "process_list_psscan.txt"
    try:
        rc, stdout, stderr = _run_vol_plugin(
            vol_path, evidence_path, "windows.psscan.PsScan", logger)
        psscan_txt.write_text(stdout, encoding="utf-8", errors="replace")
        artifact_paths.append(str(psscan_txt))
        plugin = "windows.psscan.PsScan"
        try:
            assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
        except RuntimeError as exc:
            errors.append(str(exc))
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Process List",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                findings=[], statistics={},
                class_results=[cr],
            )
        if stdout.strip():
            psscan_rows = _parse_vol_tsv(stdout)
            logger.info("[%s] PsScan: %d processes", MODULE_NAME, len(psscan_rows))
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        errors.append(f"PsScan error: {exc}")

    # ------------------------------------------------------------------
    # Exact process records and candidate interpretations
    # ------------------------------------------------------------------
    for view_name, rows in (("PsList", pslist_rows), ("PsScan", psscan_rows)):
        for row in rows:
            pid = str(row.get("PID") or "")
            proc_name = str(row.get("ImageFileName") or row.get("Name") or "unknown")
            findings.append(make_finding(
                finding_type="MEMORY_PROCESS_RECORD", severity=Severity.INFO,
                description=f"{view_name} reported process '{proc_name}' with PID {pid or '?' }.",
                evidence_path=str(evidence_path),
                metadata={**deterministic_metadata(
                    "Volatility process-table record", validators=[f"Volatility 3 {view_name}"],
                    semantic_limit="The record is attributed to the successful structural view only; maliciousness is not inferred."),
                    "view": view_name, "pid": pid, "image_name": proc_name,
                    "ppid": row.get("PPID", ""), "offset": row.get("Offset(V)", ""),
                    "record": row},
            ))

    pslist_pids = {str(r.get("PID", "")) for r in pslist_rows}
    psscan_pids = {str(r.get("PID", "")) for r in psscan_rows}
    hidden_pids = psscan_pids - pslist_pids
    for pid in sorted(hidden_pids):
        if not pid or pid == "0":
            continue
        entry = next((r for r in psscan_rows if str(r.get("PID", "")) == pid), {})
        proc_name = str(entry.get("ImageFileName") or entry.get("Name") or "unknown")
        exact = {
            **deterministic_metadata(
                "cross-view set difference", validators=["Volatility 3 PsScan", "Volatility 3 PsList"],
                semantic_limit="A cross-view discrepancy is established; DKOM or rootkit causation is not established."),
            "pid": pid, "image_name": proc_name, "ppid": entry.get("PPID", ""),
            "offset": entry.get("Offset(V)", ""), "present_in": ["PsScan"], "absent_from": ["PsList"],
        }
        findings.append(make_finding(
            finding_type="PROCESS_CROSS_VIEW_DISCREPANCY", severity=Severity.MEDIUM,
            description=f"PID {pid} ('{proc_name}') was present in PsScan and absent from PsList.",
            evidence_path=str(evidence_path), metadata=exact))
        findings.append(make_finding(
            finding_type="ROOTKIT_DKOM_CANDIDATE", severity=Severity.MEDIUM,
            description=f"Cross-view discrepancy for PID {pid} is retained as a possible hidden-process interpretation.",
            evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                "PsScan/PsList discrepancy",
                reason="A cross-view difference can also result from process termination, acquisition state, symbols or parser limitations; structural corroboration is required.")}))

    proc_name_counts: dict[str, int] = {}
    for row in pslist_rows:
        name = str(row.get("ImageFileName") or row.get("Name") or "").lower()
        if name:
            proc_name_counts[name] = proc_name_counts.get(name, 0) + 1
    for name, count in proc_name_counts.items():
        if name in _SINGLETON_PROCESSES and count > 1:
            exact = {**deterministic_metadata(
                "exact process-name count in PsList", validators=["Volatility 3 PsList"],
                semantic_limit="The count is exact for this parsed view; masquerading is not established."),
                "process_name": name, "instance_count": count}
            findings.append(make_finding(
                finding_type="PROCESS_INSTANCE_COUNT", severity=Severity.INFO,
                description=f"PsList contained {count} record(s) named '{name}'.",
                evidence_path=str(evidence_path), metadata=exact))
            findings.append(make_finding(
                finding_type="PROCESS_MASQUERADING_CANDIDATE", severity=Severity.MEDIUM,
                description=f"Multiple '{name}' records are retained for contextual review.",
                evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                    "singleton-process expectation",
                    reason="Expected singleton behaviour varies by OS build, session state and parser context.")}))

    pid_to_name = {str(r.get("PID", "")): str(r.get("ImageFileName") or r.get("Name") or "").lower() for r in pslist_rows}
    for row in pslist_rows:
        child_name = str(row.get("ImageFileName") or row.get("Name") or "").lower()
        ppid, pid = str(row.get("PPID", "")), str(row.get("PID", ""))
        if child_name in _EXPECTED_PARENTS:
            parent_name = pid_to_name.get(ppid, "").lower()
            expected = sorted(_EXPECTED_PARENTS[child_name])
            if parent_name and parent_name not in expected:
                exact = {**deterministic_metadata(
                    "exact PsList parent/child fields", validators=["Volatility 3 PsList"],
                    semantic_limit="The parent relationship is established; suspiciousness is contextual and remains a candidate."),
                    "child_name": child_name, "child_pid": pid, "parent_name": parent_name,
                    "parent_pid": ppid, "reference_expected_parents": expected}
                findings.append(make_finding(
                    finding_type="PROCESS_PARENT_RELATIONSHIP", severity=Severity.INFO,
                    description=f"'{child_name}' (PID {pid}) records parent '{parent_name}' (PID {ppid}).",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="SUSPICIOUS_PROCESS_PARENT_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"The parent relationship for '{child_name}' is retained for contextual review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "expected-parent reference table",
                        reason="Parent expectations vary by OS build, service configuration and process lifecycle.")}))

    # ------------------------------------------------------------------
    # Write JSON summary
    # ------------------------------------------------------------------
    summary_path = output_dir / "process_list.json"
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME,
                "case_id": case_id,
                "generated_at": utc_now(),
                "pslist_count": len(pslist_rows),
                "psscan_count": len(psscan_rows),
                "hidden_process_count": len(hidden_pids),
                "pslist": pslist_rows,
                "psscan": psscan_rows,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(summary_path))
    except OSError as exc:
        errors.append(f"Failed to write process_list.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    if not pslist_rows and not psscan_rows:
        status = ModuleStatus.FAILED

    summary = (
        f"PsList: {len(pslist_rows)} processes, PsScan: {len(psscan_rows)} processes; "
        f"{len(hidden_pids)} DKOM-hidden, {len(findings)} total findings."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED" if status != ModuleStatus.FAILED else "MODULE_FAILED",
             {"module": MODULE_NAME, "case_id": case_id, "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.MEMORY,
        artefact_class="Memory Process List",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics={
            "total_processes": len(pslist_rows),
            "suspicious_count": len(findings),
            "hidden_processes": len(hidden_pids),
            "psscan_count": len(psscan_rows),
        },
        summary=summary,
        class_results=[cr],
    )
