"""Evidence integrity validation over the logical media stream.

For E01 evidence this module hashes the reconstructed, decompressed media bytes
and compares them with hash/digest sections parsed from the container.  It never
compares a raw compressed container hash with a media-level acquisition hash.
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any

from core.native_evidence import EvidenceFormatError, hash_media_stream, independent_sha256
from core.deterministic_validation import deterministic_metadata
from core.evidence_declaration import discover_evidence_declarations
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

MODULE_NAME = "evidence_validator"


def _hash_source_container(path: Path) -> dict[str, Any]:
    """Hash the supplied source container bytes without reconstructing media."""
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            size += len(block)
            md5.update(block); sha1.update(block); sha256.update(block)
    return {
        "path": str(path), "size_bytes": size, "hash_basis": "source-file-bytes",
        "md5": md5.hexdigest(), "sha1": sha1.hexdigest(), "sha256": sha256.hexdigest(),
    }


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start = utc_now()
    t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    findings = []
    errors: list[str] = []

    evidence_path = Path(evidence_path).resolve()
    if not evidence_path.exists():
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(),
            duration_seconds=time.monotonic() - t0,
            errors=[f"Evidence not found: {evidence_path}"],
            summary="DID NOT RUN — evidence file not found.",
            class_results=[ClassResult(
                locus=Locus.HASH_VERIFY,
                artefact_class="Evidence Hash Integrity",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE,
                count=0,
            )],
        )

    try:
        source_container = _hash_source_container(evidence_path)
        result = hash_media_stream(evidence_path)
        md5 = str(result["md5"])
        sha1 = str(result["sha1"])
        sha256 = str(result["sha256"])
        size = int(result["size_bytes"])
        embedded = dict(result.get("embedded_hashes") or {})
        matches = dict(result.get("embedded_hash_matches") or {})
        metadata = dict(result.get("metadata") or {})
        warnings = list(result.get("warnings") or [])
        stream_type = str(result.get("stream_type") or "unknown")

        # Hard invariant: a top-line SHA-256 is publishable only after a second,
        # independently chunked pass reaches the same value.
        second_sha256 = independent_sha256(evidence_path)
        self_test_match = second_sha256 == sha256
    except (OSError, EvidenceFormatError, ValueError) as exc:
        error = f"Logical-media hash validation failed: {exc}"
        logger.error(error)
        errors.append(error)
        manifest = {
            "module": MODULE_NAME,
            "case_id": case_id,
            "generated_at": utc_now(),
            "execution_outcome": "did_not_run",
            "reason": error,
            "evidence_path": str(evidence_path),
            "findings": 0,
            "errors": errors,
        }
        mp = output_dir / "evidence_validator_manifest.json"
        mp.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(),
            duration_seconds=time.monotonic() - t0,
            artifact_paths=[str(mp)], errors=errors,
            summary=f"DID NOT RUN — {error}",
            class_results=[ClassResult(
                locus=Locus.HASH_VERIFY,
                artefact_class="Evidence Hash Integrity",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.PARTIAL_FAILURE,
                count=0,
            )],
        )

    mismatches = {algo: embedded.get(algo, "") for algo, ok in matches.items() if not ok}
    verified_embedded = {algo: embedded.get(algo, "") for algo, ok in matches.items() if ok}

    findings.append(make_finding(
        finding_type="SOURCE_CONTAINER_HASH_COMPUTED",
        severity=Severity.INFO,
        description=(
            f"The supplied source container '{evidence_path.name}' was hashed byte-for-byte "
            f"({source_container['size_bytes']:,} bytes). SHA-256: "
            f"{source_container['sha256'][:16]}…. This examination hash is not an "
            "embedded EWF media-digest comparison."
        ),
        evidence_path=str(evidence_path),
        metadata={
            "source_container_path": str(evidence_path),
            "source_container_md5": source_container["md5"],
            "source_container_sha1": source_container["sha1"],
            "source_container_sha256": source_container["sha256"],
            "file_sha256": source_container["sha256"],
            "source_offset_cluster_packet_or_row": "entire source-container byte stream",
            "source_container_size_bytes": source_container["size_bytes"],
            "hash_scope": "source_container_bytes",
            "hash_basis": source_container["hash_basis"],
            **deterministic_metadata(
                "byte-for-byte hashing of the supplied source container",
                validators=["hashlib MD5", "hashlib SHA-1", "hashlib SHA-256"],
            ),
        },
    ))

    if self_test_match:
        findings.append(make_finding(
            finding_type="EVIDENCE_MEDIA_HASH_COMPUTED",
            severity=Severity.INFO,
            description=(
                f"Logical media for '{evidence_path.name}' was hashed natively "
                f"({size:,} bytes). SHA-256: {sha256[:16]}…; independent self-test: PASS."
            ),
            evidence_path=str(evidence_path),
            metadata={
                "md5": md5, "sha1": sha1, "sha256": sha256,
                "independent_sha256": second_sha256,
                "source_container_sha256": source_container["sha256"],
                "source_offset_cluster_packet_or_row": "logical media stream reconstructed from all EWF chunks",
                "self_test_match": True,
                "stream_type": stream_type,
                "size_bytes": size,
                **deterministic_metadata("two independent logical-media hash passes", validators=["core.native_evidence.hash_media_stream", "core.native_evidence.independent_sha256"]),
            },
        ))
    else:
        findings.append(make_finding(
            finding_type="EVIDENCE_HASH_SELF_TEST_FAILED",
            severity=Severity.HIGH,
            description=(
                "Independent SHA-256 recomputation did not match the top-line claim. "
                "The hash is withheld from clean verification and the evidence stream "
                "must be treated as indeterminate."
            ),
            evidence_path=str(evidence_path),
            metadata={"first_sha256": sha256, "independent_sha256": second_sha256},
        ))

    for algo, digest in sorted(verified_embedded.items()):
        findings.append(make_finding(
            finding_type="EWF_EMBEDDED_HASH_MATCH",
            severity=Severity.INFO,
            description=(
                f"Computed {algo.upper()} of the reconstructed media matches the "
                "digest embedded in the EWF container."
            ),
            evidence_path=str(evidence_path),
            metadata={"algorithm": algo, "computed": result[algo], "embedded": digest,
                      "source_container_sha256": source_container["sha256"],
                      "source_offset_cluster_packet_or_row": f"EWF embedded {algo} digest/hash section",
                      **deterministic_metadata("computed logical-media digest equals embedded EWF digest", validators=["native EWF digest parser", "exact digest equality"])},
        ))

    for algo, digest in sorted(mismatches.items()):
        findings.append(make_finding(
            finding_type="EVIDENCE_HASH_MISMATCH",
            severity=Severity.HIGH,
            description=(
                f"Computed {algo.upper()} of the reconstructed media does not match "
                "the digest embedded in the EWF container."
            ),
            evidence_path=str(evidence_path),
            metadata={"algorithm": algo, "computed": result.get(algo, ""), "embedded": digest,
                      "source_container_sha256": source_container["sha256"],
                      "source_offset_cluster_packet_or_row": f"EWF embedded {algo} digest/hash section",
                      **deterministic_metadata("computed logical-media digest differs from embedded EWF digest", validators=["native EWF digest parser", "exact digest comparison"])},
        ))

    declarations = discover_evidence_declarations(config)
    if declarations:
        declaration_rows = [item.as_dict() for item in declarations]
        first = declarations[0]
        findings.append(make_finding(
            finding_type="SYNTHETIC_VALIDATION_DECLARATION",
            severity=Severity.INFO,
            description=(
                f"Runtime-discovered evidence text explicitly describes the supplied material as "
                f"synthetic, fabricated, training, test, demonstration, or validation data in "
                f"{len(declarations)} retained source(s)."
            ),
            evidence_path=first.path,
            artifact_path=first.path,
            metadata={
                "file_sha256": first.sha256,
                "byte_offset": first.byte_offset,
                "encoding": first.encoding,
                "primary_source": first.as_dict(),
                "supporting_sources": declaration_rows,
                "declaration_count": len(declarations),
                "provenance_invariant": "Each supporting path, SHA-256, excerpt, encoding and offset belongs to the same retained source object.",
                "semantic_limit": "The declaration describes the evidence set; it does not validate every embedded statement or artefact.",
                **deterministic_metadata(
                    "explicit self-declaration parsed from runtime-discovered evidence text",
                    validators=["content-based text discovery", "exact excerpt retention", "source SHA-256"],
                ),
            },
        ))

    if stream_type == "ewf" and not embedded:
        warnings.append("EWF parsed, but no supported embedded digest/hash value was present")
        findings.append(make_finding(
            finding_type="EWF_EMBEDDED_HASH_UNAVAILABLE",
            severity=Severity.LOW,
            description=(
                "Logical-media hashes were computed successfully, but no supported "
                "embedded EWF digest was available for acquisition-hash comparison."
            ),
            evidence_path=str(evidence_path),
            metadata={"stream_type": stream_type},
        ))

    clean = self_test_match and not mismatches
    if not self_test_match:
        outcome = "ran_with_caveat"
        verdict = AssuranceVerdict.INDETERMINATE
        skip_reason = SkipReason.PARTIAL_FAILURE
    elif mismatches:
        outcome = "ran_found_x"
        verdict = AssuranceVerdict.PRESENT
        skip_reason = None
    elif warnings or (stream_type == "ewf" and not embedded):
        outcome = "ran_with_caveat"
        verdict = AssuranceVerdict.PRESENT
        skip_reason = None
    else:
        outcome = "ran_found_x" if findings else "ran_found_nothing"
        verdict = AssuranceVerdict.PRESENT
        skip_reason = None

    manifest = {
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "execution_outcome": outcome,
        "hash_scope": "separate_source_container_and_logical_media",
        "source_container": source_container,
        "logical_media": {
            "md5": md5, "sha1": sha1,
            "sha256": sha256 if self_test_match else None,
            "first_pass_sha256": sha256,
            "independent_sha256": second_sha256,
            "self_test_match": self_test_match,
            "size_bytes": size,
        },
        "stream_type": stream_type,
        "md5": md5,
        "sha1": sha1,
        "sha256": sha256 if self_test_match else None,
        "first_pass_sha256": sha256,
        "independent_sha256": second_sha256,
        "self_test_match": self_test_match,
        "embedded_hashes": embedded,
        "embedded_hash_matches": matches,
        "size_bytes": size,
        "evidence_path": str(evidence_path),
        "ewf_metadata": metadata,
        "warnings": warnings,
        "findings": len(findings),
        "errors": errors,
    }
    mp = output_dir / "evidence_validator_manifest.json"
    mp.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    # The manifest binds the reconstructed-media digests, embedded references,
    # comparison results and source path. Retain it on every integrity finding
    # so the H2 assurance gate can independently verify the observation.
    for finding in findings:
        finding.metadata.setdefault("report_file", str(mp))
        if str(finding.finding_type) == "SYNTHETIC_VALIDATION_DECLARATION":
            # The declaration's retained artefact must be the exact source text,
            # not the module summary manifest.  This prevents path/hash/reference
            # cross-wiring during H2 assurance.
            finding.artifact_path = str(finding.evidence_path)
            finding.metadata["retained_source_path"] = str(finding.evidence_path)
        else:
            finding.artifact_path = str(mp)

    if mismatches:
        summary = (
            f"RAN AND FOUND {len(mismatches)} embedded-hash mismatch(es); "
            f"logical media size={size:,} bytes."
        )
    elif warnings:
        summary = (
            f"RAN WITH CAVEAT — media hashes computed and self-tested; "
            f"{'; '.join(warnings[:2])}."
        )
    else:
        summary = (
            f"RAN AND VERIFIED {len(findings)} integrity result(s) — logical-media "
            f"SHA-256={sha256[:16]}…; independent self-test PASS; size={size:,} bytes."
        )

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=ModuleStatus.COMPLETED if clean else ModuleStatus.PARTIAL,
        start_time=start,
        end_time=utc_now(),
        duration_seconds=time.monotonic() - t0,
        findings=findings,
        artifact_paths=[str(mp)],
        errors=errors,
        statistics={
            "source_container_md5": source_container["md5"],
            "source_container_sha1": source_container["sha1"],
            "source_container_sha256": source_container["sha256"],
            "source_container_size_bytes": source_container["size_bytes"],
            "logical_media_md5": md5,
            "logical_media_sha1": sha1,
            "logical_media_sha256": sha256 if self_test_match else "",
            "md5": md5,
            "sha1": sha1,
            "sha256": sha256 if self_test_match else "",
            "first_pass_sha256": sha256,
            "independent_sha256": second_sha256,
            "hash_self_test_match": self_test_match,
            "embedded_hash_matches": matches,
            # Backward-compatible aggregate field.
            "ewf_hash_match": (all(matches.values()) if matches else None),
            "size_bytes": size,
            "execution_outcome": outcome,
        },
        summary=summary,
        class_results=[ClassResult(
            locus=Locus.HASH_VERIFY,
            artefact_class="Evidence Hash Integrity",
            verdict=verdict,
            skip_reason=skip_reason,
            count=len(mismatches) if mismatches else (1 if self_test_match else 0),
        )],
    )
