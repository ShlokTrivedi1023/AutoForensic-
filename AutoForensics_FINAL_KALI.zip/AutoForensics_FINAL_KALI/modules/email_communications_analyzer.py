"""
email_communications_analyzer.py — Email and Instant Messenger Forensics Module.

Analyzes email artifacts found in the evidence image:
  - DBX files (Outlook Express) — parse message headers, body, attachments
  - PST/OST files (Outlook) — extract via readpst/libpst
  - EML files — RFC 822 parsing
  - AIM/AOL Instant Messenger chat logs
  - MSN Messenger / Windows Live Messenger logs
  - Browser-based webmail detection (URLs, cached pages)

Auto-installs: libpst-utils (apt), readpst (apt)

Target platform : Kali Linux, Python 3.11
External tools  : readpst (libpst), fls, icat (The Sleuth Kit)
"""

from __future__ import annotations

import email as _email_mod
import email.policy
import hashlib
import json
import logging
import re
import struct
import subprocess
import sys
import time
from email import message_from_bytes
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict, ClassResult, Finding, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason,
    _run_subprocess, make_finding, utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME = "email_communications_analyzer"
FLS_TIMEOUT  = 3600
ICAT_TIMEOUT = 300

# IM log patterns (path matching)
_IM_PATTERNS = [
    ("AIM",     re.compile(r"aim.*\.txt$|Buddy Chat/", re.IGNORECASE)),
    ("MSN",     re.compile(r"MSN.*\.xml$|WindowsLive.*\.xml$", re.IGNORECASE)),
    ("Yahoo",   re.compile(r"Yahoo.*\/(archive|Messages)/.*\.dat$", re.IGNORECASE)),
    ("Skype",   re.compile(r"main\.db$.*skype|skype.*main\.db$", re.IGNORECASE)),
    ("ICQ",     re.compile(r"ICQ.*\.dat$|icqchat", re.IGNORECASE)),
]

# Email artifact patterns
_EMAIL_PATTERNS = [
    ("dbx",  re.compile(r"\.dbx$", re.IGNORECASE)),
    ("pst",  re.compile(r"\.pst$", re.IGNORECASE)),
    ("ost",  re.compile(r"\.ost$", re.IGNORECASE)),
    ("eml",  re.compile(r"\.eml$", re.IGNORECASE)),
    ("mbox", re.compile(r"\.mbox$|\/mail\/[^/]+$", re.IGNORECASE)),
    ("msg",  re.compile(r"\.msg$", re.IGNORECASE)),
]

# AIM log directories
_AIM_LOG_PATTERNS = [
    re.compile(r"America Online.*Organize/.*\.txt$", re.IGNORECASE),
    re.compile(r"AOL.*Organize/.*\.txt$", re.IGNORECASE),
    re.compile(r"Instant Messenger.*Logs/", re.IGNORECASE),
]

# Outlook Express DBX B-tree signature (little-endian 0xFE12ADCF)
_DBX_MAGIC = b'\xcf\xad\x12\xfe'


def _label_email_artefact(path) -> str:
    """Return human-readable label for an email artefact path."""
    from pathlib import Path as _P
    path = _P(path)
    name_lower = path.name.lower()
    path_str   = str(path).replace("\\", "/").lower()
    if name_lower.endswith(".dbx"):
        return "Outlook Express store (.dbx)"
    if name_lower.endswith(".pst"):
        return "Outlook PST store"
    if name_lower.endswith(".ost"):
        return "Outlook OST store"
    if name_lower.endswith(".mbox"):
        return "mbox email store"
    if name_lower.endswith(".pfc") or "aol organize" in path_str:
        return "AOL Personal Filing Cabinet (.pfc)"
    suffix = path.suffix or "unknown"
    return f"Email store ({suffix})"


def _detect_partition_offset_mmls(analysis_path: Path, logger: logging.Logger) -> int:
    """Detect NTFS partition start sector via mmls; falls back to fls probe."""
    import sys as _sys
    _sudo = []

    for table_type in ("dos", "gpt"):
        try:
            rc, out, _ = _run_subprocess(
                _sudo + ["mmls", "-t", table_type, str(analysis_path)],
                timeout=30, logger=logger,
            )
            if rc == 0 and out:
                for line in out.splitlines():
                    if re.search(r"NTFS|Basic data", line, re.IGNORECASE):
                        m = re.search(r"\b(\d{4,})\b", line)
                        if m:
                            logger.info("[EMAIL] mmls %s offset: %s", table_type, m.group(1))
                            return int(m.group(1))
                for line in out.splitlines():
                    m = re.search(r"^\s*\d+:\s+\d+:\d+\s+(\d+)", line)
                    if m:
                        return int(m.group(1))
        except Exception as exc:
            logger.debug("[EMAIL] mmls %s failed: %s", table_type, exc)

    for candidate in (2048, 63, 64, 128, 0):
        try:
            _sudo2 = []
            off = ["-o", str(candidate)] if candidate > 0 else []
            rc, out, _ = _run_subprocess(
                _sudo2 + ["fls"] + off + [str(analysis_path)],
                timeout=10, logger=logger,
            )
            if rc == 0 and out.strip():
                logger.info("[EMAIL] fls probe offset: %d", candidate)
                return candidate
        except Exception:
            pass

    logger.warning("[EMAIL] Could not detect partition offset — defaulting to 0")
    return 0


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception:
            pass

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "email_artifacts").mkdir(exist_ok=True)
    (output_dir / "im_logs").mkdir(exist_ok=True)

    findings: list[Finding] = []
    errors: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        return _fail(MODULE_NAME, case_id, start_time,
                     f"Evidence not found: {evidence_path}", coc_logger, logger)

    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    if partition_offset == 0 and "partition_offset" not in config:
        partition_offset = _detect_partition_offset_mmls(analysis_path, logger)
        tlog(f"[EMAIL] Detected partition offset: {partition_offset} sectors")
    tlog(f"[EMAIL] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")

    # ── Step 1: fls enumeration ──────────────────────────────────────────────
    tlog("[EMAIL] Running fls to locate email and IM artifacts...")
    fls_entries = _run_fls(analysis_path, logger, errors, offset=partition_offset)
    tlog(f"[EMAIL] fls: {len(fls_entries)} filesystem entries")

    # Native-first fallback: when TSK is absent, enumerate the read-only
    # filesystem tree already exposed by the orchestrator.  Paths and files are
    # discovered from the current evidence; no case-specific names are assumed.
    native_scan_used = False
    ws = config.get("_working_set") if isinstance(config.get("_working_set"), dict) else {}
    native_root_value = (ws or {}).get("extracted_files_dir") or (ws or {}).get("mounted_fs_root")
    native_root = Path(str(native_root_value)) if native_root_value else None
    if not fls_entries and native_root is not None and native_root.is_dir():
        native_entries: list[dict] = []
        for item in sorted(native_root.rglob("*")):
            try:
                if not item.is_file():
                    continue
                relative = item.relative_to(native_root).as_posix()
                native_entries.append({
                    "path": relative,
                    "inode": "",
                    "deleted": False,
                    "local_path": str(item),
                })
            except (OSError, ValueError):
                continue
        fls_entries = native_entries
        native_scan_used = True
        # Absence of the optional TSK binary is not an analysis error when the
        # evidence-derived native tree is available.
        errors = [e for e in errors if "fls" not in str(e).lower()]
        tlog(f"[EMAIL] Native filesystem enumeration: {len(fls_entries)} file(s)")

    email_matches: list[dict] = []
    im_matches:    list[dict] = []

    for entry in fls_entries:
        norm = entry["path"].replace("\\", "/")
        for fmt, pat in _EMAIL_PATTERNS:
            if pat.search(norm):
                email_matches.append({**entry, "format": fmt})
                break
        for im_type, pat in _IM_PATTERNS:
            if pat.search(norm):
                im_matches.append({**entry, "im_type": im_type})
                break
        for aim_pat in _AIM_LOG_PATTERNS:
            if aim_pat.search(norm):
                if not any(m["inode"] == entry["inode"] for m in im_matches):
                    im_matches.append({**entry, "im_type": "AIM"})
                break

    tlog(f"[EMAIL] Found {len(email_matches)} email artifacts, {len(im_matches)} IM logs")

    # ── Step 2: Extract and parse email artifacts ────────────────────────────
    emails_summary: list[dict] = []
    total_emails_parsed = 0
    duplicate_email_stores = 0
    seen_email_store_hashes: dict[str, str] = {}

    for match in email_matches:  # exhaustive store processing
        if match.get("local_path"):
            dest = Path(str(match["local_path"]))
        else:
            dest = output_dir / "email_artifacts" / re.sub(
                r"[^A-Za-z0-9_.\-]", "_", Path(match["path"]).name)
            if not dest.exists():
                dest, err = _icat_extract(analysis_path,
                                           match["inode"], dest, logger,
                                           offset=partition_offset)
                if err:
                    errors.append(f"icat failed for {match['path']}: {err}")
                    tlog(f"[EMAIL] FAILED to extract {match['path']}: {err}")
                    continue
        tlog(f"[EMAIL] Extracted {match['format']}: {dest.name} ({dest.stat().st_size} bytes)")
        try:
            store_sha256 = hashlib.sha256(dest.read_bytes()).hexdigest()
        except OSError:
            store_sha256 = ""
        if store_sha256 and store_sha256 in seen_email_store_hashes:
            duplicate_email_stores += 1
            emails_summary.append({
                "path": match["path"], "format": match["format"], "local": str(dest),
                "size": dest.stat().st_size, "sha256": store_sha256,
                "duplicate_of": seen_email_store_hashes[store_sha256],
                "message_count": 0, "alias_only": True,
            })
            tlog(f"[EMAIL] Exact duplicate store alias: {match['path']} -> {seen_email_store_hashes[store_sha256]}")
            continue
        if store_sha256:
            seen_email_store_hashes[store_sha256] = match["path"]

        parsed_info = _parse_email_file(dest, match["format"], logger)
        emails_summary.append({
            "path":   match["path"],
            "format": match["format"],
            "local":  str(dest),
            "size":   dest.stat().st_size,
            "sha256": store_sha256,
            **parsed_info,
        })
        total_emails_parsed += parsed_info.get("message_count", 0)

        # Generate findings
        if parsed_info.get("message_count", 0) > 0:
            senders   = parsed_info.get("senders", [])
            receivers = parsed_info.get("receivers", [])
            subjects  = parsed_info.get("subjects", [])
            findings.append(make_finding(
                "EMAIL_STORE_FOUND", Severity.INFO,
                f"Email archive found: '{match['path']}' ({match['format'].upper()}, "
                f"{dest.stat().st_size:,} bytes). "
                f"{parsed_info.get('message_count', 0)} message(s) parsed. "
                f"Senders: {'; '.join(senders[:3])}. "
                f"Subjects sample: {'; '.join(str(s)[:50] for s in subjects[:3])}.",
                match["path"],
                {"format": match["format"], "size": dest.stat().st_size,
                 "message_count": parsed_info.get("message_count", 0),
                 "senders": senders[:10], "receivers": receivers[:10],
                 "subjects": [str(s)[:100] for s in subjects[:10]],
                 "messages": parsed_info.get("messages", []),
                 "store_sha256": store_sha256, "source_file": str(dest),
                 **deterministic_metadata("RFC 5322/mailbox parser records", validators=["email/mailbox parser", "SHA-256"])},
            ))
            for message_index, message in enumerate(parsed_info.get("messages", [])):
                exact_record = {
                    "message_index": message_index,
                    "from": str(message.get("from") or ""),
                    "to": str(message.get("to") or ""),
                    "cc": str(message.get("cc") or ""),
                    "date": str(message.get("date") or ""),
                    "subject": str(message.get("subject") or ""),
                    "body": str(message.get("body") or ""),
                    "source_file": str(dest),
                    "logical_store_path": match["path"],
                    "store_sha256": store_sha256,
                    **deterministic_metadata(
                        "RFC 5322/mailbox message parser record",
                        validators=["email/mailbox parser", "source store SHA-256", "message ordinal"],
                        semantic_limit="Stored message fields only; sender identity, authorship, delivery and intent are not independently verified",
                    ),
                }
                findings.append(make_finding(
                    "EMAIL_MESSAGE_RECORD", Severity.INFO,
                    f"Message record {message_index + 1} was parsed from '{match['path']}'. "
                    f"Stored From='{exact_record['from']}', To='{exact_record['to']}', "
                    f"Date='{exact_record['date']}', Subject='{exact_record['subject']}'.",
                    match["path"], exact_record,
                ))
        # Per-message investigation-keyword matching. A lexical match is a
        # review aid, not a determination of criminality or intent.
        msgs = parsed_info.get("messages", [])
        if msgs:
            _emit_criminal_keyword_findings(msgs, match["path"], findings)

        # Flag investigation keywords for examiner review.
        kws = parsed_info.get("criminal_keywords", [])
        if kws:
            findings.append(make_finding(
                "EMAIL_INVESTIGATION_KEYWORDS", Severity.MEDIUM,
                f"Investigation-keyword matches found in email archive '{match['path']}': "
                + ", ".join(kws[:10]) + ". "
                "This is a lexical triage result only and does not establish an offence, intent, or authorship.",
                match["path"],
                {"keywords": kws, "file": str(dest), **candidate_metadata("email keyword matching", reason="Lexical match does not establish intent or offence")},
            ))

    # AOL PFC detection on extracted email files
    for match in email_matches:
        local = (Path(str(match["local_path"])) if match.get("local_path") else
                 output_dir / "email_artifacts" / re.sub(
                     r"[^A-Za-z0-9_.\-]", "_", Path(match["path"]).name))
        if local.exists():
            pfc = _parse_aol_pfc(local, logger)
            if pfc.get("is_aol_pfc"):
                findings.append(make_finding(
                    "AOL_PFC_FOUND", Severity.HIGH,
                    f"AOL PFC format detected: '{match['path']}'. "
                    f"Screen names: {', '.join(pfc['screen_names'][:5])}. "
                    f"Email addresses: {', '.join(pfc['email_addresses'][:5])}. "
                    f"Away messages: {len(pfc['away_messages'])} found.",
                    match["path"],
                    pfc,
                ))
                tlog(f"[EMAIL] AOL PFC found: {match['path']}")

    # ── Step 3: Extract and parse IM logs ───────────────────────────────────
    im_summary: list[dict] = []
    for match in im_matches:
        if match.get("local_path"):
            dest = Path(str(match["local_path"]))
        else:
            dest = output_dir / "im_logs" / re.sub(
                r"[^A-Za-z0-9_.\-]", "_", Path(match["path"]).name)
            if not dest.exists():
                dest, err = _icat_extract(analysis_path,
                                           match["inode"], dest, logger,
                                           offset=partition_offset)
                if err:
                    errors.append(f"icat failed for {match['path']}: {err}")
                    continue
        tlog(f"[EMAIL] Extracted IM log ({match['im_type']}): {dest.name}")

        parsed_im = _parse_im_log(dest, match["im_type"], logger)
        im_summary.append({
            "path":    match["path"],
            "im_type": match["im_type"],
            "local":   str(dest),
            **parsed_im,
        })

        if parsed_im.get("line_count", 0) > 0:
            participants = parsed_im.get("participants", [])
            findings.append(make_finding(
                "IM_CHAT_LOG_FOUND", Severity.MEDIUM,
                f"Instant Messenger chat log found: '{match['path']}' "
                f"({match['im_type']}). "
                f"{parsed_im.get('line_count', 0)} log lines. "
                f"Participants: {', '.join(participants[:5])}.",
                match["path"],
                {"im_type": match["im_type"],
                 "line_count": parsed_im.get("line_count", 0),
                 "participants": participants,
                 "sample_lines": parsed_im.get("sample_lines", [])[:5],
                 "source_file": str(dest),
                 **deterministic_metadata("chat-log line parser", validators=["retained source lines"])},
            ))
            for line_index, line_text in enumerate(parsed_im.get("lines", [])):
                findings.append(make_finding(
                    "IM_MESSAGE_LINE_RECORD", Severity.INFO,
                    f"Retained chat-log line {line_index + 1} from '{match['path']}': {str(line_text)[:300]}",
                    match["path"],
                    {
                        "im_type": match["im_type"], "line_index": line_index,
                        "line_text": str(line_text), "source_file": str(dest),
                        **deterministic_metadata(
                            "exact non-empty retained source line",
                            validators=["line splitting", "source file SHA-256"],
                            semantic_limit="Stored line text only; participant identity, authorship and intent are not independently verified",
                        ),
                    },
                ))

    # ── Screenshots ─────────────────────────────────────────────────────────
    try:
        from modules.screenshot_capture import capture_terminal, capture_table, record_screenshot
        sc_dir = output_dir / "screenshots"
        sc_dir.mkdir(exist_ok=True)
        sc_idx = sc_dir / "screenshots_index.json"

        # Fig 5.1 — fls email enumeration terminal
        fls_preview = "\n".join(terminal_lines[:80])
        png = capture_terminal("fls email file enumeration", fls_preview,
                               sc_dir, "fig_5_1",
                               "Fig 5.1: fls output identifying email archives and IM logs")
        if png:
            record_screenshot(sc_idx, "fig_5_1", png,
                              "Fig 5.1: fls output identifying email archives and IM logs")

        # Fig 5.2 — Email archives summary table
        if emails_summary:
            em_rows = [[e.get("format","?"), e.get("path","?")[-50:],
                        str(e.get("message_count",0)),
                        "; ".join(e.get("senders",[])[:2])[:50]]
                       for e in emails_summary[:15]]
            png = capture_table("Email Archives Discovered",
                                ["Format", "Path", "Messages", "Senders"],
                                em_rows, sc_dir, "fig_5_2",
                                "Fig 5.2: Email archive stores found on evidence image")
            if png:
                record_screenshot(sc_idx, "fig_5_2", png,
                                  "Fig 5.2: Email archive stores found on evidence image")

        # Fig 5.3 — Individual email subjects/senders (first archive)
        if emails_summary:
            first_em = emails_summary[0]
            subj_rows = [[s[:80]] for s in first_em.get("subjects",[])[:25] if s]
            if subj_rows:
                png = capture_table(f"Email Subjects — {first_em.get('path','?')[-40:]}",
                                    ["Subject"],
                                    subj_rows, sc_dir, "fig_5_3",
                                    "Fig 5.3: Email subjects from primary archive")
                if png:
                    record_screenshot(sc_idx, "fig_5_3", png,
                                      "Fig 5.3: Email subjects from primary archive")

        # Fig 5.4 — IM chat logs table
        if im_summary:
            im_rows = [[i.get("im_type","?"), i.get("path","?")[-50:],
                        str(i.get("line_count",0)),
                        "; ".join(i.get("participants",[])[:3])[:60]]
                       for i in im_summary[:15]]
            png = capture_table("Instant Messenger Chat Logs",
                                ["IM Type", "Path", "Lines", "Participants"],
                                im_rows, sc_dir, "fig_5_4",
                                "Fig 5.4: IM chat log files found on evidence image")
            if png:
                record_screenshot(sc_idx, "fig_5_4", png,
                                  "Fig 5.4: IM chat log files found on evidence image")

        tlog(f"[EMAIL] Screenshots saved to {sc_dir}")
    except Exception as _sc_exc:
        logger.warning("[EMAIL] Screenshot capture failed: %s", _sc_exc)

    # ── Write manifest ───────────────────────────────────────────────────────
    manifest = {
        "module":              MODULE_NAME,
        "case_id":             case_id,
        "generated_at":        utc_now(),
        "email_files_found":   len(email_matches),
        "im_logs_found":       len(im_matches),
        "total_emails_parsed": total_emails_parsed,
        "duplicate_email_store_aliases": duplicate_email_stores,
        "emails_summary":      emails_summary,
        "im_summary":          im_summary,
        "findings":            len(findings),
        "errors":              errors,
    }
    manifest_path = output_dir / "email_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    (output_dir / "terminal_output.txt").write_text(
        "\n".join(terminal_lines), encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[EMAIL] Completed in {wall_elapsed:.1f}s — {len(findings)} findings")

    # Track DBX stores that were found but could not be parsed (missing tool)
    _dbx_found_unreadable = sum(
        1 for e in emails_summary
        if e.get("format") == "dbx"
        and e.get("parse_method") == "raw_extraction"
        and e.get("message_count", 0) == 0
    )

    status = (ModuleStatus.COMPLETED if not errors
              else ModuleStatus.PARTIAL if (email_matches or im_matches)
              else ModuleStatus.FAILED)
    if _dbx_found_unreadable and status == ModuleStatus.COMPLETED:
        status = ModuleStatus.PARTIAL

    summary = (
        f"Email analysis: {len(email_matches)} email store(s), "
        f"{total_emails_parsed} unique message(s) parsed, {duplicate_email_stores} exact duplicate store alias(es), "
        f"{len(im_matches)} IM log(s). {len(findings)} findings."
        + (" Native evidence-tree enumeration used because TSK listing was unavailable." if native_scan_used else "")
        + (f" {_dbx_found_unreadable} DBX store(s) located but unreadable (dbxconv/undbx not installed)."
           if _dbx_found_unreadable else "")
    )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED
                else EventType.MODULE_FAILED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value},
            )
        except Exception:
            pass

    if status == ModuleStatus.FAILED:
        _email_verdict = AssuranceVerdict.INDETERMINATE
        _email_skip    = SkipReason.PARTIAL_FAILURE
    elif _dbx_found_unreadable and total_emails_parsed == 0:
        # DBX stores found but content unreadable — cannot confirm VERIFIED_ABSENT
        _email_verdict = AssuranceVerdict.INDETERMINATE
        _email_skip    = SkipReason.DEPENDENCY_MISSING
    elif len(findings) > 0:
        _email_verdict = AssuranceVerdict.PRESENT
        _email_skip    = None
    else:
        _email_verdict = AssuranceVerdict.VERIFIED_ABSENT
        _email_skip    = None

    _email_cr = ClassResult(
        locus=Locus.EMAIL,
        artefact_class="Email Communications",
        verdict=_email_verdict,
        skip_reason=_email_skip,
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings, artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={"email_stores": len(email_matches),
                     "im_logs": len(im_matches),
                     "emails_parsed": total_emails_parsed,
                     "duplicate_email_store_aliases": duplicate_email_stores},
        summary=summary,
        class_results=[_email_cr],
    )


# ---------------------------------------------------------------------------
# Email parsers
# ---------------------------------------------------------------------------

def _detect_format_by_magic(path: Path) -> Optional[str]:
    """Return the email format inferred from the file's magic bytes, or None."""
    try:
        with open(path, "rb") as fh:
            header = fh.read(16)
    except OSError:
        return None
    if len(header) < 4:
        return None
    # DBX (Outlook Express): FE 12 AD CF
    if header[:4] == b"\xfe\x12\xad\xcf":
        return "dbx"
    # PST / OST (Outlook): 21 42 44 4E  ("!BDN")
    if header[:4] == b"\x21\x42\x44\x4e":
        return "pst"
    # OLE2 compound document (MSG, older PST, AOL PFC): D0 CF 11 E0
    if header[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        return "msg"
    # mbox: plain text starting with "From " (RFC 4155)
    if header[:5] == b"From ":
        return "mbox"
    return None


def _parse_email_file(path: Path, fmt: str, logger: logging.Logger) -> dict:
    result: dict = {"message_count": 0, "senders": [], "receivers": [], "subjects": []}
    try:
        # Override extension-based routing with magic-byte detection so a file
        # named "Inbox.dbx" that is actually a PST gets the right parser.
        magic_fmt = _detect_format_by_magic(path)
        if magic_fmt and magic_fmt != fmt:
            logger.info(
                "[EMAIL] Format override: extension says '%s', magic says '%s' for %s",
                fmt, magic_fmt, path.name,
            )
            fmt = magic_fmt
        if fmt == "eml":
            return _parse_eml(path, logger)
        elif fmt == "mbox":
            return _parse_mbox(path, logger)
        elif fmt in ("pst", "ost"):
            return _parse_pst_with_readpst(path, logger)
        elif fmt == "dbx":
            return _parse_dbx(path, logger)
        elif fmt == "msg":
            return _parse_msg(path, logger)
    except Exception as exc:
        logger.warning("Email parse error for %s: %s", path, exc)
    return result


def _parse_eml(path: Path, logger: logging.Logger) -> dict:
    try:
        data = path.read_bytes()
        msg = message_from_bytes(data, policy=_email_mod.policy.compat32)
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain" and part.get_content_disposition() != "attachment":
                    try:
                        payload = part.get_payload(decode=True)
                        body = (payload or b"").decode(part.get_content_charset() or "utf-8", errors="replace")
                    except Exception:
                        body = str(part.get_payload() or "")
                    break
        else:
            try:
                payload = msg.get_payload(decode=True)
                body = (payload or b"").decode(msg.get_content_charset() or "utf-8", errors="replace")
            except Exception:
                body = str(msg.get_payload() or "")
        record = {
            "from": str(msg.get("From", "")),
            "to": str(msg.get("To", "")),
            "cc": str(msg.get("CC", "")),
            "date": str(msg.get("Date", "")),
            "subject": str(msg.get("Subject", "")),
            "body": body,
        }
        return {
            "message_count": 1,
            "senders": [record["from"]], "receivers": [record["to"]],
            "subjects": [record["subject"]], "dates": [record["date"]],
            "messages": [record],
            "has_attachments": any(
                p.get_content_disposition() == "attachment"
                for p in msg.walk()
            ),
        }
    except Exception as exc:
        return {"message_count": 0, "error": str(exc)}


def _parse_mbox(path: Path, logger: logging.Logger) -> dict:
    try:
        import mailbox
        mbox = mailbox.mbox(str(path))
        senders, receivers, subjects, messages = [], [], [], []
        for msg in mbox:
            sender  = str(msg.get("From",    ""))
            to      = str(msg.get("To",      ""))
            cc      = str(msg.get("CC",      ""))
            date    = str(msg.get("Date",    ""))
            subject = str(msg.get("Subject", ""))
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        try:
                            body = part.get_payload(decode=True).decode("utf-8", errors="replace")
                        except Exception:
                            pass
                        break
            else:
                try:
                    body = msg.get_payload(decode=True).decode("utf-8", errors="replace")
                except Exception:
                    body = str(msg.get_payload())
            senders.append(sender)
            receivers.append(to)
            subjects.append(subject)
            messages.append({"from": sender, "to": to, "cc": cc,
                              "date": date, "subject": subject, "body": body})
        return {
            "message_count": len(messages),
            "senders":   list(dict.fromkeys(senders)),
            "receivers": list(dict.fromkeys(receivers)),
            "subjects":  subjects,
            "messages":  messages,
        }
    except Exception as exc:
        return {"message_count": 0, "error": str(exc)}


def _parse_pst_with_readpst(path: Path, logger: logging.Logger) -> dict:
    """Use readpst to extract PST/OST to mbox format then parse."""
    import tempfile, os, shutil
    if not shutil.which("readpst"):
        # Never install packages or invoke sudo inside an evidence run.
        return {"message_count": 0, "note": "readpst not available"}

    try:
        tmpdir = tempfile.mkdtemp()
        cmd = ["readpst", "-o", tmpdir, "-e", str(path)]
        rc, stdout, stderr = _run_subprocess(cmd, 300, logger)
        mbox_files = list(Path(tmpdir).rglob("*.mbox"))
        total = 0
        senders, receivers, subjects = [], [], []
        for mf in mbox_files:
            res = _parse_mbox(mf, logger)
            total += res.get("message_count", 0)
            senders.extend(res.get("senders", []))
            receivers.extend(res.get("receivers", []))
            subjects.extend(res.get("subjects", []))
        shutil.rmtree(tmpdir, ignore_errors=True)
        return {
            "message_count": total,
            "senders":   sorted(set(senders)),
            "receivers": sorted(set(receivers)),
            "subjects":  subjects,
        }
    except Exception as exc:
        return {"message_count": 0, "error": str(exc)}


def _parse_dbx(path: Path, logger: logging.Logger) -> dict:
    """
    Parse Outlook Express .dbx store.
    Tries undbx first, then dbxconv, then falls back to raw byte extraction.
    # LIVE-RUN-REQUIRED: undbx/dbxconv must be installed: apt install undbx dbxconv
    """
    import shutil as _shutil
    import email as _email_stdlib
    import tempfile as _tempfile
    from pathlib import Path as _P
    path = _P(path)

    # Verify DBX magic bytes — bail early on corrupt/misidentified files
    try:
        file_header = path.read_bytes()[:4]
        if file_header != _DBX_MAGIC:
            logger.warning("DBX magic mismatch for %s: %s (expected CF AD 12 FE)",
                           path.name, file_header.hex())
            # Continue anyway — some DBX variants have a different header
            # but we still attempt extraction
    except OSError as exc:
        logger.warning("Cannot read DBX file %s: %s", path.name, exc)
        return {"message_count": 0, "senders": [], "receivers": [],
                "subjects": [], "criminal_keywords": [], "messages": [],
                "parse_method": "error"}

    output_dir = _P(_tempfile.mkdtemp(prefix="dbx_parse_"))
    messages = []
    eml_dir = output_dir / f"dbx_{path.stem}"
    eml_dir.mkdir(parents=True, exist_ok=True)

    _tool_used = None
    if _shutil.which("undbx"):
        rc, stdout, stderr = _run_subprocess(
            ["undbx", str(path), str(eml_dir)],
            timeout=120, logger=logger,
        )
        if rc == 0:
            _tool_used = "undbx"
        else:
            logger.warning("undbx rc=%d for %s: %s", rc, path.name, (stderr or "")[:200])

    if _tool_used is None and _shutil.which("dbxconv"):
        rc, stdout, stderr = _run_subprocess(
            ["dbxconv", "-o", str(eml_dir), str(path)],
            timeout=120, logger=logger,
        )
        if rc == 0:
            _tool_used = "dbxconv"
        else:
            logger.warning("dbxconv rc=%d for %s: %s", rc, path.name, (stderr or "")[:200])

    if _tool_used is None:
        logger.info("No DBX tool available — raw extraction for %s", path.name)
        _extract_dbx_raw(path, eml_dir, logger)
        _tool_used = "raw_extraction"

    for eml_file in sorted(eml_dir.glob("*.eml")):
        try:
            msg = _email_stdlib.message_from_bytes(eml_file.read_bytes())
            # Coerce header objects to str — email.header.Header objects are not strings
            # and will cause TypeError in regex operations below.
            messages.append({
                "from":    str(msg.get("From", "") or ""),
                "to":      str(msg.get("To", "") or ""),
                "subject": str(msg.get("Subject", "") or ""),
                "date":    str(msg.get("Date", "") or ""),
                "body":    "",
                "source":  str(path),
            })
        except Exception as exc:
            if logger:
                logger.debug("Could not parse %s: %s", eml_file.name, exc)

    senders   = [m["from"]    for m in messages if m["from"]]
    receivers = [m["to"]      for m in messages if m["to"]]
    subjects  = [m["subject"] for m in messages if m["subject"]]

    _CRIMINAL_KW = re.compile(
        r"\b(credit|card|fraud|atm|skimmer|password|account|money|wire|"
        r"fake|identity|passport|printer|stolen|clone|dump)\b",
        re.IGNORECASE,
    )
    flagged_kw: list[str] = []
    for t in subjects + senders:
        for hit in _CRIMINAL_KW.finditer(t):
            flagged_kw.append(hit.group())
    flagged_kw = list(dict.fromkeys(flagged_kw))

    return {
        "message_count":    len(messages),
        "senders":          list(dict.fromkeys(senders)),
        "receivers":        list(dict.fromkeys(receivers)),
        "subjects":         subjects,
        "criminal_keywords": flagged_kw,
        "messages":         messages,
        "parse_method":     _tool_used,
    }


def _extract_dbx_raw(dbx_path, out_dir, logger) -> None:
    """Extract message boundaries from DBX without an external tool."""
    from pathlib import Path as _P
    data = _P(dbx_path).read_bytes()
    # Search for RFC-2822 message start markers
    _MARKERS = [b"From:", b"Return-Path:", b"Received:", b"Message-ID:"]
    boundaries: list[int] = []
    for marker in _MARKERS:
        pos = 0
        while True:
            idx = data.find(marker, pos)
            if idx == -1:
                break
            # Only count if preceded by \r\n or at start or after NUL run
            if idx == 0 or data[idx-1:idx] in (b'\n', b'\x00'):
                boundaries.append(idx)
            pos = idx + 1
    boundaries = sorted(set(boundaries))
    if not boundaries:
        logger.info("Raw DBX extraction: no message boundaries in %s", _P(dbx_path).name)
        return
    logger.info("Raw DBX extraction: %d boundary markers in %s", len(boundaries), _P(dbx_path).name)
    for idx in range(len(boundaries)):
        start = boundaries[idx]
        end   = boundaries[idx + 1] if idx + 1 < len(boundaries) else len(data)
        chunk = data[start:end]
        if len(chunk) > 20:  # skip trivially small chunks
            (_P(out_dir) / f"msg_{idx:04d}.eml").write_bytes(chunk)


def _parse_msg(path: Path, logger: logging.Logger) -> dict:
    """Parse Outlook .msg file (OLE compound) — extract headers."""
    try:
        data = path.read_bytes()
        from_re    = re.compile(rb"From:\s*([^\r\n]+)", re.IGNORECASE)
        to_re      = re.compile(rb"To:\s*([^\r\n]+)", re.IGNORECASE)
        subject_re = re.compile(rb"Subject:\s*([^\r\n]+)", re.IGNORECASE)
        senders   = [m.group(1).decode("utf-8", "replace") for m in from_re.finditer(data)]
        receivers = [m.group(1).decode("utf-8", "replace") for m in to_re.finditer(data)]
        subjects  = [m.group(1).decode("utf-8", "replace") for m in subject_re.finditer(data)]
        return {
            "message_count": max(1, len(subjects)),
            "senders": senders, "receivers": receivers, "subjects": subjects,
        }
    except Exception as exc:
        return {"message_count": 0, "error": str(exc)}


# ---------------------------------------------------------------------------
# IM log parsers
# ---------------------------------------------------------------------------

def _parse_aim_log(log_path, logger) -> dict:
    """Extract screen-name strings from common AIM/plain-text log formats.

    A parsed screen name is reported as a value stored in the artefact; it is
    not treated as a verified identity or account owner.
    """
    import re as _re
    from pathlib import Path as _P
    text = _P(log_path).read_text(errors="replace")
    participants: list[str] = []
    patterns = (
        r"(?im)^\s*IM Sessions? with\s+([A-Za-z0-9_.@\-]{2,64})",
        r"(?im)^\s*Conversation with\s+([A-Za-z0-9_.@\-]{2,64})",
        # username: message
        r"(?im)^\s*([A-Za-z][A-Za-z0-9_.@\-]{1,63})\s*:\s*\S",
        # [2008-02-13 04:47:14] username: message
        r"(?im)^\s*\[[^\]]{3,40}\]\s*([A-Za-z][A-Za-z0-9_.@\-]{1,63})\s*:\s*\S",
        # (04:47:14) username: message / 04:47 username: message
        r"(?im)^\s*(?:\([^)]{2,30}\)|\d{1,2}:\d{2}(?::\d{2})?)\s+([A-Za-z][A-Za-z0-9_.@\-]{1,63})\s*:\s*\S",
        # username (04:47): message
        r"(?im)^\s*([A-Za-z][A-Za-z0-9_.@\-]{1,63})\s*\([^)]{2,30}\)\s*:\s*\S",
    )
    rejected = {"aim", "aol", "session", "conversation", "date", "time", "from", "to"}
    for pattern in patterns:
        for value in _re.findall(pattern, text):
            candidate = str(value).strip()
            if candidate and candidate.lower() not in rejected and not _re.match(r"^\d{4}", candidate):
                participants.append(candidate)
    lines = [line.rstrip() for line in text.splitlines() if line.strip()]
    return {
        "participants": list(dict.fromkeys(participants)),
        "participant_interpretation": "screen-name strings recorded in the log; identity/ownership not verified",
        "log_path": str(log_path),
        "line_count": len(lines),
        "sample_lines": lines[:10],
        "lines": lines,
    }


def _parse_im_log(path: Path, im_type: str, logger: logging.Logger) -> dict:
    if im_type == "AIM":
        return _parse_aim_log(path, logger)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = [l.rstrip() for l in text.splitlines() if l.strip()]
        participants = set()
        # Regex for common IM log username patterns
        user_re = re.compile(r"^([A-Za-z0-9_.\-@]{2,50})\s*[:\(]", re.MULTILINE)
        for m in user_re.finditer(text):
            participants.add(m.group(1))
        return {
            "line_count":    len(lines),
            "participants":  sorted(participants),
            "sample_lines":  lines[:10],
            "lines": lines,
        }
    except Exception as exc:
        return {"line_count": 0, "error": str(exc)}


_CRIMINAL_KW_RE = re.compile(
    r"\b(credit[\s\-]?card|atm|fraud|card[\s\-]?number|fake[\s\-]?id|passport|skimmer|password)\b",
    re.IGNORECASE,
)

def _emit_criminal_keyword_findings(
    messages: list[dict],
    archive_path: str,
    findings: list,
) -> None:
    """Emit bounded lexical-match findings for examiner review."""
    non_matching = 0
    for msg in messages:
        text = f"{msg.get('subject','')} {msg.get('body','')}"
        hits = list(set(m.group() for m in _CRIMINAL_KW_RE.finditer(text)))
        if hits:
            findings.append(make_finding(
                "EMAIL_INVESTIGATION_KEYWORD", Severity.MEDIUM,
                f"Investigation-keyword match(es) found in an email artefact with stored From value '{msg.get('from','')}' "
                f"dated {msg.get('date','')}. "
                f"Subject: {msg.get('subject','')[:100]}. Matched terms: {', '.join(hits)}. "
                "The match does not verify the sender identity, authorship, intent, or criminality.",
                archive_path,
                {
                    "from":         msg.get("from", ""),
                    "to":           msg.get("to",   ""),
                    "cc":           msg.get("cc",   ""),
                    "date":         msg.get("date", ""),
                    "subject":      msg.get("subject", ""),
                    "body":         msg.get("body", ""),
                    "keywords":     hits,
                },
            ))
        else:
            non_matching += 1
    if non_matching > 0:
        findings.append(make_finding(
            "EMAIL_AGGREGATE", Severity.INFO,
            f"{non_matching} email(s) in '{archive_path}' contained no configured investigation-keyword matches.",
            archive_path,
            {"non_flagged_count": non_matching},
        ))


_AOL_MAGIC_VARIANTS = (
    b"\x41\x4F\x4C\x20",  # "AOL " ASCII prefix (some versions)
    b"\xCF\xAD\x12\xFE",  # AOL PFC database signature (documented)
)

def _parse_aol_pfc(path: Path, logger: logging.Logger) -> dict:
    """
    Detect AOL PFC format by magic bytes at offset 0.
    Extract screen names, away messages, and email addresses using strings.
    """
    try:
        with path.open("rb") as fh:
            header = fh.read(16)
    except OSError:
        return {"is_aol_pfc": False}
    first4 = header[:4]
    if first4 not in _AOL_MAGIC_VARIANTS:
        return {"is_aol_pfc": False}

    logger.info("[EMAIL] AOL PFC format detected: %s", path.name)
    screen_names: list[str] = []
    email_addresses: list[str] = []
    away_messages: list[str] = []

    try:
        result = subprocess.run(
            ["strings", "-n", "8", str(path)],
            capture_output=True, timeout=60, shell=False,
        )
        text = result.stdout.decode("utf-8", errors="replace")
        email_re = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            for m in email_re.finditer(line):
                email_addresses.append(m.group())
            if "away" in line.lower() and len(line) > 10:
                away_messages.append(line[:300])
    except Exception as exc:
        logger.warning("[EMAIL] strings failed on PFC %s: %s", path.name, exc)

    return {
        "is_aol_pfc":      True,
        "screen_names":    sorted(set(screen_names)),
        "email_addresses": sorted(set(email_addresses)),
        "away_messages":   sorted(set(away_messages)),
    }


# ---------------------------------------------------------------------------
# fls / icat
# ---------------------------------------------------------------------------

def _run_fls(analysis_path: Path,
             logger: logging.Logger, errors: list,
             offset: int = 0) -> list[dict]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found")
        return []
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return []
    entries = []
    for line in stdout.splitlines():
        m = re.match(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", line.strip())
        if m and not m.group(2).endswith("/"):
            entries.append({"inode": m.group(1).split("-")[0], "path": m.group(2).strip()})
    return entries


def _icat_extract(analysis_path: Path, inode: str,
                  dest: Path, logger: logging.Logger,
                  offset: int = 0) -> tuple[Path, str | None]:
    import subprocess as _subprocess
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    logger.debug("icat cmd: %s", " ".join(cmd))
    try:
        result = _subprocess.run(
            cmd, capture_output=True, timeout=ICAT_TIMEOUT, shell=False
        )
    except FileNotFoundError:
        return dest, "icat not found"
    except _subprocess.TimeoutExpired:
        return dest, f"icat timed out after {ICAT_TIMEOUT}s"
    except Exception as exc:
        return dest, str(exc)
    if result.returncode != 0:
        stderr_txt = result.stderr.decode("utf-8", errors="replace")[:200]
        return dest, f"icat exit {result.returncode}: {stderr_txt}"
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(result.stdout)
        return dest, None
    except OSError as exc:
        return dest, str(exc)


def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    logger.error("Module %s failed: %s", module_name, reason)
    return ModuleResult(
        module_name=module_name, case_id=case_id, status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(), duration_seconds=0.0,
        findings=[], artifact_paths=[], errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
        class_results=[ClassResult(
            locus=Locus.EMAIL,
            artefact_class="Email Communications",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            count=0,
        )],
    )
