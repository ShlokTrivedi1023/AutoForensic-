"""
browser_history_analyzer.py — Browser History and Activity Forensics Module.

Extracts and analyzes web browser history artifacts:
  - Internet Explorer: index.dat (history, cache, cookies)
  - Edge: WebCacheV01.dat (ESE database), history files
  - Chrome: History SQLite database, Cookies, Downloads
  - Firefox: places.sqlite, cookies.sqlite, downloads.json
  - Opera: history files

Auto-installs: python-libesedb (pip), mdb-tools (apt)

Target platform : Kali Linux, Python 3.11
External tools  : fls, icat (The Sleuth Kit), sqlite3 (Python built-in)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Finding,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    resolve_corpus_roots,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME = "browser_history_analyzer"
FLS_TIMEOUT  = 3600
ICAT_TIMEOUT = 300

# Browser artifact path patterns
_BROWSER_PATTERNS = [
    # Internet Explorer / Edge (legacy)
    ("ie_history",    re.compile(r"Temporary Internet Files.*index\.dat$|History.*index\.dat$", re.IGNORECASE)),
    ("edge_cache",    re.compile(r"MicrosoftEdge.*WebCacheV01\.dat$", re.IGNORECASE)),
    ("ie_cache",      re.compile(r"Temporary Internet Files/Content\.IE5/index\.dat$", re.IGNORECASE)),
    # Chrome
    ("chrome_hist",   re.compile(r"Google/Chrome.*Default/History$", re.IGNORECASE)),
    ("chrome_cookie", re.compile(r"Google/Chrome.*Default/Cookies$", re.IGNORECASE)),
    ("chrome_dl",     re.compile(r"Google/Chrome.*Default/History$", re.IGNORECASE)),
    # Firefox
    ("ff_places",     re.compile(r"Firefox/Profiles/.*places\.sqlite$", re.IGNORECASE)),
    ("ff_cookies",    re.compile(r"Firefox/Profiles/.*cookies\.sqlite$", re.IGNORECASE)),
    # Opera
    ("opera_hist",    re.compile(r"Opera.*opera_autoupdate\.log$|Opera.*History$", re.IGNORECASE)),
    # Edge Chromium
    ("edge_chrom",    re.compile(r"Microsoft/Edge.*Default/History$", re.IGNORECASE)),
]


def _dedupe_artefacts(artefacts: list) -> list:
    """Deduplicate browser artefacts by content hash, then inode/path.

    Native extraction and carving can expose byte-identical copies of the same
    SQLite database under different names.  Those copies are aliases of one
    evidential byte stream, not independent browser databases.
    """
    seen: dict[str, dict] = {}
    result: list[dict] = []
    for artefact in artefacts:
        inode = str(artefact.get("inode", "")).strip()
        direct = str(artefact.get("direct_path", "")).strip()
        logical = str(artefact.get("path", "")).strip()
        digest = ""
        candidate = Path(direct) if direct else None
        if candidate and candidate.is_file():
            try:
                digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
            except OSError:
                digest = ""
        key = (f"sha256:{digest}" if digest else
               f"inode:{inode}" if inode else
               f"path:{direct or logical}".lower())
        if key in seen:
            prior = seen[key]
            aliases = prior.setdefault("source_aliases", [])
            alias = direct or logical
            if alias and alias not in aliases:
                aliases.append(alias)
            continue
        artefact = dict(artefact)
        if digest:
            artefact["content_sha256"] = digest
        artefact.setdefault("source_aliases", [direct or logical] if (direct or logical) else [])
        seen[key] = artefact
        result.append(artefact)
    return result


def _content_classify_browser_db(path: Path) -> Optional[str]:
    """Identify browser SQLite artefacts from header and table schema, not path."""
    try:
        with open(path, "rb") as fh:
            if fh.read(16) != b"SQLite format 3\x00":
                return None
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            tables = {
                str(row[0]).lower()
                for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            }
        finally:
            conn.close()
    except (OSError, sqlite3.Error):
        return None
    if {"urls", "visits"}.issubset(tables) or "urls" in tables:
        return "chrome_hist"
    if {"moz_places", "moz_historyvisits"}.issubset(tables) or "moz_places" in tables:
        return "ff_places"
    if "cookies" in tables and ("meta" in tables or "downloads" in tables):
        return "chrome_cookie"
    if "moz_cookies" in tables:
        return "ff_cookies"
    return None


def _dedupe_urls(records: list) -> list:
    """Deduplicate exact browser records without collapsing distinct events."""
    seen: set = set()
    result = []
    for item in records:
        key = (
            item.get("record_type", "visit"), item.get("database_sha256", ""),
            item.get("table", ""), item.get("rowid", ""),
            item.get("url", ""), item.get("visit_time", ""),
            item.get("start_time", ""), item.get("end_time", ""),
            item.get("last_access_time", ""),
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception:
            pass

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "browser_artifacts").mkdir(exist_ok=True)

    findings: list[Finding] = []
    errors: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        _result = _fail(MODULE_NAME, case_id, start_time,
                        f"Evidence not found: {evidence_path}", coc_logger, logger)
        _result.class_results.append(ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="Browser History Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
        ))
        return _result

    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    tlog(f"[BROWSER] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")

    # Primary native/content path: inspect every SQLite file in the extracted
    # corpus and classify it from its schema. A synthetic or relocated History
    # database is therefore found even when its path does not resemble a real
    # Chrome/Firefox installation.
    _roots = resolve_corpus_roots(config.get("_working_set", {}), output_dir=output_dir)
    browser_matches: list[dict] = []
    for _root in _roots:
        try:
            _candidates = _root.rglob("*")
        except OSError as exc:
            errors.append(f"Cannot enumerate native corpus {_root}: {exc}")
            continue
        for _path in _candidates:
            try:
                if not _path.is_file() or _path.is_symlink():
                    continue
            except OSError:
                continue
            _btype = _content_classify_browser_db(_path)
            if _btype:
                browser_matches.append({
                    "path": str(_path),
                    "direct_path": str(_path),
                    "inode": "",
                    "browser_type": _btype,
                    "detection_basis": "sqlite_header_and_table_schema",
                })

    # Optional verification/fallback path.  Missing Sleuth Kit is not an error
    # when the native corpus exists: the content-based path above is complete
    # for SQLite browser databases and should not be downgraded merely because
    # an accelerator is absent.
    if _roots:
        fls_entries: list[dict] = []
        tlog(
            f"[BROWSER] Native corpus available ({len(_roots)} root(s)); "
            "skipping optional fls enumeration."
        )
    else:
        tlog("[BROWSER] No native corpus; trying optional fls enumeration...")
        fls_entries = _run_fls(analysis_path, logger, errors, offset=partition_offset)
        tlog(f"[BROWSER] fls: {len(fls_entries)} filesystem entries (optional TSK path)")

    for entry in fls_entries:
        norm = entry["path"].replace("\\", "/")
        for btype, pat in _BROWSER_PATTERNS:
            if pat.search(norm):
                browser_matches.append({**entry, "browser_type": btype})
                break

    browser_matches = _dedupe_artefacts(browser_matches)
    tlog(f"[BROWSER] Found {len(browser_matches)} browser artifact(s)")

    all_history: list[dict] = []
    total_urls = 0
    unique_browser_matches: list[dict] = []
    duplicate_browser_aliases: list[dict] = []
    seen_history_sets: dict[tuple, str] = {}

    # FIX #12: removed arbitrary cap of 15 — process all browser artifacts found
    for match in browser_matches:
        dest_name = re.sub(r"[^A-Za-z0-9_.\-]", "_",
                            f"{match['browser_type']}_{Path(match['path']).name}")
        direct_path = match.get("direct_path")
        if direct_path:
            dest = Path(direct_path)
            tlog(
                f"[BROWSER] Content-classified {match['browser_type']}: {dest.name} "
                f"({dest.stat().st_size:,} bytes)"
            )
        else:
            dest = output_dir / "browser_artifacts" / dest_name
            if not dest.exists():
                dest, err = _icat_extract(analysis_path,
                                           match["inode"], dest, logger,
                                           offset=partition_offset)
                if err:
                    errors.append(f"icat failed: {err}")
                    tlog(f"[BROWSER] FAILED {match['path']}: {err}")
                    continue
            tlog(f"[BROWSER] Extracted {match['browser_type']}: {dest.name} "
                 f"({dest.stat().st_size:,} bytes)")

        history = _parse_browser_artifact(dest, match["browser_type"], logger)
        if history:
            semantic_key = tuple(sorted(
                (str(item.get("url") or ""), str(item.get("title") or ""),
                 str(item.get("visit_time") or item.get("last_visited") or ""),
                 int(item.get("visit_count") or 0))
                for item in history
            ))
            if semantic_key in seen_history_sets:
                duplicate_browser_aliases.append({
                    "path": match.get("path"),
                    "alias_of": seen_history_sets[semantic_key],
                    "record_count": len(history),
                })
                tlog(f"[BROWSER] Duplicate logical history database suppressed: {dest.name}")
                continue
            seen_history_sets[semantic_key] = str(match.get("path") or dest)
            unique_browser_matches.append(match)
            all_history.extend(history)
            tlog(f"[BROWSER] Parsed {len(history)} URL(s) from {dest.name}")

            db_sha256 = str(match.get("content_sha256") or hashlib.sha256(dest.read_bytes()).hexdigest())
            findings.append(make_finding(
                "BROWSER_DATABASE_PARSED", Severity.INFO,
                f"A browser SQLite database was structurally parsed: {len(history)} exact record(s).",
                str(match.get("path") or dest),
                {
                    **deterministic_metadata(
                        "SQLite header/schema and row-level queries",
                        validators=["SQLite immutable read-only parser", "table schema", "row provenance"],
                        semantic_limit="Exact stored records only; visit intent and maliciousness are not inferred.",
                    ),
                    "file_path": str(dest), "file_sha256": db_sha256,
                    "logical_path": str(match.get("path") or ""),
                    "browser_type": match["browser_type"],
                    "record_count": len(history),
                    "source_aliases": match.get("source_aliases") or [],
                },
                artifact_path=str(dest),
            ))
            for record in history:
                record_type = str(record.get("record_type") or "visit")
                if record_type == "download":
                    desc = f"A browser download row was parsed from table {record.get('table')} row {record.get('rowid')}."
                    ftype = "BROWSER_DOWNLOAD_RECORD"
                else:
                    desc = f"A browser visit row was parsed from table {record.get('table')} row {record.get('rowid')}."
                    ftype = "BROWSER_VISIT_RECORD"
                findings.append(make_finding(
                    ftype, Severity.INFO, desc,
                    str(match.get("path") or dest),
                    {
                        **deterministic_metadata(
                            "SQLite row extraction with exact table and row identifier",
                            validators=["SQLite immutable read-only parser", "table/rowid locator"],
                            semantic_limit="Stored browser record only; maliciousness or user intent is not inferred.",
                        ),
                        **record,
                        "file_path": str(dest), "file_sha256": db_sha256,
                        "source_aliases": match.get("source_aliases") or [],
                    },
                    artifact_path=str(dest),
                ))
                if record_type == "visit" and _is_suspicious_url(str(record.get("url") or "")):
                    findings.append(make_finding(
                        "BROWSER_URL_REVIEW_CANDIDATE", Severity.INFO,
                        "A stored URL matched configured review terms; this is a candidate only and does not establish maliciousness or intent.",
                        str(match.get("path") or dest),
                        {
                            **candidate_metadata(
                                "configured URL review-term match",
                                reason="Keyword/path matching is heuristic and cannot establish maliciousness or intent.",
                            ),
                            **record, "file_path": str(dest), "file_sha256": db_sha256,
                        },
                        artifact_path=str(dest),
                    ))


    all_history = _dedupe_urls(all_history)
    total_urls = sum(1 for item in all_history if item.get("record_type") == "visit")

    # ── Write manifest ───────────────────────────────────────────────────────
    manifest = {
        "module":        MODULE_NAME,
        "case_id":       case_id,
        "generated_at":  utc_now(),
        "browser_files": len(unique_browser_matches),
        "duplicate_browser_aliases": duplicate_browser_aliases,
        "total_urls":    sum(1 for r in all_history if r.get("record_type") == "visit"),
        "total_downloads": sum(1 for r in all_history if r.get("record_type") == "download"),
        # FIX #12: removed arbitrary 200-entry cap — report full history count
        "history":       all_history,
        "findings":      len(findings),
        "errors":        errors,
    }
    manifest_path = output_dir / "browser_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    (output_dir / "terminal_output.txt").write_text("\n".join(terminal_lines), encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[BROWSER] Completed in {wall_elapsed:.1f}s — {len(findings)} findings, "
         f"{total_urls} URLs")

    status = (ModuleStatus.COMPLETED if not errors
              else ModuleStatus.PARTIAL if unique_browser_matches
              else ModuleStatus.FAILED)

    summary = (
        f"Browser history: {len(unique_browser_matches)} unique artifact(s), "
        f"{total_urls} visit record(s), {sum(1 for r in all_history if r.get('record_type') == 'download')} download record(s). {len(findings)} canonical finding(s)."
    )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED
                else EventType.MODULE_FAILED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value},
            )
        except Exception:
            pass

    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="Browser History Artefacts",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )

    _result = ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings, artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={"browser_files": len(unique_browser_matches),
                    "duplicate_browser_aliases": len(duplicate_browser_aliases),
                    "total_urls": total_urls,
                    "total_downloads": sum(1 for r in all_history if r.get("record_type") == "download") ,
                    "execution_outcome": "ran_found_x" if findings else "ran_found_nothing"},
        summary=summary,
    )
    _result.class_results.append(cr)
    return _result


# ---------------------------------------------------------------------------
# Browser artifact parsers
# ---------------------------------------------------------------------------

def _parse_browser_artifact(path: Path, browser_type: str,
                              logger: logging.Logger) -> list[dict]:
    """Dispatch to format-specific parser. Returns list of URL visit dicts."""
    try:
        if browser_type in ("chrome_hist", "ff_places", "edge_chrom", "ff_cookies"):
            return _parse_sqlite_history(path, browser_type, logger)
        elif browser_type in ("ie_history", "ie_cache"):
            return _parse_index_dat(path, logger)
        elif browser_type == "edge_cache":
            return _parse_webcache(path, logger)
        else:
            return _parse_sqlite_history(path, browser_type, logger)
    except Exception as exc:
        logger.warning("Browser parse error %s: %s", path.name, exc)
        return []


def _chrome_time(value: Any) -> str:
    try:
        raw = int(value or 0)
        if raw <= 0:
            return ""
        from datetime import datetime, timezone
        return datetime.fromtimestamp(raw / 1_000_000 - 11_644_473_600, tz=timezone.utc).isoformat()
    except (ValueError, OSError, OverflowError):
        return ""


def _firefox_time(value: Any) -> str:
    try:
        raw = int(value or 0)
        if raw <= 0:
            return ""
        from datetime import datetime, timezone
        return datetime.fromtimestamp(raw / 1_000_000, tz=timezone.utc).isoformat()
    except (ValueError, OSError, OverflowError):
        return ""


def _parse_sqlite_history(path: Path, browser_type: str, logger: logging.Logger) -> list[dict]:
    """Parse exact browser rows with table/rowid provenance."""
    results: list[dict] = []
    try:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        conn = sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            tables = {str(r[0]).lower() for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
            if "urls" in tables:
                # Chromium visit records. Prefer the visits table for each event;
                # fall back to the URLs aggregate when no visits table exists.
                if "visits" in tables:
                    try:
                        query = """
                            SELECT v.rowid AS visit_rowid, v.visit_time, v.from_visit,
                                   v.transition, u.rowid AS url_rowid, u.url, u.title,
                                   u.visit_count, u.last_visit_time
                            FROM visits v JOIN urls u ON u.id = v.url
                            ORDER BY v.visit_time
                        """
                        for row in conn.execute(query):
                            results.append({
                                "record_type": "visit", "browser": "chromium",
                                "database": str(path), "database_sha256": digest,
                                "table": "visits+urls", "rowid": row["visit_rowid"],
                                "url_rowid": row["url_rowid"], "url": str(row["url"] or ""),
                                "title": str(row["title"] or ""),
                                "visit_count": int(row["visit_count"] or 0),
                                "visit_time": _chrome_time(row["visit_time"]),
                                "last_visit_time": _chrome_time(row["last_visit_time"]),
                                "from_visit": row["from_visit"], "transition": row["transition"],
                            })
                    except sqlite3.Error:
                        pass
                if not any(r.get("record_type") == "visit" for r in results):
                    try:
                        for row in conn.execute(
                            "SELECT rowid, url, title, visit_count, last_visit_time FROM urls ORDER BY last_visit_time"
                        ):
                            results.append({
                                "record_type": "visit", "browser": "chromium",
                                "database": str(path), "database_sha256": digest,
                                "table": "urls", "rowid": row[0],
                                "url": str(row[1] or ""), "title": str(row[2] or ""),
                                "visit_count": int(row[3] or 0), "visit_time": _chrome_time(row[4]),
                            })
                    except sqlite3.Error:
                        pass
                if "downloads" in tables:
                    columns = {str(r[1]).lower() for r in conn.execute('PRAGMA table_info("downloads")')}
                    select_cols = ["rowid"] + [c for c in (
                        "id", "current_path", "target_path", "start_time", "end_time",
                        "last_access_time", "received_bytes", "total_bytes", "state",
                        "danger_type", "interrupt_reason", "opened", "referrer", "tab_url", "site_url"
                    ) if c in columns]
                    try:
                        for row in conn.execute("SELECT " + ",".join(select_cols) + " FROM downloads"):
                            values = dict(zip(select_cols, row))
                            url = str(values.get("tab_url") or values.get("site_url") or values.get("referrer") or "")
                            results.append({
                                "record_type": "download", "browser": "chromium",
                                "database": str(path), "database_sha256": digest,
                                "table": "downloads", "rowid": values.get("rowid"),
                                "download_id": values.get("id"), "url": url,
                                "current_path": str(values.get("current_path") or ""),
                                "target_path": str(values.get("target_path") or ""),
                                "start_time": _chrome_time(values.get("start_time")),
                                "end_time": _chrome_time(values.get("end_time")),
                                "last_access_time": _chrome_time(values.get("last_access_time")),
                                "received_bytes": values.get("received_bytes"),
                                "total_bytes": values.get("total_bytes"),
                                "state": values.get("state"), "opened": values.get("opened"),
                            })
                    except sqlite3.Error:
                        pass
            if "moz_places" in tables:
                try:
                    query = """
                        SELECT h.rowid AS visit_rowid, h.visit_date, h.from_visit, h.visit_type,
                               p.rowid AS place_rowid, p.url, p.title, p.visit_count, p.last_visit_date
                        FROM moz_historyvisits h JOIN moz_places p ON p.id = h.place_id
                        ORDER BY h.visit_date
                    """
                    if "moz_historyvisits" not in tables:
                        raise sqlite3.OperationalError("no visits table")
                    for row in conn.execute(query):
                        results.append({
                            "record_type": "visit", "browser": "firefox",
                            "database": str(path), "database_sha256": digest,
                            "table": "moz_historyvisits+moz_places", "rowid": row["visit_rowid"],
                            "place_rowid": row["place_rowid"], "url": str(row["url"] or ""),
                            "title": str(row["title"] or ""), "visit_count": int(row["visit_count"] or 0),
                            "visit_time": _firefox_time(row["visit_date"]),
                            "last_visit_time": _firefox_time(row["last_visit_date"]),
                            "from_visit": row["from_visit"], "visit_type": row["visit_type"],
                        })
                except sqlite3.Error:
                    try:
                        for row in conn.execute(
                            "SELECT rowid, url, title, visit_count, last_visit_date FROM moz_places ORDER BY last_visit_date"
                        ):
                            results.append({
                                "record_type": "visit", "browser": "firefox",
                                "database": str(path), "database_sha256": digest,
                                "table": "moz_places", "rowid": row[0],
                                "url": str(row[1] or ""), "title": str(row[2] or ""),
                                "visit_count": int(row[3] or 0), "visit_time": _firefox_time(row[4]),
                            })
                    except sqlite3.Error:
                        pass
        finally:
            conn.close()
    except (OSError, sqlite3.Error) as exc:
        logger.warning("SQLite history parse error: %s", exc)
    return results


def _parse_index_dat(path: Path, logger: logging.Logger) -> list[dict]:
    """Parse Internet Explorer index.dat for URLs."""
    results: list[dict] = []
    try:
        data = path.read_bytes()
        # index.dat magic: "Client UrlCache MMF Ver 5.2"
        url_re = re.compile(rb"https?://[^\x00\r\n]{10,300}", re.IGNORECASE)
        urls = set()
        for m in url_re.finditer(data):
            url = m.group(0).decode("ascii", errors="replace")
            if url not in urls:
                urls.add(url)
                results.append({"url": url[:300], "browser": "ie", "visit_time": ""})
    except Exception as exc:
        logger.warning("index.dat parse error: %s", exc)
    return results


def _parse_webcache(path: Path, logger: logging.Logger) -> list[dict]:
    """Parse Edge WebCacheV01.dat ESE database (extract URLs from binary)."""
    results: list[dict] = []
    try:
        data = path.read_bytes()
        url_re = re.compile(rb"https?://[^\x00\r\n<>\"]{10,300}", re.IGNORECASE)
        urls = set()
        for m in url_re.finditer(data):
            url = m.group(0).decode("utf-8", errors="replace")
            if url not in urls and len(url) > 15:
                urls.add(url)
                results.append({"url": url[:300], "browser": "edge_legacy", "visit_time": ""})
    except Exception as exc:
        logger.warning("WebCache parse error: %s", exc)
    return results


# ---------------------------------------------------------------------------
# Suspicious URL detection
# ---------------------------------------------------------------------------

_SUSPICIOUS_URL_PATTERNS = [
    re.compile(r"\.onion([:/?]|$)", re.IGNORECASE),        # Tor hidden services
    re.compile(r"pastebin\.com|ghostbin\.com", re.IGNORECASE),  # Pastebin
    re.compile(r"(mega|mediafire|zippyshare|anonfiles)\.com", re.IGNORECASE),  # File sharing
    re.compile(r"bitcoin|ethereum|crypto.*wallet|monero", re.IGNORECASE),  # Crypto
    re.compile(r"(buy|sell|purchase).*(gun|weapon|drug|ammo)", re.IGNORECASE),
    re.compile(r"vpn|proxifier|anonymizer|hide.*ip", re.IGNORECASE),
    re.compile(r"(john|hashcat|metasploit|kali|exploit)", re.IGNORECASE),
    re.compile(r"wireshark|aircrack|nmap.*download", re.IGNORECASE),
    re.compile(r"steganography|steghide|stegano", re.IGNORECASE),
    re.compile(r"(ccleaner|bleachbit|eraser).*download", re.IGNORECASE),
]


def _is_suspicious_url(url: str) -> bool:
    return any(p.search(url) for p in _SUSPICIOUS_URL_PATTERNS)


# ---------------------------------------------------------------------------
# fls / icat helpers
# ---------------------------------------------------------------------------

def _run_fls(analysis_path: Path,
             logger: logging.Logger, errors: list,
             offset: int = 0) -> list[dict]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found")
        return []
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return []
    entries = []
    for line in stdout.splitlines():
        m = re.match(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", line.strip())
        if m and not m.group(2).endswith("/"):
            entries.append({"inode": m.group(1).split("-")[0], "path": m.group(2).strip()})
    return entries


def _icat_extract(analysis_path: Path, inode: str,
                  dest: Path, logger: logging.Logger,
                  offset: int = 0) -> tuple[Path, str | None]:
    import subprocess as _subprocess
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    logger.debug("icat cmd: %s", " ".join(cmd))
    try:
        result = _subprocess.run(
            cmd, capture_output=True, timeout=ICAT_TIMEOUT, shell=False
        )
    except FileNotFoundError:
        return dest, "icat not found"
    except _subprocess.TimeoutExpired:
        return dest, f"icat timed out after {ICAT_TIMEOUT}s"
    except Exception as exc:
        return dest, str(exc)
    if result.returncode != 0:
        stderr_txt = result.stderr.decode("utf-8", errors="replace")[:200]
        return dest, f"icat exit {result.returncode}: {stderr_txt}"
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(result.stdout)
        return dest, None
    except OSError as exc:
        return dest, str(exc)


def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    logger.error("Module %s failed: %s", module_name, reason)
    return ModuleResult(
        module_name=module_name, case_id=case_id, status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(), duration_seconds=0.0,
        findings=[], artifact_paths=[], errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
    )
