"""
anti_forensic_detector.py — Anti-Forensic Activity Detection Module.

Detects and documents anti-forensic acts from registry, file system,
and artifact evidence:
  - Prefetch folder empty / disabled (CRITICAL anti-forensic indicator)
  - Event log clearing / truncation
  - Wiping/cleaner tools installed or executed (CCleaner, Eraser, BleachBit)
  - MRU list clearing
  - Recycle Bin wiping
  - File shredding tools
  - Disk wiping tools (SDelete, DBAN references)
  - Registry key deletion patterns
  - VSS (Volume Shadow Copy) deletion
  - NTFS journal deletion
  - Timestamp manipulation artifacts

Produces a numbered anti-forensic acts table for the report.

Target platform : Kali Linux, Python 3.11
External tools  : fls (The Sleuth Kit), python-registry (pip)
"""

from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Finding,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME = "anti_forensic_detector"
FLS_TIMEOUT  = 3600
ICAT_TIMEOUT = 300

# Anti-forensic tool indicators
_WIPING_TOOLS = [
    ("CCleaner",      re.compile(r"ccleaner", re.IGNORECASE)),
    ("Eraser",        re.compile(r"eraser.*exe|eraser.*setup", re.IGNORECASE)),
    ("BleachBit",     re.compile(r"bleachbit", re.IGNORECASE)),
    ("SDelete",       re.compile(r"sdelete", re.IGNORECASE)),
    ("FileShredder",  re.compile(r"fileshredder|file.?shredder", re.IGNORECASE)),
    ("PriVaZer",      re.compile(r"privazer", re.IGNORECASE)),
    ("Moo0AntiRecovery", re.compile(r"moo0", re.IGNORECASE)),
    ("FreeRaser",     re.compile(r"freeraser|free.?raser", re.IGNORECASE)),
    ("HardWipe",      re.compile(r"hardwipe", re.IGNORECASE)),
    ("Wipe",          re.compile(r"\bwipe.*\.exe|\bwipe.*setup", re.IGNORECASE)),
    ("DBAN",          re.compile(r"dban|darik", re.IGNORECASE)),
    ("Disk Wipe",     re.compile(r"diskwipe|disk.?wipe", re.IGNORECASE)),
    ("CipherShed",    re.compile(r"ciphershed", re.IGNORECASE)),
    ("VeraCrypt",     re.compile(r"veracrypt", re.IGNORECASE)),
    ("TrueCrypt",     re.compile(r"truecrypt", re.IGNORECASE)),
    ("Recuva",        re.compile(r"recuva", re.IGNORECASE)),  # recovery awareness
    ("PhotoRec",      re.compile(r"photorec", re.IGNORECASE)),  # recovery awareness
    ("AntiRecovery",  re.compile(r"anti.?recovery|antirecovery", re.IGNORECASE)),
    ("Cipher /W",     re.compile(r"cipher.*\/w|cipher.*/w", re.IGNORECASE)),
    ("Format /P",     re.compile(r"format.*\/p|format.*/p", re.IGNORECASE)),
]

# Forensic investigation tool indicators
_FORENSIC_TOOLS = [
    ("FTK",         re.compile(r"ftk|forensic toolkit", re.IGNORECASE)),
    ("Autopsy",     re.compile(r"autopsy", re.IGNORECASE)),
    ("EnCase",      re.compile(r"encase", re.IGNORECASE)),
    ("Helix",       re.compile(r"helix.*live|e-fense", re.IGNORECASE)),
    ("WinHex",      re.compile(r"winhex", re.IGNORECASE)),
    ("Recuva",      re.compile(r"recuva", re.IGNORECASE)),
    ("R-Studio",    re.compile(r"r-studio|rstudio.*recover", re.IGNORECASE)),
    ("ProDiscover", re.compile(r"prodiscover", re.IGNORECASE)),
    ("X-Ways",      re.compile(r"x-ways|xways", re.IGNORECASE)),
    ("Cellebrite",  re.compile(r"cellebrite|ufed", re.IGNORECASE)),
    ("GetDataBack", re.compile(r"getdataback|ntfs recovery", re.IGNORECASE)),
]

# Encryption tool indicators
_ENCRYPTION_TOOLS = [
    ("VeraCrypt",  re.compile(r"veracrypt", re.IGNORECASE)),
    ("TrueCrypt",  re.compile(r"truecrypt", re.IGNORECASE)),
    ("BitLocker",  re.compile(r"bitlocker|manage-bde", re.IGNORECASE)),
    ("AxCrypt",    re.compile(r"axcrypt", re.IGNORECASE)),
    ("7-Zip AES",  re.compile(r"7z.*password|7-zip.*encryp", re.IGNORECASE)),
    ("EncFS",      re.compile(r"encfs", re.IGNORECASE)),
    ("AESCrypt",   re.compile(r"aescrypt|aes crypt", re.IGNORECASE)),
    ("GNU PG",     re.compile(r"gpg4win|gnupg", re.IGNORECASE)),
    ("EFS",        re.compile(r"cipher.*\/e|efs.*enabled", re.IGNORECASE)),
]

# Anti-forensic command patterns (in shell history, prefetch, etc.)
_AF_COMMANDS = [
    ("wevtutil cl",       "Event log clearing command"),
    ("Clear-EventLog",    "PowerShell event log clearing"),
    ("vssadmin delete",   "Volume shadow copy deletion"),
    ("bcdedit /set",      "Boot configuration modification"),
    ("sfc /scannow",      "System file integrity scan (possibly repair after tampering)"),
    ("cipher /w",         "Secure free space wipe"),
    ("format /p",         "DoD overwrite format"),
    ("del /f /s /q",      "Forced recursive file deletion"),
    ("net user /delete",  "User account deletion"),
    ("reg delete",        "Registry key deletion"),
    ("wmic shadowcopy",   "VSS management"),
    ("Set-MpPreference",  "Windows Defender modification"),
    ("Disable-WindowsOptionalFeature", "Windows feature disabling"),
]


def _check_forensic_tools(fls_entries: list[dict]) -> list[dict]:
    """Detect presence of forensic/investigation awareness tools."""
    hits = []
    for entry in fls_entries:
        path_lower = entry["path"].lower()
        for tool_name, pat in _FORENSIC_TOOLS:
            if pat.search(path_lower):
                if not any(h["tool"] == tool_name for h in hits):
                    hits.append({"tool": tool_name, "path": entry["path"]})
                    break
    return hits


def _check_encryption_tools(fls_entries: list[dict]) -> list[dict]:
    """Detect encryption tools that may hide evidence."""
    hits = []
    for entry in fls_entries:
        path_lower = entry["path"].lower()
        for tool_name, pat in _ENCRYPTION_TOOLS:
            if pat.search(path_lower):
                if not any(h["tool"] == tool_name for h in hits):
                    hits.append({"tool": tool_name, "path": entry["path"]})
                    break
    return hits


def _check_batch_account_creation(case_output_root: Path, logger: logging.Logger) -> list[dict]:
    """
    Read windows_registry_analyzer output for user accounts with timestamps.
    Flag any accounts created within 60 seconds of each other.
    """
    import json as _json
    reg_manifest = case_output_root / "windows_registry_analyzer" / "registry_manifest.json"
    if not reg_manifest.exists():
        return []
    try:
        data = _json.loads(reg_manifest.read_text(encoding="utf-8"))
        accounts = data.get("user_accounts", [])
        timestamped = []
        for acc in accounts:
            ct = acc.get("creation_time")
            if not ct:
                continue
            try:
                from datetime import datetime as _dt
                dt = _dt.fromisoformat(str(ct).replace("Z", "+00:00"))
                timestamped.append((acc.get("username", "?"), dt.timestamp()))
            except Exception:
                continue
        timestamped.sort(key=lambda x: x[1])
        clusters = []
        for i in range(len(timestamped) - 1):
            delta = abs(timestamped[i + 1][1] - timestamped[i][1])
            if delta < 60:
                clusters.append({
                    "account_a":     timestamped[i][0],
                    "account_b":     timestamped[i + 1][0],
                    "delta_seconds": round(delta, 1),
                })
        return clusters
    except Exception as exc:
        logger.debug("batch account check failed: %s", exc)
        return []


def _check_empty_profiles(case_output_root: Path, logger: logging.Logger) -> list[dict]:
    """Flag users whose NTUSER.DAT is smaller than 8 KB (never-used cover account)."""
    import json as _json
    reg_manifest = case_output_root / "windows_registry_analyzer" / "registry_manifest.json"
    if not reg_manifest.exists():
        return []
    try:
        data = _json.loads(reg_manifest.read_text(encoding="utf-8"))
        empty = []
        for acc in data.get("user_accounts", []):
            ntuser_size = acc.get("ntuser_size_bytes", -1)
            if 0 < ntuser_size < 8192:
                empty.append({
                    "username":    acc.get("username", "?"),
                    "ntuser_size": ntuser_size,
                })
        return empty
    except Exception as exc:
        logger.debug("empty profile check failed: %s", exc)
        return []


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception:
            pass

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    findings: list[Finding] = []
    errors: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        return _fail(MODULE_NAME, case_id, start_time,
                     f"Evidence not found: {evidence_path}", coc_logger, logger)

    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    tlog(f"[ANTIF] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")

    # ── Step 1: fls enumeration ──────────────────────────────────────────────
    tlog("[ANTIF] Running fls to detect anti-forensic indicators...")
    fls_entries, fls_raw = _run_fls_full(analysis_path, logger, errors,
                                          offset=partition_offset)
    tlog(f"[ANTIF] fls: {len(fls_entries)} filesystem entries")

    anti_forensic_acts: list[dict] = []
    act_counter = 1

    # New-check result holders (initialised here to keep manifest scope clean)
    double_exts:    list[dict] = []
    forensic_tools: list[dict] = []
    enc_tools:      list[dict] = []
    batch_clusters: list[dict] = []
    empty_profiles: list[dict] = []

    # ── Step 2: Check Prefetch folder ───────────────────────────────────────
    tlog("[ANTIF] Checking Windows Prefetch folder...")
    prefetch_files = [e for e in fls_entries
                      if re.search(r"Windows/Prefetch/.*\.pf$", e["path"], re.IGNORECASE)]
    prefetch_dir_exists = any(
        re.search(r"Windows/Prefetch/?$", e["path"], re.IGNORECASE)
        for e in fls_entries
    )

    if prefetch_dir_exists and not prefetch_files:
        tlog("[ANTIF] Prefetch folder exists but contains no .pf files — indicator requires context")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": "Prefetch Folder Empty",
            "severity": "MEDIUM",
            "description": "Windows Prefetch folder exists but contains no .pf files. "
                           "This can be consistent with clearing, disabled Prefetch, a new "
                           "installation, cleanup or an incomplete image. Cause and intent are not established.",
            "evidence": "Windows/Prefetch/ directory — 0 .pf files",
        })
        act_counter += 1
        findings.insert(0, make_finding(
            "PREFETCH_FOLDER_EMPTY_INDICATOR", Severity.MEDIUM,
            "Windows Prefetch folder exists but contains no .pf files. This is a contextual "
            "indicator only; disabled Prefetch, cleanup, a new installation, an incomplete "
            "image or clearing can produce the same observation.",
            "Windows/Prefetch/",
            {"prefetch_count": 0, "folder_exists": True},
        ))
    elif prefetch_files:
        tlog(f"[ANTIF] Prefetch: {len(prefetch_files)} .pf files (normal)")
    else:
        tlog("[ANTIF] Prefetch: folder not found (non-Windows or disabled)")

    # ── Step 3: Scan fls output for wiping tools ─────────────────────────────
    tlog("[ANTIF] Scanning file system for wiping tools...")
    found_tools: list[dict] = []
    for entry in fls_entries:
        path_lower = entry["path"].lower()
        for tool_name, tool_pat in _WIPING_TOOLS:
            if tool_pat.search(path_lower):
                if not any(f["tool"] == tool_name for f in found_tools):
                    found_tools.append({
                        "tool": tool_name,
                        "path": entry["path"],
                        "inode": entry["inode"],
                    })
                    anti_forensic_acts.append({
                        "act_number": act_counter,
                        "act": f"Wiping Tool: {tool_name}",
                        "severity": "MEDIUM",
                        "description": f"A filename/path associated with wiping or privacy tool "
                                       f"'{tool_name}' was found at '{entry['path']}'. Presence "
                                       "does not establish installation, execution, user attribution or evidence destruction.",
                        "evidence": entry["path"],
                    })
                    act_counter += 1

    if found_tools:
        tlog(f"[ANTIF] Wiping tools found: {', '.join(t['tool'] for t in found_tools)}")
        findings.append(make_finding(
            "WIPING_TOOL_NAME_INDICATORS", Severity.MEDIUM,
            f"{len(found_tools)} wiping/privacy-tool name indicator(s) found: "
            + ", ".join(t["tool"] for t in found_tools) + ". "
            "The observation does not establish that a tool was installed, executed or used to destroy evidence.",
            str(evidence_path),
            {"tools": found_tools},
        ))

    # ── Step 4: Check event log sizes ──────────────────────────────────────
    tlog("[ANTIF] Checking Windows Event Log sizes for clearing...")
    evtx_files = [e for e in fls_entries
                  if re.search(r"\.evtx$", e["path"], re.IGNORECASE)]
    tlog(f"[ANTIF] Found {len(evtx_files)} .evtx log files")

    # ── Step 5: Check for VSS deletion evidence ─────────────────────────────
    tlog("[ANTIF] Checking for VSS/shadow copy deletion patterns...")
    vss_indicators = [e for e in fls_entries
                      if re.search(r"vssadmin|shadowcopy|shadow.*volume", e["path"], re.IGNORECASE)]
    if vss_indicators:
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": "Volume Shadow Copy References Found",
            "severity": "MEDIUM",
            "description": "VSS/shadow copy related files found. If VSS entries are "
                           "absent despite long Windows installation, shadows may have been deleted.",
            "evidence": "; ".join(v["path"] for v in vss_indicators[:3]),
        })
        act_counter += 1

    # ── Step 6: Check recycle bin status ───────────────────────────────────
    tlog("[ANTIF] Checking Recycle Bin status...")
    recycle_i_files = [e for e in fls_entries
                       if re.search(r"\$Recycle\.Bin.*\$I", e["path"], re.IGNORECASE)]
    recycle_r_files = [e for e in fls_entries
                       if re.search(r"\$Recycle\.Bin.*\$R", e["path"], re.IGNORECASE)]
    tlog(f"[ANTIF] Recycle Bin: {len(recycle_i_files)} $I files, {len(recycle_r_files)} $R files")

    if recycle_i_files:
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": "Files Deleted via Recycle Bin",
            "severity": "LOW",
            "description": f"{len(recycle_i_files)} Recycle Bin $I metadata record(s) were found. "
                           "These record deletion-related metadata but are not, by themselves, an anti-forensic indicator.",
            "evidence": f"{len(recycle_i_files)} $I metadata records",
        })
        act_counter += 1
        findings.append(make_finding(
            "RECYCLE_BIN_METADATA", Severity.INFO,
            f"{len(recycle_i_files)} Recycle Bin $I metadata record(s) were identified. "
            "This establishes the presence of deletion metadata, not anti-forensic intent.",
            str(evidence_path),
            {"count": len(recycle_i_files)},
        ))

    # ── Step 7: Check shell history for anti-forensic commands ──────────────
    tlog("[ANTIF] Scanning case artifacts for anti-forensic commands...")
    af_commands_found: list[dict] = []
    case_root = output_dir.parent.parent
    text_corpus = ""
    for p in case_root.rglob("*.txt"):
        try:
            text_corpus += p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass

    for cmd_str, cmd_desc in _AF_COMMANDS:
        if cmd_str.lower() in text_corpus.lower():
            af_commands_found.append({"command": cmd_str, "description": cmd_desc})
            anti_forensic_acts.append({
                "act_number": act_counter,
                "act": f"Command-String Indicator: {cmd_str}",
                "severity": "MEDIUM",
                "description": f"The text pattern '{cmd_str}' was found in extracted text. "
                               f"It is associated with {cmd_desc.lower()}, but a string match does not prove execution, user attribution or intent.",
                "evidence": "Extracted text artifacts",
            })
            act_counter += 1

    if af_commands_found:
        findings.append(make_finding(
            "COMMAND_STRING_INDICATORS", Severity.MEDIUM,
            f"{len(af_commands_found)} command-string indicator(s) detected in extracted text: "
            + ", ".join(c["command"] for c in af_commands_found[:5]) + ". "
            "The result does not establish command execution or intent.",
            str(evidence_path),
            {"commands": af_commands_found},
        ))

    # ── Step 8: Additional anti-forensic checks ───────────────────────────────

    # Double-extension filenames — a distinct anti-forensic signal from the
    # magic-byte-vs-extension mismatch (which is owned and reported by
    # filesystem_deep_analyzer / file_signature_analyzer).  Use the SAME shared
    # double-extension detector that populates the tool-output double-extension
    # line, so the count here can never contradict it, and never label it an
    # "extension mismatch".
    tlog("[ANTIF] Checking double-extension filenames (shared result set)...")
    try:
        from modules.filesystem_deep_analyzer import _detect_extension_mismatches
        double_exts = _detect_extension_mismatches(fls_entries, logger)
    except Exception as exc:
        if logger:
            logger.warning("Could not run shared double-extension check: %s", exc)
        double_exts = []

    if double_exts:
        tlog(f"[ANTIF] Double-extension filenames: {len(double_exts)}")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": f"Double-Extension Filenames ({len(double_exts)})",
            "severity": "MEDIUM",
            "description": (
                f"{len(double_exts)} file(s) have double-extension names. This is "
                "a filename anomaly consistent with masquerading, but the name alone "
                "does not establish user intent or an anti-forensic act."
            ),
            "evidence": "; ".join(
                f"{m['path']} (declared {m['declared_ext']}, inner {m['inner_ext']})"
                for m in double_exts[:3]
            ),
        })
        act_counter += 1
        # The dedicated anti-forensic class needs an evidence-backed outcome of
        # its own. Keep one consolidated finding rather than duplicating each
        # per-file suspicious-name observation.
        findings.append(make_finding(
            "DOUBLE_EXTENSION_FILENAME_INDICATORS", Severity.MEDIUM,
            f"{len(double_exts)} double-extension filename indicator(s) were identified: "
            + "; ".join(str(item.get("path") or "") for item in double_exts[:10])
            + ". Filename structure alone does not establish user intent.",
            str(double_exts[0].get("path") or evidence_path),
            {"double_extensions": double_exts, "indicator_only": True},
        ))

    # Forensic tools
    tlog("[ANTIF] Scanning for forensic investigation tools...")
    forensic_tools = _check_forensic_tools(fls_entries)
    if forensic_tools:
        tlog(f"[ANTIF] Forensic tools found: {', '.join(t['tool'] for t in forensic_tools)}")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": f"Forensic Tools Present ({len(forensic_tools)})",
            "severity": "LOW",
            "description": (
                f"{len(forensic_tools)} forensic-tool name/path indicator(s) found: "
                + ", ".join(t["tool"] for t in forensic_tools) + ". "
                "Presence alone does not establish installation, execution, user attribution or purpose."
            ),
            "evidence": "; ".join(t["path"] for t in forensic_tools[:3]),
        })
        act_counter += 1
        findings.append(make_finding(
            "FORENSIC_TOOL_NAME_INDICATORS", Severity.LOW,
            f"Forensic-related tool names detected: "
            + ", ".join(t["tool"] for t in forensic_tools),
            str(evidence_path),
            {"tools": forensic_tools},
        ))

    # Encryption tools
    tlog("[ANTIF] Scanning for encryption tools...")
    enc_tools = _check_encryption_tools(fls_entries)
    if enc_tools:
        tlog(f"[ANTIF] Encryption tools found: {', '.join(t['tool'] for t in enc_tools)}")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": f"Encryption Tools Present ({len(enc_tools)})",
            "severity": "MEDIUM",
            "description": (
                f"{len(enc_tools)} encryption tool(s) found: "
                + ", ".join(t["tool"] for t in enc_tools) + ". "
                "Encryption-tool presence is neutral without evidence of installation, execution, ownership or concealment."
            ),
            "evidence": "; ".join(t["path"] for t in enc_tools[:3]),
        })
        act_counter += 1
        findings.append(make_finding(
            "ENCRYPTION_TOOL_NAME_INDICATORS", Severity.MEDIUM,
            f"Encryption-related tools detected: "
            + ", ".join(t["tool"] for t in enc_tools),
            str(evidence_path),
            {"tools": enc_tools},
        ))

    # Batch account creation
    tlog("[ANTIF] Checking for batch account creation...")
    batch_clusters = _check_batch_account_creation(output_dir.parent, logger)
    if batch_clusters:
        tlog(f"[ANTIF] Batch account creation clusters: {len(batch_clusters)}")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": f"Batch Account Creation ({len(batch_clusters)} cluster(s))",
            "severity": "MEDIUM",
            "description": (
                f"{len(batch_clusters)} pair(s) of accounts have recorded creation times "
                "within 60 seconds. This can result from administrative automation or imaging "
                "artefacts; scripted concealment and user intent are not established."
            ),
            "evidence": "; ".join(
                f"{c['account_a']} + {c['account_b']} ({c['delta_seconds']}s apart)"
                for c in batch_clusters[:3]
            ),
        })
        act_counter += 1
        findings.append(make_finding(
            "RAPID_ACCOUNT_CREATION_INDICATOR", Severity.MEDIUM,
            f"Rapid account-creation timing indicator: {len(batch_clusters)} pair(s) have "
            "recorded creation times within 60 seconds. Administrative automation, imaging "
            "artefacts and other benign causes remain possible.",
            str(evidence_path),
            {"clusters": batch_clusters},
        ))

    # Empty user profiles
    tlog("[ANTIF] Checking for empty user profiles...")
    empty_profiles = _check_empty_profiles(output_dir.parent, logger)
    if empty_profiles:
        tlog(f"[ANTIF] Empty profiles: {len(empty_profiles)}")
        anti_forensic_acts.append({
            "act_number": act_counter,
            "act": f"Empty User Profiles ({len(empty_profiles)})",
            "severity": "MEDIUM",
            "description": (
                f"{len(empty_profiles)} user profile(s) have NTUSER.DAT smaller than 8 KB: "
                + ", ".join(p["username"] for p in empty_profiles[:5]) + ". "
                "This can be consistent with a new, unused or incomplete profile; a cover "
                "identity and user intent are not established."
            ),
            "evidence": "; ".join(
                f"{p['username']} ({p['ntuser_size']:,} bytes)"
                for p in empty_profiles[:3]
            ),
        })
        act_counter += 1
        findings.append(make_finding(
            "SMALL_USER_PROFILE_INDICATORS", Severity.MEDIUM,
            f"{len(empty_profiles)} small-profile indicator(s) (NTUSER.DAT < 8 KB): "
            + ", ".join(p["username"] for p in empty_profiles) + ". "
            "This does not establish account purpose or user intent.",
            str(evidence_path),
            {"profiles": empty_profiles},
        ))

    # ── Step 9: Record indicator table without creating an aggregate finding ─
    # Concrete findings above are the source of truth. An aggregate "act" row
    # would duplicate them and could overstate intent, so the table remains in
    # raw_data/statistics for examiner review only.
    if anti_forensic_acts:
        tlog(f"[ANTIF] Potential anti-forensic indicators table: {len(anti_forensic_acts)} indicator(s)")

    # ── Canonical cross-module anomaly aggregation ──────────────────────────
    # When the orchestrator provides accepted findings from earlier modules,
    # those exact records are the sole evidentiary input for this module. Legacy
    # filename/tool-name scans remain in the manifest for examiner review but do
    # not create additional PRESENT facts or infer intent.
    canonical_map = ((config.get("_working_set") or {}).get("canonical_findings_by_module") or {})
    legacy_observations = [
        {
            "finding_type": str(getattr(f, "finding_type", "")),
            "description": str(getattr(f, "description", "")),
            "metadata": dict(getattr(f, "metadata", {}) or {}),
        }
        for f in findings
    ]
    if canonical_map:
        categories = {
            "DELETION_WITH_RETAINED_CONTENT": {"DELETED_FILE_RECOVERED"},
            "CONTENT_NAMING_MISMATCH": {"FILE_SIGNATURE_MISMATCH", "DOUBLE_EXTENSION"},
            "HIDDEN_OR_APPENDED_BYTES": {
                "TRAILING_DATA_PRESENT", "STEGANOGRAPHIC_PAYLOAD_DECODED",
                "FILE_SLACK_DATA", "UNALLOCATED_DUPLICATE_OBJECT",
            },
            "ENCRYPTED_RETAINED_CONTENT": {"PASSWORD_PROTECTED_ARCHIVE", "PASSWORD_RECOVERED"},
            "INTERNAL_METADATA_INCONSISTENCY": {
                "DOCUMENT_CASE_IDENTIFIER_MISMATCH", "GEOLOCATION_SOURCE_DISCREPANCY",
                "FUTURE_TIMESTAMP", "TIMELINE_FUTURE_DATE",
                "TIMESTAMP_DATE_AFTER_ACQUISITION", "NORMALIZED_FILESYSTEM_TIMESTAMPS",
            },
        }
        aggregated: list[Finding] = []
        for category, accepted_types in categories.items():
            records: list[dict[str, Any]] = []
            for source_module, source_findings in canonical_map.items():
                if source_module == MODULE_NAME:
                    continue
                for record in source_findings or []:
                    if str(record.get("finding_type") or "").upper() in accepted_types:
                        records.append({**record, "source_module": source_module})
            if not records:
                continue
            first = records[0]
            locations = sorted({
                str((r.get("metadata") or {}).get("file_path") or r.get("evidence_path") or "")
                for r in records if ((r.get("metadata") or {}).get("file_path") or r.get("evidence_path"))
            })
            source_ids = [str(r.get("finding_id") or "") for r in records if r.get("finding_id")]
            aggregated.append(make_finding(
                "ANTI_FORENSIC_STYLE_ANOMALY", Severity.INFO,
                (
                    f"{len(records)} previously validated record(s) were consolidated under "
                    f"{category.replace('_', ' ').lower()}. This reports exact anomalies only; "
                    "user intent, concealment purpose and criminality are not inferred."
                ),
                str(first.get("evidence_path") or evidence_path),
                {
                    **deterministic_metadata(
                        "aggregation of prior H2-accepted canonical finding identifiers",
                        validators=["canonical_findings_by_module", "finding-id equality"],
                        semantic_limit="Anomaly presence only; no anti-forensic intent claim",
                    ),
                    "anomaly_category": category,
                    "source_finding_ids": source_ids,
                    "source_modules": sorted({str(r.get("source_module")) for r in records}),
                    "source_records": records,
                    "locations": locations,
                },
            ))
        findings = aggregated

    # ── Write manifest ───────────────────────────────────────────────────────
    manifest = {
        "module":                  MODULE_NAME,
        "case_id":                 case_id,
        "generated_at":            utc_now(),
        "prefetch_empty":          prefetch_dir_exists and not prefetch_files,
        "prefetch_count":          len(prefetch_files),
        "wiping_tools":            found_tools,
        "evtx_count":              len(evtx_files),
        "recycle_bin_deletions":   len(recycle_i_files),
        "af_commands":             af_commands_found,
        "anti_forensic_acts":      anti_forensic_acts,
        "double_extensions":       len(double_exts),
        "forensic_tools":          forensic_tools,
        "encryption_tools":        enc_tools,
        "batch_account_clusters":  len(batch_clusters),
        "empty_profiles":          empty_profiles,
        "findings":                len(findings),
        "legacy_candidate_observations": legacy_observations,
        "canonical_aggregation_used": bool(canonical_map),
        "errors":                  errors,
    }
    manifest_path = output_dir / "antiforensic_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    for finding in findings:
        if not getattr(finding, "artifact_path", None):
            finding.artifact_path = str(manifest_path)
        finding.metadata.setdefault("report_file", str(manifest_path))
    (output_dir / "terminal_output.txt").write_text("\n".join(terminal_lines), encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[ANTIF] Completed in {wall_elapsed:.1f}s — {len(anti_forensic_acts)} indicator(s), "
         f"{len(findings)} concrete finding(s)")

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL

    summary = (
        f"Anti-forensic indicator analysis: {len(anti_forensic_acts)} indicator(s) recorded "
        f"({len(found_tools)} wiping-tool name indicator(s), prefetch_empty={prefetch_dir_exists and not prefetch_files}). "
        f"{len(findings)} concrete finding(s). Indicators do not establish intent without corroboration."
    )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value},
            )
        except Exception:
            pass

    if findings:
        _af_verdict = AssuranceVerdict.PRESENT
        _af_skip_reason = None
        _af_notes = "Concrete evidence-referenced anti-forensic finding(s) retained."
    elif anti_forensic_acts:
        _af_verdict = AssuranceVerdict.INDETERMINATE
        _af_skip_reason = SkipReason.PARTIAL_FAILURE
        _af_notes = (
            f"{len(anti_forensic_acts)} indicator-only row(s) require examiner review; "
            "no concrete anti-forensic finding was retained."
        )
    else:
        _af_verdict = AssuranceVerdict.VERIFIED_ABSENT
        _af_skip_reason = None
        _af_notes = "Configured anti-forensic checks completed with no retained indicator or concrete finding."

    cr = ClassResult(
        locus=Locus.ANTI_FORENSICS,
        artefact_class="Anti-Forensic Techniques",
        verdict=_af_verdict,
        skip_reason=_af_skip_reason,
        count=len(findings),
        notes=_af_notes,
    )

    canonical_input_count = sum(
        len(records or []) for module_name, records in canonical_map.items()
        if module_name != MODULE_NAME
    ) if isinstance(canonical_map, dict) else 0

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings, artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={"sources_discovered": canonical_input_count,
                     "sources_processed": canonical_input_count,
                     "supported_objects_discovered": canonical_input_count,
                     "supported_objects_processed": canonical_input_count,
                     "records_discovered": canonical_input_count,
                     "records_processed": canonical_input_count,
                     "unresolved_supported_objects": 0,
                     "parser_errors": len(errors),
                     "anti_forensic_acts": len(anti_forensic_acts),
                     "wiping_tools": len(found_tools),
                     "prefetch_empty": int(prefetch_dir_exists and not prefetch_files),
                     "double_extensions": len(double_exts),
                     "execution_outcome": (
                         "ran_found_x" if findings
                         else "ran_with_caveat" if anti_forensic_acts or errors
                         else "ran_found_nothing"
                     )},
        summary=summary,
        class_results=[cr],
    )


# ---------------------------------------------------------------------------
# fls full listing
# ---------------------------------------------------------------------------

def _run_fls_full(analysis_path: Path,
                   logger: logging.Logger, errors: list,
                   offset: int = 0) -> tuple[list[dict], str]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found")
        return [], ""
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return [], ""
    entries = []
    for line in stdout.splitlines():
        m = re.match(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", line.strip())
        if m and not m.group(2).endswith("/"):
            entries.append({"inode": m.group(1).split("-")[0], "path": m.group(2).strip()})
    return entries, stdout


def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    logger.error("Module %s failed: %s", module_name, reason)
    cr = ClassResult(
        locus=Locus.ANTI_FORENSICS,
        artefact_class="Anti-Forensic Techniques",
        verdict=AssuranceVerdict.INDETERMINATE,
        skip_reason=SkipReason.NO_EVIDENCE,
        notes=reason,
    )
    return ModuleResult(
        module_name=module_name, case_id=case_id, status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(), duration_seconds=0.0,
        findings=[], artifact_paths=[], errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
        class_results=[cr],
    )
