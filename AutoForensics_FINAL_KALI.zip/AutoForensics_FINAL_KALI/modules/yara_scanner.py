"""
yara_scanner.py — YARA Rule Scanner for AutoForensics.

Runs YARA rules against all files in the output directory and reports matches
with the file path, rule name, and matched string details.

Two execution modes are supported:
  1. Python yara-python library (preferred — faster, no subprocess overhead).
  2. ``yara`` CLI fallback when the library is not installed.

Rule severity is inferred from rule name prefixes:
  MAL_* → HIGH (known malware family rule)
  SUSP_* → MEDIUM (suspicious behaviour indicator)
  TOOL_* → MEDIUM (dual-use tool — Mimikatz, Cobalt Strike, etc.)
  INFO_* → INFO (benign but noteworthy)
  All others → MEDIUM

Target platform : Kali Linux, Python 3.11+
External tools  : yara (CLI fallback)
Optional libs   : yara-python>=4.3.1
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional
import hashlib

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots, iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

try:
    import yara as _yara_lib  # type: ignore[import]
    _YARA_PY_AVAILABLE = True
except ImportError:
    _yara_lib = None  # type: ignore[assignment]
    _YARA_PY_AVAILABLE = False

MODULE_NAME: str = "yara_scanner"
YARA_CLI_TIMEOUT: int = 300   # 5 minutes per file (CLI mode)
DEFAULT_PER_FILE_TIMEOUT: int = 60   # 60 seconds (yara-python mode)


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _rule_severity(rule_name: str) -> Severity:
    """
    Infer Finding severity from the YARA rule name prefix convention.

    Parameters
    ----------
    rule_name : YARA rule identifier string.

    Returns
    -------
    Severity enum value.
    """
    upper = rule_name.upper()
    if upper.startswith("MAL_") or upper.startswith("MALWARE_"):
        return Severity.HIGH
    if upper.startswith("SUSP_") or upper.startswith("SUSPICIOUS_"):
        return Severity.MEDIUM
    if upper.startswith("TOOL_"):
        return Severity.MEDIUM
    if upper.startswith("INFO_"):
        return Severity.INFO
    if upper.startswith("RANSOM") or upper.startswith("BACKDOOR") or upper.startswith("TROJAN"):
        return Severity.HIGH
    return Severity.MEDIUM


def _collect_rule_files(rules_path_str: str) -> list[Path]:
    """
    Resolve rules_path to a list of .yar/.yara files.

    Parameters
    ----------
    rules_path_str : String path to a directory or single .yar file.

    Returns
    -------
    List of Path objects for all rule files found.
    """
    rules_path = Path(rules_path_str)
    if not rules_path.exists():
        return []
    if rules_path.is_file():
        return [rules_path]
    # Directory — collect all .yar and .yara files recursively
    yar_files: list[Path] = []
    for ext in ("*.yar", "*.yara"):
        yar_files.extend(rules_path.rglob(ext))
    return yar_files


def _rule_identifiers(rule_files: list[Path]) -> list[str]:
    """Return declared rule identifiers for transparent rule-count reporting."""
    names: list[str] = []
    pattern = re.compile(r"(?m)^\s*(?:private\s+|global\s+)?rule\s+([A-Za-z_][A-Za-z0-9_]*)\b")
    for path in rule_files:
        try:
            names.extend(pattern.findall(path.read_text(encoding="utf-8", errors="replace")))
        except OSError:
            continue
    return sorted(set(names))


def _validate_rule_file_cli(rule_file: Path, logger: logging.Logger) -> tuple[bool, str]:
    """Compile-check one YARA source with the CLI without treating no-match as failure."""
    try:
        with tempfile.NamedTemporaryFile(prefix="af_yara_empty_", delete=True) as target:
            rc, _stdout, stderr = _run_subprocess(
                ["yara", "-w", str(rule_file), target.name],
                timeout=30, logger=logger,
            )
        return rc in (0, 1), stderr.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as exc:
        return False, str(exc)


def _scan_file_yara_py(
    compiled_rules: Any,
    file_path: Path,
    per_file_timeout: int,
) -> list[dict[str, Any]]:
    """
    Scan a file using the yara-python compiled rules object.

    Parameters
    ----------
    compiled_rules    : yara.Rules compiled object.
    file_path         : File to scan.
    per_file_timeout  : Timeout in seconds for this file.

    Returns
    -------
    List of match dicts: {rule, tags, strings: [{offset, identifier, data_hex}]}.
    """
    matches: list[dict[str, Any]] = []
    try:
        yara_matches = compiled_rules.match(  # type: ignore[union-attr]
            str(file_path), timeout=per_file_timeout
        )
        for m in yara_matches:
            strings: list[dict[str, Any]] = []
            for s in m.strings:
                # yara-python 4.x: s is a StringMatch object
                for inst in getattr(s, "instances", [s]):
                    offset = getattr(inst, "offset", 0)
                    raw = getattr(inst, "matched_data", getattr(inst, "data", b""))
                    strings.append({
                        "offset": offset,
                        "identifier": getattr(s, "identifier", ""),
                        "data_hex": raw.hex() if isinstance(raw, bytes) else str(raw),
                    })
            matches.append({
                "rule": m.rule,
                "tags": list(m.tags),
                "meta": dict(m.meta),
                "strings": strings,
            })
    except Exception:
        pass
    return matches


def _scan_file_yara_cli(
    rules_file: Path,
    file_path: Path,
    logger: logging.Logger,
) -> list[dict[str, Any]]:
    """
    Scan a file using the yara CLI and parse its output.

    Parameters
    ----------
    rules_file : Path to the .yar rules file.
    file_path  : File to scan.
    logger     : Module logger.

    Returns
    -------
    List of match dicts with rule and file path.
    """
    matches: list[dict[str, Any]] = []
    try:
        rc, stdout, _ = _run_subprocess(
            ["yara", "-s", str(rules_file), str(file_path)],
            timeout=YARA_CLI_TIMEOUT, logger=logger,
        )
        # yara CLI output: "<rule_name> <file_path>" for each match
        for line in stdout.splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) >= 1 and parts[0]:
                matches.append({"rule": parts[0], "tags": [], "strings": []})
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return matches


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Scan all files in output_dir against YARA rules.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing extracted files.
    config        : Configuration dict; recognised keys:
                    - ``yara_rules_path`` (str): directory or .yar file.
                    - ``yara_timeout`` (int): per-file timeout (default 60s).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with YARA_RULE_MATCH findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    # Collect all explicit and evidence-contained rules. Evidence rules are
    # discovered by syntax, not filename, and are analysed in addition to the
    # bundled baseline. This is general recursive evidence dispatch, not fixture
    # prefeeding.
    rule_sources: list[tuple[str, str]] = []
    configured = str(config.get("yara_rules_path", "") or "").strip()
    if configured:
        rule_sources.append(("investigator_configured", configured))
    for value in config.get("evidence_yara_rule_sources") or []:
        if value:
            rule_sources.append(("evidence_contained", str(value)))
    bundled = Path(__file__).resolve().parents[1] / "config" / "yara" / "default_rules.yar"
    if bundled.is_file():
        rule_sources.append(("bundled_default", str(bundled)))

    # De-duplicate rule paths while preserving source provenance.
    seen_rule_paths: set[str] = set()
    rule_files: list[Path] = []
    rule_file_sources: dict[str, list[str]] = {}
    for source_kind, source_path in rule_sources:
        for rf in _collect_rule_files(source_path):
            try:
                key = str(rf.resolve())
            except OSError:
                key = str(rf)
            rule_file_sources.setdefault(key, []).append(source_kind)
            if key not in seen_rule_paths:
                seen_rule_paths.add(key)
                rule_files.append(rf)
    rules_source = "+".join(sorted({k for kinds in rule_file_sources.values() for k in kinds})) or "none"
    per_file_timeout = int(config.get("yara_timeout", DEFAULT_PER_FILE_TIMEOUT))

    if not rule_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MALWARE,
            artefact_class="YARA Rule Matches",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            notes="No configured, evidence-contained, or bundled YARA rule file was available",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["No configured, evidence-contained, or bundled YARA rule file was available"],
            summary="DID NOT RUN — no configured or bundled YARA rules were available.",
            class_results=[cr],
        )

    if not rule_files:
        errors.append("No .yar/.yara files were discovered from configured, evidence-contained, or bundled sources")

    output_dir.mkdir(parents=True, exist_ok=True)

    # Compile rules fail-closed. A scanner that compiled zero rules may never
    # produce VERIFIED_ABSENT, because no detection technique was actually applied.
    compiled_rules: Optional[Any] = None
    valid_rule_files: list[Path] = []
    rule_ids = _rule_identifiers(rule_files)
    compile_errors: list[str] = []
    if _YARA_PY_AVAILABLE and rule_files:
        try:
            filepaths_dict = {f"ns_{i}": str(rf) for i, rf in enumerate(rule_files)}
            compiled_rules = _yara_lib.compile(filepaths=filepaths_dict)  # type: ignore[union-attr]
            valid_rule_files = list(rule_files)
            logger.info("[%s] Compiled %d rule file(s), %d declared rule(s)",
                        MODULE_NAME, len(valid_rule_files), len(rule_ids))
        except Exception as exc:
            compile_errors.append(f"yara-python compile failed: {exc}")
            logger.error("[%s] %s", MODULE_NAME, compile_errors[-1])
            compiled_rules = None
    elif rule_files:
        for rf in rule_files:
            ok, detail = _validate_rule_file_cli(rf, logger)
            if ok:
                valid_rule_files.append(rf)
            else:
                compile_errors.append(f"YARA rule compile failed for {rf}: {detail}")
        if compile_errors:
            for item in compile_errors:
                logger.error("[%s] %s", MODULE_NAME, item)

    if not valid_rule_files:
        errors.extend(compile_errors or ["No YARA rule source compiled successfully"] )

    # Collect target files from this module's dir and sibling artifact/recovery dirs
    # Corpus roots come from what the recovery/carving modules actually
    # produced this run — never from assumed sibling directory names.
    _ws = config.get("_working_set", {})
    _corpus_roots = resolve_corpus_roots(_ws, output_dir=output_dir)
    all_files: list[Path] = []
    aliases_by_hash: dict[str, list[str]] = {}
    canonical_by_hash: dict[str, Path] = {}
    for item in iter_corpus_files(
        _ws, output_dir=output_dir, include_case_context=False,
        include_derived=False, deduplicate_by_hash=False,
    ):
        if item in rule_files:
            continue
        try:
            h = hashlib.sha256()
            with item.open("rb") as fh:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(block)
            digest = h.hexdigest()
        except OSError:
            continue
        aliases_by_hash.setdefault(digest, []).append(str(item))
        canonical_by_hash.setdefault(digest, item)
    all_files = sorted(canonical_by_hash.values(), key=lambda p: str(p))

    logger.info("[%s] Scanning %d unique byte streams against YARA rules", MODULE_NAME, len(all_files))

    files_scanned = 0
    total_matches = 0
    high_severity_matches = 0
    unique_rules_matched: set[str] = set()
    all_match_records: list[dict[str, Any]] = []

    for file_path in all_files:
        file_matches: list[dict[str, Any]] = []

        if compiled_rules is not None:
            file_matches = _scan_file_yara_py(compiled_rules, file_path, per_file_timeout)
        elif valid_rule_files:
            # CLI fallback — one invocation per compile-validated rule file
            for rf in valid_rule_files:
                file_matches.extend(_scan_file_yara_cli(rf, file_path, logger))

        files_scanned += 1

        for match in file_matches:
            rule_name = match.get("rule", "unknown")
            severity = _rule_severity(rule_name)
            total_matches += 1
            unique_rules_matched.add(rule_name)
            if severity == Severity.HIGH:
                high_severity_matches += 1

            findings.append(make_finding(
                finding_type="YARA_RULE_MATCH",
                severity=severity,
                description=(
                    f"YARA rule '{rule_name}' matched file: {file_path.name}"
                ),
                evidence_path=str(evidence_path),
                metadata={
                    **deterministic_metadata(
                        "YARA engine compiled-rule exact match",
                        validators=["yara-python" if compiled_rules is not None else "yara-cli"],
                    ),
                    "file_path": str(file_path),
                    "file_sha256": next((d for d, p in canonical_by_hash.items() if p == file_path), ""),
                    "byte_identical_aliases": aliases_by_hash.get(next((d for d, p in canonical_by_hash.items() if p == file_path), ""), []),
                    "rule_name": rule_name,
                    "tags": match.get("tags", []),
                    "matched_strings": match.get("strings", [])[:5],
                    "meta": match.get("meta", {}),
                    "rule_source_paths": [str(p) for p in valid_rule_files],
                },
            ))
            all_match_records.append({
                "file_path": str(file_path),
                "rule_name": rule_name,
                "severity": severity.value,
                "tags": match.get("tags", []),
                "strings": match.get("strings", []),
            })

    # Write results
    results_path = output_dir / "yara_matches.json"
    try:
        with open(results_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(),
                "files_scanned": files_scanned,
            "unique_byte_streams_scanned": len(all_files),
            "duplicate_aliases_collapsed": sum(max(0, len(v) - 1) for v in aliases_by_hash.values()),
                "rules_source": rules_source,
                "rule_files": [str(path) for path in rule_files],
                "rule_file_sources": rule_file_sources,
                "valid_rule_files": [str(path) for path in valid_rule_files],
                "declared_rule_ids": rule_ids,
                "compile_errors": compile_errors,
                "total_matches": total_matches,
                "high_severity_matches": high_severity_matches,
                "unique_rules_matched": list(unique_rules_matched),
                "matches": all_match_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(results_path))
    except OSError as exc:
        errors.append(f"Failed to write yara_matches.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    technique_applied = bool(valid_rule_files) and files_scanned > 0
    if not valid_rule_files:
        status = ModuleStatus.ERROR
    elif errors:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.COMPLETED

    summary = (
        f"Compiled {len(valid_rule_files)} rule file(s) containing {len(rule_ids)} declared rule(s); "
        f"scanned {files_scanned} files; {total_matches} YARA matches "
        f"({high_severity_matches} HIGH) across {len(unique_rules_matched)} matched rules."
    )
    if not technique_applied:
        summary = "INDETERMINATE — no YARA rule set compiled and executed successfully. " + summary

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "matches": total_matches})

    cr = ClassResult(
        locus=Locus.MALWARE,
        artefact_class="YARA Rule Matches",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT if technique_applied
            else AssuranceVerdict.INDETERMINATE
        ),
        skip_reason=(None if technique_applied else SkipReason.DEPENDENCY_MISSING),
        count=len(findings),
        notes=("" if technique_applied else "No valid YARA rules compiled; no absence conclusion was made."),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            "files_scanned": files_scanned,
            "sources_discovered": len(all_files),
            "sources_processed": files_scanned,
            "supported_objects_discovered": len(all_files),
            "supported_objects_processed": files_scanned,
            "records_discovered": len(all_files),
            "records_processed": files_scanned,
            "unresolved_supported_objects": max(0, len(all_files) - files_scanned),
            "parser_errors": len(errors),
            "engine_completed": bool(
                technique_applied and not compile_errors and not errors
                and files_scanned == len(all_files)
            ),
            "rules_source": rules_source,
            "rule_files": len(rule_files),
            "valid_rule_files": len(valid_rule_files),
            "declared_rules": len(rule_ids),
            "rules_compiled": bool(valid_rule_files),
            "compile_errors": compile_errors,
            "total_matches": total_matches,
            "high_severity_matches": high_severity_matches,
            "unique_rules_matched": len(unique_rules_matched),
        },
        summary=summary,
        class_results=[cr],
    )
