"""
image_content_analyzer.py — Image Content Analysis and Embedded Figure Generation.

Analyzes all image files found in the evidence image:
  - Extract and embed every image as a base64 figure in the report
  - OCR text recognition (Tesseract) for printed text in images
  - Flag images containing ID cards, passports, credit cards (pattern matching)
  - EXIF metadata extraction for GPS coordinates and device info
  - Face-like image detection via basic heuristics (skin tone pixel ratio)
  - Steganography pre-screening (file size anomalies vs content)

Auto-installs: tesseract-ocr (apt), python-tesseract (pip), exiftool (apt)

Target platform : Kali Linux, Python 3.11
External tools  : tesseract, exiftool, fls, icat (The Sleuth Kit)
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import candidate_metadata, deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Finding,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    iter_corpus_files,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME = "image_content_analyzer"
FLS_TIMEOUT  = 3600
ICAT_TIMEOUT = 300
MAX_IMAGES_TO_EMBED = 50   # max preview payloads exposed to the report
MAX_IMAGES_TO_ANALYZE = 0  # zero means exhaustive; configured caps become explicit partial coverage
MAX_IMAGE_BYTES = 0  # zero means no module-imposed byte-size exclusion
OCR_TIMEOUT = 30

# Image file extensions to analyze
_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".tif",
               ".webp", ".ico", ".heic", ".heif", ".raw", ".cr2", ".nef"}

# Tesseract OCR patterns that flag document images
_ID_PATTERNS = [
    (re.compile(r"passport|PASSPORT|United States|UNITED STATES|Republic|REPUBLIC",
                re.IGNORECASE), "Passport"),
    (re.compile(r"driver.?s? licen[cs]e|DL|driver license", re.IGNORECASE), "Driver License"),
    (re.compile(r"credit card|debit card|VISA|MasterCard|AMERICAN EXPRESS|Discover",
                re.IGNORECASE), "Credit/Debit Card"),
    (re.compile(r"social security|SSN|social insurance", re.IGNORECASE), "Social Security Card"),
    (re.compile(r"birth certificate|BIRTH CERTIFICATE", re.IGNORECASE), "Birth Certificate"),
    (re.compile(r"\b\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4}\b", re.IGNORECASE), "Card Number Pattern"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "SSN Pattern"),
    (re.compile(r"\bP[0-9A-Z]{8}\b"), "Passport Number Pattern"),
]

# GPS extraction patterns for EXIF
_GPS_RE = re.compile(
    r"GPS.*?(\d+)\s+deg\s+(\d+)'\s+([\d.]+)\"\s+([NSEW])",
    re.IGNORECASE | re.DOTALL,
)


def _ensure_tesseract() -> bool:
    """Return whether optional Tesseract is already available.

    Forensic analysis must never install packages or invoke sudo during a run.
    Missing OCR support is reported as a capability caveat instead.
    """
    import shutil
    return bool(shutil.which("tesseract"))


_TESSERACT_AVAILABLE = _ensure_tesseract()


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception:
            pass

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    images_dir = output_dir / "extracted_images"
    images_dir.mkdir(exist_ok=True)

    findings: list[Finding] = []
    errors: list[str] = []
    warnings: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        return _fail(MODULE_NAME, case_id, start_time,
                     f"Evidence not found: {evidence_path}", coc_logger, logger)

    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    tlog(f"[IMGCONT] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")
    tlog(f"[IMGCONT] tesseract: {_TESSERACT_AVAILABLE}")

    # ── fls enumeration ──────────────────────────────────────────────────────
    tlog("[IMGCONT] Running fls to locate image files...")
    fls_entries = _run_fls(analysis_path, logger, errors, offset=partition_offset)
    tlog(f"[IMGCONT] fls: {len(fls_entries)} total entries")

    image_entries = [
        e for e in fls_entries
        if Path(e["path"]).suffix.lower() in _IMAGE_EXTS
    ]
    tlog(f"[IMGCONT] Image-extension candidates found: {len(image_entries)}")

    # ── Working-set corpus scan ───────────────────────────────────────────────
    ws = config.get("_working_set", {})
    # Shared corpus resolved by the orchestrator from what the recovery and
    # carving modules actually produced this run (falls back to the legacy
    # working-set keys when this module runs standalone).
    _corpus_roots: list[Path] = resolve_corpus_roots(ws, output_dir=output_dir)

    _seen_resolved: set[str] = set()
    corpus_image_files: list[Path] = []
    corpus_by_name: dict[str, list[Path]] = {}
    for _f in iter_corpus_files(ws, output_dir=output_dir, deduplicate_by_hash=False):
        if _f.suffix.lower() not in _IMAGE_EXTS:
            continue
        try:
            _resolved = str(_f.resolve())
        except OSError:
            _resolved = str(_f)
        if _resolved in _seen_resolved:
            continue
        _seen_resolved.add(_resolved)
        corpus_image_files.append(_f)
        corpus_by_name.setdefault(_f.name, []).append(_f)

    # If TSK enumeration is unavailable but the native read-only extraction tree
    # contains the evidence files, that tree is an equivalent primary corpus.
    if not fls_entries and corpus_image_files and errors:
        warnings.extend(errors)
        errors.clear()
        warnings.append("TSK image enumeration unavailable; native evidence corpus used.")

    tlog(f"[IMGCONT] Corpus image files (working-set): {len(corpus_image_files)}")

    # ── Extract and analyze images ────────────────────────────────────────────
    embedded_images: list[dict] = []
    flagged_images:  list[dict] = []
    images_with_gps: list[dict] = []
    duplicate_aliases: list[dict[str, str]] = []
    seen_content_hashes: set[str] = set()
    canonical_image_by_digest: dict[str, str] = {}
    canonical_image_by_pixel: dict[str, str] = {}
    visual_duplicates: list[dict[str, str]] = []
    invalid_candidates_skipped: list[str] = []
    total_ocr_hits = 0

    max_images = int(config.get("image_analysis_max", MAX_IMAGES_TO_ANALYZE) or 0)
    max_image_bytes = int(config.get("image_analysis_max_bytes", MAX_IMAGE_BYTES) or 0)
    sample = image_entries[:max_images] if max_images > 0 else image_entries
    used_corpus_paths: set[str] = set()
    failed_images: list[str] = []
    if max_images > 0 and len(image_entries) > max_images:
        errors.append(
            f"Image analysis safety ceiling reached: {len(image_entries)} TSK image entries; "
            f"only {max_images} were examined. Increase image_analysis_max for full coverage."
        )
    tlog(f"[IMGCONT] Candidate validation scheduled for {len(sample)} TSK-listed image path(s) (limit {'unlimited' if max_images <= 0 else max_images})")

    for i, entry in enumerate(sample, 1):
        path_obj = Path(entry["path"])
        safe_name = re.sub(r"[^A-Za-z0-9_.\-]", "_", path_obj.name)
        dest = images_dir / safe_name
        native_candidates = corpus_by_name.get(path_obj.name, [])
        if native_candidates:
            # Prefer the already reconstructed read-only evidence copy.
            dest = native_candidates[0]
            used_corpus_paths.add(str(dest.resolve()))
        elif not dest.exists():
            dest_result, err = _icat_extract(analysis_path,
                                              entry["inode"], dest, logger,
                                              offset=partition_offset)
            if err:
                errors.append(f"icat extraction failed for {entry['path']}: {err}")
                failed_images.append(entry["path"])
                continue
            dest = dest_result

        tlog(f"[IMGCONT] [{i}/{len(sample)}] Candidate validation: {path_obj.name}")
        img_info = _analyse_one_image(dest, entry["path"], logger, max_image_bytes=max_image_bytes)
        if img_info is None:
            warnings.append(f"Excluded corrupt, oversized, or non-image candidate: {entry['path']}")
            invalid_candidates_skipped.append(entry["path"])
            continue
        digest = str(img_info.get("sha256") or "")
        pixel_digest = str(img_info.get("pixel_sha256") or "")
        if digest and digest in canonical_image_by_digest:
            duplicate_aliases.append({"path": entry["path"], "sha256": digest, "pixel_sha256": pixel_digest, "canonical_path": canonical_image_by_digest[digest], "relationship": "byte-identical recovery/source alias"})
            continue
        if digest:
            seen_content_hashes.add(digest); canonical_image_by_digest[digest] = entry["path"]
        if pixel_digest and pixel_digest in canonical_image_by_pixel:
            visual_duplicates.append({"path": entry["path"], "sha256": digest, "pixel_sha256": pixel_digest, "canonical_path": canonical_image_by_pixel[pixel_digest], "relationship": "same decoded pixels; distinct file byte stream"})
        elif pixel_digest:
            canonical_image_by_pixel[pixel_digest] = entry["path"]

        if img_info.get("gps"):
            images_with_gps.append(img_info)
        if img_info.get("doc_type"):
            total_ocr_hits += 1
            flagged_images.append(img_info)
            tlog(f"[IMGCONT] FLAGGED {path_obj.name}: {img_info['doc_type']}")

        embedded_images.append({k: v for k, v in img_info.items() if k != "_b64_preview"})

        if img_info.get("structure_validated"):
            findings.append(make_finding(
                "IMAGE_FILE_STRUCTURALLY_PARSED", Severity.INFO,
                f"Image '{entry['path']}' decoded completely as "
                f"{img_info.get('detected_format') or 'an image'} with dimensions "
                f"{img_info.get('width')}x{img_info.get('height')} and mode "
                f"{img_info.get('mode') or 'unspecified'}. The SHA-256 is "
                f"{img_info.get('sha256')}. This establishes file structure and "
                "pixel decodability only; it does not classify depicted content or intent.",
                str(dest),
                {
                    "logical_path": entry["path"],
                    "source_path": str(dest),
                    "sha256": img_info.get("sha256"),
                    "detected_format": img_info.get("detected_format"),
                    "mime": img_info.get("mime"),
                    "width": img_info.get("width"),
                    "height": img_info.get("height"),
                    "mode": img_info.get("mode"),
                    "validation_method": "complete_image_decode",
                    "finding_basis": "deterministic",
                    "deterministic_validation": True,
                    "validators": ["Pillow complete image decode", "SHA-256"],
                    "semantic_limit": "structure and pixels only; no scene, identity, document, or intent inference",
                },
            ))

        if img_info["doc_type"]:
            findings.append(make_finding(
                "DOCUMENT_IMAGE_DETECTED", Severity.HIGH,
                f"Image '{entry['path']}' classified as: {img_info['doc_type']}. "
                f"OCR extracted text contains patterns matching official documents. "
                f"OCR preview: {img_info['ocr_text'][:200]}",
                entry["path"],
                {"doc_type": img_info["doc_type"],
                 "file_size": img_info["size"],
                 "ocr_preview": img_info["ocr_text"][:500],
                 "b64_preview": img_info.get("_b64_preview", ""),
                 **candidate_metadata(
                     "OCR text pattern classification",
                     reason="OCR and regex image classification require visual examiner confirmation",
                     threshold="pattern match in OCR transcription",
                 )},
            ))

    # ── Corpus (working-set) image analysis ──────────────────────────────────
    remaining_slots = None if max_images <= 0 else max(0, max_images - len(sample))
    corpus_remaining = [
        p for p in corpus_image_files if str(p.resolve()) not in used_corpus_paths
    ]
    corpus_sample = corpus_remaining if remaining_slots is None else corpus_remaining[:remaining_slots]
    if remaining_slots is not None and len(corpus_remaining) > remaining_slots:
        errors.append(
            f"Image analysis safety ceiling reached: {len(corpus_remaining) - remaining_slots} "
            "additional corpus image(s) were not examined."
        )
    tlog(f"[IMGCONT] Additional corpus images scheduled: {len(corpus_sample)}")

    for i, corpus_path in enumerate(corpus_sample, 1):
        tlog(f"[IMGCONT] [corpus {i}/{len(corpus_sample)}] Candidate validation: {corpus_path.name}")
        img_info_c = _analyse_one_image(corpus_path, str(corpus_path), logger, max_image_bytes=max_image_bytes)
        if img_info_c is None:
            warnings.append(f"Excluded corrupt, oversized, or non-image candidate: {corpus_path}")
            invalid_candidates_skipped.append(str(corpus_path))
            continue

        digest = str(img_info_c.get("sha256") or "")
        pixel_digest = str(img_info_c.get("pixel_sha256") or "")
        if digest and digest in canonical_image_by_digest:
            duplicate_aliases.append({"path": str(corpus_path), "sha256": digest, "pixel_sha256": pixel_digest, "canonical_path": canonical_image_by_digest[digest], "relationship": "byte-identical recovery/source alias"})
            continue
        if digest:
            seen_content_hashes.add(digest); canonical_image_by_digest[digest] = str(corpus_path)
        if pixel_digest and pixel_digest in canonical_image_by_pixel:
            visual_duplicates.append({"path": str(corpus_path), "sha256": digest, "pixel_sha256": pixel_digest, "canonical_path": canonical_image_by_pixel[pixel_digest], "relationship": "same decoded pixels; distinct file byte stream"})
        elif pixel_digest:
            canonical_image_by_pixel[pixel_digest] = str(corpus_path)
        img_info_c["source"] = "corpus"

        if img_info_c.get("gps"):
            images_with_gps.append(img_info_c)
        if img_info_c.get("doc_type"):
            total_ocr_hits += 1
            flagged_images.append(img_info_c)
            tlog(f"[IMGCONT] FLAGGED (corpus) {corpus_path.name}: {img_info_c['doc_type']}")

        embedded_images.append({k: v for k, v in img_info_c.items() if k != "_b64_preview"})

        if img_info_c.get("structure_validated"):
            findings.append(make_finding(
                "IMAGE_FILE_STRUCTURALLY_PARSED", Severity.INFO,
                f"Image '{corpus_path}' decoded completely as "
                f"{img_info_c.get('detected_format') or 'an image'} with dimensions "
                f"{img_info_c.get('width')}x{img_info_c.get('height')} and mode "
                f"{img_info_c.get('mode') or 'unspecified'}. The SHA-256 is "
                f"{img_info_c.get('sha256')}. This establishes file structure and "
                "pixel decodability only; it does not classify depicted content or intent.",
                str(corpus_path),
                {
                    "logical_path": str(corpus_path),
                    "source_path": str(corpus_path),
                    "sha256": img_info_c.get("sha256"),
                    "detected_format": img_info_c.get("detected_format"),
                    "mime": img_info_c.get("mime"),
                    "width": img_info_c.get("width"),
                    "height": img_info_c.get("height"),
                    "mode": img_info_c.get("mode"),
                    "validation_method": "complete_image_decode",
                    "finding_basis": "deterministic",
                    "deterministic_validation": True,
                    "validators": ["Pillow complete image decode", "SHA-256"],
                    "semantic_limit": "structure and pixels only; no scene, identity, document, or intent inference",
                },
            ))

        if img_info_c["doc_type"]:
            findings.append(make_finding(
                "DOCUMENT_IMAGE_DETECTED", Severity.HIGH,
                f"Image '{corpus_path}' classified as: {img_info_c['doc_type']}. "
                f"OCR extracted text contains patterns matching official documents. "
                f"OCR preview: {img_info_c['ocr_text'][:200]}",
                str(corpus_path),
                {"doc_type": img_info_c["doc_type"],
                 "file_size": img_info_c["size"],
                 "ocr_preview": img_info_c["ocr_text"][:500],
                 "b64_preview": img_info_c.get("_b64_preview", ""),
                 "candidate_only": True,
                 "fact_class": "CANDIDATE_ONLY",
                 **candidate_metadata(
                     "OCR text pattern classification",
                     reason="OCR and regex image classification require visual examiner confirmation",
                     threshold="pattern match in OCR transcription",
                 )},
            ))

    # ── GPS findings ──────────────────────────────────────────────────────────
    if images_with_gps:
        gps_list = [{"path": img["path"], "gps": img["gps"],
                     "exif": img["exif"]} for img in images_with_gps]
        findings.append(make_finding(
            "GPS_COORDINATES_IN_IMAGES", Severity.INFO,
            f"{len(images_with_gps)} image(s) contain deterministically parsed metadata coordinate fields. "
            f"Coordinates. Values: " + "; ".join(
                f"{img['gps']}" for img in images_with_gps[:3]) + ". "
            "Embedded coordinates are metadata assertions; they do not independently "
            "prove where, when, by whom, or on what device an image was created.",
            str(evidence_path),
            {"images_with_gps": gps_list[:20],
             "metadata_namespace": "SOURCE_RETAINED_BY_PARSER",
             "interpretation_caveat": "metadata assertion; requires independent corroboration",
             **deterministic_metadata("metadata coordinate field parsing", validators=["exiftool/Pillow namespace-preserving parser"])},
        ))
        tlog(f"[IMGCONT] GPS found in {len(images_with_gps)} image(s)")

    # ── Summary finding ───────────────────────────────────────────────────────
    if embedded_images:
        findings.append(make_finding(
            "IMAGE_ANALYSIS_COMPLETE", Severity.INFO,
            f"Image content analysis: {len(image_entries)} extension candidates listed by TSK and "
            f"{len(corpus_image_files)} evidentiary paths discovered in the native evidence tree; "
            f"{len(embedded_images)} analyzed, {len(flagged_images)} flagged "
            f"(ID/passport/credit card), {len(images_with_gps)} with GPS. "
            f"OCR performed on {len([i for i in embedded_images if i.get('ocr_text')])} images.",
            str(evidence_path),
            {"total_images": len(image_entries),
             "analyzed": len(embedded_images),
             "flagged": len(flagged_images),
             "gps_count": len(images_with_gps),
             "fact_class": "DERIVED_FACT",
             "counts_toward_unique_evidence": False,
             "deterministic_validation": True},
        ))

    # ── Write manifest ───────────────────────────────────────────────────────
    manifest = {
        "module":                 MODULE_NAME,
        "case_id":                case_id,
        "generated_at":           utc_now(),
        "extension_candidates":   len(image_entries),
        "total_images":           len(image_entries),
        "corpus_images_scanned":  len(corpus_image_files),
        "analyzed":               len(embedded_images),
        "flagged":                len(flagged_images),
        "gps_images":             len(images_with_gps),
        "image_data":             embedded_images,
        "flagged_details": [
            {"path": img["path"], "doc_type": img["doc_type"],
             "ocr_preview": img.get("ocr_text","")[:300]}
            for img in flagged_images
        ],
        "gps_data":        [{"path": img["path"], "gps": img["gps"]}
                             for img in images_with_gps],
        "findings":        len(findings),
        "failed_images":   failed_images,
        "invalid_candidates_skipped": invalid_candidates_skipped,
        "duplicate_aliases": duplicate_aliases,
        "visual_content_relationships": visual_duplicates,
        "candidate_source_paths": len(sample) + len(corpus_sample),
        "successful_decodes": len(embedded_images) + len(duplicate_aliases),
        "valid_image_objects": len(embedded_images),
        "invalid_candidate_paths": len(invalid_candidates_skipped),
        "failed_candidate_paths": len(failed_images),
        "source_paths": len(sample) + len(corpus_sample),
        "unique_valid_image_streams": len(canonical_image_by_digest),
        "unique_byte_streams": len(canonical_image_by_digest),
        "unique_pixel_identities": len(canonical_image_by_pixel),
        "logical_image_objects": len(embedded_images),
        "recovery_aliases": len(duplicate_aliases),
        "warnings":        warnings,
        "errors":          errors,
    }
    manifest_path = output_dir / "image_content_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    for finding in findings:
        if not finding.artifact_path:
            candidate = ""
            if finding.finding_type == "GPS_COORDINATES_IN_IMAGES" and images_with_gps:
                candidate = str(images_with_gps[0].get("path") or "")
            finding.artifact_path = candidate if candidate and Path(candidate).is_file() else str(manifest_path)
        finding.metadata.setdefault("report_file", str(manifest_path))
    (output_dir / "terminal_output.txt").write_text("\n".join(terminal_lines), encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[IMGCONT] Completed in {wall_elapsed:.1f}s — {len(findings)} findings")

    status = (
        ModuleStatus.COMPLETED if not errors and not failed_images
        else ModuleStatus.PARTIAL if embedded_images
        else ModuleStatus.FAILED
    )

    summary = (
        f"Image analysis: {len(image_entries)} extension candidates listed by TSK, "
        f"{len(corpus_image_files)} evidentiary paths discovered in the native evidence tree, "
        f"{len(embedded_images)} analyzed, {len(flagged_images)} flagged, "
        f"{len(images_with_gps)} with GPS. {len(findings)} findings."
    )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED
                else EventType.MODULE_FAILED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value},
            )
        except Exception:
            pass

    adjudicated_candidates = (
        len(embedded_images) + len(duplicate_aliases) + len(invalid_candidates_skipped)
    )
    complete_scope = (
        not errors and not failed_images
        and adjudicated_candidates == len(sample) + len(corpus_sample)
    )
    cr = ClassResult(
        locus=Locus.IMAGES,
        artefact_class="Image Content Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT if complete_scope
            else AssuranceVerdict.INDETERMINATE
        ),
        skip_reason=(None if findings or complete_scope else SkipReason.PARTIAL_FAILURE),
        count=len(findings),
        notes="; ".join((errors or warnings)[:3]),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings, artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={"sources_discovered": len(sample) + len(corpus_sample),
                     "sources_processed": adjudicated_candidates,
                     "supported_objects_discovered": len(sample) + len(corpus_sample),
                     "supported_objects_processed": adjudicated_candidates,
                     "records_discovered": len(sample) + len(corpus_sample),
                     "records_processed": adjudicated_candidates,
                     "unresolved_supported_objects": max(0, (len(sample) + len(corpus_sample)) - adjudicated_candidates) + len(failed_images),
                     "parser_errors": len(failed_images) + len(errors),
                     "total_images": len(image_entries),
                     "analyzed": len(embedded_images),
                     "flagged": len(flagged_images),
                     "gps_images": len(images_with_gps),
                     "corpus_images_scanned": len(corpus_image_files),
                     "failed_images": len(failed_images),
                     "invalid_candidates_skipped": len(invalid_candidates_skipped),
                     "duplicate_image_aliases": len(duplicate_aliases),
                     "visual_content_relationships": len(visual_duplicates),
                     "candidate_source_paths": len(sample) + len(corpus_sample),
                     "successful_decodes": len(embedded_images) + len(duplicate_aliases),
                     "valid_image_objects": len(embedded_images),
                     "source_paths": len(sample) + len(corpus_sample),
                     "unique_byte_streams": len(canonical_image_by_digest),
                     "unique_decoded_pixel_contents": len(canonical_image_by_pixel),
                     "unique_pixel_identities": len(canonical_image_by_pixel),
                     "logical_image_objects": len(embedded_images),
                     "recovery_aliases": len(duplicate_aliases),
                     "coverage_complete": complete_scope,
                     "warnings": warnings,
                     "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if complete_scope else "ran_with_caveat")},
        summary=summary,
        class_results=[cr],
    )


# ---------------------------------------------------------------------------
# Per-image analysis helper
# ---------------------------------------------------------------------------

def _analyse_one_image(
    path: Path,
    label: str,
    logger: logging.Logger,
    *,
    max_image_bytes: int = 0,
) -> Optional[dict]:
    """Analyse a single image file and return an img_info dict, or None to skip.

    Args:
        path:   Absolute path to the image file on disk.
        label:  Logical path recorded in img_info["path"] and findings.
        logger: Module logger.

    Returns:
        img_info dict (without "b64" key; b64 preview stored as "_b64_preview"),
        or None if the file is too big, too small, or unreadable.
    """
    try:
        file_size = path.stat().st_size
    except OSError:
        return None

    if (max_image_bytes > 0 and file_size > max_image_bytes) or file_size < 100:
        return None

    try:
        # A valid extension/header is insufficient: force full pixel decoding so
        # truncated carving candidates are excluded rather than counted as failed
        # source images.
        width = height = 0
        mode = ""
        detected_format = ""
        structure_validated = False
        pixel_sha256 = ""
        try:
            from PIL import Image
            with Image.open(path) as image:
                width, height = image.size
                if width <= 0 or height <= 0 or width * height > 100_000_000:
                    return None
                # Force complete decoding.  A filename extension or header alone
                # is not sufficient for a canonical image finding.
                image.load()
                mode = str(image.mode or "")
                detected_format = str(image.format or "").upper()
                structure_validated = bool(detected_format)
                canonical_pixels = image.convert("RGBA").tobytes()
                pixel_sha256 = hashlib.sha256(
                    f"{width}x{height}|RGBA|".encode("ascii") + canonical_pixels
                ).hexdigest()
        except ImportError:
            # Without a structural decoder the file can still be retained in the
            # manifest, but it cannot support a canonical image-content finding.
            structure_validated = False
        except Exception:
            return None
        raw_bytes = path.read_bytes()
        digest = hashlib.sha256(raw_bytes).hexdigest()
        b64 = base64.b64encode(raw_bytes).decode("ascii")
        img_ext = path.suffix.lower().lstrip(".")
        mime = {
            "JPG": "image/jpeg", "JPEG": "image/jpeg", "PNG": "image/png",
            "GIF": "image/gif", "BMP": "image/bmp", "TIFF": "image/tiff",
            "WEBP": "image/webp", "ICO": "image/x-icon",
        }.get(detected_format, {
            "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
            "gif": "image/gif", "bmp": "image/bmp", "tiff": "image/tiff",
        }.get(img_ext, "application/octet-stream"))
    except OSError:
        return None

    img_info: dict = {
        "path":         label,
        "local":        str(path),
        "size":         file_size,
        "sha256":       digest,
        "pixel_sha256": pixel_sha256,
        "mime":         mime,
        "ext":          img_ext,
        "detected_format": detected_format,
        "width":        width,
        "height":       height,
        "mode":         mode,
        "structure_validated": structure_validated,
        "ocr_text":     "",
        "doc_type":     None,
        "gps":          None,
        "exif":         {},
        "_b64_preview": b64[:100],
    }

    # EXIF via exiftool
    exif = _extract_exif(path, logger)
    img_info["exif"] = exif
    gps = exif.get("gps")
    if gps:
        img_info["gps"] = gps

    # OCR
    if _TESSERACT_AVAILABLE and file_size < 2_000_000:
        ocr_text = _run_ocr(path, logger)
        img_info["ocr_text"] = ocr_text
        if ocr_text:
            doc_type = _classify_document_image(ocr_text)
            if doc_type:
                img_info["doc_type"] = doc_type

    return img_info


# ---------------------------------------------------------------------------
# OCR
# ---------------------------------------------------------------------------

def _run_ocr(image_path: Path, logger: logging.Logger) -> str:
    try:
        cmd = ["tesseract", str(image_path), "stdout", "--psm", "3"]
        rc, stdout, stderr = _run_subprocess(cmd, OCR_TIMEOUT, logger)
        return stdout.strip()
    except Exception as exc:
        logger.debug("OCR error for %s: %s", image_path.name, exc)
        return ""


def _classify_document_image(ocr_text: str) -> Optional[str]:
    for pattern, doc_type in _ID_PATTERNS:
        if pattern.search(ocr_text):
            return doc_type
    return None


# ---------------------------------------------------------------------------
# EXIF extraction
# ---------------------------------------------------------------------------

def _extract_exif(image_path: Path, logger: logging.Logger) -> dict:
    import shutil
    if not shutil.which("exiftool"):
        pillow_result = _parse_exif_with_pillow(image_path, logger)
        if pillow_result:
            return pillow_result
        return _parse_jpeg_exif_raw(image_path, logger)
    try:
        cmd = ["exiftool", "-json", "-G1", "-GPS*", "-XMP:GPS*", "-EXIF:GPS*", "-Make", "-Model",
               "-CreateDate", "-ModifyDate", str(image_path)]
        rc, stdout, stderr = _run_subprocess(cmd, 30, logger)
        if rc == 0 and stdout.strip():
            import json as _json
            data_list = _json.loads(stdout)
            data = data_list[0] if data_list else {}
            result = {}
            gps_groups: dict[str, dict[str, str]] = {}
            for k, v in data.items():
                key = str(k)
                result[key] = str(v)
                if ":" in key:
                    group, field = key.split(":", 1)
                    result.setdefault(field, str(v))
                    if field.startswith("GPS"):
                        gps_groups.setdefault(group, {})[field] = str(v)
            # Select one complete coordinate pair and preserve its actual namespace.
            for group, values in gps_groups.items():
                if values.get("GPSLatitude") and values.get("GPSLongitude"):
                    result["gps"] = f"{values['GPSLatitude']} {values.get('GPSLatitudeRef','')}, {values['GPSLongitude']} {values.get('GPSLongitudeRef','')}"
                    result["gps_namespace"] = "XMP" if group.casefold().startswith("xmp") else "EXIF" if group.casefold().startswith("exif") else group
                    break
            return result
    except Exception as exc:
        logger.debug("exiftool error: %s", exc)
    return _parse_jpeg_exif_raw(image_path, logger)



def _parse_exif_with_pillow(path: Path, logger: logging.Logger) -> dict:
    """Read common EXIF and GPS fields without an external executable."""
    try:
        from PIL import Image, ExifTags
        with Image.open(path) as image:
            exif = image.getexif()
            if not exif:
                return {}
            result: dict = {}
            for tag_id, value in exif.items():
                name = ExifTags.TAGS.get(tag_id, str(tag_id))
                if name in {"Make", "Model", "DateTime", "DateTimeOriginal", "DateTimeDigitized"}:
                    result[name] = str(value)
            try:
                gps_ifd = exif.get_ifd(34853)  # GPSInfo
            except Exception:
                gps_ifd = exif.get(34853) or {}
            if gps_ifd:
                gps = {ExifTags.GPSTAGS.get(k, str(k)): v for k, v in dict(gps_ifd).items()}
                def _ratio(value):
                    try:
                        return float(value)
                    except Exception:
                        try:
                            return float(value.numerator) / float(value.denominator)
                        except Exception:
                            return 0.0
                def _dms(values):
                    vals = list(values or [])
                    if len(vals) != 3:
                        return None
                    return _ratio(vals[0]) + _ratio(vals[1]) / 60.0 + _ratio(vals[2]) / 3600.0
                lat = _dms(gps.get("GPSLatitude"))
                lon = _dms(gps.get("GPSLongitude"))
                if lat is not None and lon is not None:
                    if str(gps.get("GPSLatitudeRef", "N")).upper().startswith("S"):
                        lat = -lat
                    if str(gps.get("GPSLongitudeRef", "E")).upper().startswith("W"):
                        lon = -lon
                    result["gps"] = f"{lat:.8f}, {lon:.8f}"
                    result["GPSLatitude"] = f"{lat:.8f}"
                    result["GPSLongitude"] = f"{lon:.8f}"
                    result["gps_namespace"] = "EXIF"
            return result
    except Exception as exc:
        logger.debug("Pillow EXIF parse failed for %s: %s", path.name, exc)
        return {}

def _parse_jpeg_exif_raw(path: Path, logger: logging.Logger) -> dict:
    """Minimal JPEG EXIF parser for GPS coordinates without exiftool."""
    result: dict = {}
    try:
        data = path.read_bytes()
        if data[:2] != b"\xff\xd8":  # JPEG SOI
            return result
        # Look for EXIF APP1 marker
        i = 2
        while i < len(data) - 4:
            if data[i] == 0xff:
                marker = data[i+1]
                seg_len = struct.unpack_from(">H", data, i+2)[0]
                seg_data = data[i+4 : i+2+seg_len]
                if marker == 0xe1 and seg_data[:4] == b"Exif":
                    # Parse EXIF for GPS IFD
                    gps_text = _extract_gps_from_exif(seg_data[6:])
                    if gps_text:
                        result["gps"] = gps_text
                    break
                i += 2 + seg_len
            else:
                i += 1
    except Exception:
        pass
    return result


def _extract_gps_from_exif(exif_data: bytes) -> Optional[str]:
    """Extremely minimal GPS extraction from EXIF binary."""
    try:
        if exif_data[:2] in (b"II", b"MM"):
            byte_order = "<" if exif_data[:2] == b"II" else ">"
            gps_tag_offset = exif_data.find(b"\x25\x88")  # GPS IFD tag
            if gps_tag_offset > 0:
                return "GPS data present (use exiftool for coordinates)"
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# fls / icat helpers
# ---------------------------------------------------------------------------

def _run_fls(analysis_path: Path,
             logger: logging.Logger, errors: list,
             offset: int = 0) -> list[dict]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found")
        return []
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return []
    entries = []
    for line in stdout.splitlines():
        m = re.match(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", line.strip())
        if m and not m.group(2).endswith("/"):
            entries.append({"inode": m.group(1).split("-")[0], "path": m.group(2).strip()})
    return entries


def _icat_extract(analysis_path: Path, inode: str,
                  dest: Path, logger: logging.Logger,
                  offset: int = 0) -> tuple[Path, str | None]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, ICAT_TIMEOUT, logger)
    except FileNotFoundError:
        return dest, "icat not found"
    except Exception as exc:
        return dest, str(exc)
    if rc != 0:
        return dest, f"icat exit {rc}: {stderr[:200]}"
    try:
        dest.write_bytes(stdout.encode("utf-8", errors="replace"))
        return dest, None
    except OSError as exc:
        return dest, str(exc)


def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    logger.error("Module %s failed: %s", module_name, reason)
    cr = ClassResult(
        locus=Locus.IMAGES,
        artefact_class="Image Content Artefacts",
        verdict=AssuranceVerdict.INDETERMINATE,
        skip_reason=SkipReason.NO_EVIDENCE,
        notes=reason,
    )
    return ModuleResult(
        module_name=module_name, case_id=case_id, status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(), duration_seconds=0.0,
        findings=[], artifact_paths=[], errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
        class_results=[cr],
    )
