"""
network_protocol_decoder.py — Network Protocol Decoder for AutoForensics.

Uses ``tshark`` to decode and extract structured artifacts from specific application
protocols found in PCAP files:

  SMB/SMB2   — file access via admin shares (C$, IPC$, ADMIN$)
  FTP        — cleartext credentials and transferred files
  SMTP       — email content and encoded attachments
  SSH        — version banners
  TLS/SNI    — hostnames from TLS ClientHello extensions
  ICMP       — tunneling detection (oversized payloads)
  ARP        — poisoning detection (multiple MACs for same IP)

Target platform : Kali Linux, Python 3.11+
External tools  : tshark (wireshark-common package)
"""

from __future__ import annotations

import json
import logging
import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.native_network import decode_packets, public_record

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "network_protocol_decoder"
TSHARK_TIMEOUT: int = 3600

_SMB_ADMIN_SHARES: frozenset[str] = frozenset({"c$", "admin$", "ipc$", "d$", "e$"})
_ICMP_TUNNEL_THRESHOLD: int = 64   # bytes — ICMP payload larger than this is suspicious


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _find_pcap_files(output_dir: Path, config: dict[str, Any]) -> list[Path]:
    files: list[Path] = []
    for pat in ("*.pcap", "*.pcapng", "*.cap"):
        files.extend(output_dir.rglob(pat))
    explicit = config.get("pcap_path", "")
    if explicit:
        p = Path(explicit)
        if p.is_file() and p not in files:
            files.append(p)
    for value in config.get("pcap_paths") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    ws = config.get("_working_set") or {}
    for value in ws.get("nested_network_sources") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    # Canonicalise and de-duplicate without assuming filenames.
    unique: list[Path] = []
    seen: set[str] = set()
    for p in files:
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _tshark_extract(
    pcap: Path,
    display_filter: str,
    fields: list[str],
    logger: logging.Logger,
) -> list[dict[str, str]]:
    """
    Run tshark with a display filter and extract specified fields.

    Parameters
    ----------
    pcap           : PCAP file path.
    display_filter : Wireshark display filter.
    fields         : Field names to extract.
    logger         : Module logger.

    Returns
    -------
    List of dicts, one per matching packet.
    """
    cmd = ["tshark", "-r", str(pcap), "-Y", display_filter,
           "-T", "fields", "-E", "header=y", "-E", "separator=|"]
    for f in fields:
        cmd += ["-e", f]
    try:
        rc, stdout, _ = _run_subprocess(cmd, timeout=TSHARK_TIMEOUT, logger=logger)
        if not stdout.strip():
            return []
        lines = stdout.splitlines()
        if len(lines) < 2:
            return []
        headers = [h.strip() for h in lines[0].split("|")]
        rows: list[dict[str, str]] = []
        for line in lines[1:]:
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < len(headers):
                parts.extend([""] * (len(headers) - len(parts)))
            rows.append(dict(zip(headers, parts)))
        return rows
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Decode application-layer protocols from PCAP files.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing PCAP files.
    config        : Configuration dict; recognised key: ``pcap_path``.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with protocol-specific findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    pcap_files = _find_pcap_files(output_dir, config)
    if not pcap_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.NETWORK,
            artefact_class="Network Protocol Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
            notes="No PCAP files found in output directory.",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no PCAP files found.",
            class_results=[cr],
        )

    stats: dict[str, int] = {
        "decoded_frames": 0, "smb_sessions": 0, "ftp_commands": 0, "smtp_sessions": 0,
        "tls_connections": 0, "unique_sni_hosts": 0,
    }
    all_sni_hosts: set[str] = set()
    protocol_data: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for pcap in pcap_files:
        logger.info("[%s] Decoding protocols in: %s", MODULE_NAME, pcap.name)

        # Baseline deterministic dissection. This records ordinary Ethernet/IP/
        # UDP/TCP frames even when no higher-level suspicious protocol exists.
        native_rows = [public_record(row) for row in decode_packets(pcap)]
        if native_rows:
            baseline_rows = native_rows
            baseline_validator = "native PCAP/PCAPNG Ethernet/IPv4/UDP/TCP parser with capture byte offsets"
        else:
            baseline_rows = _tshark_extract(
                pcap, "frame",
                ["frame.number", "frame.time_epoch", "eth.src", "eth.dst",
                 "ip.src", "ip.dst", "ip.proto", "udp.srcport", "udp.dstport",
                 "tcp.srcport", "tcp.dstport", "tcp.flags", "_ws.col.Protocol"],
                logger,
            )
            baseline_validator = "tshark Ethernet/IP/UDP/TCP dissectors"
        # Attach deterministic semantic event labels derived only from decoded
        # protocol fields. These labels feed the consolidated timeline and are
        # not threat or intent classifications.
        for row in baseline_rows:
            protocols = {str(x).upper() for x in (row.get("protocols") or [])}
            label = "NETWORK FRAME"
            flags = row.get("tcp_flags")
            try:
                flags_i = int(flags) if flags is not None else -1
            except (TypeError, ValueError):
                flags_i = -1
            if "DNS" in protocols:
                label = "DNS response" if int(row.get("src_port") or 0) == 53 else "DNS request"
            elif flags_i == 0x02:
                label = "TCP SYN"
            elif flags_i == 0x12:
                label = "TCP SYN-ACK"
            elif flags_i == 0x10:
                label = "TCP ACK"
            elif "HTTP" in protocols:
                label = "HTTP packet"
            row["semantic_event"] = label
            row["event"] = label
        stats["decoded_frames"] += len(baseline_rows)
        protocol_data["baseline"].extend(baseline_rows)
        if baseline_rows:
            findings.append(make_finding(
                finding_type="NETWORK_PROTOCOL_RECORD", severity=Severity.INFO,
                description=f"Decoded {len(baseline_rows)} packet frame(s) with retained protocol fields from {pcap.name}.",
                evidence_path=str(pcap), artifact_path=str(pcap),
                metadata={**deterministic_metadata(
                    "protocol fields decoded from retained packet bytes",
                    validators=[baseline_validator],
                ), "pcap_file": str(pcap), "records": baseline_rows,
                   "semantic_scope": "decoded packet facts only; no maliciousness inferred"},
            ))

        # SMB
        smb_rows = _tshark_extract(pcap, "smb or smb2",
                                   ["frame.time", "ip.src", "ip.dst",
                                    "smb.cmd", "smb2.cmd", "smb.file", "smb2.filename"],
                                   logger)
        stats["smb_sessions"] += len(smb_rows)
        protocol_data["smb"].extend(smb_rows)
        for row in smb_rows:
            fname = (row.get("smb.file") or row.get("smb2.filename") or "").lower()
            share = fname.split("\\")[0] if "\\" in fname else fname
            if share in _SMB_ADMIN_SHARES:
                exact = {**deterministic_metadata(
                    "SMB share path decoded by protocol dissector", validators=["tshark SMB/SMB2 dissector"],
                    semantic_limit="Use of an administrative share is recorded; abuse or lateral movement is not established."),
                    **row, "pcap_file": pcap.name, "share": share}
                findings.append(make_finding(
                    finding_type="SMB_SHARE_PATH_OBSERVED", severity=Severity.INFO,
                    description=f"SMB path '{fname}' uses share '{share}' from {row.get('ip.src', '?')} to {row.get('ip.dst', '?')}.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="SMB_ADMIN_SHARE_ABUSE_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"Administrative-share use for '{fname}' is retained for contextual review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "administrative-share lookup", reason="Administrative shares are also used for legitimate system administration.")}))

        # FTP
        ftp_rows = _tshark_extract(pcap, "ftp",
                                   ["frame.time", "ip.src", "ip.dst",
                                    "ftp.request.command", "ftp.request.arg",
                                    "ftp.response.code"],
                                   logger)
        stats["ftp_commands"] += len(ftp_rows)
        protocol_data["ftp"].extend(ftp_rows)
        for row in ftp_rows:
            cmd = row.get("ftp.request.command", "").upper()
            arg = row.get("ftp.request.arg", "")
            if cmd in ("USER", "PASS"):
                findings.append(make_finding(
                    finding_type="FTP_CLEARTEXT_CREDENTIALS",
                    severity=Severity.HIGH,
                    description=(
                        f"FTP {cmd} command in cleartext from {row.get('ip.src', '?')} "
                        f"in {pcap.name}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={**row, "pcap_file": pcap.name},
                ))

        # SMTP
        smtp_rows = _tshark_extract(pcap, "smtp",
                                    ["frame.time", "ip.src", "ip.dst",
                                     "smtp.req.command", "smtp.req.parameter"],
                                    logger)
        stats["smtp_sessions"] += len(smtp_rows)
        protocol_data["smtp"].extend(smtp_rows)

        # TLS SNI
        tls_rows = _tshark_extract(pcap, "tls.handshake.type == 1",
                                   ["frame.time", "ip.src", "ip.dst",
                                    "tls.handshake.extensions_server_name"],
                                   logger)
        stats["tls_connections"] += len(tls_rows)
        for row in tls_rows:
            sni = row.get("tls.handshake.extensions_server_name", "")
            if sni:
                all_sni_hosts.add(sni.lower())

        # ICMP tunneling
        icmp_rows = _tshark_extract(pcap, "icmp",
                                    ["frame.time", "ip.src", "ip.dst",
                                     "icmp.type", "icmp.code", "data.len"],
                                    logger)
        for row in icmp_rows:
            try:
                data_len = int(row.get("data.len") or 0)
            except ValueError:
                data_len = 0
            if data_len > _ICMP_TUNNEL_THRESHOLD:
                exact = {**deterministic_metadata(
                    "ICMP payload length decoded by protocol dissector", validators=["tshark ICMP dissector"],
                    semantic_limit="Payload length is established; tunnelling is not established by size alone."),
                    **row, "pcap_file": pcap.name, "payload_length_bytes": data_len}
                findings.append(make_finding(
                    finding_type="ICMP_PAYLOAD_LENGTH_OBSERVED", severity=Severity.INFO,
                    description=f"ICMP payload length {data_len} bytes was decoded from {row.get('ip.src', '?')} to {row.get('ip.dst', '?')}.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="ICMP_TUNNEL_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"The {data_len}-byte ICMP payload is retained for tunnelling review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "payload-size threshold", reason="Payload size alone cannot establish ICMP tunnelling.")}))

        # ARP poisoning
        arp_rows = _tshark_extract(pcap, "arp",
                                   ["frame.time", "arp.src.proto_ipv4",
                                    "arp.src.hw_mac", "arp.dst.proto_ipv4"],
                                   logger)
        ip_to_macs: dict[str, set[str]] = defaultdict(set)
        for row in arp_rows:
            ip = row.get("arp.src.proto_ipv4", "")
            mac = row.get("arp.src.hw_mac", "")
            if ip and mac:
                ip_to_macs[ip].add(mac.lower())
        for ip, macs in ip_to_macs.items():
            if len(macs) > 1:
                exact = {**deterministic_metadata(
                    "ARP IP-to-MAC multiplicity from decoded frames", validators=["tshark ARP dissector"],
                    semantic_limit="Multiple observed MAC addresses are established; poisoning is not established without temporal/topology validation."),
                    "ip": ip, "macs": sorted(macs), "pcap_file": pcap.name}
                findings.append(make_finding(
                    finding_type="ARP_IP_MAC_MULTIPLICITY_OBSERVED", severity=Severity.INFO,
                    description=f"IP {ip} was observed with {len(macs)} distinct MAC addresses.",
                    evidence_path=str(evidence_path), metadata=exact))
                findings.append(make_finding(
                    finding_type="ARP_POISONING_CANDIDATE", severity=Severity.MEDIUM,
                    description=f"The IP/MAC multiplicity for {ip} is retained for poisoning review.",
                    evidence_path=str(evidence_path), metadata={**exact, **candidate_metadata(
                        "multiple-MAC threshold", reason="DHCP, failover, mobility and capture duration can produce legitimate multiplicity.")}))

        exact_records = {
            "smb": smb_rows, "ftp": ftp_rows, "smtp": smtp_rows,
            "tls": tls_rows, "icmp": icmp_rows, "arp": arp_rows,
        }
        exact_count = sum(len(v) for v in exact_records.values())
        if exact_count:
            findings.append(make_finding(
                finding_type="NETWORK_PROTOCOL_RECORD", severity=Severity.INFO,
                description=f"Decoded {exact_count} application/network protocol record(s) from {pcap.name}.",
                evidence_path=str(pcap), artifact_path=str(pcap),
                metadata={**deterministic_metadata(
                    "protocol fields decoded from retained packet bytes",
                    validators=["tshark protocol dissectors"],
                ), "pcap_file": str(pcap), "records": {k: v for k, v in exact_records.items()}},
            ))

    stats["unique_sni_hosts"] = len(all_sni_hosts)

    # Write report
    report_path = output_dir / "protocol_analysis.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "sni_hosts": sorted(all_sni_hosts),
                "protocol_records": {
                    k: v for k, v in protocol_data.items()
                },
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write protocol_analysis.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"Decoded {len(pcap_files)} PCAP(s), {stats['decoded_frames']} frames: {stats['smb_sessions']} SMB, "
        f"{stats['ftp_commands']} FTP, {stats['tls_connections']} TLS connections; "
        f"{len(findings)} findings."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.NETWORK,
        artefact_class="Network Protocol Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
        class_results=[cr],
    )
