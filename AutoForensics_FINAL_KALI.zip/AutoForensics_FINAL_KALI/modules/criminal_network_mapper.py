"""Neutral, field-aware identifier correlation.

The historical module name is retained for compatibility.  The implementation
never infers criminality, ownership, identity or intent.  Canonical findings are
limited to exact co-occurrence within the same parsed record.  Global regex
correlation and social-handle guesses remain available only as candidate data.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, strict_emails, strict_ips, strict_urls
from core.structured_records import extract_structured_records, record_locator_metadata, value_role
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, resolve_corpus_roots, iter_corpus_files, make_finding, utc_now,
)

MODULE_NAME = "criminal_network_mapper"

_PHONE_RE = re.compile(r"(?<!\d)\+?[1-9]\d{7,14}(?!\d)")
_SCREEN_NAME_RE = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{2,32}(?![A-Za-z0-9_])")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _node(kind: str, value: str) -> str:
    return f"{kind}:{value.casefold() if kind in {'email','domain','url'} else value}"


def _extract_all_iocs(
    text: str, *, include_web_indicators: bool = False, include_screen_names: bool = False
) -> dict[str, set[str]]:
    """Legacy candidate extractor retained for API compatibility.

    This helper does not feed canonical findings. It returns strictly bounded
    syntax candidates, with URLs and labelled screen names opt-in only.
    """
    values = {
        "emails": set(strict_emails(text)),
        "ips": set(strict_ips(text)),
        "urls": set(strict_urls(text)) if include_web_indicators else set(),
        "phones": set(),
        "screen_names": set(),
    }
    for raw in re.findall(r"(?<!\w)\+?[1-9](?:[ .()/-]?\d){7,14}(?!\w)", text):
        digits = re.sub(r"\D", "", raw)
        if raw.strip().startswith("+") and 8 <= len(digits) <= 15:
            values["phones"].add("+" + digits)
        elif 10 <= len(digits) <= 15:
            values["phones"].add("+" + digits)
    if include_screen_names:
        labelled = re.compile(
            r"(?im)\b(?:screen[ _-]?name|username|handle)\s*[:=]?\s*([A-Za-z][A-Za-z0-9_.-]{1,31})\b"
        )
        values["screen_names"].update(match.group(1) for match in labelled.finditer(text))
    return values


def _record_identifiers(record) -> list[dict[str, str]]:
    identifiers: list[dict[str, str]] = []
    for field_name, raw in record.fields.items():
        value = str(raw)
        role = value_role(record, field_name)
        if role in {"email", "free_text"}:
            for item in strict_emails(value):
                identifiers.append({"kind": "email", "value": item, "field": field_name, "role": role})
        elif role == "message_identifier":
            # Message IDs are record locators, not participant identities.
            for item in strict_emails(value):
                identifiers.append({"kind": "message_id", "value": item, "field": field_name, "role": role})
        if role in {"ip", "free_text", "hostname"}:
            for item in strict_ips(value):
                identifiers.append({"kind": "ip", "value": item, "field": field_name, "role": role})
        if role in {"url", "free_text"}:
            for item in strict_urls(value):
                identifiers.append({"kind": "url", "value": item, "field": field_name, "role": role})
        if role == "phone":
            for match in _PHONE_RE.finditer(value):
                identifiers.append({"kind": "phone", "value": match.group(0), "field": field_name, "role": role})
        if role == "imei":
            digits = re.sub(r"\D", "", value)
            if len(digits) == 15:
                identifiers.append({"kind": "imei", "value": digits, "field": field_name, "role": role})
        if role == "hostname":
            for host in value.split():
                host = host.strip(".,;:()[]{}\"").casefold()
                if re.fullmatch(r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", host):
                    identifiers.append({"kind": "domain", "value": host, "field": field_name, "role": role})
    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for item in identifiers:
        key = (item["kind"], item["value"].casefold(), item["field"])
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict[str, Any],
        logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now()
    roots = resolve_corpus_roots(config.get("_working_set", {}), output_dir=output_dir)
    # Correlation is built only from original evidentiary content. It never
    # scans module output, carved copies, scanner feature files, configuration
    # or ground-truth/validation references.
    files = iter_corpus_files(
        config.get("_working_set", {}), output_dir=output_dir,
        include_case_context=False, include_derived=False,
        deduplicate_by_hash=False,
    )

    unique: list[Path] = []
    seen_hashes: set[str] = set()
    aliases: dict[str, list[str]] = defaultdict(list)
    for path in sorted(set(files), key=lambda p: p.as_posix()):
        try:
            digest = _sha256(path)
        except OSError:
            continue
        if digest in seen_hashes:
            aliases[digest].append(str(path))
            continue
        seen_hashes.add(digest)
        unique.append(path)

    findings = []
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[tuple[str, str], dict[str, Any]] = {}
    records_examined = 0
    candidate_handles: list[dict[str, Any]] = []

    for path in unique:
        records = extract_structured_records(path)
        if not records:
            # Preserve legacy social-handle search only as an unpromoted
            # candidate. It has no identity/ownership semantics.
            try:
                raw = path.read_bytes()
            except OSError:
                continue
            if len(raw) <= 8 * 1024 * 1024:
                text = raw.decode("utf-8", errors="ignore")
                handles = sorted(set(_SCREEN_NAME_RE.findall(text)))
                if handles:
                    candidate_handles.append({
                        "file_path": str(path), "file_sha256": _sha256(path),
                        "candidate_handles": handles, "promotion_status": "NOT_PROMOTED",
                        "reason": "Handle-shaped text does not establish account identity or ownership.",
                    })
            continue
        for record in records:
            records_examined += 1
            ids = _record_identifiers(record)
            participant_ids = [item for item in ids if item["kind"] != "message_id"]
            for item in ids:
                node_id = _node(item["kind"], item["value"])
                node = nodes.setdefault(node_id, {
                    "id": node_id, "kind": item["kind"], "value": item["value"],
                    "occurrences": [],
                })
                node["occurrences"].append({
                    **record_locator_metadata(record, item["field"]),
                    "field_role": item["role"],
                })
            # Correlate only identifiers co-occurring in the same exact record.
            unique_record_nodes = sorted({_node(item["kind"], item["value"]) for item in participant_ids})
            for idx, left in enumerate(unique_record_nodes):
                for right in unique_record_nodes[idx + 1:]:
                    key = (left, right)
                    edge = edges.setdefault(key, {
                        "source": left, "target": right,
                        "relationship": "co_occurs_in_same_structured_record",
                        "record_references": [],
                    })
                    edge["record_references"].append({
                        **record_locator_metadata(record),
                        "fields": sorted({item["field"] for item in participant_ids}),
                    })

    # Emit exact occurrence findings, not a single whole-image regex summary.
    for node in sorted(nodes.values(), key=lambda x: x["id"]):
        if node["kind"] == "message_id":
            continue
        first = node["occurrences"][0]
        kind = node["kind"]
        description = (
            f"The literal {kind} identifier '{node['value']}' occurs in {len(node['occurrences'])} "
            "exact parsed record(s). This establishes occurrence only, not ownership, identity or intent."
        )
        md = {
            **deterministic_metadata(
                "structured-record field parsing and exact token validation",
                validators=["core.structured_records", "strict token validator"],
                semantic_limit="Occurrence/co-occurrence only; no criminality, ownership or real-person attribution.",
            ),
            "identifier_kind": kind, "identifier_value": node["value"],
            "occurrence_count": len(node["occurrences"]),
            "occurrences": node["occurrences"],
            "source_file": first.get("source_file"), "file_path": first.get("file_path"),
            "file_sha256": first.get("file_sha256"),
            **{k: v for k, v in first.items() if k in {"table", "rowid", "row", "line", "json_path", "message_index", "field_name"}},
        }
        if kind == "ip":
            try:
                ip = ipaddress.ip_address(node["value"])
                md["ip_scope"] = (
                    "private" if ip.is_private else "reserved/documentation" if ip.is_reserved or not ip.is_global else "global"
                )
            except ValueError:
                continue
        findings.append(make_finding(
            "IDENTIFIER_LITERAL_OCCURRENCE", Severity.INFO, description,
            str(first.get("source_file") or evidence_path), md,
            artifact_path=str(first.get("source_file") or "") or None,
        ))

    for edge in sorted(edges.values(), key=lambda x: (x["source"], x["target"])):
        first = edge["record_references"][0]
        findings.append(make_finding(
            "IDENTIFIER_RECORD_COOCCURRENCE", Severity.INFO,
            f"'{edge['source']}' and '{edge['target']}' occur in the same exact parsed record. "
            "This is a neutral record relationship and does not establish criminality or ownership.",
            str(first.get("source_file") or evidence_path),
            {
                **deterministic_metadata(
                    "same-record structured-field co-occurrence",
                    validators=["core.structured_records"],
                    semantic_limit="Neutral co-occurrence only; no social relationship, ownership or criminality inferred.",
                ),
                "source_identifier": edge["source"], "target_identifier": edge["target"],
                "relationship": edge["relationship"],
                "record_count": len(edge["record_references"]),
                "record_references": edge["record_references"],
                "source_file": first.get("source_file"), "file_path": first.get("file_path"),
                "file_sha256": first.get("file_sha256"),
                **{k: v for k, v in first.items() if k in {"table", "rowid", "row", "line", "json_path", "message_index"}},
            },
            artifact_path=str(first.get("source_file") or "") or None,
        ))

    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "identifier_correlation.json"
    report_path.write_text(json.dumps({
        "module": MODULE_NAME, "display_name": "Identifier and record correlation",
        "case_id": case_id, "generated_at": utc_now(),
        "policy": "Only exact structured-record occurrence/co-occurrence is canonical. Criminality, identity and ownership are never inferred.",
        "nodes": sorted(nodes.values(), key=lambda x: x["id"]),
        "edges": sorted(edges.values(), key=lambda x: (x["source"], x["target"])),
        "candidate_observations": candidate_handles,
        "byte_identical_aliases": dict(aliases),
    }, indent=2, ensure_ascii=True), encoding="utf-8")

    end = utc_now()
    summary = (
        f"Neutral identifier correlation examined {records_examined} exact record(s): "
        f"{len(nodes)} literal node(s), {len(edges)} same-record edge(s); "
        f"{len(candidate_handles)} opaque candidate source(s) quarantined."
    )
    cr = ClassResult(
        Locus.OTHER, "Neutral Identifier Record Correlation",
        AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.COMPLETED,
        start_time=start, end_time=end, findings=findings,
        artifact_paths=[str(report_path)], errors=[],
        statistics={
            "sources_discovered": len(unique), "sources_processed": len(unique),
            "supported_objects_discovered": len(unique), "supported_objects_processed": len(unique),
            "records_discovered": records_examined, "records_processed": records_examined,
            "unresolved_supported_objects": 0, "parser_errors": 0,
            "records_examined": records_examined, "identifier_nodes": len(nodes),
            "same_record_edges": len(edges), "candidate_sources": len(candidate_handles),
            "execution_outcome": "ran_found_x" if findings else "ran_found_nothing",
        },
        summary=summary, class_results=[cr],
    )
