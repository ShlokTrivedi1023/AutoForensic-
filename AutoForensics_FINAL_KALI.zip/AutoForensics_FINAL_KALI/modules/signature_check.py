"""signature_check.py — single source of truth for magic-byte vs extension.

Magic-byte-vs-extension mismatch detection must be computed in exactly ONE
place so every consumer reports the same count.  Previously two modules
computed it independently and the report showed two contradicting numbers.

``resolve_signature_mismatches`` performs the computation once per run and
memoises the result on the shared working-set, so whichever module runs first
computes it and every later module consumes the identical result.

The signature table is a general, structural magic-byte table — format
signatures defined by the file formats themselves — not tied to any case.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

# Working-set key holding the memoised mismatch result for the current evidence.
SIGNATURE_MISMATCH_KEY = "signature_mismatch_result"

# General magic-byte signature table: header bytes → (canonical type label,
# extensions that legitimately carry that content).  Structural format
# signatures, never case-specific values.  A container format (ZIP/OLE) maps to
# every extension that is really that container, so an .xlsx detected as a ZIP
# container is not a false mismatch.
_SIGNATURE_TABLE: list[tuple[bytes, str, frozenset[str]]] = [
    (b"\xff\xd8\xff",              "jpeg", frozenset({"jpg", "jpeg", "jpe"})),
    (b"\x89PNG\r\n\x1a\n",         "png",  frozenset({"png"})),
    (b"GIF87a",                    "gif",  frozenset({"gif"})),
    (b"GIF89a",                    "gif",  frozenset({"gif"})),
    (b"BM",                        "bmp",  frozenset({"bmp", "dib"})),
    (b"%PDF",                      "pdf",  frozenset({"pdf"})),
    (b"PK\x03\x04",                "zip",  frozenset({
        "zip", "docx", "xlsx", "pptx", "odt", "ods", "odp",
        "jar", "apk", "epub", "vsdx",
    })),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "ole", frozenset({
        "doc", "xls", "ppt", "msg", "msi", "vsd",
    })),
    (b"MZ",                        "pe",   frozenset({"exe", "dll", "sys", "scr", "ocx", "cpl"})),
    (b"\x7fELF",                   "elf",  frozenset({"elf", "so", "o", "bin"})),
    (b"Rar!\x1a\x07",              "rar",  frozenset({"rar"})),
    (b"\x1f\x8b",                  "gzip", frozenset({"gz", "tgz"})),
    (b"7z\xbc\xaf\x27\x1c",        "7z",   frozenset({"7z"})),
    (b"ID3",                       "mp3",  frozenset({"mp3"})),
    (b"\xff\xfb",                  "mp3",  frozenset({"mp3"})),
    (b"fLaC",                      "flac", frozenset({"flac"})),
    (b"OggS",                      "ogg",  frozenset({"ogg", "oga", "ogv"})),
    (b"RIFF",                      "riff", frozenset({"wav", "avi", "webp"})),
]

# Longest signature first, so a more specific header wins over a shorter prefix.
_SIGNATURE_TABLE_SORTED = sorted(
    _SIGNATURE_TABLE, key=lambda t: len(t[0]), reverse=True
)

# Only extensions the table can adjudicate are worth flagging; an unknown
# extension can never be a mismatch because there is nothing to compare against.
_KNOWN_EXTENSIONS: frozenset[str] = frozenset(
    e for _, _, exts in _SIGNATURE_TABLE for e in exts
)

_MAX_HEADER_BYTES = 16


# Content-type families, derived structurally from the detected format label and
# the declared extension — never from filenames or a per-case allowlist.  A
# mismatch's severity is a function of these two families only.
_DET_EXECUTABLE = frozenset({"pe", "elf"})
_DET_ARCHIVE = frozenset({"zip", "rar", "gzip", "7z"})
_DET_DOCUMENT = frozenset({"pdf", "ole"})
_DET_IMAGE = frozenset({"jpeg", "png", "gif", "bmp"})
_DET_MEDIA = frozenset({"mp3", "flac", "ogg", "riff"})

_EXT_EXECUTABLE = frozenset({"exe", "dll", "sys", "scr", "ocx", "cpl",
                             "elf", "so", "o", "bin"})
_EXT_ARCHIVE = frozenset({"zip", "rar", "gz", "tgz", "7z", "jar", "apk",
                          "epub", "vsdx"})
_EXT_DOCUMENT = frozenset({"pdf", "doc", "xls", "ppt", "docx", "xlsx", "pptx",
                           "odt", "ods", "odp", "msg", "msi", "vsd"})
_EXT_IMAGE = frozenset({"jpg", "jpeg", "jpe", "png", "gif", "bmp", "dib", "webp"})
_EXT_MEDIA = frozenset({"mp3", "flac", "ogg", "oga", "ogv", "wav", "avi"})


# libmagic MIME strings map to the same families, so the severity rule is
# identical whether the detector reported a format label (signature_check) or a
# MIME type (file_signature_analyzer via libmagic).
_MIME_EXECUTABLE = frozenset({
    "application/x-dosexec", "application/x-msdownload", "application/x-executable",
    "application/x-sharedlib", "application/x-elf", "application/x-mach-binary",
    "application/x-pie-executable", "text/x-shellscript", "application/x-sh",
})
_MIME_ARCHIVE = frozenset({
    "application/zip", "application/x-rar", "application/x-rar-compressed",
    "application/x-7z-compressed", "application/x-tar", "application/gzip",
    "application/x-gzip", "application/x-bzip2",
})


def _detected_family(detected_type: str) -> str:
    dt = detected_type.lower()
    if dt in _DET_EXECUTABLE or dt in _MIME_EXECUTABLE:
        return "executable"
    if dt in _DET_ARCHIVE or dt in _MIME_ARCHIVE:
        return "archive"
    if dt in _DET_DOCUMENT:
        return "document"
    if dt in _DET_IMAGE:
        return "image"
    if dt in _DET_MEDIA:
        return "media"
    # MIME prefixes for the passive families.
    if dt.startswith("image/"):
        return "image"
    if dt.startswith(("audio/", "video/")):
        return "media"
    if dt.startswith("text/"):
        return "text"
    if dt == "application/pdf" or dt.startswith("application/vnd") or dt == "application/msword":
        return "document"
    return "other"


def _ext_family(declared_ext: str) -> str:
    ex = declared_ext.lower()
    if ex in _EXT_EXECUTABLE:
        return "executable"
    if ex in _EXT_ARCHIVE:
        return "archive"
    if ex in _EXT_DOCUMENT:
        return "document"
    if ex in _EXT_IMAGE:
        return "image"
    if ex in _EXT_MEDIA:
        return "media"
    return "other"


def _mismatch_severity(detected_type: str, declared_ext: str) -> str:
    """Severity of a magic-byte-vs-extension mismatch, from its category alone.

    Purely a function of the detected content family and the declared extension
    family — no filename inspection, no allowlist.  Returns 'high' | 'medium' |
    'low'.
    """
    det = _detected_family(detected_type)
    ext = _ext_family(declared_ext)
    # Active executable content wearing a non-executable extension is the most
    # serious disguise (e.g. a PE named .pdf).
    if det == "executable" and ext != "executable":
        return "high"
    # Archive content hidden under a non-archive, non-document extension
    # (e.g. a ZIP named .png) is a data-hiding signal.
    if det == "archive" and ext not in ("archive", "document"):
        return "high"
    # Passive families (image/media/text) disagreeing (e.g. a renamed image, or
    # a text file under a media extension) hides nothing active — this is where
    # benign mismatches fall out low.
    _passive = ("image", "media", "text")
    if det in _passive and ext in _passive:
        return "low"
    return "medium"


def _declared_ext(path: Path) -> str:
    return path.suffix.lstrip(".").lower()


def _detect_type(header: bytes) -> Optional[tuple[str, frozenset[str]]]:
    """Return (type_label, valid_extensions) for the header, or None."""
    for magic, label, exts in _SIGNATURE_TABLE_SORTED:
        if header[:len(magic)] == magic:
            return label, exts
    return None


def detect_signature_mismatches(files: "list[Path]") -> list[dict]:
    """Return one record per file whose content type contradicts its extension.

    A file is a mismatch only when BOTH its declared extension and its detected
    content type are known and the extension is not among the extensions that
    legitimately carry that content.  Files with unknown extensions or
    unrecognised headers are not mismatches — there is nothing to contradict.
    """
    mismatches: list[dict] = []
    for f in files:
        try:
            if not f.is_file():
                continue
            ext = _declared_ext(f)
            if ext not in _KNOWN_EXTENSIONS:
                continue
            with open(f, "rb") as fh:
                header = fh.read(_MAX_HEADER_BYTES)
        except OSError:
            continue
        detected = _detect_type(header)
        if detected is None:
            continue
        label, valid_exts = detected
        if ext in valid_exts:
            continue  # content matches an extension it legitimately carries
        mismatches.append({
            "path":          str(f),
            "name":          f.name,
            "declared_ext":  ext,
            "detected_mime": label,
            "detected_type": label,
            "expected_ext":  "/".join(sorted(valid_exts)),
            # Category-derived severity, the single source every surface renders.
            "severity":      _mismatch_severity(label, ext),
        })
    return mismatches


def _iter_corpus_files(corpus_roots: "list[Path]") -> "list[Path]":
    files: list[Path] = []
    for root in corpus_roots:
        try:
            for p in root.rglob("*"):
                if p.is_file():
                    files.append(p)
        except OSError:
            continue
    return files


def publish_signature_mismatches(
    working_set: "Optional[dict[str, Any]]",
    records: list[dict],
) -> None:
    """Publish the authoritative mismatch result onto the shared working-set.

    The module that owns the magic-byte-vs-extension computation calls this so
    every later module consumes its exact result rather than recomputing a
    different one.  Idempotent: a result already published is left in place.
    """
    if isinstance(working_set, dict) and SIGNATURE_MISMATCH_KEY not in working_set:
        working_set[SIGNATURE_MISMATCH_KEY] = list(records)


def resolve_signature_mismatches(
    working_set: "Optional[dict[str, Any]]",
    files: "Optional[list[Path]]" = None,
    corpus_roots: "Optional[list[Path]]" = None,
    logger: "Optional[logging.Logger]" = None,
) -> list[dict]:
    """Compute magic-byte-vs-extension mismatches once, memoised on working_set.

    The first module to call this computes the result over the given files (or
    the corpus roots) and stores it on the working-set under
    ``SIGNATURE_MISMATCH_KEY``; every later caller receives the identical list,
    so no two modules can report different counts.  When no working-set is
    supplied (standalone invocation) the computation simply runs each call.
    """
    ws = working_set if isinstance(working_set, dict) else None
    if ws is not None and SIGNATURE_MISMATCH_KEY in ws:
        return ws[SIGNATURE_MISMATCH_KEY]

    scan_files: list[Path]
    if files is not None:
        scan_files = list(files)
    elif corpus_roots is not None:
        scan_files = _iter_corpus_files(corpus_roots)
    else:
        scan_files = []

    result = detect_signature_mismatches(scan_files)
    if logger is not None:
        logger.debug(
            "[SIGCHECK] magic-byte-vs-extension: %d file(s) scanned, %d mismatch(es)",
            len(scan_files), len(result),
        )
    if ws is not None:
        ws[SIGNATURE_MISMATCH_KEY] = result
    return result
