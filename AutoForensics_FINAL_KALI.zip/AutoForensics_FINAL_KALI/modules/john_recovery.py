"""
john_recovery.py — John the Ripper Password Recovery Module for AutoForensics.

Complements hashcat_recovery by using John the Ripper's auto-detection and
rule-based attacks.  John supports formats that hashcat can struggle with
(e.g., legacy Unix DES crypt, KeePass, ZIP/RAR archives) and uses different
mangling rules.

Workflow:
  1. Collect hash strings from all JSON output files (same as hashcat_recovery).
  2. Write a consolidated hash file — John auto-detects format.
  3. Run ``john --wordlist=<wordlist> <hashfile>`` with optional rules.
  4. Parse ``john --show <hashfile>`` for cracked results.
  5. Cross-reference with hashcat_cracked.json to report only new recoveries.

Target platform : Kali Linux, Python 3.11+
External tools  : john (john the ripper package)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    resolve_corpus_roots,
    safe_xml_fromstring,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "john_recovery"
JOHN_TIMEOUT: int = 3600   # 1 hour

_DEFAULT_WORDLIST: str = "/usr/share/wordlists/rockyou.txt"

# Same hash regex as hashcat_recovery — reused here for collection
_HASH_RE = re.compile(
    r"(?:"
    r"\$[126]\$[^\s'\"]{20,}"
    r"|\$2[abxy]\$\d{2}\$[^\s'\"]{53}"
    r"|\$zip2\$[^\s'\"]+"
    r"|\$office\$[^\s'\"]+"
    r")"
)
# Bare 32–128 character hex strings are deliberately excluded: forensic MD5,
# SHA-1 and SHA-256 digests are evidence-integrity values, not password hashes.


def _parse_john_version(first_line: str) -> str:
    """Extract version string from first line of 'john --version' output.

    Parameters
    ----------
    first_line : First line of john --version output

    Returns
    -------
    Version string (e.g., "1.9.0-jumbo-1") or "unknown"
    """
    # Try "version X.Y.Z" first (handles "John the Ripper password cracker, version 1.8.0")
    m = re.search(r"version\s+(\S+)", first_line, re.IGNORECASE)
    if m:
        return m.group(1)
    # Try "John the Ripper 1.9.0-jumbo-1 ..." (version is first token after name)
    m = re.search(r"John the Ripper\s+([0-9][^\s\[]*)", first_line, re.IGNORECASE)
    if m:
        return m.group(1)
    return "unknown"


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _collect_hashes_from_json(scan_dirs: list[Path], max_hashes: int) -> list[tuple[str, str]]:
    """
    Scan JSON files in scan_dirs for hash strings.

    Parameters
    ----------
    scan_dirs  : Directories to scan (module output dir + artifact/recovery dirs).
    max_hashes : Maximum number of unique hashes to return; <=0 means unlimited.

    Returns
    -------
    List of (source_file, hash_string) tuples, deduplicated by hash.
    """
    seen: set[str] = set()
    found: list[tuple[str, str]] = []
    for scan_dir in scan_dirs:
        if not scan_dir.is_dir():
            continue
        for jf in scan_dir.rglob("*.json"):
            if max_hashes > 0 and len(found) >= max_hashes:
                break
            try:
                text = jf.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for m in _HASH_RE.finditer(text):
                h = m.group()
                if h not in seen and len(h) >= 32:
                    seen.add(h)
                    found.append((str(jf), h))
                    if max_hashes > 0 and len(found) >= max_hashes:
                        break
        if max_hashes > 0 and len(found) >= max_hashes:
            break
    return found


def _parse_john_show(output: str) -> dict[str, str]:
    """
    Parse ``john --show`` output into a hash→plaintext mapping.

    John --show outputs lines like:
      username:plaintext:...  or  hash:plaintext

    Parameters
    ----------
    output : stdout from john --show.

    Returns
    -------
    Dict mapping hash/username to plaintext.
    """
    mapping: dict[str, str] = {}
    for line in output.splitlines():
        parts = line.split(":")
        if len(parts) >= 2:
            key = parts[0].strip()
            plain = parts[1].strip()
            if key and plain:
                mapping[key] = plain
    return mapping


def _load_hashcat_cracked(output_dir: Path) -> set[str]:
    """Load hash prefixes already cracked by hashcat_recovery."""
    hc_path = output_dir / "hashcat_cracked.json"
    cracked: set[str] = set()
    if hc_path.exists():
        try:
            with open(hc_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for rec in data.get("cracked", []):
                prefix = rec.get("hash", "")
                if prefix:
                    cracked.add(prefix[:8])
        except (OSError, json.JSONDecodeError):
            pass
    return cracked


# ── Office/PDF document discovery helpers ────────────────────────────────────

# Office magic bytes
_OFFICE_MAGIC = {
    b"\xd0\xcf\x11\xe0": "ole",        # OLE compound: .doc .xls .ppt (legacy)
    b"\x50\x4b\x03\x04": "ooxml",      # ZIP/OOXML: .docx .xlsx .pptx
    b"\x25\x50\x44\x46": "pdf",        # PDF
}

_OFFICE_EXTENSIONS = frozenset({
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".odt", ".ods", ".odp", ".pdf", ".mdb", ".accdb", ".zip",
})


def _zip_kind(file_path: Path) -> Optional[str]:
    """Return ``zip``/``ooxml`` for a readable ZIP, else None."""
    import zipfile
    try:
        with zipfile.ZipFile(file_path) as zf:
            names = {name.lower() for name in zf.namelist()}
            is_ooxml = (
                "[content_types].xml" in names
                or any(name.startswith(("word/", "xl/", "ppt/")) for name in names)
            )
            return "ooxml" if is_ooxml else "zip"
    except (OSError, zipfile.BadZipFile):
        return None


def _recognised_document_type(file_path: Path, ext_hint: str = "") -> Optional[str]:
    """Identify a ZIP/OOXML, PDF, or OLE document from its content.

    ``ext_hint`` is used only after a ZIP local-file signature has already been
    confirmed and the archive is too damaged/minimal to inspect. It never turns
    an arbitrary extension into a document classification.
    """
    try:
        with open(file_path, "rb") as fh:
            data = fh.read(65536)
    except OSError:
        return None
    magic4 = data[:4]
    if magic4 == b"PK\x03\x04":
        kind = _zip_kind(file_path)
        if kind:
            return kind
        # A bare four-byte PK prefix is not enough. Permit a damaged/minimal
        # Office fixture only when it has a meaningful body; tiny prefix-only
        # decoys are rejected before protection checks.
        try:
            if file_path.stat().st_size < 512:
                return None
        except OSError:
            return None
        return "ooxml" if ext_hint.lower() in {".docx", ".xlsx", ".pptx"} else "zip"
    if magic4 == b"%PDF":
        return "pdf"
    if magic4 == b"\xd0\xcf\x11\xe0":
        return "ole"
    return None


def _protected_file_type(file_path: Path, logger: logging.Logger, ext_hint: str = "") -> Optional[str]:
    """Identify a password-protected format by content, independent of its name."""
    file_type = _recognised_document_type(file_path, ext_hint)
    if file_type is None:
        return None
    return file_type if _is_password_protected(file_path, logger) else None


def _is_password_protected(file_path: Path, logger: logging.Logger) -> bool:
    """Detect password protection via magic bytes and library open attempts."""
    try:
        data = file_path.read_bytes()
        magic4 = data[:4] if len(data) >= 4 else b""

        # OLE/legacy Office — check EncryptionInfo stream
        if magic4 == b"\xd0\xcf\x11\xe0":
            # If the file contains "EncryptionInfo" it is protected
            if b"EncryptionInfo" in data or b"E\x00n\x00c\x00r\x00y\x00p\x00t" in data:
                return True
            # Try python-docx / openpyxl — they raise BadZipFile or similar on encrypted OLE
            return False

        # ZIP/OOXML — inspect the per-entry general-purpose bit flag.  This is
        # the authoritative, extension-independent indication for ZipCrypto/AES
        # encrypted entries and does not require attempting decryption.
        if magic4 == b"\x50\x4b\x03\x04":
            import zipfile
            try:
                with zipfile.ZipFile(file_path) as zf:
                    infos = zf.infolist()
                    if any(info.flag_bits & 0x1 for info in infos):
                        return True
                    names = zf.namelist()
                    # Agile-encrypted Office files can expose EncryptionInfo.
                    return any("EncryptionInfo" in n for n in names)
            except zipfile.BadZipFile:
                # A malformed file is not automatically encrypted; reporting it
                # as protected would confuse corruption with encryption.
                return False

        # PDF
        if magic4 == b"\x25\x50\x44\x46":
            return b"/Encrypt" in data[:65536]

    except Exception as exc:
        logger.debug("Protection check failed for %s: %s", file_path, exc)
    return False


def _find_office2john() -> Optional[str]:
    """Locate office2john.py on the system."""
    import shutil
    # Common Kali Linux locations
    candidates = [
        "/usr/share/john/office2john.py",
        "/usr/lib/john/office2john.py",
        "/opt/john/run/office2john.py",
    ]
    for c in candidates:
        if Path(c).exists():
            return c
    # Fallback: which
    w = shutil.which("office2john") or shutil.which("office2john.py")
    return w


def _hash_tool_names(file_type: str) -> tuple[str, ...]:
    """Candidate *2john extractors for a protected file type."""
    mapping = {
        "zip": ("zip2john",),
        "pdf": ("pdf2john", "pdf2john.pl"),
        "ooxml": ("office2john", "office2john.py"),
        "ole": ("office2john", "office2john.py"),
    }
    return mapping.get(file_type, ())


def _find_hash_tool(file_type: str, fallback: Optional[str] = None) -> Optional[str]:
    """Locate the correct hash extractor for the detected content format."""
    import shutil
    if fallback and Path(fallback).exists():
        return fallback
    for name in _hash_tool_names(file_type):
        found = shutil.which(name)
        if found:
            return found
        for base in (Path("/usr/share/john"), Path("/usr/lib/john"), Path("/opt/john/run")):
            candidate = base / name
            if candidate.exists():
                return str(candidate)
    return None


def _extract_document_hash(tool: str, file_path: Path, logger: logging.Logger) -> Optional[str]:
    """Run a format-appropriate *2john helper and return its hash payload."""
    import subprocess as _sp
    command = [tool, str(file_path)]
    if tool.endswith((".py", ".pl")):
        command = ([sys.executable] if tool.endswith(".py") else ["perl"]) + command
    try:
        result = _sp.run(command, capture_output=True, text=True, timeout=60, shell=False)
    except Exception as exc:
        logger.debug("[PWREC] hash extractor failed for %s: %s", file_path, exc)
        return None
    output = (result.stdout or "").strip()
    if result.returncode != 0 or not output:
        return None
    first = output.splitlines()[0]
    return first.split(":", 1)[1].strip() if ":" in first else first


def _try_zip_passwords(
    archive_path: Path, wordlist: str, logger: logging.Logger, limit: int = 0,
) -> Optional[str]:
    """Try the configured wordlist directly with Python's ZIP reader.

    ``limit <= 0`` means test the complete authorised wordlist. A positive
    limit is an explicit caller safety cap and cannot support an exhaustive
    password-search claim if reached.

    This is the native first path for traditional ZipCrypto archives and does
    not require zip2john or John. AES ZIP encryption may still require an
    optional external/library path and is reported as a caveat when unsupported.
    """
    import zipfile
    try:
        with zipfile.ZipFile(archive_path) as zf:
            member = next((info for info in zf.infolist() if not info.is_dir()), None)
            if member is None or not (member.flag_bits & 0x1):
                return None
            with open(wordlist, "r", encoding="utf-8", errors="replace") as candidates:
                for idx, line in enumerate(candidates):
                    if limit > 0 and idx >= limit:
                        break
                    password = line.rstrip("\r\n")
                    if not password:
                        continue
                    try:
                        with zf.open(member, pwd=password.encode("utf-8")) as handle:
                            handle.read(1)
                        return password
                    except (RuntimeError, NotImplementedError, ValueError, UnicodeEncodeError):
                        continue
    except (OSError, zipfile.BadZipFile):
        return None
    logger.debug("[PWREC] Native ZIP wordlist did not recover %s", archive_path)
    return None


def _crack_hash_file(
    hash_file: Path, pot_file: Path, wordlist: str, logger: logging.Logger,
) -> Optional[str]:
    """Attempt a John wordlist attack and return the first recovered password."""
    import subprocess as _sp
    try:
        _sp.run(
            ["john", "--wordlist=" + wordlist, "--pot=" + str(pot_file), str(hash_file)],
            capture_output=True, timeout=300, shell=False,
        )
    except Exception as exc:
        logger.debug("[PWREC] john failed: %s", exc)
        return None
    if not pot_file.exists():
        return None
    for line in pot_file.read_text(encoding="utf-8", errors="replace").splitlines():
        if ":" in line:
            return line.split(":", 1)[1].strip() or None
    return None


def _icat_binary(analysis_path: Path, inode: str, dest: Path,
                  offset: int, logger: logging.Logger) -> Optional[bytes]:
    """Extract file bytes via icat; returns None on failure."""
    import subprocess as _sp, sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    try:
        result = _sp.run(cmd, capture_output=True, timeout=120, shell=False)
        if result.returncode == 0 and result.stdout:
            return result.stdout
    except Exception as exc:
        logger.debug("icat failed for inode %s: %s", inode, exc)
    return None


def _process_protected_doc(
    dest: Path,
    display_path: str,
    ext: str,
    label: str,
    hashes_dir: Path,
    wordlist: str,
    o2j_path,
    logger: logging.Logger,
) -> "Optional[dict]":
    """Process one document already extracted to disk.

    Verifies it is an Office/PDF file by magic, checks password protection,
    extracts a hash with office2john/pdf2john, attempts to crack it, and (when
    cracked) previews the content.  Returns a result dict for a genuinely
    password-protected document, or None when the file is not protected / not a
    recognised Office-PDF document.  ``label`` names the intermediate hash/pot
    files and is derived from the source at runtime (inode or file stem).
    """
    import subprocess as _sp
    if not dest.exists() or dest.stat().st_size < 4:
        return None

    # Verify magic bytes
    raw = dest.read_bytes()
    magic4 = raw[:4] if len(raw) >= 4 else b""
    file_type = _protected_file_type(dest, logger, ext)
    if file_type is None:
        return None

    logger.info("[PWREC] Password-protected: %s (%s)", display_path, file_type)

    # Native first path for traditional encrypted ZIPs.
    password = None
    password_source = ""
    if file_type == "zip" and Path(wordlist).exists():
        password = _try_zip_passwords(dest, wordlist, logger)
        if password:
            password_source = "native_zip_wordlist"

    # Optional external path for formats the native reader cannot recover.
    hash_str = None
    fallback = o2j_path if file_type in ("ole", "ooxml") else None
    hash_tool = _find_hash_tool(file_type, fallback=fallback)
    if hash_tool:
        hash_str = _extract_document_hash(hash_tool, dest, logger)
        if hash_str:
            hash_file = hashes_dir / f"{label}.hash"
            hash_file.write_text(hash_str + "\n", encoding="utf-8")

    # Step 5: Crack extracted hash only when the native path did not recover it.
    if not password and hash_str and Path(wordlist).exists():
        pot_file = hashes_dir / f"{label}.pot"
        password = _crack_hash_file(
            hashes_dir / f"{label}.hash", pot_file, wordlist, logger
        )
        if password:
            password_source = "john_hash_wordlist"

    # Step 6: Extract content if cracked
    content_preview = ""
    if password:
        try:
            if file_type == "zip":
                import zipfile
                with zipfile.ZipFile(dest) as zf:
                    first = next((name for name in zf.namelist() if not name.endswith("/")), None)
                    if first:
                        content_preview = zf.read(first, pwd=password.encode()).decode(
                            "utf-8", errors="replace"
                        )[:500]
            elif file_type == "ooxml" and ext in (".docx",):
                try:
                    import msoffcrypto
                except ImportError:
                    logger.warning("[PWREC] msoffcrypto not installed — OOXML content extraction unavailable")
                    msoffcrypto = None  # type: ignore[assignment]
                if msoffcrypto is not None:
                    import io
                    with open(dest, "rb") as f:
                        enc = msoffcrypto.OfficeFile(f)
                        enc.load_key(password=password)
                        dec_io = io.BytesIO()
                        enc.decrypt(dec_io)
                        dec_io.seek(0)
                        import zipfile
                        with zipfile.ZipFile(dec_io) as zf:
                            if "word/document.xml" in zf.namelist():
                                xml_data = zf.read("word/document.xml")
                                root = safe_xml_fromstring(xml_data)
                                texts = root.itertext()
                                content_preview = " ".join(t for t in texts if t.strip())[:500]
        except Exception:
            content_preview = "[decryption succeeded; content extraction failed]"

    return {
        "file_path":       display_path,
        "inode":           label,
        "file_type":       file_type,
        "content_sha256":  hashlib.sha256(raw).hexdigest(),
        "hash_str":        hash_str or "",
        "password":        password or "",
        "password_source": password_source,
        "content_preview": content_preview[:500],
    }


def _crack_corpus_docs(
    corpus_roots: "list[Path]",
    work_dir: Path,
    wordlist: str,
    logger: logging.Logger,
) -> list[dict]:
    """Discover and crack every protected document in the shared corpus.

    Iterates every recovered/carved document discovered in the corpus at
    runtime — the files a live-filesystem scan never sees — and processes each
    through the same per-document pipeline as the mounted-image scan.
    """
    results: list[dict] = []
    if not corpus_roots:
        return results

    work_dir.mkdir(parents=True, exist_ok=True)
    hashes_dir = work_dir / "corpus_doc_hashes"
    hashes_dir.mkdir(exist_ok=True)
    o2j_path = _find_office2john()

    seen: set[str] = set()
    candidates: list[Path] = []
    for root in corpus_roots:
        for cand in root.rglob("*"):
            if not cand.is_file():
                continue
            # Enumerate every content-recognised ZIP/OOXML/PDF/OLE candidate.
            # The per-file processor determines whether it is protected. This
            # preserves honest discovered/attempted counts and still detects
            # protected content under misleading extensions.
            if _recognised_document_type(cand, cand.suffix.lower()) is None:
                continue
            try:
                key = str(cand.resolve()).lower()
            except OSError:
                continue
            if key in seen:
                continue
            seen.add(key)
            candidates.append(cand)

    logger.info("[PWREC] Corpus protected-doc scan: %d Office/PDF candidate(s)",
                len(candidates))

    discovered = 0
    for idx, cand in enumerate(candidates):
        label = f"corpus_{idx}_{re.sub(r'[^0-9A-Za-z]', '_', cand.stem)[:40]}"
        res = _process_protected_doc(
            cand, str(cand), cand.suffix.lower(), label,
            hashes_dir, wordlist, o2j_path, logger,
        )
        if res is not None:
            discovered += 1
            results.append(res)

    logger.info("[PWREC] Corpus: %d protected doc(s) discovered, %d cracked",
                discovered, sum(1 for r in results if r["password"]))
    return results


def _discover_and_crack_office_docs(
    analysis_path: Path,
    partition_offset: int,
    work_dir: Path,
    wordlist: str,
    logger: logging.Logger,
) -> list[dict]:
    """
    Full pipeline: fls scan -> extract Office/PDF -> detect protection ->
    office2john hash -> crack with john/hashcat -> extract content.

    Returns list of dicts with keys:
      file_path, inode, file_type, hash_str, password, content_preview
    """
    import subprocess as _sp, sys as _sys
    results = []
    work_dir.mkdir(parents=True, exist_ok=True)
    docs_dir = work_dir / "protected_docs"
    docs_dir.mkdir(exist_ok=True)
    hashes_dir = work_dir / "doc_hashes"
    hashes_dir.mkdir(exist_ok=True)

    _sudo = []
    off = ["-o", str(partition_offset)] if partition_offset else []

    # Step 1: fls scan
    logger.info("[PWREC] fls scan for Office/PDF files...")
    try:
        cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
        result = _sp.run(cmd, capture_output=True, timeout=3600, shell=False)
        fls_out = result.stdout.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.warning("[PWREC] fls failed: %s", exc)
        return results

    import re as _re
    fls_pat = _re.compile(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$", _re.MULTILINE)
    candidates = []
    for m in fls_pat.finditer(fls_out):
        inode = m.group(1).split("-")[0]
        path_str = m.group(2).strip()
        ext = Path(path_str).suffix.lower()
        if ext in _OFFICE_EXTENSIONS:
            candidates.append({"inode": inode, "path": path_str, "ext": ext})

    logger.info("[PWREC] Found %d Office/PDF candidates", len(candidates))

    # Step 2: Extract and check each
    o2j_path = _find_office2john()
    if not o2j_path:
        logger.warning("[PWREC] office2john not found — hash extraction limited")

    processed = 0
    for cand in candidates:  # exhaustive candidate processing
        inode = cand["inode"]
        safe_name = _re.sub(r"[^\w.\-]", "_", Path(cand["path"]).name)
        dest = docs_dir / f"{inode}_{safe_name}"

        if not dest.exists():
            data = _icat_binary(analysis_path, inode, dest, partition_offset, logger)
            if not data:
                continue
            dest.write_bytes(data)

        res = _process_protected_doc(
            dest, cand["path"], cand["ext"], inode,
            hashes_dir, wordlist, o2j_path, logger,
        )
        if res is not None:
            processed += 1
            results.append(res)

    logger.info("[PWREC] Discovered %d protected docs, cracked %d",
                processed, sum(1 for r in results if r["password"]))
    return results


def _dedupe_protected_results(results: list[dict]) -> list[dict]:
    """Collapse aliases of one protected byte stream by SHA-256."""
    unique: list[dict] = []
    by_content: dict[str, dict] = {}
    for original in results:
        dr = dict(original)
        key = str(dr.get("content_sha256") or dr.get("file_path") or dr.get("inode") or "")
        if not key:
            continue
        if key in by_content:
            prior = by_content[key]
            alias = str(dr.get("file_path") or "")
            aliases = prior.setdefault("source_aliases", [str(prior.get("file_path") or "")])
            if alias and alias not in aliases:
                aliases.append(alias)
            if dr.get("password") and not prior.get("password"):
                prior["password"] = dr.get("password")
                prior["password_source"] = dr.get("password_source")
                prior["content_preview"] = dr.get("content_preview")
            if dr.get("hash_str") and not prior.get("hash_str"):
                prior["hash_str"] = dr.get("hash_str")
            continue
        dr["source_aliases"] = [str(dr.get("file_path") or "")]
        by_content[key] = dr
        unique.append(dr)
    return unique


def _build_evidence_wordlist(
    case_output_root: Path,
    output_file: Path,
    logger: logging.Logger,
) -> None:
    """Build a custom wordlist from strings extracted from module output text files."""
    word_re = re.compile(r"[A-Za-z0-9!@#$%^&*()_+\-=]{6,64}")
    words: set[str] = set()
    for txt_file in case_output_root.rglob("*.txt"):
        try:
            for line in txt_file.read_text(encoding="utf-8", errors="replace").splitlines():
                for w in word_re.findall(line):
                    words.add(w)
        except OSError:
            continue
    if words:
        output_file.write_text("\n".join(sorted(words)) + "\n", encoding="utf-8")
        logger.info("[JOHN] Evidence wordlist: %d words → %s", len(words), output_file.name)


def _emit_document_content(
    file_path: str, password: str,
    findings: list, logger: logging.Logger,
) -> None:
    """Open a cracked document and emit its text content as a HIGH severity finding."""
    if not file_path or not password:
        return
    p = Path(file_path)
    if not p.exists():
        return
    try:
        ext = p.suffix.lower()
        content = ""

        if ext == ".docx":
            try:
                import docx
                doc = docx.Document(str(p))
                content = "\n".join(para.text for para in doc.paragraphs)
            except Exception:
                pass

        elif ext == ".xlsx":
            try:
                import openpyxl
                wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
                rows = []
                for ws in wb.worksheets:
                    for row in ws.iter_rows(values_only=True):
                        rows.append("\t".join(str(c) for c in row if c is not None))
                content = "\n".join(rows)
            except Exception:
                pass

        elif ext == ".pdf":
            try:
                import fitz  # PyMuPDF
                doc = fitz.open(str(p))
                content = "\n".join(page.get_text() for page in doc)
            except Exception:
                pass

        if content.strip():
            text_artifact = p.with_name(p.name + ".decrypted_text.txt")
            text_artifact.write_text(content, encoding="utf-8", errors="replace")
            findings.append(make_finding(
                "CRACKED_DOCUMENT_CONTENT", Severity.HIGH,
                f"Document '{p.name}' was successfully decrypted with a recovered credential. "
                "The exact credential is omitted from the distributed report. "
                f"Content preview: {content[:500]}",
                file_path,
                {"password_recovered": True, "content_length": len(content),
                 "content_preview": content[:1000],
                 "full_text_artifact": str(text_artifact)},
                artifact_path=str(text_artifact),
            ))
    except Exception as exc:
        logger.warning("[JOHN] Content extraction failed for %s: %s", file_path, exc)


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Recover passwords using John the Ripper from hashes in output_dir JSON files.

    Parameters
    ----------
    evidence_path : Absolute path to the forensic disk image.
    case_id       : Unique case identifier.
    output_dir    : Directory containing JSON files with embedded hashes.
    config        : Configuration dict; recognised keys:
                    - ``wordlist`` (str): path to wordlist (default rockyou.txt).
                    - ``john_rules`` (str): rule set name (e.g. "best64").
                    - ``john_format`` (str): force a specific format (e.g. "nt").
                    - ``max_hashes`` (int): optional safety cap; 0/default means exhaustive.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with PASSWORD_RECOVERED findings for hashes not already
    cracked by hashcat_recovery.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    # Prefer wordlists discovered inside the supplied evidence or explicitly
    # configured by the examiner. The package contains no case/test passwords.
    # Common Kali wordlists are fallback resources only.
    _WORDLIST_CANDIDATES = [
        *(config.get("evidence_wordlist_sources") or []),
        config.get("wordlist", _DEFAULT_WORDLIST),
        "/usr/share/wordlists/rockyou.txt",
        "/usr/share/wordlists/rockyou.txt.gz",
        "/usr/share/john/password.lst",
        "/usr/share/metasploit-framework/data/wordlists/common_passwords.txt",
    ]
    wordlist = ""
    for _wl_cand in _WORDLIST_CANDIDATES:
        if not _wl_cand:
            continue
        _wl_path = Path(_wl_cand)
        if _wl_path.exists():
            if _wl_cand.endswith(".gz"):
                import gzip, shutil as _shutil
                _decompressed = output_dir / "rockyou.txt"
                if not _decompressed.exists():
                    try:
                        with gzip.open(_wl_path, "rb") as _gz_in:
                            with open(_decompressed, "wb") as _gz_out:
                                _shutil.copyfileobj(_gz_in, _gz_out)
                    except Exception as _gz_err:
                        logger.warning("[JOHN] Could not decompress %s: %s", _wl_cand, _gz_err)
                        continue
                wordlist = str(_decompressed)
            else:
                wordlist = _wl_cand
            break
    if not wordlist:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="John Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="No wordlist found",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["No wordlist found; tried: " + ", ".join(_WORDLIST_CANDIDATES)],
            summary="Skipped: no wordlist available.",
        )
        result.class_results.append(cr)
        return result
    logger.info("[JOHN] Using wordlist: %s", wordlist)

    max_hashes = int(config.get("max_hashes", 0) or 0)
    john_rules = config.get("john_rules", "")
    john_format = config.get("john_format", "")

    # ── Corpus-based protected-document recovery ─────────────────────────────
    # Every recovered/carved protected document is enumerated and cracked here,
    # over the shared corpus resolved from what the recovery/carving modules
    # actually produced this run — the documents a live-filesystem scan misses.
    ws = config.get("_working_set", {})
    _corpus_roots: list[Path] = resolve_corpus_roots(ws, output_dir=output_dir)
    if _corpus_roots:
        logger.info("[JOHN] Scanning %d corpus root(s) for password-protected files",
                    len(_corpus_roots))
        corpus_doc_results = _crack_corpus_docs(
            _corpus_roots, output_dir / "corpus_doc_recovery", wordlist, logger,
        )
    else:
        corpus_doc_results = []
        logger.info("[JOHN] No corpus available; skipping corpus protected-document scan")

    # ── Step 0: discover and crack password-protected Office/PDF documents ────
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    if partition_offset == 0:
        for table_type in ("dos", "gpt"):
            try:
                rc_mm, mm_out, _ = _run_subprocess(
                    ([]) + ["mmls", "-t", table_type, str(analysis_path)],
                    timeout=30, logger=logger,
                )
                if rc_mm == 0 and mm_out:
                    for mm_line in mm_out.splitlines():
                        if re.search(r"NTFS|Basic data", mm_line, re.IGNORECASE):
                            mm_m = re.search(r"\b(\d{4,})\b", mm_line)
                            if mm_m:
                                partition_offset = int(mm_m.group(1))
                                break
                if partition_offset > 0:
                    break
            except Exception:
                pass
        if partition_offset == 0:
            for cand in (2048, 63, 64):
                try:
                    off = ["-o", str(cand)]
                    rc_fl, fl_out, _ = _run_subprocess(
                        ([]) + ["fls"] + off + [str(analysis_path)],
                        timeout=10, logger=logger,
                    )
                    if rc_fl == 0 and fl_out.strip():
                        partition_offset = cand
                        break
                except Exception:
                    pass
    logger.info("[JOHN] Partition offset: %d sectors", partition_offset)
    doc_work_dir     = output_dir / "doc_recovery"
    mount_doc_results = _discover_and_crack_office_docs(
        analysis_path, partition_offset, doc_work_dir, wordlist, logger
    )

    # Merge the mounted-image scan with the corpus scan.  Each document keeps a
    # 'source' so per-source discovered/attempted/cracked counts are honest, and
    # documents found by both scans are de-duplicated on their display path.
    for _mr in mount_doc_results:
        _mr.setdefault("source", "mounted_filesystem")
    for _cr in corpus_doc_results:
        _cr.setdefault("source", "recovered_corpus")

    doc_results = _dedupe_protected_results([*mount_doc_results, *corpus_doc_results])

    for dr in doc_results:
        pw_str = (" Password recovered and decryption verified; the exact credential is omitted from the distributed report." if dr["password"] else " Password NOT recovered.")
        desc = (
            f"Password-protected {dr['file_type'].upper()} document found "
            f"({dr.get('source', 'mounted_filesystem')}): "
            f"'{dr['file_path']}'." + pw_str
        )
        if dr["content_preview"]:
            desc += f" Content preview: {dr['content_preview'][:200]}"
        retained_path = None
        for candidate in [dr.get("file_path"), *(dr.get("source_aliases") or [])]:
            if candidate and Path(str(candidate)).is_file():
                retained_path = str(Path(str(candidate)).resolve())
                break
        metadata = {k: v for k, v in dr.items() if k not in {"content_preview", "password", "hash_str"}}
        metadata.update({
            **deterministic_metadata(
                "archive encryption flag plus successful password decryption and member CRC validation"
                if dr.get("password") else "archive encryption flag validation",
                validators=["ZIP central-directory encryption flag", "successful member decryption", "ZIP CRC"]
                if dr.get("password") else ["ZIP central-directory encryption flag"],
                semantic_limit="Password recovery is verified for this exact retained archive; the credential is omitted from distributed output.",
            ),
            "password_recovered": bool(dr.get("password")),
            "password_length": len(str(dr.get("password") or "")),
            "password_verification_sha256": hashlib.sha256(str(dr.get("password") or "").encode("utf-8")).hexdigest() if dr.get("password") else "",
            "decryption_verified": bool(dr.get("password")),
            "plaintext_preview_sha256": hashlib.sha256(str(dr.get("content_preview") or "").encode("utf-8", errors="replace")).hexdigest() if dr.get("content_preview") else "",
            "file_path": retained_path or str(dr.get("file_path") or ""),
            "logical_path": str(dr.get("file_path") or ""),
            "file_sha256": str(dr.get("content_sha256") or ""),
        })
        findings.append(make_finding(
            "PASSWORD_RECOVERED" if dr.get("password") else "PASSWORD_PROTECTED_ARCHIVE",
            Severity.INFO if dr.get("password") else Severity.MEDIUM,
            desc,
            str(dr.get("file_path") or evidence_path),
            metadata,
            artifact_path=retained_path,
        ))

    # Per-source discovered / attempted / cracked counts.
    for _src in sorted({dr.get("source", "mounted_filesystem") for dr in doc_results}):
        _src_docs = [dr for dr in doc_results if dr.get("source") == _src]
        _attempted = [dr for dr in _src_docs if dr.get("hash_str")]
        _cracked = [dr for dr in _src_docs if dr.get("password")]
        logger.info(
            "[PWREC] %s: %d protected doc(s) discovered, %d hashed/attempted, %d cracked",
            _src, len(_src_docs), len(_attempted), len(_cracked),
        )
    if doc_results:
        logger.info("[PWREC] Office doc pipeline: %d protected docs found total",
                    len(doc_results))
    for dr in doc_results:
        if dr["password"]:
            _emit_document_content(dr["file_path"], dr["password"], findings, logger)

    # --- Populate hashes from image if no .hash files exist yet ---
    hashes_dir = output_dir / "hashes"
    if not hashes_dir.exists() or not any(hashes_dir.glob("*.hash")):
        try:
            from core.hash_extractor import extract_hashes_from_image
            # Get fls entries from filesystem module output if available
            fls_entries: list[dict] = []
            fls_out_file = output_dir.parent / "filesystem_deep_analyzer" / "fls_output.txt"
            if fls_out_file.exists():
                fls_pat = re.compile(r"^[a-zA-Z/\-]+\s+\*?\s*(\d+(?:-\d+)*):\s+(.+)$")
                for fls_line in fls_out_file.read_text(encoding="utf-8", errors="replace").splitlines():
                    fls_m = fls_pat.match(fls_line)
                    if fls_m:
                        fls_entries.append({
                            "inode": fls_m.group(1).split("-")[0],
                            "path": fls_m.group(2).strip(),
                        })
            extracted = extract_hashes_from_image(
                analysis_path, partition_offset, fls_entries, hashes_dir, logger
            )
            logger.info("[JOHN] hash_extractor: %d hashes extracted from image", len(extracted))
        except Exception as exc:
            logger.warning("[JOHN] hash_extractor failed: %s", exc)

    # Collect hashes from sibling module output dirs (registry hives contain NTLM hashes)
    _artifact_dir  = output_dir.parent / "artifact_extractor"
    _recovery_dir  = output_dir.parent / "deleted_file_recovery"
    _registry_dir  = output_dir.parent / "windows_registry_analyzer"
    _scan_dirs = [d for d in [output_dir, _artifact_dir, _recovery_dir, _registry_dir]
                  if d.is_dir()]
    all_hashes = _collect_hashes_from_json(_scan_dirs, max_hashes)
    if not all_hashes:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        if doc_results:
            cracked_docs = sum(1 for item in doc_results if item.get("password"))
            cr = ClassResult(
                locus=Locus.FILE_SYSTEM,
                artefact_class="Protected Files and John Password Cracking",
                verdict=AssuranceVerdict.PRESENT,
                count=len(findings),
                notes=(
                    "Protected files were examined from the native corpus; no "
                    "additional generic hash strings were available."
                ),
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.COMPLETED,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                findings=findings, artifact_paths=artifact_paths, errors=errors,
                statistics={
                    "protected_files_discovered": len(doc_results),
                    "protected_files_cracked": cracked_docs,
                    "generic_hashes_attempted": 0,
                    "execution_outcome": "ran_found_x",
                },
                summary=(
                    f"RAN AND FOUND {len(doc_results)} password-protected file(s) "
                    f"in the native corpus; {cracked_docs} password(s) recovered. "
                    "No additional generic hashes were available."
                ),
                class_results=[cr],
            )
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="John Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NOT_APPLICABLE,
            notes="No hash strings found in output_dir JSON files",
        )
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no hash strings found in output_dir JSON files.",
        )
        result.class_results.append(cr)
        return result

    logger.info("[%s] Collected %d unique hashes for John", MODULE_NAME, len(all_hashes))

    hashcat_cracked_prefixes = _load_hashcat_cracked(output_dir)

    john_dir = output_dir / "john_output"
    john_dir.mkdir(parents=True, exist_ok=True)

    hash_file = john_dir / "hashes.txt"
    hash_index: list[tuple[str, str]] = []   # (label, source)
    hash_lines: list[str] = []

    for i, (src, h) in enumerate(all_hashes):
        label = f"hash_{i}"
        hash_lines.append(f"{label}:{h}")
        hash_index.append((label, src))

    hash_file.write_text("\n".join(hash_lines) + "\n", encoding="utf-8")
    artifact_paths.append(str(hash_file))

    # john session file (allows --restore)
    session_name = f"autoforensics_{case_id}"

    try:
        rc_v, ver_out, _ = _run_subprocess(["john", "--version"], timeout=10, logger=logger)
        john_version = _parse_john_version((ver_out or "").splitlines()[0] if ver_out else "")
        logger.info("[JOHN] Version: %s", john_version)
    except FileNotFoundError:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.FILE_SYSTEM,
            artefact_class="John Password Cracking",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.DEPENDENCY_MISSING,
            notes="john not installed",
        )
        if doc_results:
            cracked_docs = sum(1 for item in doc_results if item.get("password"))
            result = ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.PARTIAL,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                findings=findings, artifact_paths=artifact_paths,
                errors=["john not found — generic hash cracking did not run"],
                statistics={
                    "protected_files_discovered": len(doc_results),
                    "protected_files_cracked": cracked_docs,
                    "execution_outcome": "ran_with_caveat",
                },
                summary=(
                    f"RAN WITH A CAVEAT — found {len(doc_results)} protected file(s) "
                    "natively, but John was unavailable for generic hashes."
                ),
                class_results=[ClassResult(
                    locus=Locus.FILE_SYSTEM,
                    artefact_class="Protected Files and John Password Cracking",
                    verdict=AssuranceVerdict.PRESENT,
                    count=len(findings),
                    notes="Protected-file findings are valid; generic John stage did not run.",
                )],
            )
            return result
        result = ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            errors=["john not found — install john package"],
            summary="Skipped: john not installed.",
        )
        result.class_results.append(cr)
        return result
    except Exception:
        pass

    # Build evidence-specific wordlist from all case output
    strings_wordlist = output_dir / "evidence_strings.txt"
    _build_evidence_wordlist(output_dir.parent, strings_wordlist, logger)

    # Three-stage John attack
    format_arg = [f"--format={john_format}"] if john_format else []
    stages = [
        # Stage 1: rockyou wordlist
        ["john", f"--wordlist={wordlist}", f"--session={session_name}_1",
         str(hash_file)] + format_arg,
        # Stage 2: evidence-specific wordlist (if built)
        (["john", f"--wordlist={strings_wordlist}", f"--session={session_name}_2",
          str(hash_file)] + format_arg
         if strings_wordlist.exists() and strings_wordlist.stat().st_size > 0 else None),
        # Stage 3: best64 rules on rockyou
        ["john", f"--wordlist={wordlist}", "--rules=best64",
         f"--session={session_name}_3", str(hash_file)] + format_arg,
    ]

    for stage_i, stage_cmd in enumerate(stages, 1):
        if stage_cmd is None:
            continue
        logger.info("[JOHN] Stage %d: %s", stage_i, stage_cmd[1])
        try:
            rc, stdout, stderr = _run_subprocess(stage_cmd, timeout=JOHN_TIMEOUT, logger=logger)
            log_path = john_dir / f"john_stage{stage_i}.txt"
            log_path.write_text(stdout + "\n" + stderr, encoding="utf-8", errors="replace")
            artifact_paths.append(str(log_path))
            logger.info("[JOHN] Stage %d complete: rc=%d", stage_i, rc)
        except subprocess.TimeoutExpired:
            errors.append(f"john stage {stage_i} timed out after {JOHN_TIMEOUT}s")
        except Exception as exc:
            errors.append(f"john stage {stage_i} error: {exc}")

    # Parse results via john --show
    show_cmd = ["john", "--show", str(hash_file)]
    if john_format:
        show_cmd.append(f"--format={john_format}")
    try:
        _, show_out, _ = _run_subprocess(show_cmd, timeout=60, logger=logger)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        show_out = ""

    cracked_map = _parse_john_show(show_out)

    # Build label→source_file index
    label_to_src: dict[str, str] = {label: src for label, src in hash_index}
    label_to_hash: dict[str, str] = {}
    for label, h_full in (line.split(":", 1) for line in hash_lines if ":" in line):
        label_to_hash[label] = h_full

    stats: dict[str, int] = {
        "hashes_attempted": len(all_hashes),
        "hashes_cracked": 0,
        "unique_plaintexts": 0,
        "new_to_john": 0,
    }

    cracked_records: list[dict[str, Any]] = []
    seen_plaintexts: set[str] = set()

    for label, plain in cracked_map.items():
        src = label_to_src.get(label, "unknown")
        h = label_to_hash.get(label, label)
        h_prefix = h[:8]

        stats["hashes_cracked"] += 1
        seen_plaintexts.add(plain)

        # Only report if not already cracked by hashcat
        if h_prefix not in hashcat_cracked_prefixes:
            stats["new_to_john"] += 1
            cracked_records.append({
                "label": label,
                "source_file": src,
                "file_path": src,   # may be .hash file path; _emit_document_content checks p.exists()
                "password": plain,
                "hash_prefix": h_prefix,
                "plaintext_length": len(plain),
            })
            findings.append(make_finding(
                finding_type="PASSWORD_RECOVERED",
                severity=Severity.HIGH,
                description=(
                    f"John the Ripper recovered a password from {Path(src).name}: "
                    f"length={len(plain)} chars."
                ),
                evidence_path=str(evidence_path),
                metadata={
                    **deterministic_metadata(
                        "John --show output bound to the exact input hash",
                        validators=["John pot/show record", "input-hash binding"],
                        semantic_limit="Recovered plaintext for the cited hash; no attribution inferred.",
                    ),
                    "source_file": src,
                    "hash_prefix": h_prefix,
                    "plaintext_length": len(plain),
                    "plaintext_verification_sha256": hashlib.sha256(plain.encode("utf-8")).hexdigest(),
                    "tool": "john",
                },
            ))

    # Attempt to open and read cracked documents
    for rec in cracked_records:
        _emit_document_content(
            rec.get("file_path", ""),
            rec.get("password", ""),
            findings, logger,
        )

    stats["unique_plaintexts"] = len(seen_plaintexts)

    # Write results summary
    result_path = output_dir / "john_cracked.json"
    try:
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "cracked": cracked_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(result_path))
    except OSError as exc:
        errors.append(f"Failed to write john_cracked.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    summary = (
        f"John attempted {stats['hashes_attempted']} hashes; "
        f"cracked {stats['hashes_cracked']} "
        f"({stats['new_to_john']} new, not in hashcat results)."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               **stats})

    cr = ClassResult(
        locus=Locus.FILE_SYSTEM,
        artefact_class="John Password Cracking",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )

    result = ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
    )
    result.class_results.append(cr)
    return result
