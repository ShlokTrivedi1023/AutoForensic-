"""
windows_registry_analyzer.py — Comprehensive Windows Registry Forensics Module.

Performs deep analysis of all Windows Registry hives found in the evidence image:
  SAM        — user account profiling; cover-account detection pairs non-built-in
               accounts created close in time only when a corroborating profile
               signal (template-identical or empty profiles) is also present
  SOFTWARE   — OS identification, installed programs (flag forensic/wiping/encryption tools)
  SYSTEM     — USBSTOR history, network shares, computer name, timezone
  NTUSER.DAT — UserAssist, RecentDocs, OpenSaveMRU, TypedURLs, ShellBags, MRU

Uses python-registry when available, falls back to raw REGF binary parsing.

Target platform : Kali Linux, Python 3.11
External tools  : python-registry (pip), regipy (pip, optional)
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import logging
import os
import shutil
import re
import struct
import subprocess
import sys
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata
from core.evidence_inventory import classify_file
from modules._base import iter_corpus_files

from modules._base import (
    AssuranceVerdict, ClassResult, Finding, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason,
    _run_subprocess, make_finding, utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

from core.partition_offset import detect_partition_offset  # noqa: F401

# ---------------------------------------------------------------------------
# python-registry availability — single consolidated import
# (auto-pip-install removed: invasive and unreliable on forensic workstations)
# ---------------------------------------------------------------------------
try:
    from Registry.Registry import Registry as _RegistryClass
    _REGISTRY_OK = True
except ImportError:
    try:
        import Registry as _reg_mod
        _RegistryClass = getattr(_reg_mod, "Registry", None)
        _REGISTRY_OK = _RegistryClass is not None
    except ImportError:
        _RegistryClass = None
        _REGISTRY_OK = False

# Keep _REG_AVAILABLE as an alias for back-compat with existing callers
_REG_AVAILABLE = _REGISTRY_OK

# Registry exception aliases — used to guard partial-hive reads
try:
    from Registry import RegistryParse
    _REG_KEY_NOT_FOUND = getattr(RegistryParse, "RegistryKeyNotFoundException",  KeyError)
    _REG_VAL_NOT_FOUND = getattr(RegistryParse, "RegistryValueNotFoundException", KeyError)
except ImportError:
    _REG_KEY_NOT_FOUND = KeyError
    _REG_VAL_NOT_FOUND = KeyError


def _open_hive(path):
    """Open a registry hive file. Returns Registry object or raises."""
    if not _REGISTRY_OK or _RegistryClass is None:
        raise RuntimeError("python-registry not installed or failed to import")
    from pathlib import Path as _Path
    return _RegistryClass(str(_Path(path)))

MODULE_NAME = "windows_registry_analyzer"
FLS_TIMEOUT = 3600
ICAT_TIMEOUT = 300

# Tools flagged as forensic/anti-forensic (wiping, encryption, privacy)
_SUSPICIOUS_TOOLS = {
    "ccleaner", "eraser", "bleachbit", "sdelete", "fileshredder",
    "privazer", "moo0 anti-recovery", "freeraser", "hardwipe",
    "bitlocker", "veracrypt", "truecrypt", "axcrypt", "7-zip",
    "winrar", "torrent", "bittorrent", "utorrent", "wireshark",
    "nmap", "metasploit", "cain", "aircrack", "kali",
    "tor browser", "vpn", "hide my ip", "anonymizer",
    "steghide", "openstego", "steganos",
    "passware", "elcomsoft", "hashcat", "john the ripper",
}

# Known OS ProductName → structured info
_OS_NAME_MAP = {
    "windows 10": {"family": "Windows", "generation": "10", "era": "Modern"},
    "windows 11": {"family": "Windows", "generation": "11", "era": "Modern"},
    "windows 7":  {"family": "Windows", "generation": "7",  "era": "Legacy"},
    "windows xp": {"family": "Windows", "generation": "XP", "era": "Legacy"},
    "windows vista": {"family": "Windows", "generation": "Vista", "era": "Legacy"},
    "windows 8":  {"family": "Windows", "generation": "8", "era": "Modern"},
    "windows server 2019": {"family": "Windows Server", "generation": "2019", "era": "Server"},
    "windows server 2016": {"family": "Windows Server", "generation": "2016", "era": "Server"},
    "windows server 2012": {"family": "Windows Server", "generation": "2012", "era": "Server"},
}



def _parse_reg_export(path: Path) -> tuple[bool, list[dict[str, Any]], str]:
    """Parse a Windows .reg text export with exact line provenance."""
    try:
        raw = path.read_bytes()
    except OSError as exc:
        return False, [], str(exc)
    text = ""
    for encoding in ("utf-16", "utf-8-sig", "cp1252"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeError:
            continue
    if not text:
        return False, [], "unsupported text encoding"
    lines = text.splitlines()
    header = next((line.strip() for line in lines if line.strip()), "")
    if not (header.casefold().startswith("windows registry editor version") or header.casefold().startswith("regedit4")):
        return False, [], "missing .reg export header"
    current_key = ""
    values: list[dict[str, Any]] = []
    for line_number, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith(";") or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            current_key = stripped[1:-1]
            continue
        match = re.match(r'(?P<name>@|"(?:[^"\\]|\\.)*")\s*=\s*(?P<data>.*)$', stripped)
        if not match or not current_key:
            continue
        raw_name = match.group("name")
        name = "(Default)" if raw_name == "@" else bytes(raw_name[1:-1], "utf-8").decode("unicode_escape", errors="replace")
        raw_data = match.group("data").strip()
        value_type = "REG_SZ"
        value_data: Any = raw_data
        if raw_data.casefold().startswith("dword:"):
            value_type = "REG_DWORD"
            token = raw_data.split(":", 1)[1]
            try:
                value_data = int(token, 16)
            except ValueError:
                value_data = token
        elif raw_data.casefold().startswith("hex"):
            prefix, _, payload = raw_data.partition(":")
            value_type = "REG_BINARY" if prefix.casefold() == "hex" else f"REG_{prefix.upper()}"
            value_data = payload.replace("\\", "")
        elif len(raw_data) >= 2 and raw_data[0] == raw_data[-1] == '"':
            value_data = bytes(raw_data[1:-1], "utf-8").decode("unicode_escape", errors="replace")
        values.append({
            "key_path": current_key,
            "value_name": name,
            "value_type": value_type,
            "value_data": value_data,
            "line_number": line_number,
            "raw_line": line,
        })
    return True, values, ""


def _registry_container_type(inv: Any, raw: bytes, semantic_parse_succeeded: bool) -> str:
    if semantic_parse_succeeded:
        return "VALID_NATIVE_HIVE"
    lowered = raw.lower()
    if b"synthetic" in lowered or b"training" in lowered:
        return "SYNTHETIC_HIVE_CONTAINER"
    if getattr(inv, "object_type", "") == "registry_hive" and getattr(inv, "deterministic", False):
        return "UNSUPPORTED_HIVE"
    return "CORRUPT_HIVE"

# ---------------------------------------------------------------------------
# run() — module entry point
# ---------------------------------------------------------------------------

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict,
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Extract and analyze Windows Registry hives from a disk image.
    """
    start_time = utc_now()
    wall_start = time.monotonic()

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_STARTED,
                           description=f"Module '{MODULE_NAME}' started",
                           evidence_path=str(evidence_path),
                           metadata={"module": MODULE_NAME})
        except Exception as _e:
            logger.warning("CoC start failed: %s", _e)

    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()
    findings: list[Finding] = []
    errors: list[str] = []
    warnings: list[str] = []
    terminal_lines: list[str] = []

    def tlog(msg: str) -> None:
        logger.info(msg)
        terminal_lines.append(msg)

    if not evidence_path.exists():
        return _fail(MODULE_NAME, case_id, start_time, f"Evidence not found: {evidence_path}",
                     coc_logger, logger)

    # analysis_path: mounted ewf1 (raw) or block device; falls back to evidence_path
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset") if config.get("partition_offset") is not None else 0)
    if partition_offset == 0 and "partition_offset" not in config:
        from core.partition_offset import detect_partition_offset_mounted
        partition_offset = detect_partition_offset_mounted(analysis_path, logger)
    if partition_offset == 0:
        tlog("[REGISTRY] Partition offset is 0 — using context-provided value (partitionless or root filesystem)")
    tlog(f"[REGISTRY] Evidence: {evidence_path.name}  analysis: {analysis_path.name}")
    tlog(f"[REGISTRY] Partition offset: {partition_offset} sectors")
    tlog(f"[REGISTRY] python-registry available: {_REG_AVAILABLE}")

    output_dir.mkdir(parents=True, exist_ok=True)
    hives_dir = output_dir / "hives"
    hives_dir.mkdir(exist_ok=True)

    # Text registry exports are a distinct evidence class and do not require a
    # binary hive parser. They are parsed with exact key/value and line provenance.
    reg_exports: list[dict[str, Any]] = []
    ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
    for candidate in iter_corpus_files(ws, output_dir=output_dir, deduplicate_by_hash=True):
        if candidate.suffix.casefold() != ".reg":
            continue
        valid, values, error = _parse_reg_export(candidate)
        if not valid:
            warnings.append(f"Registry export {candidate.name} was not parsed: {error}")
            continue
        digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
        reg_exports.append({"path": str(candidate), "sha256": digest, "values": values})
        findings.append(make_finding(
            "REGISTRY_EXPORT_PARSED", Severity.INFO,
            f"Text registry export {candidate.name} was deterministically parsed with {len(values)} value record(s).",
            str(candidate), artifact_path=str(candidate), metadata={
                "file_path": str(candidate), "file_sha256": digest,
                "container_type": "TEXT_REGISTRY_EXPORT", "value_count": len(values),
                **deterministic_metadata("Windows .reg grammar and exact line parser", validators=[".reg header", "key/value line parser"]),
            },
        ))
        for value in values:
            findings.append(make_finding(
                "REGISTRY_VALUE_RECORD", Severity.INFO,
                f"Registry value {value['key_path']}\\{value['value_name']} was parsed from line {value['line_number']}.",
                str(candidate), artifact_path=str(candidate), metadata={
                    "file_path": str(candidate), "file_sha256": digest,
                    "container_type": "TEXT_REGISTRY_EXPORT",
                    **value,
                    "source_offset_cluster_packet_or_row": f"line:{value['line_number']}",
                    **deterministic_metadata("Windows .reg value parser", validators=["key path", "value name/type/data", "line number"]),
                },
            ))

    # ── Step 1: fls enumeration ──────────────────────────────────────────────
    tlog("[REGISTRY] Running fls to find registry hives...")
    fls_entries = _run_fls(analysis_path, logger, errors, offset=partition_offset)
    native_scan_used = False
    if not fls_entries:
        ws = config.get("_working_set", {}) if isinstance(config, dict) else {}
        native_root_value = ws.get("extracted_files_dir") or ws.get("mounted_fs_root")
        native_root = Path(native_root_value) if native_root_value else None
        if native_root and native_root.is_dir():
            native_scan_used = True
            for native_file in native_root.rglob("*"):
                if not native_file.is_file():
                    continue
                try:
                    rel = str(native_file.relative_to(native_root)).replace("\\", "/")
                except ValueError:
                    rel = native_file.name
                fls_entries.append({"inode": "", "path": rel, "deleted": False,
                                    "native_source": str(native_file)})
            errors[:] = [e for e in errors if "fls" not in e.lower()]
            warnings.append("Sleuth Kit enumeration unavailable; native extracted filesystem tree was searched for registry hives.")
    tlog(f"[REGISTRY] Filesystem search covered {len(fls_entries)} file entries")

    hive_patterns = [
        ("SAM",      re.compile(r"(?:Windows|WINDOWS)/System32/config/SAM$", re.IGNORECASE)),
        ("SYSTEM",   re.compile(r"(?:Windows|WINDOWS)/System32/config/SYSTEM$", re.IGNORECASE)),
        ("SOFTWARE", re.compile(r"(?:Windows|WINDOWS)/System32/config/SOFTWARE$", re.IGNORECASE)),
        ("SECURITY", re.compile(r"(?:Windows|WINDOWS)/System32/config/SECURITY$", re.IGNORECASE)),
        # Windows XP: Documents and Settings\<user>\NTUSER.DAT
        # Windows Vista+: Users\<user>\NTUSER.DAT
        ("NTUSER",   re.compile(
            r"(?:Documents and Settings|Users)/([^/]+)/NTUSER\.DAT$", re.IGNORECASE)),
        ("USRCLASS", re.compile(
            r"Users/[^/]+/AppData/Local/Microsoft/Windows/UsrClass\.dat$", re.IGNORECASE)),
    ]

    hive_matches: list[dict[str, Any]] = []
    for entry in fls_entries:
        norm = entry["path"].replace("\\", "/")
        for hive_type, pat in hive_patterns:
            if pat.search(norm):
                # Extract username from NTUSER path
                username = ""
                m = re.search(
                    r"(?:Documents and Settings|Users)/([^/]+)/NTUSER\.DAT",
                    norm, re.IGNORECASE,
                )
                if m:
                    username = m.group(1)
                hive_matches.append({
                    "hive_type": hive_type,
                    "path":      entry["path"],
                    "inode":     entry["inode"],
                    "username":  username,
                    "native_source": entry.get("native_source"),
                })
                break

    # Add recursively inventoried REGF containers that may live outside the
    # conventional Windows/System32/config paths. Classification is based on
    # the REGF base block, checksum and HBIN structure, not filename.
    _seen_hive_sources = {str(h.get("native_source") or "") for h in hive_matches}
    for value in config.get("registry_hive_paths") or []:
        source = Path(str(value))
        if not source.is_file() or str(source) in _seen_hive_sources:
            continue
        hive_matches.append({
            "hive_type": source.name.upper() if source.name else "REGF",
            "path": str(source), "inode": "", "username": "",
            "native_source": str(source),
        })
        _seen_hive_sources.add(str(source))

    # Collapse byte-identical hives discovered through multiple roots or both
    # FLS and recursive inventory. Alternate locations remain aliases rather
    # than being parsed and counted as independent hives.
    deduped_hives: list[dict[str, Any]] = []
    hive_by_key: dict[str, dict[str, Any]] = {}
    for hm in hive_matches:
        source = Path(str(hm.get("native_source") or ""))
        digest = ""
        if source.is_file():
            try:
                digest = hashlib.sha256(source.read_bytes()).hexdigest()
            except OSError:
                digest = ""
        key = f"sha256:{digest}" if digest else f"logical:{str(hm.get('path') or '').casefold()}"
        existing = hive_by_key.get(key)
        if existing is None:
            hm["aliases"] = []
            hm["sha256"] = digest
            hive_by_key[key] = hm
            deduped_hives.append(hm)
        else:
            alias = str(hm.get("path") or hm.get("native_source") or "")
            if alias and alias != str(existing.get("path") or ""):
                existing.setdefault("aliases", []).append(alias)
    hive_matches = deduped_hives

    tlog(f"[REGISTRY] Found {len(hive_matches)} registry hive path candidate(s): "
         + ", ".join(f"{h['hive_type']}({h.get('username','') or 'system'})" for h in hive_matches))

    # ── Step 2: Extract hive files ───────────────────────────────────────────
    extracted_hives: list[dict[str, Any]] = []
    for hm in hive_matches:
        safe_name = re.sub(r"[^A-Za-z0-9_.\-]", "_", Path(hm["path"]).name)
        if hm["username"]:
            safe_name = f"{hm['username']}_{safe_name}"
        dest = hives_dir / safe_name
        if not dest.exists():
            if hm.get("native_source"):
                try:
                    shutil.copy2(Path(hm["native_source"]), dest)
                    err = None
                except OSError as exc:
                    err = str(exc)
            else:
                dest, err = _icat_extract(analysis_path, hm["inode"], dest, logger,
                                           offset=partition_offset)
            if err:
                errors.append(f"Registry hive extraction failed for {hm['path']}: {err}")
                tlog(f"[REGISTRY] FAILED to extract {hm['path']}: {err}")
                continue
        tlog(f"[REGISTRY] Extracted {hm['hive_type']} → {dest.name} ({dest.stat().st_size} bytes)")
        hm["local_path"] = str(dest)
        extracted_hives.append(hm)

    # De-duplicate again after extraction.  Different discovery paths or
    # materialised copies can point to the same exact hive byte stream.  Parse
    # each SHA-256 once and retain every alternate logical/source path as an
    # alias so counts are evidence counts, not extraction-path counts.
    _unique_extracted: list[dict[str, Any]] = []
    _by_extracted_hash: dict[str, dict[str, Any]] = {}
    for hm in extracted_hives:
        local = Path(str(hm.get("local_path") or ""))
        try:
            digest = hashlib.sha256(local.read_bytes()).hexdigest()
        except OSError:
            digest = "path:" + str(local)
        prior = _by_extracted_hash.get(digest)
        if prior is None:
            hm["sha256"] = digest if not digest.startswith("path:") else ""
            hm.setdefault("aliases", [])
            _by_extracted_hash[digest] = hm
            _unique_extracted.append(hm)
        else:
            for alias in (str(hm.get("path") or ""), str(hm.get("native_source") or ""), str(hm.get("local_path") or "")):
                if alias and alias not in prior.setdefault("aliases", []):
                    prior["aliases"].append(alias)
    duplicate_hive_alias_count = len(extracted_hives) - len(_unique_extracted)
    extracted_hives = _unique_extracted
    hive_matches = extracted_hives
    tlog(
        f"[REGISTRY] Retained {len(extracted_hives)} unique hive byte stream(s) "
        f"with {duplicate_hive_alias_count} duplicate alias(es)."
    )

    # Every structurally valid REGF container is itself a deterministic
    # finding, even when a dedicated registry library cannot parse complete
    # key/value cell semantics. Embedded strings are retained as exact bytes
    # without claiming that they represent normal key/value placement.
    for hm in extracted_hives:
        local = Path(str(hm.get("local_path") or ""))
        try:
            inv = classify_file(local)
        except Exception:
            continue
        if inv.object_type != "registry_hive" or not inv.deterministic:
            continue
        raw = local.read_bytes()
        ascii_runs = sorted(set(
            m.group(0).decode("ascii", errors="ignore")
            for m in re.finditer(rb"[ -~]{6,}", raw)
        ))
        utf16_runs = sorted(set(
            m.group(0).decode("utf-16le", errors="ignore")
            for m in re.finditer(rb"(?:[ -~]\x00){6,}", raw)
        ))
        container_type = _registry_container_type(inv, raw, semantic_parse_succeeded=False)
        findings.append(make_finding(
            finding_type="REGISTRY_HIVE_CONTAINER", severity=Severity.INFO,
            description=(
                f"A REGF container was structurally validated at {hm['path']} and classified as {container_type}. "
                "Key/value semantics are reported separately only when a cell parser succeeds."
            ),
            evidence_path=str(hm["path"]), artifact_path=str(local),
            metadata={
                **deterministic_metadata(
                    "REGF base-block checksum/sequence/HBIN structural validation",
                    validators=["evidence_inventory.registry_baseblock"],
                ),
                "file_path": str(local), "logical_path": str(hm["path"]),
                "aliases": list(hm.get("aliases") or []),
                "file_sha256": inv.sha256, "structure": inv.metadata,
                "container_type": container_type,
                "semantic_parse_status": "NOT_YET_CONFIRMED",
                "embedded_ascii_strings": ascii_runs,
                "embedded_utf16le_strings": utf16_runs,
                "semantic_limit": "String presence does not establish key/value cell semantics",
            },
        ))

    # ── Step 3: Parse each hive ──────────────────────────────────────────────
    results: dict[str, Any] = {
        "user_accounts":    [],
        "deleted_accounts": [],
        "os_info":          {},
        "cover_accounts":   [],
        "usb_devices":      [],
        "network_shares":   [],
        "userassist":       {},
        "recentdocs":       {},
        "opensavemru":      {},
        "typedurlsmru":     [],
        "shellbags":        [],
        "installed_programs": [],
        "suspicious_software": [],
        "prefetch_empty":   False,
        "computer_name":    "",
        "timezone":         "",
        "hives_parsed":     [],
    }

    sam_hives   = [h for h in extracted_hives if h["hive_type"] == "SAM"]
    sys_hives   = [h for h in extracted_hives if h["hive_type"] == "SYSTEM"]
    soft_hives  = [h for h in extracted_hives if h["hive_type"] == "SOFTWARE"]
    ntuser_hives = [h for h in extracted_hives if h["hive_type"] == "NTUSER"]

    for hm in sam_hives:
        tlog(f"[REGISTRY] Parsing SAM hive: {hm['local_path']}")
        parsed = _parse_sam(Path(hm["local_path"]), logger)
        results["user_accounts"].extend(parsed.get("accounts", []))
        _deleted = parsed.get("deleted_accounts", [])
        results.setdefault("deleted_accounts", []).extend(_deleted)
        results["hives_parsed"].append("SAM")
        findings.extend(_findings_from_sam(parsed, hm["path"]))
        tlog(f"[REGISTRY] SAM: {len(parsed.get('accounts', []))} accounts found, "
             f"{len(_deleted)} deleted account(s) recovered")

    for hm in sys_hives:
        tlog(f"[REGISTRY] Parsing SYSTEM hive: {hm['local_path']}")
        parsed = _parse_system(Path(hm["local_path"]), logger)
        results["usb_devices"].extend(parsed.get("usb_devices", []))
        results["network_shares"].extend(parsed.get("network_shares", []))
        results["computer_name"] = parsed.get("computer_name", "")
        results["timezone"] = parsed.get("timezone", "")
        results["hives_parsed"].append("SYSTEM")
        findings.extend(_findings_from_system(parsed, hm["path"]))
        tlog(f"[REGISTRY] SYSTEM: {len(parsed.get('usb_devices',[]))} USB devices, "
             f"computer={parsed.get('computer_name','')}")

    for hm in soft_hives:
        tlog(f"[REGISTRY] Parsing SOFTWARE hive: {hm['local_path']}")
        parsed = _parse_software(Path(hm["local_path"]), logger)
        results["os_info"] = parsed.get("os_info", {})
        results["installed_programs"] = parsed.get("installed", [])
        results["suspicious_software"] = parsed.get("suspicious", [])
        results["hives_parsed"].append("SOFTWARE")
        findings.extend(_findings_from_software(parsed, hm["path"]))
        tlog(f"[REGISTRY] SOFTWARE: OS={parsed.get('os_info',{}).get('ProductName','?')}, "
             f"{len(parsed.get('installed',[]))} programs, "
             f"{len(parsed.get('suspicious',[]))} suspicious")

    # Per-user profile signals used to corroborate cover-account pairing:
    # profile size and a content hash of the NTUSER.DAT, both discovered at
    # runtime.  Template-cloned cover accounts share an identical (often empty)
    # profile; genuine distinct users do not.
    profile_signals: dict[str, dict] = {}
    for hm in ntuser_hives:
        uname = hm.get("username", "unknown")
        tlog(f"[REGISTRY] Parsing NTUSER.DAT for user: {uname}")
        parsed = _parse_ntuser(Path(hm["local_path"]), logger)
        # Record exact profile-hive size.  Size alone cannot establish that an
        # account is unused, deceptive, or a "cover" identity.
        _ntuser_size = Path(hm["local_path"]).stat().st_size
        try:
            _ntuser_hash = hashlib.sha256(
                Path(hm["local_path"]).read_bytes()
            ).hexdigest()
        except OSError:
            _ntuser_hash = ""
        profile_signals[uname] = {
            "ntuser_size_bytes": _ntuser_size,
            "ntuser_sha256": _ntuser_hash,
        }
        if _ntuser_size < 8192:
            findings.append(make_finding(
                "SMALL_REGISTRY_HIVE_CONTAINER", Severity.INFO,
                f"The NTUSER.DAT associated with '{uname}' is {_ntuser_size:,} bytes, "
                "below the configured 8 KiB review threshold. This is an exact size "
                "observation only; usage history, account purpose and identity are not inferred.",
                hm["path"],
                {
                    "username": uname, "ntuser_size_bytes": _ntuser_size,
                    "review_threshold_bytes": 8192,
                    **deterministic_metadata(
                        "exact retained file-size comparison",
                        validators=["filesystem stat", "integer threshold comparison"],
                        semantic_limit="Size anomaly only; no cover-account or usage conclusion.",
                    ),
                },
            ))
            tlog(f"[REGISTRY] SMALL HIVE: {uname} — NTUSER.DAT {_ntuser_size} bytes")
        ua = parsed.get("userassist", {})
        if ua:
            results["userassist"][uname] = ua
        rd = parsed.get("recentdocs", {})
        if rd:
            results["recentdocs"][uname] = rd
        osmru = parsed.get("opensavemru", {})
        if osmru:
            results["opensavemru"][uname] = osmru
        turls = parsed.get("typedurlsmru", [])
        if turls:
            results["typedurlsmru"].extend(turls)
        sbags = parsed.get("shellbags", [])
        if sbags:
            results["shellbags"].extend(sbags)
        results["hives_parsed"].append(f"NTUSER({uname})")
        findings.extend(_findings_from_ntuser(parsed, hm["path"], uname))
        tlog(f"[REGISTRY] NTUSER({uname}): "
             f"userassist={len(ua)}, recentdocs={len(rd)}, "
             f"shellbags={len(sbags)}, typedurlsmru={len(turls)}")

    # ── Cover account detection ──────────────────────────────────────────────
    cover_accounts = _detect_cover_accounts(results["user_accounts"], profile_signals)
    results["cover_accounts"] = cover_accounts
    for ca in cover_accounts:
        findings.insert(0, make_finding(
            finding_type="ACCOUNT_CREATION_PROXIMITY_PROFILE_SIMILARITY",
            severity=Severity.INFO,
            description=(
                f"Accounts '{ca['account_a']}' and '{ca['account_b']}' have retained "
                f"timestamps {ca['delta_seconds']:.0f} seconds apart and share the exact "
                f"profile signal '{ca['corroboration']}'. This records temporal/profile "
                "similarity only; it does not establish a cover account, common operator, "
                "deception, or intent."
            ),
            evidence_path="SAM/NTUSER registry evidence",
            metadata={
                "account_a": ca["account_a"], "account_b": ca["account_b"],
                "delta_seconds": ca["delta_seconds"],
                "corroboration": ca["corroboration"],
                **deterministic_metadata(
                    "exact timestamp difference and profile-signal equality",
                    validators=["registry timestamp parser", "SHA-256/size equality", "built-in account exclusion"],
                    semantic_limit="Similarity observation only; account purpose and identity remain indeterminate.",
                ),
            },
        ))
    if cover_accounts:
        tlog(f"[REGISTRY] CRITICAL: {len(cover_accounts)} cover account pair(s) detected!")

    # ── Step 3b: Generate screenshots ───────────────────────────────────────
    try:
        from modules.screenshot_capture import capture_terminal, capture_table, record_screenshot
        sc_dir = output_dir / "screenshots"
        sc_dir.mkdir(exist_ok=True)
        sc_idx = sc_dir / "screenshots_index.json"

        # Fig 4.1 — fls terminal output
        fls_text = "\n".join(terminal_lines[:80])
        png = capture_terminal("fls registry hive enumeration", fls_text,
                               sc_dir, "fig_4_1",
                               "Fig 4.1: registry-hive search output")
        if png:
            record_screenshot(sc_idx, "fig_4_1", png,
                              "Fig 4.1: registry-hive search output")

        # Fig 4.2 — User accounts (SAM hive).  Columns are labelled by the field
        # actually parsed: the SAM key last-write time (not account creation),
        # and the last-login time; deleted records are marked as such.
        def _acct_row(a: dict) -> list[str]:
            state = "DELETED" if a.get("deleted") else "live"
            return [
                a.get("username", "?"),
                str(a.get("rid", "?")),
                str(a.get("creation_time") or "N/A")[:19],
                str(a.get("last_write") or "N/A")[:19],
                str(a.get("last_login") or "N/A")[:19],
                state,
            ]
        ua_rows = [_acct_row(a) for a in results["user_accounts"][:20]]
        ua_rows += [_acct_row(a) for a in results.get("deleted_accounts", [])[:20]]
        if ua_rows:
            png = capture_table("User Account Profile — SAM Hive",
                                ["Username", "RID", "Account Created",
                                 "SAM Key Last-Write", "Last Login", "State"],
                                ua_rows, sc_dir, "fig_4_2",
                                "Fig 4.2: SAM hive user account profile "
                                "(key last-write vs last login; deleted records included)")
            if png:
                record_screenshot(sc_idx, "fig_4_2", png,
                                  "Fig 4.2: SAM hive user account profile")

        # Fig 4.3 — Cover accounts (if any)
        if cover_accounts:
            ca_rows = [[ca.get("account_a","?"), ca.get("account_b","?"),
                        f"{ca.get('delta_seconds',0):.0f}s",
                        "CRITICAL — Cover Account"]
                       for ca in cover_accounts[:10]]
            png = capture_table("Cover Account Detection",
                                ["Account A", "Account B", "Delta (sec)", "Verdict"],
                                ca_rows, sc_dir, "fig_4_3",
                                "Fig 4.3: Cover accounts created within 120 seconds")
            if png:
                record_screenshot(sc_idx, "fig_4_3", png,
                                  "Fig 4.3: Cover accounts created within 120 seconds")

        # Fig 4.4 — USB devices (USBSTOR)
        usb_rows = [[u.get("device_class","?")[:25], u.get("instance_id","?")[:35],
                     u.get("friendly_name","?")[:40], u.get("last_connected","N/A")[:19]]
                    for u in results["usb_devices"][:20]]
        if usb_rows:
            png = capture_table("USBSTOR Device History — SYSTEM Hive",
                                ["Class", "Instance ID", "Friendly Name", "Last Connected"],
                                usb_rows, sc_dir, "fig_4_4",
                                "Fig 4.4: USBSTOR USB device connection history")
            if png:
                record_screenshot(sc_idx, "fig_4_4", png,
                                  "Fig 4.4: USBSTOR USB device connection history")

        # Fig 4.5 — Installed programs (SOFTWARE hive)
        prog_rows = [[p.get("displayname") or p.get("key_name","?"),
                      str(p.get("displayversion","?"))[:20],
                      str(p.get("publisher","?"))[:35],
                      str(p.get("install_date","N/A"))[:12]]
                     for p in results["installed_programs"][:30]]
        if prog_rows:
            png = capture_table("Installed Programs — SOFTWARE Hive",
                                ["Program Name", "Version", "Publisher", "Install Date"],
                                prog_rows, sc_dir, "fig_4_5",
                                "Fig 4.5: Installed programs list from SOFTWARE hive")
            if png:
                record_screenshot(sc_idx, "fig_4_5", png,
                                  "Fig 4.5: Installed programs list from SOFTWARE hive")

        # Fig 4.6 — Suspicious software
        if results["suspicious_software"]:
            susp_rows = [[p.get("displayname") or p.get("key_name","?"),
                          str(p.get("publisher","?"))[:35],
                          "ANTI-FORENSIC TOOL"]
                         for p in results["suspicious_software"][:20]]
            png = capture_table("Suspicious / Anti-Forensic Software",
                                ["Program Name", "Publisher", "Verdict"],
                                susp_rows, sc_dir, "fig_4_6",
                                "Fig 4.6: Anti-forensic or wiping tools detected")
            if png:
                record_screenshot(sc_idx, "fig_4_6", png,
                                  "Fig 4.6: Anti-forensic or wiping tools detected")

        # Fig 4.7 — UserAssist (per user)
        ua_fig = 7
        for uname, ua_data in list(results["userassist"].items())[:3]:
            if not isinstance(ua_data, dict):
                continue
            ua_app_rows = [[k[:60], str(v.get("run_count","?") if isinstance(v, dict) else v)]
                           for k, v in list(ua_data.items())[:25]]
            if ua_app_rows:
                fid = f"fig_4_{ua_fig}"
                cap = f"Fig 4.{ua_fig}: UserAssist execution history for user '{uname}'"
                png = capture_table(f"UserAssist — {uname}",
                                    ["Application Path", "Run Count"],
                                    ua_app_rows, sc_dir, fid, cap)
                if png:
                    record_screenshot(sc_idx, fid, png, cap)
                ua_fig += 1

        # Fig 4.10 — RecentDocs (per user)
        rd_fig = 10
        for uname, rd_data in list(results["recentdocs"].items())[:2]:
            if not isinstance(rd_data, dict):
                continue
            rd_rows: list[list[str]] = []
            for ext, docs in list(rd_data.items())[:10]:
                for doc in (docs[:5] if isinstance(docs, list) else []):
                    rd_rows.append([uname, str(ext), str(doc)[:80]])
            if rd_rows:
                fid = f"fig_4_{rd_fig}"
                cap = f"Fig 4.{rd_fig}: RecentDocs for user '{uname}'"
                png = capture_table(f"RecentDocs — {uname}",
                                    ["User", "Extension", "Document"],
                                    rd_rows, sc_dir, fid, cap)
                if png:
                    record_screenshot(sc_idx, fid, png, cap)
                rd_fig += 1

        tlog(f"[REGISTRY] Screenshots saved to {sc_dir}")
    except Exception as _sc_exc:
        logger.warning("[REGISTRY] Screenshot capture failed: %s", _sc_exc)

    # ── Step 4: Write manifest ───────────────────────────────────────────────
    manifest = {
        "module":       MODULE_NAME,
        "case_id":      case_id,
        "generated_at": utc_now(),
        "hives_found":  len(hive_matches),
        "hives_extracted": len(extracted_hives),
        "duplicate_hive_aliases": duplicate_hive_alias_count,
        "hives_parsed": results["hives_parsed"],
        "registry_exports": reg_exports,
        "registry_export_count": len(reg_exports),
        "findings_count": len(findings),
        "results":      results,
        "warnings":     warnings,
        "errors":       errors,
    }
    manifest_path = output_dir / "registry_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")

    terminal_output = "\n".join(terminal_lines)
    (output_dir / "terminal_output.txt").write_text(terminal_output, encoding="utf-8")

    wall_elapsed = time.monotonic() - wall_start
    tlog(f"[REGISTRY] Completed in {wall_elapsed:.1f}s — {len(findings)} findings")

    if not hive_matches and not reg_exports:
        status = ModuleStatus.NOT_APPLICABLE
        summary = (
            "NOT APPLICABLE — NO WINDOWS REGISTRY CORPUS. No binary hive or text registry export was identified."
        )
    else:
        status = (ModuleStatus.COMPLETED if not errors
                  else ModuleStatus.PARTIAL if extracted_hives
                  else ModuleStatus.SKIPPED)
        summary = (
            f"Parsed {len(extracted_hives)} unique registry hive byte stream(s) ({duplicate_hive_alias_count} duplicate alias(es)). "
            f"{len(results['user_accounts'])} user accounts, "
            f"{len(results['usb_devices'])} USB devices, "
            f"{len(results['installed_programs'])} installed programs, "
            f"{len(cover_accounts)} cover account pair(s), {len(reg_exports)} text registry export(s). "
            f"{len(findings)} findings."
        )

    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(
                EventType.MODULE_COMPLETED if status != ModuleStatus.FAILED else EventType.MODULE_FAILED,
                description=f"Module '{MODULE_NAME}' finished: {summary}",
                evidence_path=str(evidence_path),
                metadata={"module": MODULE_NAME, "status": status.value,
                           "findings": len(findings), "duration_sec": round(wall_elapsed, 2)},
            )
        except Exception as _e:
            logger.warning("CoC end failed: %s", _e)

    if not hive_matches and not reg_exports:
        _reg_verdict   = AssuranceVerdict.INDETERMINATE
        _reg_skip      = SkipReason.NO_CORPUS
    elif not _REG_AVAILABLE and not extracted_hives:
        _reg_verdict   = AssuranceVerdict.INDETERMINATE
        _reg_skip      = SkipReason.DEPENDENCY_MISSING
    elif len(findings) > 0:
        _reg_verdict   = AssuranceVerdict.PRESENT
        _reg_skip      = None
    elif extracted_hives and _REG_AVAILABLE:
        _reg_verdict   = AssuranceVerdict.VERIFIED_ABSENT
        _reg_skip      = None
    elif extracted_hives:
        _reg_verdict   = AssuranceVerdict.INDETERMINATE
        _reg_skip      = SkipReason.LAYER2_UNVERIFIED
    else:
        _reg_verdict   = AssuranceVerdict.INDETERMINATE
        _reg_skip      = SkipReason.PARTIAL_FAILURE

    _reg_cr = ClassResult(
        locus=Locus.REGISTRY,
        artefact_class="Windows Registry Artefacts",
        verdict=_reg_verdict,
        skip_reason=_reg_skip,
        count=len(findings),
        notes=(summary if _reg_skip == SkipReason.NO_CORPUS else "; ".join((errors or warnings)[:3])),
    )

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=utc_now(),
        duration_seconds=round(wall_elapsed, 2),
        findings=findings,
        artifact_paths=[str(manifest_path)],
        errors=errors,
        statistics={
            "hives_found":    len(hive_matches),
            "registry_exports": len(reg_exports),
            "hives_extracted": len(extracted_hives),
            "duplicate_hive_aliases": duplicate_hive_alias_count,
            "sources_discovered": len(hive_matches) + len(reg_exports),
            "sources_processed": len(extracted_hives) + len(reg_exports),
            "supported_objects_discovered": len(hive_matches) + len(reg_exports),
            "supported_objects_processed": len(extracted_hives) + len(reg_exports),
            "unresolved_supported_objects": max(0, len(hive_matches) - len(extracted_hives)),
            # Duplicate byte streams are retained only as aliases above; no
            # duplicate primary registry finding remains in this result.
            "duplicate_primary_records": 0,
            "user_accounts":  len(results["user_accounts"]),
            "usb_devices":    len(results["usb_devices"]),
            "installed_programs": len(results["installed_programs"]),
            "cover_accounts": len(cover_accounts),
            "findings":       len(findings),
            "warnings":       warnings,
            "execution_outcome": ("did_not_run" if status == ModuleStatus.SKIPPED else
                                  "ran_found_x" if findings else "ran_found_nothing"),
            "not_applicable_reason": (summary if status == ModuleStatus.SKIPPED else ""),
        },
        summary=summary,
        class_results=[_reg_cr],
    )


# ---------------------------------------------------------------------------
# fls / icat helpers
# ---------------------------------------------------------------------------

def _run_fls(analysis_path: Path,
             logger: logging.Logger, errors: list,
             offset: int = 0) -> list[dict]:
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset > 0 else []
    cmd = _sudo + ["fls", "-r", "-p"] + off + [str(analysis_path)]
    try:
        rc, stdout, stderr = _run_subprocess(cmd, FLS_TIMEOUT, logger)
    except FileNotFoundError:
        errors.append("fls not found — install sleuthkit")
        return []
    except Exception as exc:
        errors.append(f"fls error: {exc}")
        return []

    if rc == -11 or (rc != 0 and "partition" in (stderr or "").lower()):
        errors.append(
            f"TSK exit {rc} — partition offset {offset} wrong. Run mmls to find correct offset."
        )
        return []

    entries: list[dict] = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        m = re.match(r"^([a-zA-Z/\-]+)\s+(\*?)\s*(\d+(?:-\d+)*):\s+(.+)$", line)
        if m:
            deleted = bool(m.group(2))
            inode   = m.group(3).split("-")[0]
            path_str = m.group(4).strip()
            entries.append({"inode": inode, "path": path_str, "deleted": deleted})
    return entries


def _icat_extract(analysis_path: Path, inode: str,
                  dest: Path, logger: logging.Logger,
                  offset: int = 0) -> tuple[Path, str | None]:
    import subprocess as _subprocess
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset > 0 else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]
    logger.debug("icat cmd: %s", " ".join(cmd))
    try:
        result = _subprocess.run(
            cmd, capture_output=True, timeout=ICAT_TIMEOUT, shell=False
        )
    except FileNotFoundError:
        return dest, "icat not found"
    except _subprocess.TimeoutExpired:
        return dest, f"icat timed out after {ICAT_TIMEOUT}s"
    except Exception as exc:
        return dest, str(exc)
    if result.returncode != 0 or not result.stdout:
        stderr_txt = result.stderr.decode("utf-8", errors="replace")[:200]
        return dest, f"icat rc={result.returncode}: {stderr_txt}"
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(result.stdout)
    except Exception as exc:
        return dest, str(exc)
    return dest, None


# ---------------------------------------------------------------------------
# SAM parser
# ---------------------------------------------------------------------------

def _deleted_sam_accounts(path: Path, live_rids: set, logger: logging.Logger) -> list[dict]:
    """Recover deleted SAM accounts from unallocated hive cells (raw scan).

    Runs regardless of which parser handled the live accounts, since the
    python-registry API does not expose deleted keys.  Returns [] on any error.
    """
    try:
        data = path.read_bytes()
        if len(data) < 4096 or data[:4] != b"regf":
            return []
        return _RegfParser(data).extract_deleted_sam_users(live_rids)
    except Exception as exc:
        logger.warning("[REGISTRY] deleted SAM scan failed: %s", exc)
        return []


def _parse_sam(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """Parse SAM hive for local user accounts (live and recoverable deleted)."""
    result: dict[str, Any] = {"accounts": [], "deleted_accounts": [], "parse_status": "ok"}

    if _REGISTRY_OK:
        try:
            reg = _open_hive(path)
            # python-registry API: reg.open() navigates from the hive root by path.
            # root.find_subkey() does not exist in this library — it raises AttributeError.
            names_key = None
            for _key_path in (
                "SAM\\Domains\\Account\\Users\\Names",
                "Domains\\Account\\Users\\Names",
            ):
                try:
                    names_key = reg.open(_key_path)
                    break
                except Exception:
                    continue
            if names_key:
                for sub in names_key.subkeys():
                    # A registry key timestamp is its LAST-WRITE time, not its
                    # creation time; label it as such and leave creation unset
                    # unless a genuine creation source is available.
                    _key_lw = None
                    try:
                        kt = sub.timestamp()
                        if kt:
                            _key_lw = kt.isoformat()
                    except Exception:
                        pass
                    account: dict[str, Any] = {
                        "username": sub.name(),
                        "creation_time": None,
                        "last_write": _key_lw,
                        "last_login": None,
                        "rid": None,
                        "deleted": False,
                    }
                    try:
                        # Under Users\Names\<user>, the RID is encoded as the type
                        # field of the subkey's default value (SAM on-disk layout).
                        for _v in sub.values():
                            if _v.name() in ("", "(default)"):
                                account["rid"] = int(_v.value_type())
                                break
                    except Exception:
                        pass
                    result["accounts"].append(account)
                result["parse_status"] = "ok_python_registry"
                # Deleted-record recovery always runs via the raw scanner, since
                # python-registry does not expose unallocated (deleted) keys.
                _live_rids = {a["rid"] for a in result["accounts"] if a.get("rid")}
                result["deleted_accounts"] = _deleted_sam_accounts(path, _live_rids, logger)
                return result
        except Exception as exc:
            logger.warning("python-registry SAM failed: %s", exc)

    # Fallback: check for REGF magic
    try:
        data = path.read_bytes()
        if len(data) < 4096 or data[:4] != b"regf":
            result["parse_status"] = "invalid_magic"
            return result
        parser = _RegfParser(data)
        result["accounts"] = parser.extract_sam_users()
        _live_rids = {a["rid"] for a in result["accounts"] if a.get("rid")}
        result["deleted_accounts"] = parser.extract_deleted_sam_users(_live_rids)
        result["parse_status"] = "ok_raw"
    except Exception as exc:
        result["parse_status"] = "error"
        result["error"] = str(exc)
    return result


# ---------------------------------------------------------------------------
# Control set resolver
# ---------------------------------------------------------------------------

def _resolve_control_set(reg) -> str:
    """Return the correct ControlSetXXX key name for an offline hive.

    Reads SYSTEM\\Select\\Current to find the active control set number.
    Falls back to brute-forcing ControlSet001/002/003 if Select is absent.
    Last resort: returns 'CurrentControlSet' (may fail on offline hives).
    """
    for select_path in ("Select", "SYSTEM\\Select"):
        try:
            select_key = reg.open(select_path)
            current_val = select_key.value("Current").value()
            cs_name = f"ControlSet{int(current_val):03d}"
            reg.open(cs_name)   # verify it exists
            return cs_name
        except Exception:
            pass
    for cs in ("ControlSet001", "ControlSet002", "ControlSet003"):
        try:
            reg.open(cs)
            return cs
        except Exception:
            pass
    return "CurrentControlSet"


# ---------------------------------------------------------------------------
# SYSTEM parser
# ---------------------------------------------------------------------------

def _parse_system(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """Parse SYSTEM hive for USB history, network shares, computer name, timezone."""
    result: dict[str, Any] = {
        "usb_devices": [], "network_shares": [],
        "computer_name": "", "timezone": "",
        "parse_status": "ok",
    }

    if _REGISTRY_OK:
        try:
            reg = _open_hive(path)
            cs = _resolve_control_set(reg)

            try:
                cn_key = reg.open(f"{cs}\\Control\\ComputerName\\ComputerName")
                result["computer_name"] = str(cn_key.value("ComputerName").value())
            except Exception:
                pass

            try:
                tz_key = reg.open(f"{cs}\\Control\\TimeZoneInformation")
                for val_name in ("TimeZoneKeyName", "StandardName"):
                    try:
                        result["timezone"] = str(tz_key.value(val_name).value())
                        break
                    except Exception:
                        pass
            except Exception:
                pass

            try:
                usb_key = reg.open(f"{cs}\\Enum\\USBSTOR")
                for dev_class_key in usb_key.subkeys():
                    for instance_key in dev_class_key.subkeys():
                        device: dict[str, Any] = {
                            "class":       dev_class_key.name(),
                            "instance_id": instance_key.name(),
                            "friendly_name": "",
                        }
                        for _val_name in ("FriendlyName", "DeviceDesc"):
                            try:
                                device["friendly_name"] = str(instance_key.value(_val_name).value())
                                break
                            except Exception:
                                pass
                        result["usb_devices"].append(device)
            except Exception:
                pass

            try:
                shares_key = reg.open(f"{cs}\\Services\\LanmanServer\\Shares")
                for val in shares_key.values():
                    result["network_shares"].append({
                        "name": val.name(),
                        "path": str(val.value()),
                    })
            except Exception:
                pass

            result["parse_status"] = "ok_python_registry"
            return result
        except Exception as exc:
            logger.warning("python-registry SYSTEM failed: %s — falling back to raw parser", exc)

    try:
        data = path.read_bytes()
        if len(data) < 4096 or data[:4] != b"regf":
            result["parse_status"] = "invalid_magic"
            return result
        parser = _RegfParser(data)
        result["usb_devices"]    = parser.extract_usb_history()
        result["computer_name"]  = parser.extract_computer_name()
        result["timezone"]       = parser.extract_timezone()
        result["network_shares"] = parser.extract_network_shares()
        result["parse_status"]   = "ok_raw"
    except Exception as exc:
        result["parse_status"] = "error"
        result["error"] = str(exc)
    return result


# ---------------------------------------------------------------------------
# SOFTWARE parser
# ---------------------------------------------------------------------------

def _parse_software(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """Parse SOFTWARE hive for OS info and installed programs."""
    result: dict[str, Any] = {
        "os_info": {}, "installed": [], "suspicious": [],
        "parse_status": "ok",
    }

    if _REGISTRY_OK:
        try:
            reg = _open_hive(path)

            for os_key_path in (
                "Microsoft\\Windows NT\\CurrentVersion",
                "Microsoft\\Windows\\CurrentVersion",
            ):
                try:
                    nt_key = reg.open(os_key_path)
                    for val_name in ("ProductName", "CurrentVersion", "CurrentBuild",
                                     "RegisteredOwner", "RegisteredOrganization",
                                     "InstallDate", "CSDVersion", "EditionID", "UBR"):
                        try:
                            result["os_info"][val_name] = str(nt_key.value(val_name).value())
                        except Exception:
                            pass
                    if result["os_info"]:
                        break
                except Exception:
                    pass

            for uninst_path in (
                "Microsoft\\Windows\\CurrentVersion\\Uninstall",
                "Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall",
            ):
                try:
                    uninst_key = reg.open(uninst_path)
                    for prog_key in uninst_key.subkeys():
                        prog: dict[str, Any] = {
                            "key_name":       prog_key.name(),
                            "displayname":    "",
                            "displayversion": "",
                            "publisher":      "",
                            "install_date":   "",
                            "installlocation": "",
                        }
                        for val_name, field in (
                            ("DisplayName",     "displayname"),
                            ("DisplayVersion",  "displayversion"),
                            ("Publisher",       "publisher"),
                            ("InstallDate",     "install_date"),
                            ("InstallLocation", "installlocation"),
                        ):
                            try:
                                prog[field] = str(prog_key.value(val_name).value())
                            except Exception:
                                pass
                        prog["name"]    = prog["displayname"] or prog["key_name"]
                        prog["version"] = prog["displayversion"]
                        result["installed"].append(prog)
                except Exception:
                    pass

            result["suspicious"] = [
                prog for prog in result["installed"]
                if any(s in (prog.get("displayname") or prog.get("key_name") or "").lower()
                       for s in _SUSPICIOUS_TOOLS)
            ]
            result["parse_status"] = "ok_python_registry"
            return result
        except Exception as exc:
            logger.warning("python-registry SOFTWARE failed: %s — falling back to raw parser", exc)

    try:
        data = path.read_bytes()
        if len(data) < 4096 or data[:4] != b"regf":
            result["parse_status"] = "invalid_magic"
            return result
        parser = _RegfParser(data)
        result["os_info"]   = parser.extract_os_info()
        result["installed"] = parser.extract_installed_software()
        result["suspicious"] = [
            prog for prog in result["installed"]
            if any(s in (prog.get("displayname") or prog.get("key_name") or "").lower()
                   for s in _SUSPICIOUS_TOOLS)
        ]
        result["parse_status"] = "ok_raw"
    except Exception as exc:
        result["parse_status"] = "error"
        result["error"] = str(exc)
    return result


# ---------------------------------------------------------------------------
# NTUSER.DAT parser
# ---------------------------------------------------------------------------

def _parse_ntuser(path: Path, logger: logging.Logger) -> dict[str, Any]:
    """Parse NTUSER.DAT for UserAssist, RecentDocs, OpenSaveMRU, TypedURLs, ShellBags."""
    result: dict[str, Any] = {
        "userassist": {}, "recentdocs": {}, "opensavemru": {},
        "typedurlsmru": [], "shellbags": [], "parse_status": "ok",
    }

    if _REGISTRY_OK:
        try:
            reg = _open_hive(path)

            # UserAssist — ROT-13 encoded value names under each GUID subkey
            try:
                ua_base = reg.open(
                    "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\UserAssist"
                )
                for guid_key in ua_base.subkeys():
                    try:
                        count_key = None
                        for sk in guid_key.subkeys():
                            if sk.name().upper() == "COUNT":
                                count_key = sk
                                break
                        if not count_key:
                            continue
                        entries: dict = {}
                        for val in count_key.values():
                            enc = val.name()
                            decoded = "".join(
                                chr(ord(c) + 13) if 'a' <= c <= 'm' or 'A' <= c <= 'M'
                                else chr(ord(c) - 13) if 'n' <= c <= 'z' or 'N' <= c <= 'Z'
                                else c for c in enc
                            )
                            raw_data = val.value()
                            run_count = 0
                            last_run = None
                            if isinstance(raw_data, bytes) and len(raw_data) >= 8:
                                import struct as _struct
                                rc_raw = _struct.unpack_from("<I", raw_data, 4)[0]
                                run_count = max(0, rc_raw - 5) if rc_raw >= 5 else rc_raw
                                if len(raw_data) >= 68:
                                    ft = _struct.unpack_from("<Q", raw_data, 60)[0]
                                    if ft > 0:
                                        last_run = _filetime_to_iso(ft)
                            entries[decoded] = {
                                "run_count": run_count,
                                "last_run":  last_run,
                            }
                        if entries:
                            result["userassist"][guid_key.name()] = entries
                    except Exception:
                        pass
            except Exception:
                pass

            # RecentDocs
            try:
                rd_key = reg.open(
                    "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs"
                )
                for _ext_key in ([rd_key] + list(rd_key.subkeys())):
                    _label = _ext_key.name() if _ext_key is not rd_key else "(root)"
                    _mru_vals = {v.name(): v.value() for v in _ext_key.values()
                                 if v.name() != "MRUListEx"}
                    _items = []
                    try:
                        mru_order = _ext_key.value("MRUListEx").value()
                        if isinstance(mru_order, bytes):
                            import struct as _struct
                            for _i in range(0, len(mru_order) - 3, 4):
                                _idx = _struct.unpack_from("<I", mru_order, _i)[0]
                                if _idx == 0xFFFFFFFF:
                                    break
                                _raw = _mru_vals.get(str(_idx), b"")
                                if isinstance(_raw, bytes) and _raw:
                                    _name = _raw.split(b"\x00\x00")[0]
                                    try:
                                        _items.append(_name.decode("utf-16-le", errors="replace").rstrip("\x00"))
                                    except Exception:
                                        pass
                    except Exception:
                        pass
                    if _items:
                        result["recentdocs"][_label] = _items
            except Exception:
                pass

            # TypedURLs
            try:
                tu_key = reg.open("Software\\Microsoft\\Internet Explorer\\TypedURLs")
                result["typedurlsmru"] = [
                    str(v.value())
                    for v in tu_key.values()
                    if isinstance(v.value(), str)
                ]
            except Exception:
                pass

            # OpenSaveMRU
            for mru_path in (
                "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\ComDlg32\\OpenSavePidlMRU",
                "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\ComDlg32\\OpenSaveMRU",
            ):
                try:
                    mru_base = reg.open(mru_path)
                    for ext_key in mru_base.subkeys():
                        _items2 = [str(v.value()) for v in ext_key.values()
                                   if v.name() != "MRUListEx" and isinstance(v.value(), str)]
                        if _items2:
                            result["opensavemru"][ext_key.name()] = _items2
                except Exception:
                    pass
                if result["opensavemru"]:
                    break

            # ShellBags (BagMRU)
            for bags_path in (
                "Software\\Microsoft\\Windows\\Shell\\BagMRU",
                "Local Settings\\Software\\Microsoft\\Windows\\Shell\\BagMRU",
                "Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\BagMRU",
            ):
                try:
                    bags_key = reg.open(bags_path)
                    _walk_bags_pyreg(bags_key, "", result["shellbags"], depth=0)
                    break
                except Exception:
                    pass

            result["parse_status"] = "ok_python_registry"
            return result
        except Exception as exc:
            logger.warning("python-registry NTUSER failed: %s — falling back to raw parser", exc)

    try:
        data = path.read_bytes()
        if len(data) < 4096 or data[:4] != b"regf":
            result["parse_status"] = "invalid_magic"
            return result
        parser = _RegfParser(data)
        result["userassist"]   = parser.extract_userassist()
        result["recentdocs"]   = parser.extract_recent_docs()
        result["opensavemru"]  = parser.extract_opensavemru()
        result["typedurlsmru"] = parser.extract_typedurlsmru()
        result["shellbags"]    = parser.extract_shellbags()
        result["parse_status"] = "ok_raw"
    except Exception as exc:
        result["parse_status"] = "error"
        result["error"] = str(exc)
    return result


def _walk_bags_pyreg(
    key: Any,
    prefix: str,
    bags: list,
    depth: int = 0,
    _seen_paths: set[str] | None = None,
) -> None:
    """Recursively walk every reachable BagMRU key.

    There is no arbitrary depth limit. A registry-key path set prevents a
    malformed/cyclic structure from causing unbounded recursion.
    """
    if _seen_paths is None:
        _seen_paths = set()
    try:
        key_path = str(key.path())
    except Exception:
        key_path = prefix or repr(key)
    if key_path in _seen_paths:
        return
    _seen_paths.add(key_path)

    for val in key.values():
        if val.name().isdigit():
            bags.append(f"{prefix}/{val.name()}" if prefix else val.name())
    for sub in key.subkeys():
        _walk_bags_pyreg(
            sub,
            f"{prefix}/{sub.name()}" if prefix else sub.name(),
            bags,
            depth + 1,
            _seen_paths,
        )


# ---------------------------------------------------------------------------
# Cover account detection
# ---------------------------------------------------------------------------

# Time-proximity window for cover-account pairing (seconds).  Shared by the
# detector and the finding text so the two can never diverge.
_COVER_ACCOUNT_WINDOW_SECONDS = 60.0

# Windows assigns interactive user accounts a RID >= 1000; RIDs below that are
# reserved by the OS for built-in and service accounts (500 Administrator,
# 501 Guest, 502 krbtgt, 503 DefaultAccount, 504 WDAGUtilityAccount, and the
# service/well-known range).  This is a structural constant from the SAM
# specification, not a case-specific value.
_FIRST_NON_BUILTIN_RID = 1000

# A profile smaller than this is treated as empty/never-used (template profile).
_EMPTY_PROFILE_MAX_BYTES = 8192


def _is_builtin_account(acc: dict) -> bool:
    """True when an account is a built-in/service account by RID structure.

    Identification is structural — the well-known RID range from the SAM
    specification — never a match against literal account names.  When the RID
    is unknown the account is not assumed built-in; the corroboration
    requirement below is the backstop against a false positive in that case.
    """
    rid = acc.get("rid")
    try:
        return rid is not None and int(rid) < _FIRST_NON_BUILTIN_RID
    except (TypeError, ValueError):
        return False


def _corroborating_profile_signal(
    user_a: str, user_b: str, profile_signals: dict
) -> str:
    """Return a runtime-discovered corroboration label for a pair, or "".

    Time proximity alone is insufficient — default OS accounts are created in
    the same install second.  A pair is only corroborated when their profiles
    look template-cloned: byte-identical NTUSER.DAT content, or both empty
    (never used interactively).  All signals are discovered from the evidence.
    """
    sig_a = profile_signals.get(user_a) or {}
    sig_b = profile_signals.get(user_b) or {}

    hash_a = sig_a.get("ntuser_sha256") or ""
    hash_b = sig_b.get("ntuser_sha256") or ""
    if hash_a and hash_b and hash_a == hash_b:
        return "identical NTUSER.DAT profile hash"

    size_a = sig_a.get("ntuser_size_bytes")
    size_b = sig_b.get("ntuser_size_bytes")
    if (isinstance(size_a, int) and isinstance(size_b, int)
            and size_a < _EMPTY_PROFILE_MAX_BYTES
            and size_b < _EMPTY_PROFILE_MAX_BYTES):
        return "both profiles empty/never-used"

    return ""


def _detect_cover_accounts(
    accounts: list[dict],
    profile_signals: "Optional[dict]" = None,
) -> list[dict]:
    """Flag time-proximate account pairs that are corroborated as cover accounts.

    Two guards suppress the historical false positive where default OS accounts
    (created in the same install second) were flagged Critical on shared
    creation time alone:

      1. Built-in/service accounts are excluded structurally by well-known RID
         range — never by matching account names.
      2. A time-proximate pair is reported only when a corroborating indicator
         discovered at runtime (template-identical or both-empty user profiles)
         is also present.
    """
    profile_signals = profile_signals or {}

    timestamped = []
    for acc in accounts:
        if _is_builtin_account(acc):
            continue  # default OS / service account — not a cover account
        # Use the genuine creation time when available, else the SAM key
        # last-write time (the closest structural proxy for a never-modified
        # freshly created account).
        ct = acc.get("creation_time") or acc.get("last_write")
        if not ct:
            continue
        try:
            if isinstance(ct, str):
                dt = datetime.fromisoformat(ct.replace("Z", "+00:00"))
            else:
                dt = ct
            timestamped.append((acc["username"], dt.timestamp()))
        except Exception:
            continue

    timestamped.sort(key=lambda x: x[1])
    pairs = []
    for i in range(len(timestamped) - 1):
        delta = abs(timestamped[i+1][1] - timestamped[i][1])
        if delta >= _COVER_ACCOUNT_WINDOW_SECONDS:
            continue
        user_a, user_b = timestamped[i][0], timestamped[i+1][0]
        corroboration = _corroborating_profile_signal(user_a, user_b, profile_signals)
        if not corroboration:
            continue  # time proximity alone is not enough
        pairs.append({
            "account_a":     user_a,
            "account_b":     user_b,
            "delta_seconds": delta,
            "corroboration": corroboration,
        })
    return pairs


# ---------------------------------------------------------------------------
# Finding factories
# ---------------------------------------------------------------------------

def _findings_from_sam(parsed: dict, hive_path: str) -> list[Finding]:
    findings = []
    accounts = parsed.get("accounts", [])
    if accounts:
        findings.append(make_finding(
            "USER_ACCOUNTS_PROFILED", Severity.INFO,
            f"SAM hive parsed. {len(accounts)} local user account(s) found: "
            + ", ".join(a.get("username","?") for a in accounts[:10])
            + ("…" if len(accounts) > 10 else "") + ". "
            "RIDs, SAM key last-write and last-login timestamps recorded "
            "(the key last-write time is not the account creation time).",
            hive_path,
            {"accounts": [a.get("username") for a in accounts],
             "count": len(accounts)},
        ))

    # Deleted account records recovered from unallocated SAM cells.
    deleted = parsed.get("deleted_accounts", [])
    for da in deleted:
        findings.append(make_finding(
            "DELETED_SAM_ACCOUNT_RECOVERED", Severity.HIGH,
            f"Deleted SAM user account recovered from unallocated hive space: "
            f"RID {da.get('rid','?')} (key name '{da.get('username','?')}'). "
            f"SAM key last-write: {da.get('last_write') or 'unknown'}. "
            "The account was removed from the live SAM but its record survives "
            "in a freed cell.",
            hive_path,
            {
                "rid":        da.get("rid"),
                "username":   da.get("username"),
                "last_write": da.get("last_write"),
                "deleted":    True,
            },
        ))
    return findings


def _findings_from_system(parsed: dict, hive_path: str) -> list[Finding]:
    findings = []
    usb = parsed.get("usb_devices", [])
    if usb:
        findings.append(make_finding(
            "USBSTOR_HISTORY_FOUND", Severity.HIGH,
            f"USBSTOR registry key contains {len(usb)} retained USB storage device record(s). "
            "The records identify device class, instance ID and friendly name where present. "
            "No transfer, user, purpose or exfiltration conclusion is drawn from registration alone.",
            hive_path,
            {"devices": usb[:10]},
        ))
    shares = parsed.get("network_shares", [])
    if shares:
        findings.append(make_finding(
            "NETWORK_SHARE_HISTORY", Severity.MEDIUM,
            f"Network share history found: {len(shares)} share(s) recorded in registry. "
            + "; ".join(s.get("path","?") for s in shares[:5]),
            hive_path,
            {"shares": shares[:20]},
        ))
    return findings


def _findings_from_software(parsed: dict, hive_path: str) -> list[Finding]:
    findings = []
    os_info = parsed.get("os_info", {})
    if os_info:
        findings.append(make_finding(
            "OS_IDENTIFICATION", Severity.INFO,
            f"Operating system identified: {os_info.get('ProductName','unknown')} "
            f"(Build {os_info.get('CurrentBuild','?')}, "
            f"Version {os_info.get('CurrentVersion','?')}, "
            f"Registered to: {os_info.get('RegisteredOwner','N/A')} / "
            f"{os_info.get('RegisteredOrganization','N/A')}).",
            hive_path,
            os_info,
        ))
    suspicious = parsed.get("suspicious", [])
    for prog in suspicious:
        name = prog.get("displayname") or prog.get("key_name", "")
        findings.append(make_finding(
            "CONFIGURED_SOFTWARE_NAME_MATCH", Severity.INFO,
            f"Installed-program metadata contains the exact configured review-name match '{name}'. "
            "This proves the retained registry-name match only; execution, behaviour, purpose and "
            "anti-forensic intent are not inferred.",
            hive_path,
            {
                "program": prog, "category": "configured_review_name",
                **deterministic_metadata(
                    "exact installed-program name comparison",
                    validators=["registry key/value parser", "case-insensitive token-boundary equality"],
                    semantic_limit="Name match only; no execution or maliciousness conclusion.",
                ),
            },
        ))
    return findings


def _findings_from_ntuser(parsed: dict, hive_path: str, username: str) -> list[Finding]:
    findings = []
    userassist = parsed.get("userassist", {})
    if userassist:
        total = sum(len(v) if isinstance(v, (list, dict)) else 0 for v in userassist.values())
        findings.append(make_finding(
            "USERASSIST_HISTORY_FOUND", Severity.MEDIUM,
            f"UserAssist registry key found for user '{username}'. "
            f"{total} program execution record(s). "
            "UserAssist tracks GUI application executions with run count and last run time. "
            "Decoded from ROT-13 GUID-based keys.",
            hive_path,
            {"username": username, "entry_count": total},
        ))
    # Check for forensic tool execution — each match is a HIGH severity finding
    _FORENSIC_TOOLS_CHECK = [
        "FTKImager", "EnCase", "Wireshark", "Autopsy",
        "dd.exe", "SecureClean", "CCleaner", "WinHex",
    ]
    for guid_key, entries in userassist.items():
        if not isinstance(entries, dict):
            continue
        for decoded_name, ua_info in entries.items():
            if not isinstance(ua_info, dict):
                continue
            for tool in _FORENSIC_TOOLS_CHECK:
                if re.search(r'(?:^|[/\\ ])' + re.escape(tool.lower()) + r'(?:\.|[ ]|$)',
                             decoded_name.lower()):
                    run_count = ua_info.get("run_count", 0)
                    last_run  = ua_info.get("last_run", "unknown")
                    findings.append(make_finding(
                        "USERASSIST_CONFIGURED_NAME_MATCH", Severity.INFO,
                        f"A parsed UserAssist record contains the configured application-name match "
                        f"'{tool}' for user profile '{username}', with retained run-count {run_count} "
                        f"and last-run value {last_run}. This does not establish anti-forensic intent.",
                        hive_path,
                        {
                            "tool": tool, "username": username, "run_count": run_count,
                            "last_run": last_run, "decoded_path": decoded_name[:400],
                            **deterministic_metadata(
                                "parsed UserAssist record plus exact configured-name boundary match",
                                validators=["registry cell parser", "ROT13 decoder", "token-boundary comparison"],
                                semantic_limit="Retained UserAssist record only; intent and operator identity are not inferred.",
                            ),
                        },
                    ))
                    break
    recentdocs = parsed.get("recentdocs", {})
    if recentdocs:
        total = sum(len(v) if isinstance(v, list) else 1 for v in recentdocs.values())
        findings.append(make_finding(
            "RECENTDOCS_MRU_FOUND", Severity.MEDIUM,
            f"RecentDocs MRU list found for user '{username}'. "
            f"{total} recently accessed document path(s). "
            "Provides direct evidence of document access history.",
            hive_path,
            {"username": username, "categories": list(recentdocs.keys())[:10]},
        ))
    opensavemru = parsed.get("opensavemru", {})
    if opensavemru:
        total = sum(len(v) if isinstance(v, list) else 1 for v in opensavemru.values())
        findings.append(make_finding(
            "OPENSAVEMRU_FOUND", Severity.MEDIUM,
            f"OpenSaveMRU found for user '{username}': {total} file access record(s). "
            "Records files opened or saved via the common file dialog, "
            "revealing application usage and file paths.",
            hive_path,
            {"username": username, "count": total},
        ))
    typedurlsmru = parsed.get("typedurlsmru", [])
    if typedurlsmru:
        findings.append(make_finding(
            "TYPEDURLS_FOUND", Severity.MEDIUM,
            f"TypedURLs found for user '{username}': {len(typedurlsmru)} URL(s) typed "
            f"manually into Internet Explorer/Edge address bar. "
            "Examples: " + "; ".join(str(u)[:60] for u in typedurlsmru[:3]),
            hive_path,
            {"username": username, "urls": [str(u)[:200] for u in typedurlsmru[:20]]},
        ))
    shellbags = parsed.get("shellbags", [])
    if shellbags:
        findings.append(make_finding(
            "SHELLBAGS_FOUND", Severity.MEDIUM,
            f"ShellBags found for user '{username}': {len(shellbags)} folder access record(s). "
            "ShellBags preserve folder browsing history including folders on "
            "removed USB drives and deleted directories.",
            hive_path,
            {"username": username, "count": len(shellbags),
             "samples": [str(s)[:100] for s in shellbags[:5]]},
        ))
    return findings


# ---------------------------------------------------------------------------
# REGF binary parser (extended from artifact_extractor pattern)
# ---------------------------------------------------------------------------

def _filetime_to_iso(ft: int) -> Optional[str]:
    """Convert Windows FILETIME (100-ns intervals since 1601-01-01) to ISO 8601 UTC string."""
    if ft == 0:
        return None
    try:
        unix_ts = (ft - 116444736000000000) / 1e7
        return datetime.fromtimestamp(unix_ts, tz=timezone.utc).isoformat(timespec="seconds")
    except (OSError, OverflowError, ValueError):
        return None


class _RegfParser:
    _BASE = 4096

    def __init__(self, data: bytes) -> None:
        self._d = data
        self._root_off: int = struct.unpack_from("<I", data, 32)[0]
        self.hive_bins_size: int = struct.unpack_from("<I", data, 40)[0]

    # ── Public extractors ────────────────────────────────────────────────────

    def extract_sam_users(self) -> list[dict]:
        """Parse SAM Users — read F (account flags, login count, timestamps) and V (username, RID)."""
        nk = self._nav(["SAM", "Domains", "Account", "Users"]) \
             or self._nav(["Domains", "Account", "Users"])
        if not nk:
            return []

        users = []
        for rid_hex, rid_off in self._iter_subkeys(nk):
            # Skip non-RID subkeys (Names, and anything not exactly 8 hex digits)
            if rid_hex.upper() == "NAMES" or not re.fullmatch(r"[0-9A-Fa-f]{8}", rid_hex):
                continue
            user_nk = self._read_nk(rid_off)
            vals = self._read_vals(user_nk)

            account: dict = {
                "username":      rid_hex,
                "rid":           None,
                "creation_time": None,
                "last_write":    user_nk.get("last_write"),
                "last_login":    None,
                "login_count":   0,
                "account_flags": "",
                "deleted":       False,
            }

            try:
                account["rid"] = int(rid_hex, 16)
            except ValueError:
                pass

            # Parse F binary value: last logon FILETIME at offset 8, login count uint16 at offset 40,
            # account control flags uint32 at offset 48
            f_raw = vals.get("F", "")
            if isinstance(f_raw, str):
                try:
                    f_bytes = bytes.fromhex(f_raw)
                except ValueError:
                    logging.getLogger(__name__).warning(
                        "[REGISTRY] SAM F value hex decode failed for RID %s — skipping binary parse", rid_hex)
                    f_bytes = b""
                    account["parse_error"] = "F_value_hex_decode_failed"
            elif isinstance(f_raw, (bytes, bytearray)):
                f_bytes = bytes(f_raw)
            else:
                f_bytes = b""

            if len(f_bytes) >= 52:
                ft_logon = struct.unpack_from("<Q", f_bytes, 8)[0]
                if ft_logon > 0:
                    account["last_login"] = _filetime_to_iso(ft_logon)
                account["login_count"] = struct.unpack_from("<H", f_bytes, 40)[0]
                acf = struct.unpack_from("<I", f_bytes, 48)[0]
                flags = []
                if acf & 0x0001: flags.append("DISABLED")
                if acf & 0x0002: flags.append("HOMEDIR_REQUIRED")
                if acf & 0x0004: flags.append("PASSWD_NOTREQD")
                if acf & 0x0008: flags.append("TEMP_DUP_ACCOUNT")
                if acf & 0x0010: flags.append("NORMAL_ACCOUNT")
                if acf & 0x0200: flags.append("DONT_EXPIRE_PASSWORD")
                if acf & 0x0400: flags.append("ACCOUNT_LOCKOUT")
                if acf & 0x0800: flags.append("ENCRYPTED_TEXT_PWD_ALLOWED")
                if acf & 0x2000: flags.append("SMARTCARD_REQUIRED")
                account["account_flags"] = "|".join(flags) if flags else f"0x{acf:08X}"

            # Parse V binary value: username UTF-16LE stored at offset 0xCC + pointer at bytes 12-16
            v_raw = vals.get("V", "")
            if isinstance(v_raw, str):
                try:
                    v_bytes = bytes.fromhex(v_raw)
                except ValueError:
                    logging.getLogger(__name__).warning(
                        "[REGISTRY] SAM V value hex decode failed for RID %s — username will be RID hex", rid_hex)
                    v_bytes = b""
                    account.setdefault("parse_error", "V_value_hex_decode_failed")
            elif isinstance(v_raw, (bytes, bytearray)):
                v_bytes = bytes(v_raw)
            else:
                v_bytes = b""

            if len(v_bytes) >= 20:
                try:
                    uname_off = struct.unpack_from("<I", v_bytes, 12)[0]
                    uname_len = struct.unpack_from("<I", v_bytes, 16)[0]
                    str_area_start = 0xCC
                    abs_start = str_area_start + uname_off
                    abs_end   = abs_start + uname_len
                    if uname_len > 0 and uname_len <= 512 and abs_end <= len(v_bytes):
                        account["username"] = v_bytes[abs_start:abs_end].decode(
                            "utf-16-le", errors="replace"
                        ).rstrip("\x00")
                except Exception:
                    pass

            users.append(account)

        return users

    def extract_deleted_sam_users(self, live_rids: "Optional[set[int]]" = None) -> list[dict]:
        """Recover deleted SAM user RID keys from unallocated hive cells.

        A registry cell whose size field is POSITIVE is unallocated (freed) — a
        deleted record.  This scans the hive for unallocated ``nk`` cells whose
        name is an 8-hex-digit RID (the on-disk name of a SAM user key), so
        accounts removed from the live key list still surface.  RIDs already
        present in the live account list are skipped.  Nothing is hardcoded; the
        RID pattern is the structural SAM key-naming convention.
        """
        live_rids = live_rids or set()
        recovered: list[dict] = []
        seen: set[int] = set()
        data = self._d
        pos = self._BASE
        limit = len(data)
        rid_re = re.compile(r"^[0-9A-Fa-f]{8}$")

        # Scan for the 'nk' signature; the 4 bytes immediately before it are the
        # cell size (negative = allocated, positive = unallocated/deleted).
        idx = data.find(b"nk", pos)
        while idx != -1 and idx + 80 <= limit:
            size_off = idx - 4
            if size_off >= self._BASE:
                size = struct.unpack_from("<i", data, size_off)[0]
                if size > 0:  # unallocated cell → deleted record
                    cell = data[idx:idx + max(0, abs(size) - 4)]
                    if len(cell) >= 80:
                        name_len = struct.unpack_from("<H", cell, 72)[0]
                        flags = struct.unpack_from("<H", cell, 2)[0]
                        if 0 < name_len <= 64 and 76 + name_len <= len(cell):
                            is_ascii = bool(flags & 0x0020)
                            try:
                                name = cell[76:76 + name_len].decode(
                                    "ascii" if is_ascii else "utf-16-le",
                                    errors="replace",
                                )
                            except Exception:
                                name = ""
                            if rid_re.match(name):
                                try:
                                    rid = int(name, 16)
                                except ValueError:
                                    rid = None
                                if rid is not None and rid not in live_rids and rid not in seen:
                                    seen.add(rid)
                                    ft = struct.unpack_from("<Q", cell, 4)[0]
                                    recovered.append({
                                        "username":      name,
                                        "rid":           rid,
                                        "creation_time": None,
                                        "last_write":    _filetime_to_iso(ft),
                                        "last_login":    None,
                                        "login_count":   0,
                                        "account_flags": "",
                                        "deleted":       True,
                                    })
            idx = data.find(b"nk", idx + 2)
        return recovered

    def extract_os_info(self) -> dict:
        nk = self._nav(["Microsoft", "Windows NT", "CurrentVersion"]) \
             or self._nav(["Microsoft", "Windows", "CurrentVersion"])
        if not nk:
            return {}
        return {k: str(v) for k, v in self._read_vals(nk).items()
                if k in ("ProductName", "CurrentVersion", "CurrentBuild",
                         "RegisteredOwner", "RegisteredOrganization",
                         "InstallDate", "InstallTime", "CSDVersion",
                         "BuildBranch", "EditionID", "UBR")}

    def extract_installed_software(self) -> list[dict]:
        software: list[dict] = []
        for path in (
            ["Microsoft", "Windows", "CurrentVersion", "Uninstall"],
            ["Wow6432Node", "Microsoft", "Windows", "CurrentVersion", "Uninstall"],
        ):
            nk = self._nav(path)
            if not nk:
                continue
            for prog_name, prog_off in self._iter_subkeys(nk):
                pnk = self._read_nk(prog_off)
                vals = self._read_vals(pnk)
                prog = {
                    "name":        str(vals.get("DisplayName", prog_name or "?")),
                    "version":     str(vals.get("DisplayVersion", "")),
                    "publisher":   str(vals.get("Publisher", "")),
                    "install_date": str(vals.get("InstallDate", "")),
                    "key_name":    prog_name,
                    "displayname": str(vals.get("DisplayName", prog_name or "?")),
                    "displayversion": str(vals.get("DisplayVersion", "")),
                    "installlocation": str(vals.get("InstallLocation", "")),
                }
                software.append(prog)
        return software

    def extract_usb_history(self) -> list[dict]:
        for cs in ("ControlSet001", "ControlSet002", "ControlSet003"):
            nk = self._nav([cs, "Enum", "USBSTOR"])
            if not nk:
                continue
            devices = []
            for dev_class, class_off in self._iter_subkeys(nk):
                cnk = self._read_nk(class_off)
                for inst, inst_off in self._iter_subkeys(cnk):
                    ink = self._read_nk(inst_off)
                    vals = self._read_vals(ink)
                    devices.append({
                        "device_class":  dev_class,
                        "instance_id":   inst,
                        "friendly_name": str(vals.get("FriendlyName","")),
                        "hardware_id":   str(vals.get("HardwareID","")),
                    })
            return devices
        return []

    def extract_computer_name(self) -> str:
        for cs in ("ControlSet001", "ControlSet002", "ControlSet003"):
            nk = self._nav([cs, "Control", "ComputerName", "ComputerName"])
            if nk:
                vals = self._read_vals(nk)
                if "ComputerName" in vals:
                    return str(vals["ComputerName"])
        return ""

    def extract_timezone(self) -> str:
        for cs in ("ControlSet001", "ControlSet002", "ControlSet003"):
            nk = self._nav([cs, "Control", "TimeZoneInformation"])
            if nk:
                vals = self._read_vals(nk)
                for key in ("TimeZoneKeyName", "StandardName"):
                    if key in vals:
                        return str(vals[key])
        return ""

    def extract_network_shares(self) -> list[dict]:
        shares = []
        # MRU mapped drives in NTUSER (will be called from NTUSER context too)
        for cs in ("ControlSet001", "ControlSet002", "ControlSet003"):
            nk = self._nav([cs, "Services", "LanmanServer", "Shares"])
            if nk:
                for name, _ in self._iter_subkeys(nk):
                    shares.append({"name": name, "type": "server_share"})
        return shares

    def extract_userassist(self) -> dict:
        """
        Extract UserAssist from NTUSER.DAT.
        Each value is a 72-byte binary blob:
          offset 4  : uint32 run count (subtract 5 for Vista+ bias)
          offset 60 : uint64 last-run FILETIME
        Value names are ROT-13 encoded.
        """
        result: dict = {}
        nk = self._nav([
            "Software", "Microsoft", "Windows", "CurrentVersion",
            "Explorer", "UserAssist",
        ])
        if not nk:
            return result

        for guid, guid_off in self._iter_subkeys(nk):
            count_nk = None
            for subname, sub_off in self._iter_subkeys(self._read_nk(guid_off)):
                if subname.upper() == "COUNT":
                    count_nk = self._read_nk(sub_off)
                    break
            if not count_nk:
                continue

            vals = self._read_vals(count_nk)
            entries: dict = {}
            for enc_name, raw_data in vals.items():
                # ROT-13 decode the value name
                decoded = "".join(
                    chr(ord(c) + 13) if 'a' <= c <= 'm' or 'A' <= c <= 'M'
                    else chr(ord(c) - 13) if 'n' <= c <= 'z' or 'N' <= c <= 'Z'
                    else c
                    for c in enc_name
                )

                run_count = 0
                last_run_iso = None

                # Parse the 72-byte binary blob for run count and last-run timestamp
                if isinstance(raw_data, str):
                    try:
                        blob = bytes.fromhex(raw_data)
                    except ValueError:
                        blob = b""
                elif isinstance(raw_data, (bytes, bytearray)):
                    blob = bytes(raw_data)
                else:
                    blob = b""

                if len(blob) >= 8:
                    raw_count = struct.unpack_from("<I", blob, 4)[0]
                    run_count = max(0, raw_count - 5) if raw_count >= 5 else raw_count

                if len(blob) >= 68:
                    ft = struct.unpack_from("<Q", blob, 60)[0]
                    last_run_iso = _filetime_to_iso(ft)

                entries[decoded] = {
                    "run_count": run_count,
                    "last_run":  last_run_iso,
                    "encoded":   enc_name,
                }

            if entries:
                result[guid] = entries

        return result

    def extract_recent_docs(self) -> dict:
        nk = self._nav([
            "Software", "Microsoft", "Windows", "CurrentVersion",
            "Explorer", "RecentDocs",
        ])
        if not nk:
            return {}
        docs: dict = {}
        vals = self._read_vals(nk)
        mru = self._decode_mrulist(vals)
        if mru:
            docs["(root)"] = mru
        for ext, sub_off in self._iter_subkeys(nk):
            sub_nk = self._read_nk(sub_off)
            sub_vals = self._read_vals(sub_nk)
            mru_items = self._decode_mrulist(sub_vals)
            if mru_items:
                docs[ext] = mru_items
        return docs

    def extract_opensavemru(self) -> dict:
        result: dict = {}
        # OpenSavePidlMRU (Vista+) and OpenSaveMRU (XP)
        for key_path in (
            ["Software", "Microsoft", "Windows", "CurrentVersion",
             "Explorer", "ComDlg32", "OpenSavePidlMRU"],
            ["Software", "Microsoft", "Windows", "CurrentVersion",
             "Explorer", "ComDlg32", "OpenSaveMRU"],
        ):
            nk = self._nav(key_path)
            if not nk:
                continue
            for ext, sub_off in self._iter_subkeys(nk):
                sub_nk = self._read_nk(sub_off)
                sub_vals = self._read_vals(sub_nk)
                mru = self._decode_mrulist(sub_vals)
                if mru:
                    result[ext] = mru
        return result

    def extract_typedurlsmru(self) -> list:
        nk = self._nav([
            "Software", "Microsoft", "Internet Explorer", "TypedURLs",
        ])
        if not nk:
            return []
        vals = self._read_vals(nk)
        return [str(v) for v in vals.values() if isinstance(v, str)]

    def extract_shellbags(self) -> list:
        """Extract shellbags (folder browsing history) from UsrClass.dat or NTUSER.DAT."""
        bags: list = []
        for path in (
            ["Software", "Microsoft", "Windows", "Shell", "BagMRU"],
            ["Local Settings", "Software", "Microsoft", "Windows", "Shell", "BagMRU"],
            ["Software", "Classes", "Local Settings", "Software", "Microsoft",
             "Windows", "Shell", "BagMRU"],
        ):
            nk = self._nav(path)
            if nk:
                self._walk_bagmru(nk, "", bags, depth=0)
                break
        return bags

    def _walk_bagmru(
        self,
        nk: dict,
        prefix: str,
        bags: list,
        depth: int = 0,
        _seen_offsets: set[int] | None = None,
    ) -> None:
        """Walk every reachable BagMRU subkey without an arbitrary depth cap."""
        if _seen_offsets is None:
            _seen_offsets = set()
        vals = self._read_vals(nk)
        for vname, vdata in vals.items():
            if vname.isdigit():
                entry = f"{prefix}/{vname}" if prefix else vname
                bags.append(entry)
        for subname, sub_off in self._iter_subkeys(nk):
            if sub_off in _seen_offsets:
                continue
            _seen_offsets.add(sub_off)
            sub_nk = self._read_nk(sub_off)
            self._walk_bagmru(
                sub_nk,
                f"{prefix}/{subname}" if prefix else subname,
                bags,
                depth + 1,
                _seen_offsets,
            )

    # ── REGF cell navigation ─────────────────────────────────────────────────

    def _cell(self, off: int) -> bytes:
        abs_off = self._BASE + off
        if abs_off + 4 > len(self._d):
            return b""
        size = struct.unpack_from("<i", self._d, abs_off)[0]
        pl = abs(size) - 4
        if pl <= 0:
            return b""
        return self._d[abs_off + 4 : abs_off + 4 + pl]

    def _read_nk(self, off: int) -> dict:
        cell = self._cell(off)
        if len(cell) < 80 or cell[:2] != b"nk":
            return {}
        flags = struct.unpack_from("<H", cell, 2)[0]
        # NK last-written timestamp (FILETIME) lives at payload offset 4.  This
        # is the key's LAST-WRITE time, not its creation time — the two diverge
        # once a key is modified, so it must be labelled as last-write.
        last_write_ft = struct.unpack_from("<Q", cell, 4)[0]
        num_sub  = struct.unpack_from("<I", cell, 20)[0]
        sub_off  = struct.unpack_from("<i", cell, 28)[0]
        num_vals = struct.unpack_from("<I", cell, 36)[0]
        vals_off = struct.unpack_from("<i", cell, 40)[0]
        name_len = struct.unpack_from("<H", cell, 72)[0]
        is_ascii = bool(flags & 0x0020)
        name_raw = cell[76 : 76 + name_len]
        try:
            name = name_raw.decode("ascii" if is_ascii else "utf-16-le", errors="replace")
        except Exception:
            name = name_raw.hex()
        return {"name": name, "num_sub": num_sub, "sub_off": sub_off,
                "num_vals": num_vals, "vals_off": vals_off,
                "last_write": _filetime_to_iso(last_write_ft)}

    def _iter_subkeys(self, nk: dict) -> list[tuple[str, int]]:
        if not nk or nk.get("num_sub", 0) == 0 or nk.get("sub_off", -1) < 0:
            return []
        return self._expand_list(nk["sub_off"])

    def _expand_list(
        self,
        list_off: int,
        depth: int = 0,
        _seen_list_offsets: set[int] | None = None,
    ) -> list[tuple[str, int]]:
        # RI indirection depth is not arbitrarily capped. A visited-offset set
        # prevents malformed registry list cycles from looping forever.
        if _seen_list_offsets is None:
            _seen_list_offsets = set()
        if list_off in _seen_list_offsets:
            return []
        _seen_list_offsets.add(list_off)
        cell = self._cell(list_off)
        if len(cell) < 4:
            return []
        sig   = cell[:2]
        count = struct.unpack_from("<H", cell, 2)[0]
        res: list[tuple[str, int]] = []
        if sig in (b"lf", b"lh"):
            for i in range(min(count, (len(cell) - 4) // 8)):
                off = struct.unpack_from("<i", cell, 4 + i * 8)[0]
                if off >= 0:
                    sub = self._read_nk(off)
                    if sub:
                        res.append((sub["name"], off))
        elif sig == b"li":
            for i in range(min(count, (len(cell) - 4) // 4)):
                off = struct.unpack_from("<i", cell, 4 + i * 4)[0]
                if off >= 0:
                    sub = self._read_nk(off)
                    if sub:
                        res.append((sub["name"], off))
        elif sig == b"ri":
            for i in range(min(count, (len(cell) - 4) // 4)):
                sub_list = struct.unpack_from("<i", cell, 4 + i * 4)[0]
                if sub_list >= 0:
                    res.extend(self._expand_list(sub_list, depth + 1, _seen_list_offsets))
        return res

    def _nav(self, path: list[str], start: int | None = None) -> dict | None:
        cur = self._root_off if start is None else start
        for comp in path:
            nk = self._read_nk(cur)
            if not nk:
                return None
            found = False
            for name, sub_off in self._iter_subkeys(nk):
                if name.lower() == comp.lower():
                    cur = sub_off
                    found = True
                    break
            if not found:
                return None
        return self._read_nk(cur)

    def _read_vals(self, nk: dict) -> dict:
        vals: dict = {}
        if not nk or nk.get("num_vals", 0) == 0 or nk.get("vals_off", -1) < 0:
            return vals
        vlist = self._cell(nk["vals_off"])
        for i in range(min(nk["num_vals"], len(vlist) // 4)):
            vk_off = struct.unpack_from("<i", vlist, i * 4)[0]
            if vk_off < 0:
                continue
            vk = self._cell(vk_off)
            if len(vk) < 20 or vk[:2] != b"vk":
                continue
            try:
                name_len  = struct.unpack_from("<H", vk, 2)[0]
                data_size = struct.unpack_from("<I", vk, 4)[0]
                data_off  = struct.unpack_from("<i", vk, 8)[0]
                data_type = struct.unpack_from("<I", vk, 12)[0]
                vk_flags  = struct.unpack_from("<H", vk, 16)[0]
                is_ascii  = bool(vk_flags & 0x0001)
                val_name  = ("(Default)" if name_len == 0 else
                              vk[20:20+name_len].decode(
                                  "ascii" if is_ascii else "utf-16-le", errors="replace"))
                inline   = bool(data_size & 0x80000000)
                act_size = data_size & 0x7FFFFFFF
                raw      = (struct.pack("<I", data_off)[:act_size] if inline
                             else self._cell(data_off)[:act_size])
                if data_type == 1:
                    decoded: Any = raw.decode("utf-16-le", errors="replace").rstrip("\x00")
                elif data_type == 2:
                    decoded = raw.decode("utf-16-le", errors="replace").rstrip("\x00")
                elif data_type == 4:
                    decoded = struct.unpack_from("<I", raw)[0] if len(raw) >= 4 else 0
                elif data_type == 7:
                    decoded = [s for s in raw.decode("utf-16-le", errors="replace").split("\x00") if s]
                else:
                    decoded = raw.hex()
                vals[val_name] = decoded
            except Exception:
                continue
        return vals

    @staticmethod
    def _decode_mrulist(vals: dict) -> list[str]:
        items: list[str] = []
        order_raw = vals.get("MRUListEx", b"")
        if isinstance(order_raw, str):
            try:
                order_raw = bytes.fromhex(order_raw)
            except Exception:
                order_raw = b""
        if isinstance(order_raw, bytes) and len(order_raw) >= 4:
            for i in range(0, len(order_raw) - 3, 4):
                idx = struct.unpack_from("<I", order_raw, i)[0]
                if idx == 0xFFFFFFFF:
                    break
                raw_entry = vals.get(str(idx), "")
                if isinstance(raw_entry, str) and raw_entry:
                    name = raw_entry.split("\x00")[0]
                    if name:
                        items.append(name)
        # Fallback: MRUList (string order index)
        if not items:
            mru_list = vals.get("MRUList", "")
            if isinstance(mru_list, str):
                for c in mru_list:
                    raw_entry = vals.get(c, "")
                    if isinstance(raw_entry, str) and raw_entry:
                        items.append(raw_entry)
        return items


# ---------------------------------------------------------------------------
# _fail helper
# ---------------------------------------------------------------------------

def _fail(module_name: str, case_id: str, start_time: str, reason: str,
          coc_logger: Any, logger: logging.Logger) -> ModuleResult:
    if coc_logger is not None and _COC_AVAILABLE:
        try:
            coc_logger.log(EventType.MODULE_FAILED,
                           description=f"Module '{module_name}' failed: {reason}",
                           metadata={"module": module_name, "reason": reason})
        except Exception:
            pass
    logger.error("Module %s failed: %s", module_name, reason)
    return ModuleResult(
        module_name=module_name, case_id=case_id,
        status=ModuleStatus.FAILED,
        start_time=start_time, end_time=utc_now(),
        duration_seconds=0.0, findings=[], artifact_paths=[],
        errors=[reason], statistics={},
        summary=f"Module failed: {reason}",
        class_results=[ClassResult(
            locus=Locus.REGISTRY,
            artefact_class="Windows Registry Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_EVIDENCE,
            count=0,
        )],
    )
