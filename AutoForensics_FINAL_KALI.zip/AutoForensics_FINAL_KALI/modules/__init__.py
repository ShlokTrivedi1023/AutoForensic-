"""
modules/__init__.py — AutoForensics analysis modules package.

Each module in this package exposes a single ``run()`` entry point with a
consistent signature:

    run(
        evidence_path: Path,
        case_id: str,
        output_dir: Path,
        config: dict[str, Any],
        logger: logging.Logger,
        coc_logger: Any = None,
    ) -> ModuleResult

The orchestrator in ``core.main`` discovers and invokes modules dynamically.
All shared data structures (Finding, ModuleResult, Severity, ModuleStatus) are
defined in ``modules._base`` and re-exported here for convenience.
"""

from __future__ import annotations

from modules._base import (
    Finding,
    ModuleResult,
    ModuleStatus,
    Severity,
    make_finding,
    utc_now,
)

__all__ = [
    "Finding",
    "ModuleResult",
    "ModuleStatus",
    "Severity",
    "make_finding",
    "utc_now",
    "AVAILABLE_MODULES",
]

AVAILABLE_MODULES: list[str] = [
    "artifact_extractor",
    "bulk_extractor_scan",
    "clamav_scanner",
    "deleted_file_recovery",
    "dns_analyzer",
    "document_analyzer",
    "exiftool_metadata",
    "file_signature_analyzer",
    "foremost_carver",
    "geolocation_extractor",
    "hash_database_match",
    "hashcat_recovery",
    "http_reconstructor",
    "ioc_matcher",
    "john_recovery",
    "keyword_search",
    "memory_artifact_extractor",
    "memory_malware_scanner",
    "memory_network_connections",
    "memory_process_list",
    "memory_string_analyzer",
    "mobile_analyzer",
    "network_protocol_decoder",
    "ocr_text_extractor",
    "pcap_analyzer",
    "rootkit_detector",
    "scalpel_carver",
    "steganography_detector",
    "string_extractor",
    "suspicious_file_detector",
    "yara_scanner",
]
