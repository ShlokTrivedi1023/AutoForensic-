"""
modules/screenshot_capture.py

PIL-based forensic screenshot renderer.  Produces dark-themed PNG images from
terminal output (Method A) and structured table data (Method B) so every
module finding has photographic proof embedded in the PDF report.

Usage in a module's run() function:

    from modules.screenshot_capture import capture_terminal, capture_table, record_screenshot

    sc_dir = output_dir / "screenshots"
    sc_dir.mkdir(exist_ok=True)
    sc_idx = sc_dir / "screenshots_index.json"

    png = capture_terminal("fls output", stdout_text, sc_dir, "fig_3_1",
                           "Fig 3.1: fls recursive listing")
    if png:
        record_screenshot(sc_idx, "fig_3_1", png, "Fig 3.1: fls recursive listing")
"""

from __future__ import annotations

import json
import logging
import textwrap
from pathlib import Path
from typing import Any, Optional, Sequence

_logger = logging.getLogger("autoforensics.screenshot_capture")

# ---------------------------------------------------------------------------
# Colour palette (GitHub Dark theme)
# ---------------------------------------------------------------------------
_BG         = (13,  17,  23)     # #0D1117 — terminal background
_HEADER_BG  = (22,  27,  34)     # #161B22 — header band
_TEXT_FG    = (230, 237, 243)    # #E6EDF3 — primary text
_DIM_FG     = (139, 148, 158)    # #8B949E — dim / secondary
_CYAN_FG    = (88,  166, 255)    # #58A6FF — title / accent
_GREEN_FG   = (63,  185, 80)     # #3FB950 — success / prompt
_TBL_HDR    = (26,  39,  68)     # #1A2744 — table header row
_TBL_ALT    = (22,  27,  34)     # #161B22 — alternating table row
_TBL_BORDER = (48,  54,  61)     # #30363D — cell border

# PIL font size → approximate line height map
_LINE_HEIGHTS: dict[int, int] = {9: 14, 10: 15, 11: 17, 12: 18, 13: 20}

# ---------------------------------------------------------------------------
# PIL availability guard
# ---------------------------------------------------------------------------
try:
    from PIL import Image, ImageDraw, ImageFont
    _PIL = True
except ImportError:
    _PIL = False


def _pil_available() -> bool:
    return _PIL


# ---------------------------------------------------------------------------
# Font loader
# ---------------------------------------------------------------------------

def _load_font(size: int) -> Any:
    """Return a truetype monospace font, falling back to default."""
    if not _PIL:
        return None
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoMono-Regular.ttf",
        "C:/Windows/Fonts/consola.ttf",
        "C:/Windows/Fonts/cour.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except (OSError, AttributeError):
            continue
    try:
        return ImageFont.load_default()
    except Exception:
        return None


def _load_bold_font(size: int) -> Any:
    if not _PIL:
        return None
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
        "C:/Windows/Fonts/consolab.ttf",
        "C:/Windows/Fonts/courbd.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except (OSError, AttributeError):
            continue
    return _load_font(size)


# ---------------------------------------------------------------------------
# Text-bbox helper (compatible with all Pillow versions)
# ---------------------------------------------------------------------------

def _text_width(draw: Any, text: str, font: Any) -> int:
    try:
        bb = draw.textbbox((0, 0), text, font=font)
        return bb[2] - bb[0]
    except AttributeError:
        w, _ = draw.textsize(text, font=font)  # type: ignore[attr-defined]
        return w


def _text_height(draw: Any, text: str, font: Any) -> int:
    try:
        bb = draw.textbbox((0, 0), text, font=font)
        return bb[3] - bb[1]
    except AttributeError:
        _, h = draw.textsize(text, font=font)  # type: ignore[attr-defined]
        return h


# ---------------------------------------------------------------------------
# Method A — Terminal output renderer
# ---------------------------------------------------------------------------

def render_terminal(
    title: str,
    text: str,
    caption: str = "",
    max_lines: int = 60,
    char_width: int = 110,
    font_size: int = 11,
) -> Optional[bytes]:
    """Render CLI tool output as a dark-themed terminal PNG.

    Returns PNG bytes, or None if PIL unavailable.
    """
    if not _PIL:
        return None

    font      = _load_font(font_size)
    bold_font = _load_bold_font(font_size + 1)

    # Clamp and wrap lines
    raw_lines = text.splitlines()[:max_lines]
    lines: list[str] = []
    for raw in raw_lines:
        if len(raw) <= char_width:
            lines.append(raw)
        else:
            for chunk in textwrap.wrap(raw, char_width, break_long_words=True):
                lines.append(chunk)
    lines = lines[:max_lines]

    # Measure character cell
    dummy = Image.new("RGB", (1, 1))
    dd    = ImageDraw.Draw(dummy)
    ch_w  = max(_text_width(dd, "M", font), 1)
    ch_h  = max(_text_height(dd, "Mg", font), 1) + 3

    padding    = 16
    header_h   = 36
    footer_h   = 24 if caption else 0
    content_h  = ch_h * max(len(lines), 1)
    img_w      = ch_w * char_width + padding * 2
    img_h      = header_h + content_h + padding * 2 + footer_h

    img  = Image.new("RGB", (img_w, img_h), _BG)
    draw = ImageDraw.Draw(img)

    # Header band
    draw.rectangle([(0, 0), (img_w, header_h)], fill=_HEADER_BG)
    # Traffic-light dots
    for x, col in [(14, (236, 78, 67)), (34, (255, 189, 68)), (54, (40, 200, 64))]:
        draw.ellipse([(x - 6, header_h // 2 - 6), (x + 6, header_h // 2 + 6)], fill=col)
    draw.text((72, (header_h - ch_h) // 2), title,
              font=bold_font, fill=_CYAN_FG)

    # Prompt line
    y = header_h + padding
    prompt = f"root@kali:~# {title.lower().replace(' ', '_')}"
    draw.text((padding, y), prompt, font=font, fill=_GREEN_FG)
    y += ch_h

    # Content lines
    for line in lines:
        draw.text((padding, y), line, font=font, fill=_TEXT_FG)
        y += ch_h

    # Footer / caption
    if caption:
        draw.rectangle([(0, img_h - footer_h), (img_w, img_h)], fill=_HEADER_BG)
        draw.text((padding, img_h - footer_h + 4), caption,
                  font=_load_font(font_size - 1), fill=_DIM_FG)

    import io as _io
    buf = _io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Method B — Table renderer
# ---------------------------------------------------------------------------

def render_table(
    title: str,
    headers: list[str],
    rows: list[list[str]],
    caption: str = "",
    max_rows: int = 40,
    font_size: int = 10,
) -> Optional[bytes]:
    """Render a structured table as a dark-themed PNG.

    Returns PNG bytes, or None if PIL unavailable or no rows.
    """
    if not _PIL or not rows:
        return None

    rows    = [r for r in rows if r][:max_rows]
    ncols   = max(len(headers), max(len(r) for r in rows))
    headers = list(headers) + [""] * (ncols - len(headers))
    rows    = [list(r) + [""] * (ncols - len(r)) for r in rows]

    font      = _load_font(font_size)
    bold_font = _load_bold_font(font_size)

    padding   = 12
    header_h  = 34
    row_h     = font_size + 12
    footer_h  = 22 if caption else 0
    cell_pad  = 8

    dummy = Image.new("RGB", (1, 1))
    dd    = ImageDraw.Draw(dummy)

    # Calculate column widths based on content
    col_widths: list[int] = []
    for c in range(ncols):
        max_w = _text_width(dd, str(headers[c]), bold_font) + cell_pad * 2
        for r in rows:
            cw = _text_width(dd, str(r[c])[:80], font) + cell_pad * 2
            if cw > max_w:
                max_w = cw
        col_widths.append(max(max_w, 40))

    table_w = sum(col_widths)
    img_w   = table_w + padding * 2
    title_h = 28
    table_h = row_h * (1 + len(rows))   # header row + data rows
    img_h   = title_h + header_h + table_h + padding + footer_h

    img  = Image.new("RGB", (img_w, img_h), _BG)
    draw = ImageDraw.Draw(img)

    # Title band
    draw.rectangle([(0, 0), (img_w, title_h + header_h)], fill=_HEADER_BG)
    draw.text((padding, (title_h - (font_size + 4)) // 2), title,
              font=_load_bold_font(font_size + 1), fill=_CYAN_FG)

    # Column headers
    x = padding
    hdr_y = title_h
    for c, (hdr, cw) in enumerate(zip(headers, col_widths)):
        draw.rectangle([(x, hdr_y), (x + cw - 1, hdr_y + row_h - 1)],
                       fill=_TBL_HDR)
        draw.text((x + cell_pad, hdr_y + (row_h - (font_size + 2)) // 2),
                  str(hdr)[:80], font=bold_font, fill=_TEXT_FG)
        x += cw

    # Data rows
    for ri, row in enumerate(rows):
        y   = title_h + row_h * (ri + 1)
        bg  = _BG if ri % 2 == 0 else _TBL_ALT
        x   = padding
        for c, (cell, cw) in enumerate(zip(row, col_widths)):
            draw.rectangle([(x, y), (x + cw - 1, y + row_h - 1)], fill=bg)
            # Faint border
            draw.rectangle([(x, y), (x + cw - 1, y + row_h - 1)],
                           outline=_TBL_BORDER)
            txt = str(cell)[:80]
            draw.text((x + cell_pad, y + (row_h - (font_size + 2)) // 2),
                      txt, font=font, fill=_TEXT_FG)
            x += cw

    # Footer
    if caption:
        fy = img_h - footer_h
        draw.rectangle([(0, fy), (img_w, img_h)], fill=_HEADER_BG)
        draw.text((padding, fy + 4), caption,
                  font=_load_font(font_size - 1), fill=_DIM_FG)

    import io as _io
    buf = _io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# High-level capture functions
# ---------------------------------------------------------------------------

def capture_terminal(
    label: str,
    text: str,
    output_dir: Path,
    figure_id: str,
    caption: str = "",
    max_lines: int = 60,
) -> Optional[Path]:
    """Render terminal output to PNG and save in output_dir/figure_id.png."""
    if not text or not text.strip():
        return None
    png_bytes = render_terminal(
        title=label,
        text=text,
        caption=caption,
        max_lines=max_lines,
    )
    if not png_bytes:
        return None
    out_path = output_dir / f"{figure_id}.png"
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(png_bytes)
        return out_path
    except OSError as exc:
        _logger.warning("capture_terminal: could not save %s: %s", out_path, exc)
        return None


def capture_table(
    label: str,
    headers: list[str],
    rows: list[list[str]],
    output_dir: Path,
    figure_id: str,
    caption: str = "",
    max_rows: int = 40,
) -> Optional[Path]:
    """Render table data to PNG and save in output_dir/figure_id.png."""
    if not rows:
        return None
    png_bytes = render_table(
        title=label,
        headers=headers,
        rows=rows,
        caption=caption,
        max_rows=max_rows,
    )
    if not png_bytes:
        return None
    out_path = output_dir / f"{figure_id}.png"
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(png_bytes)
        return out_path
    except OSError as exc:
        _logger.warning("capture_table: could not save %s: %s", out_path, exc)
        return None


# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------

def record_screenshot(
    index_path: Path,
    figure_id: str,
    png_path: Path,
    caption: str,
) -> None:
    """Upsert a screenshot entry in screenshots_index.json."""
    try:
        if index_path.exists():
            existing: list[dict] = json.loads(index_path.read_text(encoding="utf-8"))
        else:
            existing = []
        # Remove any prior entry with same figure_id
        existing = [e for e in existing if e.get("figure_id") != figure_id]
        existing.append({
            "figure_id": figure_id,
            "path":      str(png_path),
            "caption":   caption,
        })
        index_path.write_text(
            json.dumps(existing, indent=2), encoding="utf-8"
        )
    except Exception as exc:
        _logger.warning("record_screenshot failed for %s: %s", figure_id, exc)
