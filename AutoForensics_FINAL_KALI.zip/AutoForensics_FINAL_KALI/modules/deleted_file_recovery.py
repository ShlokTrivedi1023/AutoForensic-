"""
deleted_file_recovery.py — Deleted file recovery module for AutoForensics.

Purpose
-------
This module recovers deleted files from a forensic disk image using two complementary
The Sleuth Kit tools:

  1. tsk_recover  — bulk extraction of both allocated and unallocated file data.
                    It writes every recoverable file to an output directory, preserving
                    directory structure where possible.

  2. fls -d       — lists only deleted directory entries, capturing the original
                    filename, inode number, and parent path.  Even when the file data
                    has been overwritten, fls may still see the directory entry.

  3. icat         — low-level inode data extractor used as a fallback to extract
                    individual files by inode number when tsk_recover did not already
                    recover them.

Tool selection rationale
------------------------
tsk_recover is the primary recovery tool because it handles both allocated (live) and
unallocated (deleted) data in a single pass and correctly handles complex cases like
journalled filesystems and reallocated inodes.

fls -d is used in addition because it provides the original filename and path for each
deleted entry, which tsk_recover may not always preserve.  Knowing the original path is
critical for establishing what a user deleted and when.

icat is used as a targeted complement: for any deleted file found by fls that tsk_recover
did not already extract, icat directly reads the inode's data blocks and writes a copy.

Forensic value
--------------
Deleted file recovery is one of the most forensically significant analysis steps.
Users attempting to conceal activity will delete incriminating files; recovery of those
files can reveal:
  - Deleted executable files (malware, exploit tools, scripts)
  - Deleted documents (exfiltration targets, contraband)
  - Deleted communication records (chat logs, email drafts)
  - Evidence of wiping tools (overwritten inodes, zero-byte entries)

Every recovered file is catalogued in a recovery_manifest.json that records the
original path, inode, MAC times, file size, and the path to the recovered copy.

Python version: 3.11+
Target OS     : Kali Linux
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
from pathlib import Path
from core.forensic_identity import deduplicate_deleted_findings
from typing import Any, Optional

from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason,
    _run_subprocess,
    _validate_icat_call,
    make_finding,
    utc_now,
)

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "deleted_file_recovery"

# tsk_recover on a multi-terabyte image can run for several hours; one hour is
# a reasonable maximum for typical forensic workstation hardware and image sizes.
TSK_RECOVER_TIMEOUT: int = 7200  # 2 hours — bulk extraction can be slow

# fls and icat are lighter operations; 30 minutes is generous.
FLS_TIMEOUT: int = 1800   # 30 minutes
ICAT_TIMEOUT: int = 300   # 5 minutes per file

# Maximum number of individual icat extractions to perform.
# Large images with thousands of deleted files would make icat extraction impractically
# slow; we cap it and note in statistics how many were skipped.
MAX_ICAT_EXTRACTIONS: int = 0  # zero = exhaustive fallback extraction

# File extensions considered "executable" for HIGH severity classification.
# This list covers common executable formats on Linux, Windows, and macOS.
EXECUTABLE_EXTENSIONS: frozenset[str] = frozenset({
    ".exe", ".dll", ".sys", ".drv", ".scr",   # Windows PE
    ".sh", ".bash", ".zsh", ".ksh", ".csh",   # Unix shell scripts
    ".py", ".pyc", ".pyo", ".pyd",             # Python
    ".pl", ".rb", ".php", ".js", ".vbs",       # Interpreted
    ".jar", ".class",                          # JVM
    ".elf", ".so", ".out",                     # Linux ELF
    ".dylib", ".app",                          # macOS
    ".ps1", ".psm1", ".psd1", ".bat", ".cmd",  # Windows scripting
    ".msi", ".msp", ".msu",                    # Windows installers
    ".deb", ".rpm",                            # Linux packages
})

# File extensions considered "documents" for MEDIUM severity classification.
DOCUMENT_EXTENSIONS: frozenset[str] = frozenset({
    ".doc", ".docx", ".dot", ".dotx",
    ".xls", ".xlsx", ".xlsm", ".csv",
    ".ppt", ".pptx", ".pps", ".ppsx",
    ".pdf", ".rtf", ".odt", ".ods", ".odp",
    ".txt", ".log", ".md", ".rst",
    ".eml", ".msg", ".mbox", ".pst", ".ost",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2",
    ".db", ".sqlite", ".sqlite3",
    ".html", ".htm", ".xml", ".json", ".yaml", ".yml",
    ".vcf", ".ics",
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".svg",
    ".mp4", ".avi", ".mkv", ".mov", ".wmv",
    ".mp3", ".wav", ".aac", ".flac",
})

# Magic bytes for file type identification
_MAGIC_SIGNATURES: list[tuple[bytes, str, str]] = [
    # PE executables
    (b"\x4d\x5a",             "executable", "PE/EXE/DLL"),
    # Office legacy OLE
    (b"\xd0\xcf\x11\xe0",    "document",   "Office OLE (doc/xls/ppt)"),
    # ZIP/OOXML/jar
    (b"\x50\x4b\x03\x04",    "document",   "ZIP/OOXML/docx/xlsx"),
    # PDF
    (b"\x25\x50\x44\x46",    "document",   "PDF"),
    # JPEG
    (b"\xff\xd8\xff",        "image",      "JPEG"),
    # PNG
    (b"\x89\x50\x4e\x47",    "image",      "PNG"),
    # GIF
    (b"\x47\x49\x46\x38",    "image",      "GIF"),
    # BMP
    (b"\x42\x4d",            "image",      "BMP"),
    # ELF (Linux executable)
    (b"\x7f\x45\x4c\x46",    "executable", "ELF"),
    # SQLite
    (b"\x53\x51\x4c\x69",    "database",   "SQLite"),
    # REGF (Windows registry hive)
    (b"\x72\x65\x67\x66",    "document",   "Registry Hive"),
    # mbox
    (b"\x46\x72\x6f\x6d\x20","document",   "mbox email"),
    # gzip
    (b"\x1f\x8b",            "archive",    "gzip"),
    # 7-zip
    (b"\x37\x7a\xbc\xaf",    "archive",    "7-Zip"),
]


def _detect_magic_type(file_path: Path) -> tuple[str, str]:
    """
    Read first 16 bytes and return (category, description).
    category: 'executable', 'document', 'image', 'database', 'archive', 'unknown'
    """
    try:
        with open(file_path, "rb") as f:
            header = f.read(16)
        for magic, category, desc in _MAGIC_SIGNATURES:
            if header[:len(magic)] == magic:
                return category, desc
    except OSError:
        pass
    return "unknown", ""


# ---------------------------------------------------------------------------
# Image type detection
# ---------------------------------------------------------------------------


def _detect_image_type(evidence_path: Path) -> Optional[str]:
    """
    Determine the image format from the file extension.

    tsk_recover requires an explicit ``-i <type>`` flag for Expert Witness Format
    (E01/Ex01) images because EWF is a container format that wraps the actual disk
    data.  Without the flag, TSK would try to interpret the EWF header as a raw
    sector stream and fail.

    Parameters
    ----------
    evidence_path : Resolved absolute path to the evidence file.

    Returns
    -------
    str | None
        The TSK image type string to pass as ``-i <type>``, or None for raw images
        (where no -i flag is needed).
    """
    ext = evidence_path.suffix.lower()

    # Expert Witness Format and its variants all use EWF libraries in TSK.
    if ext in (".e01", ".ex01", ".l01", ".lx01", ".s01", ".sx01"):
        return "ewf"

    # AFF and AFF4 are advanced forensic formats with their own TSK drivers.
    if ext in (".aff", ".aff4"):
        return "aff"

    # Raw / dd images need no -i flag.
    # .img, .dd, .raw, .bin, .iso, .dmg (when raw) are all treated as raw sector streams.
    return None


def _check_ewf_support(logger: logging.Logger) -> bool:
    """
    Verify that tsk_recover was compiled with EWF (Expert Witness Format) support.

    tsk_recover accepts ``-i list`` to print all supported image types.  If "ewf" is
    not in the output, the tool was built without libewf and E01 images cannot be
    processed directly — the analyst would need to use ewfmount first.

    Parameters
    ----------
    logger : Module logger.

    Returns
    -------
    bool
        True if EWF support is available, False otherwise.
    """
    try:
        rc, stdout, stderr = _run_subprocess(
            ["tsk_recover", "-i", "list"], timeout=15, logger=logger
        )
        output = (stdout + stderr).lower()
        return "ewf" in output
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


# ---------------------------------------------------------------------------
# tsk_recover
# ---------------------------------------------------------------------------


def _run_tsk_recover(
    analysis_path: Path,
    output_dir: Path,
    image_type: Optional[str],
    logger: logging.Logger,
    offset: int = 0,
) -> tuple[Path, bool, list[str]]:
    """
    Run ``tsk_recover -e`` on a raw analysis_path (ewf1 or block device).

    image_type is kept for signature compat but is no longer used for -i flag.
    analysis_path is always a raw file, so no -i ewf is needed.
    """
    import sys as _sys
    errors: list[str] = []
    recovered_dir = output_dir / "recovered"

    try:
        recovered_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        errors.append(f"Cannot create recovery directory {recovered_dir}: {exc}")
        return recovered_dir, False, errors

    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["tsk_recover"] + off + ["-e", str(analysis_path), str(recovered_dir)]

    try:
        rc, stdout, stderr = _run_subprocess(
            cmd, timeout=TSK_RECOVER_TIMEOUT, logger=logger
        )
    except subprocess.TimeoutExpired:
        errors.append(f"tsk_recover timed out after {TSK_RECOVER_TIMEOUT}s.")
        # The directory may still contain partially recovered files; report as partial.
        return recovered_dir, False, errors
    except FileNotFoundError:
        errors.append("tsk_recover binary not found; TSK may not be installed.")
        return recovered_dir, False, errors
    except OSError as exc:
        errors.append(f"tsk_recover OS error: {exc}")
        return recovered_dir, False, errors

    if rc != 0:
        errors.append(f"tsk_recover exited {rc}: {stderr[:500]}")
        # Non-zero exit may still mean partial recovery occurred.

    # Count recovered files to confirm output.
    try:
        recovered_count = sum(1 for _ in recovered_dir.rglob("*") if _.is_file())
        logger.info("tsk_recover extracted %d files to %s.", recovered_count, recovered_dir)
        success = recovered_count > 0 or rc == 0
    except OSError:
        success = rc == 0

    return recovered_dir, success, errors


# ---------------------------------------------------------------------------
# fls deleted-entry enumeration
# ---------------------------------------------------------------------------


# fls output line pattern for deleted files.
# The '*' deleted flag is MANDATORY — lines without it are live (allocated) entries.
# Format (plain):   <type_field> * <inode_triple>[ (realloc)]:  <path>
# Format (fls -l):  <type_field> * <inode_triple>[ (realloc)]:  <path>  <size> <mtime> <atime> <ctime> <crtime>
# Examples:
#   r/r * 14-128-3:    Users/bob/secret.docx
#   d/d * 21-128-1:    $OrphanFiles/file0.exe
#   -/r * 55-128-2 (realloc):   documents/report.pdf
_FLS_DELETED_RE = re.compile(
    r'^[\w/\-?]+\s+'                     # type field: r/r, d/d, r/-, -/r, v/v, ?/? etc.
    r'\*\s+'                             # DELETED flag — mandatory
    r'(?P<inode>\d+(?:-\d+-\d+)?)'       # inode: bare int (ext, e.g. 1698) OR NTFS
                                         # addr-type-id triple (e.g. 14-128-3). The
                                         # bare-int form was previously dropped.
    r'(?:\s+\(realloc\))?'               # optional (realloc) annotation
    r':\s*'                              # colon separator (allow trailing space)
    r'(?P<rest>.+)$',                    # everything after the colon
    re.DOTALL,
)

# Keep the old pattern name as an alias so existing call-sites in _run_fls_deleted
# that still reference _FLS_DELETED_PATTERN continue to work.
_FLS_DELETED_PATTERN = _FLS_DELETED_RE


def _parse_fls_deleted_line(line: str):
    """Parse one fls -rpd [-l] output line. Returns dict or None if not a deleted entry."""
    m = _FLS_DELETED_RE.match(line.strip())
    if not m:
        return None
    inode = m.group("inode")
    # Skip inode-0 entries — these are metadata inodes (not real deleted files)
    try:
        if int(inode.split("-")[0]) == 0:
            return None
    except (ValueError, IndexError):
        pass
    rest = m.group("rest").strip()
    # The long-listing format appends: <path>  <size> <mtime> <atime> <ctime> <crtime>
    # Try to split off the 5 trailing whitespace-separated tokens
    parts = rest.rsplit(None, 5)  # split from right: at most 5 splits
    path = rest
    size, mtime, atime, ctime, crtime = -1, "", "", "", ""
    if len(parts) == 6:
        # parts[-5:] might be the timestamp fields; verify size is numeric
        try:
            size = int(parts[1])
            path  = parts[0]
            mtime = parts[2]
            atime = parts[3]
            ctime = parts[4]
            crtime = parts[5]
        except (ValueError, IndexError):
            pass  # not long-listing; path stays as full rest
    return {
        "inode":  inode,
        "path":   path.strip(),
        "size":   size,
        "mtime":  mtime,
        "atime":  atime,
        "ctime":  ctime,
        "crtime": crtime,
    }


def _run_fls_deleted(
    analysis_path: Path,
    image_type: Optional[str],
    logger: logging.Logger,
    offset: int = 0,
) -> tuple[list[dict[str, str]], list[str]]:
    """
    Run ``fls -r -d`` on a raw analysis_path to enumerate deleted entries.

    image_type kept for signature compat but no -i flag is used for raw paths.
    The -r flag enables recursive traversal.

    fls can see directory entries even after the file data has been overwritten,
    because the directory entry (name, inode, timestamps) may persist in the
    directory block until that block is reused.  This means we can often recover
    the original filename even when the data is gone.

    Parameters
    ----------
    evidence_path : Resolved path to the forensic image.
    image_type    : TSK image type string for -i flag, or None.
    logger        : Module logger.

    Returns
    -------
    tuple[list[dict[str, str]], list[str]]
        (deleted_entries, errors)
        Each entry dict has keys: "inode", "path", "type_code" (r=file, d=dir).
    """
    deleted_entries: list[dict[str, str]] = []
    errors: list[str] = []

    # Build fls command — no -i flag (analysis_path is always raw).
    # FIX #7: add -l to capture size + 4 MAC timestamps per entry.
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["fls", "-r", "-d", "-l"] + off + [str(analysis_path)]

    try:
        rc, stdout, stderr = _run_subprocess(cmd, timeout=FLS_TIMEOUT, logger=logger)
    except subprocess.TimeoutExpired:
        errors.append(f"fls -d timed out after {FLS_TIMEOUT}s.")
        return deleted_entries, errors
    except FileNotFoundError:
        errors.append("fls binary not found.")
        return deleted_entries, errors

    if rc != 0:
        errors.append(f"fls -d exited {rc}: {stderr[:300]}")
        if not stdout.strip():
            return deleted_entries, errors

    # Parse each output line.
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue

        parsed = _parse_fls_deleted_line(line)
        if not parsed:
            # Some fls output lines are informational headers; skip them.
            logger.debug("fls line did not match expected pattern: %s", line[:120])
            continue

        # Derive type_code from the first character of the line (r=file, d=dir, etc.)
        type_code = line[0].lower() if line else "-"

        deleted_entries.append({
            "inode":     parsed["inode"],
            "path":      parsed["path"],
            "type_code": type_code,
            # FIX #7: four MAC timestamps as distinct fields (empty if -l unavailable)
            "mtime":  parsed["mtime"],
            "atime":  parsed["atime"],
            "ctime":  parsed["ctime"],
            "crtime": parsed["crtime"],
            "size":   parsed["size"],
        })

    logger.info("fls -d found %d deleted entries.", len(deleted_entries))
    return deleted_entries, errors


# ---------------------------------------------------------------------------
# icat extraction
# ---------------------------------------------------------------------------


def _extract_with_icat(
    analysis_path: Path,
    inode: str,
    output_path: Path,
    image_type: Optional[str],
    logger: logging.Logger,
    offset: int = 0,
) -> tuple[bool, list[str]]:
    """
    Extract a single file by inode number using ``icat`` on a raw analysis_path.

    icat reads the data blocks referenced by the given inode and writes them to
    stdout.  We capture stdout and write it to output_path.  This approach is used
    as a fallback for files that fls detected but tsk_recover did not extract.

    icat works even when the directory entry has been cleared, as long as the inode
    structure (and its data block pointers) is still intact in the filesystem.

    Parameters
    ----------
    evidence_path : Resolved path to the forensic image.
    inode         : Inode number string (may include a dash-suffix for NTFS, e.g. "42-128-1").
    output_path   : Where to write the extracted file data.
    image_type    : TSK image type string for -i flag, or None.
    logger        : Module logger.

    Returns
    -------
    tuple[bool, list[str]]
        (success, errors)
    """
    errors: list[str] = []

    # Build icat command — no -i flag (analysis_path is raw)
    import sys as _sys
    _sudo = []
    off = ["-o", str(offset)] if offset else []
    cmd = _sudo + ["icat"] + off + [str(analysis_path), inode]

    try:
        # We need raw bytes here because icat outputs binary file content.
        result = subprocess.run(
            cmd,
            shell=False,
            capture_output=True,
            timeout=ICAT_TIMEOUT,
            cwd=None,
        )
    except subprocess.TimeoutExpired:
        errors.append(f"icat timed out for inode {inode}.")
        return False, errors
    except FileNotFoundError:
        errors.append("icat binary not found.")
        return False, errors
    except OSError as exc:
        errors.append(f"icat OS error for inode {inode}: {exc}")
        return False, errors

    if result.returncode != 0:
        stderr_text = result.stderr.decode("utf-8", errors="replace")[:200]
        errors.append(f"icat exited {result.returncode} for inode {inode}: {stderr_text}")
        return False, errors

    if not result.stdout:
        # Zero-byte output could be a genuinely empty file or data wiped.
        logger.debug("icat returned zero bytes for inode %s.", inode)

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(result.stdout)
        logger.debug("icat extracted inode %s to %s (%d bytes).", inode, output_path, len(result.stdout))
        return True, errors
    except OSError as exc:
        errors.append(f"Failed to write icat output for inode {inode}: {exc}")
        return False, errors


# ---------------------------------------------------------------------------
# Recovery manifest
# ---------------------------------------------------------------------------


def _build_manifest_entry(
    original_path: str,
    inode: str,
    type_code: str,
    recovered_path: Optional[str],
    source: str,
    size_bytes: int = -1,
) -> dict[str, Any]:
    """
    Build a single manifest record for a recovered or catalogued file.

    Parameters
    ----------
    original_path  : The original path of the file within the filesystem.
    inode          : Inode number string.
    type_code      : Entry type: 'r' = file, 'd' = directory, '-' = unknown.
    recovered_path : Absolute path to the extracted file on disk, or None.
    source         : How the entry was found: "tsk_recover", "fls", or "icat".
    size_bytes     : Size of the recovered file in bytes (-1 if unknown).

    Returns
    -------
    dict[str, Any]
        Manifest record dict.
    """
    return {
        "original_path": original_path,
        "inode": inode,
        "type": "file" if type_code == "r" else ("directory" if type_code == "d" else "unknown"),
        "recovered_path": recovered_path,
        "source": source,
        "size_bytes": size_bytes,
        "timestamp": utc_now(),
    }


# ---------------------------------------------------------------------------
# Finding severity classifier
# ---------------------------------------------------------------------------


def _classify_severity(file_path: str, recovered_path: Optional[str] = None) -> tuple[Severity, str]:
    """
    Assign severity from magic bytes (if file was extracted) or extension fallback.
    Returns (Severity, rationale_string).

    Executables are HIGH priority because they may represent malware, exploit tools,
    or scripted attack payloads.  Documents are MEDIUM because they may be exfiltration
    targets or contain contraband.  Everything else is LOW.

    Parameters
    ----------
    file_path      : The original path or filename of the recovered file.
    recovered_path : Path to the extracted file on disk, used for magic byte detection.

    Returns
    -------
    tuple[Severity, str]
        (severity, rationale_string)
    """
    # Try magic bytes first (most reliable)
    if recovered_path:
        magic_cat, magic_desc = _detect_magic_type(Path(recovered_path))
        if magic_cat == "executable":
            return Severity.HIGH, f"executable by magic ({magic_desc})"
        if magic_cat in ("document", "database"):
            return Severity.MEDIUM, f"document by magic ({magic_desc})"
        if magic_cat == "image":
            return Severity.MEDIUM, f"image by magic ({magic_desc})"
        if magic_cat == "archive":
            return Severity.MEDIUM, f"archive by magic ({magic_desc})"

    # Extension fallback
    ext = Path(file_path).suffix.lower()
    if ext in EXECUTABLE_EXTENSIONS:
        return Severity.HIGH, "executable by extension"
    if ext in DOCUMENT_EXTENSIONS:
        return Severity.MEDIUM, "document by extension"
    return Severity.LOW, "other"


# ---------------------------------------------------------------------------
# Chain-of-custody logger helper
# ---------------------------------------------------------------------------


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    """
    Emit a chain-of-custody log entry if a coc_logger is provided.

    Parameters
    ----------
    coc_logger : Any logger object with an .info() method, or None.
    event      : Event name string.
    details    : Structured context dict.
    """
    if coc_logger is None:
        return
    try:
        coc_logger.info(
            "COC_EVENT: %s | %s",
            event,
            " | ".join(f"{k}={v}" for k, v in details.items()),
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Recovery helpers
# ---------------------------------------------------------------------------


def _count_recovered_files(recovered_dir) -> int:
    """Count files actually written by tsk_recover."""
    from pathlib import Path as _Path
    rd = _Path(recovered_dir)
    if not rd.is_dir():
        return 0
    return sum(1 for _ in rd.rglob("*") if _.is_file())


# Zero means exhaustive finding enumeration. A positive caller-supplied cap is
# allowed only as an explicit resource-control mode and must not be represented
# as exhaustive coverage.
MAX_RECOVERED_FINDINGS: int = 0


def _findings_from_recovered_corpus(
    recovered_dir,
    evidence_path,
    logger: logging.Logger,
    *,
    exclude_paths: "Optional[set[str]]" = None,
    cap: int = MAX_RECOVERED_FINDINGS,
) -> list:
    """
    Derive DELETED_FILE_RECOVERED findings from the tsk_recover output tree.

    tsk_recover ``-e`` writes every recovered file under ``recovered_dir``,
    preserving the original directory structure.  This is the authoritative
    record of what was recovered — far more reliable than re-parsing the
    brittle ``fls -d`` text output.  One finding is produced per recovered
    file, severity-classified from magic bytes / extension.

    Parameters
    ----------
    recovered_dir : Directory tsk_recover extracted into.
    evidence_path : Resolved forensic image path (recorded on each finding).
    logger        : Module logger.
    exclude_paths : POSIX-relative original paths already represented by an
                    fls-derived finding; skipped here to avoid double-counting
                    the same logical file.
    cap           : Maximum number of findings to enumerate.

    Returns
    -------
    list[Finding]
        One DELETED_FILE_RECOVERED finding per (non-excluded) recovered file.
    """
    exclude_paths = exclude_paths or set()
    findings: list = []
    rd = Path(recovered_dir)
    if not rd.is_dir():
        return findings

    for f in sorted(rd.rglob("*")):
        if not f.is_file():
            continue
        try:
            rel = f.relative_to(rd).as_posix()
        except ValueError:
            rel = f.name
        if rel in exclude_paths:
            continue
        if cap > 0 and len(findings) >= cap:
            logger.warning(
                "recovered-corpus finding cap of %d reached; caller requested "
                "non-exhaustive finding enumeration.", cap,
            )
            break

        recovered_path_str = str(f.resolve())
        severity, sev_rationale = _classify_severity(rel, recovered_path_str)
        magic_cat, magic_desc = _detect_magic_type(f)
        try:
            size_bytes = f.stat().st_size
        except OSError:
            size_bytes = -1

        findings.append(make_finding(
            finding_type="DELETED_FILE_RECOVERED",
            severity=severity,
            description=(
                f"Deleted file recovered by tsk_recover: '{rel}' "
                f"(ext={Path(rel).suffix.lower()!r}, "
                f"magic={magic_desc or 'unknown'}, source=tsk_recover)"
            ),
            evidence_path=rel,
            artifact_path=recovered_path_str,
            metadata={
                "original_path":      rel,
                "extension":          Path(rel).suffix.lower(),
                "magic_category":     magic_cat,
                "magic_description":  magic_desc,
                "severity_rationale": sev_rationale,
                "recovery_source":    "tsk_recover",
                "size_bytes":         size_bytes,
            },
        ))

    return findings


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Run deleted file recovery against a forensic disk image.

    Execution sequence:
      1. Detect image type from extension; check EWF support if applicable.
      2. Run tsk_recover -e to extract all recoverable files.
      3. Run fls -r -d to enumerate deleted directory entries.
      4. For deleted entries not already extracted by tsk_recover, run icat.
      5. Build recovery_manifest.json cataloguing every recovered file.
      6. Generate Finding objects per recovered file, severity-classified by extension.
      7. Return ModuleResult with statistics and all artifact paths.

    Parameters
    ----------
    evidence_path : Path to the forensic image (.img, .dd, .raw, .E01, etc.).
                    Resolved to absolute path before use.
    case_id       : Unique case identifier string.
    output_dir    : Directory for module output.  Will be created if absent.
    config        : Configuration dict.  Recognised keys:
                      "max_icat_extractions" (int) — override MAX_ICAT_EXTRACTIONS.
                      "skip_icat" (bool)           — disable icat fallback extraction.
    logger        : Standard library Logger instance.
    coc_logger    : Optional chain-of-custody logger.

    Returns
    -------
    ModuleResult
        status COMPLETED: tsk_recover ran and fls was parsed.
        status PARTIAL  : one of the above failed but the other succeeded.
        status FAILED   : both tsk_recover and fls failed.
        status SKIPPED  : evidence_path does not exist.
    """
    start_time = utc_now()
    start_ts = time.monotonic()

    # Resolve paths to absolute before passing to any external tool.
    evidence_path = evidence_path.resolve()
    output_dir = output_dir.resolve()

    all_findings: list[Any] = []
    all_artifact_paths: list[str] = []
    all_errors: list[str] = []
    manifest_entries: list[dict[str, Any]] = []

    statistics: dict[str, Any] = {
        "total_recovered": 0,
        "deleted_found": 0,
        "executables_found": 0,
        "documents_found": 0,
        "other_found": 0,
        "icat_extractions": 0,
        "icat_failures": 0,
    }

    tsk_recover_success = False
    fls_success = False

    _log_coc(
        coc_logger,
        "MODULE_STARTED",
        {"module": MODULE_NAME, "case_id": case_id, "evidence": str(evidence_path), "timestamp": start_time},
    )
    logger.info("Module %s started for case %s, evidence: %s", MODULE_NAME, case_id, evidence_path)

    # Pre-condition check.
    if not evidence_path.exists():
        msg = f"Evidence file not found: {evidence_path}"
        logger.error(msg)
        end_time = utc_now()
        _log_coc(coc_logger, "MODULE_FAILED", {"module": MODULE_NAME, "reason": msg})
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=time.monotonic() - start_ts,
            errors=[msg],
            summary=f"SKIPPED — evidence file not found: {evidence_path}",
            class_results=[ClassResult(
                locus=Locus.DELETED_FILES,
                artefact_class="Deleted File Records",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE,
                count=0,
            )],
        )

    # Ensure output directory exists.
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        all_errors.append(f"Cannot create output directory {output_dir}: {exc}")

    # Primary native path: the orchestrator has already parsed the filesystem
    # and published deleted-file output. External TSK tools remain only as a
    # legacy/verification fallback when no native corpus is supplied.
    _ws = config.get("_working_set", {})
    _native_deleted_raw = _ws.get("native_deleted_root")
    _native_deleted = Path(_native_deleted_raw) if _native_deleted_raw else None
    if _native_deleted is not None and _native_deleted.is_dir():
        _native_manifest_path = _native_deleted.parent / "native_filesystem_manifest.json"
        _native_manifest = {}
        try:
            _native_manifest = json.loads(_native_manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
        _deleted_records = [f for f in _native_manifest.get("files", []) if f.get("deleted")]
        _record_by_output = {str(f.get("extracted_path") or ""): f for f in _deleted_records}
        for _path in sorted(_native_deleted.rglob("*")):
            if not _path.is_file():
                continue
            _record = _record_by_output.get(str(_path), {})
            _original = str(_record.get("path") or _path.name)
            _status = str(_record.get("recovery_status") or "recovered")
            _severity, _rationale = _classify_severity(_original, str(_path))
            all_artifact_paths.append(str(_path.resolve()))
            _size = int(_record.get("size_bytes") or _path.stat().st_size)
            _sha256 = str(_record.get("sha256") or _sha256_file(_path))
            all_findings.append(make_finding(
                finding_type="DELETED_FILE_RECOVERED",
                severity=_severity,
                description=(
                    f"Deleted file recovered natively from its filesystem record/cluster "
                    f"chain: '{_original}' ({_size} bytes; SHA-256={_sha256}; "
                    f"status={_status}). No tsk_recover/icat dependency was used."
                ),
                evidence_path=_original, artifact_path=str(_path.resolve()),
                metadata={
                    **_record, "original_path": _original,
                    "recovery_source": "native_filesystem_parser",
                    "recovery_status": _status, "severity_rationale": _rationale,
                    "size_bytes": _size, "sha256": _sha256,
                },
            ))
        # Include metadata-only deleted records, including overwritten/reallocated
        # files whose original bytes can no longer be trusted or recovered.
        _represented = {str(f.metadata.get("original_path")) for f in all_findings}
        for _record in _deleted_records:
            _original = str(_record.get("path") or "unknown")
            if _original in _represented:
                continue
            _status = str(_record.get("recovery_status") or "not_recoverable")
            all_findings.append(make_finding(
                finding_type="DELETED_FILE_RECORD", severity=Severity.LOW,
                description=(
                    f"Deleted directory record found natively for '{_original}', "
                    f"but content status is {_status}."
                ),
                evidence_path=_original, metadata={
                    **_record, "original_path": _original,
                    "recovery_source": "native_filesystem_parser",
                },
            ))
        all_findings, duplicate_representations = deduplicate_deleted_findings(all_findings)
        duplicate_ledger = output_dir / "duplicate_representations.json"
        duplicate_ledger.write_text(json.dumps(duplicate_representations, indent=2), encoding="utf-8")
        all_artifact_paths.append(str(duplicate_ledger))
        statistics["duplicate_representations"] = len(duplicate_representations)
        statistics["unique_deleted_artifacts"] = len({f.metadata.get("forensic_identity") for f in all_findings if str(f.finding_type).startswith("DELETED_")})
        statistics["total_recovered"] = sum(
            1 for f in all_findings if f.finding_type == "DELETED_FILE_RECOVERED"
        )
        statistics["deleted_found"] = len(_deleted_records)
        statistics["native_recovery"] = True
        statistics["execution_outcome"] = (
            "ran_found_x" if _deleted_records else "ran_found_nothing"
        )
        _manifest_out = output_dir / "recovery_manifest.json"
        _recovered_evidence_files = sorted({
            str(f.artifact_path) for f in all_findings
            if f.finding_type == "DELETED_FILE_RECOVERED" and f.artifact_path and Path(str(f.artifact_path)).is_file()
        })
        _manifest_out.write_text(json.dumps({
            "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
            "execution_outcome": statistics["execution_outcome"],
            "recovery_source": "native_filesystem_parser",
            "deleted_records": _deleted_records,
            "recovered_evidence_files": _recovered_evidence_files,
            "recovery_control_files": [str(duplicate_ledger)],
            "exported_recovery_copies": [],
            "duplicate_representation_records": duplicate_representations,
            "external_tools_required": False,
        }, indent=2, default=str), encoding="utf-8")
        all_artifact_paths.append(str(_manifest_out))
        _verdict = AssuranceVerdict.PRESENT if _deleted_records else AssuranceVerdict.VERIFIED_ABSENT
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.COMPLETED,
            start_time=start_time, end_time=utc_now(), duration_seconds=time.monotonic()-start_ts,
            findings=all_findings, artifact_paths=all_artifact_paths, errors=[],
            statistics=statistics,
            summary=(
                f"RAN AND FOUND {len(_deleted_records)} deleted record(s); "
                f"{statistics['total_recovered']} file(s) recovered natively."
                if _deleted_records else
                "RAN AND FOUND NOTHING — native deleted-entry scan completed."
            ),
            class_results=[ClassResult(
                locus=Locus.DELETED_FILES, artefact_class="Deleted File Records",
                verdict=_verdict, count=len(_deleted_records),
            )],
        )

    # Use the mounted ewf1 path (or raw device) injected by the orchestrator.
    # analysis_path is always raw — never an .E01 directly, so no -i ewf needed.
    analysis_path    = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", 0))
    image_type       = None  # raw/block file; no TSK image-type flag required
    statistics["image_type"] = "raw (mounted)" if analysis_path != evidence_path else "raw"
    logger.info("Deleted file recovery: analysis_path=%s offset=%d", analysis_path, partition_offset)

    # -----------------------------------------------------------------------
    # Step 1: tsk_recover -e (bulk recovery)
    # -----------------------------------------------------------------------
    logger.info("Running tsk_recover -e …")
    recovered_dir, tsk_recover_success, tsk_errors = _run_tsk_recover(
        analysis_path, output_dir, image_type, logger,
        offset=partition_offset,
    )
    all_errors.extend(tsk_errors)

    # Build a set of inodes already recovered by tsk_recover.
    # We do this by walking the recovered directory and collecting filenames that
    # tsk_recover may have named after inodes (e.g. f0000042.dat).
    # This is a best-effort heuristic; tsk_recover doesn't always use inode-based names.
    already_recovered_names: set[str] = set()
    if recovered_dir.exists():
        try:
            for recovered_file in recovered_dir.rglob("*"):
                if recovered_file.is_file():
                    all_artifact_paths.append(str(recovered_file.resolve()))
                    already_recovered_names.add(recovered_file.name.lower())
                    statistics["total_recovered"] += 1
        except OSError as exc:
            all_errors.append(f"Error walking recovered directory: {exc}")

    logger.info("tsk_recover extracted %d files.", statistics["total_recovered"])

    # -----------------------------------------------------------------------
    # Step 2: fls -r -d (deleted entry enumeration)
    # -----------------------------------------------------------------------
    logger.info("Running fls -r -d to enumerate deleted entries …")
    deleted_entries, fls_errors = _run_fls_deleted(analysis_path, image_type, logger,
                                                     offset=partition_offset)
    all_errors.extend(fls_errors)
    fls_success = len(deleted_entries) > 0 or not fls_errors
    # Track fls outcome for ClassResult verdict
    _fls_not_found = any("fls binary not found" in e for e in fls_errors)
    _fls_errored   = bool(fls_errors) and not _fls_not_found

    statistics["deleted_found"] = len(deleted_entries)
    statistics["deleted_files_enumerated"] = len(deleted_entries)
    statistics["files_recovered_by_tsk_recover"] = _count_recovered_files(recovered_dir)

    # -----------------------------------------------------------------------
    # Step 3: icat fallback extraction for files not covered by tsk_recover
    # -----------------------------------------------------------------------
    max_icat = int(config.get("max_icat_extractions", MAX_ICAT_EXTRACTIONS) or 0)
    skip_icat = config.get("skip_icat", False)
    icat_count = 0
    icat_limit_reached = False
    deleted_regular_entries_unextracted = 0

    icat_dir = output_dir / "icat_extracted"
    if not skip_icat and deleted_entries:
        try:
            icat_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            all_errors.append(f"Cannot create icat directory: {exc}")
            skip_icat = True

    # -----------------------------------------------------------------------
    # Step 4: Catalogue all deleted entries and build findings
    # -----------------------------------------------------------------------
    for entry in deleted_entries:
        original_path = entry["path"]
        inode = entry["inode"]
        type_code = entry["type_code"]

        # Only process regular files (not directories) for icat extraction.
        if type_code != "r":
            manifest_entries.append(
                _build_manifest_entry(original_path, inode, type_code, None, "fls")
            )
            continue

        # Determine whether this file should be extracted with icat.
        recovered_path_str: Optional[str] = None
        icat_source = "fls_only"

        if not skip_icat and (max_icat <= 0 or icat_count < max_icat):
            # Guard: skip icat for inode 0 and other metadata inodes.
            if not _validate_icat_call(inode, str(analysis_path), logger):
                icat_source = "invalid_or_metadata_inode_not_extracted"
                deleted_regular_entries_unextracted += 1
            else:

                # Construct a safe output filename: sanitise the original path so it
                # is a valid filesystem path under icat_dir.
                safe_name = re.sub(r"[^\w.\-]", "_", os.path.basename(original_path))
                if not safe_name:
                    safe_name = f"inode_{inode}"
                icat_out = icat_dir / f"{inode}_{safe_name}"

                # Don't extract if the file already exists from a previous run.
                if not icat_out.exists():
                    success, icat_errors = _extract_with_icat(
                        analysis_path, inode, icat_out, image_type, logger,
                        offset=partition_offset,
                    )
                    all_errors.extend(icat_errors)

                    if success:
                        recovered_path_str = str(icat_out.resolve())
                        all_artifact_paths.append(recovered_path_str)
                        statistics["icat_extractions"] += 1
                        icat_source = "icat"
                    else:
                        statistics["icat_failures"] += 1
                else:
                    # File already extracted in a previous run.
                    recovered_path_str = str(icat_out.resolve())
                    icat_source = "icat_cached"

                icat_count += 1
        elif max_icat > 0 and icat_count >= max_icat:
            icat_limit_reached = True
            deleted_regular_entries_unextracted += 1
            icat_source = "fls_only_configured_icat_limit"
            if icat_count == max_icat:
                logger.warning(
                    "icat extraction cap of %d reached; remaining deleted files will "
                    "be catalogued but explicitly marked unresolved for content recovery.", max_icat
                )
                icat_count += 1  # suppress repeated warning while retaining the cap state
        elif skip_icat:
            deleted_regular_entries_unextracted += 1
            icat_source = "fls_only_icat_disabled"

        # Determine severity for this file.
        severity, sev_rationale = _classify_severity(original_path, recovered_path_str)

        if severity == Severity.HIGH:
            statistics["executables_found"] += 1
        elif severity == Severity.MEDIUM:
            if "image" in sev_rationale:
                statistics.setdefault("images_found", 0)
                statistics["images_found"] += 1
            else:
                statistics["documents_found"] += 1
        else:
            statistics["other_found"] += 1

        # Add to manifest.
        size_bytes = -1
        if recovered_path_str:
            try:
                size_bytes = Path(recovered_path_str).stat().st_size
            except OSError:
                pass

        manifest_entries.append(
            _build_manifest_entry(
                original_path, inode, type_code, recovered_path_str, icat_source, size_bytes
            )
        )

        # Create Finding.
        magic_cat, magic_desc = _detect_magic_type(Path(recovered_path_str)) if recovered_path_str else ("unknown", "")
        _recovered = bool(recovered_path_str)
        all_findings.append(
            make_finding(
                finding_type=("DELETED_FILE_RECOVERED" if _recovered else "DELETED_FILE_RECORD"),
                severity=severity,
                description=(
                    (f"Deleted file recovered: '{original_path}' " if _recovered else f"Deleted file record catalogued without recovered content: '{original_path}' ")
                    + f"(inode={inode}, ext={Path(original_path).suffix.lower()!r}, "
                    + f"magic={magic_desc or 'unknown'}, source={icat_source})"
                ),
                evidence_path=original_path,
                artifact_path=recovered_path_str,
                metadata={
                    "inode":             inode,
                    "original_path":     original_path,
                    "extension":         Path(original_path).suffix.lower(),
                    "magic_category":    magic_cat,
                    "magic_description": magic_desc,
                    "severity_rationale": sev_rationale,
                    "recovery_source":   icat_source,
                    "content_recovered": _recovered,
                    "recovery_status":   ("RECOVERED" if _recovered else "UNRESOLVED_CONTENT"),
                    "size_bytes":        size_bytes,
                    # FIX #7: per-file provenance — four MAC timestamps
                    "mtime":  entry.get("mtime",  ""),
                    "atime":  entry.get("atime",  ""),
                    "ctime":  entry.get("ctime",  ""),
                    "crtime": entry.get("crtime", ""),
                },
            )
        )

    # -----------------------------------------------------------------------
    # Step 4b: Derive findings from the tsk_recover corpus (source of truth)
    # -----------------------------------------------------------------------
    # tsk_recover -e is the authoritative recovery: it writes every recovered
    # file to disk (this run recovered ~1698).  The brittle fls -d text parse
    # must never suppress a real recovery, so we enumerate the recovered corpus
    # directly and add one finding per recovered file that an fls-derived
    # finding does not already represent (deduped by original path).
    _fls_original_paths = {
        (f.metadata.get("original_path") or "").strip()
        for f in all_findings
    }
    _corpus_findings = _findings_from_recovered_corpus(
        recovered_dir, evidence_path, logger,
        exclude_paths=_fls_original_paths,
    )
    all_findings.extend(_corpus_findings)
    for _cf in _corpus_findings:
        if _cf.severity == Severity.HIGH:
            statistics["executables_found"] += 1
        elif _cf.severity == Severity.MEDIUM:
            statistics["documents_found"] += 1
        else:
            statistics["other_found"] += 1

    # Stable identity prevents exported aliases and carved copies from inflating
    # the unique deleted-artefact count.
    all_findings, duplicate_representations = deduplicate_deleted_findings(all_findings)
    duplicate_ledger = output_dir / "duplicate_representations.json"
    duplicate_ledger.write_text(json.dumps(duplicate_representations, indent=2), encoding="utf-8")
    all_artifact_paths.append(str(duplicate_ledger))
    statistics["duplicate_representations"] = len(duplicate_representations)
    statistics["unique_deleted_artifacts"] = len({f.metadata.get("forensic_identity") for f in all_findings if str(f.finding_type).startswith("DELETED_")})

    statistics["icat_limit_configured"] = max_icat
    statistics["icat_limit_reached"] = icat_limit_reached
    statistics["deleted_regular_entries_unextracted"] = deleted_regular_entries_unextracted
    statistics["unresolved_supported_objects"] = deleted_regular_entries_unextracted + int(statistics.get("icat_failures", 0) or 0)
    if icat_limit_reached:
        all_errors.append(
            f"Configured max_icat_extractions={max_icat} prevented exhaustive deleted-file fallback extraction."
        )
    if skip_icat and deleted_regular_entries_unextracted:
        all_errors.append(
            "icat fallback extraction was disabled while deleted regular-file records required content recovery."
        )

    # -----------------------------------------------------------------------
    # Step 5: Write recovery_manifest.json
    # -----------------------------------------------------------------------
    manifest_path = output_dir / "recovery_manifest.json"
    manifest_data: dict[str, Any] = {
        "case_id": case_id,
        "module": MODULE_NAME,
        "evidence_path": str(evidence_path),
        "generated_at": utc_now(),
        "statistics": statistics,
        "entries": manifest_entries,
        "recovered_evidence_files": sorted({
            str(f.artifact_path) for f in all_findings
            if f.finding_type == "DELETED_FILE_RECOVERED" and f.artifact_path and Path(str(f.artifact_path)).is_file()
        }),
        "recovery_control_files": [str(duplicate_ledger)],
        "exported_recovery_copies": sorted({str(p) for p in recovered_dir.rglob("*") if p.is_file()}),
        "duplicate_representation_records": duplicate_representations,
    }

    try:
        manifest_path.write_text(
            json.dumps(manifest_data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        all_artifact_paths.append(str(manifest_path.resolve()))
        logger.info("Recovery manifest written to %s.", manifest_path)
    except OSError as exc:
        all_errors.append(f"Failed to write recovery manifest: {exc}")

    # -----------------------------------------------------------------------
    # Determine status
    # -----------------------------------------------------------------------
    if tsk_recover_success and fls_success:
        status = ModuleStatus.COMPLETED if not all_errors else ModuleStatus.PARTIAL
    elif tsk_recover_success or fls_success:
        status = ModuleStatus.PARTIAL
    else:
        status = ModuleStatus.FAILED

    summary = (
        f"{MODULE_NAME}: {status.value} — "
        f"{statistics['total_recovered']} files recovered by tsk_recover, "
        f"{statistics['deleted_found']} deleted entries found by fls, "
        f"{statistics['executables_found']} executables (HIGH), "
        f"{statistics['documents_found']} documents (MEDIUM), "
        f"{statistics['other_found']} other (LOW)."
    )

    end_time = utc_now()
    duration = time.monotonic() - start_ts

    _log_coc(
        coc_logger,
        "MODULE_COMPLETED" if status != ModuleStatus.FAILED else "MODULE_FAILED",
        {
            "module": MODULE_NAME,
            "case_id": case_id,
            "status": status.value,
            "findings": len(all_findings),
            "duration_seconds": f"{duration:.2f}",
            "timestamp": end_time,
        },
    )

    logger.info(
        "Module %s finished: status=%s, findings=%d, duration=%.2fs",
        MODULE_NAME,
        status.value,
        len(all_findings),
        duration,
    )

    # The deleted-files total is the true recovered count: max of the enumerated
    # findings and the tsk_recover corpus size (the latter wins when the finding
    # list was capped, so count still reports e.g. 1698 rather than the cap).
    recovered_total = int(statistics.get("total_recovered", 0) or 0)
    _deleted_total = int(statistics.get("unique_deleted_artifacts", 0) or 0)
    if _deleted_total == 0:
        _deleted_total = max(len(all_findings), recovered_total)

    if _deleted_total > 0:
        # tsk_recover recovered files and/or fls enumerated deleted entries —
        # deleted data is demonstrably PRESENT regardless of fls parse quirks.
        _del_verdict   = AssuranceVerdict.PRESENT
        _del_skip      = None
    elif _fls_not_found:
        _del_verdict   = AssuranceVerdict.INDETERMINATE
        _del_skip      = SkipReason.DEPENDENCY_MISSING
    elif _fls_errored:
        _del_verdict   = AssuranceVerdict.INDETERMINATE
        _del_skip      = SkipReason.PARTIAL_FAILURE
    else:
        _del_verdict   = AssuranceVerdict.VERIFIED_ABSENT
        _del_skip      = None

    _del_cr = ClassResult(
        locus=Locus.DELETED_FILES,
        artefact_class="Deleted File Records",
        verdict=_del_verdict,
        skip_reason=_del_skip,
        count=_deleted_total,
    )

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=round(duration, 3),
        findings=all_findings,
        artifact_paths=all_artifact_paths,
        errors=all_errors,
        statistics=statistics,
        summary=summary,
        class_results=[_del_cr],
    )
