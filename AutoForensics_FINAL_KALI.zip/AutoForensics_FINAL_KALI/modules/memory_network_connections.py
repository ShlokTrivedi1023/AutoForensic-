"""
memory_network_connections.py — Memory Network Connection Extractor for AutoForensics.

Uses Volatility 3 to extract active and historical network connections from a
memory dump.  Two plugins are tried:

  windows.netstat.NetStat   — reads kernel socket tracking structures
  windows.netscan.NetScan   — pool-tag scan for connection objects (finds more)

Suspicious indicators include processes that should never have network access,
connections to unusual ports, and backdoor-associated port numbers.

Target platform : Kali Linux, Python 3.11+
External tools  : python3 /opt/volatility3/vol.py (Volatility 3)
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    assert_subprocess_ok,
    find_memory_source,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

MODULE_NAME: str = "memory_network_connections"
VOL_TIMEOUT: int = 3600

# Processes that should never initiate external network connections
_NO_NETWORK_PROCESSES: frozenset[str] = frozenset({
    "lsass.exe", "lsm.exe", "wininit.exe", "smss.exe",
    "csrss.exe", "winlogon.exe", "services.exe",
})

# Common malware / C2 ports
_SUSPICIOUS_PORTS: frozenset[int] = frozenset({
    4444, 4445, 4446, 4447,    # Meterpreter defaults
    1337, 31337,                # l33t/Elite backdoor ports
    8888, 9999, 6666, 7777,    # Common reverse shell ports
    1604, 1723,                 # Some VPN / older backdoors
    65535, 65000, 64000,        # High ports used by malware
    12345, 54321,               # Classic backdoor ports
})


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _parse_vol_tsv(output: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    headers: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("Volatility"):
            continue
        parts = stripped.split("\t")
        if not headers:
            headers = [h.strip() for h in parts]
            continue
        if len(parts) < len(headers):
            parts.extend([""] * (len(headers) - len(parts)))
        rows.append(dict(zip(headers, [p.strip() for p in parts])))
    return rows


def _run_vol_plugin(
    vol_path: str,
    evidence_path: Path,
    plugin: str,
    logger: logging.Logger,
) -> tuple[int, str, str]:
    """
    Run a Volatility 3 plugin and return (returncode, stdout, stderr).

    Parameters
    ----------
    vol_path      : Path to vol.py.
    evidence_path : Memory dump path.
    plugin        : Volatility plugin name.
    logger        : Module logger.

    Returns
    -------
    Tuple of (returncode, stdout, stderr).

    Raises
    ------
    FileNotFoundError       If python3 or vol.py is not found.
    subprocess.TimeoutExpired  If the plugin exceeds VOL_TIMEOUT.
    """
    execution = run_volatility_plugin(
        evidence_path=evidence_path, plugin=plugin,
        config={"vol_path": vol_path}, timeout=VOL_TIMEOUT,
    )
    logger.debug("Volatility command: %s", execution.command)
    return execution.returncode, execution.stdout, execution.stderr


def _port_from_str(addr_port: str) -> int:
    """Extract port number from 'ip:port' or 'port' string."""
    if ":" in addr_port:
        try:
            return int(addr_port.rsplit(":", 1)[-1])
        except ValueError:
            pass
    try:
        return int(addr_port)
    except ValueError:
        return 0


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Extract and analyse network connections from a memory dump.

    Parameters
    ----------
    evidence_path : Absolute path to the memory dump.
    case_id       : Unique case identifier.
    output_dir    : Directory where reports are written.
    config        : Configuration dict; recognised keys:
                    - ``vol_path`` (str): path to vol.py
                      (default: /opt/volatility3/vol.py).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with network connection findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []

    vol_path = config.get("vol_path", "/opt/volatility3/vol.py")

    mem_source = find_memory_source(evidence_path, output_dir, config)
    if mem_source is None:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Memory Network Connections",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
        )
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.SKIPPED,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            summary="SKIPPED — no memory image supplied for this evidence item (no .raw/.lime/.dmp/.vmem found; no hiberfil.sys/pagefile.sys carved)",
            findings=[],
            errors=[],
            statistics={},
            class_results=[cr],
        )
    # Use mem_source for all Volatility calls
    evidence_path = mem_source

    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Try NetStat then NetScan
    # ------------------------------------------------------------------
    all_connections: list[dict[str, str]] = []

    for plugin in ("windows.netstat.NetStat", "windows.netscan.NetScan"):
        txt_path = output_dir / f"network_{plugin.split('.')[-1].lower()}.txt"
        try:
            rc, stdout, stderr = _run_vol_plugin(vol_path, evidence_path, plugin, logger)
            txt_path.write_text(stdout, encoding="utf-8", errors="replace")
            artifact_paths.append(str(txt_path))
            try:
                assert_subprocess_ok(rc, stderr, f"Volatility {plugin}", logger)
            except RuntimeError as exc:
                errors.append(str(exc))
                end_time = utc_now()
                from datetime import datetime
                duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
                cr = ClassResult(
                    locus=Locus.MEMORY,
                    artefact_class="Memory Network Connections",
                    verdict=AssuranceVerdict.INDETERMINATE,
                    skip_reason=SkipReason.DEPENDENCY_MISSING,
                )
                return ModuleResult(
                    module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.ERROR,
                    start_time=start_time, end_time=end_time, duration_seconds=duration,
                    errors=errors, summary=f"ERROR — Volatility {plugin} returned rc={rc}",
                    findings=[], statistics={},
                    class_results=[cr],
                )
            rows = _parse_vol_tsv(stdout)
            if rows:
                all_connections = rows
                logger.info("[%s] %s: %d connections", MODULE_NAME, plugin, len(rows))
                break
            else:
                logger.warning("[%s] %s returned no data, trying fallback", MODULE_NAME, plugin)
        except FileNotFoundError:
            errors.append(f"Volatility 3 not found at {vol_path}")
            end_time = utc_now()
            from datetime import datetime
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            cr = ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Memory Network Connections",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.DEPENDENCY_MISSING,
            )
            return ModuleResult(
                module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
                start_time=start_time, end_time=end_time, duration_seconds=duration,
                errors=errors, summary=f"Skipped: Volatility 3 not found at {vol_path}",
                class_results=[cr],
            )
        except subprocess.TimeoutExpired:
            errors.append(f"{plugin} timed out")

    # ------------------------------------------------------------------
    # Analyse connections
    # ------------------------------------------------------------------
    established_count = 0
    listening_count = 0
    suspicious_count = 0
    unique_foreign_ips: set[str] = set()
    foreign_ip_port_map: dict[str, set[int]] = {}

    for conn in all_connections:
        state = conn.get("State", conn.get("Proto", "")).upper()
        owner = (conn.get("Owner", conn.get("Process", ""))).lower()
        local_addr = conn.get("LocalAddr", conn.get("Local Address", ""))
        foreign_addr = conn.get("ForeignAddr", conn.get("Foreign Address", ""))
        pid = conn.get("PID", "")

        if "ESTABLISHED" in state or "CLOSE_WAIT" in state:
            established_count += 1
        if "LISTEN" in state:
            listening_count += 1

        # Track foreign IPs
        if foreign_addr and foreign_addr not in ("0.0.0.0", "*", "::", "::1"):
            ip_part = foreign_addr.rsplit(":", 1)[0] if ":" in foreign_addr else foreign_addr
            if ip_part and ip_part not in ("0.0.0.0", "*"):
                unique_foreign_ips.add(ip_part)
                foreign_port = _port_from_str(foreign_addr)
                if foreign_port:
                    foreign_ip_port_map.setdefault(ip_part, set()).add(foreign_port)

        # Check: suspicious ports
        foreign_port = _port_from_str(foreign_addr)
        local_port = _port_from_str(local_addr)
        for port in (foreign_port, local_port):
            if port in _SUSPICIOUS_PORTS:
                suspicious_count += 1
                findings.append(make_finding(
                    finding_type="C2_PORT_DETECTED",
                    severity=Severity.HIGH,
                    description=(
                        f"Connection on known backdoor/C2 port {port} — "
                        f"process: '{owner}' (PID {pid}), state: {state}"
                    ),
                    evidence_path=str(evidence_path),
                    metadata={
                        "process": owner, "pid": pid,
                        "local_addr": local_addr, "foreign_addr": foreign_addr,
                        "state": state, "suspicious_port": port,
                    },
                ))

        # Check: processes that should not have network connections
        for no_net in _NO_NETWORK_PROCESSES:
            if no_net in owner and "LISTEN" not in state:
                suspicious_count += 1
                findings.append(make_finding(
                    finding_type="PROCESS_UNEXPECTED_NETWORK",
                    severity=Severity.HIGH,
                    description=(
                        f"Process '{owner}' (PID {pid}) has network connection "
                        f"to {foreign_addr} — this process should not initiate connections."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={
                        "process": owner, "pid": pid,
                        "foreign_addr": foreign_addr, "state": state,
                    },
                ))

    # Check for multiple ports to same foreign IP (port-scanning / spray pattern)
    for ip, ports in foreign_ip_port_map.items():
        if len(ports) > 5:
            findings.append(make_finding(
                finding_type="SUSPICIOUS_NETWORK_CONNECTION",
                severity=Severity.MEDIUM,
                description=(
                    f"Multiple connections ({len(ports)} ports) to foreign IP {ip} "
                    f"— possible command channel or data exfiltration."
                ),
                evidence_path=str(evidence_path),
                metadata={"foreign_ip": ip, "port_count": len(ports),
                          "ports": list(ports)[:20]},
            ))

    # Write JSON
    json_path = output_dir / "network_connections.json"
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME,
                "case_id": case_id,
                "generated_at": utc_now(),
                "total_connections": len(all_connections),
                "established": established_count,
                "listening": listening_count,
                "suspicious": suspicious_count,
                "unique_foreign_ips": len(unique_foreign_ips),
                "connections": all_connections,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(json_path))
    except OSError as exc:
        errors.append(f"Failed to write network_connections.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    if not all_connections and errors:
        status = ModuleStatus.FAILED

    summary = (
        f"Found {len(all_connections)} network connections "
        f"({established_count} established, {listening_count} listening); "
        f"{len(findings)} suspicious findings."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED" if status != ModuleStatus.FAILED else "MODULE_FAILED",
             {"module": MODULE_NAME, "case_id": case_id, "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.MEMORY,
        artefact_class="Memory Network Connections",
        verdict=AssuranceVerdict.PRESENT if findings else AssuranceVerdict.VERIFIED_ABSENT,
        count=len(findings),
    )

    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start_time,
        end_time=end_time,
        duration_seconds=duration,
        findings=findings,
        artifact_paths=artifact_paths,
        errors=errors,
        statistics={
            "total_connections": len(all_connections),
            "established_count": established_count,
            "listening_count": listening_count,
            "suspicious_count": suspicious_count,
            "unique_foreign_ips": len(unique_foreign_ips),
        },
        summary=summary,
        class_results=[cr],
    )
