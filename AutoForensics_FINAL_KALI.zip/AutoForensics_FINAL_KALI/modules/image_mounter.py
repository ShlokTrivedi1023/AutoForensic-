"""Read-only evidence access status (native stream; no OS mount)."""
from __future__ import annotations
import json, logging, time
from pathlib import Path
from typing import Any
from core.deterministic_validation import deterministic_metadata
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

MODULE_NAME = "image_mounter"


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict,
        logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now(); t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    ws = config.get("_working_set", {})
    analysis_path = Path(config.get("analysis_path") or str(evidence_path))
    partition_offset = int(config.get("partition_offset", ws.get("offset_sectors", 0) or 0))
    access_method = str(ws.get("evidence_access_method") or (
        "native_ewf_reconstruction" if analysis_path != Path(evidence_path) else "native_raw_stream"
    ))
    fs_root = ws.get("mounted_fs_root")
    deleted_root = ws.get("native_deleted_root")
    mount_attempted = bool(ws.get("os_mount_attempted", False))
    mount_succeeded = bool(ws.get("os_mount_succeeded", False))
    mount_path = ws.get("os_mount_path")
    mount_exit_code = ws.get("os_mount_exit_code")
    cleanup_status = str(ws.get("os_mount_cleanup_status") or "NOT_APPLICABLE — native read-only parsing used")
    access_finding = make_finding(
        finding_type="NATIVE_EVIDENCE_ACCESS_STATUS",
        severity=Severity.INFO,
        description=(
            f"Evidence is available through {access_method}; no sudo, FUSE, loop, "
            f"or OS-level mount was used. Filesystem offset: {partition_offset} sectors."
        ),
        evidence_path=str(evidence_path),
        metadata={
            "analysis_path": str(analysis_path), "partition_offset": partition_offset,
            "access_method": access_method, "os_mount_used": mount_succeeded, "sudo_used": False,
            "mount_attempted": mount_attempted, "mount_succeeded": mount_succeeded,
            "mount_path": mount_path, "mount_exit_code": mount_exit_code,
            "cleanup_status": cleanup_status,
            "active_corpus_root": fs_root, "deleted_corpus_root": deleted_root,
            **deterministic_metadata("orchestrator-retained read-only access manifest", validators=["analysis path existence", "access-method manifest", "no OS mount flag"]),
        },
    )
    mp = output_dir / "image_mounter_manifest.json"
    mp.write_text(json.dumps({
        "module": MODULE_NAME, "case_id": case_id, "generated_at": utc_now(),
        "execution_outcome": "ran_found_x", "analysis_path": str(analysis_path),
        "partition_offset": partition_offset, "access_method": access_method,
        "os_mount_used": mount_succeeded, "sudo_used": False,
        "mount_attempted": mount_attempted, "mount_succeeded": mount_succeeded,
        "mount_path": mount_path, "mount_exit_code": mount_exit_code,
        "cleanup_status": cleanup_status,
        "validation_result": "DIRECT_READ_ONLY_ACCESS_VALIDATED" if analysis_path.is_file() else "ACCESS_PATH_MISSING",
        "active_corpus_root": fs_root, "deleted_corpus_root": deleted_root,
    }, indent=2), encoding="utf-8")
    access_finding.artifact_path = str(mp)
    access_finding.metadata.setdefault("report_file", str(mp))
    access_validated = analysis_path.is_file() and analysis_path.stat().st_size >= 0
    status = ModuleStatus.COMPLETED if access_validated else ModuleStatus.FAILED_ISOLATED
    errors = [] if access_validated else [f"Read-only analysis path is unavailable: {analysis_path}"]
    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start, end_time=utc_now(), duration_seconds=time.monotonic()-t0,
        findings=[access_finding] if access_validated else [], artifact_paths=[str(mp)], errors=errors,
        statistics={"mounted": int(mount_succeeded), "native_access": int(access_validated),
                    "sources_discovered": 1, "sources_processed": int(access_validated),
                    "supported_objects_discovered": 1, "supported_objects_processed": int(access_validated),
                    "records_discovered": 1, "records_processed": int(access_validated),
                    "unresolved_supported_objects": 0 if access_validated else 1,
                    "parser_errors": 0,
                    "mount_attempted": mount_attempted, "mount_succeeded": mount_succeeded,
                    "mount_path": mount_path, "mount_exit_code": mount_exit_code,
                    "cleanup_status": cleanup_status,
                    "partition_offset": partition_offset, "execution_outcome": "ran_found_x"},
        summary=(f"Direct read-only evidence access completed via {access_method}. "
                 + (f"An OS-level read-only mount also completed at {mount_path}." if mount_succeeded
                    else "OS-level mounting was not required by the declared direct-access scope and is reported separately.")),
        class_results=[
            ClassResult(locus=Locus.FILE_SYSTEM, artefact_class="Direct Read-only Evidence Access",
                        verdict=AssuranceVerdict.PRESENT, count=1,
                        notes="Native parsing/reconstruction is distinct from an OS mount."),
            ClassResult(locus=Locus.FILE_SYSTEM, artefact_class="OS-level Image Mounting",
                        verdict=AssuranceVerdict.PRESENT if mount_succeeded else AssuranceVerdict.INDETERMINATE,
                        skip_reason=None if mount_succeeded else SkipReason.NOT_APPLICABLE,
                        count=1 if mount_succeeded else 0,
                        notes=(f"Mounted read-only at {mount_path}; cleanup={cleanup_status}." if mount_succeeded
                               else "No OS-level mount was attempted or validated; direct parsing does not prove mounting capability.")),
        ],
    )
