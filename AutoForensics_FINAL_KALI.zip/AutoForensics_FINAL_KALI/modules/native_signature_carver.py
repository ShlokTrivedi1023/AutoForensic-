"""Always-available signature carving module for metadata-less objects."""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from core.native_carving import carve_signatures
from modules._base import (
    AssuranceVerdict, ClassResult, Locus, ModuleResult, ModuleStatus,
    Severity, SkipReason, make_finding, utc_now,
)

MODULE_NAME = "native_signature_carver"


def run(evidence_path: Path, case_id: str, output_dir: Path, config: dict,
        logger: logging.Logger, coc_logger: Any = None) -> ModuleResult:
    start = utc_now()
    t0 = time.monotonic()
    output_dir.mkdir(parents=True, exist_ok=True)
    source = Path(config.get("analysis_path") or evidence_path).resolve()
    if not source.is_file():
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start, end_time=utc_now(), duration_seconds=time.monotonic() - t0,
            summary="DID NOT RUN — no readable logical evidence stream was available.",
            errors=[f"Evidence stream not found: {source}"],
            class_results=[ClassResult(
                locus=Locus.DELETED_FILES,
                artefact_class="Signature-Carved Objects",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NO_EVIDENCE,
            )],
        )

    errors: list[str] = []
    candidate_limit = int(config.get("native_carving_max_candidates", 0) or 0)
    max_scan = config.get("native_carving_max_scan_bytes")
    max_scan_value = int(max_scan) if max_scan not in (None, "", 0, "0") else None
    scan_limit_reached = bool(max_scan_value is not None and source.stat().st_size > max_scan_value)
    candidate_limit_reached = False
    try:
        # Zero means exhaustive.  If a caller explicitly imposes a positive
        # candidate cap, ask the core for one extra result so truncation can be
        # detected and must downgrade completion rather than occurring silently.
        core_limit = candidate_limit + 1 if candidate_limit > 0 else 0
        candidates = carve_signatures(
            source,
            output_dir / "carved",
            max_scan_bytes=max_scan_value,
            max_candidates=core_limit,
        )
        if candidate_limit > 0 and len(candidates) > candidate_limit:
            candidate_limit_reached = True
            candidates = candidates[:candidate_limit]
            errors.append(
                f"Configured native_carving_max_candidates={candidate_limit} prevented exhaustive carving; "
                "at least one additional supported observation existed."
            )
        if scan_limit_reached:
            errors.append(
                f"Configured native_carving_max_scan_bytes={max_scan_value} prevented full logical-media scanning."
            )
    except Exception as exc:
        candidates = []
        errors.append(f"Native signature carving failed: {exc}")

    inventory = ((config.get("_working_set") or {}).get("evidence_inventory") or {})
    known_hashes: dict[str, str] = {}
    for obj in inventory.get("objects") or []:
        if isinstance(obj, dict) and obj.get("sha256") and obj.get("path"):
            known_hashes.setdefault(str(obj["sha256"]), str(obj["path"]))

    findings = []
    duplicate_primary_records = 0
    invalid_accepted_carvings = 0
    accepted_carvings = 0
    candidate_carvings = 0
    rejected_carvings = 0

    for item in candidates:
        alias_of = known_hashes.get(item.sha256, "")
        metadata = item.as_dict()

        validation_state = str(
            getattr(item, "validation_state", "ACCEPTED")
        ).upper()

        if validation_state == "REJECTED":
            fact_class = "REJECTED"
            rejected_carvings += 1

        elif validation_state in {
            "CANDIDATE",
            "CANDIDATE_ONLY",
            "UNRESOLVED",
        }:
            validation_state = "CANDIDATE"
            fact_class = "CANDIDATE_ONLY"
            candidate_carvings += 1

        else:
            validation_state = "ACCEPTED"
            fact_class = (
                "ALTERNATIVE_REPRESENTATION"
                if alias_of
                else "VERIFIED_DECODED_EVIDENCE"
            )
            accepted_carvings += 1

            if alias_of:
                duplicate_primary_records += 1

        fully_validated = validation_state == "ACCEPTED"

        metadata.update({
            "validation_state": validation_state,
            "duplicate_identity": f"carved-object:{item.sha256}",
            "canonical_source_path": alias_of,
            "counts_toward_unique_evidence": (
                fully_validated and not bool(alias_of)
            ),
            "fact_class": fact_class,
            # Structural completeness and payload-integrity assurance are
            # intentionally separate.  Encrypted ZIPs can have fully validated
            # container geometry while their member payload CRC cannot be checked
            # without credentials; those remain CANDIDATE_ONLY.
            "structurally_validated": bool(getattr(item, "footer_found", False)),
            "payload_integrity_validated": bool(
                getattr(item, "payload_validated", False)
            ),
            "candidate_only": validation_state == "CANDIDATE",
            "rejected": validation_state == "REJECTED",
        })

        if fully_validated and not metadata["structurally_validated"]:
            invalid_accepted_carvings += 1

        if validation_state == "REJECTED":
            description = (
                f"Carved {item.file_type.upper()} candidate at logical "
                f"byte offset {item.offset_bytes}; deterministic payload "
                "integrity validation failed. The observation is retained "
                "for audit as REJECTED and is not reported as PRESENT."
            )

        elif validation_state == "CANDIDATE":
            description = (
                f"Carved {item.file_type.upper()} candidate at logical "
                f"byte offset {item.offset_bytes}; payload integrity could "
                "not be deterministically established. The observation is "
                "retained as CANDIDATE_ONLY and is not asserted as "
                "confirmed evidence."
            )

        elif item.file_type == "zip":
            description = (
                f"Carved a validated ZIP object at logical byte offset "
                f"{item.offset_bytes}. Container geometry, member "
                "decompression and CRC integrity were validated. "
                "Carving alone does not establish deletion state."
            )

        else:
            description = (
                f"Carved a complete {item.file_type.upper()} "
                f"signature/footer object at logical byte offset "
                f"{item.offset_bytes}. Signature carving does not by "
                "itself prove the object was deleted."
            )

        findings.append(make_finding(
            finding_type="SIGNATURE_CARVED_OBJECT",
            severity=Severity.INFO,
            description=description,
            evidence_path=str(source),
            artifact_path=(item.output_path or str(source)),
            metadata=metadata,
        ))

    outcome = (
        "ran_with_caveat" if errors else
        ("ran_found_x" if candidates else "ran_found_nothing")
    )
    manifest = output_dir / "native_signature_carving_manifest.json"
    manifest.write_text(json.dumps({
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "execution_outcome": outcome,
        "source": str(source),
        "method": "native streaming header/footer carving",
        "candidate_count": len(candidates),
        "candidate_limit_configured": candidate_limit,
        "candidate_limit_reached": candidate_limit_reached,
        "scan_limit_reached": scan_limit_reached,
        "accepted_count": accepted_carvings,
        "candidate_only_count": candidate_carvings,
        "rejected_count": rejected_carvings,
        "reporting_caveat": (
            "A carved signature object may be allocated, embedded, slack, or "
            "unallocated; deletion status is not inferred from carving alone."
        ),
        "candidates": [item.as_dict() for item in candidates],
        "errors": errors,
    }, indent=2), encoding="utf-8")

    status = ModuleStatus.ERROR if errors and not candidates else (
        ModuleStatus.PARTIAL if errors else ModuleStatus.COMPLETED
    )
    if errors and not candidates:
        verdict = AssuranceVerdict.INDETERMINATE
        skip_reason = SkipReason.PARTIAL_FAILURE
    elif accepted_carvings:
        verdict = AssuranceVerdict.PRESENT
        skip_reason = None
    elif candidate_carvings:
        verdict = AssuranceVerdict.INDETERMINATE
        skip_reason = None
    else:
        # The scan completed, but all discovered objects were
        # deterministically rejected, or no valid object was found.
        verdict = AssuranceVerdict.VERIFIED_ABSENT
        skip_reason = None

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start, end_time=utc_now(), duration_seconds=time.monotonic() - t0,
        findings=findings, artifact_paths=[str(manifest)], errors=errors,
        statistics={
            "candidate_count": len(candidates),
            "objects_discovered": len(candidates),
            "objects_processed": len(candidates),
            "accepted_findings": accepted_carvings,
            "candidate_observations": candidate_carvings,
            "rejected_observations": rejected_carvings,
            "invalid_accepted_carvings": invalid_accepted_carvings,
            "duplicate_primary_records": duplicate_primary_records,
            # Candidate-only observations are fully *processed* observations,
            # not unprocessed/unresolved coverage.  Only an imposed scan/candidate
            # limit leaves supported scope unresolved.
            "unresolved_supported_objects": (
                (1 if candidate_limit_reached else 0)
                + (1 if scan_limit_reached else 0)
            ),
            "candidate_limit_reached": candidate_limit_reached,
            "scan_limit_reached": scan_limit_reached,
            "execution_outcome": outcome,
            "native_path": True,
        },
        summary=(
            f"RAN: {accepted_carvings} validated signature-carved "
            f"object(s), {candidate_carvings} candidate-only "
            f"observation(s), and {rejected_carvings} rejected "
            "observation(s); deletion status is intentionally not inferred."
            if candidates else
            (
                "RAN WITH A CAVEAT — native signature carving failed."
                if errors
                else "RAN AND FOUND NOTHING using native signature carving."
            )
        ),
        class_results=[ClassResult(
            locus=Locus.DELETED_FILES,
            artefact_class="Signature-Carved Objects",
            verdict=verdict,
            skip_reason=skip_reason,
            count=accepted_carvings,
            notes=(
                f"Accepted={accepted_carvings}; "
                f"candidate-only={candidate_carvings}; "
                f"rejected={rejected_carvings}. "
                "Carving identifies byte-resident objects, not deletion state."
            ),
        )],
    )
