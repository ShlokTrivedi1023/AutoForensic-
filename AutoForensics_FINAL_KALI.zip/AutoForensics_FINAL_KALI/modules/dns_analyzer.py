"""
dns_analyzer.py — DNS Traffic Analysis Module for AutoForensics.

Extracts and analyses DNS queries and responses from packet capture files using
``tshark``.  Detects DNS tunneling, DGA domains, fast-flux, and queries to
suspicious TLDs and dynamic DNS providers.

Target platform : Kali Linux, Python 3.11+
External tools  : tshark (wireshark-common package)
"""

from __future__ import annotations

import json
import logging
import math
import re
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any

from core.deterministic_validation import deterministic_metadata, candidate_metadata
from core.native_network import decode_packets

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    _run_subprocess,
    make_finding,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "dns_analyzer"
TSHARK_TIMEOUT: int = 3600

# Suspicious TLDs associated with malware C2, bulletproof hosting, or privacy abuse
_SUSPICIOUS_TLDS: frozenset[str] = frozenset({
    ".bit", ".bazar", ".coin", ".onion", ".locker", ".cyou",
    ".top", ".xyz", ".gq", ".ml", ".cf", ".ga", ".tk",
})

# Dynamic DNS providers commonly abused for C2
_DYNAMIC_DNS_DOMAINS: frozenset[str] = frozenset({
    "duckdns.org", "no-ip.com", "no-ip.org", "hopto.org", "ddns.net",
    "zapto.org", "servebeer.com", "servegame.com", "servehttp.com",
    "ngrok.io", "ngrok.com", "pagekite.me", "localtunnel.me",
    "freedns.afraid.org", "changeip.com", "dynu.com",
})

# Maximum entropy for a "normal" domain name (DGA domains tend to be 3.5+)
DGA_ENTROPY_THRESHOLD: float = 3.5
# Minimum label length to apply DGA detection
DGA_MIN_LABEL_LENGTH: int = 8
# DNS tunneling: subdomain label longer than this is suspicious
DNS_TUNNEL_LABEL_LENGTH: int = 50


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _find_pcap_files(output_dir: Path, config: dict[str, Any]) -> list[Path]:
    files: list[Path] = []
    for pat in ("*.pcap", "*.pcapng", "*.cap"):
        files.extend(output_dir.rglob(pat))
    explicit = config.get("pcap_path", "")
    if explicit:
        p = Path(explicit)
        if p.is_file() and p not in files:
            files.append(p)
    for value in config.get("pcap_paths") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    ws = config.get("_working_set") or {}
    for value in ws.get("nested_network_sources") or []:
        p = Path(str(value))
        if p.is_file() and p not in files:
            files.append(p)
    # Canonicalise and de-duplicate without assuming filenames.
    unique: list[Path] = []
    seen: set[str] = set()
    for p in files:
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _string_entropy(s: str) -> float:
    """Compute Shannon entropy of a string (character-level)."""
    if not s:
        return 0.0
    counts = Counter(s.lower())
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def _extract_tld(domain: str) -> str:
    """Return the TLD (last dot-delimited label) of a domain."""
    parts = domain.rstrip(".").rsplit(".", 1)
    return "." + parts[-1].lower() if len(parts) > 1 else ""


def _is_dynamic_dns(domain: str) -> bool:
    dl = domain.lower()
    return any(dl.endswith(d) for d in _DYNAMIC_DNS_DOMAINS)


def _extract_dns_records(pcap: Path, logger: logging.Logger) -> list[dict[str, str]]:
    """
    Extract DNS query/response records from a PCAP using tshark.

    Parameters
    ----------
    pcap   : Path to the PCAP file.
    logger : Module logger.

    Returns
    -------
    List of dicts with DNS record fields.
    """
    fields = [
        "frame.number", "frame.time", "ip.src", "ip.dst",
        "dns.qry.name", "dns.qry.type",
        "dns.resp.name", "dns.a", "dns.aaaa",
        "dns.flags.response", "dns.resp.ttl",
        "dns.flags.rcode",
    ]
    cmd = ["tshark", "-r", str(pcap), "-Y", "dns",
           "-T", "fields", "-E", "header=y", "-E", "separator=|",
           "-E", "occurrence=f"]
    for f in fields:
        cmd += ["-e", f]

    records: list[dict[str, str]] = []
    try:
        rc, stdout, _ = _run_subprocess(cmd, timeout=TSHARK_TIMEOUT, logger=logger)
        if not stdout.strip():
            return records
        lines = stdout.splitlines()
        if not lines:
            return records
        headers = [h.strip() for h in lines[0].split("|")]
        for line in lines[1:]:
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < len(headers):
                parts.extend([""] * (len(headers) - len(parts)))
            records.append(dict(zip(headers, parts)))
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.warning("[%s] tshark DNS extraction failed: %s", MODULE_NAME, exc)
    return records



def _decode_dns_name(payload: bytes, offset: int) -> tuple[str, int]:
    labels=[]; seen=set(); original_next=None
    while offset < len(payload):
        if offset in seen: raise ValueError("DNS compression loop")
        seen.add(offset); length=payload[offset]
        if length == 0:
            offset += 1
            return ".".join(labels), (original_next if original_next is not None else offset)
        if length & 0xC0 == 0xC0:
            if offset+1 >= len(payload): raise ValueError("truncated DNS pointer")
            pointer=((length & 0x3F)<<8)|payload[offset+1]
            if original_next is None: original_next=offset+2
            offset=pointer; continue
        if length & 0xC0 or offset+1+length>len(payload): raise ValueError("invalid DNS label")
        labels.append(payload[offset+1:offset+1+length].decode("ascii",errors="replace"))
        offset += 1+length
    raise ValueError("unterminated DNS name")

def _extract_dns_records_native(pcap: Path, logger: logging.Logger) -> list[dict[str,str]]:
    records=[]
    for packet in decode_packets(pcap):
        payload=packet.get("transport_payload") or b""
        if not isinstance(payload,(bytes,bytearray)) or len(payload)<12:
            continue
        if int(packet.get("src_port") or 0)!=53 and int(packet.get("dst_port") or 0)!=53:
            continue
        try:
            ident=int.from_bytes(payload[0:2],"big"); flags=int.from_bytes(payload[2:4],"big")
            qd=int.from_bytes(payload[4:6],"big"); an=int.from_bytes(payload[6:8],"big")
            off=12; qname=""; qtype=0
            if qd:
                qname,off=_decode_dns_name(payload,off)
                if off+4>len(payload): raise ValueError("truncated DNS question")
                qtype=int.from_bytes(payload[off:off+2],"big"); off+=4
            answers=[]; ttl=""
            for _ in range(an):
                _,off=_decode_dns_name(payload,off)
                if off+10>len(payload): break
                rtype=int.from_bytes(payload[off:off+2],"big"); ttl_i=int.from_bytes(payload[off+4:off+8],"big"); rdlen=int.from_bytes(payload[off+8:off+10],"big"); off+=10
                rdata=payload[off:off+rdlen]; off+=rdlen
                if rtype==1 and len(rdata)==4: answers.append(".".join(str(x) for x in rdata)); ttl=str(ttl_i)
            records.append({
                "frame.number":str(packet.get("frame_number") or ""),"frame.time":str(packet.get("timestamp") or ""),"ip.src":str(packet.get("ip_src") or ""),"ip.dst":str(packet.get("ip_dst") or ""),
                "dns.qry.name":qname,"dns.qry.type":str(qtype),"dns.resp.name":qname if flags & 0x8000 else "",
                "dns.a":",".join(answers),"dns.aaaa":"","dns.flags.response":"1" if flags & 0x8000 else "0",
                "dns.resp.ttl":ttl,"dns.flags.rcode":str(flags & 0xF),"dns.id":f"0x{ident:04x}",
                "validation_method":"native DNS parser over retained UDP payload"})
        except Exception as exc:
            logger.debug("[%s] Native DNS decode skipped frame: %s",MODULE_NAME,exc)
    return records



def _answer_values(record: dict[str, str]) -> list[str]:
    values: list[str] = []
    for key in ("dns.a", "dns.aaaa", "dns.cname"):
        raw = str(record.get(key) or "")
        for value in re.split(r"[,;\s]+", raw):
            value = value.strip()
            if value and value not in values:
                values.append(value)
    return values


def _normalise_dns_records(records: list[dict[str, str]]) -> dict[str, int]:
    """Classify, count and pair DNS request/response records deterministically."""
    pending: dict[tuple[str, str, str, str], list[int]] = {}
    response_indexes: list[int] = []
    query_count = response_count = question_count = answer_count = error_count = 0
    for index, record in enumerate(records):
        response = str(record.get("dns.flags.response") or "0").strip() in {"1", "true", "True"}
        qname = str(record.get("dns.qry.name") or record.get("dns.resp.name") or "").rstrip(".").casefold()
        txid = str(record.get("dns.id") or "").casefold()
        src = str(record.get("ip.src") or "")
        dst = str(record.get("ip.dst") or "")
        client, server = (dst, src) if response else (src, dst)
        key = (txid, qname, client, server)
        record["record_type"] = "DNS_RESPONSE" if response else "DNS_QUERY"
        record["transaction_id"] = txid
        record["transaction_key"] = "|".join(key)
        record["client_ip"] = client
        record["server_ip"] = server
        record["answers"] = _answer_values(record)
        record["matched_pair"] = False
        record["matched_record_index"] = None
        if qname:
            question_count += 1
        answer_count += len(record["answers"])
        try:
            if int(str(record.get("dns.flags.rcode") or "0"), 0) != 0:
                error_count += 1
        except ValueError:
            pass
        if response:
            response_count += 1
            response_indexes.append(index)
        else:
            query_count += 1
            pending.setdefault(key, []).append(index)

    unmatched_responses = 0
    for response_index in response_indexes:
        record = records[response_index]
        key = tuple(str(record.get("transaction_key") or "").split("|", 3))
        candidates = pending.get(key) or []
        if candidates:
            query_index = candidates.pop(0)
            record["matched_pair"] = True
            record["matched_record_index"] = query_index + 1
            records[query_index]["matched_pair"] = True
            records[query_index]["matched_record_index"] = response_index + 1
        else:
            unmatched_responses += 1
    unmatched_requests = sum(len(values) for values in pending.values())
    return {
        "queries": query_count, "responses": response_count,
        "questions": question_count, "answers": answer_count, "errors": error_count,
        "unmatched_requests": unmatched_requests, "unmatched_responses": unmatched_responses,
    }

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Analyse DNS traffic from PCAP files in output_dir.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing PCAP files.
    config        : Configuration dict; recognised key: ``pcap_path``.
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with DNS_TUNNELING_INDICATOR, DGA_DOMAIN_DETECTED,
    SUSPICIOUS_TLD, DYNAMIC_DNS_USAGE findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    pcap_files = _find_pcap_files(output_dir, config)
    if not pcap_files:
        end_time = utc_now()
        from datetime import datetime
        duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
        cr = ClassResult(
            locus=Locus.NETWORK,
            artefact_class="DNS Transaction Artefacts",
            verdict=AssuranceVerdict.INDETERMINATE,
            skip_reason=SkipReason.NO_CORPUS,
            notes="No PCAP files found in output directory.",
        )
        return ModuleResult(
            module_name=MODULE_NAME, case_id=case_id, status=ModuleStatus.SKIPPED,
            start_time=start_time, end_time=end_time, duration_seconds=duration,
            summary="Skipped: no PCAP files found.",
            class_results=[cr],
        )

    all_records: list[dict[str, str]] = []
    for pcap in pcap_files:
        records = _extract_dns_records(pcap, logger)
        if not records:
            records = _extract_dns_records_native(pcap, logger)
        logger.info("[%s] %s: %d DNS records", MODULE_NAME, pcap.name, len(records))
        for record in records:
            record.setdefault("pcap_file", str(pcap))
        all_records.extend(records)

    dns_counts = _normalise_dns_records(all_records)
    total_queries = dns_counts["queries"]
    total_responses = dns_counts["responses"]
    unique_domains: set[str] = set()
    nxdomain_count = 0
    domain_ip_map: dict[str, set[str]] = {}
    domain_query_times: dict[str, list[str]] = {}
    flagged_domains: set[str] = set()
    dynamic_dns_count = 0

    for rec in all_records:
        qname = (rec.get("dns.qry.name") or rec.get("dns.resp.name") or "").lower().rstrip(".")
        if not qname:
            continue
        unique_domains.add(qname)

        # NXDOMAIN
        rcode = rec.get("dns.flags.rcode") or rec.get("dns.flags.response") or ""
        if rcode == "3":
            nxdomain_count += 1

        # Track IP responses for fast-flux detection
        ip_resp = rec.get("dns.a") or rec.get("dns.aaaa") or ""
        if ip_resp:
            domain_ip_map.setdefault(qname, set()).add(ip_resp)

        # Track query times
        ts = rec.get("frame.time") or ""
        if ts:
            domain_query_times.setdefault(qname, []).append(ts)

        # DNS tunneling: long subdomain labels
        labels = qname.split(".")
        for label in labels[:-2]:  # exclude TLD and SLD
            if len(label) > DNS_TUNNEL_LABEL_LENGTH:
                if qname not in flagged_domains:
                    flagged_domains.add(qname)
                    findings.append(make_finding(
                        finding_type="DNS_TUNNELING_INDICATOR",
                        severity=Severity.HIGH,
                        description=(
                            f"DNS query contains unusually long subdomain label ({len(label)} chars) "
                            f"in '{qname}' — possible DNS tunneling."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**candidate_metadata(
                            "DNS long-label threshold",
                            reason="Length alone cannot establish DNS tunnelling",
                        ), "domain": qname, "label": label, "label_length": len(label),
                           "threshold": DNS_TUNNEL_LABEL_LENGTH},
                    ))

        # DGA detection: high-entropy short label
        if len(labels) >= 2:
            sld = labels[-2] if len(labels) >= 2 else ""
            if len(sld) >= DGA_MIN_LABEL_LENGTH:
                ent = _string_entropy(sld)
                if ent >= DGA_ENTROPY_THRESHOLD:
                    if qname not in flagged_domains:
                        flagged_domains.add(qname)
                        findings.append(make_finding(
                            finding_type="DGA_DOMAIN_DETECTED",
                            severity=Severity.HIGH,
                            description=(
                                f"Domain '{qname}' has high-entropy label '{sld}' "
                                f"(entropy: {ent:.2f}) — possible DGA domain."
                            ),
                            evidence_path=str(evidence_path),
                            metadata={**candidate_metadata(
                                "DNS label entropy threshold",
                                reason="Entropy alone cannot establish algorithmic domain generation",
                            ), "domain": qname, "label": sld, "entropy": round(ent, 3),
                               "threshold": DGA_ENTROPY_THRESHOLD},
                        ))

        # Suspicious TLD
        tld = _extract_tld(qname)
        if tld in _SUSPICIOUS_TLDS and qname not in flagged_domains:
            flagged_domains.add(qname)
            findings.append(make_finding(
                finding_type="SUSPICIOUS_TLD",
                severity=Severity.MEDIUM,
                description=f"DNS query for domain with suspicious TLD '{tld}': '{qname}'",
                evidence_path=str(evidence_path),
                metadata={**candidate_metadata(
                    "configured TLD review list",
                    reason="TLD membership does not establish malicious infrastructure",
                ), "domain": qname, "tld": tld},
            ))

        # Dynamic DNS
        if _is_dynamic_dns(qname) and qname not in flagged_domains:
            dynamic_dns_count += 1
            flagged_domains.add(qname)
            findings.append(make_finding(
                finding_type="DYNAMIC_DNS_USAGE",
                severity=Severity.MEDIUM,
                description=f"DNS query for dynamic DNS domain: '{qname}'",
                evidence_path=str(evidence_path),
                metadata={**candidate_metadata(
                    "configured dynamic-DNS provider list",
                    reason="Provider use does not establish command-and-control activity",
                ), "domain": qname},
            ))

    # Fast-flux: domain with many different IPs in short time
    for domain, ips in domain_ip_map.items():
        if len(ips) > 5:
            findings.append(make_finding(
                finding_type="FAST_FLUX_DNS",
                severity=Severity.HIGH,
                description=(
                    f"Domain '{domain}' resolved to {len(ips)} different IPs — "
                    f"possible fast-flux DNS (botnet / CDN abuse)."
                ),
                evidence_path=str(evidence_path),
                metadata={**candidate_metadata(
                    "multiple-address threshold",
                    reason="Multiple answers may be normal load balancing or CDN behaviour",
                ), "domain": domain, "ip_count": len(ips), "ips": sorted(ips), "threshold": 5},
            ))

    # Exact DNS records are deterministic protocol artefacts. Heuristic labels
    # such as tunnelling/DGA remain candidate-only observations.
    for rec in all_records:
        qname = str(rec.get("dns.qry.name") or "").rstrip(".")
        answers = [str(rec.get(k) or "") for k in ("dns.a", "dns.aaaa", "dns.cname") if rec.get(k)]
        if not qname and not answers:
            continue
        source_file = str(rec.get("pcap_file") or (pcap_files[0] if pcap_files else evidence_path))
        record_type = str(rec.get("record_type") or "DNS_QUERY")
        is_response = record_type == "DNS_RESPONSE"
        description = (
            f"Decoded DNS response for '{qname or '<unknown>'}' with {len(answers)} answer value(s)."
            if is_response else
            f"Decoded DNS query for '{qname or '<unknown>'}'."
        )
        findings.append(make_finding(
            finding_type=("DNS_RESPONSE_RECORD" if is_response else "DNS_QUERY_RECORD"),
            severity=Severity.INFO,
            description=description,
            evidence_path=source_file,
            metadata={**deterministic_metadata("DNS fields decoded from retained packet bytes", validators=[rec.get("validation_method") or "tshark DNS dissector"]),
                      **rec, "query_name": qname, "answers": answers,
                      "packet_number": rec.get("frame.number"),
                      "fact_class": "VERIFIED_DECODED_EVIDENCE"},
            artifact_path=source_file if Path(source_file).is_file() else None,
        ))

    # Write report
    report_path = output_dir / "dns_analysis.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(),
                "total_dns_queries": total_queries,
                "total_dns_responses": total_responses,
                "total_dns_questions": dns_counts["questions"],
                "total_dns_answers": dns_counts["answers"],
                "dns_error_records": dns_counts["errors"],
                "unmatched_requests": dns_counts["unmatched_requests"],
                "unmatched_responses": dns_counts["unmatched_responses"],
                "unique_domains": len(unique_domains),
                "nxdomain_count": nxdomain_count,
                "candidate_domains": len(flagged_domains),
                "dynamic_dns_candidate_count": dynamic_dns_count,
                "top_queried_domains": [
                    d for d, _ in Counter(
                        (r.get("dns.qry.name") or "").lower().rstrip(".")
                        for r in all_records if r.get("record_type") == "DNS_QUERY"
                    ).most_common(50)
                ],
                "dns_records": all_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write dns_analysis.json: {exc}")

    end_time = utc_now()
    from datetime import datetime
    duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL
    exact_records = sum(1 for finding in findings if finding.finding_type in {"DNS_QUERY_RECORD", "DNS_RESPONSE_RECORD"})
    candidate_records = len(findings) - exact_records
    summary = (
        f"DNS protocol decoding retained {total_queries} query record(s) and {total_responses} response record(s) "
        f"across {len(unique_domains)} unique domain(s); {candidate_records} "
        "rule-based observation(s) remain candidate-only. Synthetic .invalid "
        "domains and documentation-range addresses are not characterised as malicious."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    cr = ClassResult(
        locus=Locus.NETWORK,
        artefact_class="DNS Transaction Artefacts",
        verdict=(
            AssuranceVerdict.PRESENT if findings
            else AssuranceVerdict.VERIFIED_ABSENT
        ),
        count=sum(1 for finding in findings if finding.finding_type == "DNS_RECORD"),
        notes="One request and one response are counted once each; rule-based anomaly observations are candidate-only.",
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics={
            "total_dns_queries": total_queries,
            "total_dns_responses": total_responses,
            "total_dns_questions": dns_counts["questions"],
            "total_dns_answers": dns_counts["answers"],
            "dns_error_records": dns_counts["errors"],
            "unmatched_requests": dns_counts["unmatched_requests"],
            "unmatched_responses": dns_counts["unmatched_responses"],
            "unique_domains": len(unique_domains),
            "nxdomain_count": nxdomain_count,
            "exact_dns_records": exact_records,
            "candidate_domains": len(flagged_domains),
            "dynamic_dns_candidate_count": dynamic_dns_count,
            "candidate_observations": candidate_records,
        },
        summary=summary,
        class_results=[cr],
    )
