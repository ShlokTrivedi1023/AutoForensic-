"""
suspicious_file_detector.py — Suspicious File Characteristic Detector for AutoForensics.

Detects files with anomalous characteristics that may indicate malware, anti-forensics,
or hidden data:

  1. Shannon entropy analysis — high entropy suggests encryption, compression, or packing.
  2. Packer signature detection — UPX, MPRESS, and other PE packer signatures.
  3. Double extension detection — files like 'invoice.pdf.exe'.
  4. Anomalous metadata — future timestamps, zero-byte files, no extension.

Target platform : Kali Linux, Python 3.11+
External tools  : none (pure Python)
"""

from __future__ import annotations

import json
import logging
import math
import struct
import time
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from core.deterministic_validation import deterministic_metadata, candidate_metadata

from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    make_finding,
    resolve_absence_verdict,
    resolve_corpus_roots,
    iter_corpus_files,
    utc_now,
)

try:
    from core.custody_log import EventType
    _COC_AVAILABLE = True
except ImportError:
    _COC_AVAILABLE = False
    EventType = None  # type: ignore[assignment,misc]

MODULE_NAME: str = "suspicious_file_detector"

# Entropy thresholds
ENTROPY_HIGH: float = 7.2    # Almost certainly encrypted/compressed/packed
ENTROPY_MEDIUM: float = 6.5  # Possibly compressed

# Packer signatures: (label, bytes_to_search_in_header, signature_bytes)
_PACKER_SIGNATURES: list[tuple[str, int, bytes]] = [
    ("UPX",    512, b"UPX0"),
    ("UPX",    512, b"UPX1"),
    ("MPRESS", 512, b"MPRESS1"),
    ("MPRESS", 512, b"MPRESS2"),
    ("FSG",    512, b"FSG!"),
    ("Petite", 512, b"Petite"),
    ("ASPack", 512, b"ASPack"),
    ("PECompact", 512, b"PEC2"),
    ("NsPack", 512, b"nsp0"),
    ("NSPack", 512, b"nsp1"),
]

# Suspicious section names in PE files
_SUSPICIOUS_SECTIONS: frozenset[bytes] = frozenset({
    b".UPX0", b".UPX1", b".upx0", b".upx1",
    b".MPRESS1", b".MPRESS2",
    b".nsp0", b".nsp1",
})

# Known text / media extensions that should never have executable content
_BINARY_BAIT_EXTENSIONS: frozenset[str] = frozenset({
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".txt", ".csv", ".mp3", ".mp4", ".avi", ".mov",
})
_EXPECTED_COMPRESSED_EXTENSIONS: frozenset[str] = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".tif", ".tiff",
    ".zip", ".rar", ".7z", ".gz", ".bz2", ".xz",
    ".mp3", ".mp4", ".avi", ".mov", ".pdf",
    ".docx", ".xlsx", ".pptx", ".odt", ".ods", ".odp",
})



@dataclass
class EntropyResult:
    """Result of entropy analysis for a single file."""
    path: str
    avg_entropy: float
    max_block_entropy: float
    is_likely_packed: bool
    block_count: int


def _log_coc(coc_logger: Any, event: str, details: dict[str, Any]) -> None:
    if coc_logger is None:
        return
    try:
        coc_logger.info("COC_EVENT: %s | %s", event,
                        " | ".join(f"{k}={v}" for k, v in details.items()))
    except Exception:
        pass


def _shannon_entropy(data: bytes) -> float:
    """
    Compute Shannon entropy of a byte sequence.

    Parameters
    ----------
    data : Raw bytes to analyse.

    Returns
    -------
    Entropy in bits per byte (0.0 – 8.0).
    """
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    length = len(data)
    entropy = 0.0
    for c in counts:
        if c > 0:
            p = c / length
            entropy -= p * math.log2(p)
    return entropy


def _analyze_entropy(file_path: Path, block_size: int = 4096) -> Optional[EntropyResult]:
    """
    Compute block-wise Shannon entropy for a file.

    A 4 KiB default avoids the severe finite-sample downward bias produced by
    256-byte blocks, where even uniformly random data rarely reaches the configured
    7.2-bit threshold.

    Parameters
    ----------
    file_path  : Path to the file.
    block_size : Read this many bytes per block.

    Returns
    -------
    EntropyResult, or None if the file cannot be read.
    """
    block_entropies: list[float] = []
    try:
        with open(file_path, "rb") as f:
            while True:
                block = f.read(block_size)
                if not block:
                    break
                block_entropies.append(_shannon_entropy(block))
    except OSError:
        return None

    if not block_entropies:
        return EntropyResult(
            path=str(file_path), avg_entropy=0.0,
            max_block_entropy=0.0, is_likely_packed=False, block_count=0,
        )

    avg = sum(block_entropies) / len(block_entropies)
    mx = max(block_entropies)
    return EntropyResult(
        path=str(file_path),
        avg_entropy=round(avg, 4),
        max_block_entropy=round(mx, 4),
        is_likely_packed=avg >= ENTROPY_HIGH,
        block_count=len(block_entropies),
    )


def _detect_packer(file_path: Path) -> Optional[str]:
    """
    Check the first 512 bytes of a file for known packer signatures.

    Parameters
    ----------
    file_path : Path to the file (typically a PE executable).

    Returns
    -------
    Packer name string if detected, else None.
    """
    try:
        with open(file_path, "rb") as f:
            header = f.read(512)
    except OSError:
        return None

    for label, search_len, sig in _PACKER_SIGNATURES:
        if sig in header[:search_len]:
            return label
    return None


def _check_pe_sections(file_path: Path) -> list[str]:
    """
    Parse PE section names and return those that are suspicious.

    Parameters
    ----------
    file_path : Path to the file (PE format).

    Returns
    -------
    List of suspicious section names.
    """
    suspicious: list[str] = []
    try:
        with open(file_path, "rb") as f:
            data = f.read(4096)  # Enough to cover the PE header and section table

        if len(data) < 64 or data[:2] != b"MZ":
            return suspicious

        # e_lfanew offset at byte 0x3C
        pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
        if pe_offset + 24 > len(data):
            return suspicious

        if data[pe_offset:pe_offset + 4] != b"PE\x00\x00":
            return suspicious

        # NumberOfSections at offset 6 from PE signature
        num_sections = struct.unpack_from("<H", data, pe_offset + 6)[0]
        # SizeOfOptionalHeader at offset 20
        opt_hdr_size = struct.unpack_from("<H", data, pe_offset + 20)[0]
        # Section table starts after the optional header
        section_offset = pe_offset + 24 + opt_hdr_size

        for i in range(min(num_sections, 96)):
            sec_start = section_offset + i * 40
            if sec_start + 8 > len(data):
                break
            name = data[sec_start:sec_start + 8].rstrip(b"\x00")
            if name in _SUSPICIOUS_SECTIONS:
                suspicious.append(name.decode("ascii", errors="replace"))

    except (struct.error, OSError):
        pass

    return suspicious


def _has_double_extension(file_path: Path) -> bool:
    """Return True if the file name has a double extension (e.g. file.pdf.exe)."""
    suffixes = file_path.suffixes
    return len(suffixes) >= 2


def _is_future_timestamp(file_path: Path) -> bool:
    """Return True if the file modification time is in the future."""
    try:
        mtime = file_path.stat().st_mtime
        now = datetime.now(timezone.utc).timestamp()
        return mtime > now + 3600  # Allow 1-hour clock skew
    except OSError:
        return False


def _is_password_protected_archive(file_path: Path) -> bool:
    """Return True for a ZIP containing at least one encrypted entry."""
    try:
        with open(file_path, "rb") as fh:
            if fh.read(4) != b"PK\x03\x04":
                return False
        with zipfile.ZipFile(file_path) as zf:
            return any(info.flag_bits & 0x1 for info in zf.infolist())
    except (OSError, zipfile.BadZipFile):
        return False



def _kdbx_header_status(file_path: Path) -> tuple[bool, str]:
    """Return exact KeePass KDBX signature validity for .kdbx files."""
    if file_path.suffix.lower() != ".kdbx":
        return True, "not_applicable"
    try:
        header=file_path.read_bytes()[:12]
    except OSError:
        return False, "unreadable"
    valid_magic=bytes.fromhex("03d9a29a67fb4bb5")
    return header.startswith(valid_magic), header.hex()

def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    """
    Detect files with suspicious characteristics in output_dir.

    Parameters
    ----------
    evidence_path : Forensic image path (recorded in findings).
    case_id       : Unique case identifier.
    output_dir    : Directory containing extracted files.
    config        : Configuration dict (no required keys).
    logger        : Standard Python logger.
    coc_logger    : Optional CustodyLogger instance.

    Returns
    -------
    ModuleResult with HIGH_ENTROPY_FILE, PACKED_EXECUTABLE, DOUBLE_EXTENSION,
    and FUTURE_TIMESTAMP findings.
    """
    start_time = utc_now()
    _log_coc(coc_logger, "MODULE_STARTED", {"module": MODULE_NAME, "case_id": case_id})

    findings = []
    artifact_paths: list[str] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    # Scan the shared corpus — the mounted filesystem root plus any recovered/
    # carved trees — never this module's own (empty) output_dir.  When no corpus
    # is available the file list is empty and the absence verdict below resolves
    # to INDETERMINATE, never VERIFIED_ABSENT.
    ws = config.get("_working_set", {})
    _corpus_roots = resolve_corpus_roots(ws, output_dir=output_dir)
    # Only retained evidentiary content is screened. Analysis configuration,
    # validation/ground-truth material and prior module output cannot become
    # suspicious-file corroboration.
    all_files: list[Path] = iter_corpus_files(
        ws, output_dir=output_dir, deduplicate_by_hash=False
    )

    logger.info("[%s] Analysing %d files", MODULE_NAME, len(all_files))

    stats = {
        "sources_discovered": len(all_files),
        "sources_processed": 0,
        "supported_objects_discovered": len(all_files),
        "supported_objects_processed": 0,
        "records_discovered": len(all_files),
        "records_processed": 0,
        "files_analyzed": 0,
        "high_entropy_count": 0,
        "packed_executables": 0,
        "anomalous_files": 0,
        "password_protected_archives": 0,
        "unresolved_supported_objects": 0,
        "parser_errors": 0,
    }
    analysis_records: list[dict[str, Any]] = []

    pe_extensions = {".exe", ".dll", ".sys", ".ocx", ".drv", ".scr"}

    for file_path in all_files:
        try:
            # Establish readability before applying the deterministic checks.  A
            # read failure is an unresolved source, never a verified absence.
            with file_path.open("rb") as probe:
                probe.read(1)
        except OSError as exc:
            errors.append(f"Cannot read {file_path}: {exc}")
            continue
        stats["files_analyzed"] += 1
        stats["sources_processed"] += 1
        stats["supported_objects_processed"] += 1
        stats["records_processed"] += 1
        ext = file_path.suffix.lower()
        anomalies: list[str] = []

        kdbx_valid, kdbx_header = _kdbx_header_status(file_path)
        if file_path.suffix.lower() == ".kdbx" and not kdbx_valid:
            stats["anomalous_files"] += 1
            anomalies.append("INVALID_KDBX_SIGNATURE")
            findings.append(make_finding(
                finding_type="INVALID_KDBX_SIGNATURE", severity=Severity.MEDIUM,
                description=(f"File '{file_path.name}' uses the .kdbx extension but does not contain the required KeePass KDBX signature."),
                evidence_path=str(evidence_path),
                metadata={**deterministic_metadata(
                    "exact KDBX signature comparison",
                    validators=["KeePass KDBX magic bytes"],
                    semantic_limit="Invalid structure only; intent and content are not inferred.",
                ), "file_path":str(file_path),"observed_header_hex":kdbx_header,
                    "expected_signature_hex":"03d9a29a67fb4bb5"},
            ))

        if _is_password_protected_archive(file_path):
            stats["password_protected_archives"] += 1
            anomalies.append("PASSWORD_PROTECTED_ARCHIVE")
            findings.append(make_finding(
                finding_type="PASSWORD_PROTECTED_ARCHIVE",
                severity=Severity.MEDIUM,
                description=(
                    f"Archive '{file_path.name}' contains encrypted entries. "
                    "Detection is content-based and does not depend on its extension."
                ),
                evidence_path=str(evidence_path),
                metadata={**deterministic_metadata(
                    "ZIP general-purpose encryption flag",
                    validators=["zipfile central-directory flag_bits"],
                    semantic_limit="Encryption status only; ownership or malicious intent is not inferred.",
                ), "file_path": str(file_path)},
            ))

        # Entropy analysis
        entropy_result = _analyze_entropy(file_path)
        if entropy_result:
            if entropy_result.avg_entropy >= ENTROPY_HIGH:
                if ext in _EXPECTED_COMPRESSED_EXTENSIONS:
                    anomalies.append(f"EXPECTED_COMPRESSION_ENTROPY:{entropy_result.avg_entropy:.2f}")
                else:
                    stats["high_entropy_count"] += 1
                    anomalies.append(f"HIGH_ENTROPY:{entropy_result.avg_entropy:.2f}")
                    findings.append(make_finding(
                        finding_type="HIGH_ENTROPY_FILE",
                        severity=Severity.MEDIUM,
                        description=(
                            f"File '{file_path.name}' has high entropy "
                            f"({entropy_result.avg_entropy:.2f} bits/byte). This can "
                            "indicate encryption, compression, packing, or random data; "
                            "entropy alone is not a malware or concealment finding."
                        ),
                        evidence_path=str(evidence_path),
                        metadata={**candidate_metadata(
                            "Shannon entropy threshold",
                            reason="High entropy can result from compression, encryption, packing or random data and does not identify cause.",
                        ), "file_path": str(file_path),
                            "avg_entropy": entropy_result.avg_entropy,
                            "max_block_entropy": entropy_result.max_block_entropy,
                            "threshold": ENTROPY_HIGH},
                    ))
            elif entropy_result.avg_entropy >= ENTROPY_MEDIUM:
                anomalies.append(f"MEDIUM_ENTROPY:{entropy_result.avg_entropy:.2f}")

        # Packer detection (PE files only)
        if ext in pe_extensions:
            packer = _detect_packer(file_path)
            if packer:
                stats["packed_executables"] += 1
                anomalies.append(f"PACKER:{packer}")
                findings.append(make_finding(
                    finding_type="PACKED_EXECUTABLE",
                    severity=Severity.MEDIUM,
                    description=(
                        f"PE file '{file_path.name}' is packed with {packer}. "
                        "This establishes the named packer signature only; malicious intent or execution is not inferred."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={
                        "file_path": str(file_path),
                        "packer": packer,
                        "extension": ext,
                    },
                ))

            suspicious_sections = _check_pe_sections(file_path)
            if suspicious_sections:
                anomalies.append(f"SUSPICIOUS_SECTIONS:{suspicious_sections}")

        # Double extension
        if _has_double_extension(file_path):
            real_ext = file_path.suffixes[-1].lower()
            decoy_ext = "".join(file_path.suffixes[:-1]).lower()
            if real_ext in pe_extensions and any(d in _BINARY_BAIT_EXTENSIONS
                                                  for d in file_path.suffixes[:-1]):
                stats["anomalous_files"] += 1
                anomalies.append("DOUBLE_EXTENSION")
                findings.append(make_finding(
                    finding_type="DOUBLE_EXTENSION",
                    severity=Severity.MEDIUM,
                    description=(
                        f"File '{file_path.name}' has multiple extensions: "
                        f"'{decoy_ext}' followed by '{real_ext}'. This is a filename "
                        f"anomaly requiring content verification; it does not by itself "
                        f"establish concealment or anti-forensic intent."
                    ),
                    evidence_path=str(evidence_path),
                    metadata={**deterministic_metadata(
                        "filename suffix parsing",
                        validators=["pathlib suffix sequence"],
                        semantic_limit="Exact naming anomaly only; concealment or intent is not inferred.",
                    ), "file_path": str(file_path), "decoy_extension": decoy_ext,
                        "real_extension": real_ext},
                ))

        # Extracted-copy host timestamps are intentionally excluded. Future-dated
        # evidence records are identified from source metadata by timeline/mobile
        # parsers, never from the host filesystem mtime of an extracted copy.

        if anomalies:
            _entropy_dict: Optional[dict] = None
            if entropy_result is not None:
                try:
                    _entropy_dict = asdict(entropy_result)
                except (TypeError, AttributeError):
                    _entropy_dict = {
                        "path": str(getattr(entropy_result, "path", "")),
                        "avg_entropy": float(getattr(entropy_result, "avg_entropy", 0.0)),
                        "max_block_entropy": float(getattr(entropy_result, "max_block_entropy", 0.0)),
                        "is_likely_packed": bool(getattr(entropy_result, "is_likely_packed", False)),
                        "block_count": int(getattr(entropy_result, "block_count", 0)),
                    }
            analysis_records.append({
                "file_path": str(file_path),
                "anomalies": anomalies,
                "entropy": _entropy_dict,
            })

    # Write JSON report
    report_path = output_dir / "suspicious_files.json"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "module": MODULE_NAME, "case_id": case_id,
                "generated_at": utc_now(), **stats,
                "suspicious_files": analysis_records,
            }, f, indent=2, ensure_ascii=True)
        artifact_paths.append(str(report_path))
    except OSError as exc:
        errors.append(f"Failed to write suspicious_files.json: {exc}")

    stats["unresolved_supported_objects"] = max(0, len(all_files) - stats["files_analyzed"])
    stats["parser_errors"] = len(errors)

    end_time = utc_now()
    from datetime import datetime as dt2
    duration = (dt2.fromisoformat(end_time) - dt2.fromisoformat(start_time)).total_seconds()

    status = ModuleStatus.COMPLETED if not errors else ModuleStatus.PARTIAL

    summary = (
        f"Analysed {stats['files_analyzed']} files; "
        f"{stats['high_entropy_count']} high-entropy, "
        f"{stats['packed_executables']} packed executables, "
        f"{stats['password_protected_archives']} password-protected archive(s), "
        f"{stats['anomalous_files']} exact structural/naming anomalies. "
        "Entropy and packer-rule observations remain candidate-only; extracted-copy host mtimes are excluded."
    )

    _log_coc(coc_logger, "MODULE_COMPLETED", {"module": MODULE_NAME, "case_id": case_id,
                                               "findings": len(findings)})

    # Absence is only "verified" if we actually examined a non-empty corpus with
    # the technique applied; examining 0 files can never confirm absence.
    _verdict, _skip = resolve_absence_verdict(
        found=len(findings),
        examined=stats["files_analyzed"],
        technique_applied=True,  # entropy/packer/extension checks are pure-Python, always applied
        status=status,
    )
    cr = ClassResult(
        locus=Locus.MALWARE,
        artefact_class="Suspicious File Indicators",
        verdict=_verdict,
        skip_reason=_skip,
        count=len(findings),
        notes=(
            "" if _verdict != AssuranceVerdict.INDETERMINATE
            else f"No corpus examined ({stats['files_analyzed']} files) — absence unverified."
        ),
    )

    return ModuleResult(
        module_name=MODULE_NAME, case_id=case_id, status=status,
        start_time=start_time, end_time=end_time, duration_seconds=duration,
        findings=findings, artifact_paths=artifact_paths, errors=errors,
        statistics=stats, summary=summary,
        class_results=[cr],
    )
