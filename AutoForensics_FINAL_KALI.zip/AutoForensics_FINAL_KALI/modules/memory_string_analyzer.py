"""Deterministic literal-string analysis for genuine or nested memory sources.

The module scans every explicitly classified memory source and every nested
memory-marker source supplied by the orchestrator. It reports literal pattern
occurrences only. A pattern-shaped string is not described as a valid credential,
malware IOC, ownership indicator, process object or network connection.
"""
from __future__ import annotations

import hashlib
import json
import logging
import mmap
import re
from pathlib import Path
from typing import Any, Iterable

from core.deterministic_validation import deterministic_metadata
from modules._base import (
    AssuranceVerdict,
    ClassResult,
    Locus,
    ModuleResult,
    ModuleStatus,
    Severity,
    SkipReason,
    make_finding,
    utc_now,
)

MODULE_NAME = "memory_string_analyzer"
MIN_LENGTH = 8

_STRING_ASCII = re.compile(rb"[\x20-\x7e]{8,}")
_STRING_UTF16LE = re.compile(rb"(?:[\x20-\x7e]\x00){8,}")

_PATTERNS: dict[str, re.Pattern[str]] = {
    "ipv4": re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"),
    "url": re.compile(r"\b(?:https?|ftp)://[^\s<>\"'\\]{4,}", re.IGNORECASE),
    "email": re.compile(r"\b[a-zA-Z0-9._%+\-]{2,64}@[a-zA-Z0-9.\-]{2,253}\.[a-zA-Z]{2,}\b"),
    "ntlm_pair": re.compile(r"\b[a-fA-F0-9]{32}:[a-fA-F0-9]{32}\b"),
    "jwt_shape": re.compile(r"\beyJ[a-zA-Z0-9_\-]{10,}\.[a-zA-Z0-9_\-]{10,}(?:\.[a-zA-Z0-9_\-]{10,})?\b"),
    "aws_access_key_shape": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "gcp_api_key_shape": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    "bitcoin_address_shape": re.compile(r"\b(?:[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[a-z0-9]{8,87})\b"),
    "ethereum_address_shape": re.compile(r"\b0x[a-fA-F0-9]{40}\b"),
    "encoded_powershell_shape": re.compile(r"(?:-enc(?:odedcommand)?|-e)\s+([A-Za-z0-9+/]{40,}={0,2})", re.IGNORECASE),
}

_SEVERITY = {
    "ipv4": Severity.INFO,
    "url": Severity.INFO,
    "email": Severity.INFO,
    "ntlm_pair": Severity.MEDIUM,
    "jwt_shape": Severity.MEDIUM,
    "aws_access_key_shape": Severity.MEDIUM,
    "gcp_api_key_shape": Severity.MEDIUM,
    "bitcoin_address_shape": Severity.INFO,
    "ethereum_address_shape": Severity.INFO,
    "encoded_powershell_shape": Severity.MEDIUM,
}

_SENSITIVE = {
    "ntlm_pair", "jwt_shape", "aws_access_key_shape", "gcp_api_key_shape",
    "encoded_powershell_shape",
}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _source_paths(evidence_path: Path, config: dict[str, Any]) -> list[Path]:
    ws = config.get("_working_set") or {}
    values: list[Any] = []
    for key in ("memory_path", "memory_image"):
        if config.get(key):
            values.append(config[key])
    values.extend(config.get("memory_paths") or [])
    values.extend(config.get("memory_marker_paths") or [])
    values.extend(ws.get("nested_memory_sources") or [])
    values.extend(ws.get("nested_memory_marker_sources") or [])
    if str(config.get("evidence_type") or "").lower() == "memory":
        values.append(evidence_path)

    unique: list[Path] = []
    seen_paths: set[str] = set()
    seen_hashes: set[str] = set()
    for value in values:
        path = Path(str(value))
        if not path.is_file():
            continue
        try:
            resolved = str(path.resolve())
        except OSError:
            resolved = str(path)
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        try:
            digest = _sha256(path)
        except OSError:
            continue
        if digest in seen_hashes:
            continue
        seen_hashes.add(digest)
        unique.append(path)
    return unique


def _iter_strings(path: Path) -> Iterable[tuple[int, str, str]]:
    """Yield ``(byte_offset, encoding, literal)`` without loading the file."""
    with path.open("rb") as handle:
        if path.stat().st_size == 0:
            return
        with mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ) as mapped:
            for match in _STRING_ASCII.finditer(mapped):
                yield match.start(), "ASCII", match.group().decode("ascii", errors="strict")
            for match in _STRING_UTF16LE.finditer(mapped):
                yield match.start(), "UTF-16LE", match.group().decode("utf-16le", errors="strict")


def _display_value(category: str, value: str) -> dict[str, str]:
    digest = hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()
    if category in _SENSITIVE:
        if len(value) <= 8:
            masked = "[REDACTED]"
        else:
            masked = value[:4] + "…" + value[-4:]
        return {"value_display": masked, "value_sha256": digest}
    return {"value": value, "value_sha256": digest}


def run(
    evidence_path: Path,
    case_id: str,
    output_dir: Path,
    config: dict[str, Any],
    logger: logging.Logger,
    coc_logger: Any = None,
) -> ModuleResult:
    start = utc_now()
    output_dir.mkdir(parents=True, exist_ok=True)
    sources = _source_paths(evidence_path, config)
    if not sources:
        now = utc_now()
        return ModuleResult(
            module_name=MODULE_NAME,
            case_id=case_id,
            status=ModuleStatus.NOT_APPLICABLE,
            start_time=start,
            end_time=now,
            findings=[],
            errors=[],
            statistics={
                "sources_discovered": 0,
                "sources_processed": 0,
                "supported_objects_discovered": 0,
                "supported_objects_processed": 0,
                "records_discovered": 0,
                "records_processed": 0,
                "unresolved_supported_objects": 0,
                "applicability_check_completed": True,
                "execution_outcome": "did_not_run",
            },
            summary="NOT APPLICABLE — no genuine or nested memory source was identified.",
            class_results=[ClassResult(
                locus=Locus.MEMORY,
                artefact_class="Literal strings in memory sources",
                verdict=AssuranceVerdict.INDETERMINATE,
                skip_reason=SkipReason.NOT_APPLICABLE,
                notes="The orchestrator's memory-source inventory contained no applicable source.",
            )],
        )

    max_occurrences = int(config.get("max_memory_string_occurrences") or 0)
    occurrences: dict[str, list[dict[str, Any]]] = {key: [] for key in _PATTERNS}
    total_strings = 0
    source_records: list[dict[str, Any]] = []
    unresolved = 0
    errors: list[str] = []

    for source in sources:
        try:
            source_hash = _sha256(source)
            strings_for_source = 0
            matches_for_source = 0
            for base_offset, encoding, literal in _iter_strings(source):
                total_strings += 1
                strings_for_source += 1
                for category, pattern in _PATTERNS.items():
                    for match in pattern.finditer(literal):
                        value = match.group(1) if category == "encoded_powershell_shape" else match.group(0)
                        relative = match.start(1) if category == "encoded_powershell_shape" else match.start(0)
                        byte_offset = base_offset + (relative * 2 if encoding == "UTF-16LE" else relative)
                        record = {
                            "category": category,
                            "source_path": str(source),
                            "source_sha256": source_hash,
                            "byte_offset": byte_offset,
                            "encoding": encoding,
                            **_display_value(category, value),
                        }
                        if max_occurrences and sum(len(v) for v in occurrences.values()) >= max_occurrences:
                            unresolved += 1
                        else:
                            occurrences[category].append(record)
                        matches_for_source += 1
            source_records.append({
                "source_path": str(source),
                "source_sha256": source_hash,
                "bytes": source.stat().st_size,
                "strings_examined": strings_for_source,
                "literal_pattern_occurrences": matches_for_source,
                "completed": True,
            })
        except (OSError, ValueError) as exc:
            errors.append(f"{source}: {exc}")
            unresolved += 1
            source_records.append({"source_path": str(source), "completed": False, "error": str(exc)})

    ledger_path = output_dir / "memory_literal_string_occurrences.jsonl"
    with ledger_path.open("w", encoding="utf-8") as handle:
        for category in sorted(occurrences):
            for record in occurrences[category]:
                handle.write(json.dumps(record, sort_keys=True, ensure_ascii=True) + "\n")

    findings = []
    for category, records in occurrences.items():
        if not records:
            continue
        source_paths = sorted({record["source_path"] for record in records})
        findings.append(make_finding(
            finding_type="LITERAL_MEMORY_STRING_PATTERN",
            severity=_SEVERITY[category],
            description=(
                f"{len(records)} literal {category.replace('_', ' ')} pattern occurrence(s) "
                f"were found across {len(source_paths)} memory source(s). This records string "
                "presence only and does not validate the value or attribute activity."
            ),
            evidence_path=source_paths[0],
            artifact_path=str(ledger_path),
            metadata={
                **deterministic_metadata(
                    "byte-exact ASCII/UTF-16LE extraction and literal regular-expression matching",
                    validators=["source SHA-256", "byte offset", "encoding", "literal value or redacted value hash"],
                    semantic_limit="Literal pattern presence only; validity, ownership, execution and maliciousness are not inferred.",
                ),
                "category": category,
                "occurrence_count": len(records),
                "occurrences": records,
                "source_paths": source_paths,
                "ledger_path": str(ledger_path),
            },
        ))

    manifest_path = output_dir / "memory_string_analysis_manifest.json"
    manifest = {
        "module": MODULE_NAME,
        "case_id": case_id,
        "generated_at": utc_now(),
        "policy": "Literal presence only; sensitive values are masked and represented by SHA-256.",
        "sources": source_records,
        "strings_examined": total_strings,
        "occurrence_counts": {key: len(value) for key, value in occurrences.items()},
        "unresolved_occurrences": unresolved,
        "ledger": str(ledger_path),
        "errors": errors,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8")

    processed = sum(1 for record in source_records if record.get("completed"))
    status = ModuleStatus.COMPLETED if not errors and unresolved == 0 and processed == len(sources) else ModuleStatus.PARTIAL
    verdict = (
        AssuranceVerdict.PRESENT if findings
        else AssuranceVerdict.VERIFIED_ABSENT if status == ModuleStatus.COMPLETED
        else AssuranceVerdict.INDETERMINATE
    )
    return ModuleResult(
        module_name=MODULE_NAME,
        case_id=case_id,
        status=status,
        start_time=start,
        end_time=utc_now(),
        findings=findings,
        artifact_paths=[str(ledger_path), str(manifest_path)],
        errors=errors,
        statistics={
            "sources_discovered": len(sources),
            "sources_processed": processed,
            "supported_objects_discovered": len(sources),
            "supported_objects_processed": processed,
            "records_discovered": total_strings,
            "records_processed": total_strings,
            "literal_pattern_occurrences": sum(len(v) for v in occurrences.values()),
            "unresolved_supported_objects": unresolved + (len(sources) - processed),
            "parser_errors": len(errors),
            "execution_outcome": "ran_found_x" if findings else ("ran_found_nothing" if status == ModuleStatus.COMPLETED else "ran_with_caveat"),
        },
        summary=(
            f"Examined {total_strings} ASCII/UTF-16LE string records from {processed}/{len(sources)} "
            f"memory source(s); retained {sum(len(v) for v in occurrences.values())} exact literal pattern occurrence(s)."
        ),
        class_results=[ClassResult(
            locus=Locus.MEMORY,
            artefact_class="Literal strings in memory sources",
            verdict=verdict,
            skip_reason=None if verdict != AssuranceVerdict.INDETERMINATE else SkipReason.PARTIAL_FAILURE,
            count=len(findings),
            notes="No kernel structures or real-world attribution are inferred from literal strings.",
        )],
    )
