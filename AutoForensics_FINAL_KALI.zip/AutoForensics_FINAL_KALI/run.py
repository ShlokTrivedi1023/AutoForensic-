#!/usr/bin/env python3
"""
run.py — AutoForensics single-command entry point.

Validates the execution environment (Python version, external tools, config
files), then hands off to core/main.py.  Every check emits a clear fix
instruction when it fails so the operator can resolve issues without digging
through documentation.

Flags
-----
  --check     Verify the environment and exit without starting an investigation.
  --version   Print the AutoForensics version and the version of every external
              tool, then exit.

All other flags are forwarded verbatim to core/main.py (see its --help for the
full argument list).
"""

from __future__ import annotations

import argparse
import getpass
import hmac
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Platform constants
# ---------------------------------------------------------------------------

from core.version import VERSION

# Project root is the directory that contains this file.
# Resolved at import time so every path check is consistent regardless of
# how run.py was invoked (python run.py, ./run.py, via symlink, etc.).
_PROJECT_ROOT = Path(__file__).parent.resolve()

# Python version gate — 3.10 for structural pattern matching and modern typing
_MIN_PYTHON: tuple[int, int] = (3, 10)

# Config files that must exist and be parseable before any investigation starts.
# Each entry is (path, human-readable label).
_CONFIG_FILES: list[tuple[Path, str]] = [
    (_PROJECT_ROOT / "config" / "modules.yaml", "module configuration"),
]

# ---------------------------------------------------------------------------
# External tool specifications
#
# Each dict describes one required external tool:
#   name         Human-readable tool name (used in output messages).
#   binary       Executable name searched on PATH via shutil.which().
#   version_args Command arguments that print a short version string.
#                Use None for tools whose version check is handled specially.
#   fix          apt-get / manual command to install the missing tool.
#   extra_paths  Absolute paths to check when the binary is not on PATH
#                (useful for tools installed outside the standard prefix).
# ---------------------------------------------------------------------------

_TOOLS: list[dict] = [
    {
        "name":         "tshark",
        "binary":       "tshark",
        "version_args": ["tshark", "--version"],
        "fix":          "sudo apt-get install -y tshark wireshark-common",
        "extra_paths":  [],
    },
    {
        "name":         "hashcat",
        "binary":       "hashcat",
        "version_args": ["hashcat", "--version"],
        "fix":          "sudo apt-get install -y hashcat",
        "extra_paths":  [],
    },
    {
        "name":         "john",
        "binary":       "john",
        "version_args": ["john", "--list=build-info"],
        "fix":          "sudo apt-get install -y john",
        "extra_paths":  [],
    },
    {
        "name":         "yara",
        "binary":       "yara",
        "version_args": ["yara", "--version"],
        "fix":          "sudo apt-get install -y yara",
        "extra_paths":  [],
    },
    {
        "name":         "clamscan",
        "binary":       "clamscan",
        "version_args": ["clamscan", "--version"],
        "fix":          "sudo apt-get install -y clamav",
        "extra_paths":  [],
    },
    {
        "name":         "bulk_extractor",
        "binary":       "bulk_extractor",
        "version_args": ["bulk_extractor", "--version"],
        "fix":          "sudo apt-get install -y bulk-extractor",
        "extra_paths":  [],
    },
    {
        "name":         "foremost",
        "binary":       "foremost",
        "version_args": ["foremost", "-V"],
        "fix":          "sudo apt-get install -y foremost",
        "extra_paths":  [],
    },
    {
        "name":         "scalpel",
        "binary":       "scalpel",
        "version_args": ["scalpel", "-V"],
        "fix":          "sudo apt-get install -y scalpel",
        "extra_paths":  [],
    },
    {
        "name":         "exiftool",
        "binary":       "exiftool",
        "version_args": ["exiftool", "-ver"],
        "fix":          "sudo apt-get install -y libimage-exiftool-perl",
        "extra_paths":  [],
    },
    {
        "name":         "tesseract",
        "binary":       "tesseract",
        "version_args": ["tesseract", "--version"],
        "fix":          "sudo apt-get install -y tesseract-ocr",
        "extra_paths":  [],
    },
    {
        "name":         "steghide",
        "binary":       "steghide",
        "version_args": ["steghide", "--version"],
        "fix":          "sudo apt-get install -y steghide",
        "extra_paths":  [],
    },
    {
        # volatility3 is not a single binary — it is a Python package cloned
        # to /opt/volatility3.  We check for the vol.py launcher script.
        "name":         "volatility3",
        "binary":       None,         # not a PATH binary
        "version_args": None,         # handled specially in _check_tool()
        "fix":          (
            "git clone https://github.com/volatilityfoundation/volatility3 "
            "/opt/volatility3\n"
            "  pip install -r /opt/volatility3/requirements.txt"
        ),
        "extra_paths":  ["/opt/volatility3/vol.py"],
        "vol3_launcher": "/opt/volatility3/vol.py",
    },
]


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------

def _check_python_version() -> tuple[bool, str]:
    """
    Return (ok, message) for the Python version requirement.

    A False result is always fatal — the interpreter cannot be swapped
    mid-run, so we exit immediately rather than collecting further errors.
    """
    current = sys.version_info[:2]
    if current >= _MIN_PYTHON:
        return True, f"Python {sys.version.split()[0]}"

    return False, (
        f"Python {current[0]}.{current[1]} detected — "
        f"AutoForensics requires Python {_MIN_PYTHON[0]}.{_MIN_PYTHON[1]}+.\n"
        "  Fix: install Python 3.10 or later from https://www.python.org/downloads/\n"
        "  On Kali: sudo apt-get install -y python3.11 python3.11-venv"
    )


def _run_version_cmd(args: list[str], timeout: int = 8) -> str:
    """
    Run a tool version command and return the first non-empty output line.

    Returns "installed (version check failed)" if the process crashes or
    times out — the tool is still usable; we just could not read its version.
    Never raises.
    """
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        # Many tools print version to stderr (e.g. foremost, scalpel)
        output = result.stdout.strip() or result.stderr.strip()
        if output:
            return output.splitlines()[0][:120]
        return "installed (no version output)"
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return "installed (version check failed)"


def _check_tool(spec: dict) -> tuple[bool, str]:
    """
    Return (ok, message) for one tool specification.

    ok=True  means the tool is available (message is the version string).
    ok=False means the tool is missing (message is an error + fix instruction).
    """
    name = spec["name"]

    # ── Special case: Volatility 3 may be a PATH wrapper or vol.py ──
    if name == "volatility3":
        try:
            from core.volatility_adapter import resolve_volatility_launcher
            launcher = resolve_volatility_launcher({})
            return True, (
                f"volatility3: {launcher.version} "
                f"({launcher.resolved_path}; {launcher.source})"
            )
        except (FileNotFoundError, OSError) as exc:
            return False, (
                f"volatility3 not found — {exc}\n"
                f"  Fix: {spec['fix']}"
            )

    # ── Normal binary tool ─────────────────────────────────────────────
    # Search PATH first, then any extra_paths listed in the spec.
    binary: Optional[str] = shutil.which(spec["binary"])
    if binary is None:
        for extra in spec.get("extra_paths", []):
            if Path(extra).exists():
                binary = extra
                break

    if binary is None:
        return False, (
            f"{name}: not found on PATH.\n"
            f"  Fix: {spec['fix']}"
        )

    version_args = spec.get("version_args")
    if version_args:
        ver = _run_version_cmd([binary, *version_args[1:]])
        return True, f"{name}: {ver}"

    return True, f"{name}: found at {binary}"


def _check_config(path: Path, label: str) -> tuple[bool, str]:
    """
    Return (ok, message) for one config file.

    Checks existence and basic parseability only — deep schema validation
    is left to core/main.py which can produce more contextual error messages.
    """
    if not path.exists():
        if path.suffix == ".json":
            fix = (
                "register at least one investigator first:\n"
                "  python tools/admin.py register-investigator"
            )
        else:
            fix = f"copy or create the file from the template in config/"
        return False, f"{label} not found at {path}.\n  Fix: {fix}"

    # Parse the file to catch syntax errors before they surface inside the investigation
    try:
        if path.suffix == ".json":
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict):
                return False, (
                    f"{label} at {path} is not a JSON object — "
                    "must be a top-level mapping."
                )
        elif path.suffix in (".yaml", ".yml"):
            # Import yaml lazily — if PyYAML is missing, give a helpful message
            try:
                import yaml
            except ImportError:
                return False, (
                    f"{label}: cannot parse {path} — PyYAML not installed.\n"
                    "  Fix: pip install PyYAML"
                )
            with open(path, encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
            if not isinstance(data, dict):
                return False, (
                    f"{label} at {path} is not a YAML mapping — "
                    "must be a top-level mapping."
                )
    except (json.JSONDecodeError, OSError) as exc:
        return False, f"{label} at {path} is invalid: {exc}"

    return True, f"{label}: OK  ({path.name})"


# ---------------------------------------------------------------------------
# Aggregate check runner
# ---------------------------------------------------------------------------

def _run_all_checks() -> tuple[list[str], list[str]]:
    """
    Execute every environment check and return (ok_messages, error_messages).

    The caller uses the presence of errors to decide whether to proceed or abort.
    Checks are always run in full so the operator sees every problem at once,
    not one-at-a-time with successive re-runs.
    """
    ok: list[str] = []
    errors: list[str] = []

    # ── Python version — always first ──────────────────────────────────
    passed, msg = _check_python_version()
    if not passed:
        # Python version failure is immediately fatal — nothing else can run.
        print(f"\n  [FAIL] {msg}\n", file=sys.stderr)
        sys.exit(1)
    ok.append(msg)

    # ── External tools ─────────────────────────────────────────────────
    for spec in _TOOLS:
        passed, msg = _check_tool(spec)
        (ok if passed else errors).append(msg)

    # ── Config files ───────────────────────────────────────────────────
    for path, label in _CONFIG_FILES:
        passed, msg = _check_config(path, label)
        (ok if passed else errors).append(msg)

    return ok, errors


# ---------------------------------------------------------------------------
# Output formatters
# ---------------------------------------------------------------------------

def _print_check_results(ok: list[str], errors: list[str]) -> None:
    """
    Print check results with clear [OK] / [FAIL] prefix and indented fix hints.
    """
    for msg in ok:
        print(f"  [OK  ]  {msg}")
    for msg in errors:
        # First line carries the [FAIL] tag; continuation lines (fix hints)
        # are indented to match so they are visually grouped with the error.
        lines = msg.splitlines()
        print(f"  [FAIL]  {lines[0]}")
        for extra_line in lines[1:]:
            print(f"           {extra_line}")


def _print_versions() -> None:
    """
    Print the AutoForensics version and the version string of every tool.

    Missing tools are shown as "not found" rather than raising so that the
    operator can run --version even on a partially configured system.
    """
    print("\nAutoForensics")
    print(f"Python         {sys.version.split()[0]}  ({sys.executable})")
    print()
    print("External tools:")
    for spec in _TOOLS:
        passed, msg = _check_tool(spec)
        status = "" if passed else "  [NOT FOUND]"
        print(f"  {msg}{status}")
    print()


# ---------------------------------------------------------------------------
# Investigation launcher
# ---------------------------------------------------------------------------

def _launch_investigation(forwarded_args: list[str]) -> int:
    """
    Import core/main.py and invoke ForensicOrchestrator.run().

    We import directly (rather than spawning a subprocess) so that the process
    is a single Python interpreter.  This avoids the overhead of a second
    interpreter start-up, keeps the log output in one stream, and allows
    tests to mock internals more easily.

    All arguments that were not consumed by run.py's own parser are forwarded
    to core/main.py's argument parser unchanged.

    Parameters
    ----------
    forwarded_args:
        sys.argv-style list of strings to parse inside core/main.py.

    Returns
    -------
    Process exit code (0 success, 1 failure).
    """
    # Add the project root to sys.path so that `from core.xxx import` resolves
    # regardless of the working directory from which run.py was invoked.
    root_str = str(_PROJECT_ROOT)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    try:
        import logging

        from core.main import (
            DEFAULT_OUTPUT_DIR,
            ForensicOrchestrator,
            _build_parser,
        )
    except ImportError as exc:
        print(
            f"\nFATAL: Cannot import core/main.py: {exc}\n"
            "Ensure run.py is in the AutoForensics project root directory.",
            file=sys.stderr,
        )
        return 1

    inner_parser = _build_parser()
    args = inner_parser.parse_args(forwarded_args)

    raw_output = getattr(args, "output_dir", None)
    output_dir = Path(raw_output).resolve() if raw_output else DEFAULT_OUTPUT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )

    orchestrator = ForensicOrchestrator(output_dir=output_dir)
    return orchestrator.run(args)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------



class _PersistedCustodyView:
    """Read-only view of a previously written custody JSONL ledger."""

    def __init__(self, ledger_path: Path) -> None:
        import json as _json
        self._ledger_path = ledger_path
        self._entries_data: list[dict] = []
        for line in ledger_path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                item = _json.loads(line)
            except Exception:
                item = {"_malformed": True, "raw": line[:500]}
            self._entries_data.append(item)

    @staticmethod
    def _entry_hash(item: dict) -> str:
        import hashlib as _hashlib, json as _json
        content = {k: item.get(k) for k in (
            "timestamp", "entry_id", "event_type", "investigator_id",
            "case_id", "description", "evidence_path", "metadata",
            "previous_hash",
        )}
        raw = _json.dumps(content, sort_keys=True, ensure_ascii=True)
        return _hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def entries_with_status(self) -> list[dict]:
        out: list[dict] = []
        previous = "GENESIS"
        for idx, item in enumerate(self._entries_data):
            row = dict(item)
            if row.get("_malformed"):
                row["status"] = "MALFORMED"
            else:
                valid = (
                    row.get("previous_hash") == previous
                    and row.get("self_hash") == self._entry_hash(row)
                )
                row["status"] = ("GENESIS" if idx == 0 and valid else "PASS" if valid else "FAIL")
                previous = str(row.get("self_hash") or "")
            out.append(row)
        return out

    def verify_chain(self) -> bool:
        return all(x.get("status") in {"GENESIS", "PASS"} for x in self.entries_with_status())

    def log(self, *args: Any, **kwargs: Any) -> None:
        # Report-only mode must never mutate a sealed historical ledger.
        return None


def _run_report_only(case_dir: Path, case_config: Any = None,
                     require_llm: bool = False) -> int:
    """
    Generate a full PDF report from an existing case output directory.

    Bypasses environment checks and the investigation pipeline entirely.
    Reads module output JSON files from case_dir, constructs ModuleResult
    objects, and calls ReportGenerator.generate().

    Parameters
    ----------
    case_dir:
        Directory produced by a previous AutoForensics investigation run,
        containing module output JSON manifests.
    case_config:
        Optional CaseConfig loaded from --case JSON; when supplied every
        report section is populated with real case metadata.

    Returns
    -------
    Exit code: 0 for success, 1 for failure.
    """
    import logging
    import os

    root_str = str(_PROJECT_ROOT)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
    logger = logging.getLogger("autoforensics.report_only")

    if not case_dir.is_dir():
        print(f"\nFATAL: Case directory does not exist: {case_dir}\n", file=sys.stderr)
        return 1

    try:
        from core.report_loader import load_case_results, load_evidence_acquisition
        from core.report_generator import ReportGenerator
        from core.llm_provider import LLMUnavailable
    except ImportError as exc:
        print(
            f"\nFATAL: Cannot import required report modules: {exc}\n"
            "Ensure run.py is executed from the AutoForensics project root.",
            file=sys.stderr,
        )
        return 1

    case_id = (
        str(getattr(case_config, "case_number", "") or "").strip()
        if case_config is not None else ""
    ) or case_dir.name
    logger.info("--report-only: loading case '%s' from %s", case_id, case_dir)

    all_module_results = load_case_results(case_dir, logger, case_config=case_config)
    logger.info("Loaded %d module result(s) with %d total finding(s)",
                len(all_module_results),
                sum(len(r.findings) for r in all_module_results))

    evidence_items = load_evidence_acquisition(case_dir)

    output_dir = case_dir / "reports"
    output_dir.mkdir(parents=True, exist_ok=True)

    api_key = ""  # provider credentials are read directly from the environment

    custody_path = case_dir / f"{case_id}_custody.jsonl"
    custody_view = _PersistedCustodyView(custody_path) if custody_path.is_file() else None

    gen = ReportGenerator(
        case_id=case_id,
        investigator=(case_config.examiner.name if case_config else "AutoForensics Examiner"),
        all_module_results=all_module_results,
        coc_logger=custody_view,
        output_dir=output_dir,
        case_dir=case_dir,
        api_key=api_key,
        evidence_items=evidence_items,
        classification=(case_config.classification if case_config else "CONFIDENTIAL"),
        case_config=case_config,
        require_llm=require_llm,
    )

    try:
        result = gen.generate()
    except LLMUnavailable as exc:
        # Strict mode (--require-llm / REQUIRE_LLM): abort rather than emit the
        # deterministic fallback.  Clear message, non-zero exit — no traceback.
        logger.error("Strict LLM mode: aborting — configured synthesis unavailable: %s", exc)
        print(
            "\nFATAL: --require-llm is set but the configured LLM synthesis was unavailable:\n"
            f"  {exc}\n"
            "Check LLM_PROVIDER and the corresponding API key/model settings, or "
            "drop --require-llm to allow the labelled deterministic fallback.\n",
            file=sys.stderr,
        )
        return 2
    except Exception as exc:
        logger.error("Report generation failed: %s", exc, exc_info=True)
        print(f"\nFATAL: Report generation failed: {exc}\n", file=sys.stderr)
        return 1

    total_findings = sum(len(r.findings) for r in all_module_results)
    print(f"\n{'='*60}")
    print(f"  AutoForensics Report Generated — Case {case_id}")
    print(f"{'='*60}")
    print(f"  PDF:      {result.pdf_path}")
    print(f"  JSON:     {result.json_path}")
    print(f"  Pages:    {result.page_count}")
    print(f"  Findings: {total_findings}")
    print(f"  SHA-256:  {result.sha256_hash}")
    print(f"  Time:     {result.generation_time:.1f}s")
    print(f"  API calls:{result.api_calls_made}")
    if result.quality_warnings:
        print(f"\n  Quality warnings ({len(result.quality_warnings)}):")
        for w in result.quality_warnings:
            print(f"    - {w}")
    print()
    return 0


def _case_config_complete(cfg: Any) -> bool:
    """Return True if cfg is STRUCTURALLY complete enough to skip the wizard.

    Required: case_number, examiner.name, and at least one evidence item that
    declares a non-empty path.  Path *existence* is deliberately NOT checked
    here: a user who supplied a case file with declared evidence paths should
    use that file, not be dropped into the wizard merely because the paths do
    not resolve on the current host (e.g. images staged on another machine).
    Path existence is validated at acquisition time with a clear error.
    """
    if not getattr(cfg, "case_number", ""):
        return False
    examiner = getattr(cfg, "examiner", None)
    if not examiner or not getattr(examiner, "name", ""):
        return False
    evidence = getattr(cfg, "evidence_items", [])
    if not evidence:
        return False
    return any(str(getattr(e, "path", "") or "").strip() for e in evidence)


def _case_evidence_paths_exist(cfg: Any) -> bool:
    """Return True if at least one declared evidence path resolves on this host."""
    for e in getattr(cfg, "evidence_items", []) or []:
        p = str(getattr(e, "path", "") or "").strip()
        if p and Path(p).exists():
            return True
    return False


def _require_llm_enabled(ns: Any) -> bool:
    """
    Return True when strict LLM mode is requested via the --require-llm flag or
    a truthy REQUIRE_LLM environment variable.  Falsey env values (0, empty,
    false, no, off) do not enable strict mode.
    """
    if getattr(ns, "require_llm", False):
        return True
    val = os.environ.get("REQUIRE_LLM", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def _build_run_parser() -> argparse.ArgumentParser:
    """
    Build the argument parser for run.py's own flags.

    We use parse_known_args() so that flags intended for core/main.py pass
    through without being declared here.  add_help=False prevents -h from
    being consumed before we can decide whether to also print core/main.py's
    help text.
    """
    parser = argparse.ArgumentParser(
        prog="autoforensics",
        description="AutoForensics — Automated Digital Forensic Investigation Platform",
        add_help=False,
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help=(
            "Verify Python version, external tools, and config files. "
            "Exits 0 if all checks pass, 1 if any fail.  Does not start "
            "an investigation."
        ),
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print AutoForensics version and all external tool versions, then exit.",
    )
    parser.add_argument(
        "--report-only",
        metavar="CASE_DIR",
        default=None,
        help=(
            "Generate a full PDF report from an existing case output directory "
            "without re-running the investigation pipeline.  CASE_DIR must be "
            "the path to a completed AutoForensics case output directory."
        ),
    )
    parser.add_argument(
        "--case",
        metavar="CASE_CONFIG_JSON",
        default=None,
        help=(
            "Path to a case_config.json file containing all case metadata. "
            "If omitted, an interactive wizard collects the information."
        ),
    )
    parser.add_argument(
        "--case-file",
        metavar="CASE_CONFIG_JSON",
        default=None,
        help=(
            "Path to a case config JSON file. Skips the interactive wizard when "
            "case_number, examiner.name, and at least one evidence item with a valid "
            "path are present. A missing profile defaults to 'full'."
        ),
    )
    parser.add_argument(
        "--skip-check",
        action="store_true",
        help=(
            "Skip external tool environment checks and start the investigation anyway. "
            "Modules requiring missing tools will report SKIPPED status. "
            "Useful on Windows or partially configured systems."
        ),
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help=(
            "Never launch the interactive wizard or prompt for input. Requires a "
            "case configuration via --case-file/--case or AUTOFORENSICS_CASE_CONFIG. "
            "Exits with an error instead of prompting when configuration is absent."
        ),
    )
    parser.add_argument(
        "--require-llm",
        action="store_true",
        help=(
            "Strict LLM mode: abort report generation with a non-zero exit if "
            "the configured LLM provider is unavailable instead of emitting the "
            "labelled deterministic fallback. Also enabled by setting the "
            "REQUIRE_LLM environment variable to a truthy value (1/true/yes/on)."
        ),
    )
    parser.add_argument(
        "--help", "-h",
        action="store_true",
        help="Show this help message (and core/main.py help) then exit.",
    )
    return parser


def _print_preflight_checklist(cfg: Any) -> None:
    """Print which supplementary files were found vs missing."""
    supp = cfg.supplementary
    print("\n  PRE-FLIGHT CHECKLIST - Supplementary Files")
    print("  " + "-" * 52)

    def _check(label: str, path: str) -> None:
        if path and Path(path).is_file():
            print(f"  [FOUND  ] {label}")
        elif path:
            print(f"  [MISSING] {label} — path given but file not found: {path}")
        else:
            print(f"  [MISSING] {label} — not provided; appendix will show placeholder")

    _check("Authorisation letter",  supp.authorisation_letter)
    _check("Chain of custody form", supp.coc_form_image)
    _check("Examiner signature",    supp.examiner_signature)
    _check("Supervisor signature",  supp.supervisor_signature)
    for i, p in enumerate(supp.evidence_bag_photos, 1):
        _check(f"Evidence bag photo {i}", p)
    if not supp.evidence_bag_photos:
        print("  [MISSING] Evidence bag photos — not provided; appendix will show placeholder")
    for i, p in enumerate(getattr(supp, "additional_files", []) or [], 1):
        _check(f"Additional supporting file {i}", p)
    print()


def _auto_install_deps() -> None:
    """Never modify the analysis host during an investigation run.

    Dependencies are declared in requirements.txt and pre-flight checks report
    what is unavailable. Optional capabilities then skip or use native fallbacks.
    """
    return None


def _run_preflight_checks(case_config=None) -> list[tuple[str, str, str]]:
    """Run pre-flight checks. Returns list of (label, PASS/WARN/FAIL, detail)."""
    import shutil as _shutil
    import subprocess as _sp
    results = []

    def _check_tool(name: str, version_args: list[str], *, accepted_rc: tuple[int, ...] = (0,)) -> tuple[str, str]:
        binary = _shutil.which(name)
        if not binary:
            return "FAIL", f"{name} not found"
        try:
            r = _sp.run([binary, *version_args[1:]], capture_output=True, text=True, timeout=10)
            output = (r.stdout or r.stderr or "").strip()
            first = output.splitlines()[0][:120] if output else f"found at {binary}"
            invalid = any(token in output.casefold() for token in (
                "invalid option", "unknown option", "unrecognized option", "illegal option",
            ))
            if r.returncode not in accepted_rc or invalid:
                return "WARN", f"binary found but capability probe was not accepted (rc={r.returncode}): {first}"
            return "PASS", first
        except Exception as exc:
            return "WARN", str(exc)[:120]

    def _check_pip(pkg: str, import_name: str) -> tuple[str, str]:
        try:
            __import__(import_name)
            return "PASS", f"{pkg} importable"
        except ImportError:
            return "FAIL", f"{pkg} not installed — run: pip install {pkg}"

    results.append(("TSK (fls)",  *_check_tool("fls",  ["fls",  "-V"])))
    results.append(("TSK (mmls)", *_check_tool("mmls", ["mmls", "-V"])))
    results.append(("TSK (icat)", *_check_tool("icat", ["icat", "-V"])))
    results.append(("john",       *_check_tool("john", ["john", "--list=build-info"])))
    results.append(("hashcat",    *_check_tool("hashcat", ["hashcat", "--version"])))
    results.append(("scalpel",    *_check_tool("scalpel", ["scalpel", "-V"])))
    results.append(("python-registry", *_check_pip("python-registry", "Registry")))
    results.append(("wand",       *_check_pip("wand", "wand")))
    results.append(("reportlab",  *_check_pip("reportlab", "reportlab")))
    results.append(("PIL",        *_check_pip("Pillow", "PIL")))

    if case_config:
        for ev in getattr(case_config, "evidence_items", []):
            if getattr(ev, "path", ""):
                p = Path(ev.path)
                s, d = ("PASS", str(p)) if p.exists() else ("FAIL", f"NOT FOUND: {p}")
                results.append((f"Evidence: {getattr(ev, 'label', '')[:30]}", s, d))
        supp = getattr(case_config, "supplementary", None)
        if supp:
            for attr, label in [
                ("authorisation_letter", "Auth letter"),
                ("coc_form_image", "COC form image"),
            ]:
                path_str = getattr(supp, attr, "")
                if path_str:
                    p = Path(path_str)
                    s = "PASS" if p.exists() else "WARN"
                    results.append((label, s, str(p) if p.exists() else f"NOT FOUND: {p}"))
            for i, photo in enumerate(getattr(supp, "evidence_bag_photos", [])):
                p = Path(photo)
                s = "PASS" if p.exists() else "WARN"
                results.append((f"Evidence bag photo {i+1}", s,
                                 str(p) if p.exists() else f"NOT FOUND: {p}"))
            for i, extra in enumerate(getattr(supp, "additional_files", []) or []):
                p = Path(extra)
                s = "PASS" if p.exists() else "WARN"
                results.append((f"Supporting file {i+1}", s,
                                 str(p) if p.exists() else f"NOT FOUND: {p}"))

    return results


def _interactive_account_gate() -> dict[str, Any] | None:
    """Authenticate an existing investigator or invoke administrator-led account creation.

    Account creation deliberately remains an administrative action; the wizard never
    weakens the registry by allowing unauthenticated self-registration.
    """
    try:
        from core.main import (
            INVESTIGATORS_REGISTRY_PATH,
            _ensure_investigators_registry,
            _hash_password,
        )
    except ImportError as exc:
        print(f"\nFATAL: Cannot initialise investigator authentication: {exc}", file=sys.stderr)
        return None

    _ensure_investigators_registry()
    while True:
        print("\n" + "=" * 62)
        print("                         AUTOFORENSICS")
        print("=" * 62)
        print("  Investigator Authentication")
        print("\n  [1] Sign in with an existing investigator account")
        print("  [2] Create a new investigator account (administrator approval required)")
        print("  [3] Exit")
        choice = input("\n  Select option: ").strip()
        if choice == "3":
            return None
        if choice == "2":
            admin_tool = _PROJECT_ROOT / "tools" / "admin.py"
            print("\n  Starting administrator-led investigator registration...\n")
            rc = subprocess.call([sys.executable, str(admin_tool), "add-investigator"])
            if rc != 0:
                print("\n  Account creation did not complete. If this is a first-run installation,")
                print("  initialise the administrator with: python3 tools/admin.py set-admin-password")
            continue
        if choice != "1":
            print("  Select 1, 2 or 3.")
            continue

        investigator_id = input("  Investigator ID: ").strip()
        password = getpass.getpass("  Password: ")
        if not investigator_id or not password:
            print("  Authentication failed.")
            continue
        try:
            registry = json.loads(INVESTIGATORS_REGISTRY_PATH.read_text(encoding="utf-8"))
            profile = dict((registry.get("investigators") or {}).get(investigator_id) or {})
            salt_hex = str(profile.get("password_salt") or "")
            stored = str(profile.get("password_hash") or "")
            active = bool(profile.get("active", True))
            if not profile or not active or not salt_hex or not stored:
                raise ValueError("credential check failed")
            candidate = _hash_password(password, bytes.fromhex(salt_hex))
            if not hmac.compare_digest(candidate, stored):
                raise ValueError("credential check failed")
        except Exception:
            print("  Authentication failed.")
            continue

        # Core authentication remains authoritative and records the login in its
        # audit/chain-of-custody flow.  Pass the credential only inside this process
        # and consume it immediately when core starts.
        os.environ["AUTOFORENSICS_INVESTIGATOR_ID"] = investigator_id
        os.environ["AUTOFORENSICS_PASSWORD"] = password
        print(f"  Authentication verified for {profile.get('name') or investigator_id}.")
        return profile


def main(argv: Optional[list[str]] = None) -> int:
    """
    Top-level entry point.

    Parameters
    ----------
    argv:
        Argument list to parse.  Defaults to sys.argv[1:] when None.
        The parameter exists so tests can call main() without patching sys.argv.

    Returns
    -------
    Exit code: 0 for success / clean exit, 1 for any failure.
    """
    parser = _build_run_parser()
    known, forwarded = parser.parse_known_args(argv)

    # Normalise the --require-llm flag into REQUIRE_LLM so every downstream path
    # (report-only here AND the full pipeline in core/main.py) observes strict
    # mode uniformly through the environment.
    if _require_llm_enabled(known):
        os.environ["REQUIRE_LLM"] = "1"

    _auto_install_deps()

    # ── --help ──────────────────────────────────────────────────────────
    if known.help:
        parser.print_help()
        print(
            "\nInvestigation arguments (forwarded to core/main.py):\n"
            "(pass --help to an investigation run for the full list)"
        )
        root_str = str(_PROJECT_ROOT)
        if root_str not in sys.path:
            sys.path.insert(0, root_str)
        try:
            from core.main import _build_parser as _inner_parser
            print()
            _inner_parser().print_help()
        except ImportError:
            print("  (core/main.py could not be imported — check your installation)")
        return 0

    # ── --version ───────────────────────────────────────────────────────
    if known.version:
        _print_versions()
        return 0

    # ── Early setup: sys.path + case config load (needed before --report-only) ─
    root_str = str(_PROJECT_ROOT)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    case_cfg = None
    if known.case:
        try:
            from core.case_config import load_case_config
            case_cfg = load_case_config(known.case)
            print(f"\n  [FOUND  ] Case config: {known.case}  ({case_cfg.case_number})")
        except ValueError as exc:
            print(f"\n  [ERROR  ] {exc}", file=sys.stderr)
            return 1
        except ImportError as exc:
            print(f"\n  [FATAL  ] Cannot import case_config: {exc}", file=sys.stderr)
            return 1

    if case_cfg is None and known.case_file:
        try:
            from core.case_config import load_case_config
            _loaded = load_case_config(known.case_file)
            if _case_config_complete(_loaded):
                if not _loaded.investigation_profile:
                    _loaded.investigation_profile = "full"
                case_cfg = _loaded
                print(f"\n  [FOUND  ] Case file: {known.case_file}  ({case_cfg.case_number})")
                if not _case_evidence_paths_exist(case_cfg):
                    print(
                        "  [WARN   ] None of the declared evidence paths resolve on this "
                        "host; acquisition will validate paths and fail clearly if they "
                        "remain unavailable."
                    )
            else:
                print(
                    f"\n  [WARN   ] --case-file '{known.case_file}' is missing required "
                    "fields (case_number, examiner.name, or an evidence item with a "
                    "declared path)."
                )
        except ValueError as exc:
            print(f"\n  [ERROR  ] {exc}", file=sys.stderr)
            return 1
        except ImportError as exc:
            print(f"\n  [FATAL  ] Cannot import case_config: {exc}", file=sys.stderr)
            return 1

    # ── --report-only (skip pipeline; generate report from existing output) ─
    if known.report_only:
        return _run_report_only(
            Path(known.report_only).resolve(),
            case_config=case_cfg,
            require_llm=_require_llm_enabled(known),
        )

    # ── --check (environment only, no investigation) ─────────────────────
    if known.check:
        print("\nAutoForensics — Environment Check")
        print("=" * 54)
        ok, errors = _run_all_checks()
        print()
        _print_check_results(ok, errors)
        print()
        if errors:
            total = len(ok) + len(errors)
            print(
                f"Result: FAILED — {len(errors)} of {total} checks failed.\n"
                "Resolve the issues above and re-run:  python run.py --check"
            )
            return 1
        print(f"Result: PASSED — all {len(ok)} checks OK.")
        return 0

    # ── Normal launch: check environment, then start investigation ───────
    ok, errors = _run_all_checks()

    if errors:
        if known.skip_check:
            print(
                f"\nAutoForensics — Environment Check WARNINGS "
                f"({len(errors)} missing tool(s))\n"
                "--skip-check active: proceeding anyway; affected modules will be SKIPPED.\n",
                file=sys.stderr,
            )
            _print_check_results([], errors)
            print(file=sys.stderr)
        else:
            print(
                f"\nAutoForensics — Environment Check FAILED\n"
                + "=" * 54
                + "\nThe following requirements are missing or misconfigured:\n",
                file=sys.stderr,
            )
            _print_check_results([], errors)
            print(
                "\nFix all issues above, then re-launch AutoForensics.\n"
                "Use  python run.py --check  to re-verify without starting an investigation.",
                file=sys.stderr,
            )
            return 1

    # ── Interactive investigator account gate ─────────────────────────────
    account_profile = None
    _forwarded_has_id = any(arg == "--investigator-id" or arg.startswith("--investigator-id=") for arg in forwarded)
    if (
        sys.stdin.isatty()
        and not getattr(known, "non_interactive", False)
        and not _forwarded_has_id
        and not os.environ.get("AUTOFORENSICS_INVESTIGATOR_ID", "").strip()
    ):
        account_profile = _interactive_account_gate()
        if account_profile is None:
            print("\nAutoForensics exited before case intake.")
            return 0

    # ── Load from AUTOFORENSICS_CASE_CONFIG env var before falling back to wizard ─
    if case_cfg is None:
        _env_path = os.environ.get("AUTOFORENSICS_CASE_CONFIG", "")
        if _env_path:
            try:
                from core.case_config import load_case_config
                _env_loaded = load_case_config(_env_path)
                if _case_config_complete(_env_loaded):
                    if not _env_loaded.investigation_profile:
                        _env_loaded.investigation_profile = "full"
                    case_cfg = _env_loaded
                    print(
                        f"\n  [FOUND  ] AUTOFORENSICS_CASE_CONFIG: {_env_path}"
                        f"  ({case_cfg.case_number})"
                    )
            except (ValueError, ImportError):
                pass  # Non-fatal; fall through to wizard

    # ── Load or collect case configuration ───────────────────────────────
    if case_cfg is None:
        # --case, --case-file, and AUTOFORENSICS_CASE_CONFIG not supplied or incomplete.
        # In non-interactive mode (explicit flag or no attached TTY) never prompt:
        # fail with a clear, actionable error instead of blocking on the wizard.
        _non_interactive = getattr(known, "non_interactive", False) or not sys.stdin.isatty()
        if _non_interactive:
            print(
                "\nFATAL: No usable case configuration and running non-interactively.\n"
                "Supply --case-file <file.json> (with case_number, examiner.name and at "
                "least one evidence item with a declared path), set "
                "AUTOFORENSICS_CASE_CONFIG, or run without --non-interactive on a "
                "terminal to use the wizard.",
                file=sys.stderr,
            )
            return 1
        try:
            from core.case_config import run_wizard
        except ImportError as exc:
            print(f"\nFATAL: Cannot import case_config: {exc}", file=sys.stderr)
            return 1
        print("\n  No case config supplied — launching interactive wizard.\n")
        try:
            case_cfg = run_wizard(examiner_defaults=account_profile)
        except (KeyboardInterrupt, EOFError):
            print(
                "\n\nWizard cancelled. "
                "Pass --case-file <file.json> or set AUTOFORENSICS_CASE_CONFIG to skip."
            )
            return 1

    # If the investigator explicitly enabled cloud narrative in the case wizard,
    # collect the OpenAI credential securely without persisting it in the case JSON.
    _ai_policy = getattr(case_cfg, "ai_policy", None)
    if (
        _ai_policy is not None
        and str(getattr(_ai_policy, "mode", "")).casefold() == "cloud_opt_in"
        and bool(getattr(_ai_policy, "allow_cloud_case_data", False))
    ):
        os.environ["LLM_PROVIDER"] = "openai"
        os.environ.setdefault("OPENAI_MODEL", "gpt-4o-mini")
        if not os.environ.get("OPENAI_API_KEY", "").strip() and sys.stdin.isatty():
            _key = getpass.getpass("  OpenAI API key (hidden; not stored in case file): ").strip()
            if _key:
                os.environ["OPENAI_API_KEY"] = _key

    _print_preflight_checklist(case_cfg)

    checks = _run_preflight_checks(case_config=case_cfg)
    pass_count = sum(1 for _, s, _ in checks if s == "PASS")
    fail_count = sum(1 for _, s, _ in checks if s == "FAIL")
    warn_count = sum(1 for _, s, _ in checks if s == "WARN")
    print(f"\nPre-flight: {pass_count} PASS  {warn_count} WARN  {fail_count} FAIL")
    for label, status, detail in checks:
        icon = {"PASS": "[+]", "WARN": "[!]", "FAIL": "[X]"}.get(status, "[ ]")
        print(f"  {icon} {label:<35} {status:<5} {detail[:60]}")
    if fail_count > 0 and not getattr(known, "skip_check", False):
        print("\nFAIL items detected. Use --skip-check to proceed anyway.")
        return 1

    import os as _os
    import tempfile as _tempfile
    import json as _json
    import dataclasses as _dc

    def _serial(obj: Any) -> Any:
        if _dc.is_dataclass(obj):
            return {k: _serial(v) for k, v in _dc.asdict(obj).items()}
        if hasattr(obj, "isoformat"):
            return obj.isoformat()
        return obj

    with _tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as _tmp:
        _json.dump(_serial(case_cfg), _tmp)
        _tmp_path = _tmp.name

    _os.environ["AUTOFORENSICS_CASE_CONFIG"] = _tmp_path

    # Forward the non-interactive decision to core.main, which parses its own
    # args and never sees --non-interactive (run.py consumes it).  Without this
    # the orchestrator would still prompt for authentication and confirmation.
    if getattr(known, "non_interactive", False) or not sys.stdin.isatty():
        _os.environ["AUTOFORENSICS_NON_INTERACTIVE"] = "1"

    return _launch_investigation(forwarded)


if __name__ == "__main__":
    sys.exit(main())
