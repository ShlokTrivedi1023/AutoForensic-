# AI-use disclosure

AI-assisted systems, including Anthropic Claude and OpenAI-based assistants, were used as drafting, debugging and review aids during development and documentation. Their output was not treated as evidence, an answer key or an autonomous forensic conclusion. Human review remains responsible for source-code acceptance, research claims, testing, interpretation and submission.

At runtime, the optional OpenAI integration is limited to one controlled narrative-synthesis request when explicitly enabled. The API key is read from the environment. Forensic findings are produced by deterministic modules and ledgers; the model cannot create, promote, reject or alter findings. Unsafe or unsupported absolute wording is rejected and replaced by an evidence-locked local fallback.

This disclosure should be reviewed against the applicable university or organisational AI-use policy before academic submission. It must not be removed or narrowed in a way that misstates actual assistance.
